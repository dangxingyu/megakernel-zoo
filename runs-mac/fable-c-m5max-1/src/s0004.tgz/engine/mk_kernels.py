"""Metal kernels of the engine (compiled at run time through mx.fast.metal_kernel).

Every kernel that sums over a weight row does it per (row of the pass, output) in an order that does not depend on how
many rows the pass has: explicit fma, default ("safe") math mode, simd_sum at the end. A K-row verify pass therefore
gives each row the bits the one-row step gives it (tests/rowexact.py).
"""
from __future__ import annotations

import mlx.core as mx

_BF = "as_type<float4>(uint4(*((const device vec<ushort,4>*)(%s))) << 16)"


def bf4(expr: str) -> str:
    """4 BF16 weights at expr as float4."""
    return _BF % expr


def hf4(expr: str) -> str:
    """4 activations at expr (IEEE half bits in a uint16 buffer) as float4."""
    return "float4(*((const device half4*)(%s)))" % expr


# ------------------------------------------------------------------------------------------------- dense BF16 GEMV
# out[k, n] = sum_d W[n, d] x[k, d]; W bf16 bits [N, D], x bf16 bits [K, D], D % 128 == 0. One simdgroup per output.
_GEMV = f"""
    uint n = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    float4 acc[K];
    for (int k = 0; k < K; k++) acc[k] = float4(0.0f);
    const device ushort* wr = w + size_t(n) * D;
    for (int i = 0; i < D / 128; i++) {{
        int idx = (i * 32 + lane) * 4;
        float4 wf = {bf4('wr + idx')};
        for (int k = 0; k < K; k++) {{
            float4 xv = {hf4('x + k * D + idx')};
            acc[k] = fma(wf, xv, acc[k]);
        }}
    }}
    for (int k = 0; k < K; k++) {{
        float4 a = acc[k];
        float s = simd_sum((a.x + a.y) + (a.z + a.w));
        if (lane == 0) out[k * N + n] = s;
    }}
"""
_gemv = mx.fast.metal_kernel(name="mk_gemv", input_names=["w", "x"], output_names=["out"], source=_GEMV)


def gemv(w16: mx.array, x16: mx.array, n_out: int | None = None) -> mx.array:
    """w16 uint16 [N, D] (bf16 bits), x16 uint16 [K, D] (bf16 bits) -> float32 [K, N]."""
    N, D = w16.shape
    if n_out is not None:
        N = n_out
    K = x16.shape[0]
    return _gemv(inputs=[w16, x16], template=[("D", D), ("N", N), ("K", K)], grid=(N * 32, 1, 1),
                 threadgroup=(256 if N % 8 == 0 else 32, 1, 1), output_shapes=[(K, N)], output_dtypes=[mx.float32])[0]


def bits(x: mx.array) -> mx.array:
    """float -> IEEE half bits: the activation format the kernels read (11 significant bits; BF16 has 8)."""
    return x.astype(mx.float16).view(mx.uint16)


# small float GEMV: out[k, n] = sum_d W[n, d] x[k, d], any D, one thread per output
_GEMV_S = """
    uint g = thread_position_in_grid.x;
    uint k = g / N, n = g % N;
    float acc = 0.0f;
    for (int d = 0; d < D; d++) acc = fma(w[n * D + d], x[k * D + d], acc);
    out[g] = acc;
"""
_gemv_s = mx.fast.metal_kernel(name="mk_gemv_small", input_names=["w", "x"], output_names=["out"], source=_GEMV_S)


def gemv_small(w: mx.array, x: mx.array) -> mx.array:
    N, D = w.shape
    K = x.shape[0]
    return _gemv_s(inputs=[w, x], template=[("D", D), ("N", N)], grid=(K * N, 1, 1), threadgroup=(32, 1, 1),
                   output_shapes=[(K, N)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- router
_ROUTER = """
    uint row = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    float sc[4];
    float bi[4];
    for (int i = 0; i < 4; i++) {
        uint e = lane + 32 * i;
        float x = logits[row * 128 + e];
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(x)));
        sc[i] = x < 0 ? y : 1.0f - y;
        bi[i] = sc[i] + bias[e];
    }
    float wsel[8];
    uint esel[8];
    for (int k = 0; k < 8; k++) {
        float best = -INFINITY;
        uint be = 128;
        for (int i = 0; i < 4; i++) {
            if (bi[i] > best) { best = bi[i]; be = lane + 32 * i; }
        }
        float top = simd_max(best);
        uint win = simd_min(best == top ? be : 128u);
        float s = 0.0f;
        for (int i = 0; i < 4; i++) {
            if (lane + 32 * i == win) { s = sc[i]; bi[i] = -INFINITY; }
        }
        wsel[k] = simd_sum(s);
        esel[k] = win;
    }
    float total = 0.0f;
    for (int k = 0; k < 8; k++) total += wsel[k];
    if (lane == 0) {
        for (int k = 0; k < 8; k++) {
            idx[row * 8 + k] = esel[k];
            wts[row * 8 + k] = wsel[k] / (total + 1e-20f) * 8.0f;
        }
    }
"""
_router = mx.fast.metal_kernel(name="mk_router", input_names=["logits", "bias"], output_names=["idx", "wts"], source=_ROUTER)


def router(logits: mx.array, bias: mx.array):
    K = logits.shape[0]
    return _router(inputs=[logits, bias], grid=(K * 32, 1, 1), threadgroup=(32, 1, 1), output_shapes=[(K, 8), (K, 8)],
                   output_dtypes=[mx.uint32, mx.float32])


# ------------------------------------------------------------------------------------------------- experts
def _e4m3(b: int) -> float:
    s = -1.0 if b & 128 else 1.0
    e, m = (b >> 3) & 15, b & 7
    return s * (m / 8 * 2.0 ** -6 if e == 0 else (1 + m / 8) * 2.0 ** (e - 7))


_HDR = ("constant float E2M1[16] = {0.0f, 0.5f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f, 6.0f, -0.0f, -0.5f, -1.0f, -1.5f, -2.0f, -3.0f, -4.0f, -6.0f};\n"
        "constant float E4M3[256] = {" + ", ".join(repr(float(_e4m3(b) if (b & 127) != 127 else 0.0)) + "f" for b in range(256)) + "};\n"
        """
inline float4 nv4(uint c) { return float4(E2M1[c & 15u], E2M1[(c >> 4) & 15u], E2M1[(c >> 8) & 15u], E2M1[(c >> 12) & 15u]); }
inline float4 mx4(uint c) { return float4(E4M3[c & 255u], E4M3[(c >> 8) & 255u], E4M3[(c >> 16) & 255u], E4M3[c >> 24]); }
inline float hsum(float4 a) { return (a.x + a.y) + (a.z + a.w); }
// one NVFP4 group: 16 elements (8 code bytes), x16 = 16 bf16 inputs
inline float nvgroup(const device uchar* cp, float4 x0, float4 x1, float4 x2, float4 x3) {
    uint c0 = *((const device uint*)cp);
    uint c1 = *((const device uint*)(cp + 4));
    float4 a = nv4(c0) * x0;
    a = fma(nv4(c0 >> 16), x1, a);
    a = fma(nv4(c1), x2, a);
    a = fma(nv4(c1 >> 16), x3, a);
    return hsum(a);
}
// one MXFP8 group: 32 elements (32 code bytes)
inline float mxgroup(const device uchar* cp, const device ushort* xp) {
    float4 a = float4(0.0f);
    for (int j = 0; j < 8; j++) {
        uint c = *((const device uint*)(cp + 4 * j));
        float4 xv = float4(*((const device half4*)(xp + 4 * j)));
        a = fma(mx4(c), xv, a);
    }
    return hsum(a);
}
inline ushort to_bf16(float f) {       // (name kept) the activation format between the two expert matrices: IEEE half bits
    return as_type<ushort>(half(f));
}
""")


def _dot_src(fmt: str, D: int, acc: str, cp: str, sp: str, xp: str) -> str:
    """Statements that add one lane's share of the dot of a quantized row (codes at cp, scales at sp) with the bf16 row
    at xp to `acc` (already scaled per group)."""
    if fmt == "nv":
        groups = D // 16
        it = (groups + 31) // 32
        return f"""
        for (int i = 0; i < {it}; i++) {{
            int g = i * 32 + int(lane);
            if (g < {groups}) {{
                const device ushort* xq = {xp} + g * 16;
                float4 x0 = {hf4('xq')};
                float4 x1 = {hf4('xq + 4')};
                float4 x2 = {hf4('xq + 8')};
                float4 x3 = {hf4('xq + 12')};
                {acc} = fma(nvgroup({cp} + g * 8, x0, x1, x2, x3), E4M3[({sp})[g]], {acc});
            }}
        }}"""
    groups = D // 32
    it = (groups + 31) // 32
    return f"""
        for (int i = 0; i < {it}; i++) {{
            int g = i * 32 + int(lane);
            if (g < {groups}) {{
                {acc} = fma(mxgroup({cp} + g * 32, {xp} + g * 32), as_type<float>(uint(({sp})[g]) << 23), {acc});
            }}
        }}"""


def _make_up(fmt: str):
    D, cb, sb = 2304, (1152 if fmt == "nv" else 2304), (144 if fmt == "nv" else 72)
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint p = g0 / 1152, m = g0 % 1152;
    uint e = idx[p];
    const device ushort* xr = x + (p / 8) * {D};
    const device uchar* c0 = codes + (size_t(e) * 2304 + 2 * m) * {cb};
    const device uchar* s0 = scales + (size_t(e) * 2304 + 2 * m) * {sb};
    float a0 = 0.0f, a1 = 0.0f;
    {_dot_src(fmt, D, 'a0', 'c0', 's0', 'xr')}
    {_dot_src(fmt, D, 'a1', f'(c0 + {cb})', f'(s0 + {sb})', 'xr')}
    float gs = gsc[e];
    float gt = simd_sum(a0) * gs;
    float up = simd_sum(a1) * gs;
    if (lane == 0) {{
        float gc = metal::precise::tanh(gt * 0.25f) * 4.0f;
        float uc = metal::precise::tanh(up * 0.04f) * 25.0f;
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(gt)));
        float sg = gt < 0 ? y : 1.0f - y;
        out[g0] = to_bf16(gc * sg * uc);
    }}
"""
    return mx.fast.metal_kernel(name=f"mk_up_{fmt}", input_names=["codes", "scales", "gsc", "x", "idx"], output_names=["out"],
                                source=src, header=_HDR)


def _make_down(fmt: str):
    D, cb, sb = 1152, (576 if fmt == "nv" else 1152), (72 if fmt == "nv" else 36)
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint row = g0 / 2304, n = g0 % 2304;
    float y = 0.0f;
    for (int j = 0; j < 8; j++) {{
        uint p = row * 8 + j;
        uint e = idx[p];
        const device ushort* xr = h + p * {D};
        const device uchar* c0 = codes + (size_t(e) * 2304 + n) * {cb};
        const device uchar* s0 = scales + (size_t(e) * 2304 + n) * {sb};
        float a0 = 0.0f;
        {_dot_src(fmt, D, 'a0', 'c0', 's0', 'xr')}
        y = fma(simd_sum(a0) * gsc[e], wts[p], y);
    }}
    if (lane == 0) out[g0] = y;
"""
    return mx.fast.metal_kernel(name=f"mk_down_{fmt}", input_names=["codes", "scales", "gsc", "h", "idx", "wts"],
                                output_names=["out"], source=src, header=_HDR)


_up = {f: _make_up(f) for f in ("nv", "mx")}
_down = {f: _make_down(f) for f in ("nv", "mx")}


def experts(fmt: str, w13, s13, g13, w2, s2, g2, x16: mx.array, idx: mx.array, wts: mx.array) -> mx.array:
    """x16 uint16 [K, 2304] (bf16 bits), idx uint32 [K, 8], wts float32 [K, 8] -> float32 [K, 2304]: the weighted sum of
    the 8 chosen experts (gate/up rows interleaved, soft-capped SwiGLU, BF16 between the two matrices)."""
    K = x16.shape[0]
    h = _up[fmt](inputs=[w13, s13, g13, x16, idx], grid=(K * 8 * 1152 * 32, 1, 1), threadgroup=(256, 1, 1),
                 output_shapes=[(K * 8, 1152)], output_dtypes=[mx.uint16])[0]
    return _down[fmt](inputs=[w2, s2, g2, h, idx, wts], grid=(K * 2304 * 32, 1, 1), threadgroup=(256, 1, 1),
                      output_shapes=[(K, 2304)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- attention
# One threadgroup per (row, head). Keys at positions < p0 come from the cache (bf16 bits [T, 1024]), positions p0.. from
# the rows of this pass (knew / vnew [K, 1024]). The relative bias is rel . proj[:, distance] for distance < 1024; the
# sink is one extra logit with a zero value.
_ATT = f"""
    constexpr int TG = 256;
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint grp = threadgroup_position_in_grid.x;
    int row = grp / 24, head = grp % 24, kvh = head / 3;
    int p0 = meta[0];
    int pos = p0 + row;
    int first = meta[1] > 0 ? max(0, pos - meta[1] + 1) : 0;
    threadgroup float sc[SMAX];
    threadgroup float red[8];
    threadgroup float4 part[TG];
    const device float* qp = q + grp * 128;
    const device float* rp = rel + grp * 16;
    float lmax = -INFINITY;
    for (int s = first + int(tid); s <= pos; s += TG) {{
        const device ushort* kp = (s < p0 ? kc + size_t(s) * 1024 : knew + (s - p0) * 1024) + kvh * 128;
        float4 a = float4(0.0f);
        for (int j = 0; j < 32; j++) {{
            float4 kf = {hf4('kp + 4 * j')};
            a = fma(kf, *((const device float4*)(qp + 4 * j)), a);
        }}
        float v = ((a.x + a.y) + (a.z + a.w)) * 0.08838834764831845f;
        int d = pos - s;
        if (d < 1024) {{
            float b = 0.0f;
            for (int r = 0; r < 16; r++) b = fma(rp[r], proj[r * 1024 + d], b);
            v += b;
        }}
        sc[s - first] = v;
        lmax = max(lmax, v);
    }}
    float m = simd_max(lmax);
    if (lane == 0) red[sg] = m;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float sink = sinks[grp];
    m = sink;
    for (int i = 0; i < 8; i++) m = max(m, red[i]);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float lsum = 0.0f;
    for (int s = first + int(tid); s <= pos; s += TG) {{
        float pr = metal::precise::exp(sc[s - first] - m);
        sc[s - first] = pr;
        lsum += pr;
    }}
    float ss = simd_sum(lsum);
    if (lane == 0) red[sg] = ss;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float tot = metal::precise::exp(sink - m);
    for (int i = 0; i < 8; i++) tot += red[i];
    int c = tid / 32;
    int d4 = (tid % 32) * 4;
    float4 acc = float4(0.0f);
    for (int s = first + c; s <= pos; s += 8) {{
        const device ushort* vp = (s < p0 ? vc + size_t(s) * 1024 : vnew + (s - p0) * 1024) + kvh * 128 + d4;
        float4 vf = {hf4('vp')};
        acc = fma(vf, float4(sc[s - first]), acc);
    }}
    part[tid] = acc;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (tid < 32) {{
        float4 o = part[tid];
        for (int i = 1; i < 8; i++) o += part[i * 32 + tid];
        o = o / tot;
        *((device float4*)(out + grp * 128 + d4)) = o;
    }}
"""
_att = mx.fast.metal_kernel(name="mk_attention", input_names=["q", "kc", "vc", "knew", "vnew", "rel", "proj", "sinks", "meta"],
                            output_names=["out"], source=_ATT)


def attention(q, kc, vc, knew, vnew, rel, proj, sinks, meta, smax: int) -> mx.array:
    """q float32 [K, 24, 128]; kc / vc uint16 [T, 1024]; knew / vnew uint16 [K, 1024]; rel float32 [K, 24, 16]; proj
    float32 [16, 1024]; sinks float32 [K, 24]; meta int32 [2] = (position of row 0, window or 0) -> float32 [K, 3072]."""
    K = q.shape[0]
    return _att(inputs=[q, kc, vc, knew, vnew, rel, proj, sinks, meta], template=[("SMAX", smax)], grid=(K * 24 * 256, 1, 1),
                threadgroup=(256, 1, 1), output_shapes=[(K, 3072)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- experts, shared reads
# A verify pass of K rows chooses 8K (row, expert) pairs but far fewer distinct experts. The plan kernel groups the pairs
# by expert into slots of up to M pairs; the gate/up and down kernels then read each expert's codes once per slot and
# accumulate every pair of the slot (each pair in its own accumulator, the same fma order as a one-row step: the bits
# per row do not depend on M, on the slot or on the other rows). Unused slots exit at once.
_PLAN = """
    uint e = thread_position_in_threadgroup.x;          // one thread per expert, one threadgroup of 128
    threadgroup uint cnt[128];
    uint pairs[KM];
    uint m = 0;
    for (uint p = 0; p < NP; p++) {
        if (idx[p] == e && m < KM) { pairs[m] = p; m++; }
    }
    uint ns = (m + M - 1) / M;
    cnt[e] = ns;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    uint off = 0, total = 0;
    for (uint i = 0; i < 128; i++) { if (i < e) off += cnt[i]; total += cnt[i]; }
    for (uint s = 0; s < ns; s++) {
        slot_e[off + s] = e;
        for (uint i = 0; i < M; i++) slot_p[(off + s) * M + i] = (s * M + i < m) ? pairs[s * M + i] : 0xFFFFFFFFu;
    }
    for (uint s = total + e; s < S; s += 128) {
        slot_e[s] = 0xFFFFFFFFu;
        for (uint i = 0; i < M; i++) slot_p[s * M + i] = 0xFFFFFFFFu;
    }
"""
_plan = mx.fast.metal_kernel(name="mk_plan", input_names=["idx"], output_names=["slot_e", "slot_p"], source=_PLAN)


def _decode_src(fmt: str, cp: str, g: str) -> str:
    if fmt == "nv":
        return f"""uint q0 = *((const device uint*)({cp} + {g} * 8));
                uint q1 = *((const device uint*)({cp} + {g} * 8 + 4));
                float4 w0 = nv4(q0), w1 = nv4(q0 >> 16), w2 = nv4(q1), w3 = nv4(q1 >> 16);"""
    return "\n".join(f"float4 w{j} = mx4(*((const device uint*)({cp} + {g} * 32 + {4 * j})));" for j in range(8))


def _rows_src(fmt: str, D: int, M: int, R: int, cps, sps, xps, accs) -> str:
    """One lane's share of R weight rows x M input rows. accs[r][i] accumulators; cps[r] / sps[r] code and scale pointers;
    xps[i] input row pointers."""
    per, nf = (16, 4) if fmt == "nv" else (32, 8)
    groups = D // per
    it = (groups + 31) // 32
    body = ""
    for r in range(R):
        body += "{ " + _decode_src(fmt, cps[r], "g")
        sc = f"E4M3[({sps[r]})[g]]" if fmt == "nv" else f"as_type<float>(uint(({sps[r]})[g]) << 23)"
        body += f"\n                float sc = {sc};"
        for i in range(M):
            xq = f"({xps[i]} + g * {per})"
            if fmt == "nv":
                body += f"""
                {{ float4 a = w0 * {hf4(xq)};
                  a = fma(w1, {hf4(xq + ' + 4')}, a);
                  a = fma(w2, {hf4(xq + ' + 8')}, a);
                  a = fma(w3, {hf4(xq + ' + 12')}, a);
                  {accs[r][i]} = fma(hsum(a), sc, {accs[r][i]}); }}"""
            else:
                body += f"\n                {{ float4 a = float4(0.0f);"
                for j in range(8):
                    body += f"\n                  a = fma(w{j}, {hf4(xq + f' + {4 * j}')}, a);"
                body += f"\n                  {accs[r][i]} = fma(hsum(a), sc, {accs[r][i]}); }}"
        body += " }\n"
    return f"""
        for (int it = 0; it < {it}; it++) {{
            int g = it * 32 + int(lane);
            if (g < {groups}) {{
                {body}
            }}
        }}"""


def _make_up2(fmt: str, M: int, R: int):
    D, cb, sb = 2304, (1152 if fmt == "nv" else 2304), (144 if fmt == "nv" else 72)
    accs = [[f"a{r}_{i}" for i in range(M)] for r in range(2 * R)]
    cps = [f"(c0 + {r * cb})" for r in range(2 * R)]
    sps = [f"(s0 + {r * sb})" for r in range(2 * R)]
    xps = [f"xr{i}" for i in range(M)]
    decl = "float " + ", ".join(f"{a} = 0.0f" for row in accs for a in row) + ";"
    xdecl = "\n".join(f"    uint p{i} = slot_p[s * {M} + {i}]; const device ushort* xr{i} = x + ((p{i} == 0xFFFFFFFFu ? p0 : p{i}) / 8) * {D};"
                      for i in range(M))
    fin = ""
    for r in range(R):
        for i in range(M):
            fin += f"""
    {{ float gt = simd_sum({accs[2 * r][i]}) * gs; float up = simd_sum({accs[2 * r + 1][i]}) * gs;
      if (lane == 0 && p{i} != 0xFFFFFFFFu) {{
        float gc = metal::precise::tanh(gt * 0.25f) * 4.0f;
        float uc = metal::precise::tanh(up * 0.04f) * 25.0f;
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(gt)));
        float sg = gt < 0 ? y : 1.0f - y;
        out[p{i} * 1152 + m + {r}] = to_bf16(gc * sg * uc);
      }} }}"""
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint s = g0 / {1152 // R}, m = (g0 % {1152 // R}) * {R};
    uint e = slot_e[s];
    if (e == 0xFFFFFFFFu) return;
{xdecl}
    const device uchar* c0 = codes + (size_t(e) * 2304 + 2 * m) * {cb};
    const device uchar* s0 = scales + (size_t(e) * 2304 + 2 * m) * {sb};
    {decl}
    {_rows_src(fmt, D, M, 2 * R, cps, sps, xps, accs)}
    float gs = gsc[e];
    {fin}
"""
    return mx.fast.metal_kernel(name=f"mk_up2_{fmt}_{M}_{R}", input_names=["codes", "scales", "gsc", "x", "slot_e", "slot_p"],
                                output_names=["out"], source=src, header=_HDR)


def _make_down2(fmt: str, M: int, R: int):
    D, cb, sb = 1152, (576 if fmt == "nv" else 1152), (72 if fmt == "nv" else 36)
    accs = [[f"a{r}_{i}" for i in range(M)] for r in range(R)]
    cps = [f"(c0 + {r * cb})" for r in range(R)]
    sps = [f"(s0 + {r * sb})" for r in range(R)]
    xps = [f"xr{i}" for i in range(M)]
    decl = "float " + ", ".join(f"{a} = 0.0f" for row in accs for a in row) + ";"
    xdecl = "\n".join(f"    uint p{i} = slot_p[s * {M} + {i}]; const device ushort* xr{i} = h + (p{i} == 0xFFFFFFFFu ? p0 : p{i}) * {D};"
                      for i in range(M))
    fin = ""
    for r in range(R):
        for i in range(M):
            fin += f"""
    {{ float o = simd_sum({accs[r][i]}) * gs;
      if (lane == 0 && p{i} != 0xFFFFFFFFu) out[p{i} * 2304 + n + {r}] = o; }}"""
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint s = g0 / {2304 // R}, n = (g0 % {2304 // R}) * {R};
    uint e = slot_e[s];
    if (e == 0xFFFFFFFFu) return;
{xdecl}
    const device uchar* c0 = codes + (size_t(e) * 2304 + n) * {cb};
    const device uchar* s0 = scales + (size_t(e) * 2304 + n) * {sb};
    {decl}
    {_rows_src(fmt, D, M, R, cps, sps, xps, accs)}
    float gs = gsc[e];
    {fin}
"""
    return mx.fast.metal_kernel(name=f"mk_down2_{fmt}_{M}_{R}", input_names=["codes", "scales", "gsc", "h", "slot_e", "slot_p"],
                                output_names=["out"], source=src, header=_HDR)


_COMB = """
    uint g = thread_position_in_grid.x;
    uint row = g / 2304, n = g % 2304;
    float y = 0.0f;
    for (int j = 0; j < 8; j++) y = fma(o[(row * 8 + j) * 2304 + n], wts[row * 8 + j], y);
    out[g] = y;
"""
_comb = mx.fast.metal_kernel(name="mk_comb", input_names=["o", "wts"], output_names=["out"], source=_COMB)
_up2, _down2 = {}, {}


def experts2(fmt: str, w13, s13, g13, w2, s2, g2, x16, idx, wts, M: int, RU: int = 2, RD: int = 2) -> mx.array:
    """As experts(), each distinct expert read once per slot of up to M (row, expert) pairs."""
    K = x16.shape[0]
    S = min(8 * K, 128)
    slot_e, slot_p = _plan(inputs=[idx], template=[("KM", K), ("NP", 8 * K), ("M", M), ("S", S)], grid=(128, 1, 1),
                           threadgroup=(128, 1, 1), output_shapes=[(S,), (S, M)], output_dtypes=[mx.uint32, mx.uint32])
    ku = _up2.get((fmt, M, RU)) or _up2.setdefault((fmt, M, RU), _make_up2(fmt, M, RU))
    kd = _down2.get((fmt, M, RD)) or _down2.setdefault((fmt, M, RD), _make_down2(fmt, M, RD))
    h = ku(inputs=[w13, s13, g13, x16, slot_e, slot_p], grid=(S * (1152 // RU) * 32, 1, 1), threadgroup=(256, 1, 1),
           output_shapes=[(K * 8, 1152)], output_dtypes=[mx.uint16])[0]
    o = kd(inputs=[w2, s2, g2, h, slot_e, slot_p], grid=(S * (2304 // RD) * 32, 1, 1), threadgroup=(256, 1, 1),
           output_shapes=[(K * 8, 2304)], output_dtypes=[mx.float32])[0]
    return _comb(inputs=[o, wts], grid=(K * 2304, 1, 1), threadgroup=(256, 1, 1), output_shapes=[(K, 2304)],
                 output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- depth mix
# Attention of Q learned queries over N depth sources of each row (N - 1 block states and the current partial), in one
# kernel: one threadgroup of 576 threads per row, 4 dims per thread; scores by fixed-order sums, softmax over the
# sources, weighted sum. out [K, Q, D].
def _make_mix(N: int, Q: int):
    names = [f"b{i}" for i in range(N)]
    load = "\n".join(f"    float4 v{i} = *((const device float4*)({n} + row * 2304 + d4));" for i, n in enumerate(names))
    dots = "\n".join(f"    float s{i}_{j} = dot4(v{i}, *((const device float4*)(qs + {j} * 2304 + d4)));" for i in range(N) for j in range(Q))
    red = "\n".join(f"    s{i}_{j} = tgsum(s{i}_{j}, buf + {(i * Q + j) * 18}, lane, sg);" for i in range(N) for j in range(Q))
    outs = ""
    for j in range(Q):
        outs += f"    {{ float m = s0_{j};\n"
        for i in range(1, N):
            outs += f"      m = max(m, s{i}_{j});\n"
        for i in range(N):
            outs += f"      float e{i} = metal::precise::exp((s{i}_{j} - m) * SCALE);\n"
        outs += "      float z = e0" + "".join(f" + e{i}" for i in range(1, N)) + ";\n"
        outs += "      float4 o = v0 * (e0 / z);\n"
        for i in range(1, N):
            outs += f"      o = fma(v{i}, float4(e{i} / z), o);\n"
        outs += f"      *((device float4*)(out + (row * {Q} + {j}) * 2304 + d4)) = o; }}\n"
    src = f"""
    constexpr float SCALE = 0.020833333333333332f;      // 2304 ^ -0.5
    uint row = threadgroup_position_in_grid.x;
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint d4 = tid * 4;
    threadgroup float buf[{N * Q * 18}];
{load}
{dots}
{red}
{outs}
"""
    hdr = """
inline float dot4(float4 a, float4 b) { float4 p = a * b; return (p.x + p.y) + (p.z + p.w); }
// the sum of v over the 576 threads of the group: simdgroup sums, then the 18 partials in order
inline float tgsum(float v, threadgroup float* buf, uint lane, uint sg) {
    float s = simd_sum(v);
    if (lane == 0) buf[sg] = s;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float t = 0.0f;
    for (int i = 0; i < 18; i++) t += buf[i];
    return t;
}
"""
    return mx.fast.metal_kernel(name=f"mk_mix_{N}_{Q}", input_names=names + ["qs"], output_names=["out"], source=src, header=hdr)


_mix = {}


def mix(sources: list, queries: mx.array) -> mx.array:
    """sources: N arrays float32 [K, 2304]; queries float32 [Q, 2304] -> float32 [K, Q, 2304]."""
    N, Q, K = len(sources), queries.shape[0], sources[0].shape[0]
    k = _mix.get((N, Q)) or _mix.setdefault((N, Q), _make_mix(N, Q))
    return k(inputs=list(sources) + [queries], grid=(K * 576, 1, 1), threadgroup=(576, 1, 1), output_shapes=[(K, Q, 2304)],
             output_dtypes=[mx.float32])[0]
