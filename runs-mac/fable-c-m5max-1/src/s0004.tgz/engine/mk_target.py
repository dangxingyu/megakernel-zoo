"""Inkling-2-Mini's text model as one K-row pass (K consecutive positions of one sequence), written on MLX arrays and the
kernels of kernels.py. K = 1 is the decode step; K = 2..8 is the verify pass of track C. The weights stay in the stored
formats (NVFP4 / MXFP8 expert codes and scales as stored, BF16 everything else).
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import mlx.core as mx

import mk_kernels as kn

F32 = mx.float32
EPS = 1e-6
import os
ROUND = os.environ.get("MK_ROUND", "0") == "1"
COMPILE = os.environ.get("MK_COMPILE", "1") == "1"
EXP2 = os.environ.get("MK_EXP2", "1") == "1"
MSLOT = [int(v) for v in os.environ.get("MK_M", "1,2,2,2,2,2,2,2").split(",")]     # pairs per expert slot, by rows K
RUP, RDN = int(os.environ.get("MK_RUP", "2")), int(os.environ.get("MK_RDN", "2"))


def rms(x, w=None):
    return mx.fast.rms_norm(x, w, EPS)


def depth_mix(blocks: list, partial, query):
    """Attention of learned queries over the depth sources of each row. blocks: list of [K, D]; partial [K, D];
    query [D] -> [K, D], or [Q, D] -> list of Q arrays [K, D]."""
    if query.ndim == 1:
        return kn.mix(blocks + [partial], query[None])[:, 0]
    o = kn.mix(blocks + [partial], query)
    return [o[:, j] for j in range(query.shape[0])]


def l2clip(x, scale, thr):
    """x [K, H, d] float32."""
    s = x * scale if scale is not None else x
    n = mx.sqrt((s * s).sum(axis=-1, keepdims=True))
    return s * mx.minimum(thr / (n + 1e-6), 1.0)


class Target:
    def __init__(self, model_dir: str, max_context: int):
        cfg = json.loads((Path(model_dir) / "config.json").read_text())
        self.tc = tc = cfg["text_config"]
        assert tc["hidden_size"] == 2304 and tc["num_attention_heads"] == 24 and tc["num_key_value_heads"] == 8
        assert tc["n_routed_experts"] == 128 and tc["num_experts_per_tok"] == 8 and tc["sconv_kernel_size"] == 4
        assert tc["d_rel"] == 16 and tc["rel_extent"] == 1024 and tc["sliding_window_size"] == 1024
        assert tc["mlp_gate_softcap"] == 4.0 and tc["mlp_up_softcap"] == 25.0 and tc["route_scale"] == 8.0
        self.T = int(max_context) + 8
        assert self.T + 8 <= 7168 and self.T < tc["log_scaling_n_floor"], "attention kernel: context too long"
        self.smax = self.T + 8
        self.vocab = tc["unpadded_vocab_size"]
        self.cap = tc["final_logit_softcapping"]
        self.local = set(tc["local_layer_ids"])
        lc = tc["loop_config"]
        self.core = range(lc["core_start"], lc["core_end"])
        self.passes = lc["num_passes"]
        self.qthr, self.rthr = tc["qk_l2_clip_threshold"], tc["rel_l2_clip_threshold"]
        w = mx.load(str(Path(model_dir) / "model-00001-of-00001.safetensors"))
        g = lambda k: w["model.llm." + k]  # noqa: E731
        u16 = lambda a: a.view(mx.uint16)  # noqa: E731
        self.embed = g("embed.weight")
        self.embed_norm = g("embed_norm.weight").astype(F32)
        self.unembed = u16(g("unembed.weight"))
        self.norm = g("norm.weight").astype(F32)
        self.out_query = g("attn_res.output_query")
        cq = g("middle_cycle_cross_pass_queries").reshape(-1, 2, 2304)
        ckv = g("middle_cycle_cross_pass_kv_queries").reshape(-1, 2, 2304)
        self.msg_query = mx.concatenate([cq[:, :1], ckv, cq[:, 1:]], axis=1)     # [12, 4, D]: q, k, v, mlp
        self.layers = []
        for i in range(tc["num_hidden_layers"]):
            p = f"layers.{i}."
            L = {"full": i not in self.local, "boundary": i % tc["n_layers_per_attn_res_block"] == 0, "i": i}
            L["qgrs"] = u16(mx.concatenate([g(p + "attn.wq_du.weight"), g(p + "attn.gate_attn.weight"),
                                            g(p + "attn.wr_du.weight"), g(p + "attn.attn_sink_proj.weight")]))
            if L["full"]:
                L["wk"] = u16(mx.concatenate([g(p + "attn.wk_dv.weight"), g(p + "attn.k_sconv.weight_proj")]))
                L["wv"] = u16(mx.concatenate([g(p + "attn.wv_dv.weight"), g(p + "attn.v_sconv.weight_proj")]))
                # static [4 lags, 1024] -> [8 heads, 128, 4 lags] as the reference; kept as [4, 1024]
                L["k_static"] = g(p + "attn.k_sconv.static_w").astype(F32)
                L["v_static"] = g(p + "attn.v_sconv.static_w").astype(F32)
                L["qn"], L["kn"], L["vn"] = (g(p + f"{c}_input_norm.weight").astype(F32) for c in "qkv")
            else:
                L["wk"] = u16(g(p + "attn.wk_dv.weight"))
                L["wv"] = u16(g(p + "attn.wv_dv.weight"))
                L["k_conv"] = g(p + "attn.k_sconv.weight").astype(F32)[:, 0, :].T    # [4, 1024], tap j <-> window[t + j]
                L["v_conv"] = g(p + "attn.v_sconv.weight").astype(F32)[:, 0, :].T
                L["an"] = g(p + "attn_norm.weight").astype(F32)
            L["wo"] = u16(g(p + "attn.wo_ud.weight"))
            L["q_scale"] = g(p + "attn.q_l2_clip.scale").astype(F32)
            L["r_scale"] = g(p + "attn.rel_l2_clip.scale").astype(F32)
            L["proj"] = g(p + "attn.rel_logits_proj.proj").astype(F32)
            L["a_conv"] = g(p + "attn_sconv.weight").astype(F32)[:, 0, :].T
            L["m_conv"] = g(p + "mlp_sconv.weight").astype(F32)[:, 0, :].T
            L["mn"] = g(p + "mlp_norm.weight").astype(F32)
            L["router"] = u16(g(p + "mlp.gate.weight"))
            L["rbias"] = g(p + "mlp.gate.bias")
            e = p + "mlp.experts."
            if ("model.llm." + e + "w13_weight_amax") in w:
                L["fmt"] = "nv"
                L["g13"] = g(e + "w13_weight_amax") / g(e + "w13_weight_outer_scale_denominator")
                L["g2"] = g(e + "w2_weight_amax") / g(e + "w2_weight_outer_scale_denominator")
            else:
                L["fmt"] = "mx"
                L["g13"] = L["g2"] = mx.ones((128,), dtype=F32)
            L["w13"], L["s13"], L["w2"], L["s2"] = (g(e + n) for n in ("w13_weight", "w13_weight_scale", "w2_weight", "w2_weight_scale"))
            if i > 0:
                L["aq"] = g(f"attn_res.attn_queries.{i - 1}")
            L["mq"] = g(f"attn_res.mlp_queries.{i}")
            if i in self.core:
                for c, nm in (("q", "attn"), ("k", "k"), ("v", "v"), ("m", "mlp")):
                    cp = p + f"controllers.{nm}."
                    L["c" + c + "_down"] = u16(g(cp + "down_weight"))
                    L["c" + c + "_fg"] = mx.concatenate([g(cp + "forget_weight"), g(cp + "gain_weight")]).astype(F32)
            self.layers.append(L)
        keep = [self.embed, self.embed_norm, self.unembed, self.norm, self.out_query, self.msg_query]
        for L in self.layers:
            keep += [v for v in L.values() if isinstance(v, mx.array)]
        mx.eval(keep)
        del w
        # the 48 layer applications
        cs, ce = self.core.start, self.core.stop
        self.apps = list(range(cs)) + list(self.core) * self.passes + list(range(ce, len(self.layers)))
        self.napp = len(self.apps)
        self._fns = {}
        self.reset()

    # ---------------------------------------------------------------------------------------------- state
    def reset(self):
        T = self.T
        z16 = lambda *s: mx.zeros(s, dtype=mx.uint16)  # noqa: E731
        self.kc = [z16(T, 1024) for _ in range(self.napp)]
        self.vc = [z16(T, 1024) for _ in range(self.napp)]
        # conv windows per application: k, v (1024), post-attention, post-MLP (2304): the last 3 inputs
        self.cw = [[mx.zeros((3, d), dtype=F32) for d in (1024, 1024, 2304, 2304)] for _ in range(self.napp)]
        self.pos = 0
        self.pending = None

    def commit(self, n_acc: int):
        """Keep the first n_acc rows of the last pass (K/V rows, conv windows) and advance."""
        knew, vnew, wins, K = self.pending
        p = self.pos
        for a in range(self.napp):
            self.kc[a][p:p + n_acc] = knew[a][:n_acc] if n_acc < K else knew[a]
            self.vc[a][p:p + n_acc] = vnew[a][:n_acc] if n_acc < K else vnew[a]
            self.cw[a] = [wd[n_acc:n_acc + 3] for wd in wins[a]]
        self.pos = p + n_acc
        self.pending = None

    # ---------------------------------------------------------------------------------------------- pieces
    @staticmethod
    def _sconv(x, state, taps):
        """Static depthwise conv over the last 4 inputs + residual. x [K, C] float32 (bf16 values), state [3, C],
        taps [4, C] (tap j multiplies window[t + j]; j = 3 is the current input)."""
        K = x.shape[0]
        win = mx.concatenate([state, x])
        out = win[0:K] * taps[0] + win[1:K + 1] * taps[1] + win[2:K + 2] * taps[2] + win[3:K + 3] * taps[3]
        return (out + x) * (1.0 / math.sqrt(5.0)), win

    @staticmethod
    def _dconv(x, dyn, state, static):
        """Dynamic conv of the full-attention layers. x [K, 1024]; dyn [K, 32] (8 heads x 4 lags); static [4 lags, 1024];
        lag 0 is the current input."""
        K = x.shape[0]
        win = mx.concatenate([state, x])
        d = dyn.reshape(K, 8, 1, 4)
        out = None
        for lag in range(4):
            wl = static[lag].reshape(1, 8, 128) + d[..., lag]                 # [K, 8, 128]
            t = win[3 - lag:3 - lag + K].reshape(K, 8, 128) * wl
            out = t if out is None else out + t
        return (out.reshape(K, 1024) + x) * (1.0 / 3.0), win

    @staticmethod
    def _msg_gate(L, c, h, m):
        st = mx.concatenate([rms(h), rms(m)], axis=-1)
        dn = kn.gemv(L["c" + c + "_down"], kn.bits(st))                      # [K, 64]
        fg = mx.tanh(kn.gemv_small(L["c" + c + "_fg"], dn))                  # [K, 4608]
        return (1 - fg[:, :2304]) * h + fg[:, 2304:] * m

    def _layer(self, st, L, hidden, blocks, msgs, meta, K, knew_l, vnew_l, wins_l):
        """hidden float32 [K, D] holding bf16 values; blocks: list of float32 [K, D]."""
        normed_res = rms(hidden)
        kc_a, vc_a, cw = st
        ai = depth_mix(blocks, normed_res, L["aq"]) if L["i"] > 0 else None
        if L["full"]:
            qs, ks, vs = ai
            if msgs is not None:
                qs, ks, vs = (self._msg_gate(L, c, s, msgs[j]) for j, (c, s) in enumerate((("q", qs), ("k", ks), ("v", vs))))
            hq, hk, hv = kn.bits(rms(qs, L["qn"])), kn.bits(rms(ks, L["kn"])), kn.bits(rms(vs, L["vn"]))
        else:
            hs = ai if ai is not None else hidden
            if msgs is None:
                hq = hk = hv = kn.bits(rms(hs, L["an"]))
            else:
                hq, hk, hv = (kn.bits(rms(self._msg_gate(L, c, hs, msgs[j]), L["an"])) for j, c in enumerate("qkv"))
        o = kn.gemv(L["qgrs"], hq)                                            # [K, 3072 + 3072 + 384 + 24]
        q, gate, r, sinks = o[:, :3072], o[:, 3072:6144], o[:, 6144:6528], o[:, 6528:]
        kk = kn.gemv(L["wk"], hk)
        vv = kn.gemv(L["wv"], hv)
        bfr = (lambda t: t.astype(mx.bfloat16).astype(F32)) if ROUND else (lambda t: t)
        if L["full"]:
            kx, w0 = self._dconv(bfr(kk[:, :1024]), bfr(kk[:, 1024:]), cw[0], L["k_static"])
            vx, w1 = self._dconv(bfr(vv[:, :1024]), bfr(vv[:, 1024:]), cw[1], L["v_static"])
        else:
            kx, w0 = self._sconv(bfr(kk), cw[0], L["k_conv"])
            vx, w1 = self._sconv(bfr(vv), cw[1], L["v_conv"])
        q = l2clip(q.reshape(K, 24, 128), L["q_scale"], self.qthr)
        kx = l2clip(bfr(kx).reshape(K, 8, 128), None, self.qthr)
        vx = rms(bfr(vx).reshape(K, 8, 128))
        rel = l2clip(bfr(r).reshape(K, 24, 16), L["r_scale"], self.rthr)
        knew = kn.bits(kx.reshape(K, 1024))
        vnew = kn.bits(vx.reshape(K, 1024))
        att = kn.attention(bfr(q), kc_a, vc_a, knew, vnew, bfr(rel), L["proj"], bfr(sinks),
                           meta[0 if L["full"] else 1], self.smax)
        att = att * mx.sigmoid(bfr(gate))
        ao = bfr(kn.gemv(L["wo"], kn.bits(att)))
        h, w2 = self._sconv(ao, cw[2], L["a_conv"])
        h = bfr(h)
        if L["boundary"]:
            blocks = blocks + [normed_res]
        else:
            h = hidden + h
        residual = h
        x = depth_mix(blocks, rms(h), L["mq"])
        if msgs is not None:
            x = self._msg_gate(L, "m", x, msgs[3])
        x16 = kn.bits(rms(x, L["mn"]))
        idx, wts = kn.router(kn.gemv(L["router"], x16), L["rbias"])
        if EXP2:
            y = kn.experts2(L["fmt"], L["w13"], L["s13"], L["g13"], L["w2"], L["s2"], L["g2"], x16, idx, wts,
                            MSLOT[min(K, len(MSLOT)) - 1], RUP, RDN)
        else:
            y = kn.experts(L["fmt"], L["w13"], L["s13"], L["g13"], L["w2"], L["s2"], L["g2"], x16, idx, wts)
        y, w3 = self._sconv(bfr(y), cw[3], L["m_conv"])
        out = bfr(residual + bfr(y))
        knew_l.append(knew); vnew_l.append(vnew); wins_l.append([w0, w1, w2, w3])
        return out, blocks

    # ---------------------------------------------------------------------------------------------- the pass
    def _pure(self, tokens, m_full, m_loc, kc, vc, cw):
        """The pass as a pure function of (tokens, position, state): what mx.compile traces, once per K."""
        K = tokens.shape[0]
        meta = (m_full, m_loc)
        h = rms(self.embed[tokens].astype(F32), self.embed_norm)
        knew, vnew, wins, feats = [], [], [], []
        blocks = []
        cs, ce = self.core.start, self.core.stop
        a = 0
        for i in range(cs):
            if a == 5: feats.append(h)
            h, blocks = self._layer((kc[a], vc[a], cw[a]), self.layers[i], h, blocks, None, meta, K, knew, vnew, wins); a += 1
        pre_h, pre_blocks = h, blocks
        for lp in range(self.passes):
            if lp > 0:
                bank_blocks, bank_part = blocks[len(pre_blocks) + 1:], rms(h)
                h, blocks = pre_h, pre_blocks
            for j, i in enumerate(self.core):
                msgs = depth_mix(bank_blocks, bank_part, self.msg_query[j]) if lp > 0 else None
                if a in (23, 41): feats.append(h)
                h, blocks = self._layer((kc[a], vc[a], cw[a]), self.layers[i], h, blocks, msgs, meta, K, knew, vnew, wins); a += 1
        for i in range(ce, len(self.layers)):
            h, blocks = self._layer((kc[a], vc[a], cw[a]), self.layers[i], h, blocks, None, meta, K, knew, vnew, wins); a += 1
        x = depth_mix(blocks, rms(h), self.out_query)
        fo16 = kn.bits(rms(x, self.norm))
        z = kn.gemv(self.unembed, fo16, self.vocab)
        logits = mx.tanh(z * (1.0 / self.cap)) * self.cap
        feats.append(fo16.view(mx.float16).astype(F32))
        return logits, feats, knew, vnew, wins

    def forward(self, tokens: mx.array, want_feats: bool = False):
        """tokens int32 [K] at positions pos .. pos + K - 1 -> logits float32 [K, vocab] (lazy). The pass is pending
        until commit(n)."""
        K = tokens.shape[0]
        assert self.pos + K <= self.T
        m_full = mx.array([self.pos, 0], dtype=mx.int32)
        m_loc = mx.array([self.pos, 1024], dtype=mx.int32)
        fn = self._fns.get(K) if COMPILE else self._pure
        if fn is None:
            fn = self._fns[K] = mx.compile(self._pure)
        logits, feats, knew, vnew, wins = fn(tokens, m_full, m_loc, self.kc, self.vc, self.cw)
        self.pending = (knew, vnew, wins, K)
        if want_feats:
            return logits, feats
        return logits
