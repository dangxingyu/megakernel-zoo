"""Metal kernels of the engine (compiled at run time through mx.fast.metal_kernel).

Every kernel that sums over a weight row does it per (row of the pass, output) in an order that does not depend on how
many rows the pass has: explicit fma, default ("safe") math mode, simd_sum at the end. A K-row verify pass therefore
gives each row the bits the one-row step gives it (tests/rowexact.py).
"""
from __future__ import annotations

import os

import os

import mlx.core as mx

# NVFP4 expert weights rounded to BF16 after dequantization (what a loader that materializes BF16 tensors computes)
W16 = os.environ.get("MK_W16", "1") == "1"

_BF = "as_type<float4>(uint4(*((const device vec<ushort,4>*)(%s))) << 16)"


def bf4(expr: str) -> str:
    """4 BF16 weights at expr as float4."""
    return _BF % expr


def hf4(expr: str) -> str:
    """4 activations at expr (IEEE half bits in a uint16 buffer) as float4."""
    return "float4(*((const device half4*)(%s)))" % expr


# ------------------------------------------------------------------------------------------------- dense BF16 GEMV
# out[k, n] = sum_d W[n, d] x[k, d]; W bf16 bits [N, D], x bf16 bits [K, D], D % 128 == 0. One simdgroup per output.
_GEMV = f"""
    uint n = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    float4 acc[K];
    for (int k = 0; k < K; k++) acc[k] = float4(0.0f);
    const device ushort* wr = w + size_t(n) * D;
    for (int i = 0; i < D / 128; i++) {{
        int idx = (i * 32 + lane) * 4;
        float4 wf = {bf4('wr + idx')};
        for (int k = 0; k < K; k++) {{
            float4 xv = {hf4('x + k * D + idx')};
            acc[k] = fma(wf, xv, acc[k]);
        }}
    }}
    for (int k = 0; k < K; k++) {{
        float4 a = acc[k];
        float s = simd_sum((a.x + a.y) + (a.z + a.w));
        if (lane == 0) out[k * N + n] = s;
    }}
"""
_gemv = mx.fast.metal_kernel(name="mk_gemv", input_names=["w", "x"], output_names=["out"], source=_GEMV)


def gemv(w16: mx.array, x16: mx.array, n_out: int | None = None) -> mx.array:
    """w16 uint16 [N, D] (bf16 bits), x16 uint16 [K, D] (bf16 bits) -> float32 [K, N]."""
    N, D = w16.shape
    if n_out is not None:
        N = n_out
    K = x16.shape[0]
    return _gemv(inputs=[w16, x16], template=[("D", D), ("N", N), ("K", K)], grid=(N * 32, 1, 1),
                 threadgroup=(256 if N % 8 == 0 else 32, 1, 1), output_shapes=[(K, N)], output_dtypes=[mx.float32])[0]


def bits(x: mx.array) -> mx.array:
    """float -> IEEE half bits: the activation format the kernels read (11 significant bits; BF16 has 8)."""
    return x.astype(mx.float16).view(mx.uint16)


# small float GEMV: out[k, n] = sum_d W[n, d] x[k, d], any D, one thread per output
_GEMV_S = """
    uint g = thread_position_in_grid.x;
    uint k = g / N, n = g % N;
    float4 acc = float4(0.0f);
    for (int d = 0; d < D; d += 4) acc = fma(*((const device float4*)(w + n * D + d)), *((const device float4*)(x + k * D + d)), acc);
    out[g] = (acc.x + acc.y) + (acc.z + acc.w);
"""
_gemv_s = mx.fast.metal_kernel(name="mk_gemv_small", input_names=["w", "x"], output_names=["out"], source=_GEMV_S)


def gemv_small(w: mx.array, x: mx.array) -> mx.array:
    N, D = w.shape
    K = x.shape[0]
    return _gemv_s(inputs=[w, x], template=[("D", D), ("N", N)], grid=(K * N, 1, 1), threadgroup=(32, 1, 1),
                   output_shapes=[(K, N)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- router
_ROUTER = """
    uint row = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    float sc[4];
    float bi[4];
    for (int i = 0; i < 4; i++) {
        uint e = lane + 32 * i;
        float x = logits[row * 128 + e];
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(x)));
        sc[i] = x < 0 ? y : 1.0f - y;
        bi[i] = sc[i] + bias[e];
    }
    float wsel[8];
    uint esel[8];
    for (int k = 0; k < 8; k++) {
        float best = -INFINITY;
        uint be = 128;
        for (int i = 0; i < 4; i++) {
            if (bi[i] > best) { best = bi[i]; be = lane + 32 * i; }
        }
        float top = simd_max(best);
        uint win = simd_min(best == top ? be : 128u);
        float s = 0.0f;
        for (int i = 0; i < 4; i++) {
            if (lane + 32 * i == win) { s = sc[i]; bi[i] = -INFINITY; }
        }
        wsel[k] = simd_sum(s);
        esel[k] = win;
    }
    float total = 0.0f;
    for (int k = 0; k < 8; k++) total += wsel[k];
    if (lane == 0) {
        for (int k = 0; k < 8; k++) {
            idx[row * 8 + k] = esel[k];
            wts[row * 8 + k] = wsel[k] / (total + 1e-20f) * 8.0f;
        }
    }
"""
_router = mx.fast.metal_kernel(name="mk_router", input_names=["logits", "bias"], output_names=["idx", "wts"], source=_ROUTER)


def router(logits: mx.array, bias: mx.array):
    K = logits.shape[0]
    return _router(inputs=[logits, bias], grid=(K * 32, 1, 1), threadgroup=(32, 1, 1), output_shapes=[(K, 8), (K, 8)],
                   output_dtypes=[mx.uint32, mx.float32])


# ------------------------------------------------------------------------------------------------- experts
def _e4m3(b: int) -> float:
    s = -1.0 if b & 128 else 1.0
    e, m = (b >> 3) & 15, b & 7
    return s * (m / 8 * 2.0 ** -6 if e == 0 else (1 + m / 8) * 2.0 ** (e - 7))


_HDR = ("constant float E2M1[16] = {0.0f, 0.5f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f, 6.0f, -0.0f, -0.5f, -1.0f, -1.5f, -2.0f, -3.0f, -4.0f, -6.0f};\n"
        "constant float E4M3[256] = {" + ", ".join(repr(float(_e4m3(b) if (b & 127) != 127 else 0.0)) + "f" for b in range(256)) + "};\n"
        """
inline float4 nv4(uint c) { return float4(E2M1[c & 15u], E2M1[(c >> 4) & 15u], E2M1[(c >> 8) & 15u], E2M1[(c >> 12) & 15u]); }
inline float4 mx4(uint c) { return float4(E4M3[c & 255u], E4M3[(c >> 8) & 255u], E4M3[(c >> 16) & 255u], E4M3[c >> 24]); }
inline float hsum(float4 a) { return (a.x + a.y) + (a.z + a.w); }
// NVFP4 weights as BF16 values (MK_W16): w = bf16(E2M1 x scale). E2M1 magnitudes are 2^k x {1, 1.5}, and rounding
// commutes with 2^k, so a group needs two rounded scales: A = bf16(scale) for {0.5, 1, 2, 4}, B = bf16(1.5 scale) for
// {1.5, 3, 6}.
constant float E2A[16] = {0.0f, 0.5f, 1.0f, 0.0f, 2.0f, 0.0f, 4.0f, 0.0f, -0.0f, -0.5f, -1.0f, -0.0f, -2.0f, -0.0f, -4.0f, -0.0f};
constant float E2B[16] = {0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 2.0f, 0.0f, 4.0f, -0.0f, -0.0f, -0.0f, -1.0f, -0.0f, -2.0f, -0.0f, -4.0f};
inline float4 nva4(uint c) { return float4(E2A[c & 15u], E2A[(c >> 4) & 15u], E2A[(c >> 8) & 15u], E2A[(c >> 12) & 15u]); }
inline float4 nvb4(uint c) { return float4(E2B[c & 15u], E2B[(c >> 4) & 15u], E2B[(c >> 8) & 15u], E2B[(c >> 12) & 15u]); }
inline float bf16r(float f) {
    uint b = as_type<uint>(f);
    b += 0x7FFFu + ((b >> 16) & 1u);
    return as_type<float>(b & 0xFFFF0000u);
}
// one NVFP4 group: 16 elements (8 code bytes), x16 = 16 bf16 inputs
inline float nvgroup(const device uchar* cp, float4 x0, float4 x1, float4 x2, float4 x3) {
    uint c0 = *((const device uint*)cp);
    uint c1 = *((const device uint*)(cp + 4));
    float4 a = nv4(c0) * x0;
    a = fma(nv4(c0 >> 16), x1, a);
    a = fma(nv4(c1), x2, a);
    a = fma(nv4(c1 >> 16), x3, a);
    return hsum(a);
}
// one MXFP8 group: 32 elements (32 code bytes)
inline float mxgroup(const device uchar* cp, const device ushort* xp) {
    float4 a = float4(0.0f);
    for (int j = 0; j < 8; j++) {
        uint c = *((const device uint*)(cp + 4 * j));
        float4 xv = float4(*((const device half4*)(xp + 4 * j)));
        a = fma(mx4(c), xv, a);
    }
    return hsum(a);
}
inline ushort to_bf16(float f) {       // (name kept) the activation format between the two expert matrices: IEEE half bits
    return as_type<ushort>(half(f));
}
""")


def _dot_src(fmt: str, D: int, acc: str, cp: str, sp: str, xp: str) -> str:
    """Statements that add one lane's share of the dot of a quantized row (codes at cp, scales at sp) with the bf16 row
    at xp to `acc` (already scaled per group)."""
    if fmt == "nv":
        groups = D // 16
        it = (groups + 31) // 32
        return f"""
        for (int i = 0; i < {it}; i++) {{
            int g = i * 32 + int(lane);
            if (g < {groups}) {{
                const device ushort* xq = {xp} + g * 16;
                float4 x0 = {hf4('xq')};
                float4 x1 = {hf4('xq + 4')};
                float4 x2 = {hf4('xq + 8')};
                float4 x3 = {hf4('xq + 12')};
                {acc} = fma(nvgroup({cp} + g * 8, x0, x1, x2, x3), E4M3[({sp})[g]], {acc});
            }}
        }}"""
    groups = D // 32
    it = (groups + 31) // 32
    return f"""
        for (int i = 0; i < {it}; i++) {{
            int g = i * 32 + int(lane);
            if (g < {groups}) {{
                {acc} = fma(mxgroup({cp} + g * 32, {xp} + g * 32), as_type<float>(uint(({sp})[g]) << 23), {acc});
            }}
        }}"""


def _make_up(fmt: str):
    D, cb, sb = 2304, (1152 if fmt == "nv" else 2304), (144 if fmt == "nv" else 72)
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint p = g0 / 1152, m = g0 % 1152;
    uint e = idx[p];
    const device ushort* xr = x + (p / 8) * {D};
    const device uchar* c0 = codes + (size_t(e) * 2304 + 2 * m) * {cb};
    const device uchar* s0 = scales + (size_t(e) * 2304 + 2 * m) * {sb};
    float a0 = 0.0f, a1 = 0.0f;
    {_dot_src(fmt, D, 'a0', 'c0', 's0', 'xr')}
    {_dot_src(fmt, D, 'a1', f'(c0 + {cb})', f'(s0 + {sb})', 'xr')}
    float gs = gsc[e];
    float gt = simd_sum(a0) * gs;
    float up = simd_sum(a1) * gs;
    if (lane == 0) {{
        float gc = metal::precise::tanh(gt * 0.25f) * 4.0f;
        float uc = metal::precise::tanh(up * 0.04f) * 25.0f;
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(gt)));
        float sg = gt < 0 ? y : 1.0f - y;
        out[g0] = to_bf16(gc * sg * uc);
    }}
"""
    return mx.fast.metal_kernel(name=f"mk_up_{fmt}", input_names=["codes", "scales", "gsc", "x", "idx"], output_names=["out"],
                                source=src, header=_HDR)


def _make_down(fmt: str):
    D, cb, sb = 1152, (576 if fmt == "nv" else 1152), (72 if fmt == "nv" else 36)
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint row = g0 / 2304, n = g0 % 2304;
    float y = 0.0f;
    for (int j = 0; j < 8; j++) {{
        uint p = row * 8 + j;
        uint e = idx[p];
        const device ushort* xr = h + p * {D};
        const device uchar* c0 = codes + (size_t(e) * 2304 + n) * {cb};
        const device uchar* s0 = scales + (size_t(e) * 2304 + n) * {sb};
        float a0 = 0.0f;
        {_dot_src(fmt, D, 'a0', 'c0', 's0', 'xr')}
        y = fma(simd_sum(a0) * gsc[e], wts[p], y);
    }}
    if (lane == 0) out[g0] = y;
"""
    return mx.fast.metal_kernel(name=f"mk_down_{fmt}", input_names=["codes", "scales", "gsc", "h", "idx", "wts"],
                                output_names=["out"], source=src, header=_HDR)


_up = {f: _make_up(f) for f in ("nv", "mx")}
_down = {f: _make_down(f) for f in ("nv", "mx")}


def experts(fmt: str, w13, s13, g13, w2, s2, g2, x16: mx.array, idx: mx.array, wts: mx.array) -> mx.array:
    """x16 uint16 [K, 2304] (bf16 bits), idx uint32 [K, 8], wts float32 [K, 8] -> float32 [K, 2304]: the weighted sum of
    the 8 chosen experts (gate/up rows interleaved, soft-capped SwiGLU, BF16 between the two matrices)."""
    K = x16.shape[0]
    h = _up[fmt](inputs=[w13, s13, g13, x16, idx], grid=(K * 8 * 1152 * 32, 1, 1), threadgroup=(256, 1, 1),
                 output_shapes=[(K * 8, 1152)], output_dtypes=[mx.uint16])[0]
    return _down[fmt](inputs=[w2, s2, g2, h, idx, wts], grid=(K * 2304 * 32, 1, 1), threadgroup=(256, 1, 1),
                      output_shapes=[(K, 2304)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- attention
# One threadgroup per (row, head). Keys at positions < p0 come from the cache (bf16 bits [T, 1024]), positions p0.. from
# the rows of this pass (knew / vnew [K, 1024]). The relative bias is rel . proj[:, distance] for distance < 1024; the
# sink is one extra logit with a zero value.
# The arithmetic is laid out on VT "virtual" threads per (row, head) group (VT / 32 simdgroups of 32 lanes): scores per
# key, the softmax sums per virtual simdgroup, the value sum as VT / 32 chains of keys (key mod VT / 32) x 32 lanes of 4
# dims. A real threadgroup has TG <= VT threads and each real thread runs VT / TG virtual ones with the same lane, so
# the bits do not depend on TG: small passes use TG = VT (short chains: a one-row pass at position 1150 is 1.5 ms
# faster with 1024 threads than with 256), wide passes TG = 256 (fewer threads to launch).
_ATT = f"""
    constexpr int NJ = VT / TG;
    constexpr int NSG = TG / 32;
    constexpr int NC = VT / 32;
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint grp = threadgroup_position_in_grid.x;
    int row = grp / 24, head = grp % 24, kvh = head / 3;
    int p0 = meta[0];
    int base = meta[2];
    int pos = p0 + row;
    int first = meta[1] > 0 ? max(0, pos - meta[1] + 1) : 0;
    threadgroup float sc[SMAX];
    threadgroup float red[NC];
    threadgroup float4 part[VT];
    const device float* qp = q + grp * 128;
    const device float* rp = rel + grp * 16;
    float lmax = -INFINITY;
    for (int j = 0; j < NJ; j++) {{
        int vt = (int(sg) + NSG * j) * 32 + int(lane);
        for (int s = first + vt; s <= pos; s += VT) {{
            const device ushort* kp = (s < base ? kc + (size_t(app[0]) * TT + s) * 1024 : (s < p0 ? krec + (size_t(app[0]) * RR + (s - base)) * 1024 : knew + (s - p0) * 1024)) + kvh * 128;
            float4 a = float4(0.0f);
            for (int jj = 0; jj < 32; jj++) {{
                float4 kf = {hf4('kp + 4 * jj')};
                a = fma(kf, *((const device float4*)(qp + 4 * jj)), a);
            }}
            float v = ((a.x + a.y) + (a.z + a.w)) * 0.08838834764831845f;
            int d = pos - s;
            if (d < 1024) {{
                float b = 0.0f;
                for (int r = 0; r < 16; r++) b = fma(rp[r], proj[r * 1024 + d], b);
                v += b;
            }}
            sc[s - first] = v;
            lmax = max(lmax, v);
        }}
    }}
    float m = simd_max(lmax);
    if (lane == 0) red[sg] = m;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float sink = sinks[grp];
    m = sink;
    for (int i = 0; i < NSG; i++) m = max(m, red[i]);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (int j = 0; j < NJ; j++) {{
        int vsg = int(sg) + NSG * j;
        float lsum = 0.0f;
        for (int s = first + vsg * 32 + int(lane); s <= pos; s += VT) {{
            float pr = metal::precise::exp(sc[s - first] - m);
            sc[s - first] = pr;
            lsum += pr;
        }}
        float ss = simd_sum(lsum);
        if (lane == 0) red[vsg] = ss;
    }}
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float tot = metal::precise::exp(sink - m);
    for (int i = 0; i < NC; i++) tot += red[i];
    int d4 = int(lane) * 4;
    for (int j = 0; j < NJ; j++) {{
        int c = int(sg) + NSG * j;
        float4 acc = float4(0.0f);
        for (int s = first + c; s <= pos; s += NC) {{
            const device ushort* vp = (s < base ? vc + (size_t(app[0]) * TT + s) * 1024 : (s < p0 ? vrec + (size_t(app[0]) * RR + (s - base)) * 1024 : vnew + (s - p0) * 1024)) + kvh * 128 + d4;
            float4 vf = {hf4('vp')};
            acc = fma(vf, float4(sc[s - first]), acc);
        }}
        part[c * 32 + int(lane)] = acc;
    }}
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (tid < 32) {{
        float4 o = part[tid];
        for (int i = 1; i < NC; i++) o += part[i * 32 + tid];
        o = o / tot;
        GATE_WRITE
    }}
"""
_att = mx.fast.metal_kernel(name="mk_attention", input_names=["q", "kc", "vc", "krec", "vrec", "knew", "vnew", "rel", "proj", "sinks", "meta", "app"],
                            output_names=["out"], source=_ATT.replace("GATE_WRITE", "*((device float4*)(out + grp * 128 + d4)) = o;"))
# the same with the output gate folded in: out = half(att * sigmoid(gate)), the input of o_proj
_attg = mx.fast.metal_kernel(name="mk_attention_gate", input_names=["q", "kc", "vc", "krec", "vrec", "knew", "vnew", "rel", "proj", "sinks", "meta", "app", "gate"],
                             output_names=["out"], source=_ATT.replace("GATE_WRITE", """float4 gv = *((const device float4*)(gate + grp * 128 + d4));
        float4 sgm = 1.0f / (1.0f + metal::precise::exp(-gv));
        *((device half4*)(out + grp * 128 + d4)) = half4(o * sgm);"""))


def attention_gate(q, kc, vc, krec, vrec, knew, vnew, rel, proj, sinks, meta, app, gate, smax: int) -> mx.array:
    """As attention(); kc / vc uint16 [NAPP, T, 1024] and app int32 [1] = this application; gate float32 [K, 3072] ->
    uint16 (half bits) [K, 3072] = att * sigmoid(gate)."""
    K = q.shape[0]
    vt, atg = att_layout(K, smax)
    return _attg(inputs=[q, kc, vc, krec, vrec, knew, vnew, rel, proj, sinks, meta, app, gate],
                 template=[("SMAX", smax), ("TT", kc.shape[1]), ("RR", krec.shape[1]), ("VT", vt), ("TG", atg)], grid=(K * 24 * atg, 1, 1),
                 threadgroup=(atg, 1, 1), output_shapes=[(K, 3072)], output_dtypes=[mx.uint16])[0]


ATT_VT = int(os.environ.get("MK_ATT_VT", "1024"))
ATT_WIDE = int(os.environ.get("MK_ATT_WIDE", "8"))      # passes of at least this many rows use fewer real threads
ATT_WTG = int(os.environ.get("MK_ATT_WTG", "256"))


def att_layout(K: int, smax: int):
    """(virtual threads, real threads) of the attention kernel. The virtual layout fixes the bits; threadgroup memory
    (scores + VT partial sums) must stay under 32 KB, so very long contexts fall back to the 256 layout."""
    vt = ATT_VT if smax * 4 + ATT_VT * 16 + 256 <= 32000 else 256
    return vt, (vt if K < ATT_WIDE else min(vt, ATT_WTG))


def attention(q, kc, vc, knew, vnew, rel, proj, sinks, meta, smax: int) -> mx.array:
    """q float32 [K, 24, 128]; kc / vc uint16 [T, 1024]; knew / vnew uint16 [K, 1024]; rel float32 [K, 24, 16]; proj
    float32 [16, 1024]; sinks float32 [K, 24]; meta int32 [2] = (position of row 0, window or 0) -> float32 [K, 3072]."""
    K = q.shape[0]
    vt, atg = att_layout(K, smax)
    kc3, vc3 = (kc[None] if kc.ndim == 2 else kc), (vc[None] if vc.ndim == 2 else vc)
    meta3 = mx.concatenate([meta, meta[:1]])                     # base = p0: every earlier key from the big cache
    return _att(inputs=[q, kc3, vc3, kc3, vc3, knew, vnew, rel, proj, sinks, meta3,
                        mx.zeros((1,), dtype=mx.int32)], template=[("SMAX", smax), ("TT", kc3.shape[1]), ("RR", kc3.shape[1]), ("VT", vt), ("TG", atg)], grid=(K * 24 * atg, 1, 1),
                threadgroup=(atg, 1, 1), output_shapes=[(K, 3072)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- experts, shared reads
# A verify pass of K rows chooses 8K (row, expert) pairs but far fewer distinct experts. The plan kernel groups the pairs
# by expert into slots of up to M pairs; the gate/up and down kernels then read each expert's codes once per slot and
# accumulate every pair of the slot (each pair in its own accumulator, the same fma order as a one-row step: the bits
# per row do not depend on M, on the slot or on the other rows). Unused slots exit at once.
_PLAN = """
    uint e = thread_position_in_threadgroup.x;          // one thread per expert, one threadgroup of 128
    threadgroup uint cnt[128];
    uint pairs[KM];
    uint m = 0;
    for (uint p = 0; p < NP; p++) {
        if (idx[p] == e && m < KM) { pairs[m] = p; m++; }
    }
    uint ns = (m + M - 1) / M;
    cnt[e] = ns;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    uint off = 0, total = 0;
    for (uint i = 0; i < 128; i++) { if (i < e) off += cnt[i]; total += cnt[i]; }
    for (uint s = 0; s < ns; s++) {
        slot_e[off + s] = e;
        for (uint i = 0; i < M; i++) slot_p[(off + s) * M + i] = (s * M + i < m) ? pairs[s * M + i] : 0xFFFFFFFFu;
    }
    for (uint s = total + e; s < S; s += 128) {
        slot_e[s] = 0xFFFFFFFFu;
        for (uint i = 0; i < M; i++) slot_p[s * M + i] = 0xFFFFFFFFu;
    }
"""
_plan = mx.fast.metal_kernel(name="mk_plan", input_names=["idx"], output_names=["slot_e", "slot_p"], source=_PLAN)


def _decode_src(fmt: str, cp: str, g: str) -> str:
    if fmt == "nv":
        if W16:
            return f"""uint q0 = *((const device uint*)({cp} + {g} * 8));
                uint q1 = *((const device uint*)({cp} + {g} * 8 + 4));
                float4 w0 = nva4(q0), w1 = nva4(q0 >> 16), w2 = nva4(q1), w3 = nva4(q1 >> 16);
                float4 v0 = nvb4(q0), v1 = nvb4(q0 >> 16), v2 = nvb4(q1), v3 = nvb4(q1 >> 16);"""
        return f"""uint q0 = *((const device uint*)({cp} + {g} * 8));
                uint q1 = *((const device uint*)({cp} + {g} * 8 + 4));
                float4 w0 = nv4(q0), w1 = nv4(q0 >> 16), w2 = nv4(q1), w3 = nv4(q1 >> 16);"""
    return "\n".join(f"float4 w{j} = mx4(*((const device uint*)({cp} + {g} * 32 + {4 * j})));" for j in range(8))


def _rows_src(fmt: str, D: int, M: int, R: int, cps, sps, xps, accs) -> str:
    """One lane's share of R weight rows x M input rows. accs[r][i] accumulators; cps[r] / sps[r] code and scale pointers;
    xps[i] input row pointers."""
    per, nf = (16, 4) if fmt == "nv" else (32, 8)
    groups = D // per
    it = (groups + 31) // 32
    body = ""
    for r in range(R):
        body += "{ " + _decode_src(fmt, cps[r], "g")
        sc = f"E4M3[({sps[r]})[g]]" if fmt == "nv" else f"as_type<float>(uint(({sps[r]})[g]) << 23)"
        body += f"\n                float sc = {sc};"
        if fmt == "nv" and W16:
            body += "\n                float scA = bf16r(sc * gsw), scB = bf16r(1.5f * (sc * gsw));"
        for i in range(M):
            xq = f"({xps[i]} + g * {per})"
            if fmt == "nv" and W16:
                body += f"""
                {{ float4 x0 = {hf4(xq)}, x1 = {hf4(xq + ' + 4')}, x2 = {hf4(xq + ' + 8')}, x3 = {hf4(xq + ' + 12')};
                  float4 a = w0 * x0; a = fma(w1, x1, a); a = fma(w2, x2, a); a = fma(w3, x3, a);
                  float4 b = v0 * x0; b = fma(v1, x1, b); b = fma(v2, x2, b); b = fma(v3, x3, b);
                  {accs[r][i]} = fma(hsum(a), scA, {accs[r][i]});
                  {accs[r][i]} = fma(hsum(b), scB, {accs[r][i]}); }}"""
            elif fmt == "nv":
                body += f"""
                {{ float4 a = w0 * {hf4(xq)};
                  a = fma(w1, {hf4(xq + ' + 4')}, a);
                  a = fma(w2, {hf4(xq + ' + 8')}, a);
                  a = fma(w3, {hf4(xq + ' + 12')}, a);
                  {accs[r][i]} = fma(hsum(a), sc, {accs[r][i]}); }}"""
            else:
                body += f"\n                {{ float4 a = float4(0.0f);"
                for j in range(8):
                    body += f"\n                  a = fma(w{j}, {hf4(xq + f' + {4 * j}')}, a);"
                body += f"\n                  {accs[r][i]} = fma(hsum(a), sc, {accs[r][i]}); }}"
        body += " }\n"
    return f"""
        for (int it = 0; it < {it}; it++) {{
            int g = it * 32 + int(lane);
            if (g < {groups}) {{
                {body}
            }}
        }}"""


def _make_up2(fmt: str, M: int, R: int):
    D, cb, sb = 2304, (1152 if fmt == "nv" else 2304), (144 if fmt == "nv" else 72)
    accs = [[f"a{r}_{i}" for i in range(M)] for r in range(2 * R)]
    cps = [f"(c0 + {r * cb})" for r in range(2 * R)]
    sps = [f"(s0 + {r * sb})" for r in range(2 * R)]
    xps = [f"xr{i}" for i in range(M)]
    decl = "float " + ", ".join(f"{a} = 0.0f" for row in accs for a in row) + ";"
    xdecl = "\n".join(f"    uint p{i} = slot_p[s * {M} + {i}]; const device ushort* xr{i} = x + ((p{i} == 0xFFFFFFFFu ? p0 : p{i}) / 8) * {D};"
                      for i in range(M))
    fin = ""
    for r in range(R):
        for i in range(M):
            fin += f"""
    {{ float gt = simd_sum({accs[2 * r][i]}) * gs; float up = simd_sum({accs[2 * r + 1][i]}) * gs;
      if (lane == 0 && p{i} != 0xFFFFFFFFu) {{
        float gc = metal::precise::tanh(gt * 0.25f) * 4.0f;
        float uc = metal::precise::tanh(up * 0.04f) * 25.0f;
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(gt)));
        float sg = gt < 0 ? y : 1.0f - y;
        out[p{i} * 1152 + m + {r}] = to_bf16(gc * sg * uc);
      }} }}"""
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint s = g0 / {1152 // R}, m = (g0 % {1152 // R}) * {R};
    uint e = slot_e[s];
    if (e == 0xFFFFFFFFu) return;
{xdecl}
    float gsw = gsc[e];
    const device uchar* c0 = codes + (size_t(e) * 2304 + 2 * m) * {cb};
    const device uchar* s0 = scales + (size_t(e) * 2304 + 2 * m) * {sb};
    {decl}
    {_rows_src(fmt, D, M, 2 * R, cps, sps, xps, accs)}
    float gs = {'1.0f' if (W16 and fmt == 'nv') else 'gsw'};
    {fin}
"""
    return mx.fast.metal_kernel(name=f"mk_up2_{fmt}_{M}_{R}", input_names=["codes", "scales", "gsc", "x", "slot_e", "slot_p"],
                                output_names=["out"], source=src, header=_HDR)


def _make_down2(fmt: str, M: int, R: int):
    D, cb, sb = 1152, (576 if fmt == "nv" else 1152), (72 if fmt == "nv" else 36)
    accs = [[f"a{r}_{i}" for i in range(M)] for r in range(R)]
    cps = [f"(c0 + {r * cb})" for r in range(R)]
    sps = [f"(s0 + {r * sb})" for r in range(R)]
    xps = [f"xr{i}" for i in range(M)]
    decl = "float " + ", ".join(f"{a} = 0.0f" for row in accs for a in row) + ";"
    xdecl = "\n".join(f"    uint p{i} = slot_p[s * {M} + {i}]; const device ushort* xr{i} = h + (p{i} == 0xFFFFFFFFu ? p0 : p{i}) * {D};"
                      for i in range(M))
    fin = ""
    for r in range(R):
        for i in range(M):
            fin += f"""
    {{ float o = simd_sum({accs[r][i]}) * gs;
      if (lane == 0 && p{i} != 0xFFFFFFFFu) out[p{i} * 2304 + n + {r}] = o; }}"""
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint s = g0 / {2304 // R}, n = (g0 % {2304 // R}) * {R};
    uint e = slot_e[s];
    if (e == 0xFFFFFFFFu) return;
{xdecl}
    float gsw = gsc[e];
    const device uchar* c0 = codes + (size_t(e) * 2304 + n) * {cb};
    const device uchar* s0 = scales + (size_t(e) * 2304 + n) * {sb};
    {decl}
    {_rows_src(fmt, D, M, R, cps, sps, xps, accs)}
    float gs = {'1.0f' if (W16 and fmt == 'nv') else 'gsw'};
    {fin}
"""
    return mx.fast.metal_kernel(name=f"mk_down2_{fmt}_{M}_{R}", input_names=["codes", "scales", "gsc", "h", "slot_e", "slot_p"],
                                output_names=["out"], source=src, header=_HDR)


_COMB = """
    uint g = thread_position_in_grid.x;
    uint row = g / 2304, n = g % 2304;
    float y = 0.0f;
    for (int j = 0; j < 8; j++) y = fma(o[(row * 8 + j) * 2304 + n], wts[row * 8 + j], y);
    out[g] = y;
"""
_comb = mx.fast.metal_kernel(name="mk_comb", input_names=["o", "wts"], output_names=["out"], source=_COMB)
_up2, _down2 = {}, {}


def experts2(fmt: str, w13, s13, g13, w2, s2, g2, x16, idx, wts, M: int, RU: int = 2, RD: int = 2) -> mx.array:
    """As experts(), each distinct expert read once per slot of up to M (row, expert) pairs."""
    K = x16.shape[0]
    S = min(8 * K, 128)
    slot_e, slot_p = _plan(inputs=[idx], template=[("KM", K), ("NP", 8 * K), ("M", M), ("S", S)], grid=(128, 1, 1),
                           threadgroup=(128, 1, 1), output_shapes=[(S,), (S, M)], output_dtypes=[mx.uint32, mx.uint32])
    ku = _up2.get((fmt, M, RU)) or _up2.setdefault((fmt, M, RU), _make_up2(fmt, M, RU))
    kd = _down2.get((fmt, M, RD)) or _down2.setdefault((fmt, M, RD), _make_down2(fmt, M, RD))
    h = ku(inputs=[w13, s13, g13, x16, slot_e, slot_p], grid=(S * (1152 // RU) * 32, 1, 1), threadgroup=(256, 1, 1),
           output_shapes=[(K * 8, 1152)], output_dtypes=[mx.uint16])[0]
    o = kd(inputs=[w2, s2, g2, h, slot_e, slot_p], grid=(S * (2304 // RD) * 32, 1, 1), threadgroup=(256, 1, 1),
           output_shapes=[(K * 8, 2304)], output_dtypes=[mx.float32])[0]
    return _comb(inputs=[o, wts], grid=(K * 2304, 1, 1), threadgroup=(256, 1, 1), output_shapes=[(K, 2304)],
                 output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- depth mix
# Attention of Q learned queries over N depth sources of each row (N - 1 block states and the current partial), in one
# kernel: one threadgroup of 576 threads per row, 4 dims per thread; scores by fixed-order sums, softmax over the
# sources, weighted sum. out [K, Q, D].
def _make_mix(N: int, Q: int):
    names = [f"b{i}" for i in range(N)]
    load = "\n".join(f"    float4 v{i} = *((const device float4*)({n} + row * 2304 + d4));" for i, n in enumerate(names))
    dots = "\n".join(f"    float s{i}_{j} = dot4(v{i}, *((const device float4*)(qs + {j} * 2304 + d4)));" for i in range(N) for j in range(Q))
    red = "\n".join(f"    s{i}_{j} = tgsum(s{i}_{j}, buf + {(i * Q + j) * 18}, lane, sg);" for i in range(N) for j in range(Q))
    outs = ""
    for j in range(Q):
        outs += f"    {{ float m = s0_{j};\n"
        for i in range(1, N):
            outs += f"      m = max(m, s{i}_{j});\n"
        for i in range(N):
            outs += f"      float e{i} = metal::precise::exp((s{i}_{j} - m) * SCALE);\n"
        outs += "      float z = e0" + "".join(f" + e{i}" for i in range(1, N)) + ";\n"
        outs += "      float4 o = v0 * (e0 / z);\n"
        for i in range(1, N):
            outs += f"      o = fma(v{i}, float4(e{i} / z), o);\n"
        outs += f"      *((device float4*)(out + (row * {Q} + {j}) * 2304 + d4)) = o; }}\n"
    src = f"""
    constexpr float SCALE = 0.020833333333333332f;      // 2304 ^ -0.5
    uint row = threadgroup_position_in_grid.x;
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint d4 = tid * 4;
    threadgroup float buf[{N * Q * 18}];
{load}
{dots}
{red}
{outs}
"""
    hdr = """
inline float dot4(float4 a, float4 b) { float4 p = a * b; return (p.x + p.y) + (p.z + p.w); }
// the sum of v over the 576 threads of the group: simdgroup sums, then the 18 partials in order
inline float tgsum(float v, threadgroup float* buf, uint lane, uint sg) {
    float s = simd_sum(v);
    if (lane == 0) buf[sg] = s;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float t = 0.0f;
    for (int i = 0; i < 18; i++) t += buf[i];
    return t;
}
"""
    return mx.fast.metal_kernel(name=f"mk_mix_{N}_{Q}", input_names=names + ["qs"], output_names=["out"], source=src, header=hdr)


_mix = {}


def mix(sources: list, queries: mx.array) -> mx.array:
    """sources: N arrays float32 [K, 2304]; queries float32 [Q, 2304] -> float32 [K, Q, 2304]."""
    N, Q, K = len(sources), queries.shape[0], sources[0].shape[0]
    k = _mix.get((N, Q)) or _mix.setdefault((N, Q), _make_mix(N, Q))
    return k(inputs=list(sources) + [queries], grid=(K * 576, 1, 1), threadgroup=(576, 1, 1), output_shapes=[(K, Q, 2304)],
             output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- after q/k/v GEMVs
# One kernel for what sits between the q/k/v projections and the attention: the short convolutions of k and v over the
# last 4 inputs (static taps, or static + per-token dynamic taps in the full-attention layers), the L2 clips of q, k and
# the relative states, the RMS norm of v. One thread per (row, head unit): 24 q heads, 8 k heads, 8 v heads, 24 relative.
def _make_qkv(full: bool, qthr: float, rthr: float):
    """One simdgroup per (row, unit): 24 q heads, 8 k heads, 8 v heads, 24 relative; 4 dims per lane (a sequential
    128-dim loop per thread made this kernel latency-bound). Rows KR .. KR + 2 of the grid only write the conv windows."""
    if full:
        conv = """
        float4 acc = float4(0.0f);
        for (int lag = 0; lag < 4; lag++) {
            int i = int(row) - lag;
            float4 wv4 = i < 0 ? *((const device float4*)(st + (3 + i) * 1024 + c)) : *((const device float4*)(src + i * W + c));
            float4 tp = *((const device float4*)(taps + lag * 1024 + c)) + float4(src[row * W + 1024 + hh * 4 + lag]);
            acc = fma(wv4, tp, acc);
        }
        float4 y = (acc + *((const device float4*)(src + row * W + c))) * 0.3333333333333333f;"""
    else:
        conv = """
        float4 acc = float4(0.0f);
        for (int j = 0; j < 4; j++) {
            int i = int(row) + j - 3;
            float4 wv4 = i < 0 ? *((const device float4*)(st + (3 + i) * 1024 + c)) : *((const device float4*)(src + i * W + c));
            acc = fma(wv4, *((const device float4*)(taps + j * 1024 + c)), acc);
        }
        float4 y = (acc + *((const device float4*)(src + row * W + c))) * 0.4472135954999579f;"""
    src = f"""
    constexpr float QTHR = {float(qthr)!r}f;
    constexpr float RTHR = {float(rthr)!r}f;
    uint g = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint d4 = lane * 4;
    uint row = g / 64, u = g % 64;
    if (u >= 24 && u < 40) {{
        bool isk0 = u < 32;
        uint c0 = (isk0 ? u - 24 : u - 32) * 128 + d4;
        if (row < 3) {{
            float4 sv0 = *((const device float4*)((isk0 ? kst : vst) + row * 1024 + c0));
            if (isk0) *((device float4*)(wk + row * 1024 + c0)) = sv0; else *((device float4*)(wv + row * 1024 + c0)) = sv0;
        }}
        if (row < KR) {{
            float4 xv0 = *((const device float4*)((isk0 ? kk : vv) + row * W + c0));
            if (isk0) *((device float4*)(wk + (row + 3) * 1024 + c0)) = xv0; else *((device float4*)(wv + (row + 3) * 1024 + c0)) = xv0;
        }}
    }}
    if (row >= KR) return;
    if (u < 24) {{
        float4 sv = *((const device float4*)(o + row * 6552 + u * 128 + d4)) * *((const device float4*)(q_scale + u * 128 + d4));
        float ss = simd_sum((sv.x * sv.x + sv.y * sv.y) + (sv.z * sv.z + sv.w * sv.w));
        float f = min(QTHR / (metal::precise::sqrt(ss) + 1e-6f), 1.0f);
        *((device float4*)(q + (row * 24 + u) * 128 + d4)) = sv * f;
    }} else if (u < 40) {{
        bool isk = u < 32;
        uint hh = isk ? u - 24 : u - 32;
        const device float* src = isk ? kk : vv;
        const device float* st = isk ? kst : vst;
        const device float* taps = isk ? ktaps : vtaps;
        uint c = hh * 128 + d4;
        {conv}
        float ss = simd_sum((y.x * y.x + y.y * y.y) + (y.z * y.z + y.w * y.w));
        float f = isk ? min(QTHR / (metal::precise::sqrt(ss) + 1e-6f), 1.0f) : metal::precise::rsqrt(ss * 0.0078125f + 1e-6f);
        half4 hv = half4(y * f);
        if (isk) *((device half4*)(knew + row * 1024 + c)) = hv; else *((device half4*)(vnew + row * 1024 + c)) = hv;
    }} else {{
        uint hh = u - 40;
        float4 sv = float4(0.0f);
        if (lane < 4) sv = *((const device float4*)(o + row * 6552 + 6144 + hh * 16 + d4)) * *((const device float4*)(r_scale + hh * 16 + d4));
        float ss = simd_sum((sv.x * sv.x + sv.y * sv.y) + (sv.z * sv.z + sv.w * sv.w));
        float f = min(RTHR / (metal::precise::sqrt(ss) + 1e-6f), 1.0f);
        if (lane < 4) *((device float4*)(rel + (row * 24 + hh) * 16 + d4)) = sv * f;
    }}
"""
    return mx.fast.metal_kernel(name=f"mk_qkv_{int(full)}", input_names=["o", "kk", "vv", "kst", "vst", "ktaps", "vtaps", "q_scale", "r_scale"],
                                output_names=["q", "rel", "knew", "vnew", "wk", "wv"], source=src)


_qkv = {}


def qkv_post(full: bool, o, kk, vv, kst, vst, ktaps, vtaps, q_scale, r_scale, qthr: float, rthr: float):
    """o float32 [K, 6552] (q | gate | r | sinks), kk / vv float32 [K, 1024 (+32 dynamic taps)], conv states [3, 1024],
    taps [4, 1024] -> q float32 [K, 3072], rel float32 [K, 384], knew / vnew uint16 (half bits) [K, 1024]."""
    K = o.shape[0]
    k = _qkv.get(full) or _qkv.setdefault(full, _make_qkv(full, qthr, rthr))
    return k(inputs=[o, kk, vv, kst, vst, ktaps, vtaps, q_scale, r_scale],
             template=[("W", kk.shape[1]), ("KR", K)], grid=((K + 3) * 64 * 32, 1, 1),
             threadgroup=(32, 1, 1), output_shapes=[(K, 3072), (K, 384), (K, 1024), (K, 1024), (K + 3, 1024), (K + 3, 1024)],
             output_dtypes=[mx.float32, mx.float32, mx.uint16, mx.uint16, mx.float32, mx.float32])


# static short convolution + residual over [K, C] (post-attention and post-MLP): out = (sum_j win[t + j] taps[j] + x) / sqrt(5)
# (+ add[t] when ADD: the block residual)
_SCONV = """
    uint g = thread_position_in_grid.x;
    uint row = g / (C / 4), c = (g % (C / 4)) * 4;
    float4 acc = float4(0.0f);
    for (int j = 0; j < 4; j++) {
        int i = int(row) + j - 3;
        float4 wv = i < 0 ? *((const device float4*)(st + (3 + i) * C + c)) : *((const device float4*)(x + i * C + c));
        acc = fma(wv, *((const device float4*)(taps + j * C + c)), acc);
    }
    float4 y = (acc + *((const device float4*)(x + row * C + c))) * 0.4472135954999579f;
    *((device float4*)(out + row * C + c)) = y;
"""
_sconv = mx.fast.metal_kernel(name="mk_sconv", input_names=["x", "st", "taps"], output_names=["out"], source=_SCONV)


def sconv(x, st, taps):
    K, C = x.shape
    return _sconv(inputs=[x, st, taps], template=[("C", C)], grid=(K * C // 4, 1, 1), threadgroup=(64, 1, 1),
                  output_shapes=[(K, C)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- draft-only 8-bit GEMV
# The draft head only proposes, so its weights may be read from an 8-bit copy (per-row scale; what oMLX and the B200
# engine do for the draft). The target never uses this kernel.
_GEMV8 = f"""
    uint n = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    float4 acc[K];
    for (int k = 0; k < K; k++) acc[k] = float4(0.0f);
    const device int8_t* wr = w + size_t(n) * D;
    for (int i = 0; i < D / 256; i++) {{
        int idx = (i * 32 + lane) * 8;
        float4 w0 = float4(*((const device packed_char4*)(wr + idx)));
        float4 w1 = float4(*((const device packed_char4*)(wr + idx + 4)));
        for (int k = 0; k < K; k++) {{
            acc[k] = fma(w0, {hf4('x + k * D + idx')}, acc[k]);
            acc[k] = fma(w1, {hf4('x + k * D + idx + 4')}, acc[k]);
        }}
    }}
    float sc = scale[n];
    for (int k = 0; k < K; k++) {{
        float4 a = acc[k];
        float s = simd_sum((a.x + a.y) + (a.z + a.w));
        if (lane == 0) out[k * N + n] = s * sc;
    }}
"""
_gemv8 = mx.fast.metal_kernel(name="mk_gemv8", input_names=["w", "scale", "x"], output_names=["out"], source=_GEMV8)


def quant8(w: mx.array):
    """float [N, D] -> (int8 [N, D], float32 [N]): symmetric per-row 8-bit copy (draft only)."""
    out_q, out_s = [], []
    for s0 in range(0, w.shape[0], 16384):
        wf = w[s0:s0 + 16384].astype(mx.float32)
        sc = mx.maximum(mx.abs(wf).max(axis=1), 1e-30) / 127.0
        q = mx.round(wf / sc[:, None]).astype(mx.int8)
        mx.eval(q, sc)
        out_q.append(q); out_s.append(sc)
    q, s = mx.concatenate(out_q), mx.concatenate(out_s)
    mx.eval(q, s)
    return q, s


def gemv8(wq, x16: mx.array, n_out: int | None = None) -> mx.array:
    """wq = (int8 [N, D], scale [N]); x16 uint16 [K, D] (half bits), D % 256 == 0 -> float32 [K, N]."""
    w, sc = wq
    N, D = w.shape
    if n_out is not None:
        N = n_out
    K = x16.shape[0]
    return _gemv8(inputs=[w, sc, x16], template=[("D", D), ("N", N), ("K", K)], grid=(N * 32, 1, 1),
                  threadgroup=(256 if N % 8 == 0 else 32, 1, 1), output_shapes=[(K, N)], output_dtypes=[mx.float32])[0]


# ================================================================================================= fused glue (v2)
_TGHDR = """
inline float dot4(float4 a, float4 b) { float4 p = a * b; return (p.x + p.y) + (p.z + p.w); }
// the sum of v over the 576 threads of the group: simdgroup sums, then the 18 partials in order
inline float tgsum(float v, threadgroup float* buf, uint lane, uint sg) {
    float s = simd_sum(v);
    if (lane == 0) buf[sg] = s;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float t = 0.0f;
    for (int i = 0; i < 18; i++) t += buf[i];
    return t;
}
"""


def _make_mix2(N: int, Q: int, norm_in: bool, pout: bool, wout: bool):
    """Depth mix with the neighbours folded in. Sources b0..b{N-1}; the last one is the partial, RMS-normalized here
    when norm_in. Outputs: out [K, Q, D] float32 (unless wout), pn [K, D] (the normalized partial, when pout),
    y [K, Q, D] half bits = rms_norm(out_j) * wt[j] (when wout)."""
    names = [f"b{i}" for i in range(N)]
    L = N - 1
    load = "\n".join(f"    float4 v{i} = *((const device float4*)({n} + row * 2304 + d4));" for i, n in enumerate(names))
    nred = N * Q + (1 if norm_in else 0) + (Q if wout else 0)
    pre = ""
    if norm_in:
        pre = f"""
    float hh = tgsum(dot4(v{L}, v{L}), buf + {N * Q * 18}, lane, sg);
    v{L} = v{L} * metal::precise::rsqrt(hh * (1.0f / 2304.0f) + 1e-6f);"""
    dots = "\n".join(f"    float s{i}_{j} = tgsum(dot4(v{i}, *((const device float4*)(qs + {j} * 2304 + d4))), buf + {(i * Q + j) * 18}, lane, sg);"
                     for i in range(N) for j in range(Q))
    outs = ""
    for j in range(Q):
        outs += f"    {{ float m = s0_{j};\n"
        for i in range(1, N):
            outs += f"      m = max(m, s{i}_{j});\n"
        for i in range(N):
            outs += f"      float e{i} = metal::precise::exp((s{i}_{j} - m) * SCALE);\n"
        outs += "      float z = e0" + "".join(f" + e{i}" for i in range(1, N)) + ";\n"
        outs += "      float4 o = v0 * (e0 / z);\n"
        for i in range(1, N):
            outs += f"      o = fma(v{i}, float4(e{i} / z), o);\n"
        if wout:
            outs += f"""      float oo = tgsum(dot4(o, o), buf + {(N * Q + (1 if norm_in else 0) + j) * 18}, lane, sg);
      o = o * metal::precise::rsqrt(oo * (1.0f / 2304.0f) + 1e-6f) * *((const device float4*)(wt + {j} * 2304 + d4));
      *((device half4*)(y + (row * {Q} + {j}) * 2304 + d4)) = half4(o); }}\n"""
        else:
            outs += f"      *((device float4*)(out + (row * {Q} + {j}) * 2304 + d4)) = o; }}\n"
    if pout:
        outs += f"    *((device float4*)(pn + row * 2304 + d4)) = v{L};\n"
    src = f"""
    constexpr float SCALE = 0.020833333333333332f;      // 2304 ^ -0.5
    uint row = threadgroup_position_in_grid.x;
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint d4 = tid * 4;
    threadgroup float buf[{nred * 18}];
{load}
{pre}
{dots}
{outs}
"""
    onames = ([] if wout else ["out"]) + (["pn"] if pout else []) + (["y"] if wout else [])
    return mx.fast.metal_kernel(name=f"mk_mix2_{N}_{Q}_{int(norm_in)}{int(pout)}{int(wout)}", input_names=names + ["qs"] + (["wt"] if wout else []),
                                output_names=onames, source=src, header=_TGHDR)


_mix2 = {}


def mix2(sources: list, queries: mx.array, norm_in: bool = False, pout: bool = False, wt: mx.array | None = None):
    """Returns the kernel's outputs in the order (out or y, [pn]): out float32 [K, Q, D] / y uint16 [K, Q, D], pn [K, D]."""
    N, Q, K = len(sources), queries.shape[0], sources[0].shape[0]
    key = (N, Q, norm_in, pout, wt is not None)
    k = _mix2.get(key) or _mix2.setdefault(key, _make_mix2(*key))
    shapes, dts = [], []
    if wt is None:
        shapes.append((K, Q, 2304)); dts.append(mx.float32)
    if pout:
        shapes.append((K, 2304)); dts.append(mx.float32)
    if wt is not None:
        shapes.append((K, Q, 2304)); dts.append(mx.uint16)
    o = k(inputs=list(sources) + [queries] + ([wt] if wt is not None else []), grid=(K * 576, 1, 1), threadgroup=(576, 1, 1),
          output_shapes=shapes, output_dtypes=dts)
    if wt is not None and pout:
        return o[1], o[0]
    return o if len(o) > 1 else o[0]


# message gates of the looped layers: G gates at once (q, k, v: G = 3, messages 0..2; mlp: G = 1, message 3)
def _make_gate_pre(G: int, QH: int, M0: int):
    """st_g = [unit-RMS(h_g), unit-RMS(m_g)] as half bits [K, 4608], one output per gate (the input of down_proj)."""
    src = f"""
    uint grp = threadgroup_position_in_grid.x;
    uint row = grp / {G}, g = grp % {G};
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint d4 = tid * 4;
    threadgroup float buf[36];
    float4 hv = *((const device float4*)(h + (row * {QH} + min(g, {QH - 1}u)) * 2304 + d4));
    float4 mv = *((const device float4*)(msgs + (row * 4 + {M0} + g) * 2304 + d4));
    float hh = tgsum(dot4(hv, hv), buf, lane, sg);
    float mm = tgsum(dot4(mv, mv), buf + 18, lane, sg);
    half4 ho = half4(hv * metal::precise::rsqrt(hh * (1.0f / 2304.0f) + 1e-6f));
    half4 mo = half4(mv * metal::precise::rsqrt(mm * (1.0f / 2304.0f) + 1e-6f));
""" + "".join(f"""
    if (g == {i}) {{ *((device half4*)(st{i} + row * 4608 + d4)) = ho; *((device half4*)(st{i} + row * 4608 + 2304 + d4)) = mo; }}""" for i in range(G))
    return mx.fast.metal_kernel(name=f"mk_gate_pre_{G}_{QH}_{M0}", input_names=["h", "msgs"], output_names=[f"st{i}" for i in range(G)],
                                source=src, header=_TGHDR)


def _make_gate_post(G: int, QH: int, M0: int):
    """y_g = half(rms_norm((1 - tanh(f_g)) h_g + tanh(gain_g) m_g) * wt_g); fg_g float32 [K, 4608] = forget | gain."""
    sel = "".join(f"    if (g == {i}) fg = fg{i};\n" for i in range(1, G))
    src = f"""
    uint grp = threadgroup_position_in_grid.x;
    uint row = grp / {G}, g = grp % {G};
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint d4 = tid * 4;
    threadgroup float buf[18];
    const device float* fg = fg0;
{sel}
    float4 hv = *((const device float4*)(h + (row * {QH} + min(g, {QH - 1}u)) * 2304 + d4));
    float4 mv = *((const device float4*)(msgs + (row * 4 + {M0} + g) * 2304 + d4));
    float4 f = metal::precise::tanh(*((const device float4*)(fg + row * 4608 + d4)));
    float4 gn = metal::precise::tanh(*((const device float4*)(fg + row * 4608 + 2304 + d4)));
    float4 v = (1.0f - f) * hv + gn * mv;
    float vv = tgsum(dot4(v, v), buf, lane, sg);
    half4 o = half4(v * metal::precise::rsqrt(vv * (1.0f / 2304.0f) + 1e-6f) * *((const device float4*)(wt + g * 2304 + d4)));
""" + "".join(f"""
    if (g == {i}) *((device half4*)(y{i} + row * 2304 + d4)) = o;""" for i in range(G))
    return mx.fast.metal_kernel(name=f"mk_gate_post_{G}_{QH}_{M0}", input_names=["h", "msgs", "wt"] + [f"fg{i}" for i in range(G)],
                                output_names=[f"y{i}" for i in range(G)], source=src, header=_TGHDR)


_gpre, _gpost = {}, {}


def gates(h, msgs, downs: list, fgs: list, wt, m0: int) -> list:
    """h float32 [K, QH, D] (QH = 1: the same state for every gate); msgs float32 [K, 4, D]; downs: G down_proj matrices
    (bf16 bits [64, 4608]); fgs: G float32 [4608, 64] (forget | gain); wt float32 [G, D] norm weights -> G arrays uint16
    [K, D]: the gated, normalized states as half bits."""
    K, QH = h.shape[0], h.shape[1]
    G = len(downs)
    key = (G, QH, m0)
    kp = _gpre.get(key) or _gpre.setdefault(key, _make_gate_pre(*key))
    kq = _gpost.get(key) or _gpost.setdefault(key, _make_gate_post(*key))
    st = kp(inputs=[h, msgs], grid=(K * G * 576, 1, 1), threadgroup=(576, 1, 1), output_shapes=[(K, 4608)] * G,
            output_dtypes=[mx.uint16] * G)
    fg = [gemv_small(fgs[i], gemv(downs[i], st[i])) for i in range(G)]
    return kq(inputs=[h, msgs, wt] + fg, grid=(K * G * 576, 1, 1), threadgroup=(576, 1, 1), output_shapes=[(K, 2304)] * G,
              output_dtypes=[mx.uint16] * G)


# static short convolution + residual (+ block residual) and the conv window for the next pass, one kernel
_SCONV2 = """
    uint g = thread_position_in_grid.x;
    uint row = g / (C / 4), c = (g % (C / 4)) * 4;
    if (row < 3) *((device float4*)(win + row * C + c)) = *((const device float4*)(st + row * C + c));
    if (row >= KR) return;
    float4 xv = *((const device float4*)(x + row * C + c));
    *((device float4*)(win + (row + 3) * C + c)) = xv;
    float4 acc = float4(0.0f);
    for (int j = 0; j < 4; j++) {
        int i = int(row) + j - 3;
        float4 wv = i < 0 ? *((const device float4*)(st + (3 + i) * C + c)) : *((const device float4*)(x + i * C + c));
        acc = fma(wv, *((const device float4*)(taps + j * C + c)), acc);
    }
    float4 y = (acc + xv) * 0.4472135954999579f;
    if (ADD) y += *((const device float4*)(add + row * C + c));
    *((device float4*)(out + row * C + c)) = y;
"""
_sconv2 = mx.fast.metal_kernel(name="mk_sconv2", input_names=["x", "st", "taps", "add"], output_names=["out", "win"], source=_SCONV2)


def sconv2(x, st, taps, add=None):
    """-> (out [K, C], win [K + 3, C]); out = (conv + x) / sqrt(5) (+ add)."""
    K, C = x.shape
    return _sconv2(inputs=[x, st, taps, add if add is not None else x], template=[("C", C), ("KR", K), ("ADD", add is not None)],
                   grid=((K + 3) * C // 4, 1, 1), threadgroup=(64, 1, 1), output_shapes=[(K, C), (K + 3, C)],
                   output_dtypes=[mx.float32, mx.float32])


# ------------------------------------------------------------------------------------------------- message gates, one kernel
def _make_gate_all(G: int, QH: int, M0: int):
    """G message gates of one looped layer in one kernel, one threadgroup of 576 threads per (row, gate):
    st = [unit-RMS(h), unit-RMS(m)]; dn = down_proj st (64); f, gain = tanh(forget / gain proj dn);
    y = half(rms_norm((1 - f) h + gain m) * wt)."""
    selw = "".join(f"    if (g == {i}) {{ dw = dw{i}; ft = ft{i}; }}\n" for i in range(1, G))
    wr = "".join(f"\n    if (g == {i}) *((device half4*)(y{i} + row * 2304 + d4)) = o;" for i in range(G))
    src = f"""
    uint grp = threadgroup_position_in_grid.x;
    uint row = grp / {G}, g = grp % {G};
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint d4 = tid * 4;
    threadgroup float buf[36];
    threadgroup float part[64 * 18];
    threadgroup float dnv[64];
    const device ushort* dw = dw0;
    const device float* ft = ft0;
{selw}
    float4 hv = *((const device float4*)(h + (row * {QH} + min(g, {QH - 1}u)) * 2304 + d4));
    float4 mv = *((const device float4*)(msgs + (row * 4 + {M0} + g) * 2304 + d4));
    float hh = tgsum(dot4(hv, hv), buf, lane, sg);
    float mm = tgsum(dot4(mv, mv), buf + 18, lane, sg);
    float4 hn = hv * metal::precise::rsqrt(hh * (1.0f / 2304.0f) + 1e-6f);
    float4 mn = mv * metal::precise::rsqrt(mm * (1.0f / 2304.0f) + 1e-6f);
    for (int n = 0; n < 64; n++) {{
        float4 wa = {bf4('dw + n * 4608 + d4')};
        float4 wb = {bf4('dw + n * 4608 + 2304 + d4')};
        float p = simd_sum(dot4(wa, hn) + dot4(wb, mn));
        if (lane == 0) part[n * 18 + sg] = p;
    }}
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (tid < 64) {{
        float t = 0.0f;
        for (int i = 0; i < 18; i++) t += part[tid * 18 + i];
        dnv[tid] = t;
    }}
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float4 fa = float4(0.0f), ga = float4(0.0f);
    for (int n = 0; n < 64; n++) {{
        float dv = dnv[n];
        fa = fma(*((const device float4*)(ft + n * 4608 + d4)), float4(dv), fa);
        ga = fma(*((const device float4*)(ft + n * 4608 + 2304 + d4)), float4(dv), ga);
    }}
    float4 v = (1.0f - metal::precise::tanh(fa)) * hv + metal::precise::tanh(ga) * mv;
    float vv = tgsum(dot4(v, v), buf, lane, sg);
    half4 o = half4(v * metal::precise::rsqrt(vv * (1.0f / 2304.0f) + 1e-6f) * *((const device float4*)(wt + g * 2304 + d4)));
{wr}
"""
    return mx.fast.metal_kernel(name=f"mk_gate_all_{G}_{QH}_{M0}",
                                input_names=["h", "msgs", "wt"] + [f"dw{i}" for i in range(G)] + [f"ft{i}" for i in range(G)],
                                output_names=[f"y{i}" for i in range(G)], source=src, header=_TGHDR)


_gall = {}


def gates2(h, msgs, downs: list, fts: list, wt, m0: int) -> list:
    """As gates(), one dispatch. fts: G float32 [64, 4608] (forget | gain projections, transposed)."""
    K, QH = h.shape[0], h.shape[1]
    G = len(downs)
    key = (G, QH, m0)
    k = _gall.get(key) or _gall.setdefault(key, _make_gate_all(*key))
    return k(inputs=[h, msgs, wt] + list(downs) + list(fts), grid=(K * G * 576, 1, 1), threadgroup=(576, 1, 1),
             output_shapes=[(K, 2304)] * G, output_dtypes=[mx.uint16] * G)


# ------------------------------------------------------------------------------------------------- exact argmax, short list
# A verify pass needs each row's argmax, not its logits. approx = the 8-bit copy's product (gemv8); for every output n
# |approx - exact| <= scale[n] / 2 * ||x||_1 (rounding of the copy) + float slop, so only outputs whose upper bound
# reaches the best lower bound of some row can be the argmax. Those are recomputed by exactly the GEMV arithmetic of
# mk_gemv (so the value is the bits step() computes); all others are written as -inf.
_GEMV_FLAG = _GEMV.replace("    float4 acc[K];", """    if (flag[n] == 0) {
        if (lane == 0) { for (int k = 0; k < K; k++) out[k * N + n] = -INFINITY; }
        return;
    }
    float4 acc[K];""")
assert _GEMV_FLAG != _GEMV
_gemv_flag = mx.fast.metal_kernel(name="mk_gemv_flag", input_names=["w", "x", "flag"], output_names=["out"], source=_GEMV_FLAG)


def argmax_short(w16, w8, x16: mx.array, n_out: int, cap: float):
    """w16: BF16 bits [rows, D]; w8 = (int8 [n_out, D], scale [n_out]) its 8-bit copy; x16 uint16 [K, D] (half bits).
    -> (tokens uint32 [K] = first index of the maximum of cap * tanh(z / cap) over the exact z, candidates int32 [])."""
    K, D = x16.shape
    approx = gemv8(w8, x16)                                                    # [K, n_out]
    l1 = mx.abs(x16.view(mx.float16).astype(mx.float32)).sum(axis=-1, keepdims=True)
    eps = (0.51 * l1) * w8[1][None, :] + 0.02                                  # rigorous bound + slop (see above)
    lo = (approx - eps).max(axis=-1, keepdims=True)
    flag = ((approx + eps) >= lo).any(axis=0).astype(mx.uint8)                 # [n_out]
    z = _gemv_flag(inputs=[w16, x16, flag], template=[("D", D), ("N", n_out), ("K", K)], grid=(n_out * 32, 1, 1),
                   threadgroup=(256 if n_out % 8 == 0 else 32, 1, 1), output_shapes=[(K, n_out)], output_dtypes=[mx.float32])[0]
    logits = mx.where(z == -mx.inf, -mx.inf, mx.tanh(z * (1.0 / cap)) * cap)
    return mx.argmax(logits, axis=-1), flag.astype(mx.int32).sum()
