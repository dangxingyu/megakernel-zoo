"""The checkpoint's DSpark draft head (mtp.safetensors, mtp_config): three decoder layers over a block of 8 rows (the
anchor = last committed token, and 7 mask rows) attending to a context built from the target's features, and a low-rank
Markov recurrence that turns the block into 7 drafts. The draft only proposes; the verify pass of the target decides
(Draft.cycle below: draft -> K-row verify pass -> accept the matching prefix).
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import mlx.core as mx
import numpy as np

import mk_kernels as kn

F32 = mx.float32
NB = 8
NARROW = os.environ.get("MK_NARROW", "1") == "1"


def rms(x, w=None, eps=1e-6):
    return mx.fast.rms_norm(x, w, eps)


def ngram(hist, min_match: int, n: int = NB - 1, max_match: int = 24):
    """Copy proposal from the sequence's own history: the longest earlier occurrence (>= min_match tokens, the most
    recent among the longest) of the suffix that ends at the anchor hist[-1]; its continuation, read periodically when
    it runs into the end of the history, is the proposal. Returns a list of n tokens or None."""
    L = len(hist)
    if L < min_match + 1:
        return None
    h = np.asarray(hist, dtype=np.int64)
    cand = np.nonzero(h[:L - 1] == h[L - 1])[0]
    if cand.size == 0:
        return None
    best, bj = 0, -1
    for j in cand[::-1]:
        m = 1
        while m < max_match and j - m >= 0 and h[j - m] == h[L - 1 - m]:
            m += 1
        if m > best:
            best, bj = m, int(j)
            if m >= max_match:
                break
    if best < min_match:
        return None
    period = L - 1 - bj
    return [int(h[bj + 1 + (i % period)]) for i in range(n)]


class Draft:
    def __init__(self, model_dir: str, tg):
        cfg = json.loads((Path(model_dir) / "config.json").read_text())
        mc = cfg["mtp_config"]
        assert mc["markov_head_type"] == "rnn_hidden" and mc["block_size"] == NB and mc["num_hidden_layers"] == 3
        assert mc["hidden_size"] == 2304 and mc["markov_rank"] == 256 and mc["target_layer_ids"] == [5, 23, 41, 48]
        assert mc["num_attention_heads"] == 24 and mc["num_key_value_heads"] == 8 and mc["head_dim"] == 128
        self.tg = tg
        self.T = tg.T
        self.window = mc["sliding_window_size"]
        self.local = set(mc["local_layer_ids"])
        self.vocab, self.cap = tg.vocab, tg.cap
        self.theta = float(os.environ.get("MK_CUM_TH", "0.5"))
        self.kmin = int(os.environ.get("MK_KMIN", "0"))
        self.skip_low = float(os.environ.get("MK_SKIP_LOW", "0.5"))
        self.skip_n = int(os.environ.get("MK_SKIP_N", "0"))
        self.ng_min = int(os.environ.get("MK_NGRAM", "5"))
        self.ng_wide = os.environ.get("MK_WIDE", "1") == "1"
        w = mx.load(str(Path(model_dir) / "mtp.safetensors"))
        u16 = lambda a: mx.contiguous(a).view(mx.uint16)  # noqa: E731
        f32 = lambda k: w[k].astype(F32)  # noqa: E731
        self.L = []
        for l in range(3):
            p = f"layers.{l}."
            g = lambda k: w[p + k]  # noqa: E731
            self.L.append({
                "qkv": u16(mx.concatenate([g("self_attn.q_proj.weight"), g("self_attn.k_proj.weight"), g("self_attn.v_proj.weight")])),
                "kv_ctx": u16(mx.concatenate([g("self_attn.k_proj_ctx.weight"), g("self_attn.v_proj_ctx.weight")])),
                "o": u16(g("self_attn.o_proj.weight")),
                "gate_up": u16(mx.concatenate([g("mlp.gate_proj.weight"), g("mlp.up_proj.weight")])),
                "down": u16(g("mlp.down_proj.weight")),
                "in_ln": f32(p + "input_layernorm.weight"), "post_ln": f32(p + "post_attention_layernorm.weight"),
                "dflare": f32(p + "dflare_norm.weight"), "q_norm": f32(p + "self_attn.q_norm.weight"),
                "k_norm": f32(p + "self_attn.k_norm.weight"), "k_norm_ctx": f32(p + "self_attn.k_norm_ctx.weight"),
            })
        self.q8 = os.environ.get("MK_DRAFT8", "1") == "1"
        if self.q8:
            for d in self.L:
                for k in ("qkv", "o", "gate_up", "down"):
                    d[k] = kn.quant8(d[k].view(mx.bfloat16))
        self.norm = f32("norm.weight")
        self.mask_embed = f32("mask_embed")
        self.alpha = mx.softmax(f32("fuse_weight"), axis=-1).astype(mx.bfloat16).astype(F32)       # [4, 4]
        mh = "markov_head."
        self.m_norm = f32(mh + "dflare_norm.weight")
        self.w1 = w[mh + "markov_w1.weight"]                                                       # [rows, 256] bf16
        rnn = w[mh + "rnn_proj.weight"]                                                            # [768, 5120]
        self.w_rec = u16(rnn[:, :512])
        self.w_ctx = u16(rnn[:, 512:])
        self.rnn_b = f32(mh + "rnn_proj.bias")
        ho_w, ho_b = f32(mh + "hidden_out.weight"), f32(mh + "hidden_out.bias")                   # [2304, 256], [2304]
        # logits = (hid + hidden_out(latent)) . unembed: the hidden_out x unembed product folded once (stored BF16)
        fw, fb = [], []
        un = tg.unembed.view(mx.bfloat16)
        for s in range(0, self.vocab, 16384):
            head = un[s:min(s + 16384, self.vocab)].astype(F32)
            fw.append((head @ ho_w).astype(mx.bfloat16))
            fb.append(head @ ho_b)
            mx.eval(fw[-1], fb[-1])
        self.fold_w = u16(mx.concatenate(fw))                                                      # [V, 256]
        self.un8 = None
        if self.q8:
            self.fold_w = kn.quant8(self.fold_w.view(mx.bfloat16))
            self.un8 = tg.un8 if getattr(tg, "un8", None) is not None else kn.quant8(un[:self.vocab])
        self.fold_b = mx.concatenate(fb)                                                           # [V]
        self.inv_freq = 1.0 / (mc["rope_theta"] ** (mx.arange(0, 128, 2).astype(F32) / 128))
        keep = [self.norm, self.mask_embed, self.alpha, self.m_norm, self.w1, self.w_rec, self.w_ctx, self.rnn_b,
                self.fold_w, self.fold_b, self.inv_freq, self.un8] + [v for d in self.L for v in d.values()]
        mx.eval(keep)
        self.gm = kn.gemv8 if self.q8 else kn.gemv
        self.tpos = mx.arange(self.T).astype(F32)
        self._fn = None
        self.n1 = int(os.environ.get("MK_DRAFT_N1", "3"))     # Markov steps before the first look at the probabilities
        del w
        self.reset()

    def reset(self):
        self.kc = [mx.zeros((self.T, 8, 128), dtype=F32) for _ in range(3)]
        self.vc = [mx.zeros((self.T, 8, 128), dtype=F32) for _ in range(3)]
        self.frow = None            # the 4 features of the last committed position, [1, H] each
        self.hist = []              # recent acceptance (tokens per cycle)

    # ---------------------------------------------------------------------------------------------- pieces
    def _rope(self, x, pos):
        """x [n, heads, 128], pos float32 [n]."""
        f = pos[:, None] * self.inv_freq[None]
        cos, sin = mx.cos(f)[:, None], mx.sin(f)[:, None]
        x1, x2 = x[..., :64], x[..., 64:]
        return mx.concatenate([x1 * cos - x2 * sin, x2 * cos + x1 * sin], axis=-1)

    def _mix(self, feats, row, weight):
        m = feats[0] * self.alpha[row, 0] + feats[1] * self.alpha[row, 1] + feats[2] * self.alpha[row, 2] + feats[3] * self.alpha[row, 3]
        return rms(m, weight)

    def append(self, feats, pos: int, n: int):
        """feats: 4 arrays [K, H] of a target pass at positions pos .. pos + K - 1; the first n rows become context."""
        f = [x[:n] for x in feats]
        ps = mx.arange(pos, pos + n).astype(F32)
        for l in range(3):
            w = self.L[l]
            kv = kn.gemv(w["kv_ctx"], kn.bits(self._mix(f, l, w["dflare"])))               # [n, 2048]
            k = self._rope(rms(kv[:, :1024].reshape(n, 8, 128), w["k_norm_ctx"]), ps)
            self.kc[l][pos:pos + n] = k
            self.vc[l][pos:pos + n] = kv[:, 1024:].reshape(n, 8, 128)
        self.frow = [x[n - 1:n] for x in feats]

    def _pure(self, anchor, cpos, kc, vc, frow):
        """The draft as a pure function with static shapes (traced once by mx.compile): the context is the whole K/V
        array with a mask on the positions (>= c, or outside the window of the local layers)."""
        tg = self.tg
        nd = NB - 1
        e = rms(tg.embed[anchor].astype(F32), tg.embed_norm)
        x = mx.concatenate([e, mx.broadcast_to(self.mask_embed[None], (NB - 1, 2304))])
        pos = cpos + mx.arange(NB).astype(F32)
        vis_g = self.tpos < cpos
        vis_l = vis_g & (self.tpos >= cpos - self.window)
        zero8 = mx.zeros((NB,), dtype=F32)
        mask_g = mx.concatenate([mx.where(vis_g, 0.0, -mx.inf), zero8])
        mask_l = mx.concatenate([mx.where(vis_l, 0.0, -mx.inf), zero8])
        residual = None
        for l in range(3):
            w = self.L[l]
            if residual is None:
                residual, h = x, rms(x, w["in_ln"])
            else:
                residual = x + residual
                h = rms(residual, w["in_ln"])
            qkv = self.gm(w["qkv"], kn.bits(h))                                              # [8, 5120]
            q = self._rope(rms(qkv[:, :3072].reshape(NB, 24, 128), w["q_norm"]), pos)
            k = self._rope(rms(qkv[:, 3072:4096].reshape(NB, 8, 128), w["k_norm"]), pos)
            v = qkv[:, 4096:].reshape(NB, 8, 128)
            keys = mx.concatenate([kc[l], k]).transpose(1, 2, 0)                             # [8, 128, T + 8]
            vals = mx.concatenate([vc[l], v]).transpose(1, 0, 2)                             # [8, T + 8, 128]
            qq = q.reshape(NB, 8, 3, 128).transpose(1, 0, 2, 3).reshape(8, NB * 3, 128)
            s = mx.softmax((qq @ keys) * (128 ** -0.5) + (mask_l if l in self.local else mask_g), axis=-1)
            a = (s @ vals).reshape(8, NB, 3, 128).transpose(1, 0, 2, 3).reshape(NB, 3072)
            o = self.gm(w["o"], kn.bits(a))
            residual = o + residual
            h = rms(residual, w["post_ln"])
            gu = self.gm(w["gate_up"], kn.bits(h))                                           # [8, 18432]
            gate, up = gu[:, :9216], gu[:, 9216:]
            x = self.gm(w["down"], kn.bits(mx.clip(gate * mx.sigmoid(gate) * up, -60000.0, 60000.0)))
        hid = rms(x + residual, self.norm)[1:1 + nd]                                         # [nd, H]
        f = self._mix(frow, 3, self.m_norm)                                                  # [1, H]
        inp = mx.concatenate([hid, mx.broadcast_to(f, (nd, 2304))], axis=-1)
        context = kn.gemv(self.w_ctx, kn.bits(inp)) + self.rnn_b                             # [nd, 768]
        base = (kn.gemv8(self.un8, kn.bits(hid)) if self.q8 else kn.gemv(tg.unembed, kn.bits(hid), self.vocab)) + self.fold_b
        state = mx.zeros((1, 256), dtype=F32)
        d, p, state, prev = self._markov(context[:self.n1], base[:self.n1], state, anchor)
        return d, p, state, prev, context[self.n1:], base[self.n1:]

    def _markov(self, context, base, state, prev):
        """Markov steps over the rows of context / base: each draft conditions the next through the low-rank state."""
        drafts, probs = [], []
        for i in range(context.shape[0]):
            rin = mx.concatenate([state, self.w1[prev].astype(F32)], axis=-1)
            raw = context[i:i + 1] + kn.gemv(self.w_rec, kn.bits(rin))
            gt = mx.sigmoid(raw[:, :256])
            state = gt * state + (1.0 - gt) * mx.tanh(raw[:, 256:512])
            latent = mx.tanh(raw[:, 512:])
            z = base[i:i + 1] + (kn.gemv8_narrow(self.fold_w, kn.bits(latent)) if (self.q8 and NARROW) else self.gm(self.fold_w, kn.bits(latent)))
            lg = self.cap * mx.tanh(z * (1.0 / self.cap))
            prev = mx.argmax(lg, axis=-1).astype(mx.int32)
            probs.append(mx.exp(lg.max(axis=-1) - mx.logsumexp(lg, axis=-1)))
            drafts.append(prev)
        return mx.concatenate(drafts), mx.concatenate(probs), state, prev

    def propose(self, anchor, c: int, nd: int = NB - 1):
        """anchor: int32 [1], the token at position c -> the first n1 drafts and their probabilities (lazy) and the
        rest of the block for more()."""
        if self._fn is None:
            comp = os.environ.get("MK_COMPILE", "1") == "1"
            self._fn = mx.compile(self._pure) if comp else self._pure
            self._fn2 = mx.compile(self._markov) if comp else self._markov
        d, p, state, prev, ctx, base = self._fn(anchor, mx.array([float(c)], dtype=F32), self.kc, self.vc, self.frow)
        self._rest = (ctx, base, state, prev)
        return d, p

    def more(self):
        """The remaining drafts of the block proposed last (run only while the draft is still confident)."""
        d, p, _, _ = self._fn2(*self._rest)
        return d, p

    def warm(self):
        z = mx.zeros((8, 2304), dtype=F32)
        z = mx.zeros((16, 2304), dtype=F32)
        for n in range(1, 17):
            self.append([z, z, z, z], 0, n)
        for _ in range(2):
            d, p = self.propose(mx.zeros((1,), dtype=mx.int32), 8)
            mx.eval(d, p)
            if self.n1 < NB - 1:
                mx.eval(*self.more())
        mx.eval(self.kc, self.vc)

    # ---------------------------------------------------------------------------------------------- one cycle
    def cycle(self, eng, act, left: int):
        """One draft-and-verify cycle; returns the committed tokens (1 + the accepted drafts)."""
        tg = self.tg
        c = tg.pos
        anchor = mx.array([act["last"]], dtype=mx.int32)
        nd = NB - 1
        t0 = time.perf_counter()
        # copy proposals: 7 drafts, or 15 (a 16-row pass) while the previous copy cycle was accepted in full
        wide = self.ng_wide and act.get("ng_full", False) and left - 1 >= 15
        cont = ngram(act["hist"], self.ng_min, 15 if wide else nd) if self.ng_min > 0 else None
        if cont is not None:
            d = np.asarray(cont, dtype=np.int64)
            kd = len(cont)
            eng.counters["ngram_cycles"] = eng.counters.get("ngram_cycles", 0) + 1
        elif act.get("skip", 0) > 0:
            # the draft was unsure of its first token in the last cycle: one plain step without a draft
            act["skip"] -= 1
            d, kd = np.zeros((0,), dtype=np.int64), 0
            eng.counters["plain_cycles"] = eng.counters.get("plain_cycles", 0) + 1
        else:
            d, p = self.propose(anchor, c, nd)
            mx.eval(d, p, *self._rest)
            d, p = np.array(d), np.array(p)
            if len(p) < nd and np.prod(p) >= self.theta:
                d2, p2 = self.more()
                mx.eval(d2, p2)
                d, p = np.concatenate([d, np.array(d2)]), np.concatenate([p, np.array(p2)])
                eng.counters["draft_more"] = eng.counters.get("draft_more", 0) + 1
            cum = np.cumprod(p)
            # rows worth verifying: the draft's probabilities are overconfident (cumulative 0.5 is accepted ~25-40%),
            # a row costs ~2.3 ms and a token is worth ~10 ms
            kd = max(self.kmin, int((cum >= self.theta).cumprod().sum()))
            if p[0] < self.skip_low:
                act["skip"] = self.skip_n
        t1 = time.perf_counter()
        kd = max(0, min(kd, left - 1))
        K = 1 + kd
        toks = mx.array(np.concatenate([[act["last"]], d[:kd]]).astype(np.int32))
        tgt, feats = tg.forward(toks, want_feats=True, tok_only=True)
        if tgt.ndim == 2:
            tgt = mx.argmax(tgt, axis=-1)
        mx.eval(tgt, *feats)
        t = np.array(tgt)
        a = 0
        while a < kd and int(d[a]) == int(t[a]):
            a += 1
        n_acc = a + 1
        self.append(feats, c, n_acc)
        tg.commit(n_acc)
        mx.async_eval(self.kc, self.vc, *tg.state())
        eng.counters["rows"] += K
        eng.counters["draft_s"] = eng.counters.get("draft_s", 0.0) + (t1 - t0)
        eng.counters["verify_s"] = eng.counters.get("verify_s", 0.0) + (time.perf_counter() - t1)
        eng.counters["host_syncs"] += 2
        act["ng_full"] = cont is not None and a == kd and kd >= nd
        if cont is not None:
            eng.counters["ngram_tokens"] = eng.counters.get("ngram_tokens", 0) + n_acc
            if K == 16:
                eng.counters["wide_cycles"] = eng.counters.get("wide_cycles", 0) + 1
        out = [int(v) for v in t[:n_acc]]
        act["hist"].extend(out)
        return out
