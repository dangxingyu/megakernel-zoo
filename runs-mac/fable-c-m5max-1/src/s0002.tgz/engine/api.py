"""Inkling-2-Mini on Apple silicon, track C: the target as K-row passes of our own Metal kernels (engine/target.py,
engine/kernels.py), the checkpoint's DSpark head as the draft (engine/draft.py), exact draft-and-verify behind
submit() / poll(). step() is the K = 1 pass; a verify pass gives every row the bits step() gives it.
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

import mlx.core as mx
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mk_target import Target  # noqa: E402

SPEC = os.environ.get("MK_SPEC", "1") != "0"


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        t0 = time.time()
        self.max_batch, self.max_context = int(max_batch), int(max_context)
        info = mx.device_info()
        mx.set_wired_limit(info["max_recommended_working_set_size"])
        self.tg = Target(model_dir, self.max_context)
        self.vocab = self.tg.vocab
        self.draft = None
        if SPEC:
            try:
                from mk_draft import Draft
                self.draft = Draft(model_dir, self.tg)
            except ImportError:
                self.draft = None
        self.steps = 0
        self.pending = []
        self.active = None
        self.counters = {"cycles": 0, "tokens": 0, "rows": 0, "host_syncs": 0}
        self.load_seconds = time.time() - t0
        self._warm()

    def _warm(self):
        """Compile every kernel variant (K = 1..8) before anything is timed."""
        for K in range(1, 9):
            lg = self.tg.forward(mx.zeros((K,), dtype=mx.int32))
            self.tg.commit(K)
            mx.eval(lg)
        if self.draft is not None:
            self.draft.warm()
        self.reset()
        mx.synchronize()

    def _state(self):
        return [self.tg.kc, self.tg.vc, self.tg.cw]

    # ------------------------------------------------------------------------------------------ contract
    def reset(self) -> None:
        self.tg.reset()
        if self.draft is not None:
            self.draft.reset()

    def step(self, tokens) -> mx.array:
        tokens = np.ascontiguousarray(np.asarray(tokens, dtype=np.int64))
        if tokens.shape[0] != 1:
            raise ValueError("this engine decodes one sequence (max_batch 1)")
        if self.tg.pos >= self.max_context:
            raise ValueError(f"context limit {self.max_context} reached")
        logits = self.tg.forward(mx.array(tokens.astype(np.int32)))
        self.tg.commit(1)
        mx.async_eval(logits, *self._state())
        self.steps += 1
        return logits

    def generate(self, tokens, n_steps: int):
        tokens = np.ascontiguousarray(np.asarray(tokens, dtype=np.int64))
        if tokens.shape[0] != 1:
            raise ValueError("this engine decodes one sequence (max_batch 1)")
        tok = mx.array(tokens.astype(np.int32))
        out = []
        for _ in range(int(n_steps)):
            logits = self.tg.forward(tok)
            self.tg.commit(1)
            tok = mx.argmax(logits, axis=-1).astype(mx.int32)
            mx.async_eval(tok, *self._state())
            out.append(tok)
        res = mx.stack(out, axis=1)
        mx.eval(res)
        return res

    # ------------------------------------------------------------------------------------------ serving
    def submit(self, rid, prompt, n) -> None:
        prompt, n = [int(t) for t in prompt], int(n)
        if len(prompt) < 1 or n < 1 or len(prompt) + n - 1 > self.max_context:
            raise ValueError(f"request {rid!r}: prompt {len(prompt)} + {n} new tokens exceeds {self.max_context} positions")
        if min(prompt) < 0 or max(prompt) >= 201024:
            raise ValueError(f"request {rid!r}: token id out of range")
        self.pending.append((rid, prompt, n))

    def _prefill(self, prompt):
        """The prompt in passes of up to 8 rows (row-exact with one-row steps); returns the first new token (lazy)."""
        tg = self.tg
        i, last = 0, None
        feats = []
        while i < len(prompt):
            K = min(8, len(prompt) - i)
            toks = mx.array(np.asarray(prompt[i:i + K], dtype=np.int32))
            if self.draft is not None:
                logits, f = tg.forward(toks, want_feats=True)
                self.draft.append(f, tg.pos, K)
            else:
                logits = tg.forward(toks)
            tg.commit(K)
            last = mx.argmax(logits[K - 1:K], axis=-1).astype(mx.int32)
            mx.async_eval(last, *self._state())
            i += K
        return last

    def poll(self):
        events = []
        act = self.active
        if act is None:
            if not self.pending:
                return events
            rid, prompt, n = self.pending.pop(0)
            self.reset()
            first = self._prefill(prompt)
            spec = self.draft is not None and len(prompt) + n + 16 <= self.tg.T
            act = self.active = {"rid": rid, "n": n, "sent": 0, "tok": first, "spec": spec}
            t = int(first.item())
            self.counters["host_syncs"] += 1
            act["sent"] = 1
            act["last"] = t
            events.append((rid, [t], n == 1))
            if n == 1:
                self.active = None
            return events
        left = act["n"] - act["sent"]
        if act["spec"]:
            toks = self.draft.cycle(self, act, left)
        else:
            logits = self.tg.forward(mx.array([act["last"]], dtype=mx.int32))
            self.tg.commit(1)
            toks = [int(mx.argmax(logits, axis=-1).item())]
            self.counters["host_syncs"] += 1
        toks = toks[:left]
        act["sent"] += len(toks)
        act["last"] = toks[-1]
        self.counters["cycles"] += 1
        self.counters["tokens"] += len(toks)
        done = act["sent"] >= act["n"]
        events.append((act["rid"], toks, done))
        if done:
            self.active = None
        return events

    def close(self) -> None:
        self.tg = None
        self.draft = None

    def stats(self) -> dict:
        c = dict(self.counters)
        if c["cycles"]:
            c["tokens_per_cycle"] = round(c["tokens"] / c["cycles"], 3)
        return {"implementation": "own MLX / Metal K-row passes (engine/target.py); DSpark draft-and-verify in submit/poll"
                if self.draft is not None else "own MLX / Metal K-row passes (engine/target.py); no speculation",
                "steps": self.steps, "spec": c, "load_seconds": round(self.load_seconds, 1),
                "peak_memory_gb": round(mx.get_peak_memory() / 1e9, 2)}
