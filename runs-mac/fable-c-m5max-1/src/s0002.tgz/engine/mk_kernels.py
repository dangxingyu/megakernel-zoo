"""Metal kernels of the engine (compiled at run time through mx.fast.metal_kernel).

Every kernel that sums over a weight row does it per (row of the pass, output) in an order that does not depend on how
many rows the pass has: explicit fma, default ("safe") math mode, simd_sum at the end. A K-row verify pass therefore
gives each row the bits the one-row step gives it (tests/rowexact.py).
"""
from __future__ import annotations

import mlx.core as mx

_BF = "as_type<float4>(uint4(*((const device vec<ushort,4>*)(%s))) << 16)"


def bf4(expr: str) -> str:
    return _BF % expr


# ------------------------------------------------------------------------------------------------- dense BF16 GEMV
# out[k, n] = sum_d W[n, d] x[k, d]; W bf16 bits [N, D], x bf16 bits [K, D], D % 128 == 0. One simdgroup per output.
_GEMV = f"""
    uint n = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    float4 acc[K];
    for (int k = 0; k < K; k++) acc[k] = float4(0.0f);
    const device ushort* wr = w + size_t(n) * D;
    for (int i = 0; i < D / 128; i++) {{
        int idx = (i * 32 + lane) * 4;
        float4 wf = {bf4('wr + idx')};
        for (int k = 0; k < K; k++) {{
            float4 xv = {bf4('x + k * D + idx')};
            acc[k] = fma(wf, xv, acc[k]);
        }}
    }}
    for (int k = 0; k < K; k++) {{
        float4 a = acc[k];
        float s = simd_sum((a.x + a.y) + (a.z + a.w));
        if (lane == 0) out[k * N + n] = s;
    }}
"""
_gemv = mx.fast.metal_kernel(name="mk_gemv", input_names=["w", "x"], output_names=["out"], source=_GEMV)


def gemv(w16: mx.array, x16: mx.array, n_out: int | None = None) -> mx.array:
    """w16 uint16 [N, D] (bf16 bits), x16 uint16 [K, D] (bf16 bits) -> float32 [K, N]."""
    N, D = w16.shape
    if n_out is not None:
        N = n_out
    K = x16.shape[0]
    return _gemv(inputs=[w16, x16], template=[("D", D), ("N", N), ("K", K)], grid=(N * 32, 1, 1),
                 threadgroup=(256 if N % 8 == 0 else 32, 1, 1), output_shapes=[(K, N)], output_dtypes=[mx.float32])[0]


def bits(x: mx.array) -> mx.array:
    """float -> bf16 bits (the rounding the checkpoint's BF16 linears see on their input)."""
    return x.astype(mx.bfloat16).view(mx.uint16)


# small float GEMV: out[k, n] = sum_d W[n, d] x[k, d], any D, one thread per output
_GEMV_S = """
    uint g = thread_position_in_grid.x;
    uint k = g / N, n = g % N;
    float acc = 0.0f;
    for (int d = 0; d < D; d++) acc = fma(w[n * D + d], x[k * D + d], acc);
    out[g] = acc;
"""
_gemv_s = mx.fast.metal_kernel(name="mk_gemv_small", input_names=["w", "x"], output_names=["out"], source=_GEMV_S)


def gemv_small(w: mx.array, x: mx.array) -> mx.array:
    N, D = w.shape
    K = x.shape[0]
    return _gemv_s(inputs=[w, x], template=[("D", D), ("N", N)], grid=(K * N, 1, 1), threadgroup=(32, 1, 1),
                   output_shapes=[(K, N)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- router
_ROUTER = """
    uint row = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    float sc[4];
    float bi[4];
    for (int i = 0; i < 4; i++) {
        uint e = lane + 32 * i;
        float x = logits[row * 128 + e];
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(x)));
        sc[i] = x < 0 ? y : 1.0f - y;
        bi[i] = sc[i] + bias[e];
    }
    float wsel[8];
    uint esel[8];
    for (int k = 0; k < 8; k++) {
        float best = -INFINITY;
        uint be = 128;
        for (int i = 0; i < 4; i++) {
            if (bi[i] > best) { best = bi[i]; be = lane + 32 * i; }
        }
        float top = simd_max(best);
        uint win = simd_min(best == top ? be : 128u);
        float s = 0.0f;
        for (int i = 0; i < 4; i++) {
            if (lane + 32 * i == win) { s = sc[i]; bi[i] = -INFINITY; }
        }
        wsel[k] = simd_sum(s);
        esel[k] = win;
    }
    float total = 0.0f;
    for (int k = 0; k < 8; k++) total += wsel[k];
    if (lane == 0) {
        for (int k = 0; k < 8; k++) {
            idx[row * 8 + k] = esel[k];
            wts[row * 8 + k] = wsel[k] / (total + 1e-20f) * 8.0f;
        }
    }
"""
_router = mx.fast.metal_kernel(name="mk_router", input_names=["logits", "bias"], output_names=["idx", "wts"], source=_ROUTER)


def router(logits: mx.array, bias: mx.array):
    K = logits.shape[0]
    return _router(inputs=[logits, bias], grid=(K * 32, 1, 1), threadgroup=(32, 1, 1), output_shapes=[(K, 8), (K, 8)],
                   output_dtypes=[mx.uint32, mx.float32])


# ------------------------------------------------------------------------------------------------- experts
def _e4m3(b: int) -> float:
    s = -1.0 if b & 128 else 1.0
    e, m = (b >> 3) & 15, b & 7
    return s * (m / 8 * 2.0 ** -6 if e == 0 else (1 + m / 8) * 2.0 ** (e - 7))


_HDR = ("constant float E2M1[16] = {0.0f, 0.5f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f, 6.0f, -0.0f, -0.5f, -1.0f, -1.5f, -2.0f, -3.0f, -4.0f, -6.0f};\n"
        "constant float E4M3[256] = {" + ", ".join(repr(float(_e4m3(b) if (b & 127) != 127 else 0.0)) + "f" for b in range(256)) + "};\n"
        """
inline float4 nv4(uint c) { return float4(E2M1[c & 15u], E2M1[(c >> 4) & 15u], E2M1[(c >> 8) & 15u], E2M1[(c >> 12) & 15u]); }
inline float4 mx4(uint c) { return float4(E4M3[c & 255u], E4M3[(c >> 8) & 255u], E4M3[(c >> 16) & 255u], E4M3[c >> 24]); }
inline float hsum(float4 a) { return (a.x + a.y) + (a.z + a.w); }
// one NVFP4 group: 16 elements (8 code bytes), x16 = 16 bf16 inputs
inline float nvgroup(const device uchar* cp, float4 x0, float4 x1, float4 x2, float4 x3) {
    uint c0 = *((const device uint*)cp);
    uint c1 = *((const device uint*)(cp + 4));
    float4 a = nv4(c0) * x0;
    a = fma(nv4(c0 >> 16), x1, a);
    a = fma(nv4(c1), x2, a);
    a = fma(nv4(c1 >> 16), x3, a);
    return hsum(a);
}
// one MXFP8 group: 32 elements (32 code bytes)
inline float mxgroup(const device uchar* cp, const device ushort* xp) {
    float4 a = float4(0.0f);
    for (int j = 0; j < 8; j++) {
        uint c = *((const device uint*)(cp + 4 * j));
        float4 xv = as_type<float4>(uint4(*((const device vec<ushort,4>*)(xp + 4 * j))) << 16);
        a = fma(mx4(c), xv, a);
    }
    return hsum(a);
}
inline ushort to_bf16(float f) {
    uint b = as_type<uint>(f);
    b += 0x7FFFu + ((b >> 16) & 1u);
    return ushort(b >> 16);
}
""")


def _dot_src(fmt: str, D: int, acc: str, cp: str, sp: str, xp: str) -> str:
    """Statements that add one lane's share of the dot of a quantized row (codes at cp, scales at sp) with the bf16 row
    at xp to `acc` (already scaled per group)."""
    if fmt == "nv":
        groups = D // 16
        it = (groups + 31) // 32
        return f"""
        for (int i = 0; i < {it}; i++) {{
            int g = i * 32 + int(lane);
            if (g < {groups}) {{
                const device ushort* xq = {xp} + g * 16;
                float4 x0 = {bf4('xq')};
                float4 x1 = {bf4('xq + 4')};
                float4 x2 = {bf4('xq + 8')};
                float4 x3 = {bf4('xq + 12')};
                {acc} = fma(nvgroup({cp} + g * 8, x0, x1, x2, x3), E4M3[({sp})[g]], {acc});
            }}
        }}"""
    groups = D // 32
    it = (groups + 31) // 32
    return f"""
        for (int i = 0; i < {it}; i++) {{
            int g = i * 32 + int(lane);
            if (g < {groups}) {{
                {acc} = fma(mxgroup({cp} + g * 32, {xp} + g * 32), as_type<float>(uint(({sp})[g]) << 23), {acc});
            }}
        }}"""


def _make_up(fmt: str):
    D, cb, sb = 2304, (1152 if fmt == "nv" else 2304), (144 if fmt == "nv" else 72)
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint p = g0 / 1152, m = g0 % 1152;
    uint e = idx[p];
    const device ushort* xr = x + (p / 8) * {D};
    const device uchar* c0 = codes + (size_t(e) * 2304 + 2 * m) * {cb};
    const device uchar* s0 = scales + (size_t(e) * 2304 + 2 * m) * {sb};
    float a0 = 0.0f, a1 = 0.0f;
    {_dot_src(fmt, D, 'a0', 'c0', 's0', 'xr')}
    {_dot_src(fmt, D, 'a1', f'(c0 + {cb})', f'(s0 + {sb})', 'xr')}
    float gs = gsc[e];
    float gt = simd_sum(a0) * gs;
    float up = simd_sum(a1) * gs;
    if (lane == 0) {{
        float gc = metal::precise::tanh(gt * 0.25f) * 4.0f;
        float uc = metal::precise::tanh(up * 0.04f) * 25.0f;
        float y = 1.0f / (1.0f + metal::precise::exp(metal::abs(gt)));
        float sg = gt < 0 ? y : 1.0f - y;
        out[g0] = to_bf16(gc * sg * uc);
    }}
"""
    return mx.fast.metal_kernel(name=f"mk_up_{fmt}", input_names=["codes", "scales", "gsc", "x", "idx"], output_names=["out"],
                                source=src, header=_HDR)


def _make_down(fmt: str):
    D, cb, sb = 1152, (576 if fmt == "nv" else 1152), (72 if fmt == "nv" else 36)
    src = f"""
    uint g0 = thread_position_in_grid.x / 32;
    uint lane = thread_index_in_simdgroup;
    uint row = g0 / 2304, n = g0 % 2304;
    float y = 0.0f;
    for (int j = 0; j < 8; j++) {{
        uint p = row * 8 + j;
        uint e = idx[p];
        const device ushort* xr = h + p * {D};
        const device uchar* c0 = codes + (size_t(e) * 2304 + n) * {cb};
        const device uchar* s0 = scales + (size_t(e) * 2304 + n) * {sb};
        float a0 = 0.0f;
        {_dot_src(fmt, D, 'a0', 'c0', 's0', 'xr')}
        y = fma(simd_sum(a0) * gsc[e], wts[p], y);
    }}
    if (lane == 0) out[g0] = y;
"""
    return mx.fast.metal_kernel(name=f"mk_down_{fmt}", input_names=["codes", "scales", "gsc", "h", "idx", "wts"],
                                output_names=["out"], source=src, header=_HDR)


_up = {f: _make_up(f) for f in ("nv", "mx")}
_down = {f: _make_down(f) for f in ("nv", "mx")}


def experts(fmt: str, w13, s13, g13, w2, s2, g2, x16: mx.array, idx: mx.array, wts: mx.array) -> mx.array:
    """x16 uint16 [K, 2304] (bf16 bits), idx uint32 [K, 8], wts float32 [K, 8] -> float32 [K, 2304]: the weighted sum of
    the 8 chosen experts (gate/up rows interleaved, soft-capped SwiGLU, BF16 between the two matrices)."""
    K = x16.shape[0]
    h = _up[fmt](inputs=[w13, s13, g13, x16, idx], grid=(K * 8 * 1152 * 32, 1, 1), threadgroup=(256, 1, 1),
                 output_shapes=[(K * 8, 1152)], output_dtypes=[mx.uint16])[0]
    return _down[fmt](inputs=[w2, s2, g2, h, idx, wts], grid=(K * 2304 * 32, 1, 1), threadgroup=(256, 1, 1),
                      output_shapes=[(K, 2304)], output_dtypes=[mx.float32])[0]


# ------------------------------------------------------------------------------------------------- attention
# One threadgroup per (row, head). Keys at positions < p0 come from the cache (bf16 bits [T, 1024]), positions p0.. from
# the rows of this pass (knew / vnew [K, 1024]). The relative bias is rel . proj[:, distance] for distance < 1024; the
# sink is one extra logit with a zero value.
_ATT = f"""
    constexpr int TG = 256;
    uint tid = thread_position_in_threadgroup.x;
    uint lane = thread_index_in_simdgroup;
    uint sg = simdgroup_index_in_threadgroup;
    uint grp = threadgroup_position_in_grid.x;
    int row = grp / 24, head = grp % 24, kvh = head / 3;
    int p0 = meta[0];
    int pos = p0 + row;
    int first = meta[1] > 0 ? max(0, pos - meta[1] + 1) : 0;
    threadgroup float sc[SMAX];
    threadgroup float red[8];
    threadgroup float4 part[TG];
    const device float* qp = q + grp * 128;
    const device float* rp = rel + grp * 16;
    float lmax = -INFINITY;
    for (int s = first + int(tid); s <= pos; s += TG) {{
        const device ushort* kp = (s < p0 ? kc + size_t(s) * 1024 : knew + (s - p0) * 1024) + kvh * 128;
        float4 a = float4(0.0f);
        for (int j = 0; j < 32; j++) {{
            float4 kf = {bf4('kp + 4 * j')};
            a = fma(kf, *((const device float4*)(qp + 4 * j)), a);
        }}
        float v = ((a.x + a.y) + (a.z + a.w)) * 0.08838834764831845f;
        int d = pos - s;
        if (d < 1024) {{
            float b = 0.0f;
            for (int r = 0; r < 16; r++) b = fma(rp[r], proj[r * 1024 + d], b);
            v += b;
        }}
        sc[s - first] = v;
        lmax = max(lmax, v);
    }}
    float m = simd_max(lmax);
    if (lane == 0) red[sg] = m;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float sink = sinks[grp];
    m = sink;
    for (int i = 0; i < 8; i++) m = max(m, red[i]);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float lsum = 0.0f;
    for (int s = first + int(tid); s <= pos; s += TG) {{
        float pr = metal::precise::exp(sc[s - first] - m);
        sc[s - first] = pr;
        lsum += pr;
    }}
    float ss = simd_sum(lsum);
    if (lane == 0) red[sg] = ss;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float tot = metal::precise::exp(sink - m);
    for (int i = 0; i < 8; i++) tot += red[i];
    int c = tid / 32;
    int d4 = (tid % 32) * 4;
    float4 acc = float4(0.0f);
    for (int s = first + c; s <= pos; s += 8) {{
        const device ushort* vp = (s < p0 ? vc + size_t(s) * 1024 : vnew + (s - p0) * 1024) + kvh * 128 + d4;
        float4 vf = {bf4('vp')};
        acc = fma(vf, float4(sc[s - first]), acc);
    }}
    part[tid] = acc;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (tid < 32) {{
        float4 o = part[tid];
        for (int i = 1; i < 8; i++) o += part[i * 32 + tid];
        o = o / tot;
        *((device float4*)(out + grp * 128 + d4)) = o;
    }}
"""
_att = mx.fast.metal_kernel(name="mk_attention", input_names=["q", "kc", "vc", "knew", "vnew", "rel", "proj", "sinks", "meta"],
                            output_names=["out"], source=_ATT)


def attention(q, kc, vc, knew, vnew, rel, proj, sinks, meta, smax: int) -> mx.array:
    """q float32 [K, 24, 128]; kc / vc uint16 [T, 1024]; knew / vnew uint16 [K, 1024]; rel float32 [K, 24, 16]; proj
    float32 [16, 1024]; sinks float32 [K, 24]; meta int32 [2] = (position of row 0, window or 0) -> float32 [K, 3072]."""
    K = q.shape[0]
    return _att(inputs=[q, kc, vc, knew, vnew, rel, proj, sinks, meta], template=[("SMAX", smax)], grid=(K * 24 * 256, 1, 1),
                threadgroup=(256, 1, 1), output_shapes=[(K, 3072)], output_dtypes=[mx.float32])[0]
