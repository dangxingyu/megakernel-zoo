#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
NVCC="${CUDA_HOME:-/usr/local/cuda}/bin/nvcc"
[ -x "$NVCC" ] || NVCC=nvcc
# engine/TRACK says which engine is built: A = the checkpoint's BF16 bits (apples to apples with the general
# engines), B = the lossless 12-bit weight format on top (echo A > engine/TRACK to get the track-A engine back).
TRACK="$(tr -d '[:space:]' < TRACK)"
DEFS="${MK_DEFS:-}"
[ "$TRACK" = "B" ] && DEFS="$DEFS -DW12"
if [ ! -f libmk.so ] || [ mk.cu -nt libmk.so ] || [ build.sh -nt libmk.so ] || [ TRACK -nt libmk.so ] || [ -n "${MK_DEFS:-}" ]; then
  "$NVCC" -O3 -std=c++17 -arch=sm_90 -Xptxas -v $DEFS -Xcompiler -fPIC -shared -o libmk.so.tmp mk.cu
  mv libmk.so.tmp libmk.so
fi
