// North-Mini-Code-1.0 decode megakernel for one H100.
//
// One persistent kernel per step() (or per generate() call): 132 blocks x 16 warps stay resident, block 0 leads.
// A decode step is a fixed program of stages; a stage is a list of warp-sized tasks (and, for attention, of
// block-sized tasks) claimed with an atomic counter. Every matrix product is a tensor-core m16n8k16 whose A
// operand is read straight from memory in fragment order (one 16-byte load per thread per mma) and whose B
// operand holds the batch in its 8 columns: batch 1 and batch 8 run the same instructions.
//
// Model facts used (CohereLabs/North-Mini-Code-1.0): parallel block (attention and MLP read the same normed
// input), 8 of 128 experts per token, 4 K/V heads x 8 query heads (the 8 query heads of a K/V head are the 8
// columns of an mma), tied head.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#define HID 2048
#define NLAYER 49
#define TOPK 8
#define MAXB 8
#define MAXU 64
#define VOCAB 262144
#define QKV_ROWS 5120
#define PART_ROWS 5248  // q 4096, k 512, v 512, router 128
#define HMAX 3072
#define NST_STEP 197
#define PC_HEAD 196
#define PC_ARG 197
#define ARG_CHUNK 2048
#define SCALE 0.08838834764831845f

struct LayerW {
  const uint4* qkv;     // 320 row tiles, K = 128 k-steps
  const uint4* router;  // 8 row tiles, K = 128 (unused in layer 0)
  const uint4* o;       // 128 row tiles, K = 256
  const uint4* expert;  // expert e at expert + e * exp_stride: gate|up interleaved (gu_tiles x 128), then down (128 x down_K)
  const uint16_t* normw;
  uint64_t exp_stride;  // in uint4 units
  int gu_tiles, down_K, rope, dense;
};

struct Ctl {
  uint32_t pub_seq; uint32_t pad0[15];
  uint32_t exit_id; uint32_t pad1[15];
  uint32_t ctr[256];
  uint32_t bctr[256];
  uint32_t done[256];
};

struct Dyn {
  int U;
  int slot_expert[MAXU];
  int bslot[MAXB][TOPK];
  float bw[MAXB][TOPK];
};

struct Model {
  LayerW L[NLAYER];
  const uint4* head;
  const uint16_t* embed;
  const uint16_t* normf;
  const float* rope;  // [ctx][64][2]
  uint4* kc; uint4* vc;
  uint16_t* x; uint16_t* xn; float* part; uint16_t* attn; float* opart; uint16_t* h; uint16_t* y;
  float* logits; float* candv; int* candi; int64_t* curtok;
  const uint32_t* zeros;
  Ctl* ctl; Dyn* dyn;
  uint16_t* dbg_x;     // optional [NLAYER+1][MAXB][HID]
  const int* force;    // optional [NLAYER][MAXB][TOPK] forced expert ids (debug)
  int max_ctx, maxK;
};

struct Launch {
  const Model* M;
  const int64_t* tok_in;
  float* logits_out;
  int64_t* tok_out;
  int B, pos, nsteps, gen, tok_stride;
  uint32_t seq0, launch_id;
};

#define MMA(c0, c1, c2, c3, a, b0, b1)                                                                          \
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
               : "+f"(c0), "+f"(c1), "+f"(c2), "+f"(c3)                                                         \
               : "r"((a).x), "r"((a).y), "r"((a).z), "r"((a).w), "r"(b0), "r"(b1))

__device__ __forceinline__ float bf2f(uint16_t v) { return __uint_as_float(((uint32_t)v) << 16); }
__device__ __forceinline__ uint16_t f2bf(float f) {
  uint32_t u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (uint16_t)(u >> 16);
}
__device__ __forceinline__ float rbf(float f) { return bf2f(f2bf(f)); }
__device__ __forceinline__ uint32_t vload(const uint32_t* p) { return *(const volatile uint32_t*)p; }

// y(16 rows x 8 batch columns) += W_tile(16 x 16K) * x(16K x 8): the weights stream from memory, x from cache
__device__ __forceinline__ void gemv_tile(const uint4* __restrict__ p, int K, const uint32_t* __restrict__ xb,
                                          float& c0, float& c1, float& c2, float& c3) {
  for (int k = 0; k < K; k += 8) {
    uint4 a[8];
#pragma unroll
    for (int u = 0; u < 8; u++) a[u] = p[(k + u) * 32];
#pragma unroll
    for (int u = 0; u < 8; u++) {
      uint32_t b0 = xb[(k + u) * 8], b1 = xb[(k + u) * 8 + 4];
      MMA(c0, c1, c2, c3, a[u], b0, b1);
    }
  }
}

struct Smem {
  float* S;       // [8][ctx] scores, then exp
  uint16_t* Pm;   // [8][ctx + 128] probabilities, bf16
  uint16_t* Qs;   // [8][128] rotated queries
  float* O;       // [2][8][128]
  float* R;       // [512]
  float* Mx;      // [8]
  uint32_t* W;    // [64] misc words
};

__device__ __forceinline__ int n_tile_tasks(const Model* M, int pc, int B) {
  if (pc == PC_HEAD) return VOCAB / 16;
  if (pc == PC_ARG) return B * (VOCAB / ARG_CHUNK);
  int l = pc >> 2, s = pc & 3;
  if (s == 0) return (l == 0 ? 320 : 328) * 4;
  if (s == 1) return M->dyn[l].U * M->L[l].gu_tiles;
  if (s == 2) return 128 * 4 + M->dyn[l].U * 128;
  return 128;
}
__device__ __forceinline__ int n_block_tasks(int pc, int B) { return (pc < PC_HEAD && (pc & 3) == 1) ? 4 * B : 0; }

// ---------------------------------------------------------------------------------------------------------
// attention for one (sequence, K/V head): the whole block works on it
__device__ __forceinline__ void attention_task(const Model* M, const Smem& sm, int l, int bt, int B, int pos) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g8 = lane >> 2, t4 = lane & 3;
  const int b = bt >> 2, g = bt & 3;
  const LayerW& LW = M->L[l];
  const int maxK = M->maxK;
  uint4* kc = M->kc + ((((size_t)l * MAXB + b) * 4 + g) * (size_t)maxK * 256);
  uint4* vc = M->vc + ((((size_t)l * MAXB + b) * 4 + g) * (size_t)maxK * 256);
  const int T = pos + 1, nk = (T + 15) >> 4, nk8 = (nk + 7) & ~7;
  // phase 0: q, k, v of the new token from the K-split partial sums; RoPE; append K and V
  for (int j = tid; j < 640; j += 512) {
    int row;  // row of the pair's first element in the qkv output
    if (j < 512) row = (8 * g + (j >> 6)) * 128 + 2 * (j & 63);
    else if (j < 576) row = 4096 + g * 128 + 2 * (j - 512);
    else row = 4608 + g * 128 + 2 * (j - 576);
    const float* p0 = M->part + (size_t)b * PART_ROWS + row;
    const size_t ps = (size_t)MAXB * PART_ROWS;
    float v0 = rbf(p0[0] + p0[ps] + p0[2 * ps] + p0[3 * ps]);
    float v1 = rbf(p0[1] + p0[ps + 1] + p0[2 * ps + 1] + p0[3 * ps + 1]);
    if (j < 576 && LW.rope) {
      const float* cs = M->rope + ((size_t)pos * 64 + (j & 63)) * 2;
      float c = cs[0], s = cs[1];
      float r0 = __fadd_rn(__fmul_rn(v0, c), __fmul_rn(-v1, s));
      float r1 = __fadd_rn(__fmul_rn(v1, c), __fmul_rn(v0, s));
      v0 = r0; v1 = r1;
    }
    uint16_t u0 = f2bf(v0), u1 = f2bf(v1);
    if (j < 512) {
      sm.Qs[(j >> 6) * 128 + 2 * (j & 63)] = u0;
      sm.Qs[(j >> 6) * 128 + 2 * (j & 63) + 1] = u1;
    } else if (j < 576) {
      // K cache: A operand with rows = positions, k = dims
      int d = 2 * (j - 512), p16 = pos & 15;
      size_t off = ((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ((p16 & 7) * 4 + ((d & 7) >> 1))) * 16) + (((d & 15) >> 3) * 2 + (p16 >> 3)) * 4;
      uint16_t* w = (uint16_t*)((char*)kc + off);
      w[0] = u0; w[1] = u1;
    } else {
      // V cache: A operand with rows = dims, k = positions (two dims of this pair live in different lanes)
      int p16 = pos & 15;
      for (int e = 0; e < 2; e++) {
        int d = 2 * (j - 576) + e;
        size_t off = ((((size_t)(d >> 4) * maxK + (pos >> 4)) * 32 + ((d & 7) * 4 + ((p16 & 7) >> 1))) * 16) + ((p16 >> 3) * 2 + ((d & 15) >> 3)) * 4 + (p16 & 1) * 2;
        *(uint16_t*)((char*)vc + off) = e ? u1 : u0;
      }
    }
  }
  __syncthreads();
  // phase 1: scores of the 8 query heads against every cached position
  {
    uint32_t q0[8], q1[8];
#pragma unroll
    for (int k = 0; k < 8; k++) {
      const uint32_t* qp = (const uint32_t*)(sm.Qs + g8 * 128 + 16 * k) + t4;
      q0[k] = qp[0]; q1[k] = qp[4];
    }
    for (int P = warp; P < nk; P += 16) {
      const uint4* p = kc + (size_t)P * 256 + lane;
      uint4 a[8];
#pragma unroll
      for (int k = 0; k < 8; k++) a[k] = p[k * 32];
      float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
#pragma unroll
      for (int k = 0; k < 8; k++) MMA(c0, c1, c2, c3, a[k], q0[k], q1[k]);
      int p0 = P * 16 + g8, h0 = 2 * t4;
      sm.S[h0 * M->max_ctx + p0] = c0 * SCALE;
      sm.S[(h0 + 1) * M->max_ctx + p0] = c1 * SCALE;
      sm.S[h0 * M->max_ctx + p0 + 8] = c2 * SCALE;
      sm.S[(h0 + 1) * M->max_ctx + p0 + 8] = c3 * SCALE;
    }
  }
  __syncthreads();
  // phase 2: softmax over positions 0..pos per head, in float32; probabilities to bf16
  {
    const int hd = tid & 7, slot = tid >> 3;
    float* S = sm.S + hd * M->max_ctx;
    float m = -INFINITY;
    for (int p = slot; p < T; p += 64) m = fmaxf(m, S[p]);
    sm.R[tid] = m;
    __syncthreads();
    if (tid < 8) { float mm = -INFINITY; for (int i = 0; i < 64; i++) mm = fmaxf(mm, sm.R[tid + 8 * i]); sm.Mx[tid] = mm; }
    __syncthreads();
    m = sm.Mx[hd];
    float z = 0;
    for (int p = slot; p < T; p += 64) { float e = expf(S[p] - m); S[p] = e; z += e; }
    sm.R[tid] = z;
    __syncthreads();
    if (tid < 8) { float zz = 0; for (int i = 0; i < 64; i++) zz += sm.R[tid + 8 * i]; sm.Mx[tid] = zz; }
    __syncthreads();
    z = sm.Mx[hd];
    uint16_t* Pm = sm.Pm + hd * (M->max_ctx + 128);
    for (int p = slot; p < nk8 * 16; p += 64) Pm[p] = p < T ? f2bf(S[p] / z) : (uint16_t)0;
  }
  __syncthreads();
  // phase 3: out[head][dim] = sum_t P[t][head] V[t][dim]; two warps per 16 dims (halves of the positions)
  {
    const int rt = warp & 7, half = warp >> 3;
    const int kmid = ((nk8 >> 1) + 7) & ~7;
    const int k0 = half ? kmid : 0, k1 = half ? nk8 : kmid;
    const uint4* p = vc + (size_t)rt * maxK * 32 + lane;
    const uint32_t* pb = (const uint32_t*)(sm.Pm + g8 * (M->max_ctx + 128)) + t4;
    float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
    for (int k = k0; k < k1; k += 8) {
      uint4 a[8];
#pragma unroll
      for (int u = 0; u < 8; u++) a[u] = p[(size_t)(k + u) * 32];
#pragma unroll
      for (int u = 0; u < 8; u++) { uint32_t b0 = pb[(k + u) * 8], b1 = pb[(k + u) * 8 + 4]; MMA(c0, c1, c2, c3, a[u], b0, b1); }
    }
    float* O = sm.O + half * 1024;
    int d0 = rt * 16 + g8, h0 = 2 * t4;
    O[h0 * 128 + d0] = c0; O[(h0 + 1) * 128 + d0] = c1; O[h0 * 128 + d0 + 8] = c2; O[(h0 + 1) * 128 + d0 + 8] = c3;
  }
  __syncthreads();
  for (int i = tid; i < 1024; i += 512)
    M->attn[(size_t)b * 4096 + g * 1024 + i] = f2bf(sm.O[i] + sm.O[1024 + i]);
}

// ---------------------------------------------------------------------------------------------------------
// one warp-sized task of stage pc
__device__ __forceinline__ void tile_task(const Model* M, int pc, int i, int B, float* logits) {
  const int lane = threadIdx.x & 31, g8 = lane >> 2, t4 = lane & 3;
  const int b0i = 2 * t4, b1i = 2 * t4 + 1;
  const bool act = g8 < B;
  float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
  if (pc == PC_HEAD) {
    const uint32_t* xb = act ? (const uint32_t*)(M->xn + g8 * HID) + t4 : M->zeros;
    gemv_tile(M->head + (size_t)i * 128 * 32 + lane, 128, xb, c0, c1, c2, c3);
    int row = i * 16 + g8;
    if (b0i < B) { logits[(size_t)b0i * VOCAB + row] = c0; logits[(size_t)b0i * VOCAB + row + 8] = c2; }
    if (b1i < B) { logits[(size_t)b1i * VOCAB + row] = c1; logits[(size_t)b1i * VOCAB + row + 8] = c3; }
    return;
  }
  if (pc == PC_ARG) {
    int b = i / (VOCAB / ARG_CHUNK), c = i % (VOCAB / ARG_CHUNK);
    const float* lg = logits + (size_t)b * VOCAB + c * ARG_CHUNK;
    float best = -INFINITY; int bi = 0x7fffffff;
    for (int j = lane; j < ARG_CHUNK; j += 32) { float v = lg[j]; if (v > best) { best = v; bi = c * ARG_CHUNK + j; } }
    for (int o = 16; o > 0; o >>= 1) {
      float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
      if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
    }
    if (lane == 0) { M->candv[i] = best; M->candi[i] = bi; }
    return;
  }
  const int l = pc >> 2, s = pc & 3;
  const LayerW& LW = M->L[l];
  if (s == 0) {
    // q, k, v and router rows against the normed input, K split in 4
    int r = i >> 2, sp = i & 3;
    const uint4* base = (r < 320 ? LW.qkv + (size_t)r * 128 * 32 : LW.router + (size_t)(r - 320) * 128 * 32) + sp * 32 * 32 + lane;
    const uint32_t* xb = act ? (const uint32_t*)(M->xn + g8 * HID + sp * 512) + t4 : M->zeros;
    gemv_tile(base, 32, xb, c0, c1, c2, c3);
    float* o = M->part + (size_t)sp * MAXB * PART_ROWS + r * 16 + g8;
    if (b0i < B) { o[(size_t)b0i * PART_ROWS] = c0; o[(size_t)b0i * PART_ROWS + 8] = c2; }
    if (b1i < B) { o[(size_t)b1i * PART_ROWS] = c1; o[(size_t)b1i * PART_ROWS + 8] = c3; }
  } else if (s == 1) {
    // gate|up of one expert: rows 0..7 of the tile are gate neurons, rows 8..15 the same neurons' up rows
    int u = i / LW.gu_tiles, m = i % LW.gu_tiles;
    int e = M->dyn[l].slot_expert[u];
    const uint4* base = LW.expert + (size_t)e * LW.exp_stride + (size_t)m * 128 * 32 + lane;
    const uint32_t* xb = act ? (const uint32_t*)(M->xn + g8 * HID) + t4 : M->zeros;
    gemv_tile(base, 128, xb, c0, c1, c2, c3);
    uint16_t* h = M->h + (size_t)u * MAXB * HMAX + m * 8 + g8;
    if (b0i < B) { float gt = rbf(c0); float a = rbf(gt / (1.0f + expf(-gt))); h[(size_t)b0i * HMAX] = f2bf(a * rbf(c2)); }
    if (b1i < B) { float gt = rbf(c1); float a = rbf(gt / (1.0f + expf(-gt))); h[(size_t)b1i * HMAX] = f2bf(a * rbf(c3)); }
  } else if (s == 2) {
    if (i < 512) {
      // o_proj, K split in 4
      int r = i >> 2, sp = i & 3;
      const uint4* base = LW.o + (size_t)r * 256 * 32 + sp * 64 * 32 + lane;
      const uint32_t* xb = act ? (const uint32_t*)(M->attn + g8 * 4096 + sp * 1024) + t4 : M->zeros;
      gemv_tile(base, 64, xb, c0, c1, c2, c3);
      float* o = M->opart + (size_t)sp * MAXB * HID + r * 16 + g8;
      if (b0i < B) { o[(size_t)b0i * HID] = c0; o[(size_t)b0i * HID + 8] = c2; }
      if (b1i < B) { o[(size_t)b1i * HID] = c1; o[(size_t)b1i * HID + 8] = c3; }
    } else {
      int j = i - 512, u = j >> 7, r = j & 127;
      int e = M->dyn[l].slot_expert[u];
      const uint4* base = LW.expert + (size_t)e * LW.exp_stride + (size_t)LW.gu_tiles * 128 * 32 + (size_t)r * LW.down_K * 32 + lane;
      const uint32_t* xb = act ? (const uint32_t*)(M->h + ((size_t)u * MAXB + g8) * HMAX) + t4 : M->zeros;
      gemv_tile(base, LW.down_K, xb, c0, c1, c2, c3);
      uint16_t* y = M->y + (size_t)u * MAXB * HID + r * 16 + g8;
      if (b0i < B) { y[(size_t)b0i * HID] = f2bf(c0); y[(size_t)b0i * HID + 8] = f2bf(c2); }
      if (b1i < B) { y[(size_t)b1i * HID] = f2bf(c1); y[(size_t)b1i * HID + 8] = f2bf(c3); }
    }
  } else {
    // residual: x = (x + attn) + mlp, every sum rounded to bf16 as the model's dtype does
    const Dyn& D = M->dyn[l];
    int row = i * 16 + (lane & 15), bh = lane >> 4;
    for (int j = 0; j < 4; j++) {
      int b = bh + 2 * j;
      if (b >= B) break;
      uint16_t* xp = M->x + (size_t)b * HID + row;
      const float* op = M->opart + (size_t)b * HID + row;
      const size_t os = (size_t)MAXB * HID;
      float a = rbf(op[0] + op[os] + op[2 * os] + op[3 * os]);
      float mlp;
      if (LW.dense) mlp = bf2f(M->y[(size_t)b * HID + row]);
      else {
        mlp = 0;
#pragma unroll
        for (int jj = 0; jj < TOPK; jj++) {
          float yv = bf2f(M->y[((size_t)D.bslot[b][jj] * MAXB + b) * HID + row]);
          mlp = rbf(mlp + rbf(yv * D.bw[b][jj]));
        }
      }
      *xp = f2bf(rbf(bf2f(*xp) + a) + mlp);
    }
  }
}

__device__ __forceinline__ void run_stage(const Model* M, const Smem& sm, int pc, int B, int pos, float* logits) {
  Ctl* C = M->ctl;
  const int tid = threadIdx.x, lane = tid & 31;
  const int nb = n_block_tasks(pc, B);
  if (nb) {
    for (;;) {
      if (tid == 0) sm.W[0] = atomicAdd(&C->bctr[pc], 1u);
      __syncthreads();
      int bt = (int)sm.W[0];
      if (bt >= nb) break;
      attention_task(M, sm, pc >> 2, bt, B, pos);
      __syncthreads();
      if (tid == 0) { __threadfence(); atomicAdd(&C->done[pc], 1u); }
    }
  }
  const int n = n_tile_tasks(M, pc, B);
  for (;;) {
    int i = 0;
    if (lane == 0) i = (int)atomicAdd(&C->ctr[pc], 1u);
    i = __shfl_sync(0xffffffffu, i, 0);
    if (i >= n) break;
    tile_task(M, pc, i, B, logits);
    __threadfence();
    if (lane == 0) atomicAdd(&C->done[pc], 1u);
  }
  __syncthreads();
}

// RMSNorm of x into xn (leader block): float32 mean of squares, x * rsqrt rounded to bf16, times the weight
__device__ __forceinline__ void leader_norm(const Model* M, const Smem& sm, const uint16_t* w, int B) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  for (int b = 0; b < B; b++) {
    const uint16_t* x = M->x + (size_t)b * HID;
    float v[4], ss = 0;
#pragma unroll
    for (int j = 0; j < 4; j++) { v[j] = bf2f(x[tid + 512 * j]); ss += v[j] * v[j]; }
    for (int o = 16; o > 0; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
    if (lane == 0) sm.R[warp] = ss;
    __syncthreads();
    float tot = 0;
#pragma unroll
    for (int i = 0; i < 16; i++) tot += sm.R[i];
    float rs = rsqrtf(tot * (1.0f / HID) + 1e-6f);
#pragma unroll
    for (int j = 0; j < 4; j++) {
      int i = tid + 512 * j;
      M->xn[(size_t)b * HID + i] = f2bf(bf2f(w[i]) * rbf(v[j] * rs));
    }
    __threadfence();
    __syncthreads();
  }
}

// router logits -> top 8 per sequence, sigmoid weights, union of experts over the batch (leader block)
__device__ __forceinline__ void leader_route(const Model* M, const Smem& sm, int l, int B) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  Dyn& D = M->dyn[l];
  uint32_t* masks = sm.W + 8;          // [MAXB][4]
  uint32_t* sel = sm.W + 8 + 32;       // [MAXB][8] expert ids
  float* selv = sm.R + 64;             // [MAXB][8] logits
  float* RL = sm.S;                    // [MAXB][128] rounded router logits
  if (warp < B) {
    const int b = warp;
    float v[4]; uint32_t taken = 0;
    const size_t ps = (size_t)MAXB * PART_ROWS;
#pragma unroll
    for (int j = 0; j < 4; j++) {
      const float* p0 = M->part + (size_t)b * PART_ROWS + QKV_ROWS + lane + 32 * j;
      v[j] = rbf(p0[0] + p0[ps] + p0[2 * ps] + p0[3 * ps]);
      RL[b * 128 + lane + 32 * j] = v[j];
    }
    uint32_t m[4] = {0, 0, 0, 0};
    for (int r = 0; r < TOPK; r++) {
      int e; float val;
      if (M->force) {
        e = M->force[((size_t)l * MAXB + b) * TOPK + r];
        val = RL[b * 128 + e];
      } else {
        float best = -INFINITY; int bi = 0x7fffffff;
#pragma unroll
        for (int j = 0; j < 4; j++) if (!((taken >> j) & 1) && v[j] > best) { best = v[j]; bi = lane + 32 * j; }
        for (int o = 16; o > 0; o >>= 1) {
          float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
          if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
        }
        e = bi; val = best;
        if ((e & 31) == lane) taken |= 1u << (e >> 5);
      }
      m[e >> 5] |= 1u << (e & 31);
      if (lane == 0) { sel[b * 8 + r] = e; selv[b * 8 + r] = val; }
    }
    if (lane < 4) masks[b * 4 + lane] = m[lane];
  }
  __syncthreads();
  uint32_t um[4] = {0, 0, 0, 0};
  for (int b = 0; b < B; b++)
#pragma unroll
    for (int j = 0; j < 4; j++) um[j] |= masks[b * 4 + j];
  if (tid < 128) {
    int e = tid, wi = e >> 5;
    if ((um[wi] >> (e & 31)) & 1) {
      int slot = __popc(um[wi] & ((1u << (e & 31)) - 1));
      for (int j = 0; j < wi; j++) slot += __popc(um[j]);
      D.slot_expert[slot] = e;
    }
  }
  if (warp < B && lane < TOPK) {
    const int b = warp;
    int e = sel[b * 8 + lane], wi = e >> 5;
    uint32_t below = (1u << (e & 31)) - 1;
    int slot = __popc(um[wi] & below), rank = __popc(masks[b * 4 + wi] & below);
    for (int j = 0; j < wi; j++) { slot += __popc(um[j]); rank += __popc(masks[b * 4 + j]); }
    float lg = selv[b * 8 + lane];
    D.bslot[b][rank] = slot;
    D.bw[b][rank] = rbf(1.0f / (1.0f + expf(-lg)));
  }
  if (tid == 0) D.U = __popc(um[0]) + __popc(um[1]) + __popc(um[2]) + __popc(um[3]);
  __threadfence();
  __syncthreads();
}

__global__ void __launch_bounds__(512, 1) mk_kernel(Launch A) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Model* M = A.M;
  Ctl* C = M->ctl;
  const int tid = threadIdx.x;
  const int B = A.B;
  Smem sm;
  {
    const int ctx = M->max_ctx;
    unsigned char* p = smraw;
    sm.S = (float*)p; p += 8 * ctx * 4;
    sm.Pm = (uint16_t*)p; p += 8 * (ctx + 128) * 2;
    sm.Qs = (uint16_t*)p; p += 8 * 128 * 2;
    sm.O = (float*)p; p += 2 * 8 * 128 * 4;
    sm.R = (float*)p; p += 512 * 4;
    sm.Mx = (float*)p; p += 8 * 4;
    sm.W = (uint32_t*)p;
  }
  float* logits = A.gen ? M->logits : A.logits_out;
  const int nst = A.gen ? NST_STEP + 1 : NST_STEP;
  if (blockIdx.x != 0) {
    // ---- worker blocks
    uint32_t seq = A.seq0;
    for (;;) {
      if (tid == 0) { uint32_t s; do { s = vload(&C->pub_seq); } while (s == seq); sm.W[1] = s; sm.W[2] = vload(&C->exit_id); }
      __syncthreads();
      seq = sm.W[1];
      if (sm.W[2] == A.launch_id) return;
      const uint32_t k = seq - A.seq0 - 1;
      run_stage(M, sm, (int)(k % nst), B, A.pos + (int)(k / nst), logits);
    }
  }
  // ---- leader block
  uint32_t seq = A.seq0;
#define STAGE(pc_)                                                                                          \
  {                                                                                                         \
    const int pc__ = (pc_);                                                                                 \
    if (tid == 0) { C->ctr[pc__] = 0; C->bctr[pc__] = 0; C->done[pc__] = 0; __threadfence(); C->pub_seq = seq + 1; } \
    seq++;                                                                                                  \
    __syncthreads();                                                                                        \
    run_stage(M, sm, pc__, B, pos, logits);                                                                 \
    if (tid == 0) { const uint32_t need = n_tile_tasks(M, pc__, B) + n_block_tasks(pc__, B); while (vload(&C->done[pc__]) != need) {} } \
    __syncthreads();                                                                                        \
  }
  for (int step = 0; step < A.nsteps; step++) {
    const int pos = A.pos + step;
    // embedding
    for (int b = 0; b < B; b++) {
      int64_t tk = (step == 0) ? A.tok_in[(size_t)b * A.tok_stride] : M->curtok[b];
      const uint16_t* e = M->embed + (size_t)tk * HID;
      for (int i = tid; i < HID; i += 512) M->x[(size_t)b * HID + i] = e[i];
    }
    __threadfence();
    __syncthreads();
    for (int l = 0; l < NLAYER; l++) {
      if (M->dbg_x) { for (int b = 0; b < B; b++) for (int i = tid; i < HID; i += 512) M->dbg_x[((size_t)l * MAXB + b) * HID + i] = M->x[(size_t)b * HID + i]; }
      leader_norm(M, sm, M->L[l].normw, B);
      STAGE(4 * l + 0);
      if (M->L[l].dense) { if (tid == 0) { M->dyn[l].U = 1; M->dyn[l].slot_expert[0] = 0; } __syncthreads(); }
      else leader_route(M, sm, l, B);
      STAGE(4 * l + 1);
      STAGE(4 * l + 2);
      STAGE(4 * l + 3);
    }
    if (M->dbg_x) { for (int b = 0; b < B; b++) for (int i = tid; i < HID; i += 512) M->dbg_x[((size_t)NLAYER * MAXB + b) * HID + i] = M->x[(size_t)b * HID + i]; }
    leader_norm(M, sm, M->normf, B);
    STAGE(PC_HEAD);
    if (A.gen) {
      STAGE(PC_ARG);
      const int lane = tid & 31, warp = tid >> 5;
      if (warp < B) {
        float best = -INFINITY; int bi = 0x7fffffff;
#pragma unroll
        for (int j = 0; j < 4; j++) {
          float v = M->candv[warp * 128 + lane + 32 * j]; int ix = M->candi[warp * 128 + lane + 32 * j];
          if (v > best || (v == best && ix < bi)) { best = v; bi = ix; }
        }
        for (int o = 16; o > 0; o >>= 1) {
          float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
          if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
        }
        if (lane == 0) { M->curtok[warp] = bi; A.tok_out[(size_t)warp * A.nsteps + step] = bi; }
      }
      __threadfence();
      __syncthreads();
    }
  }
  if (tid == 0) { C->exit_id = A.launch_id; __threadfence(); C->pub_seq = seq + 1; }
}

// ---------------------------------------------------------------------------------------------------------
// host side
static Model* g_model_dev = nullptr;
static uint32_t g_seq = 0, g_launch = 1;
static int g_smem = 0;
static int g_blocks = 132;

extern "C" {

int mk_sizeof_model() { return (int)sizeof(Model); }
int mk_sizeof_ctl() { return (int)sizeof(Ctl); }
int mk_sizeof_dyn() { return (int)sizeof(Dyn); }
int mk_sizeof_layer() { return (int)sizeof(LayerW); }

// model_host: a filled Model struct (device pointers inside); model_dev: device memory to hold it
int mk_init(const void* model_host, void* model_dev, int max_ctx) {
  cudaError_t e = cudaMemcpy(model_dev, model_host, sizeof(Model), cudaMemcpyHostToDevice);
  if (e != cudaSuccess) { fprintf(stderr, "mk_init memcpy: %s\n", cudaGetErrorString(e)); return 1; }
  g_model_dev = (Model*)model_dev;
  g_smem = 8 * max_ctx * 4 + 8 * (max_ctx + 128) * 2 + 8 * 128 * 2 + 2 * 8 * 128 * 4 + 512 * 4 + 8 * 4 + 256 * 4;
  if (g_smem < 120 * 1024) g_smem = 120 * 1024;  // more than half an SM's shared memory: one block per SM
  e = cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, g_smem);
  if (e != cudaSuccess) { fprintf(stderr, "mk_init smem %d: %s\n", g_smem, cudaGetErrorString(e)); return 2; }
  int dev = 0; cudaGetDevice(&dev);
  cudaDeviceProp prop; cudaGetDeviceProperties(&prop, dev);
  g_blocks = prop.multiProcessorCount;
  g_seq = 0; g_launch = 1;
  return 0;
}

static int launch(const int64_t* tok_in, int tok_stride, float* logits_out, int64_t* tok_out, int B, int pos, int nsteps, int gen) {
  Launch A;
  A.M = g_model_dev; A.tok_in = tok_in; A.logits_out = logits_out; A.tok_out = tok_out;
  A.B = B; A.pos = pos; A.nsteps = nsteps; A.gen = gen; A.tok_stride = tok_stride; A.seq0 = g_seq; A.launch_id = g_launch;
  mk_kernel<<<g_blocks, 512, g_smem, 0>>>(A);
  g_seq += (uint32_t)nsteps * (gen ? NST_STEP + 1 : NST_STEP) + 1;
  g_launch++;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) { fprintf(stderr, "mk launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}

int mk_step(const int64_t* tok_in, int tok_stride, float* logits_out, int B, int pos) { return launch(tok_in, tok_stride, logits_out, nullptr, B, pos, 1, 0); }
int mk_generate(const int64_t* tok_in, int tok_stride, int64_t* tok_out, int B, int pos, int nsteps) { return launch(tok_in, tok_stride, nullptr, tok_out, B, pos, nsteps, 1); }

}  // extern "C"
