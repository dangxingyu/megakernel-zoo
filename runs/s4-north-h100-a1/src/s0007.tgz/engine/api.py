"""North-Mini-Code-1.0 decode engine: one persistent CUDA kernel per step (engine/mk.cu).

This file only loads the checkpoint into the kernel's memory layout and launches the kernel; no model code of
any library runs in the timed path.

Layout (track A: every weight keeps its BF16 bits; only the order in memory changes): each matrix is stored in
tensor-core fragment order, 16x16 tiles, 512 bytes per tile, so that one 16-byte load per thread feeds one mma.
"""
import ctypes
import json
import os
import struct
import time

import torch

HID, NLAYER, TOPK, MAXB, MAXU, VOCAB = 2048, 49, 8, 8, 64, 262144
PART_ROWS, HMAX = 5248, 3072
HERE = os.path.dirname(os.path.abspath(__file__))


class LayerW(ctypes.Structure):
    _fields_ = [("qkv", ctypes.c_void_p), ("router", ctypes.c_void_p), ("o", ctypes.c_void_p), ("expert", ctypes.c_void_p),
                ("normw", ctypes.c_void_p), ("exp_stride", ctypes.c_uint64),
                ("gu_tiles", ctypes.c_int), ("down_K", ctypes.c_int), ("rope", ctypes.c_int), ("dense", ctypes.c_int)]


PTRS = ["head", "embed", "normf", "rope", "kc", "vc", "x", "qkvo", "qkvp", "rl", "attn", "attp", "h", "logits", "candv",
        "candi", "curtok", "zeros", "ctl", "dyn", "dbg_x", "force", "prof"]


class Model(ctypes.Structure):
    _fields_ = [("L", LayerW * NLAYER)] + [(n, ctypes.c_void_p) for n in PTRS] + [("max_ctx", ctypes.c_int), ("maxK", ctypes.c_int)]


def frag(w: torch.Tensor) -> torch.Tensor:
    """[..., M, N] -> mma A-operand order [..., M/16, N/16, 32 lanes, 4 regs, 2]: lane = 4*(row%8) + (col%8)//2,
    reg = 2*((col%16)//8) + (row%16)//8."""
    lead = w.shape[:-2]
    M, N = w.shape[-2:]
    v = w.reshape(*lead, M // 16, 2, 8, N // 16, 2, 4, 2)
    n = len(lead)
    return v.permute(*range(n), n + 0, n + 3, n + 2, n + 5, n + 4, n + 1, n + 6)


def tiles_bf16(w: torch.Tensor) -> torch.Tensor:
    """Track A tiles of a [M, N] BF16 matrix: [M/16, N/16 * 512] bytes, the checkpoint's bits in fragment order."""
    M, N = w.shape
    return frag(w.contiguous().view(torch.int16)).reshape(M // 16, -1).contiguous().view(torch.uint8)


def exb(K: int) -> int:
    return 128 if K == 48 else 256


def tiles_w12(w: torch.Tensor, cshift: torch.Tensor | None = None, hdr_shift: torch.Tensor | None = None, verify: bool = False):
    """Track B tiles of a [M, N] BF16 matrix (see engine/mk.cu): [M/16, N/16 * 384 + exb] bytes and (escapes, weights).
    W[i][j] = 2^(r_i + c_j) V[i][j]; V keeps sign and mantissa and has the exponent code 1..15 (0: the weight is 0
    in the tile). cshift: [M, N]-broadcastable integer c_j per element (None: 0). hdr_shift: [M/16, 8] int8 written to
    header bytes 16..23 (the gate|up tiles carry their neurons' down-column shifts there).
    Header: bytes 0..15 r_i, 16..23 shifts, 24..31 the end of each row group's entries (entries are sorted by
    row % 8), then the entries [value:16 | k-step:8 | row:4 | col:4]; an entry's value is the true weight divided by
    2^c_j, as BF16 bits."""
    M, N = w.shape
    R, K = M // 16, N // 16
    EXB, dev = exb(K), w.device
    EXN = (EXB - 32) // 4
    bits = w.contiguous().view(torch.int16).to(torch.int32) & 0xFFFF
    E = (bits >> 7) & 0xFF
    nz = (bits & 0x7FFF) != 0
    assert not bool(((E == 0) & nz).any()) and not bool((E == 255).any()), "denormal, infinite or NaN weight"
    Ea = E - cshift.to(torch.int32) if cshift is not None else E
    # the window of 15 exponent values that covers most of each row
    hist = torch.zeros((M, 512), dtype=torch.int32, device=dev)
    hist.scatter_add_(1, torch.where(nz, Ea + 128, torch.zeros_like(Ea)).long(), torch.ones_like(Ea))
    hist[:, 0] = 0
    cs = torch.cat([torch.zeros((M, 1), dtype=torch.int32, device=dev), hist.cumsum(1, dtype=torch.int32)], 1)
    lo = (cs[:, 15:] - cs[:, :-15]).argmax(1).to(torch.int32)          # window [lo, lo + 15) in the shifted index
    del hist, cs
    r = lo - 128 - 1                                                    # code = Ea - r in 1..15
    assert int(r.min()) >= 0 and int(r.max()) <= 222
    code = Ea - r[:, None]
    inw = nz & (code >= 1) & (code <= 15)
    scaled = torch.where(inw, (bits & 0x8000) | (code << 7) | (bits & 0x7F), torch.zeros_like(bits))
    esc = nz & ~inw
    idx = esc.nonzero()
    row, col = idx[:, 0], idx[:, 1]
    # within a tile the entries are sorted by row % 8 (the lanes of one row pair read only their own)
    order = torch.argsort((row // 16) * 8 + (row % 8), stable=True)
    row, col = row[order], col[order]
    tile = row // 16
    counts = torch.bincount(tile, minlength=R)
    assert int(counts.max()) <= EXN, f"a tile has {int(counts.max())} escapes, the header holds {EXN}"
    ea = Ea[row, col]
    assert idx.shape[0] == 0 or (int(ea.min()) >= 1 and int(ea.max()) <= 254)
    val = (bits[row, col] & 0x807F) | (ea << 7)
    entry = (val << 16) | ((col // 16) << 8) | ((row % 16) << 4) | (col % 16)
    rank = torch.arange(idx.shape[0], device=dev) - (counts.cumsum(0) - counts)[tile]
    hdr = torch.zeros((R, EXB), dtype=torch.uint8, device=dev)
    hdr[:, 0:16] = r.view(R, 16).to(torch.uint8)
    if hdr_shift is not None:
        hdr[:, 16:24] = hdr_shift.to(torch.int8).view(torch.uint8)
    grp = torch.bincount(tile * 8 + (row % 8), minlength=R * 8).view(R, 8)
    hdr[:, 24:32] = grp.cumsum(1).to(torch.uint8)                       # where each row group's entries end
    h32 = torch.zeros((R, EXN), dtype=torch.int32, device=dev)
    h32[tile, rank] = entry.to(torch.int32)
    hdr[:, 32:] = h32.view(torch.uint8)
    # per thread and pair of k-steps: 16 low bytes, 16 high nibbles
    f = frag(scaled.to(torch.int16)).reshape(R, K // 2, 2, 32, 8).permute(0, 1, 3, 2, 4).reshape(R, K // 2, 32, 16).to(torch.int32)
    lo8 = (f & 0xFF).to(torch.uint8)
    nib = ((f >> 12) & 8) | ((f >> 8) & 7)
    hi8 = (nib[..., 0::2] | (nib[..., 1::2] << 4)).to(torch.uint8)
    out = torch.cat([torch.cat([lo8.reshape(R, K // 2, 512), hi8.reshape(R, K // 2, 256)], 2).reshape(R, K * 384), hdr], 1)
    if verify:
        back = untile_w12(out, M, N, cshift)
        assert bool((back == bits).all()), "12-bit tiles do not decode to the checkpoint's bits"
    return out, int(idx.shape[0]), int(nz.sum())


def untile_w12(t: torch.Tensor, M: int, N: int, cshift: torch.Tensor | None = None) -> torch.Tensor:
    """Inverse of tiles_w12: the BF16 bit patterns [M, N] (int32), from the tile bytes alone (plus the column shifts)."""
    R, K = M // 16, N // 16
    EXB = exb(K)
    data, hdr = t[:, :K * 384].reshape(R, K // 2, 768), t[:, K * 384:]
    lo8 = data[:, :, :512].reshape(R, K // 2, 32, 16).to(torch.int32)
    hi8 = data[:, :, 512:].reshape(R, K // 2, 32, 8).to(torch.int32)
    nib = torch.stack([hi8 & 15, hi8 >> 4], -1).reshape(R, K // 2, 32, 16)
    sc = lo8 | ((nib & 7) << 8) | ((nib & 8) << 12)                      # sign | code << 7 | mantissa
    # back from fragment order: [R, K/2, 32, 16] -> [R, K, 32, 4, 2] -> [M, N]
    v = sc.reshape(R, K // 2, 32, 2, 8).permute(0, 1, 3, 2, 4).reshape(R, K, 8, 4, 2, 2, 2)   # R, K, g, t, ch, rh, j
    sc = v.permute(0, 5, 2, 1, 4, 3, 6).reshape(M, N)
    r = hdr[:, 0:16].to(torch.int32).reshape(M)
    code = (sc >> 7) & 0xFF
    Ea = code + r[:, None]
    E = Ea + cshift.to(torch.int32) if cshift is not None else Ea
    bits = torch.where(code > 0, (sc & 0x807F) | (E << 7), torch.zeros_like(sc))
    h32 = hdr[:, 32:].contiguous().view(torch.int32)
    counts = hdr[:, 31].long()
    EXN = h32.shape[1]
    live = torch.arange(EXN, device=t.device)[None, :] < counts[:, None]
    tl, k = live.nonzero()[:, 0], live.nonzero()[:, 1]
    e = h32[tl, k].to(torch.int64) & 0xFFFFFFFF
    row = tl * 16 + ((e >> 4) & 15)
    col = ((e >> 8) & 255) * 16 + (e & 15)
    val = (e >> 16).to(torch.int32)
    ev = (val >> 7) & 0xFF
    if cshift is not None:
        ev = ev + cshift.to(torch.int32).expand(M, N)[row, col]
    bits[row, col] = (val & 0x807F) | (ev << 7)
    return bits


def read_shard(path: str, device: str) -> dict:
    """All tensors of one safetensors shard as BF16 views of a single device buffer."""
    with open(path, "rb") as f:
        n = struct.unpack("<Q", f.read(8))[0]
        header = json.loads(f.read(n))
        import numpy as np
        raw = np.fromfile(f, dtype=np.int16)
    buf = torch.from_numpy(raw).to(device)
    out = {}
    for name, info in header.items():
        if name == "__metadata__":
            continue
        assert info["dtype"] == "BF16", (name, info["dtype"])
        a, b = info["data_offsets"]
        out[name] = buf[a // 2:b // 2].view(torch.bfloat16).view(*info["shape"])
    return out


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        assert max_batch <= MAXB, "this engine is built for batches up to 8"
        t0 = time.time()
        self.dev = "cuda"
        torch.cuda.init()
        self.lib = ctypes.CDLL(os.path.join(HERE, "libmk.so"))
        assert self.lib.mk_sizeof_model() == ctypes.sizeof(Model), (self.lib.mk_sizeof_model(), ctypes.sizeof(Model))
        self.max_ctx = max(128, (max_context + 127) // 128 * 128)
        assert self.max_ctx <= 2048, "contexts beyond 2048 tokens are not implemented in this build"
        self.maxK = self.max_ctx // 16
        self.keep = {}
        m = Model()
        # ---- arena layout (bytes). Track A: 512 B per k-step; track B: 384 B per k-step + a header per tile.
        self.w12 = open(os.path.join(HERE, "TRACK")).read().strip() == "B"
        assert bool(self.lib.mk_is_w12()) == self.w12, "libmk.so was built for the other track: run engine/build.sh"
        verify = bool(os.environ.get("MK_VERIFY"))
        tby = (lambda K: K * 384 + exb(K)) if self.w12 else (lambda K: K * 512)
        geo = [(1, 384, 192)] + [(128, 96, 48)] * (NLAYER - 1)  # experts, gate|up tiles, down K
        off, lay = 0, []
        for l in range(NLAYER):
            ne, gt, dk = geo[l]
            stride = gt * tby(128) + 128 * tby(dk)
            d = {"qkv": off}; off += 320 * tby(128)
            d["router"] = off; off += 8 * tby(128) if l else 0
            d["o"] = off; off += 128 * tby(256)
            d["expert"] = off; off += ne * stride
            d["stride"] = stride
            lay.append(d)
        head_off = off; off += (VOCAB // 16) * tby(128)
        arena = torch.empty(off + 4096, dtype=torch.uint8, device=self.dev)
        self.keep["arena"] = arena
        base = arena.data_ptr()
        normw = torch.empty((NLAYER + 1, HID), dtype=torch.bfloat16, device=self.dev)
        embed = torch.empty((VOCAB, HID), dtype=torch.bfloat16, device=self.dev)
        self.keep.update(normw=normw, embed=embed)
        st = {"escapes": 0, "weights": 0, "dead_neurons": 0, "min_shift": 0}

        def put(o, w, cshift=None, hdr_shift=None):
            """Tiles of the [M, N] matrix w at arena offset o; returns the bytes written."""
            if self.w12:
                t, ne_, nw_ = tiles_w12(w, cshift, hdr_shift, verify)
                st["escapes"] += ne_; st["weights"] += nw_
            else:
                t = tiles_bf16(w)
            t = t.reshape(-1)
            arena[o:o + t.numel()] = t
            return t.numel()

        def layer_ready(l, have):
            p = f"model.layers.{l}."
            if p + "self_attn.q_proj.weight" not in have or p + "self_attn.o_proj.weight" not in have or p + "input_layernorm.weight" not in have:
                return False
            if p + "self_attn.k_proj.weight" not in have or p + "self_attn.v_proj.weight" not in have:
                return False
            if l == 0:
                return all(p + f"mlp.{k}_proj.weight" in have for k in ("gate", "up", "down"))
            if p + "mlp.gate.weight" not in have:
                return False
            return all(p + f"mlp.experts.{e}.{k}_proj.weight" in have for e in (0, 63, 127) for k in ("gate", "up", "down")) and \
                sum(1 for k in have if k.startswith(p + "mlp.experts.")) == 384

        def do_layer(l, have):
            p = f"model.layers.{l}."
            g = lambda n: have.pop(p + n)
            d = lay[l]
            put(d["qkv"], torch.cat([g("self_attn.q_proj.weight"), g("self_attn.k_proj.weight"), g("self_attn.v_proj.weight")], 0))
            put(d["o"], g("self_attn.o_proj.weight"))
            normw[l] = g("input_layernorm.weight")
            ne, gt, dk = geo[l]
            if l > 0:
                put(d["router"], g("mlp.gate.weight"))
            nn = gt * 8                                           # neurons per expert
            for e0 in range(0, ne, 32):                           # experts in groups of 32 (memory)
                es = range(e0, min(ne, e0 + 32))
                n = len(es)
                name = (lambda e, k: f"mlp.{k}_proj.weight") if l == 0 else (lambda e, k: f"mlp.experts.{e}.{k}_proj.weight")
                gate = torch.stack([g(name(e, "gate")) for e in es])
                up = torch.stack([g(name(e, "up")) for e in es])
                down = torch.stack([g(name(e, "down")) for e in es])       # [n, HID, nn]
                gu = torch.stack([gate.view(n, gt, 8, HID), up.view(n, gt, 8, HID)], 2).reshape(n * gt * 16, HID)
                del gate, up
                cd = hs = None
                if self.w12:
                    # one shift per neuron: its down column's median exponent against the expert's largest (1210 neurons in
                    # 14 experts have down columns 2^20 .. 2^62 below the rest: study/dead_neurons.py)
                    ed = ((down.view(torch.int16).to(torch.int32) >> 7) & 0xFF).float()
                    med = ed.median(1).values                              # [n, nn]
                    cdn = (med - med.max(1, keepdim=True).values).round().to(torch.int32).clamp(-90, 0)   # (h is stored times 2^(96 + shift))
                    del ed
                    st["dead_neurons"] += int((cdn <= -8).sum()); st["min_shift"] = min(st["min_shift"], int(cdn.min()))
                    cd = cdn[:, None, :].expand(n, HID, nn).reshape(n * HID, nn)
                    hs = cdn.reshape(n * gt, 8)
                tg = put_view(gu, None, hs)
                try:
                    td = put_view(down.reshape(n * HID, nn), cd, None)
                except AssertionError as err:
                    raise AssertionError(f"layer {l} experts {e0}..: {err}; shifts {int(cdn.min())}..{int(cdn.max())}")
                del gu, down
                blk = torch.cat([tg.view(n, -1), td.view(n, -1)], 1).reshape(-1)
                o = d["expert"] + e0 * d["stride"]
                arena[o:o + blk.numel()] = blk
                del blk, tg, td

        def put_view(w, cshift, hdr_shift):
            if self.w12:
                t, ne_, nw_ = tiles_w12(w, cshift, hdr_shift, verify)
                st["escapes"] += ne_; st["weights"] += nw_
                return t
            return tiles_bf16(w)

        index = json.load(open(os.path.join(model_dir, "model.safetensors.index.json")))["weight_map"]
        shards = sorted(set(index.values()))
        have, todo = {}, list(range(NLAYER))
        for s in shards:
            have.update(read_shard(os.path.join(model_dir, s), self.dev))
            if "model.embed_tokens.weight" in have:
                e = have.pop("model.embed_tokens.weight")
                embed.copy_(e)
                for r0 in range(0, VOCAB, 32768):
                    put(head_off + r0 // 16 * tby(128), e[r0:r0 + 32768])
                del e
            if "model.norm.weight" in have:
                normw[NLAYER] = have.pop("model.norm.weight")
            while todo and layer_ready(todo[0], have):
                do_layer(todo.pop(0), have)
        assert not todo and not have, (todo, list(have)[:5])
        del have
        torch.cuda.empty_cache()
        self.pack_stats = dict(st, verified_bit_for_bit=verify, arena_bytes=off)
        # ---- tables and scratch
        K = self.keep
        inv_freq = 1.0 / (50000 ** (torch.arange(0, 128, 2, dtype=torch.float, device=self.dev) / 128))
        fr = torch.arange(self.max_ctx, device=self.dev)[:, None].float() * inv_freq[None]
        K["rope"] = torch.stack([fr.cos().to(torch.bfloat16).float(), fr.sin().to(torch.bfloat16).float()], -1).contiguous()
        z = lambda *shape, dtype=torch.int16: torch.zeros(shape, dtype=dtype, device=self.dev)
        kvn = NLAYER * MAXB * 4 * self.maxK * 256 * 8
        K["kc"], K["vc"] = z(kvn), z(kvn)
        K["x"] = z(MAXB * HID)
        K["qkvo"] = z(MAXB * 5120)
        K["qkvp"] = z(2 * MAXB * 5120, dtype=torch.float32)
        K["rl"] = z(2 * MAXB * 128 * 2, dtype=torch.int32)
        K["attn"] = z(MAXB * 4096)
        K["attp"] = z(32 * 8 * 1040, dtype=torch.float32)
        K["h"] = z(MAXU * MAXB * HMAX + 4096)
        K["logits"] = z(MAXB * VOCAB, dtype=torch.float32)
        K["candv"] = z(MAXB * 256, dtype=torch.float32)
        K["candi"] = z(MAXB * 256, dtype=torch.int32)
        K["curtok"] = z(MAXB, dtype=torch.int64)
        K["zeros"] = z(16384)
        K["ctl"] = z(self.lib.mk_sizeof_ctl(), dtype=torch.uint8)
        K["dyn"] = z(NLAYER * self.lib.mk_sizeof_dyn(), dtype=torch.uint8)
        K["dyn"][:4] = torch.tensor([1, 0, 0, 0], dtype=torch.uint8)  # layer 0 is dense: one "expert", slot 0
        K["modeldev"] = z(ctypes.sizeof(Model) + 64, dtype=torch.uint8)
        for l in range(NLAYER):
            ne, gt, dk = geo[l]
            L, d = m.L[l], lay[l]
            L.qkv, L.router, L.o, L.expert = base + d["qkv"], base + d["router"], base + d["o"], base + d["expert"]
            L.normw = normw[l].data_ptr()
            L.exp_stride = d["stride"]
            L.gu_tiles, L.down_K, L.dense = gt, dk, int(l == 0)
            L.rope = int(l == 0 or l % 4 != 0)
        m.head, m.embed, m.normf = base + head_off, embed.data_ptr(), normw[NLAYER].data_ptr()
        for n in PTRS[3:20]:
            setattr(m, n, K[n].data_ptr())
        m.dbg_x, m.force, m.prof = None, None, None
        m.max_ctx, m.maxK = self.max_ctx, self.maxK
        self.m = m
        self._commit()
        self.pos = 0
        self.pending, self.active, self.max_batch = [], None, max_batch
        self.calls = {"step": 0, "generate": 0}
        self.load_seconds = time.time() - t0

    def _commit(self):
        torch.cuda.synchronize()
        rc = self.lib.mk_init(ctypes.byref(self.m), ctypes.c_void_p(self.keep["modeldev"].data_ptr()), self.max_ctx)
        assert rc == 0, rc
        self.keep["ctl"].zero_()
        torch.cuda.synchronize()

    def reset(self) -> None:
        self.pos = 0

    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        B = tokens.shape[0]
        if tokens.dtype != torch.int64:
            tokens = tokens.to(torch.int64)
        logits = torch.empty((B, VOCAB), dtype=torch.float32, device=self.dev)
        rc = self.lib.mk_step(ctypes.c_void_p(tokens.data_ptr()), tokens.stride(0), ctypes.c_void_p(logits.data_ptr()), B, self.pos)
        assert rc == 0
        self.pos += 1
        self.calls["step"] += 1
        return logits

    def generate(self, tokens: torch.Tensor, n_steps: int) -> torch.Tensor:
        B = tokens.shape[0]
        if tokens.dtype != torch.int64:
            tokens = tokens.to(torch.int64)
        out = torch.empty((B, n_steps), dtype=torch.int64, device=self.dev)
        rc = self.lib.mk_generate(ctypes.c_void_p(tokens.data_ptr()), tokens.stride(0), ctypes.c_void_p(out.data_ptr()), B, self.pos, n_steps)
        assert rc == 0
        self.pos += n_steps
        self.calls["generate"] += 1
        return out

    # ---- the online contract of the HTTP server: the whole decode of a cohort is one kernel launch on the device
    GATHER_S = 0.03   # how long the first request of a cohort waits for others that arrive with it

    def submit(self, rid: int, prompt, n: int) -> None:
        self.pending.append((int(rid), [int(t) for t in prompt], int(n), time.perf_counter()))

    def poll(self):
        if self.active is None:
            if not self.pending:
                return []
            first = self.pending[0]
            group = [r for r in self.pending if len(r[1]) == len(first[1]) and r[2] == first[2]][:self.max_batch]
            if len(group) < self.max_batch and time.perf_counter() - first[3] < self.GATHER_S:
                return []
            self.pending = [r for r in self.pending if all(r is not g for g in group)]
            B, P, n = len(group), len(first[1]), first[2]
            assert 1 <= P and P + n <= self.max_ctx, "prompt + new tokens exceed the engine's context"
            prompt = torch.tensor([r[1] for r in group], dtype=torch.int64, device=self.dev)
            out = torch.empty((n, B), dtype=torch.int64, device=self.dev)
            torch.cuda.synchronize()
            rc = self.lib.mk_serve_start(ctypes.c_void_p(prompt.data_ptr()), P, ctypes.c_void_p(out.data_ptr()), B, P, n)
            assert rc == 0
            self.host = (ctypes.c_int64 * (n * B))()
            self.active = {"rids": [r[0] for r in group], "B": B, "n": n, "sent": 0, "prompt": prompt, "out": out}
            self.pos = P - 1 + n
            self.calls["serve"] = self.calls.get("serve", 0) + 1
            return []
        a = self.active
        prog = self.lib.mk_serve_poll()
        if prog <= a["sent"]:
            return []
        k0, B = a["sent"], a["B"]
        rc = self.lib.mk_serve_fetch(ctypes.c_void_p(a["out"].data_ptr()), ctypes.byref(self.host, k0 * B * 8), B, k0, prog)
        assert rc == 0
        done = prog == a["n"]
        events = [(rid, [self.host[k * B + i] for k in range(k0, prog)], done) for i, rid in enumerate(a["rids"])]
        a["sent"] = prog
        if done:
            self.active = None
        return events

    def close(self) -> None:
        torch.cuda.synchronize()
        self.keep = {}

    def stats(self) -> dict:
        impl = ("megakernel v6, track B: 12-bit weights (row exponents, neuron shifts for the down columns, exact escapes)" if self.w12
                else "megakernel v6, track A: BF16 weights in mma fragment order")
        return {"implementation": impl, "load_seconds": self.load_seconds, "pack": self.pack_stats, **self.calls}
