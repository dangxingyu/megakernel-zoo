#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
NVCC="${CUDA_HOME:-/usr/local/cuda}/bin/nvcc"
[ -x "$NVCC" ] || NVCC=nvcc
if [ ! -f libmk.so ] || [ mk.cu -nt libmk.so ] || [ build.sh -nt libmk.so ] || [ -n "${MK_DEFS:-}" ]; then
  "$NVCC" -O3 -std=c++17 -arch=sm_90 -Xptxas -v ${MK_DEFS:-} -Xcompiler -fPIC -shared -o libmk.so.tmp mk.cu
  mv libmk.so.tmp libmk.so
fi
