// North-Mini-Code-1.0 decode megakernel for one H100.
//
// One persistent kernel per step() (or per generate() call): 132 blocks x 16 warps, one block per SM.
// Every block walks the same static program; nothing is claimed dynamically. The unit of work is a quantum:
// 8 k-steps (4 KB) of one 16-row tile.
// Per layer:
//   prologue  every block reads the residual and computes the RMSNorm into its own shared memory
//   A         q|k|v and router rows: every warp of blocks 1..131 reads 20 k-steps (router rows first); block 0
//             takes the top 8 per sequence as soon as the router rows are in and publishes the union of experts
//   B         blocks 1..4B: attention of one (sequence, K/V head) each; the others: gate|up of the chosen experts,
//             each block's tiles dealt as quanta to its 16 warps and summed in shared memory
//   C         block r < 128 owns residual rows 16r..16r+15: o_proj and the down rows of every chosen expert as
//             quanta, summed in shared memory and added to the residual
// Blocks meet only through monotonic counters (router rows done, A done, route published, B done, C done).
// Every matrix product is a tensor-core m16n8k16 whose A operand is read straight from memory in fragment
// order and whose B operand holds the batch in its 8 columns: batch 1 and batch 8 run the same instructions, and
// every sum has a fixed order that does not depend on the batch.
//
// Model facts used (CohereLabs/North-Mini-Code-1.0): parallel block (attention and MLP read the same normed
// input), 8 of 128 experts per token, 4 K/V heads x 8 query heads (the 8 query heads of a K/V head are the 8
// columns of an mma), tied head.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#define HID 2048
#define NLAYER 49
#define TOPK 8
#define MAXB 8
#define MAXU 64
#define VOCAB 262144
#define QKV_ROWS 5120
#define PART_ROWS 5248  // q 4096, k 512, v 512, router 128
#define FULL_TILES 262   // stage A: tiles 0..261 are done whole by one block, tiles 262..327 (the last 8: router) in two halves
#define SHARED_ROW0 (FULL_TILES * 16)
#define TB 12           // gate|up tiles per shared-memory batch
#define QB 192          // quanta per shared-memory batch
#define HMAX 3072
#define SCALE 0.08838834764831845f
#define CTX 2048        // largest context this build's shared-memory layout holds

struct LayerW {
  const uint4* qkv;     // 320 row tiles, K = 128 k-steps
  const uint4* router;  // 8 row tiles, K = 128 (unused in layer 0)
  const uint4* o;       // 128 row tiles, K = 256
  const uint4* expert;  // expert e at expert + e * exp_stride: gate|up interleaved (gu_tiles x 128), then down (128 x down_K)
  const uint16_t* normw;
  uint64_t exp_stride;  // in uint4 units
  int gu_tiles, down_K, rope, dense;
};

struct Ctl {  // monotonic counters and sequence words; every wait is "word >= target"
  uint32_t tok_seq; uint32_t pad0[15];
  uint32_t route_seq; uint32_t pad1[15];
  uint32_t cntA; uint32_t pad2[15];
  uint32_t cntB; uint32_t pad3[15];
  uint32_t cntC; uint32_t pad4[15];
  uint32_t cntH; uint32_t pad5[15];
  uint32_t cntR; uint32_t pad6[15];
};

struct Dyn {
  int U;
  int slot_expert[MAXU];
  int bslot[MAXB][TOPK];
  float bw[MAXB][TOPK];
  int bmask[MAXU];  // which sequences use the expert of a slot
};

struct Model {
  LayerW L[NLAYER];
  const uint4* head;
  const uint16_t* embed;
  const uint16_t* normf;
  const float* rope;  // [ctx][64][2]
  uint4* kc; uint4* vc;
  uint16_t* x; uint16_t* qkvo; float* qkvp; uint2* rl; uint16_t* attn; uint16_t* h;
  float* logits; float* candv; int* candi; int64_t* curtok;
  const uint32_t* zeros;
  Ctl* ctl; Dyn* dyn;
  uint16_t* dbg_x;     // optional [NLAYER+1][MAXB][HID]
  const int* force;    // optional [NLAYER][MAXB][TOPK] forced expert ids (debug)
  long long* prof;     // optional [32] cycle counters of the leader's SM (debug)
  int max_ctx, maxK;
};

struct Launch {
  const Model* M;
  const int64_t* tok_in;
  float* logits_out;
  int64_t* tok_out;
  int B, pos, nsteps, gen, tok_stride;
  uint32_t g0, s0, h0;  // layers, steps and generate-steps completed before this launch
};

#define MMA(c0, c1, c2, c3, a, b0, b1)                                                                          \
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
               : "+f"(c0), "+f"(c1), "+f"(c2), "+f"(c3)                                                         \
               : "r"((a).x), "r"((a).y), "r"((a).z), "r"((a).w), "r"(b0), "r"(b1))

__device__ __forceinline__ float bf2f(uint16_t v) { return __uint_as_float(((uint32_t)v) << 16); }
__device__ __forceinline__ uint16_t f2bf(float f) {
  uint32_t u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (uint16_t)(u >> 16);
}
__device__ __forceinline__ float rbf(float f) { return bf2f(f2bf(f)); }
__device__ __forceinline__ uint32_t vload(const uint32_t* p) { return *(const volatile uint32_t*)p; }

// a quantum: 8 k-steps (4 KB) of a 16-row tile, read with QU loads in flight per thread. Under a saturated HBM
// queue the latency of EVERY memory operation of every SM (a poll, an atomic, a store) is about
// (bytes in flight) / (3.1 TB/s) (bench/l2_bench2.cu: 2-3 us with 16 loads in flight per thread, a __threadfence
// 10 us), so the queue is kept shallow: 16 warps per SM x QU loads x 512 B still saturates the card.
#ifndef QU
#define QU 2
#endif
#ifndef FENCE
#define FENCE() __threadfence()
#endif
template <int NK>
__device__ __forceinline__ void kmma_acc(const uint4* __restrict__ p, const uint32_t* __restrict__ xb, float& c0, float& c1, float& c2, float& c3) {
#pragma unroll
  for (int k = 0; k < NK; k += QU) {
    uint4 w[QU];
#pragma unroll
    for (int u = 0; u < QU; u++) w[u] = p[(k + u) * 32];
#pragma unroll
    for (int u = 0; u < QU; u++) {
      uint32_t b0 = xb[(k + u) * 8], b1 = xb[(k + u) * 8 + 4];
      MMA(c0, c1, c2, c3, w[u], b0, b1);
    }
  }
}
// one quantum from zero
__device__ __forceinline__ float4 qrun(const uint4* __restrict__ p, const uint32_t* __restrict__ xb) {
  float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
  kmma_acc<8>(p, xb, c0, c1, c2, c3);
  return make_float4(c0, c1, c2, c3);
}
// half a quantum (4 k-steps) from zero, its 4 loads in one group
__device__ __forceinline__ float4 hrun(const uint4* __restrict__ p, const uint32_t* __restrict__ xb) {
  float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
  uint4 w[4];
#pragma unroll
  for (int u = 0; u < 4; u++) w[u] = p[u * 32];
#pragma unroll
  for (int u = 0; u < 4; u++) { uint32_t b0 = xb[u * 8], b1 = xb[u * 8 + 4]; MMA(c0, c1, c2, c3, w[u], b0, b1); }
  return make_float4(c0, c1, c2, c3);
}
__device__ __forceinline__ float4 f4add(float4 a, float4 b) { return make_float4(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w); }

struct Smem {
  uint16_t* xn;   // [MAXB][HID] normed input of the current layer (bf16)
  uint32_t* zero; // 8 KB of zeros: the B operand of batch columns that are not in use
  float4* slot;   // [QB][32] one mma result per quantum and lane
  float4* Cst;    // [4 + MAXU][32] totals per unit of stage C
  float* S;       // [8][ctx] attention scores, then exp        (attention overlays slot and Cst)
  uint16_t* Pm;   // [8][ctx + 128] probabilities, bf16
  uint16_t* Qs;   // [8][128] rotated queries
  float* O;       // [2][8][128]
  float* R;       // [512]
  float* Mx;      // [8]
  uint32_t* W;    // [128] misc words
  const uint4** eb; // [MAXU] expert base per slot
  int* bm;        // [MAXU] sequences per slot
  int* bslot;     // [MAXB][TOPK]
  float* bw;      // [MAXB][TOPK]
  const uint4** tp; // [TB] tile pointers of a gate|up batch
};

// ---------------------------------------------------------------------------------------------------------
// attention for one (sequence, K/V head): the whole block works on it
__device__ __forceinline__ void attention_task(const Model* M, const Smem& sm, int l, int bt, int B, int pos) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g8 = lane >> 2, t4 = lane & 3;
  const int b = bt >> 2, g = bt & 3;
  const LayerW& LW = M->L[l];
  const int maxK = M->maxK;
  uint4* kc = M->kc + ((((size_t)l * MAXB + b) * 4 + g) * (size_t)maxK * 256);
  uint4* vc = M->vc + ((((size_t)l * MAXB + b) * 4 + g) * (size_t)maxK * 256);
  const int T = pos + 1, nk = (T + 15) >> 4, nk8 = (nk + 7) & ~7;
  // phase 0: q, k, v of the new token from the K-split partial sums; RoPE; append K and V
  for (int j = tid; j < 640; j += 512) {
    int row;  // row of the pair's first element in the qkv output
    if (j < 512) row = (8 * g + (j >> 6)) * 128 + 2 * (j & 63);
    else if (j < 576) row = 4096 + g * 128 + 2 * (j - 512);
    else row = 4608 + g * 128 + 2 * (j - 576);
    float v0, v1;
    if (row >= SHARED_ROW0) {  // rows of the tiles that two blocks share: two partial sums
      const float* q0 = M->qkvp + (size_t)b * QKV_ROWS + row;
      v0 = rbf(q0[0] + q0[(size_t)MAXB * QKV_ROWS]); v1 = rbf(q0[1] + q0[(size_t)MAXB * QKV_ROWS + 1]);
    } else {
      const uint16_t* p0 = M->qkvo + (size_t)b * QKV_ROWS + row;
      v0 = bf2f(p0[0]); v1 = bf2f(p0[1]);
    }
    if (j < 576 && LW.rope) {
      const float* cs = M->rope + ((size_t)pos * 64 + (j & 63)) * 2;
      float c = cs[0], s = cs[1];
      float r0 = __fadd_rn(__fmul_rn(v0, c), __fmul_rn(-v1, s));
      float r1 = __fadd_rn(__fmul_rn(v1, c), __fmul_rn(v0, s));
      v0 = r0; v1 = r1;
    }
    uint16_t u0 = f2bf(v0), u1 = f2bf(v1);
    if (j < 512) {
      sm.Qs[(j >> 6) * 128 + 2 * (j & 63)] = u0;
      sm.Qs[(j >> 6) * 128 + 2 * (j & 63) + 1] = u1;
    } else if (j < 576) {
      // K cache: A operand with rows = positions, k = dims
      int d = 2 * (j - 512), p16 = pos & 15;
      size_t off = ((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ((p16 & 7) * 4 + ((d & 7) >> 1))) * 16) + (((d & 15) >> 3) * 2 + (p16 >> 3)) * 4;
      uint16_t* w = (uint16_t*)((char*)kc + off);
      w[0] = u0; w[1] = u1;
    } else {
      // V cache: A operand with rows = dims, k = positions (two dims of this pair live in different lanes)
      int p16 = pos & 15;
      for (int e = 0; e < 2; e++) {
        int d = 2 * (j - 576) + e;
        size_t off = ((((size_t)(d >> 4) * maxK + (pos >> 4)) * 32 + ((d & 7) * 4 + ((p16 & 7) >> 1))) * 16) + ((p16 >> 3) * 2 + ((d & 15) >> 3)) * 4 + (p16 & 1) * 2;
        *(uint16_t*)((char*)vc + off) = e ? u1 : u0;
      }
    }
  }
  __syncthreads();
  // phase 1: scores of the 8 query heads against every cached position
  {
    uint32_t q0[8], q1[8];
#pragma unroll
    for (int k = 0; k < 8; k++) {
      const uint32_t* qp = (const uint32_t*)(sm.Qs + g8 * 128 + 16 * k) + t4;
      q0[k] = qp[0]; q1[k] = qp[4];
    }
    for (int P = warp; P < nk; P += 16) {
      const uint4* p = kc + (size_t)P * 256 + lane;
      uint4 a[8];
#pragma unroll
      for (int k = 0; k < 8; k++) a[k] = p[k * 32];
      float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
#pragma unroll
      for (int k = 0; k < 8; k++) MMA(c0, c1, c2, c3, a[k], q0[k], q1[k]);
      int p0 = P * 16 + g8, h0 = 2 * t4;
      sm.S[h0 * CTX + p0] = c0 * SCALE;
      sm.S[(h0 + 1) * CTX + p0] = c1 * SCALE;
      sm.S[h0 * CTX + p0 + 8] = c2 * SCALE;
      sm.S[(h0 + 1) * CTX + p0 + 8] = c3 * SCALE;
    }
  }
  __syncthreads();
  // phase 2: softmax over positions 0..pos per head, in float32; probabilities to bf16
  {
    const int hd = tid & 7, slot = tid >> 3;
    float* S = sm.S + hd * CTX;
    float m = -INFINITY;
    for (int p = slot; p < T; p += 64) m = fmaxf(m, S[p]);
    sm.R[tid] = m;
    __syncthreads();
    if (tid < 8) { float mm = -INFINITY; for (int i = 0; i < 64; i++) mm = fmaxf(mm, sm.R[tid + 8 * i]); sm.Mx[tid] = mm; }
    __syncthreads();
    m = sm.Mx[hd];
    float z = 0;
    for (int p = slot; p < T; p += 64) { float e = expf(S[p] - m); S[p] = e; z += e; }
    sm.R[tid] = z;
    __syncthreads();
    if (tid < 8) { float zz = 0; for (int i = 0; i < 64; i++) zz += sm.R[tid + 8 * i]; sm.Mx[tid] = zz; }
    __syncthreads();
    z = sm.Mx[hd];
    uint16_t* Pm = sm.Pm + hd * (CTX + 128);
    for (int p = slot; p < nk8 * 16; p += 64) Pm[p] = p < T ? f2bf(S[p] / z) : (uint16_t)0;
  }
  __syncthreads();
  // phase 3: out[head][dim] = sum_t P[t][head] V[t][dim]; two warps per 16 dims (halves of the positions)
  {
    const int rt = warp & 7, half = warp >> 3;
    const int kmid = ((nk8 >> 1) + 7) & ~7;
    const int k0 = half ? kmid : 0, k1 = half ? nk8 : kmid;
    const uint4* p = vc + (size_t)rt * maxK * 32 + lane;
    const uint32_t* pb = (const uint32_t*)(sm.Pm + g8 * (CTX + 128)) + t4;
    float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
    for (int k = k0; k < k1; k += 8) {
      uint4 a[8];
#pragma unroll
      for (int u = 0; u < 8; u++) a[u] = p[(size_t)(k + u) * 32];
#pragma unroll
      for (int u = 0; u < 8; u++) { uint32_t b0 = pb[(k + u) * 8], b1 = pb[(k + u) * 8 + 4]; MMA(c0, c1, c2, c3, a[u], b0, b1); }
    }
    float* O = sm.O + half * 1024;
    int d0 = rt * 16 + g8, h0 = 2 * t4;
    O[h0 * 128 + d0] = c0; O[(h0 + 1) * 128 + d0] = c1; O[h0 * 128 + d0 + 8] = c2; O[(h0 + 1) * 128 + d0 + 8] = c3;
  }
  __syncthreads();
  for (int i = tid; i < 1024; i += 512)
    M->attn[(size_t)b * 4096 + g * 1024 + i] = f2bf(sm.O[i] + sm.O[1024 + i]);
  FENCE();
}

// ---------------------------------------------------------------------------------------------------------
#define WAIT_GE(ptr_, target_)                                                                              \
  {                                                                                                         \
    if (tid == 0) { const uint32_t tg__ = (uint32_t)(target_); while ((int)(vload(ptr_) - tg__) < 0) {} }   \
    __syncthreads();                                                                                        \
  }
// (the stores a signal covers are fenced where they are made: a fence after the next stage's loads have been
// issued would wait for those loads)
#define SIGNAL(ptr_)                                                                                        \
  {                                                                                                         \
    __syncthreads();                                                                                        \
    if (tid == 0) atomicAdd(ptr_, 1u);                                                                      \
  }

// RMSNorm of the residual into shared memory: float32 mean of squares, x * rsqrt rounded to bf16, times the weight
__device__ __forceinline__ void prologue_norm(const Model* M, const Smem& sm, uint2 nw, int B) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  uint2 xr[MAXB];
#pragma unroll
  for (int b = 0; b < MAXB; b++) if (b < B) xr[b] = ((const uint2*)(M->x + (size_t)b * HID))[tid];
  for (int b = 0; b < B; b++) {
    float v0 = bf2f(xr[b].x & 0xffff), v1 = bf2f(xr[b].x >> 16), v2 = bf2f(xr[b].y & 0xffff), v3 = bf2f(xr[b].y >> 16);
    float ss = v0 * v0 + v1 * v1 + v2 * v2 + v3 * v3;
    for (int o = 16; o > 0; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
    if (lane == 0) sm.R[warp * 8 + b] = ss;
  }
  __syncthreads();
  const float w0 = bf2f(nw.x & 0xffff), w1 = bf2f(nw.x >> 16), w2 = bf2f(nw.y & 0xffff), w3 = bf2f(nw.y >> 16);
  for (int b = 0; b < B; b++) {
    float tot = 0;
#pragma unroll
    for (int i = 0; i < 16; i++) tot += sm.R[i * 8 + b];
    const float rs = rsqrtf(tot * (1.0f / HID) + 1e-6f);
    float v0 = bf2f(xr[b].x & 0xffff), v1 = bf2f(xr[b].x >> 16), v2 = bf2f(xr[b].y & 0xffff), v3 = bf2f(xr[b].y >> 16);
    uint2 o;
    o.x = (uint32_t)f2bf(w0 * rbf(v0 * rs)) | ((uint32_t)f2bf(w1 * rbf(v1 * rs)) << 16);
    o.y = (uint32_t)f2bf(w2 * rbf(v2 * rs)) | ((uint32_t)f2bf(w3 * rbf(v3 * rs)) << 16);
    ((uint2*)(sm.xn + b * HID))[tid] = o;
  }
  __syncthreads();
}

// leader block: router logits (two partial sums per logit from the router blocks), top 8 per sequence, sigmoid weights, union of the
// chosen experts over the batch
#define PROFR(k_) { if (M->prof && tid == 0) { long long t__ = clock64(); M->prof[k_] += t__ - tprof; tprof = t__; } }
// leader block: router logits (two stamped partial sums per logit, straight from the router blocks), top 8 per
// sequence, sigmoid weights, union of the chosen experts over the batch
__device__ __forceinline__ void leader_route(const Model* M, const Smem& sm, int l, int B, uint32_t stamp, long long& tprof) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  Dyn& D = M->dyn[l];
  uint32_t* masks = sm.W + 8;          // [MAXB][4]
  uint32_t* sel = sm.W + 8 + 32;       // [MAXB][8] expert ids, by descending logit
  float* selv = sm.R + 128;            // [MAXB][8] logits
  float* RL = (float*)sm.slot;         // [MAXB][128] rounded router logits
  float v[4];
  if (warp < B) {
    const int b = warp;
    const uint2* r0 = M->rl + b * 128 + lane;
    // a partial sum is valid once it carries this layer's stamp (the router blocks write value and stamp in one store)
    unsigned long long p[8];
    for (;;) {
#pragma unroll
      for (int j = 0; j < 4; j++) {
        p[j] = *(const volatile unsigned long long*)(r0 + 32 * j);
        p[4 + j] = *(const volatile unsigned long long*)(r0 + MAXB * 128 + 32 * j);
      }
      bool ok = true;
#pragma unroll
      for (int j = 0; j < 8; j++) ok = ok && (uint32_t)(p[j] >> 32) == stamp;
      if (ok) break;
    }
#pragma unroll
    for (int j = 0; j < 4; j++) { v[j] = rbf(__uint_as_float((uint32_t)p[j]) + __uint_as_float((uint32_t)p[4 + j])); RL[b * 128 + lane + 32 * j] = v[j]; }
  }
  __syncthreads();
  PROFR(28);
  if (warp < B) {
    const int b = warp;
    // 8 rounds of a warp-wide max over sortable integer keys: (bf16 logit as an ordered 16-bit integer) << 7 |
    // (127 - expert), so that the larger logit wins and, at a tie, the lower expert index. No data-dependent branch.
    if (!M->force) {
      int key[4];
#pragma unroll
      for (int j = 0; j < 4; j++) {
        const int u = (int)__float_as_uint(v[j]);
        const int k = u ^ ((u >> 31) & 0x7fffffff);
        key[j] = ((k >> 16) << 7) | (127 - (lane + 32 * j));
      }
#pragma unroll 1
      for (int r = 0; r < TOPK; r++) {
        int best = max(max(key[0], key[1]), max(key[2], key[3]));
#pragma unroll
        for (int o = 16; o > 0; o >>= 1) best = max(best, __shfl_xor_sync(0xffffffffu, best, o));
#pragma unroll
        for (int j = 0; j < 4; j++) key[j] = key[j] == best ? (int)0x80000000 : key[j];
        const int e = 127 - (best & 127);
        if (lane == 0) { sel[b * 8 + r] = e; selv[b * 8 + r] = RL[b * 128 + e]; }
      }
    } else if (lane < TOPK) {
      const int e = M->force[((size_t)l * MAXB + b) * TOPK + lane];
      sel[b * 8 + lane] = e; selv[b * 8 + lane] = RL[b * 128 + e];
    }
  }
  __syncthreads();
  if (tid < 4 * B) {
    const int b = tid >> 2, wi = tid & 3;
    uint32_t m = 0;
#pragma unroll
    for (int r = 0; r < TOPK; r++) { const int e = sel[b * 8 + r]; m |= (e >> 5) == wi ? 1u << (e & 31) : 0u; }
    masks[tid] = m;
  }
  __syncthreads();
  PROFR(29);
  uint32_t* um = sm.W + 8 + 32 + 64;  // [4] union of the batch
  if (tid < 4) { uint32_t u = 0; for (int b = 0; b < B; b++) u |= masks[b * 4 + tid]; um[tid] = u; }
  __syncthreads();
  if (tid < 128) {
    int e = tid, wi = e >> 5;
    if ((um[wi] >> (e & 31)) & 1) {
      int slot = __popc(um[wi] & ((1u << (e & 31)) - 1));
      for (int j = 0; j < wi; j++) slot += __popc(um[j]);
      int bm = 0;
      for (int b = 0; b < B; b++) bm |= ((masks[b * 4 + wi] >> (e & 31)) & 1) << b;
      D.slot_expert[slot] = e;
      D.bmask[slot] = bm;
    }
  }
  if (warp < B && lane < TOPK) {
    const int b = warp;
    int e = sel[b * 8 + lane], wi = e >> 5;
    uint32_t below = (1u << (e & 31)) - 1;
    int slot = __popc(um[wi] & below), rank = __popc(masks[b * 4 + wi] & below);
    for (int j = 0; j < wi; j++) { slot += __popc(um[j]); rank += __popc(masks[b * 4 + j]); }
    float lg = selv[b * 8 + lane];
    D.bslot[b][rank] = slot;
    D.bw[b][rank] = rbf(1.0f / (1.0f + expf(-lg)));
  }
  PROFR(30);
  if (tid == 0) D.U = __popc(um[0]) + __popc(um[1]) + __popc(um[2]) + __popc(um[3]);
}

// greedy choice from per-block candidates (leader block)
__device__ __forceinline__ void leader_argmax(const Model* M, const Launch& A, int step_done, int NB) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  if (warp < A.B) {
    float best = -INFINITY; int bi = 0x7fffffff;
    for (int j = lane; j < NB; j += 32) {
      float v = M->candv[j * MAXB + warp]; int ix = M->candi[j * MAXB + warp];
      if (v > best || (v == best && ix < bi)) { best = v; bi = ix; }
    }
    for (int o = 16; o > 0; o >>= 1) {
      float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
      if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
    }
    if (lane == 0) { M->curtok[warp] = bi; A.tok_out[(size_t)warp * A.nsteps + step_done] = bi; }
  }
}

#define PROF(k_) { if (M->prof && blockIdx.x == 0 && tid == 0) { long long t__ = clock64(); M->prof[k_] += t__ - tprof; tprof = t__; } }

__global__ void __launch_bounds__(512, 1) mk_kernel(Launch A) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g8 = lane >> 2, t4 = lane & 3;
  // The model's table of pointers lives in shared memory for the whole launch: a field read from global memory
  // would be one round trip through the L2 queue each time (0.3 us on a quiet card, more under a stream).
  for (int i = tid; i < (int)((sizeof(Model) + 7) / 8); i += 512) ((uint64_t*)smraw)[i] = ((const uint64_t*)A.M)[i];
  __syncthreads();
  const Model* M = (const Model*)smraw;
  Ctl* C = M->ctl;
  const int b0i = 2 * t4, b1i = 2 * t4 + 1;
  const int B = A.B, NB = gridDim.x, j = blockIdx.x, NW = 16 * NB;
  const bool act = g8 < B;
  // shared-memory layout: every offset is a compile-time constant, so that none of these pointers holds a register
  // (the kernel must stay below 128 registers for 512 threads per SM; a spill goes to local memory)
  enum : size_t {
    OFF_XN = (sizeof(Model) + 63) & ~(size_t)63,
    OFF_ZERO = OFF_XN + MAXB * HID * 2,
    OFF_SCR = OFF_ZERO + 8192,
    OFF_CST = OFF_SCR + QB * 32 * 16,
    OFF_R = OFF_CST + (4 + MAXU) * 32 * 16,
    OFF_MX = OFF_R + 512 * 4,
    OFF_W = OFF_MX + 8 * 4,
    OFF_EB = OFF_W + 128 * 4,
    OFF_BM = OFF_EB + MAXU * 8,
    OFF_BSLOT = OFF_BM + MAXU * 4,
    OFF_BW = OFF_BSLOT + MAXB * TOPK * 4,
    OFF_TP = OFF_BW + MAXB * TOPK * 4,
    OFF_PM = OFF_SCR + 8 * CTX * 4,       // attention arrays overlay the quantum slots (an attention block runs no quanta in stage B)
    OFF_QS = OFF_PM + 8 * (CTX + 128) * 2,
    OFF_O = OFF_QS + 8 * 128 * 2,
  };
  const Smem sm = {(uint16_t*)(smraw + OFF_XN), (uint32_t*)(smraw + OFF_ZERO), (float4*)(smraw + OFF_SCR), (float4*)(smraw + OFF_CST),
                   (float*)(smraw + OFF_SCR), (uint16_t*)(smraw + OFF_PM), (uint16_t*)(smraw + OFF_QS), (float*)(smraw + OFF_O),
                   (float*)(smraw + OFF_R), (float*)(smraw + OFF_MX), (uint32_t*)(smraw + OFF_W), (const uint4**)(smraw + OFF_EB),
                   (int*)(smraw + OFF_BM), (int*)(smraw + OFF_BSLOT), (float*)(smraw + OFF_BW), (const uint4**)(smraw + OFF_TP)};
  for (int i = tid; i < 2048; i += 512) sm.zero[i] = 0;
  const bool att_block = j >= 1 && j <= 4 * B;
  const int NBg = NB - 4 * B, sidx = j == 0 ? 0 : j - 4 * B;  // blocks that run gate|up tiles, and this block's index among them
  const int gw = warp * NB + j;                                // this warp's index in the grid-wide round robin
  const uint32_t* xn_b = act ? (const uint32_t*)(sm.xn + g8 * HID) + t4 : sm.zero;  // B operand of the normed input
  const int xn_step = act ? 64 : 0;                            // u32 per quantum (8 k-steps x 16 values) along it
  // stage A work of this block. Whole tiles (tile id < 320: q|k|v row tile; 320 + r: router row tile r): blocks
  // 1..131 take tiles j-1 and 131+j-1. Tiles 262..327 are cut in two halves of 64 k-steps; block j takes half j
  // (4 k-steps per warp). Every warp of blocks 1..131 thus reads 20 k-steps; the leader only 4, then it routes.
  const int htile = FULL_TILES + (j >> 1), hhalf = j & 1;
  const bool hrouter = htile >= 320;
  long long tprof = clock64();
#define A_TILE(LW_, t_) ((t_) < 320 ? (LW_).qkv + (size_t)(t_) * 4096 : (LW_).router + (size_t)((t_) - 320) * 4096)
  for (int step = 0; step < A.nsteps; step++) {
    const int pos = A.pos + step;
    const uint32_t S = A.s0 + step;
    if (j == 0) {
      if (step > 0) { WAIT_GE(&C->cntH, NB * (A.h0 + step)); leader_argmax(M, A, step - 1, NB); __syncthreads(); }
      for (int b = 0; b < B; b++) {
        int64_t tk = (step == 0) ? A.tok_in[(size_t)b * A.tok_stride] : M->curtok[b];
        ((uint2*)(M->x + (size_t)b * HID))[tid] = ((const uint2*)(M->embed + (size_t)tk * HID))[tid];
      }
      FENCE();
      __syncthreads();
      if (tid == 0) C->tok_seq = S + 1;
    }
    WAIT_GE(&C->tok_seq, S + 1);
    PROF(0);
    for (int l = 0; l < NLAYER; l++) {
      const LayerW& LW = M->L[l];
      const uint32_t G = A.g0 + step * NLAYER + l;
      const uint2 nw = ((const uint2*)LW.normw)[tid];
      if (l > 0) WAIT_GE(&C->cntC, NB * G);
      PROF(1);
      if (M->dbg_x && j == 0) for (int b = 0; b < B; b++) for (int i = tid; i < HID; i += 512) M->dbg_x[((size_t)l * MAXB + b) * HID + i] = M->x[(size_t)b * HID + i];
      prologue_norm(M, sm, nw, B);
      PROF(2);
      // ---- A: q|k|v and router rows. The leader routes first and reads its half tile afterwards.
      if (j == 0 && !LW.dense) {
        leader_route(M, sm, l, B, G + 1, tprof);
        FENCE();
        PROF(26);
      }
      if (j == 0) { __syncthreads(); if (tid == 0) C->route_seq = G + 1; PROF(27); }
      {
        const bool hdo = !(hrouter && LW.dense);
        if (hdo) sm.slot[warp * 32 + lane] = hrun(A_TILE(LW, htile) + (hhalf * 64 + warp * 4) * 32 + lane, xn_b + (hhalf * 64 + warp * 4) * (xn_step >> 3));
        if (hdo && hrouter) {
          // router rows first: the leader is polling for them. Value and stamp go out in one 8-byte store.
          __syncthreads();
          if (warp == 0) {
            float4 c = sm.slot[lane];
#pragma unroll
            for (int w = 1; w < 16; w++) c = f4add(c, sm.slot[w * 32 + lane]);
            uint2* o = M->rl + (size_t)hhalf * MAXB * 128 + (htile - 320) * 16 + g8;
            if (b0i < B) { o[b0i * 128] = make_uint2(__float_as_uint(c.x), G + 1); o[b0i * 128 + 8] = make_uint2(__float_as_uint(c.z), G + 1); }
            if (b1i < B) { o[b1i * 128] = make_uint2(__float_as_uint(c.y), G + 1); o[b1i * 128 + 8] = make_uint2(__float_as_uint(c.w), G + 1); }
          }
        }
        if (j > 0) {
          sm.slot[(16 + warp) * 32 + lane] = qrun(LW.qkv + (size_t)(j - 1) * 4096 + warp * 256 + lane, xn_b + warp * xn_step);
          sm.slot[(32 + warp) * 32 + lane] = qrun(LW.qkv + (size_t)(NB - 1 + j - 1) * 4096 + warp * 256 + lane, xn_b + warp * xn_step);
        }
        __syncthreads();
        if (warp == 0 && hdo && !hrouter) {
          float4 c = sm.slot[lane];
#pragma unroll
          for (int w = 1; w < 16; w++) c = f4add(c, sm.slot[w * 32 + lane]);
          float* o = M->qkvp + (size_t)hhalf * MAXB * QKV_ROWS + htile * 16 + g8;
          if (b0i < B) { o[b0i * QKV_ROWS] = c.x; o[b0i * QKV_ROWS + 8] = c.z; }
          if (b1i < B) { o[b1i * QKV_ROWS] = c.y; o[b1i * QKV_ROWS + 8] = c.w; }
          FENCE();
        }
        if (j > 0 && (warp == 1 || warp == 2)) {
          float4 c = sm.slot[(warp * 16) * 32 + lane];
#pragma unroll
          for (int kq = 1; kq < 16; kq++) c = f4add(c, sm.slot[(warp * 16 + kq) * 32 + lane]);
          uint16_t* o = M->qkvo + (warp == 1 ? j - 1 : NB - 1 + j - 1) * 16 + g8;
          if (b0i < B) { o[b0i * QKV_ROWS] = f2bf(c.x); o[b0i * QKV_ROWS + 8] = f2bf(c.z); }
          if (b1i < B) { o[b1i * QKV_ROWS] = f2bf(c.y); o[b1i * QKV_ROWS + 8] = f2bf(c.w); }
          FENCE();
        }
      }
      SIGNAL(&C->cntA);
      PROF(3);
      if (M->prof && j == 0 && tid == 0) M->prof[22] += (int)(vload(&C->cntA) - NB * G);
      // ---- B: attention on blocks 1..4B, gate|up of the chosen experts on the others
      if (att_block) {
        WAIT_GE(&C->cntA, NB * (G + 1));
        attention_task(M, sm, l, j - 1, B, pos);
        __syncthreads();
      }
      WAIT_GE(&C->route_seq, G + 1);
      PROF(4);
      // the routing of this layer into shared memory: expert base per slot, sequences per slot, slots and weights per sequence
      {
        const Dyn& D = M->dyn[l];
        if (tid < MAXU) {
          if (LW.dense) { sm.eb[tid] = LW.expert; sm.bm[tid] = 0xff; }
          else { sm.eb[tid] = LW.expert + (size_t)D.slot_expert[tid] * LW.exp_stride; sm.bm[tid] = D.bmask[tid]; }
        } else if (tid < 2 * MAXU) {
          sm.bslot[tid - MAXU] = D.bslot[0][tid - MAXU]; sm.bw[tid - MAXU] = D.bw[0][tid - MAXU];
        }
        if (tid == 2 * MAXU) sm.W[0] = LW.dense ? 1 : D.U;
        __syncthreads();
      }
      const int U = (int)sm.W[0];
      PROF(10);
      if (!att_block) {
        const int gu = LW.gu_tiles, n = U * gu;
        const int ct = n > sidx ? (n - sidx + NBg - 1) / NBg : 0;  // this block's tiles: sidx, sidx + NBg, ...
        for (int t0 = 0; t0 < ct; t0 += TB) {
          const int nt = min(TB, ct - t0);
          if (tid < nt) { const int i = sidx + (t0 + tid) * NBg; sm.tp[tid] = sm.eb[i / gu] + (size_t)(i % gu) * 4096; }
          __syncthreads();
          // quantum q of the batch: tile q >> 4, k-quantum q & 15; this warp takes k-quantum `warp` of every tile
          for (int k = 0; k < nt; k++) sm.slot[(k * 16 + warp) * 32 + lane] = qrun(sm.tp[k] + warp * 256 + lane, xn_b + warp * xn_step);
          PROF(11);
          __syncthreads();
          PROF(12);
          if (warp < nt) {
            // this warp finishes tile t0 + warp: sum its 16 quanta in order, SwiGLU, store h
            float4 c = sm.slot[(warp * 16) * 32 + lane];
#pragma unroll
            for (int kq = 1; kq < 16; kq++) c = f4add(c, sm.slot[(warp * 16 + kq) * 32 + lane]);
            const int i = sidx + (t0 + warp) * NBg, u = i / gu, m = i % gu;
            uint16_t* h = M->h + (size_t)u * MAXB * HMAX + m * 8 + g8;
            if (b0i < B) { float gt = rbf(c.x); float sg = rbf(gt / (1.0f + expf(-gt))); h[(size_t)b0i * HMAX] = f2bf(sg * rbf(c.z)); }
            if (b1i < B) { float gt = rbf(c.y); float sg = rbf(gt / (1.0f + expf(-gt))); h[(size_t)b1i * HMAX] = f2bf(sg * rbf(c.w)); }
            FENCE();
          }
          __syncthreads();
        }
      }
      PROF(13);
      SIGNAL(&C->cntB);
      PROF(5);
      if (M->prof && j == 0 && tid == 0) M->prof[20] += (int)(vload(&C->cntB) - NB * G);
      // ---- C: one residual row tile per block: o_proj (32 quanta) + down of every chosen expert, combined here
      WAIT_GE(&C->cntB, NB * (G + 1));
      PROF(6);
      if (j < 128) {
        const int nun = U;                                // down units
        const uint4* const op = LW.o + (size_t)j * 8192 + lane;
        const size_t dn_off = (size_t)LW.gu_tiles * 4096 + (size_t)j * LW.down_K * 32 + lane;
        const uint32_t* at_b = act ? (const uint32_t*)(M->attn + g8 * 4096) + t4 : M->zeros;
        const int dq = LW.dense ? 24 : 6;                 // quanta per down unit
        // batches of whole units, at most QB quanta: batch 0 = o_proj + the first units
        int u0 = 0;
        for (int bt = 0; u0 < nun || bt == 0; bt++) {
          const int qo = bt == 0 ? 32 : 0;                // o_proj quanta in this batch
          const int un = min(nun - u0, (QB - qo) / dq), nq = qo + un * dq;
          for (int q = warp; q < nq; q += 16) {
            const uint4* p1; const uint32_t* x1;
            if (q < qo) { p1 = op + q * 256; x1 = at_b + q * xn_step; }
            else {
              const int qq = q - qo;
              const int u = u0 + (LW.dense ? 0 : qq / 6), kq = LW.dense ? qq : qq % 6;
              p1 = sm.eb[u] + dn_off + kq * 256;
              x1 = (act && ((sm.bm[u] >> g8) & 1)) ? (const uint32_t*)(M->h + ((size_t)u * MAXB + g8) * HMAX) + t4 + kq * 64 : M->zeros;
            }
            sm.slot[q * 32 + lane] = qrun(p1, x1);
          }
          PROF(14);
          __syncthreads();
          PROF(15);
          // unit totals, in quantum order: Cst[0] holds o_proj, Cst[4 + u] the down of slot u
          for (int w = warp; w < (bt == 0 ? 1 : 0) + un; w += 16) {
            const bool isO = bt == 0 && w == 0;
            const int uu = w - (bt == 0 ? 1 : 0);
            const int q0 = isO ? 0 : qo + uu * dq, cnt = isO ? 32 : dq;
            float4 c = sm.slot[q0 * 32 + lane];
            for (int k = 1; k < cnt; k++) c = f4add(c, sm.slot[(q0 + k) * 32 + lane]);
            sm.Cst[(isO ? 0 : 4 + u0 + uu) * 32 + lane] = c;
          }
          __syncthreads();
          u0 += un;
        }
        if (warp == 0) {
#pragma unroll
          for (int q = 0; q < 4; q++) {
            const int b = 2 * t4 + (q & 1), row = j * 16 + g8 + (q >> 1) * 8;
            if (b < B) {
              const float* cs = (const float*)(sm.Cst + lane) + q;  // unit un at cs[un * 128]
              const float av = rbf(cs[0]);
              float mlp;
              if (LW.dense) mlp = rbf(cs[4 * 128]);
              else {
                mlp = 0;
#pragma unroll
                for (int jj = 0; jj < TOPK; jj++) mlp = rbf(mlp + rbf(rbf(cs[(4 + sm.bslot[b * TOPK + jj]) * 128]) * sm.bw[b * TOPK + jj]));
              }
              uint16_t* xp = M->x + (size_t)b * HID + row;
              *xp = f2bf(rbf(bf2f(*xp) + av) + mlp);
            }
          }
          FENCE();
        }
      }
      SIGNAL(&C->cntC);
      PROF(7);
      if (M->prof && j == 0 && tid == 0) M->prof[21] += (int)(vload(&C->cntC) - NB * G);
    }
    // ---- head: final norm, 16384 row tiles spread over every warp
    {
      const uint2 nw = ((const uint2*)M->normf)[tid];
      WAIT_GE(&C->cntC, NB * (A.g0 + (step + 1) * NLAYER));
      if (M->dbg_x && j == 0) for (int b = 0; b < B; b++) for (int i = tid; i < HID; i += 512) M->dbg_x[((size_t)NLAYER * MAXB + b) * HID + i] = M->x[(size_t)b * HID + i];
      prologue_norm(M, sm, nw, B);
      PROF(8);
      float bv0 = -INFINITY, bv1 = -INFINITY; int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
      const uint4* const hp = M->head + lane;
      float* const lg = A.logits_out;
      for (int i = gw; i < VOCAB / 16; i += NW) {
        const uint4* p = hp + (size_t)i * 4096;
        float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
        kmma_acc<128>(p, xn_b, c0, c1, c2, c3);
        const int row = i * 16 + g8;
        if (A.gen) {
          if (c0 > bv0) { bv0 = c0; bi0 = row; }
          if (c2 > bv0) { bv0 = c2; bi0 = row + 8; }
          if (c1 > bv1) { bv1 = c1; bi1 = row; }
          if (c3 > bv1) { bv1 = c3; bi1 = row + 8; }
        } else {
          if (b0i < B) { lg[(size_t)b0i * VOCAB + row] = c0; lg[(size_t)b0i * VOCAB + row + 8] = c2; }
          if (b1i < B) { lg[(size_t)b1i * VOCAB + row] = c1; lg[(size_t)b1i * VOCAB + row + 8] = c3; }
        }
      }
      if (A.gen) {
        // candidates of this block: [8 batch columns][128 = 16 warps x 8 row groups]
        float* CV = (float*)sm.slot; int* CI = (int*)sm.slot + 1024;
        CV[b0i * 128 + warp * 8 + g8] = bv0; CI[b0i * 128 + warp * 8 + g8] = bi0;
        CV[b1i * 128 + warp * 8 + g8] = bv1; CI[b1i * 128 + warp * 8 + g8] = bi1;
        __syncthreads();
        if (warp < B) {
          float best = -INFINITY; int bi = 0x7fffffff;
#pragma unroll
          for (int q = 0; q < 4; q++) {
            float v = CV[warp * 128 + lane + 32 * q]; int ix = CI[warp * 128 + lane + 32 * q];
            if (v > best || (v == best && ix < bi)) { best = v; bi = ix; }
          }
          for (int o = 16; o > 0; o >>= 1) {
            float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
            if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
          }
          if (lane == 0) { M->candv[j * MAXB + warp] = best; M->candi[j * MAXB + warp] = bi; }
        }
        SIGNAL(&C->cntH);
      }
      PROF(9);
    }
  }
  if (A.gen && j == 0) { WAIT_GE(&C->cntH, NB * (A.h0 + A.nsteps)); leader_argmax(M, A, A.nsteps - 1, NB); }
}

// ---------------------------------------------------------------------------------------------------------
// host side
static Model* g_model_dev = nullptr;
static uint32_t g_g0 = 0, g_s0 = 0, g_h0 = 0;
static int g_smem = 0;
static int g_blocks = 132;

extern "C" {

int mk_sizeof_model() { return (int)sizeof(Model); }
int mk_sizeof_ctl() { return (int)sizeof(Ctl); }
int mk_sizeof_dyn() { return (int)sizeof(Dyn); }
int mk_sizeof_layer() { return (int)sizeof(LayerW); }

// model_host: a filled Model struct (device pointers inside); model_dev: device memory to hold it
int mk_init(const void* model_host, void* model_dev, int max_ctx) {
  cudaError_t e = cudaMemcpy(model_dev, model_host, sizeof(Model), cudaMemcpyHostToDevice);
  if (e != cudaSuccess) { fprintf(stderr, "mk_init memcpy: %s\n", cudaGetErrorString(e)); return 1; }
  g_model_dev = (Model*)model_dev;
  if (max_ctx > 2048) { fprintf(stderr, "mk_init: contexts above 2048 need a larger attention scratch\n"); return 3; }
  if (max_ctx > CTX) return 3;
  g_smem = (int)((sizeof(Model) + 63) & ~(size_t)63) + MAXB * HID * 2 + 8192 + QB * 32 * 16 + (4 + MAXU) * 32 * 16 + 512 * 4 + 8 * 4 + 128 * 4 + MAXU * 12 + MAXB * TOPK * 8 + TB * 8 + 64;
  // (more than half an SM's shared memory: one block per SM)
  e = cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, g_smem);
  if (e != cudaSuccess) { fprintf(stderr, "mk_init smem %d: %s\n", g_smem, cudaGetErrorString(e)); return 2; }
  int dev = 0; cudaGetDevice(&dev);
  cudaDeviceProp prop; cudaGetDeviceProperties(&prop, dev);
  g_blocks = prop.multiProcessorCount;
  if (g_blocks != 132) { fprintf(stderr, "mk_init: this build is laid out for the 132 SMs of an H100, found %d\n", g_blocks); return 4; }
  g_g0 = g_s0 = g_h0 = 0;
  return 0;
}

static int launch(const int64_t* tok_in, int tok_stride, float* logits_out, int64_t* tok_out, int B, int pos, int nsteps, int gen) {
  Launch A;
  A.M = g_model_dev; A.tok_in = tok_in; A.logits_out = logits_out; A.tok_out = tok_out;
  A.B = B; A.pos = pos; A.nsteps = nsteps; A.gen = gen; A.tok_stride = tok_stride; A.g0 = g_g0; A.s0 = g_s0; A.h0 = g_h0;
  mk_kernel<<<g_blocks, 512, g_smem, 0>>>(A);
  g_g0 += (uint32_t)nsteps * NLAYER; g_s0 += nsteps; if (gen) g_h0 += nsteps;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) { fprintf(stderr, "mk launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}

int mk_step(const int64_t* tok_in, int tok_stride, float* logits_out, int B, int pos) { return launch(tok_in, tok_stride, logits_out, nullptr, B, pos, 1, 0); }
int mk_generate(const int64_t* tok_in, int tok_stride, int64_t* tok_out, int B, int pos, int nsteps) { return launch(tok_in, tok_stride, nullptr, tok_out, B, pos, nsteps, 1); }

}  // extern "C"
