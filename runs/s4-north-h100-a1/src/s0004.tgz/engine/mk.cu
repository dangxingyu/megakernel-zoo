// North-Mini-Code-1.0 decode megakernel for one H100.
//
// One persistent kernel per step() (or per generate() call): 132 blocks x 16 warps, one block per SM.
// Every block walks the same static program; nothing is claimed dynamically. Per layer:
//   prologue  every block reads the residual and computes the RMSNorm into its own shared memory
//   A         q|k|v rows as 1280 K-chunks, one per warp; block 0 computes the router, the top 8 and the union
//   B         blocks 1..4B: attention of one (sequence, K/V head) each; the others: gate|up of the chosen experts
//   C         block r < 128 owns residual rows 16r..16r+15: o_proj and the down rows of every chosen expert,
//             summed in shared memory and added to the residual
// Blocks meet only through four monotonic counters (A done, route published, B done, C done).
// Every matrix product is a tensor-core m16n8k16 whose A operand is read straight from memory in fragment
// order (one 16-byte load per thread per mma, 16 loads in flight) and whose B operand holds the batch in its
// 8 columns: batch 1 and batch 8 run the same instructions.
//
// Model facts used (CohereLabs/North-Mini-Code-1.0): parallel block (attention and MLP read the same normed
// input), 8 of 128 experts per token, 4 K/V heads x 8 query heads (the 8 query heads of a K/V head are the 8
// columns of an mma), tied head.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#define HID 2048
#define NLAYER 49
#define TOPK 8
#define MAXB 8
#define MAXU 64
#define VOCAB 262144
#define QKV_ROWS 5120
#define PART_ROWS 5248  // q 4096, k 512, v 512, router 128
#define HMAX 3072
#define SCALE 0.08838834764831845f

struct LayerW {
  const uint4* qkv;     // 320 row tiles, K = 128 k-steps
  const uint4* router;  // 8 row tiles, K = 128 (unused in layer 0)
  const uint4* o;       // 128 row tiles, K = 256
  const uint4* expert;  // expert e at expert + e * exp_stride: gate|up interleaved (gu_tiles x 128), then down (128 x down_K)
  const uint16_t* normw;
  uint64_t exp_stride;  // in uint4 units
  int gu_tiles, down_K, rope, dense;
};

struct Ctl {  // monotonic counters and sequence words; every wait is "word >= target"
  uint32_t tok_seq; uint32_t pad0[15];
  uint32_t route_seq; uint32_t pad1[15];
  uint32_t cntA; uint32_t pad2[15];
  uint32_t cntB; uint32_t pad3[15];
  uint32_t cntC; uint32_t pad4[15];
  uint32_t cntH; uint32_t pad5[15];
};

struct Dyn {
  int U;
  int slot_expert[MAXU];
  int bslot[MAXB][TOPK];
  float bw[MAXB][TOPK];
  int bmask[MAXU];  // which sequences use the expert of a slot
};

struct Model {
  LayerW L[NLAYER];
  const uint4* head;
  const uint16_t* embed;
  const uint16_t* normf;
  const float* rope;  // [ctx][64][2]
  uint4* kc; uint4* vc;
  uint16_t* x; uint16_t* xn; float* part; uint16_t* attn; float* opart; uint16_t* h; uint16_t* y;
  float* logits; float* candv; int* candi; int64_t* curtok;
  const uint32_t* zeros;
  Ctl* ctl; Dyn* dyn;
  uint16_t* dbg_x;     // optional [NLAYER+1][MAXB][HID]
  const int* force;    // optional [NLAYER][MAXB][TOPK] forced expert ids (debug)
  long long* prof;     // optional [32] cycle counters of the leader's SM (debug)
  int max_ctx, maxK;
};

struct Launch {
  const Model* M;
  const int64_t* tok_in;
  float* logits_out;
  int64_t* tok_out;
  int B, pos, nsteps, gen, tok_stride;
  uint32_t g0, s0, h0;  // layers, steps and generate-steps completed before this launch
};

#define MMA(c0, c1, c2, c3, a, b0, b1)                                                                          \
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
               : "+f"(c0), "+f"(c1), "+f"(c2), "+f"(c3)                                                         \
               : "r"((a).x), "r"((a).y), "r"((a).z), "r"((a).w), "r"(b0), "r"(b1))

__device__ __forceinline__ float bf2f(uint16_t v) { return __uint_as_float(((uint32_t)v) << 16); }
__device__ __forceinline__ uint16_t f2bf(float f) {
  uint32_t u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (uint16_t)(u >> 16);
}
__device__ __forceinline__ float rbf(float f) { return bf2f(f2bf(f)); }
__device__ __forceinline__ uint32_t vload(const uint32_t* p) { return *(const volatile uint32_t*)p; }

// y(16 rows x 8 batch columns) += W_tile(16 x 16K) * x(16K x 8): the weights stream from memory, U loads in flight
template <int U>
__device__ __forceinline__ void gemv_tile(const uint4* __restrict__ p, int K, const uint32_t* __restrict__ xb,
                                          float& c0, float& c1, float& c2, float& c3) {
  for (int k = 0; k < K; k += U) {
    uint4 a[U];
#pragma unroll
    for (int u = 0; u < U; u++) a[u] = p[(k + u) * 32];
#pragma unroll
    for (int u = 0; u < U; u++) {
      uint32_t b0 = xb[(k + u) * 8], b1 = xb[(k + u) * 8 + 4];
      MMA(c0, c1, c2, c3, a[u], b0, b1);
    }
  }
}

struct Smem {
  uint16_t* xn;   // [MAXB][HID] normed input of the current layer (bf16)
  uint32_t* zero; // 8 KB of zeros: the B operand of batch columns that are not in use
  float* S;       // [8][ctx] scores, then exp  (also: partial mma results of the other stages)
  uint16_t* Pm;   // [8][ctx + 128] probabilities, bf16
  uint16_t* Qs;   // [8][128] rotated queries
  float* O;       // [2][8][128]
  float* R;       // [512]
  float* Mx;      // [8]
  uint32_t* W;    // [128] misc words
};

// ---------------------------------------------------------------------------------------------------------
// attention for one (sequence, K/V head): the whole block works on it
__device__ __forceinline__ void attention_task(const Model* M, const Smem& sm, int l, int bt, int B, int pos) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g8 = lane >> 2, t4 = lane & 3;
  const int b = bt >> 2, g = bt & 3;
  const LayerW& LW = M->L[l];
  const int maxK = M->maxK;
  uint4* kc = M->kc + ((((size_t)l * MAXB + b) * 4 + g) * (size_t)maxK * 256);
  uint4* vc = M->vc + ((((size_t)l * MAXB + b) * 4 + g) * (size_t)maxK * 256);
  const int T = pos + 1, nk = (T + 15) >> 4, nk8 = (nk + 7) & ~7;
  // phase 0: q, k, v of the new token from the K-split partial sums; RoPE; append K and V
  for (int j = tid; j < 640; j += 512) {
    int row;  // row of the pair's first element in the qkv output
    if (j < 512) row = (8 * g + (j >> 6)) * 128 + 2 * (j & 63);
    else if (j < 576) row = 4096 + g * 128 + 2 * (j - 512);
    else row = 4608 + g * 128 + 2 * (j - 576);
    const float* p0 = M->part + (size_t)b * PART_ROWS + row;
    const size_t ps = (size_t)MAXB * PART_ROWS;
    float v0 = rbf(p0[0] + p0[ps] + p0[2 * ps] + p0[3 * ps]);
    float v1 = rbf(p0[1] + p0[ps + 1] + p0[2 * ps + 1] + p0[3 * ps + 1]);
    if (j < 576 && LW.rope) {
      const float* cs = M->rope + ((size_t)pos * 64 + (j & 63)) * 2;
      float c = cs[0], s = cs[1];
      float r0 = __fadd_rn(__fmul_rn(v0, c), __fmul_rn(-v1, s));
      float r1 = __fadd_rn(__fmul_rn(v1, c), __fmul_rn(v0, s));
      v0 = r0; v1 = r1;
    }
    uint16_t u0 = f2bf(v0), u1 = f2bf(v1);
    if (j < 512) {
      sm.Qs[(j >> 6) * 128 + 2 * (j & 63)] = u0;
      sm.Qs[(j >> 6) * 128 + 2 * (j & 63) + 1] = u1;
    } else if (j < 576) {
      // K cache: A operand with rows = positions, k = dims
      int d = 2 * (j - 512), p16 = pos & 15;
      size_t off = ((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ((p16 & 7) * 4 + ((d & 7) >> 1))) * 16) + (((d & 15) >> 3) * 2 + (p16 >> 3)) * 4;
      uint16_t* w = (uint16_t*)((char*)kc + off);
      w[0] = u0; w[1] = u1;
    } else {
      // V cache: A operand with rows = dims, k = positions (two dims of this pair live in different lanes)
      int p16 = pos & 15;
      for (int e = 0; e < 2; e++) {
        int d = 2 * (j - 576) + e;
        size_t off = ((((size_t)(d >> 4) * maxK + (pos >> 4)) * 32 + ((d & 7) * 4 + ((p16 & 7) >> 1))) * 16) + ((p16 >> 3) * 2 + ((d & 15) >> 3)) * 4 + (p16 & 1) * 2;
        *(uint16_t*)((char*)vc + off) = e ? u1 : u0;
      }
    }
  }
  __syncthreads();
  // phase 1: scores of the 8 query heads against every cached position
  {
    uint32_t q0[8], q1[8];
#pragma unroll
    for (int k = 0; k < 8; k++) {
      const uint32_t* qp = (const uint32_t*)(sm.Qs + g8 * 128 + 16 * k) + t4;
      q0[k] = qp[0]; q1[k] = qp[4];
    }
    for (int P = warp; P < nk; P += 16) {
      const uint4* p = kc + (size_t)P * 256 + lane;
      uint4 a[8];
#pragma unroll
      for (int k = 0; k < 8; k++) a[k] = p[k * 32];
      float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
#pragma unroll
      for (int k = 0; k < 8; k++) MMA(c0, c1, c2, c3, a[k], q0[k], q1[k]);
      int p0 = P * 16 + g8, h0 = 2 * t4;
      sm.S[h0 * M->max_ctx + p0] = c0 * SCALE;
      sm.S[(h0 + 1) * M->max_ctx + p0] = c1 * SCALE;
      sm.S[h0 * M->max_ctx + p0 + 8] = c2 * SCALE;
      sm.S[(h0 + 1) * M->max_ctx + p0 + 8] = c3 * SCALE;
    }
  }
  __syncthreads();
  // phase 2: softmax over positions 0..pos per head, in float32; probabilities to bf16
  {
    const int hd = tid & 7, slot = tid >> 3;
    float* S = sm.S + hd * M->max_ctx;
    float m = -INFINITY;
    for (int p = slot; p < T; p += 64) m = fmaxf(m, S[p]);
    sm.R[tid] = m;
    __syncthreads();
    if (tid < 8) { float mm = -INFINITY; for (int i = 0; i < 64; i++) mm = fmaxf(mm, sm.R[tid + 8 * i]); sm.Mx[tid] = mm; }
    __syncthreads();
    m = sm.Mx[hd];
    float z = 0;
    for (int p = slot; p < T; p += 64) { float e = expf(S[p] - m); S[p] = e; z += e; }
    sm.R[tid] = z;
    __syncthreads();
    if (tid < 8) { float zz = 0; for (int i = 0; i < 64; i++) zz += sm.R[tid + 8 * i]; sm.Mx[tid] = zz; }
    __syncthreads();
    z = sm.Mx[hd];
    uint16_t* Pm = sm.Pm + hd * (M->max_ctx + 128);
    for (int p = slot; p < nk8 * 16; p += 64) Pm[p] = p < T ? f2bf(S[p] / z) : (uint16_t)0;
  }
  __syncthreads();
  // phase 3: out[head][dim] = sum_t P[t][head] V[t][dim]; two warps per 16 dims (halves of the positions)
  {
    const int rt = warp & 7, half = warp >> 3;
    const int kmid = ((nk8 >> 1) + 7) & ~7;
    const int k0 = half ? kmid : 0, k1 = half ? nk8 : kmid;
    const uint4* p = vc + (size_t)rt * maxK * 32 + lane;
    const uint32_t* pb = (const uint32_t*)(sm.Pm + g8 * (M->max_ctx + 128)) + t4;
    float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
    for (int k = k0; k < k1; k += 8) {
      uint4 a[8];
#pragma unroll
      for (int u = 0; u < 8; u++) a[u] = p[(size_t)(k + u) * 32];
#pragma unroll
      for (int u = 0; u < 8; u++) { uint32_t b0 = pb[(k + u) * 8], b1 = pb[(k + u) * 8 + 4]; MMA(c0, c1, c2, c3, a[u], b0, b1); }
    }
    float* O = sm.O + half * 1024;
    int d0 = rt * 16 + g8, h0 = 2 * t4;
    O[h0 * 128 + d0] = c0; O[(h0 + 1) * 128 + d0] = c1; O[h0 * 128 + d0 + 8] = c2; O[(h0 + 1) * 128 + d0 + 8] = c3;
  }
  __syncthreads();
  for (int i = tid; i < 1024; i += 512)
    M->attn[(size_t)b * 4096 + g * 1024 + i] = f2bf(sm.O[i] + sm.O[1024 + i]);
}

// ---------------------------------------------------------------------------------------------------------
#define WAIT_GE(ptr_, target_)                                                                              \
  {                                                                                                         \
    if (tid == 0) { const uint32_t tg__ = (uint32_t)(target_); while ((int)(vload(ptr_) - tg__) < 0) {} }   \
    __syncthreads();                                                                                        \
  }
#define SIGNAL(ptr_)                                                                                        \
  {                                                                                                         \
    __threadfence();                                                                                        \
    __syncthreads();                                                                                        \
    if (tid == 0) atomicAdd(ptr_, 1u);                                                                      \
  }

// RMSNorm of the residual into shared memory: float32 mean of squares, x * rsqrt rounded to bf16, times the weight
__device__ __forceinline__ void prologue_norm(const Model* M, const Smem& sm, uint2 nw, int B) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  uint2 xr[MAXB];
  for (int b = 0; b < B; b++) {
    xr[b] = ((const uint2*)(M->x + (size_t)b * HID))[tid];
    float v0 = bf2f(xr[b].x & 0xffff), v1 = bf2f(xr[b].x >> 16), v2 = bf2f(xr[b].y & 0xffff), v3 = bf2f(xr[b].y >> 16);
    float ss = v0 * v0 + v1 * v1 + v2 * v2 + v3 * v3;
    for (int o = 16; o > 0; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
    if (lane == 0) sm.R[warp * 8 + b] = ss;
  }
  __syncthreads();
  const float w0 = bf2f(nw.x & 0xffff), w1 = bf2f(nw.x >> 16), w2 = bf2f(nw.y & 0xffff), w3 = bf2f(nw.y >> 16);
  for (int b = 0; b < B; b++) {
    float tot = 0;
#pragma unroll
    for (int i = 0; i < 16; i++) tot += sm.R[i * 8 + b];
    const float rs = rsqrtf(tot * (1.0f / HID) + 1e-6f);
    float v0 = bf2f(xr[b].x & 0xffff), v1 = bf2f(xr[b].x >> 16), v2 = bf2f(xr[b].y & 0xffff), v3 = bf2f(xr[b].y >> 16);
    uint2 o;
    o.x = (uint32_t)f2bf(w0 * rbf(v0 * rs)) | ((uint32_t)f2bf(w1 * rbf(v1 * rs)) << 16);
    o.y = (uint32_t)f2bf(w2 * rbf(v2 * rs)) | ((uint32_t)f2bf(w3 * rbf(v3 * rs)) << 16);
    ((uint2*)(sm.xn + b * HID))[tid] = o;
  }
  __syncthreads();
}

// leader block: router logits (8 row tiles x 2 K halves on 16 warps), top 8 per sequence, sigmoid weights,
// union of the chosen experts over the batch
__device__ __forceinline__ void leader_route(const Model* M, const Smem& sm, int l, int B) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g8 = lane >> 2, t4 = lane & 3;
  Dyn& D = M->dyn[l];
  uint32_t* masks = sm.W + 8;          // [MAXB][4]
  uint32_t* sel = sm.W + 8 + 32;       // [MAXB][8] expert ids
  float* selv = sm.R + 128;            // [MAXB][8] logits
  float* RL = sm.S + 16 * 128;         // [MAXB][128] rounded router logits
  float4* Cst = (float4*)sm.S;         // [16 warps][32 lanes]
  {
    float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
    const int rt = warp & 7, half = warp >> 3;
    const uint32_t* xb = g8 < B ? (const uint32_t*)(sm.xn + g8 * HID + half * 1024) + t4 : sm.zero;
    gemv_tile<16>(M->L[l].router + (size_t)rt * 128 * 32 + half * 64 * 32 + lane, 64, xb, c0, c1, c2, c3);
    Cst[warp * 32 + lane] = make_float4(c0, c1, c2, c3);
  }
  __syncthreads();
  if (warp < 8) {
    float4 a = Cst[warp * 32 + lane], b = Cst[(warp + 8) * 32 + lane];
    const int e = warp * 16 + g8, b0 = 2 * t4, b1 = 2 * t4 + 1;
    if (b0 < B) { RL[b0 * 128 + e] = rbf(a.x + b.x); RL[b0 * 128 + e + 8] = rbf(a.z + b.z); }
    if (b1 < B) { RL[b1 * 128 + e] = rbf(a.y + b.y); RL[b1 * 128 + e + 8] = rbf(a.w + b.w); }
  }
  __syncthreads();
  if (warp < B) {
    const int b = warp;
    float v[4]; uint32_t taken = 0;
#pragma unroll
    for (int j = 0; j < 4; j++) v[j] = RL[b * 128 + lane + 32 * j];
    uint32_t m[4] = {0, 0, 0, 0};
    for (int r = 0; r < TOPK; r++) {
      int e; float val;
      if (M->force) {
        e = M->force[((size_t)l * MAXB + b) * TOPK + r];
        val = RL[b * 128 + e];
      } else {
        float best = -INFINITY; int bi = 0x7fffffff;
#pragma unroll
        for (int j = 0; j < 4; j++) if (!((taken >> j) & 1) && v[j] > best) { best = v[j]; bi = lane + 32 * j; }
        for (int o = 16; o > 0; o >>= 1) {
          float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
          if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
        }
        e = bi; val = best;
        if ((e & 31) == lane) taken |= 1u << (e >> 5);
      }
      m[e >> 5] |= 1u << (e & 31);
      if (lane == 0) { sel[b * 8 + r] = e; selv[b * 8 + r] = val; }
    }
    if (lane < 4) masks[b * 4 + lane] = m[lane];
  }
  __syncthreads();
  uint32_t um[4] = {0, 0, 0, 0};
  for (int b = 0; b < B; b++)
#pragma unroll
    for (int j = 0; j < 4; j++) um[j] |= masks[b * 4 + j];
  if (tid < 128) {
    int e = tid, wi = e >> 5;
    if ((um[wi] >> (e & 31)) & 1) {
      int slot = __popc(um[wi] & ((1u << (e & 31)) - 1));
      for (int j = 0; j < wi; j++) slot += __popc(um[j]);
      int bm = 0;
      for (int b = 0; b < B; b++) bm |= ((masks[b * 4 + wi] >> (e & 31)) & 1) << b;
      D.slot_expert[slot] = e;
      D.bmask[slot] = bm;
    }
  }
  if (warp < B && lane < TOPK) {
    const int b = warp;
    int e = sel[b * 8 + lane], wi = e >> 5;
    uint32_t below = (1u << (e & 31)) - 1;
    int slot = __popc(um[wi] & below), rank = __popc(masks[b * 4 + wi] & below);
    for (int j = 0; j < wi; j++) { slot += __popc(um[j]); rank += __popc(masks[b * 4 + j]); }
    float lg = selv[b * 8 + lane];
    D.bslot[b][rank] = slot;
    D.bw[b][rank] = rbf(1.0f / (1.0f + expf(-lg)));
  }
  if (tid == 0) D.U = __popc(um[0]) + __popc(um[1]) + __popc(um[2]) + __popc(um[3]);
}

// greedy choice from per-block candidates (leader block)
__device__ __forceinline__ void leader_argmax(const Model* M, const Launch& A, int step_done, int NB) {
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  if (warp < A.B) {
    float best = -INFINITY; int bi = 0x7fffffff;
    for (int j = lane; j < NB; j += 32) {
      float v = M->candv[j * MAXB + warp]; int ix = M->candi[j * MAXB + warp];
      if (v > best || (v == best && ix < bi)) { best = v; bi = ix; }
    }
    for (int o = 16; o > 0; o >>= 1) {
      float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
      if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
    }
    if (lane == 0) { M->curtok[warp] = bi; A.tok_out[(size_t)warp * A.nsteps + step_done] = bi; }
  }
}

#define PROF(k_) { if (M->prof && blockIdx.x == 0 && tid == 0) { long long t__ = clock64(); M->prof[k_] += t__ - tprof; tprof = t__; } }

__global__ void __launch_bounds__(512, 1) mk_kernel(Launch A) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Model* M = A.M;
  Ctl* C = M->ctl;
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g8 = lane >> 2, t4 = lane & 3;
  const int b0i = 2 * t4, b1i = 2 * t4 + 1;
  const int B = A.B, NB = gridDim.x, j = blockIdx.x;
  const bool act = g8 < B;
  Smem sm;
  {
    const int ctx = M->max_ctx;
    unsigned char* p = smraw;
    sm.xn = (uint16_t*)p; p += MAXB * HID * 2;
    sm.zero = (uint32_t*)p; p += 8192;
    sm.S = (float*)p; p += 8 * ctx * 4;
    sm.Pm = (uint16_t*)p; p += 8 * (ctx + 128) * 2;
    sm.Qs = (uint16_t*)p; p += 8 * 128 * 2;
    sm.O = (float*)p; p += 2 * 8 * 128 * 4;
    sm.R = (float*)p; p += 512 * 4;
    sm.Mx = (float*)p; p += 8 * 4;
    sm.W = (uint32_t*)p;
  }
  for (int i = tid; i < 2048; i += 512) sm.zero[i] = 0;
  const bool att_block = j >= 1 && j <= 4 * B;
  const int NBg = NB - 4 * B, sidx = j == 0 ? 0 : j - 4 * B;  // blocks that run gate|up tiles, and this block's index among them
  long long tprof = clock64();
  for (int step = 0; step < A.nsteps; step++) {
    const int pos = A.pos + step;
    const uint32_t S = A.s0 + step;
    if (j == 0) {
      if (step > 0) { WAIT_GE(&C->cntH, NB * (A.h0 + step)); leader_argmax(M, A, step - 1, NB); __syncthreads(); }
      for (int b = 0; b < B; b++) {
        int64_t tk = (step == 0) ? A.tok_in[(size_t)b * A.tok_stride] : M->curtok[b];
        ((uint2*)(M->x + (size_t)b * HID))[tid] = ((const uint2*)(M->embed + (size_t)tk * HID))[tid];
      }
      __threadfence();
      __syncthreads();
      if (tid == 0) C->tok_seq = S + 1;
    }
    WAIT_GE(&C->tok_seq, S + 1);
    PROF(0);
    for (int l = 0; l < NLAYER; l++) {
      const LayerW& LW = M->L[l];
      const uint32_t G = A.g0 + step * NLAYER + l;
      const uint2 nw = ((const uint2*)LW.normw)[tid];
      if (l > 0) WAIT_GE(&C->cntC, NB * G);
      PROF(1);
      if (M->dbg_x && j == 0) for (int b = 0; b < B; b++) for (int i = tid; i < HID; i += 512) M->dbg_x[((size_t)l * MAXB + b) * HID + i] = M->x[(size_t)b * HID + i];
      prologue_norm(M, sm, nw, B);
      PROF(2);
      // ---- A: q|k|v rows (K split in 4, one chunk per warp); the leader block routes meanwhile
      if (j == 0) {
        if (!LW.dense) leader_route(M, sm, l, B);
        __threadfence();
        __syncthreads();
        if (tid == 0) C->route_seq = G + 1;
      } else {
        const int c = warp * (NB - 1) + (j - 1);
        if (c < 1280) {
          const int r = c >> 2, sp = c & 3;
          float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
          const uint32_t* xb = act ? (const uint32_t*)(sm.xn + g8 * HID + sp * 512) + t4 : sm.zero;
          gemv_tile<16>(LW.qkv + (size_t)r * 128 * 32 + sp * 32 * 32 + lane, 32, xb, c0, c1, c2, c3);
          float* o = M->part + (size_t)sp * MAXB * PART_ROWS + r * 16 + g8;
          if (b0i < B) { o[(size_t)b0i * PART_ROWS] = c0; o[(size_t)b0i * PART_ROWS + 8] = c2; }
          if (b1i < B) { o[(size_t)b1i * PART_ROWS] = c1; o[(size_t)b1i * PART_ROWS + 8] = c3; }
        }
      }
      SIGNAL(&C->cntA);
      PROF(3);
      // ---- B: attention on blocks 1..4B, gate|up of the chosen experts on the others
      if (att_block) {
        WAIT_GE(&C->cntA, NB * (G + 1));
        attention_task(M, sm, l, j - 1, B, pos);
      } else {
        WAIT_GE(&C->route_seq, G + 1);
        PROF(4);
        const int gu = LW.gu_tiles, n = M->dyn[l].U * gu;
        for (int i = warp * NBg + sidx; i < n; i += 16 * NBg) {
          const int u = i / gu, m = i % gu;
          const int e = M->dyn[l].slot_expert[u];
          float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
          const uint32_t* xb = act ? (const uint32_t*)(sm.xn + g8 * HID) + t4 : sm.zero;
          gemv_tile<16>(LW.expert + (size_t)e * LW.exp_stride + (size_t)m * 128 * 32 + lane, 128, xb, c0, c1, c2, c3);
          uint16_t* h = M->h + (size_t)u * MAXB * HMAX + m * 8 + g8;
          if (b0i < B) { float gt = rbf(c0); float a = rbf(gt / (1.0f + expf(-gt))); h[(size_t)b0i * HMAX] = f2bf(a * rbf(c2)); }
          if (b1i < B) { float gt = rbf(c1); float a = rbf(gt / (1.0f + expf(-gt))); h[(size_t)b1i * HMAX] = f2bf(a * rbf(c3)); }
        }
      }
      SIGNAL(&C->cntB);
      PROF(5);
      // ---- C: one residual row tile per block: o_proj (4 K chunks) + down of every chosen expert, combined here
      WAIT_GE(&C->cntB, NB * (G + 1));
      PROF(6);
      if (j < 128) {
        const Dyn& D = M->dyn[l];
        const int nu = 4 + (LW.dense ? 4 : D.U);
        float4* Cst = (float4*)sm.S;
        for (int un = warp; un < nu; un += 16) {
          float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
          if (un < 4) {
            const uint32_t* xb = act ? (const uint32_t*)(M->attn + g8 * 4096 + un * 1024) + t4 : M->zeros;
            gemv_tile<16>(LW.o + (size_t)j * 256 * 32 + un * 64 * 32 + lane, 64, xb, c0, c1, c2, c3);
          } else if (LW.dense) {
            const int sp = un - 4;
            const uint32_t* xb = act ? (const uint32_t*)(M->h + (size_t)g8 * HMAX + sp * 768) + t4 : M->zeros;
            gemv_tile<16>(LW.expert + (size_t)LW.gu_tiles * 128 * 32 + (size_t)j * 192 * 32 + sp * 48 * 32 + lane, 48, xb, c0, c1, c2, c3);
          } else {
            const int u = un - 4, e = D.slot_expert[u];
            const uint32_t* xb = ((D.bmask[u] >> g8) & 1) ? (const uint32_t*)(M->h + ((size_t)u * MAXB + g8) * HMAX) + t4 : M->zeros;
            gemv_tile<16>(LW.expert + (size_t)e * LW.exp_stride + (size_t)LW.gu_tiles * 128 * 32 + (size_t)j * 48 * 32 + lane, 48, xb, c0, c1, c2, c3);
          }
          Cst[un * 32 + lane] = make_float4(c0, c1, c2, c3);
        }
        __syncthreads();
        if (warp == 0) {
#pragma unroll
          for (int q = 0; q < 4; q++) {
            const int b = 2 * t4 + (q & 1), row = j * 16 + g8 + (q >> 1) * 8;
            if (b < B) {
              const float* cs = (const float*)(Cst + lane) + q;  // unit un at cs[un * 128]
              const float a = rbf(cs[0] + cs[128] + cs[256] + cs[384]);
              float mlp;
              if (LW.dense) mlp = rbf(cs[4 * 128] + cs[5 * 128] + cs[6 * 128] + cs[7 * 128]);
              else {
                mlp = 0;
#pragma unroll
                for (int jj = 0; jj < TOPK; jj++) mlp = rbf(mlp + rbf(rbf(cs[(4 + D.bslot[b][jj]) * 128]) * D.bw[b][jj]));
              }
              uint16_t* xp = M->x + (size_t)b * HID + row;
              *xp = f2bf(rbf(bf2f(*xp) + a) + mlp);
            }
          }
        }
      }
      SIGNAL(&C->cntC);
      PROF(7);
    }
    // ---- head: final norm, 16384 row tiles spread over every warp
    {
      const uint2 nw = ((const uint2*)M->normf)[tid];
      WAIT_GE(&C->cntC, NB * (A.g0 + (step + 1) * NLAYER));
      if (M->dbg_x && j == 0) for (int b = 0; b < B; b++) for (int i = tid; i < HID; i += 512) M->dbg_x[((size_t)NLAYER * MAXB + b) * HID + i] = M->x[(size_t)b * HID + i];
      prologue_norm(M, sm, nw, B);
      PROF(8);
      float bv0 = -INFINITY, bv1 = -INFINITY; int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
      const uint32_t* xb = act ? (const uint32_t*)(sm.xn + g8 * HID) + t4 : sm.zero;
      for (int i = warp * NB + j; i < VOCAB / 16; i += 16 * NB) {
        float c0 = 0, c1 = 0, c2 = 0, c3 = 0;
        gemv_tile<16>(M->head + (size_t)i * 128 * 32 + lane, 128, xb, c0, c1, c2, c3);
        const int row = i * 16 + g8;
        if (A.gen) {
          if (c0 > bv0) { bv0 = c0; bi0 = row; }
          if (c2 > bv0) { bv0 = c2; bi0 = row + 8; }
          if (c1 > bv1) { bv1 = c1; bi1 = row; }
          if (c3 > bv1) { bv1 = c3; bi1 = row + 8; }
        } else {
          float* lg = A.logits_out;
          if (b0i < B) { lg[(size_t)b0i * VOCAB + row] = c0; lg[(size_t)b0i * VOCAB + row + 8] = c2; }
          if (b1i < B) { lg[(size_t)b1i * VOCAB + row] = c1; lg[(size_t)b1i * VOCAB + row + 8] = c3; }
        }
      }
      if (A.gen) {
        // candidates of this block: [8 batch columns][128 = 16 warps x 8 row groups]
        float* CV = sm.S; int* CI = (int*)(sm.S + 1024);
        CV[b0i * 128 + warp * 8 + g8] = bv0; CI[b0i * 128 + warp * 8 + g8] = bi0;
        CV[b1i * 128 + warp * 8 + g8] = bv1; CI[b1i * 128 + warp * 8 + g8] = bi1;
        __syncthreads();
        if (warp < B) {
          float best = -INFINITY; int bi = 0x7fffffff;
#pragma unroll
          for (int q = 0; q < 4; q++) {
            float v = CV[warp * 128 + lane + 32 * q]; int ix = CI[warp * 128 + lane + 32 * q];
            if (v > best || (v == best && ix < bi)) { best = v; bi = ix; }
          }
          for (int o = 16; o > 0; o >>= 1) {
            float ov = __shfl_xor_sync(0xffffffffu, best, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
            if (ov > best || (ov == best && oi < bi)) { best = ov; bi = oi; }
          }
          if (lane == 0) { M->candv[j * MAXB + warp] = best; M->candi[j * MAXB + warp] = bi; }
        }
        SIGNAL(&C->cntH);
      }
      PROF(9);
    }
  }
  if (A.gen && j == 0) { WAIT_GE(&C->cntH, NB * (A.h0 + A.nsteps)); leader_argmax(M, A, A.nsteps - 1, NB); }
}

// ---------------------------------------------------------------------------------------------------------
// host side
static Model* g_model_dev = nullptr;
static uint32_t g_g0 = 0, g_s0 = 0, g_h0 = 0;
static int g_smem = 0;
static int g_blocks = 132;

extern "C" {

int mk_sizeof_model() { return (int)sizeof(Model); }
int mk_sizeof_ctl() { return (int)sizeof(Ctl); }
int mk_sizeof_dyn() { return (int)sizeof(Dyn); }
int mk_sizeof_layer() { return (int)sizeof(LayerW); }

// model_host: a filled Model struct (device pointers inside); model_dev: device memory to hold it
int mk_init(const void* model_host, void* model_dev, int max_ctx) {
  cudaError_t e = cudaMemcpy(model_dev, model_host, sizeof(Model), cudaMemcpyHostToDevice);
  if (e != cudaSuccess) { fprintf(stderr, "mk_init memcpy: %s\n", cudaGetErrorString(e)); return 1; }
  g_model_dev = (Model*)model_dev;
  g_smem = MAXB * HID * 2 + 8192 + 8 * max_ctx * 4 + 8 * (max_ctx + 128) * 2 + 8 * 128 * 2 + 2 * 8 * 128 * 4 + 512 * 4 + 8 * 4 + 256 * 4;
  // (more than half an SM's shared memory: one block per SM)
  e = cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, g_smem);
  if (e != cudaSuccess) { fprintf(stderr, "mk_init smem %d: %s\n", g_smem, cudaGetErrorString(e)); return 2; }
  int dev = 0; cudaGetDevice(&dev);
  cudaDeviceProp prop; cudaGetDeviceProperties(&prop, dev);
  g_blocks = prop.multiProcessorCount;
  g_g0 = g_s0 = g_h0 = 0;
  return 0;
}

static int launch(const int64_t* tok_in, int tok_stride, float* logits_out, int64_t* tok_out, int B, int pos, int nsteps, int gen) {
  Launch A;
  A.M = g_model_dev; A.tok_in = tok_in; A.logits_out = logits_out; A.tok_out = tok_out;
  A.B = B; A.pos = pos; A.nsteps = nsteps; A.gen = gen; A.tok_stride = tok_stride; A.g0 = g_g0; A.s0 = g_s0; A.h0 = g_h0;
  mk_kernel<<<g_blocks, 512, g_smem, 0>>>(A);
  g_g0 += (uint32_t)nsteps * NLAYER; g_s0 += nsteps; if (gen) g_h0 += nsteps;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) { fprintf(stderr, "mk launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}

int mk_step(const int64_t* tok_in, int tok_stride, float* logits_out, int B, int pos) { return launch(tok_in, tok_stride, logits_out, nullptr, B, pos, 1, 0); }
int mk_generate(const int64_t* tok_in, int tok_stride, int64_t* tok_out, int B, int pos, int nsteps) { return launch(tok_in, tok_stride, nullptr, tok_out, B, pos, nsteps, 1); }

}  // extern "C"
