"""North-Mini-Code-1.0 decode engine: one persistent CUDA kernel per step (engine/mk.cu).

This file only loads the checkpoint into the kernel's memory layout and launches the kernel; no model code of
any library runs in the timed path.

Layout (track A: every weight keeps its BF16 bits; only the order in memory changes): each matrix is stored in
tensor-core fragment order, 16x16 tiles, 512 bytes per tile, so that one 16-byte load per thread feeds one mma.
"""
import ctypes
import json
import os
import struct
import time

import torch

HID, NLAYER, TOPK, MAXB, MAXU, VOCAB = 2048, 49, 8, 8, 64, 262144
PART_ROWS, HMAX = 5248, 3072
HERE = os.path.dirname(os.path.abspath(__file__))


class LayerW(ctypes.Structure):
    _fields_ = [("qkv", ctypes.c_void_p), ("router", ctypes.c_void_p), ("o", ctypes.c_void_p), ("expert", ctypes.c_void_p),
                ("normw", ctypes.c_void_p), ("exp_stride", ctypes.c_uint64),
                ("gu_tiles", ctypes.c_int), ("down_K", ctypes.c_int), ("rope", ctypes.c_int), ("dense", ctypes.c_int)]


PTRS = ["head", "embed", "normf", "rope", "kc", "vc", "x", "qkvo", "qkvp", "rl", "attn", "attp", "h", "logits", "candv",
        "candi", "curtok", "zeros", "ctl", "dyn", "dbg_x", "force", "prof"]


class Model(ctypes.Structure):
    _fields_ = [("L", LayerW * NLAYER)] + [(n, ctypes.c_void_p) for n in PTRS] + [("max_ctx", ctypes.c_int), ("maxK", ctypes.c_int)]


def frag(w: torch.Tensor) -> torch.Tensor:
    """[..., M, N] -> mma A-operand order [..., M/16, N/16, 32 lanes, 4 regs, 2]: lane = 4*(row%8) + (col%8)//2,
    reg = 2*((col%16)//8) + (row%16)//8."""
    lead = w.shape[:-2]
    M, N = w.shape[-2:]
    v = w.reshape(*lead, M // 16, 2, 8, N // 16, 2, 4, 2)
    n = len(lead)
    v = v.permute(*range(n), n + 0, n + 3, n + 2, n + 5, n + 4, n + 1, n + 6)
    return v.reshape(*lead, -1)


def read_shard(path: str, device: str) -> dict:
    """All tensors of one safetensors shard as BF16 views of a single device buffer."""
    with open(path, "rb") as f:
        n = struct.unpack("<Q", f.read(8))[0]
        header = json.loads(f.read(n))
        import numpy as np
        raw = np.fromfile(f, dtype=np.int16)
    buf = torch.from_numpy(raw).to(device)
    out = {}
    for name, info in header.items():
        if name == "__metadata__":
            continue
        assert info["dtype"] == "BF16", (name, info["dtype"])
        a, b = info["data_offsets"]
        out[name] = buf[a // 2:b // 2].view(torch.bfloat16).view(*info["shape"])
    return out


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        assert max_batch <= MAXB, "this engine is built for batches up to 8"
        t0 = time.time()
        self.dev = "cuda"
        torch.cuda.init()
        self.lib = ctypes.CDLL(os.path.join(HERE, "libmk.so"))
        assert self.lib.mk_sizeof_model() == ctypes.sizeof(Model), (self.lib.mk_sizeof_model(), ctypes.sizeof(Model))
        self.max_ctx = max(128, (max_context + 127) // 128 * 128)
        assert self.max_ctx <= 2048, "contexts beyond 2048 tokens are not implemented in this build"
        self.maxK = self.max_ctx // 16
        self.keep = {}
        m = Model()
        # ---- arena layout (in int16 elements)
        sz_qkv, sz_router, sz_o, sz_head = 320 * 128 * 256, 8 * 128 * 256, 128 * 256 * 256, (VOCAB // 16) * 128 * 256
        geo = [(1, 384, 192)] + [(128, 96, 48)] * (NLAYER - 1)  # experts, gate|up tiles, down K
        off, lay = 0, []
        for l in range(NLAYER):
            ne, gt, dk = geo[l]
            stride = (gt * 128 + 128 * dk) * 256
            d = {"qkv": off}; off += sz_qkv
            d["router"] = off; off += sz_router if l else 0
            d["o"] = off; off += sz_o
            d["expert"] = off; off += ne * stride
            d["stride"] = stride
            lay.append(d)
        head_off = off; off += sz_head
        arena = torch.empty(off, dtype=torch.int16, device=self.dev)
        self.keep["arena"] = arena
        base = arena.data_ptr()
        normw = torch.empty((NLAYER + 1, HID), dtype=torch.bfloat16, device=self.dev)
        embed = torch.empty((VOCAB, HID), dtype=torch.bfloat16, device=self.dev)
        self.keep.update(normw=normw, embed=embed)

        def put(o, t):
            t = t.contiguous().view(torch.int16).reshape(-1)
            arena[o:o + t.numel()] = t

        def layer_ready(l, have):
            p = f"model.layers.{l}."
            if p + "self_attn.q_proj.weight" not in have or p + "self_attn.o_proj.weight" not in have or p + "input_layernorm.weight" not in have:
                return False
            if p + "self_attn.k_proj.weight" not in have or p + "self_attn.v_proj.weight" not in have:
                return False
            if l == 0:
                return all(p + f"mlp.{k}_proj.weight" in have for k in ("gate", "up", "down"))
            if p + "mlp.gate.weight" not in have:
                return False
            return all(p + f"mlp.experts.{e}.{k}_proj.weight" in have for e in (0, 63, 127) for k in ("gate", "up", "down")) and \
                sum(1 for k in have if k.startswith(p + "mlp.experts.")) == 384

        def do_layer(l, have):
            p = f"model.layers.{l}."
            g = lambda n: have.pop(p + n)
            d = lay[l]
            put(d["qkv"], frag(torch.cat([g("self_attn.q_proj.weight"), g("self_attn.k_proj.weight"), g("self_attn.v_proj.weight")], 0)))
            put(d["o"], frag(g("self_attn.o_proj.weight")))
            normw[l] = g("input_layernorm.weight")
            ne, gt, dk = geo[l]
            if l == 0:
                gate, up, down = g("mlp.gate_proj.weight")[None], g("mlp.up_proj.weight")[None], g("mlp.down_proj.weight")[None]
            else:
                put(d["router"], frag(g("mlp.gate.weight")))
                gate = torch.stack([g(f"mlp.experts.{e}.gate_proj.weight") for e in range(ne)])
                up = torch.stack([g(f"mlp.experts.{e}.up_proj.weight") for e in range(ne)])
                down = torch.stack([g(f"mlp.experts.{e}.down_proj.weight") for e in range(ne)])
            gu = torch.stack([gate.view(ne, gt, 8, HID), up.view(ne, gt, 8, HID)], 2).reshape(ne, gt * 16, HID)
            del gate, up
            blk = torch.cat([frag(gu).view(torch.int16), frag(down).view(torch.int16)], 1)
            del gu, down
            put(d["expert"], blk)
            del blk

        index = json.load(open(os.path.join(model_dir, "model.safetensors.index.json")))["weight_map"]
        shards = sorted(set(index.values()))
        have, todo = {}, list(range(NLAYER))
        for s in shards:
            have.update(read_shard(os.path.join(model_dir, s), self.dev))
            if "model.embed_tokens.weight" in have:
                e = have.pop("model.embed_tokens.weight")
                embed.copy_(e)
                for r0 in range(0, VOCAB, 32768):
                    put(head_off + r0 // 16 * 128 * 256, frag(e[r0:r0 + 32768]))
                del e
            if "model.norm.weight" in have:
                normw[NLAYER] = have.pop("model.norm.weight")
            while todo and layer_ready(todo[0], have):
                do_layer(todo.pop(0), have)
        assert not todo and not have, (todo, list(have)[:5])
        del have
        torch.cuda.empty_cache()
        # ---- tables and scratch
        K = self.keep
        inv_freq = 1.0 / (50000 ** (torch.arange(0, 128, 2, dtype=torch.float, device=self.dev) / 128))
        fr = torch.arange(self.max_ctx, device=self.dev)[:, None].float() * inv_freq[None]
        K["rope"] = torch.stack([fr.cos().to(torch.bfloat16).float(), fr.sin().to(torch.bfloat16).float()], -1).contiguous()
        z = lambda *shape, dtype=torch.int16: torch.zeros(shape, dtype=dtype, device=self.dev)
        kvn = NLAYER * MAXB * 4 * self.maxK * 256 * 8
        K["kc"], K["vc"] = z(kvn), z(kvn)
        K["x"] = z(MAXB * HID)
        K["qkvo"] = z(MAXB * 5120)
        K["qkvp"] = z(2 * MAXB * 5120, dtype=torch.float32)
        K["rl"] = z(2 * MAXB * 128 * 2, dtype=torch.int32)
        K["attn"] = z(MAXB * 4096)
        K["attp"] = z(32 * 8 * 1040, dtype=torch.float32)
        K["h"] = z(MAXU * MAXB * HMAX)
        K["logits"] = z(MAXB * VOCAB, dtype=torch.float32)
        K["candv"] = z(MAXB * 256, dtype=torch.float32)
        K["candi"] = z(MAXB * 256, dtype=torch.int32)
        K["curtok"] = z(MAXB, dtype=torch.int64)
        K["zeros"] = z(16384)
        K["ctl"] = z(self.lib.mk_sizeof_ctl(), dtype=torch.uint8)
        K["dyn"] = z(NLAYER * self.lib.mk_sizeof_dyn(), dtype=torch.uint8)
        K["dyn"][:4] = torch.tensor([1, 0, 0, 0], dtype=torch.uint8)  # layer 0 is dense: one "expert", slot 0
        K["modeldev"] = z(ctypes.sizeof(Model) + 64, dtype=torch.uint8)
        for l in range(NLAYER):
            ne, gt, dk = geo[l]
            L, d = m.L[l], lay[l]
            L.qkv, L.router, L.o, L.expert = base + 2 * d["qkv"], base + 2 * d["router"], base + 2 * d["o"], base + 2 * d["expert"]
            L.normw = normw[l].data_ptr()
            L.exp_stride = d["stride"] * 2 // 16
            L.gu_tiles, L.down_K, L.dense = gt, dk, int(l == 0)
            L.rope = int(l == 0 or l % 4 != 0)
        m.head, m.embed, m.normf = base + 2 * head_off, embed.data_ptr(), normw[NLAYER].data_ptr()
        for n in PTRS[3:20]:
            setattr(m, n, K[n].data_ptr())
        m.dbg_x, m.force, m.prof = None, None, None
        m.max_ctx, m.maxK = self.max_ctx, self.maxK
        self.m = m
        self._commit()
        self.pos = 0
        self.pending, self.active, self.max_batch = [], None, max_batch
        self.calls = {"step": 0, "generate": 0}
        self.load_seconds = time.time() - t0

    def _commit(self):
        torch.cuda.synchronize()
        rc = self.lib.mk_init(ctypes.byref(self.m), ctypes.c_void_p(self.keep["modeldev"].data_ptr()), self.max_ctx)
        assert rc == 0, rc
        self.keep["ctl"].zero_()
        torch.cuda.synchronize()

    def reset(self) -> None:
        self.pos = 0

    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        B = tokens.shape[0]
        if tokens.dtype != torch.int64:
            tokens = tokens.to(torch.int64)
        logits = torch.empty((B, VOCAB), dtype=torch.float32, device=self.dev)
        rc = self.lib.mk_step(ctypes.c_void_p(tokens.data_ptr()), tokens.stride(0), ctypes.c_void_p(logits.data_ptr()), B, self.pos)
        assert rc == 0
        self.pos += 1
        self.calls["step"] += 1
        return logits

    def generate(self, tokens: torch.Tensor, n_steps: int) -> torch.Tensor:
        B = tokens.shape[0]
        if tokens.dtype != torch.int64:
            tokens = tokens.to(torch.int64)
        out = torch.empty((B, n_steps), dtype=torch.int64, device=self.dev)
        rc = self.lib.mk_generate(ctypes.c_void_p(tokens.data_ptr()), tokens.stride(0), ctypes.c_void_p(out.data_ptr()), B, self.pos, n_steps)
        assert rc == 0
        self.pos += n_steps
        self.calls["generate"] += 1
        return out

    # ---- the online contract of the HTTP server: the whole decode of a cohort is one kernel launch on the device
    GATHER_S = 0.03   # how long the first request of a cohort waits for others that arrive with it

    def submit(self, rid: int, prompt, n: int) -> None:
        self.pending.append((int(rid), [int(t) for t in prompt], int(n), time.perf_counter()))

    def poll(self):
        if self.active is None:
            if not self.pending:
                return []
            first = self.pending[0]
            group = [r for r in self.pending if len(r[1]) == len(first[1]) and r[2] == first[2]][:self.max_batch]
            if len(group) < self.max_batch and time.perf_counter() - first[3] < self.GATHER_S:
                return []
            self.pending = [r for r in self.pending if all(r is not g for g in group)]
            B, P, n = len(group), len(first[1]), first[2]
            assert 1 <= P and P + n <= self.max_ctx, "prompt + new tokens exceed the engine's context"
            prompt = torch.tensor([r[1] for r in group], dtype=torch.int64, device=self.dev)
            out = torch.empty((n, B), dtype=torch.int64, device=self.dev)
            torch.cuda.synchronize()
            rc = self.lib.mk_serve_start(ctypes.c_void_p(prompt.data_ptr()), P, ctypes.c_void_p(out.data_ptr()), B, P, n)
            assert rc == 0
            self.host = (ctypes.c_int64 * (n * B))()
            self.active = {"rids": [r[0] for r in group], "B": B, "n": n, "sent": 0, "prompt": prompt, "out": out}
            self.pos = P - 1 + n
            self.calls["serve"] = self.calls.get("serve", 0) + 1
            return []
        a = self.active
        prog = self.lib.mk_serve_poll()
        if prog <= a["sent"]:
            return []
        k0, B = a["sent"], a["B"]
        rc = self.lib.mk_serve_fetch(ctypes.c_void_p(a["out"].data_ptr()), ctypes.byref(self.host, k0 * B * 8), B, k0, prog)
        assert rc == 0
        done = prog == a["n"]
        events = [(rid, [self.host[k * B + i] for k in range(k0, prog)], done) for i, rid in enumerate(a["rids"])]
        a["sent"] = prog
        if done:
            self.active = None
        return events

    def close(self) -> None:
        torch.cuda.synchronize()
        self.keep = {}

    def stats(self) -> dict:
        return {"implementation": "megakernel v5 (track A: BF16 weights in mma fragment order, static balanced schedule, chunked attention, device loop behind submit/poll)", "load_seconds": self.load_seconds, **self.calls}
