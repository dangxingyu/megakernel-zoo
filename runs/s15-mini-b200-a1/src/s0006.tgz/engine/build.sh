#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
OUT=${MK_BUILD_DIR:-build}
mkdir -p "$OUT"
FLAGS="-O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xptxas -v --shared -Xcompiler -fPIC"
rm -f "$OUT/libmk.so"
nvcc $FLAGS ${MK_DEFS:-} -o "$OUT/libmk.so" mk.cu 2> "$OUT/ptxas.log" || { cat "$OUT/ptxas.log"; exit 1; }
grep -A2 "Compiling entry function 'mk_kernel'" "$OUT/ptxas.log" | grep -E "stack|registers" || true
# study builds (never used by the evaluator): MK_VARIANTS="prof:-DMKPROF skel:-DSKEL,-DMKPROF"
for v in ${MK_VARIANTS:-}; do
  name=${v%%:*}; defs=${v#*:}; defs=${defs//,/ }
  rm -f "$OUT/libmk_$name.so"
  nvcc $FLAGS $defs -o "$OUT/libmk_$name.so" mk.cu 2> "$OUT/ptxas_$name.log" || { cat "$OUT/ptxas_$name.log"; exit 1; }
done
echo built
