// Inkling-2-Small decode engine: one persistent kernel per card per step, four cards.
// Attention TP4 by heads, experts TP4 inside every expert (intermediate 576 per card), everything else replicated.
// See notes/plan.md for the design and the layouts.
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef __nv_bfloat16 bf16;

#define H 4608
#define NL 48
#define NE 384
#define TOPK 8
#define ILOC 576
#define HD 128
#define NQL 12          // local q heads
#define NKVL 2          // local kv heads
#define DREL 16
#define RELEXT 1024
#define WIN 1024
#define NCARD 4
#define MAXB 8
#define NTH 1024
#define NWARP (NTH / 32)
#define CHUNK 128       // attention positions per block
#define MAXCHUNK 17     // up to 2176 positions
#define MAXU 64         // max union experts per layer (B<=8)
#define VOCAB_REAL 200058
#ifndef MAXSLOT
#define MAXSLOT 24
#endif

// ------------------------------------------------------------------------------------------------ parameters
struct W12M {               // exact 12-bit code of a BF16 matrix (engine/w12.py)
  const uint8_t* data;      // [strips][units][3][32][16]
  const uint8_t* base;      // [rows] window base exponent
  const int* hdr;           // [strips*units] escape count | offset << 8
  const int* esc;           // entries: lane<<27 | reg<<23 | half<<22 | bf16 bits
};
struct LayerW {
  const uint8_t* wqkv;      // bf16 frag [strips][U=72][4 j][32 lanes][16 B]
  const uint8_t* wo;        // bf16 frag [288][24]...
  const uint8_t* wr;        // router bf16 frag [24][72]
  const float* rbias;       // [384]
  const uint8_t* w13;       // [384][72 strips][72 units][UB]
  const uint8_t* w2;        // [384][288 strips][9 units][UB]
  const float* f13;         // [384] weight outer factor (nvfp4), unused for mxfp8
  const float* f2;
  const bf16* norm[3];      // attn_norm (local layers: all three the same) or q/k/v_input_norm
  const bf16* mlp_norm;
  const bf16* ksc;          // local: [256][4] (local channels); global: static_w [4][256]
  const bf16* vsc;
  const bf16* attn_sc;      // [4608][4]
  const bf16* mlp_sc;
  const bf16* qscale;       // [12][128]
  const bf16* rscale;       // [12][16]
  const bf16* relp;         // [16][1024]
  const float* aq;          // attention residual queries [nq][4608] (layer 0: null)
  const float* mq;          // [4608]
  W12M qkv12, wo12, wr12;
  int glob;                 // global layer
  int mx;                   // experts are mxfp8
  int qkv_strips;           // 237 or 239
  int pad;
};

struct Comm {                       // lives on each card, written by all cards
  float attn[NCARD][288][MAXB * 16]; // o_proj partial per source card: [strip][lane-layout 128 floats]
  float mlp[NCARD][288][MAXB * 16];
  float amaxs[NL][NCARD][MAXU][MAXB]; // per source card: max |act| of its 576-slice per (union expert, token)
  float cand_v[NCARD][MAXB][256];   // argmax candidates per source card per block
  int cand_i[NCARD][MAXB][256];
  unsigned cnt[8];                  // 0 attn, 1 mlp, 2 amax, 3 final
};

struct Hdr {
  int card, B, nblk, pos, parity, want_logits, gen_idx, gen_n;
  unsigned xbase[4];
  float* logits; int* tokens; int* gen_out;
};
struct Ctx {
  Hdr h;
  LayerW L[NL];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm;
  const uint8_t* unembed; int un_strips; int un_row0;
  W12M un12;
  bf16* blocks;     // [9][MAXB][H] finished blocks (block 0 = h0)
  bf16* partial;    // [MAXB][H]
  bf16* attn_s;     // [MAXB][H]  attention output after its sconv (current layer)
  bf16* hist_attn;  // [NL][MAXB][3][H]
  bf16* hist_mlp;   // [NL][MAXB][3][H]
  bf16* hist_k;     // [NL][MAXB][3][256]
  bf16* hist_v;
  bf16* kc; bf16* vc; int maxctx; int pad0;  // [NL][MAXB][2][maxctx][128]
  bf16* xfrag;      // [3][72 units][32][4][2][2] bf16 frags of xq/xk/xv
  bf16* x2frag;     // router frag of the mlp input (bf16)
  uint8_t* w13frag; // quantized mlp input: f16 frag (nvfp4) or e4m3 frag (mxfp8)
  float* w13sc;     // [MAXB] outer (nvfp4) or [144][MAXB] block scales (mxfp8)
  bf16* qkvo;       // [MAXB][3840]
  float* rlog;      // [MAXB][384]
  int* ids; float* wts;   // [MAXB][8]
  int* uni; int* nuni;
  bf16* act;        // [MAXU][MAXB][576]
  uint8_t* w2frag;  // [MAXU][9 units] frags
  float* w2sc;      // [MAXU][MAXB] / [MAXU][18][MAXB]
  float* achunk;    // [MAXB][2][MAXCHUNK][6][2+128]
  unsigned* acnt;   // [MAXB][2]
  bf16* ofrag;      // o_proj B frag
  bf16* hfrag;      // final hidden frag
  float* part;      // gemv partial slots
  unsigned* scnt;   // per-strip arrival counters
  int* next_tok;    // [MAXB]
  unsigned* bar;    // [0] counter, [1] base
  Comm* comm[NCARD];
  unsigned long long* tprof;  // optional [NL+1][16] globaltimer stamps of block 0
  bf16* dbg;        // optional [NL][2][MAXB][H]: attention and mlp outputs after their sconv
  int* dbg_ids;     // optional [NL][MAXB][8]
  unsigned* amax_loc;  // [MAXU][MAXB] local running max (float bits), reset by the last strip of each expert
  unsigned* ucnt;      // [MAXU] strips finished per union expert
};

// ------------------------------------------------------------------------------------------------ small helpers
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint4 ld4(const void* p) { return *reinterpret_cast<const uint4*>(p); }
__device__ __forceinline__ uint32_t cvt_fp4x2(uint32_t b) {
  uint32_t r; unsigned short bs = (unsigned short)b;
  asm("{ .reg .b8 t; cvt.u8.u16 t, %1; cvt.rn.f16x2.e2m1x2 %0, t; }" : "=r"(r) : "h"(bs));
  return r;
}
__device__ __forceinline__ uint32_t cvt_e4m3x2_f16x2(uint32_t w16) {
  uint32_t r; unsigned short h = (unsigned short)w16;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(h));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ uint32_t prmt(uint32_t a, uint32_t b, uint32_t s) { uint32_t r; asm("prmt.b32 %0,%1,%2,%3;" : "=r"(r) : "r"(a), "r"(b), "r"(s)); return r; }
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_e4m3(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float ue8m0(uint32_t e) { return e == 0 ? __int_as_float(0x00400000) : __int_as_float(e << 23); }
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }

__device__ __forceinline__ unsigned ld_relaxed_gpu(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ unsigned ld_relaxed_sys(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.sys.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void fence_acqrel_gpu() { asm volatile("fence.acq_rel.gpu;" ::: "memory"); }
__device__ __forceinline__ void fence_acqrel_sys() { asm volatile("fence.acq_rel.sys;" ::: "memory"); }
__device__ __forceinline__ unsigned ld_acquire_gpu(const unsigned* p) { unsigned v; asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ unsigned ld_acquire_sys(const unsigned* p) { unsigned v; asm volatile("ld.acquire.sys.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void red_release_gpu(unsigned* p, unsigned v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void red_relaxed_sys(unsigned* p, unsigned v) { asm volatile("red.relaxed.sys.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void red_release_sys(unsigned* p, unsigned v) { asm volatile("red.release.sys.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }

// bf16/f16 B-fragment index (m16n8k16), unit-major: element (token g, k) -> index in 16-bit elements
__device__ __forceinline__ int fidx16(int g, int k) {
  int u = k >> 6, j = (k >> 4) & 3, kk = k & 15, r = kk >> 3, t = (kk & 7) >> 1, h = kk & 1;
  return ((((u * 32 + g * 4 + t) * 4 + j) * 2 + r) * 2 + h);
}
// e4m3 B-fragment index (m16n8k32), unit = 64 k: element (g, k) -> byte index
__device__ __forceinline__ int fidx8(int g, int k) {
  int u = k >> 6, s = (k >> 5) & 1, kk = k & 31, r = kk >> 4, t = (kk & 15) >> 2, e = kk & 3;
  return ((((u * 32 + g * 4 + t) * 2 + s) * 2 + r) * 4 + e);
}

// compact layouts for B == 1 (column 0 only): lanes t = 0..3 of g = 0
__device__ __forceinline__ int fidx16c(int k) {
  int u = k >> 6, j = (k >> 4) & 3, kk = k & 15, r = kk >> 3, t = (kk & 7) >> 1, h = kk & 1;
  return ((((u * 4 + t) * 4 + j) * 2 + r) * 2 + h);
}
__device__ __forceinline__ int fidx8c(int k) {
  int u = k >> 6, s = (k >> 5) & 1, kk = k & 31, r = kk >> 4, t = (kk & 15) >> 2, e = kk & 3;
  return ((((u * 4 + t) * 2 + s) * 2 + r) * 4 + e);
}
template <bool CPT> __device__ __forceinline__ int fi16(int g, int k) { return CPT ? fidx16c(k) : fidx16(g, k); }
template <bool CPT> __device__ __forceinline__ int fi8(int g, int k) { return CPT ? fidx8c(k) : fidx8(g, k); }
#define LSZ (CPT ? 4 : 32)
#define LSL (CPT ? (lane & 3) : lane)
// ------------------------------------------------------------------------------------------------ barriers
__device__ unsigned g_barbase_dummy;
__device__ __forceinline__ void grid_bar(const Ctx& c, unsigned& nbar, unsigned base) {
  __syncthreads();
  nbar += 1;
  if (threadIdx.x == 0) {
    unsigned target = base + nbar * gridDim.x;
    red_release_gpu(&c.bar[0], 1);
    while ((int)(ld_relaxed_gpu(&c.bar[0]) - target) < 0) { }
    fence_acqrel_gpu();
  }
  __syncthreads();
}
// cross-card events. Host keeps xbase[k] = events of kind k before this launch.
#ifndef XSIG_FLAT
#define XSIG_HIER
#endif
#ifdef XSIG_HIER
// local grid barrier, then block 0 signals every card once (measured: 152 per-block system fences cost 5-10 us)
#define XPER 1u
#else
// every block of every card signals counter k on every card
#define XPER gridDim.x
#endif
__device__ __forceinline__ void xsignal(const Ctx& c, int k, unsigned& nbar, unsigned base);
__device__ __forceinline__ void xwait(const Ctx& c, int k, unsigned events) {
  if (threadIdx.x == 0) {
    unsigned target = (c.h.xbase[k] + events) * NCARD * XPER;
    const unsigned* p = &c.comm[c.h.card]->cnt[k];
    while ((int)(ld_relaxed_sys(p) - target) < 0) { }
    fence_acqrel_sys();
  }
  __syncthreads();
}

__device__ __forceinline__ void xsignal(const Ctx& c, int k, unsigned& nbar, unsigned base) {
#ifdef XSIG_HIER
  grid_bar(c, nbar, base);
  if (blockIdx.x == 0 && threadIdx.x == 0) {
    __threadfence_system();
    for (int d = 0; d < NCARD; d++) red_relaxed_sys(&c.comm[d]->cnt[k], 1);   // ordered by the fence above
  }
#else
  __syncthreads();
  if (threadIdx.x == 0) {
    __threadfence_system();
    for (int d = 0; d < NCARD; d++) red_relaxed_sys(&c.comm[d]->cnt[k], 1);   // ordered by the fence above
  }
#endif
}
// ------------------------------------------------------------------------------------------------ L2 prefetch
// part `part` of `nparts` of [base, base+bytes): warp 0's lanes issue bulk L2 prefetches of 32 KB.
__device__ __forceinline__ void prefetch_l2(const void* base, long bytes, int part, int nparts) {
#ifndef NO_PREFETCH
  if (threadIdx.x >= 32 || nparts <= 0) return;
  long a = (bytes * part / nparts) & ~15L, b = (bytes * (part + 1) / nparts) & ~15L;
  if (part == nparts - 1) b = bytes & ~15L;
  const char* p = (const char*)base;
  for (long o = a + (long)threadIdx.x * 32768; o < b; o += 32L * 32768) {
    unsigned n = (unsigned)min(32768L, b - o);
    asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(p + o), "r"(n) : "memory");
  }
#endif
}
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %globaltimer;" : "=l"(t)); return t; }
#define TM(li, id) do { if (c.tprof && blockIdx.x == 0 && threadIdx.x == 0) c.tprof[(li) * 32 + (id)] = gtime(); } while (0)
// ------------------------------------------------------------------------------------------------ block reductions
template <int N>
__device__ __forceinline__ void block_sum(float* v, float* red) {  // red: smem [NWARP][N]
  int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
#pragma unroll
  for (int i = 0; i < N; i++) {
    float x = v[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x += __shfl_xor_sync(0xffffffff, x, o);
    v[i] = x;
  }
  __syncthreads();
  if (lane == 0)
#pragma unroll
    for (int i = 0; i < N; i++) red[w * N + i] = v[i];
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) {
    float s = 0.f;
    for (int j = 0; j < NWARP; j++) s += red[j * N + i];
    v[i] = s;
  }
  __syncthreads();
}
__device__ __forceinline__ float block_max1(float x, float* red) {
  int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffff, x, o));
  __syncthreads();
  if (lane == 0) red[w] = x;
  __syncthreads();
  float m = red[0];
  for (int j = 1; j < NWARP; j++) m = fmaxf(m, red[j]);
  __syncthreads();
  return m;
}

#define PER ((H + NTH - 1) / NTH)   // 5 elements per thread (the last one only for tid < 512)
#define VALID(e) (threadIdx.x + (e) * NTH < H)
// element e of thread: idx = threadIdx.x + e * NTH

// rms_norm of fp32 vector (per-thread regs) with bf16 weight -> bf16 values (as float)
__device__ __forceinline__ void rmsnorm_regs(const float* u, const bf16* w, float* y, float* red) {
  float s[1] = {0.f};
#pragma unroll
  for (int e = 0; e < PER; e++) if (VALID(e)) s[0] += u[e] * u[e];
  block_sum<1>(s, red);
  float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) { y[e] = 0.f; continue; }
    float v = u[e] * r;
    if (w) v = v * bf(w[threadIdx.x + e * NTH]);
    y[e] = rbf(v);
  }
}

// static short conv over [hist0, hist1, hist2, cur]; weight [C][4]; returns bf16-rounded float
__device__ __forceinline__ float sconv4(float h0, float h1, float h2, float cur, const bf16* w4) {
  float acc = 0.f;
  acc = acc + h0 * bf(w4[0]);
  acc = acc + h1 * bf(w4[1]);
  acc = acc + h2 * bf(w4[2]);
  acc = acc + cur * bf(w4[3]);
  return rbf((acc + cur) * 0.4472135954999579f);
}

// ------------------------------------------------------------------------------------------------ GEMV skeleton
// Flattened (strip, unit) space split evenly over all warps of the grid. A strip covered by several warps is
// summed in slot order by the last warp to arrive (per-strip counter). Epilogue gets per-lane d0..d3
// (row g, col 2t), (g, 2t+1), (g+8, 2t), (g+8, 2t+1).
__device__ __forceinline__ long wstart(long T, long w, long NW) { return T * w / NW; }
__device__ __forceinline__ long warp_of(long x, long T, long NW) { return ((x + 1) * NW - 1) / T; }

#ifndef MINU
#define MINU 4
#endif
template <class OP>
__device__ void gemv(const Ctx& c, OP& op, long strips, int U) {
  const long T = strips * U;
  const long NWALL = (long)gridDim.x * NWARP;
  const long NW = max(1L, min(NWALL, T / MINU));
  // logical warp index: consecutive logical warps sit on different SMs
  const long gw = (long)(threadIdx.x >> 5) * gridDim.x + blockIdx.x;
  if (gw >= NW) return;
  const int lane = threadIdx.x & 31;
  long beg = wstart(T, gw, NW), end = wstart(T, gw + 1, NW);
  long x = beg;
  const bool tmw = c.tprof && op.tm && gw == 0;   // block 0 warp 0 stamps its first strip
  if (tmw && lane == 0) c.tprof[op.layer * 32 + op.tm] = gtime();
  while (x < end) {
    long s = x / U;
    int u0 = (int)(x - s * U);
    int u1 = (int)min((long)U, end - s * U);
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    op.run(c, s, u0, u1, acc);
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 32 + op.tm + 1] = gtime();
    long fw = warp_of(s * U, T, NW), lw = warp_of(s * U + U - 1, T, NW);
    if (fw == lw) {
      op.epi(c, s, acc);
    } else {
      float* slot = c.part + ((s * MAXSLOT + (gw - fw)) * 32 + lane) * 4;
      *reinterpret_cast<float4*>(slot) = make_float4(acc[0], acc[1], acc[2], acc[3]);
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) { __threadfence(); old = atomicAdd(&c.scnt[s], 1u); }
      old = __shfl_sync(0xffffffff, old, 0);
      if (old == (unsigned)(lw - fw)) {
        __threadfence();
        float a[4] = {0.f, 0.f, 0.f, 0.f};
        const int ns = (int)(lw - fw) + 1;
        for (int k0 = 0; k0 < ns; k0 += 8) {
          float4 p[8];
#pragma unroll
          for (int q = 0; q < 8; q++)
            p[q] = (k0 + q < ns) ? __ldcg(reinterpret_cast<const float4*>(c.part + ((s * MAXSLOT + k0 + q) * 32 + lane) * 4))
                                 : make_float4(0.f, 0.f, 0.f, 0.f);
#pragma unroll
          for (int q = 0; q < 8; q++)
            if (k0 + q < ns) { a[0] += p[q].x; a[1] += p[q].y; a[2] += p[q].z; a[3] += p[q].w; }
        }
        if (lane == 0) c.scnt[s] = 0;
        op.epi(c, s, a);
      }
    }
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 32 + op.tm + 2] = gtime();
    x = s * U + u1;
  }
}

// BF16 dense: weights [strip][unit][j][lane][16B]; B frags (bf16) [unit][lane][j][2 u32]
template <bool CPT>
__device__ __forceinline__ void run_bf16(const uint8_t* wstrip, const uint32_t* xf, int u0, int u1, float* acc, int B) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  int u = u0;
  for (; u + 2 <= u1; u += 2) {
    uint4 w[8];
#pragma unroll
    for (int q = 0; q < 8; q++) w[q] = ldg_nc(wstrip + ((long)(u + (q >> 2)) * 4 + (q & 3)) * 512 + lane * 16);
    uint4 b[4];
#pragma unroll
    for (int q = 0; q < 4; q++) b[q] = act ? ld4(xf + ((u + (q >> 1)) * LSZ + LSL) * 8 + (q & 1) * 4) : make_uint4(0, 0, 0, 0);
#pragma unroll
    for (int q = 0; q < 8; q++) {
      const uint4& bb = b[q >> 1];
      uint32_t b0 = (q & 1) ? bb.z : bb.x, b1 = (q & 1) ? bb.w : bb.y;
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b0, b1);
    }
  }
  for (; u < u1; u++) {
    uint4 w[4];
#pragma unroll
    for (int q = 0; q < 4; q++) w[q] = ldg_nc(wstrip + ((long)u * 4 + q) * 512 + lane * 16);
    uint4 b[2];
#pragma unroll
    for (int q = 0; q < 2; q++) b[q] = act ? ld4(xf + (u * LSZ + LSL) * 8 + q * 4) : make_uint4(0, 0, 0, 0);
#pragma unroll
    for (int q = 0; q < 4; q++) {
      const uint4& bb = b[q >> 1];
      uint32_t b0 = (q & 1) ? bb.z : bb.x, b1 = (q & 1) ? bb.w : bb.y;
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b0, b1);
    }
  }
}

// 12-bit exact BF16 code (track B): decode into bf16x2 registers, patch escapes, MMA.
__device__ __forceinline__ uint32_t prmt0(uint32_t a, uint32_t sel) { uint32_t r; asm("prmt.b32 %0,%1,0,%2;" : "=r"(r) : "r"(a), "r"(sel)); return r; }
__device__ __forceinline__ uint32_t w12dec(uint32_t bytes, int half, uint32_t nib, int a, uint32_t E128) {
  uint32_t y = prmt0(bytes, half ? 0xB3A2u : 0x9180u);
  uint32_t t = (nib >> (4 * a)) & 0x000F000Fu;
  return (y & 0x807F807Fu) | (t * 128u + E128);
}
template <bool CPT>
__device__ __forceinline__ void run_w12(const W12M& M, long strip, const uint32_t* xf, int u0, int u1, float* acc, int B, int U) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  uint32_t eg = M.base[strip * 16 + g], eg8 = M.base[strip * 16 + g + 8];
  const uint32_t E0 = (eg | (eg << 16)) << 7, E1 = (eg8 | (eg8 << 16)) << 7;
  const uint8_t* wbase = M.data + strip * (long)U * 1536;
  const int* hdr = M.hdr + strip * (long)U;
  for (int u = u0; u < u1; u++) {
    uint4 d0 = ldg_nc(wbase + (long)u * 1536 + lane * 16);
    uint4 d1 = ldg_nc(wbase + (long)u * 1536 + 512 + lane * 16);
    uint4 dn = ldg_nc(wbase + (long)u * 1536 + 1024 + lane * 16);
    int hd = __ldg(hdr + u);
    uint4 b0 = act ? ld4(xf + (u * LSZ + LSL) * 8) : make_uint4(0, 0, 0, 0);
    uint4 b1 = act ? ld4(xf + (u * LSZ + LSL) * 8 + 4) : make_uint4(0, 0, 0, 0);
    uint32_t by[8] = {d0.x, d0.y, d0.z, d0.w, d1.x, d1.y, d1.z, d1.w};
    uint32_t nb[4] = {dn.x, dn.y, dn.z, dn.w};
    uint32_t a[16];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      a[4 * j + 0] = w12dec(by[2 * j], 0, nb[j], 0, E0);
      a[4 * j + 1] = w12dec(by[2 * j], 1, nb[j], 1, E1);
      a[4 * j + 2] = w12dec(by[2 * j + 1], 0, nb[j], 2, E0);
      a[4 * j + 3] = w12dec(by[2 * j + 1], 1, nb[j], 3, E1);
    }
    int cnt = hd & 0xFF;
    if (cnt) {
      const int* e = M.esc + (hd >> 8);
      for (int q = 0; q < cnt; q++) {
        int en = __ldg(e + q);
        if ((en >> 27 & 31) == lane) {
          int r = (en >> 23) & 15, hf = (en >> 22) & 1;
          uint32_t val = en & 0xFFFF;
#pragma unroll
          for (int k = 0; k < 16; k++)
            if (k == r) a[k] = hf ? ((a[k] & 0x0000FFFFu) | (val << 16)) : ((a[k] & 0xFFFF0000u) | val);
        }
      }
    }
    uint32_t bb[8] = {b0.x, b0.y, b0.z, b0.w, b1.x, b1.y, b1.z, b1.w};
#pragma unroll
    for (int j = 0; j < 4; j++) mma_bf16(acc, a[4 * j], a[4 * j + 1], a[4 * j + 2], a[4 * j + 3], bb[2 * j], bb[2 * j + 1]);
  }
}

// NVFP4 unit (64 k): codes [lane][16B] (512 B) + scales [g][8B] (64 B). B frags f16 [unit][lane][j][2].
#define UB4 576
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {  // bytes (g,g8) j0, (g,g8) j1 -> {g,g},{g8,g8},{g,g},{g8,g8}
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
__device__ __forceinline__ void fp4_unit(const uint4& cw, const uint2& sw, const uint4& b01, const uint4& b23, float* acc) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t ss[2] = {sw.x, sw.y};
  uint32_t bb[8] = {b01.x, b01.y, b01.z, b01.w, b23.x, b23.y, b23.z, b23.w};
#pragma unroll
  for (int jj = 0; jj < 2; jj++) {
    uint32_t sc[4];
    scl4(ss[jj], sc);
#pragma unroll
    for (int h = 0; h < 2; h++) {
      int j = jj * 2 + h;
      uint32_t a[4];
      cvt4(cc[j], a);
      uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
      mma_f16(acc, hmul2(a[0], sg), hmul2(a[1], sg8), hmul2(a[2], sg), hmul2(a[3], sg8), bb[2 * j], bb[2 * j + 1]);
    }
  }
}
// MXFP8 unit (64 k = 2 k32 steps): codes [s][lane][16B] (1024 B) + scales [g][s][hi] (32 B).
// B frags e4m3 [unit][lane][s][2 u32] (16 B per lane); act block scales fp32 [kblock32][MAXB]
#define UB8 1056
__device__ __forceinline__ void fp8_unit(const uint4& c0, const uint4& c1, uint32_t sw, const uint4& b, const float* xs, int u, float* acc) {
  const int lane = threadIdx.x & 31, t = lane & 3;
#pragma unroll
  for (int s = 0; s < 2; s++) {
    const uint4& cc = s ? c1 : c0;
    float d[4] = {0.f, 0.f, 0.f, 0.f};
    mma_e4m3(d, cc.x, cc.y, cc.z, cc.w, s ? b.z : b.x, s ? b.w : b.y);
    float fg = ue8m0((sw >> (16 * s)) & 0xff), fg8 = ue8m0((sw >> (16 * s + 8)) & 0xff);
    float2 fa = *reinterpret_cast<const float2*>(xs + (u * 2 + s) * MAXB + 2 * t);
    acc[0] += d[0] * (fg * fa.x);
    acc[1] += d[1] * (fg * fa.y);
    acc[2] += d[2] * (fg8 * fa.x);
    acc[3] += d[3] * (fg8 * fa.y);
  }
}
template <bool CPT>
__device__ __forceinline__ void run_q(const uint8_t* wstrip, const uint8_t* xf, const float* xs, int u0, int u1, float* acc, int B, int mx) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  if (!mx) {
    int u = u0;
    for (; u + 2 <= u1; u += 2) {
      uint4 cw[2]; uint2 sw[2]; uint4 b[4];
#pragma unroll
      for (int q = 0; q < 2; q++) {
        cw[q] = ldg_nc(wstrip + (long)(u + q) * UB4 + lane * 16);
        sw[q] = ldg_nc2(wstrip + (long)(u + q) * UB4 + 512 + g * 8);
      }
#pragma unroll
      for (int q = 0; q < 4; q++) b[q] = act ? ld4(xf + ((u + (q >> 1)) * LSZ + LSL) * 32 + (q & 1) * 16) : make_uint4(0, 0, 0, 0);
      fp4_unit(cw[0], sw[0], b[0], b[1], acc);
      fp4_unit(cw[1], sw[1], b[2], b[3], acc);
    }
    for (; u < u1; u++) {
      uint4 cw = ldg_nc(wstrip + (long)u * UB4 + lane * 16);
      uint2 sw = ldg_nc2(wstrip + (long)u * UB4 + 512 + g * 8);
      uint4 b0 = act ? ld4(xf + (u * LSZ + LSL) * 32) : make_uint4(0, 0, 0, 0);
      uint4 b1 = act ? ld4(xf + (u * LSZ + LSL) * 32 + 16) : make_uint4(0, 0, 0, 0);
      fp4_unit(cw, sw, b0, b1, acc);
    }
  } else {
    for (int u = u0; u < u1; u++) {
      uint4 c0 = ldg_nc(wstrip + (long)u * UB8 + lane * 16);
      uint4 c1 = ldg_nc(wstrip + (long)u * UB8 + 512 + lane * 16);
      uint32_t sw = ldg_nc1(wstrip + (long)u * UB8 + 1024 + g * 4);
      uint4 b = act ? ld4(xf + (u * LSZ + LSL) * 16) : make_uint4(0, 0, 0, 0);
      fp8_unit(c0, c1, sw, b, xs, u, acc);
    }
  }
}

// ------------------------------------------------------------------------------------------------ ops
struct Smem {
  float red[NWARP * 40 + 64];
  float bestv[NWARP * MAXB];
  int besti[NWARP * MAXB];
  float att[6 * CHUNK];
  float qv[6 * HD];
  float relb[6 * CHUNK];
  float misc[128];
  float opart[8][6 * HD];
  int ids[MAXB * TOPK];
  float wts[MAXB * TOPK];
  int uni[MAXU];
  int nuni;
  float minv[10];
  float mixp[30];
  // per-token state of token blockIdx.x (< B) for the whole step: finished blocks 0..7, partial (8), attention out
  __align__(16) bf16 blk[9][H];
  __align__(16) bf16 ats[H];
  union {
    struct {  // compact (B == 1) fragments, used by the red mode
      __align__(16) bf16 fx[3][H];        // xq, xk, xv
      __align__(16) bf16 fx2[H];          // router input
      __align__(16) uint8_t f13[2 * H];   // w13 input (f16 nvfp4 values or e4m3)
      __align__(16) uint8_t f2[8 * ILOC * 2];  // w2 inputs of up to 8 experts
      __align__(16) bf16 fh[H];           // final hidden
      float sc13[144 * MAXB];             // w13 input scales (mxfp8) / outer at [0]
      float sc2[8 * 18 * MAXB];           // w2 input scales / outer at [ui][0][0]
    };
    __align__(16) uint8_t stage[73728];   // std mode: the current GEMV's 8-column B fragments
  };
};
// std mode: copy a GEMV's B fragments (global, L2-resident) into shared memory once per block
__device__ __forceinline__ void stage_frags(Smem& sm, const void* src, int bytes, const void* src2 = nullptr, int bytes2 = 0) {
  const uint4* s4 = reinterpret_cast<const uint4*>(src);
  uint4* d4 = reinterpret_cast<uint4*>(sm.stage);
  for (int k = threadIdx.x; k < bytes / 16; k += NTH) d4[k] = __ldcg(s4 + k);
  if (src2) {
    const uint4* t4 = reinterpret_cast<const uint4*>(src2);
    for (int k = threadIdx.x; k < bytes2 / 16; k += NTH) d4[bytes / 16 + k] = __ldcg(t4 + k);
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ residual mixes
// sources of a mix: finished blocks 0..nb-1, then the partial block (+ fp32 addend), then (extra) the attention out
__device__ __forceinline__ const bf16* msrc(Smem& sm, int nb, int s) { return s < nb ? sm.blk[s] : (s == nb ? sm.blk[8] : sm.ats); }
// softmax-over-depth statistics: sm.minv[s] = 1/rms(source s), sm.mixp[qi][s] = probabilities
template <int NQ>
__device__ __forceinline__ void load_q(const float* q, float (*qv)[PER]) {
  const float qs = 0.014731391274719739f;  // 4608 ** -0.5 rounded to fp32
#pragma unroll
  for (int e = 0; e < PER; e++)
#pragma unroll
    for (int qi = 0; qi < NQ; qi++) qv[qi][e] = VALID(e) ? q[qi * H + threadIdx.x + e * NTH] * qs : 0.f;
}
// per-warp partial sums (sumsq, dots with the queries) of sources s0..s1-1 -> sm.red
template <int NQ>
__device__ __forceinline__ void mix_part(Smem& sm, int nb, int s0, int s1, const float* addend, const float* q) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const float qs = 0.014731391274719739f;  // 4608 ** -0.5 rounded to fp32
  float qv[NQ][PER];
#pragma unroll
  for (int e = 0; e < PER; e++)
#pragma unroll
    for (int qi = 0; qi < NQ; qi++) qv[qi][e] = VALID(e) ? q[qi * H + threadIdx.x + e * NTH] * qs : 0.f;
  for (int s = s0; s < s1; s++) {
    const bf16* src = msrc(sm, nb, s);
    const bool add = (s == nb) && addend;
    float a[1 + NQ];
#pragma unroll
    for (int k = 0; k <= NQ; k++) a[k] = 0.f;
#pragma unroll
    for (int e = 0; e < PER; e++) {
      if (!VALID(e)) continue;
      float x = bf(src[threadIdx.x + e * NTH]);
      if (add) x += addend[e];
      a[0] += x * x;
#pragma unroll
      for (int qi = 0; qi < NQ; qi++) a[1 + qi] += x * qv[qi][e];
    }
#pragma unroll
    for (int k = 0; k <= NQ; k++) {
#pragma unroll
      for (int o = 16; o; o >>= 1) a[k] += __shfl_xor_sync(0xffffffff, a[k], o);
      if (lane == 0) sm.red[w * 40 + s * 4 + k] = a[k];
    }
  }
}
// reduce over warps, 1/rms per source, softmax per query -> sm.minv, sm.mixp
template <int NQ>
__device__ __forceinline__ void mix_finish(Smem& sm, int n) {
  float* red = sm.red;
  __syncthreads();
  float* fin = red + NWARP * 40;
  if (threadIdx.x < n * 4) {
    float t = 0.f;
    for (int j = 0; j < NWARP; j++) t += red[j * 40 + threadIdx.x];
    fin[threadIdx.x] = t;
  }
  __syncthreads();
  if (threadIdx.x < n) sm.minv[threadIdx.x] = rsqrtf(fin[threadIdx.x * 4] / (float)H + 1e-6f);
  __syncthreads();
  if (threadIdx.x < NQ) {
    const int qi = threadIdx.x;
    float m = -INFINITY;
    for (int s = 0; s < n; s++) m = fmaxf(m, fin[s * 4 + 1 + qi] * sm.minv[s]);
    float z = 0.f;
    for (int s = 0; s < n; s++) { float p = expf(fin[s * 4 + 1 + qi] * sm.minv[s] - m); sm.mixp[qi * 10 + s] = p; z += p; }
    for (int s = 0; s < n; s++) sm.mixp[qi * 10 + s] = sm.mixp[qi * 10 + s] / z;
  }
  __syncthreads();
}
template <int NQ>
__device__ void mix_stats(Smem& sm, int nb, int n, const float* addend, const float* q) {
  mix_part<NQ>(sm, nb, 0, n, addend, q);
  mix_finish<NQ>(sm, n);
}
// output of query qi (fp32, per-thread elements)
__device__ __forceinline__ void mix_out(Smem& sm, int nb, int n, const float* addend, int qi, float* out) {
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    const int idx = threadIdx.x + e * NTH;
    float o = 0.f;
    for (int s = 0; s < n; s++) {
      float x = bf(msrc(sm, nb, s)[idx]);
      if (s == nb && addend) x += addend[e];
      o += sm.mixp[qi * 10 + s] * (x * sm.minv[s]);
    }
    out[e] = o;
  }
}

template <bool CPT>
struct OpQKV {
  int layer; const bf16* xf0; const bf16* xs0; int tm = 0;   // xs0: staged copy of group 0 (std mode) or null   // three frags (xq, xk, xv), each 72 units
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    const LayerW& L = c.L[layer];
    int grp = 0;
    if (L.glob) grp = s < 205 ? 0 : (s < 222 ? 1 : 2);
    const uint32_t* xf = reinterpret_cast<const uint32_t*>((grp == 0 && xs0) ? xs0 : xf0 + grp * (72 * LSZ * 16));
#ifdef W12
    run_w12<CPT>(L.qkv12, s, xf, u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(L.wqkv + s * 72L * 2048, xf, u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
    int r0 = (int)s * 16 + g;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = r0 + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) c.qkvo[col * 3840 + row] = tobf(a[i]);
    }
  }
};

struct OpOproj {
  int layer; int tm = 25;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<false>(c.L[layer].wo12, s, reinterpret_cast<const uint32_t*>(c.ofrag), u0, u1, acc, c.h.B, 24);
    return;
#endif
    run_bf16<false>(c.L[layer].wo + s * 24L * 2048, reinterpret_cast<const uint32_t*>(c.ofrag), u0, u1, acc, c.h.B);
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31;
    float4 v = make_float4(a[0], a[1], a[2], a[3]);
    for (int d = 0; d < NCARD; d++)
      *reinterpret_cast<float4*>(&c.comm[d]->attn[c.h.card][s][lane * 4]) = v;
  }
};

template <bool CPT>
struct OpRouter {
  int layer; const bf16* xf; int tm = 0;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<CPT>(c.L[layer].wr12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(c.L[layer].wr + s * 72L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) c.rlog[col * NE + row] = a[i];
    }
  }
};

__device__ __forceinline__ float act_fn(float g, float u) {
  float a = (4.0f * tanhf(g / 4.0f)) * sigm(g);
  return a * (25.0f * tanhf(u / 25.0f));
}

template <bool CPT>
struct OpW13 {
  int layer; int nu; const Smem* sm; const uint8_t* xf; const float* xs; const float* outer; int tm = 0;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    const LayerW& L = c.L[layer];
    int ui = (int)(s / 72), ls = (int)(s % 72);
    int e = sm->uni[ui];
    long ub = L.mx ? UB8 : UB4;
    const uint8_t* w = L.w13 + ((long)e * 72 + ls) * 72 * ub;
    run_q<CPT>(w, xf, xs, u0, u1, acc, c.h.B, L.mx);
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    const LayerW& L = c.L[layer];
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
    int ui = (int)(s / 72), ls = (int)(s % 72);
    int e = sm->uni[ui];
    // rows g (gate if g even... ) : local row r = ls*16 + g (+8). interleaved: even row gate, odd row up.
    // lane holds rows g and g+8 for cols 2t, 2t+1. Pair (gate,up) = rows (2p, 2p+1) -> lanes g=2p and g=2p+1.
    float v[4];
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int col = 2 * t + (i & 1);
      float sc = L.mx ? 1.0f : outer[col] * L.f13[e];
      v[i] = rbf(a[i] * sc);
    }
    // partner lane (g^1) holds the other member of the pair
    float o[4];
#pragma unroll
    for (int i = 0; i < 4; i++) o[i] = __shfl_xor_sync(0xffffffff, v[i], 4);
    float m0 = 0.f, m1 = 0.f;
    if ((g & 1) == 0) {
      // this lane: gate rows (g, g+8); partner: up rows (g+1, g+9). local intermediate j = (ls*16 + g)/2 (+4)
#pragma unroll
      for (int i = 0; i < 4; i++) {
        int col = 2 * t + (i & 1);
        if (col >= c.h.B) continue;
        int j = (ls * 16 + g + (i >> 1) * 8) >> 1;
        float wt = 0.f;
        for (int k = 0; k < TOPK; k++) if (sm->ids[col * TOPK + k] == e) wt = sm->wts[col * TOPK + k];
        float y = 0.f;
        if (wt != 0.f) y = rbf(act_fn(v[i], o[i]) * wt);
        c.act[(ui * MAXB + col) * ILOC + j] = tobf(y);
        if (i & 1) m1 = fmaxf(m1, fabsf(y)); else m0 = fmaxf(m0, fabsf(y));
      }
    }
    if (!L.mx) {
      // max over the warp per column, local atomic, and the last of the expert's 72 strips publishes to every card
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) { m0 = fmaxf(m0, __shfl_xor_sync(0xffffffff, m0, o)); m1 = fmaxf(m1, __shfl_xor_sync(0xffffffff, m1, o)); }
      if (g == 0) {
        if (2 * t < c.h.B) atomicMax(&c.amax_loc[ui * MAXB + 2 * t], __float_as_uint(m0));
        if (2 * t + 1 < c.h.B) atomicMax(&c.amax_loc[ui * MAXB + 2 * t + 1], __float_as_uint(m1));
      }
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) { __threadfence(); old = atomicAdd(&c.ucnt[ui], 1u); }
      old = __shfl_sync(0xffffffff, old, 0);
      if (old == 71u) {
        __threadfence();
        if (lane < c.h.B) {
          float v = __uint_as_float(atomicExch(&c.amax_loc[ui * MAXB + lane], 0u));
          for (int d = 0; d < NCARD; d++) c.comm[d]->amaxs[layer][c.h.card][ui][lane] = v;
        }
        if (lane == 0) c.ucnt[ui] = 0;
      }
    }
  }
};

template <bool CPT>
struct OpW2 {
  int layer; int nu; const Smem* sm; const uint8_t* xf0; const float* sc0; int tm = 28;   // frags [ui][9 units], scales [ui][18][MAXB]
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    // units: (ui, k-unit) with 9 units per expert
    const LayerW& L = c.L[layer];
    int lane = threadIdx.x & 31, t = lane & 3;
    long ub = L.mx ? UB8 : UB4;
    int u = u0;
    while (u < u1) {
      int ui = u / 9, k0 = u % 9, k1 = min(9, u1 - ui * 9);
      int e = sm->uni[ui];
      const uint8_t* w = L.w2 + ((long)e * 288 + s) * 9 * ub;
      float a[4] = {0.f, 0.f, 0.f, 0.f};
      const uint8_t* xf = xf0 + (long)ui * 9 * LSZ * (L.mx ? 16 : 32);
      const float* xs = sc0 + (long)ui * 18 * MAXB;
      run_q<CPT>(w, xf, xs, k0, k1, a, c.h.B, L.mx);
      if (L.mx) {
#pragma unroll
        for (int i = 0; i < 4; i++) acc[i] += a[i];
      } else {
        float f = L.f2[e];
        float s0 = sc0[ui * 18 * MAXB + 2 * t] * f, s1 = sc0[ui * 18 * MAXB + 2 * t + 1] * f;   // outer at [ui][0][col]
        acc[0] += a[0] * s0; acc[1] += a[1] * s1; acc[2] += a[2] * s0; acc[3] += a[3] * s1;
      }
      u = ui * 9 + k1;
    }
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31;
    float4 v = make_float4(a[0], a[1], a[2], a[3]);
    for (int d = 0; d < NCARD; d++)
      *reinterpret_cast<float4*>(&c.comm[d]->mlp[c.h.card][s][lane * 4]) = v;
  }
};

template <bool CPT>
struct OpUnembed {
  float* bestv; int* besti; const bf16* xf; int tm = 0; int layer = 0;   // per-warp running best per col (smem)
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<CPT>(c.un12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(c.unembed + s * 72L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3, w = threadIdx.x >> 5;
    float bv[2] = {-INFINITY, -INFINITY};
    int bi[2] = {1 << 30, 1 << 30};
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = c.un_row0 + (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B && row < VOCAB_REAL) {
        float z = 30.0f * tanhf(a[i] / 30.0f);
        if (c.h.want_logits) c.h.logits[(long)col * VOCAB_REAL + row] = z;
        int k = i & 1;
        if (z > bv[k] || (z == bv[k] && row < bi[k])) { bv[k] = z; bi[k] = row; }
      }
    }
#pragma unroll
    for (int k = 0; k < 2; k++) {
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) {
        float ov = __shfl_xor_sync(0xffffffff, bv[k], o);
        int oi = __shfl_xor_sync(0xffffffff, bi[k], o);
        if (ov > bv[k] || (ov == bv[k] && oi < bi[k])) { bv[k] = ov; bi[k] = oi; }
      }
      int col = 2 * t + k;
      if (g == 0 && col < c.h.B) {
        float cv = bestv[w * MAXB + col];
        int ci = besti[w * MAXB + col];
        if (bv[k] > cv || (bv[k] == cv && bi[k] < ci)) { bestv[w * MAXB + col] = bv[k]; besti[w * MAXB + col] = bi[k]; }
      }
    }
  }
};

// ------------------------------------------------------------------------------------------------ phases


// write token b's 16-bit value at k into a bf16 frag array
template <bool CPT> __device__ __forceinline__ void put16(bf16* f, int b, int k, float v) { f[fi16<CPT>(b, k)] = tobf(v); }

// quantize a bf16-valued vector (one token, per-thread regs PER elements, idx = tid + e*NTH) to NVFP4 (four over six)
// and write f16 (code x block scale) frags; return outer. Blocks of 16 consecutive k: owned by 16 consecutive threads.
template <bool CPT>
__device__ float quant_nvfp4_token(const float* x, int n, int b, __half* frag, float* red, float amax_given) {
  // n = number of elements per thread (PER for H), element index k = tid + e*NTH
  float amax = amax_given;
  if (amax < 0.f) {
    float m = 0.f;
    for (int e = 0; e < n; e++) if (VALID(e)) m = fmaxf(m, fabsf(x[e]));
    amax = block_max1(m, red);
  }
  const float FMAX = 3.4028234663852886e38f;
  float encoder = fminf(1536.0f / amax, FMAX);
  float decoder = 1.0f / encoder;
  float outer = amax * (1.0f / 1536.0f);
  const int lane = threadIdx.x & 31;
  for (int e = 0; e < n; e++) {
    if (!VALID(e)) continue;
    int k = threadIdx.x + e * NTH;
    float xv = x[e];
    float bm = fabsf(xv);
    for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));  // 16 lanes = one block
    float best_val = 0.f, best_err = 0.f;
#pragma unroll
    for (int cand = 0; cand < 2; cand++) {
      float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
      float sraw = fminf(bm * (encoder * inv_max), 448.0f);
      __nv_fp8_e4m3 s8 = __nv_fp8_e4m3(sraw);
      float scale = float(s8);
      float inverse = fminf(1.0f / (scale * decoder), FMAX);
      float val = xv * inverse;
      float mag = fabsf(val);
      // E2M1 round to nearest even, saturate at 6
      float q;
      if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
      else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
      if (val != val) q = 0.f;
      float rounded = signbit(val) ? -q : q;
      float vals = rounded * scale;
      float err = fabsf(vals * outer - xv);
      for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
      if (cand == 0) { best_val = vals; best_err = err; }
      else if (err < best_err) { best_val = vals; }
    }
    frag[fi16<CPT>(b, k)] = __float2half_rn(best_val);
    (void)lane;
  }
  return outer;
}

// MXFP8 quantization of one token: blocks of 32 consecutive k (32 consecutive threads = one warp).
template <bool CPT>
__device__ void quant_mxfp8_token(const float* x, int n, int b, uint8_t* frag, float* scales /*[kb][MAXB]*/) {
  for (int e = 0; e < n; e++) {
    if (!VALID(e)) continue;
    int k = threadIdx.x + e * NTH;
    float xv = x[e];
    float m = fabsf(xv);
    for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
    float raw = m * (1.0f / 448.0f);
    unsigned bits = __float_as_uint(raw);
    int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
    if (raw <= 5.877471754111438e-39f) ex = 0;  // 2**-127
    if (ex > 254) ex = 254;
    float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
    float v = fminf(fmaxf(xv * inverse, -448.f), 448.f);
    __nv_fp8_e4m3 q(v);
    frag[fi8<CPT>(b, k)] = q.__x;
    if ((threadIdx.x & 31) == 0) scales[(k >> 5) * MAXB + b] = ue8m0((unsigned)ex);
  }
}

// write x (bf16-rounded floats) of token b into the bf16 frag f (K = H)
template <bool CPT>
__device__ __forceinline__ void put_frag_h(bf16* f, int b, const float* y) {
  for (int e = 0; e < PER; e++) if (VALID(e)) put16<CPT>(f, b, threadIdx.x + e * NTH, y[e]);
}

// all-reduce sum of the four cards' partials (mailbox [card][strip][lane-layout]) for token b, bf16-rounded
__device__ __forceinline__ void load_raw(const float (*mb)[288][MAXB * 16], int b, float* raw) {
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    int s = idx >> 4, r = idx & 15;
    int k = ((r & 7) * 4 + (b >> 1)) * 4 + (r >> 3) * 2 + (b & 1);
    float v0 = __ldcg(&mb[0][s][k]), v1 = __ldcg(&mb[1][s][k]), v2 = __ldcg(&mb[2][s][k]), v3 = __ldcg(&mb[3][s][k]);
    raw[e] = rbf(((v0 + v1) + v2) + v3);
  }
}
__device__ __forceinline__ void hist_load(const bf16* __restrict__ hist, float* h0, float* h1, float* h2) {
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    h0[e] = bf(hist[idx]); h1[e] = bf(hist[H + idx]); h2[e] = bf(hist[2 * H + idx]);
  }
}
__device__ __forceinline__ void conv_apply(const float* h0, const float* h1, const float* h2, bf16* __restrict__ hw, bool writer,
                                           const bf16* w4, const float* raw, float* out) {
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    out[e] = sconv4(h0[e], h1[e], h2[e], raw[e], w4 + idx * 4);
    if (writer) { hw[idx] = tobf(h1[e]); hw[H + idx] = tobf(h2[e]); hw[2 * H + idx] = tobf(raw[e]); }
  }
}
// short conv over the double-buffered history: all loads first, then the writes
__device__ __forceinline__ void conv_hist(const bf16* __restrict__ hist, bf16* __restrict__ hw, bool writer, const bf16* w4,
                                          const float* raw, float* out) {
  float h0[PER], h1[PER], h2[PER];
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    h0[e] = bf(hist[idx]); h1[e] = bf(hist[H + idx]); h2[e] = bf(hist[2 * H + idx]);
  }
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    out[e] = sconv4(h0[e], h1[e], h2[e], raw[e], w4 + idx * 4);
    if (writer) { hw[idx] = tobf(h1[e]); hw[H + idx] = tobf(h2[e]); hw[2 * H + idx] = tobf(raw[e]); }
  }
}

// phase: (mlp all-reduce of layer i-1, sconv, finalize) + attention input of layer i. One block per token.
template <bool RED>
__device__ void phase_attn_in(const Ctx& c, int i, int b, Smem& sm, bool dowait, unsigned ev) {
  const LayerW& L = c.L[i];
  const bool writer = !RED || blockIdx.x == 0;
  bf16* xfd = RED ? &sm.fx[0][0] : c.xfrag;
  const int xstride = RED ? H : 72 * 32 * 16;
  float* red = sm.red;
  bf16* part = sm.blk[8];
  if (i == 0) {
    int tok = c.h.tokens[b];
    float u[PER], y[PER];
    for (int e = 0; e < PER; e++) if (VALID(e)) u[e] = bf(c.embed[(long)tok * H + threadIdx.x + e * NTH]);
    rmsnorm_regs(u, c.embed_norm, y, red);
    for (int e = 0; e < PER; e++) if (VALID(e)) part[threadIdx.x + e * NTH] = tobf(y[e]);
    float x[PER];
    rmsnorm_regs(y, L.norm[0], x, red);
    put_frag_h<RED>(xfd, b, x);
    return;
  }
  const int lp = i - 1;
  // ---- before the cross-card wait: history loads, the finished blocks' statistics
  float h0[PER], h1[PER], h2[PER];
  hist_load(c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H, h0, h1, h2);
  const int nb_before = (lp == 0) ? 0 : ((lp - 1) / 6 + 1);  // finished blocks before finalize(lp)
  const bool boundary = (lp % 6) == 0;
  const int nb = nb_before + (boundary ? 1 : 0);
  if (boundary) {
    for (int e = 0; e < PER; e++) if (VALID(e)) { int idx = threadIdx.x + e * NTH; sm.blk[nb_before][idx] = part[idx]; }
    __syncthreads();
  }
  if (L.glob) mix_part<3>(sm, nb, 0, nb, nullptr, L.aq);
  else mix_part<1>(sm, nb, 0, nb, nullptr, L.aq);
  if (dowait) xwait(c, 1, ev);
  TM(i, 1);
  // ---- the mlp of layer i-1
  float raw[PER], mlp[PER];
  load_raw(c.comm[c.h.card]->mlp, b, raw);
  conv_apply(h0, h1, h2, c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, writer, c.L[lp].mlp_sc, raw, mlp);
  TM(i, 16);
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    float at = bf(sm.ats[idx]);
    if (c.dbg && writer) c.dbg[((long)(lp * 2 + 1) * MAXB + b) * H + idx] = tobf(mlp[e]);
    part[idx] = boundary ? tobf(at + mlp[e]) : tobf((bf(part[idx]) + at) + mlp[e]);
  }
  __syncthreads();
  TM(i, 17);
  const int nq = L.glob ? 3 : 1;
  if (L.glob) { mix_part<3>(sm, nb, nb, nb + 1, nullptr, L.aq); mix_finish<3>(sm, nb + 1); }
  else { mix_part<1>(sm, nb, nb, nb + 1, nullptr, L.aq); mix_finish<1>(sm, nb + 1); }
  TM(i, 18);
  for (int k = 0; k < nq; k++) {
    float o[PER], x[PER];
    mix_out(sm, nb, nb + 1, nullptr, k, o);
    rmsnorm_regs(o, L.norm[k], x, red);
    put_frag_h<RED>(xfd + k * xstride, b, x);
  }
}

// attention: block per (token b, local kv head kh, chunk ch)
__device__ void phase_attention(const Ctx& c, int i, int b, int kh, int ch, int nch, Smem& sm) {
  const LayerW& L = c.L[i];
  const int t = c.h.pos;
  const int lo = L.glob ? 0 : max(0, t + 1 - WIN);
  const int p0 = lo + ch * CHUNK, p1 = min(t + 1, p0 + CHUNK);
  const bf16* qkv = c.qkvo + b * 3840;
  // row offsets in the local qkv matrix
  const int OQ = 0, OG = 1536, OR = 3072, OS = 3264, OK = 3280, ODK = 3536, OV = L.glob ? 3552 : 3536, ODV = 3808;
  float tau = 1.0f;
  if (L.glob) tau = 1.0f + 0.1f * logf(fmaxf((float)(t + 1) / 128000.0f, 1.0f));
  bf16* kcache = c.kc + (((long)(i * MAXB + b) * NKVL + kh) * c.maxctx) * HD;
  bf16* vcache = c.vc + (((long)(i * MAXB + b) * NKVL + kh) * c.maxctx) * HD;
  int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  float* red = sm.red;
  // K and V rows of this chunk into shared memory (the B-fragment area is free during attention); row t later
  bf16* ks = reinterpret_cast<bf16*>(sm.stage);
  bf16* vs = ks + CHUNK * HD;
  {
    const int np = p1 - p0;
    for (int k = tid; k < np * 16; k += NTH) {   // 16 uint4 per row
      int r = k >> 4, q = k & 15;
      if (p0 + r == t) continue;
      reinterpret_cast<uint4*>(ks + r * HD)[q] = __ldcg(reinterpret_cast<const uint4*>(kcache + (long)(p0 + r) * HD) + q);
      reinterpret_cast<uint4*>(vs + r * HD)[q] = __ldcg(reinterpret_cast<const uint4*>(vcache + (long)(p0 + r) * HD) + q);
    }
  }
  // q of the 6 heads (l2 clip with scale) -> sm.qv; rel bias -> sm.relb (for positions of this chunk)
  // each warp w<6 handles head j=w
  if (w < 6) {
    int hl = kh * 6 + w;
    float v[4], ss = 0.f;
    for (int k = 0; k < 4; k++) {
      int d = lane + 32 * k;
      v[k] = bf(qkv[OQ + hl * HD + d]) * bf(L.qscale[hl * HD + d]);
      ss += v[k] * v[k];
    }
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
    float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
    for (int k = 0; k < 4; k++) {
      float qq = rbf(v[k] * f);
      if (L.glob) qq = rbf(qq * tau);
      sm.qv[w * HD + lane + 32 * k] = qq;
    }
    // r: 16 values
    float rv = 0.f;
    if (lane < 16) rv = bf(qkv[OR + hl * 16 + lane]) * bf(L.rscale[hl * 16 + lane]);
    float rs = rv * rv;
    for (int o = 16; o; o >>= 1) rs += __shfl_xor_sync(0xffffffff, rs, o);
    float rf = fminf(8.0f / (sqrtf(rs) + 1e-6f), 1.0f);
    float rr = rbf(rv * rf);
    if (L.glob) rr = rbf(rr * tau);
    if (lane < 16) sm.misc[16 + w * 16 + lane] = rr;
  }
  // new k, v at position t (by the chunk that holds t)
  if (p1 == t + 1) {
    if (w == 6 || w == 7) {  // warp 6: k, warp 7: v (in parallel with the q/r preparation of warps 0-5)
      const int kv = w - 6;
      int base = (kv == 0) ? OK : OV;
      const bf16* sc = (kv == 0) ? L.ksc : L.vsc;
      bf16* hist = (kv == 0 ? c.hist_k : c.hist_v) + ((long)(i * MAXB + b) * 3) * 256;
      float vals[4], ss = 0.f;
      for (int k = 0; k < 4; k++) {
        int d = lane + 32 * k, ch_ = kh * HD + d;
        float raw = bf(qkv[base + ch_]);
        float h0 = bf(hist[ch_]), h1 = bf(hist[256 + ch_]), h2 = bf(hist[512 + ch_]);
        float y;
        if (!L.glob) {
          y = sconv4(h0, h1, h2, raw, sc + ch_ * 4);
        } else {
          int dbase = (kv == 0) ? ODK : ODV;
          float acc = 0.f;
          float xs[4] = {raw, h2, h1, h0};
          for (int lag = 0; lag < 4; lag++) {
            float tap = bf(sc[lag * 256 + ch_]) + bf(qkv[dbase + kh * 4 + lag]);
            acc = acc + xs[lag] * tap;
          }
          y = rbf((acc + raw) * 0.3333333333333333f);
        }
        vals[k] = y;
        ss += y * y;
        hist[ch_] = tobf(h1); hist[256 + ch_] = tobf(h2); hist[512 + ch_] = tobf(raw);
      }
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      for (int k = 0; k < 4; k++) {
        float y;
        if (kv == 0) y = rbf(vals[k] * fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f));
        else y = rbf(vals[k] * rsqrtf(ss / 128.0f + 1e-6f));
        int d = lane + 32 * k;
        (kv == 0 ? kcache : vcache)[(long)t * HD + d] = tobf(y);
        (kv == 0 ? ks : vs)[(t - p0) * HD + d] = tobf(y);
      }
    }
  }
  __syncthreads();
  // rel bias for this chunk's positions: dist = t - p (bf16 einsum in the engines)
  for (int idx = tid; idx < 6 * (p1 - p0); idx += NTH) {
    int j = idx / (p1 - p0), p = p0 + idx % (p1 - p0);
    int dist = t - p;
    float bias = 0.f;
    if (dist < RELEXT) {
      float pr = 0.f;
#pragma unroll
      for (int d = 0; d < DREL; d++) pr += sm.misc[16 + j * 16 + d] * bf(L.relp[d * RELEXT + dist]);
      bias = rbf(pr);
    }
    sm.relb[j * CHUNK + (p - p0)] = bias;
  }
  __syncthreads();
  // scores: warp w handles positions p0 + w, +16, ...
  const float scl = 0.08838834764831845f;
  uint2 krs[CHUNK / NWARP];
#pragma unroll
  for (int q = 0; q < CHUNK / NWARP; q++) {
    int p = p0 + w + q * NWARP;
    krs[q] = (p < p1) ? *reinterpret_cast<const uint2*>(ks + (p - p0) * HD + lane * 4) : make_uint2(0, 0);
  }
#pragma unroll
  for (int q = 0; q < CHUNK / NWARP; q++) {
    int p = p0 + w + q * NWARP;
    if (p >= p1) break;
    uint2 kr = krs[q];
    float kv[4];
    { __nv_bfloat162 a = *reinterpret_cast<__nv_bfloat162*>(&kr.x), bb = *reinterpret_cast<__nv_bfloat162*>(&kr.y);
      kv[0] = __low2float(a); kv[1] = __high2float(a); kv[2] = __low2float(bb); kv[3] = __high2float(bb); }
    for (int j = 0; j < 6; j++) {
      float d = 0.f;
      for (int k = 0; k < 4; k++) d += sm.qv[j * HD + lane * 4 + k] * kv[k];
      for (int o = 16; o; o >>= 1) d += __shfl_xor_sync(0xffffffff, d, o);
      if (lane == 0) sm.att[j * CHUNK + (p - p0)] = d * scl + sm.relb[j * CHUNK + (p - p0)];
    }
  }
  __syncthreads();
  // per head max and exp
  int np = p1 - p0;
  if (w < 6) {
    float m = -INFINITY;
    for (int p = lane; p < np; p += 32) m = fmaxf(m, sm.att[w * CHUNK + p]);
    for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
    float l = 0.f;
    for (int p = lane; p < np; p += 32) { float e = expf(sm.att[w * CHUNK + p] - m); sm.att[w * CHUNK + p] = e; l += e; }
    for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffff, l, o);
    if (lane == 0) { sm.misc[w * 2] = m; sm.misc[w * 2 + 1] = l; }
  }
  __syncthreads();
  // o[j][d] = sum_p e[j][p] v[p][d]: thread -> (d = tid & 127, quarter = tid >> 7)
  {
    int d = tid & 127, qtr = tid >> 7;
    float o[6] = {0, 0, 0, 0, 0, 0};
    float vv[CHUNK / 8];
#pragma unroll
    for (int q = 0; q < CHUNK / 8; q++) {
      int p = p0 + qtr + 8 * q;
      vv[q] = (p < p1) ? bf(vs[(p - p0) * HD + d]) : 0.f;
    }
#pragma unroll
    for (int q = 0; q < CHUNK / 8; q++) {
      int p = p0 + qtr + 8 * q;
      if (p >= p1) break;
#pragma unroll
      for (int j = 0; j < 6; j++) o[j] += sm.att[j * CHUNK + (p - p0)] * vv[q];
    }
    for (int j = 0; j < 6; j++) sm.opart[qtr][j * HD + d] = o[j];
  }
  __syncthreads();
  float* chunkp = c.achunk + ((long)((b * NKVL + kh) * MAXCHUNK + ch) * 6) * (2 + HD);
  for (int idx = tid; idx < 6 * HD; idx += NTH) {
    int j = idx / HD, d = idx % HD;
    float acc = 0.f;
    for (int q = 0; q < 8; q++) acc += sm.opart[q][idx];
    chunkp[j * (2 + HD) + 2 + d] = acc;
  }
  if (tid < 6) { chunkp[tid * (2 + HD)] = sm.misc[tid * 2]; chunkp[tid * (2 + HD) + 1] = sm.misc[tid * 2 + 1]; }
  __syncthreads();
  // last chunk block combines
  __shared__ unsigned last;
  if (tid == 0) {
    __threadfence();
    unsigned old = atomicAdd(&c.acnt[b * NKVL + kh], 1u);
    last = (old == (unsigned)(nch - 1));
    if (last) c.acnt[b * NKVL + kh] = 0;
  }
  __syncthreads();
  if (!last) return;
  __threadfence();
  for (int idx = tid; idx < 6 * HD; idx += NTH) {
    int j = idx / HD, d = idx % HD;
    const float* base = c.achunk + ((long)((b * NKVL + kh) * MAXCHUNK) * 6) * (2 + HD);
    float mm[MAXCHUNK], ll[MAXCHUNK], oo[MAXCHUNK];
#pragma unroll
    for (int q = 0; q < MAXCHUNK; q++) {
      const float* pp = base + (q * 6 + j) * (2 + HD);
      bool ok = q < nch;
      mm[q] = ok ? __ldcg(pp) : -INFINITY; ll[q] = ok ? __ldcg(pp + 1) : 0.f; oo[q] = ok ? __ldcg(pp + 2 + d) : 0.f;
    }
    float M = -INFINITY;
#pragma unroll
    for (int q = 0; q < MAXCHUNK; q++) M = fmaxf(M, mm[q]);
    float Ls = 0.f, O = 0.f;
#pragma unroll
    for (int q = 0; q < MAXCHUNK; q++) {
      if (q < nch) {
        float f = expf(mm[q] - M);
        Ls += ll[q] * f;
        O += oo[q] * f;
      }
    }
    float lse = M + logf(Ls);
    float out = O / Ls;
    int hl = kh * 6 + j;
    float gate = bf(qkv[OG + hl * HD + d]);
    float sink = bf(qkv[OS + hl]);
    out = out * sigm(gate);
    out = out * sigm(lse - sink);
    put16<false>(c.ofrag, b, hl * HD + d, out);
  }
}

// phase: attention all-reduce + sconv + mlp input mix + norm + quantization. One block per token.
template <bool RED>
__device__ void phase_post_attn(const Ctx& c, int i, int b, Smem& sm, bool dowait, unsigned ev) {
  const LayerW& L = c.L[i];
  const bool writer = !RED || blockIdx.x == 0;
  float* red = sm.red;
  // ---- before the wait
  float h0[PER], h1[PER], h2[PER];
  hist_load(c.hist_attn + ((((long)c.h.parity * NL + i) * MAXB + b) * 3) * H, h0, h1, h2);
  const int nb = (i == 0) ? 0 : ((i - 1) / 6 + 1);
  const bool boundary = (i % 6) == 0;
  mix_part<1>(sm, nb, 0, boundary ? nb + 1 : nb, nullptr, L.mq);   // finished blocks (and the old partial at a boundary)
  if (dowait) xwait(c, 0, ev);
  TM(i, 6);
  float raw[PER], at[PER];
  load_raw(c.comm[c.h.card]->attn, b, raw);
  conv_apply(h0, h1, h2, c.hist_attn + ((((long)(c.h.parity ^ 1) * NL + i) * MAXB + b) * 3) * H, writer, L.attn_sc, raw, at);
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    sm.ats[idx] = tobf(at[e]);
    if (c.dbg && writer) c.dbg[((long)(i * 2) * MAXB + b) * H + idx] = tobf(at[e]);
  }
  TM(i, 20);
  __syncthreads();
  float out[PER];
  if (boundary) {
    mix_part<1>(sm, nb, nb + 1, nb + 2, nullptr, L.mq);
    mix_finish<1>(sm, nb + 2);
    mix_out(sm, nb, nb + 2, nullptr, 0, out);
  } else {
    mix_part<1>(sm, nb, nb, nb + 1, at, L.mq);
    mix_finish<1>(sm, nb + 1);
    mix_out(sm, nb, nb + 1, at, 0, out);
  }
  TM(i, 21);
  float x[PER];
  rmsnorm_regs(out, L.mlp_norm, x, red);
  TM(i, 22);
  put_frag_h<RED>(RED ? sm.fx2 : c.x2frag, b, x);
  uint8_t* f13 = RED ? sm.f13 : c.w13frag;
  float* sc13 = RED ? sm.sc13 : c.w13sc;
  if (!L.mx) {
    float outer = quant_nvfp4_token<RED>(x, PER, b, reinterpret_cast<__half*>(f13), red, -1.f);
    if (threadIdx.x == 0) sc13[b] = outer;
  } else {
    quant_mxfp8_token<RED>(x, PER, b, f13, sc13);
  }
}

// routing, computed redundantly by every block: warp b < B does token b's top-8; thread 0 the sorted union.
__device__ void phase_route(const Ctx& c, int i, Smem& sm) {
  const LayerW& L = c.L[i];
  const int lane = threadIdx.x & 31, b = threadIdx.x >> 5;
  const int B = c.h.B;
  float* sel = &sm.opart[0][0];   // [B][384] selection scores (attention scratch, free here)
  for (int k = threadIdx.x; k < B * NE; k += NTH) sel[k] = sigm(__ldcg(&c.rlog[k])) + L.rbias[k % NE];
  __syncthreads();
  if (b < B) {
    float* sb = sel + b * NE;
    int cid = 0;
    for (int r = 0; r < TOPK; r++) {
      float bv = -INFINITY; int bi = 1 << 30;
#pragma unroll
      for (int k = 0; k < 12; k++) {
        int e = lane + 32 * k;
        float v = sb[e];
        if (v > bv) { bv = v; bi = e; }
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) {
        float ov = __shfl_xor_sync(0xffffffff, bv, o); int oi = __shfl_xor_sync(0xffffffff, bi, o);
        if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
      }
      if (lane == r) cid = bi;
      if (lane == 0) sb[bi] = -INFINITY;
      __syncwarp();
    }
    // lanes 0..7 hold the chosen experts in rank order
    float sg = 0.f;
    if (lane < TOPK) sg = sigm(__ldcg(&c.rlog[b * NE + cid]));
    float z = sg;
#pragma unroll
    for (int o = 1; o < 8; o <<= 1) z += __shfl_xor_sync(0xffffffff, z, o);
    if (lane < TOPK) {
      sm.ids[b * TOPK + lane] = cid;
      sm.wts[b * TOPK + lane] = sg / z * 8.0f;
      if (c.dbg_ids && blockIdx.x == 0) c.dbg_ids[(i * MAXB + b) * TOPK + lane] = cid;
    }
  }
  __syncthreads();
  TM(i, 24);
  if (threadIdx.x == 0) {
    unsigned long long mask[6] = {0, 0, 0, 0, 0, 0};
    for (int bb = 0; bb < c.h.B; bb++)
      for (int r = 0; r < TOPK; r++) { int e = sm.ids[bb * TOPK + r]; mask[e >> 6] |= 1ull << (e & 63); }
    int n = 0;
    for (int w = 0; w < 6; w++) {
      unsigned long long m = mask[w];
      while (m) { int bit = __ffsll(m) - 1; m &= m - 1; sm.uni[n++] = w * 64 + bit; }
    }
    sm.nuni = n;
  }
  __syncthreads();
}

// quantize act (per (ui, token)) for w2 with the global amax. Block per (ui, token) pair.
__device__ void phase_quant2(const Ctx& c, int i, int ui, int b, Smem& sm) {
  const LayerW& L = c.L[i];
  // 576 values: thread t < 576? NTH=512 -> 2 passes; use per-thread 2 elements: k = tid, tid+512 (<576)
  if (threadIdx.x >= ILOC) return;   // 18 whole warps
  float x[1];
  const int n = 1;
  x[0] = bf(c.act[(ui * MAXB + b) * ILOC + threadIdx.x]);
  uint8_t* frag = c.w2frag + (long)ui * 9 * 32 * (L.mx ? 16 : 32);
  if (!L.mx) {
    float amax = 0.f;
    for (int d = 0; d < NCARD; d++) amax = fmaxf(amax, __ldcg(&c.comm[c.h.card]->amaxs[i][d][ui][b]));
    // the block-of-16 shuffles need full warps: elements k >= 576 are padding in a separate warp range
    // k = tid + 512: tids 0..63 valid, rest padding -> whole warps 0,1 valid; padding warps compute garbage not stored
    __half* f = reinterpret_cast<__half*>(frag);
    // inline quantization (amax given); store only k < 576
    const float FMAX = 3.4028234663852886e38f;
    float outer = amax * (1.0f / 1536.0f);
    if (amax == 0.f) {
      for (int e = 0; e < n; e++) { int k = threadIdx.x + e * NTH; if (k < ILOC) f[fidx16(b, k)] = __float2half_rn(0.f); }
    } else {
      float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder;
      for (int e = 0; e < n; e++) {
        int k = threadIdx.x + e * NTH;
        float xv = x[e];
        float bm = fabsf(xv);
        for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));
        float best_val = 0.f, best_err = 0.f;
        for (int cand = 0; cand < 2; cand++) {
          float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
          float sraw = fminf(bm * (encoder * inv_max), 448.0f);
          float scale = float(__nv_fp8_e4m3(sraw));
          float inverse = fminf(1.0f / (scale * decoder), FMAX);
          float val = xv * inverse, mag = fabsf(val), q;
          if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
          else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
          if (val != val) q = 0.f;
          float vals = (signbit(val) ? -q : q) * scale;
          float err = fabsf(vals * outer - xv);
          for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
          if (cand == 0) { best_val = vals; best_err = err; } else if (err < best_err) best_val = vals;
        }
        if (k < ILOC) f[fidx16(b, k)] = __float2half_rn(best_val);
      }
    }
    if (threadIdx.x == 0) c.w2sc[ui * 18 * MAXB + b] = outer;
  } else {
    float* sc = c.w2sc + (long)ui * 18 * MAXB;
    for (int e = 0; e < n; e++) {
      int k = threadIdx.x + e * NTH;
      float xv = x[e];
      float m = fabsf(xv);
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float raw = m * (1.0f / 448.0f);
      unsigned bits = __float_as_uint(raw);
      int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
      if (raw <= 5.877471754111438e-39f) ex = 0;
      if (ex > 254) ex = 254;
      float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
      float v = fminf(fmaxf(xv * inverse, -448.f), 448.f);
      if (k < ILOC) {
        frag[fidx8(b, k)] = __nv_fp8_e4m3(v).__x;
        if ((threadIdx.x & 31) == 0) sc[(k >> 5) * MAXB + b] = ue8m0((unsigned)ex);
      }
    }
  }
}

// B == 1: every block quantizes the w2 inputs of all union experts into its shared memory (compact frags).
// Flat index over nu * 576 values: blocks of 16 (nvfp4) / 32 (mxfp8) never straddle experts.
__device__ void phase_quant2_red(const Ctx& c, int i, int nu, Smem& sm) {
  const LayerW& L = c.L[i];
  const int total = nu * ILOC;
  const float FMAX = 3.4028234663852886e38f;
  for (int base = 0; base < total; base += NTH) {
    int idx = base + threadIdx.x;
    if (base + (threadIdx.x & ~31) >= total) break;   // whole warps beyond the end
    int ui = idx / ILOC, kk = idx % ILOC;
    float xv = bf(__ldcg(&c.act[(ui * MAXB) * ILOC + kk]));
    if (!L.mx) {
      float amax = 0.f;
      for (int d = 0; d < NCARD; d++) amax = fmaxf(amax, __ldcg(&c.comm[c.h.card]->amaxs[i][d][ui][0]));
      float outer = amax * (1.0f / 1536.0f);
      float best_val = 0.f;
      float bm = fabsf(xv);
      for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));
      if (amax != 0.f) {
        float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder;
        float best_err = 0.f;
        for (int cand = 0; cand < 2; cand++) {
          float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
          float sraw = fminf(bm * (encoder * inv_max), 448.0f);
          float scale = float(__nv_fp8_e4m3(sraw));
          float inverse = fminf(1.0f / (scale * decoder), FMAX);
          float val = xv * inverse, mag = fabsf(val), q;
          if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
          else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
          if (val != val) q = 0.f;
          float vals = (signbit(val) ? -q : q) * scale;
          float err = fabsf(vals * outer - xv);
          for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
          if (cand == 0) { best_val = vals; best_err = err; } else if (err < best_err) best_val = vals;
        }
      }
      __half* f = reinterpret_cast<__half*>(sm.f2 + ui * 9 * 4 * 32);
      f[fidx16c(kk)] = __float2half_rn(best_val);
      if (kk == 0) sm.sc2[ui * 18 * MAXB] = outer;
    } else {
      float m = fabsf(xv);
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float raw = m * (1.0f / 448.0f);
      unsigned bits = __float_as_uint(raw);
      int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
      if (raw <= 5.877471754111438e-39f) ex = 0;
      if (ex > 254) ex = 254;
      float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
      float v = fminf(fmaxf(xv * inverse, -448.f), 448.f);
      (sm.f2 + ui * 9 * 4 * 16)[fidx8c(kk)] = __nv_fp8_e4m3(v).__x;
      if ((kk & 31) == 0) sm.sc2[ui * 18 * MAXB + (kk >> 5) * MAXB] = ue8m0((unsigned)ex);
    }
  }
  __syncthreads();
}

// final: mlp all-reduce of layer 47 + finalize + output mix + norm -> hfrag
template <bool RED>
__device__ void phase_final(const Ctx& c, int b, Smem& sm) {
  const bool writer = !RED || blockIdx.x == 0;
  float* red = sm.red;
  bf16* part = sm.blk[8];
  const int lp = NL - 1;
  float raw[PER], mlp[PER];
  load_raw(c.comm[c.h.card]->mlp, b, raw);
  conv_hist(c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H,
            c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, writer, c.L[lp].mlp_sc, raw, mlp);
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) continue;
    int idx = threadIdx.x + e * NTH;
    float at = bf(sm.ats[idx]);
    if (c.dbg && writer) c.dbg[((long)(lp * 2 + 1) * MAXB + b) * H + idx] = tobf(mlp[e]);
    part[idx] = tobf((bf(part[idx]) + at) + mlp[e]);   // layer 47 is not a boundary
  }
  __syncthreads();
  mix_stats<1>(sm, 8, 9, nullptr, c.oq);
  float out[PER];
  mix_out(sm, 8, 9, nullptr, 0, out);
  float x[PER];
  rmsnorm_regs(out, c.fnorm, x, red);
  put_frag_h<RED>(RED ? sm.fh : c.hfrag, b, x);
}

// ------------------------------------------------------------------------------------------------ the step kernel
template <bool RED>
__device__ __forceinline__ void step_body(const Ctx& c, Smem& sm, int layer_lo, int layer_hi) {
  if (RED) {
    for (int k = threadIdx.x; k < 144 * MAXB; k += NTH) sm.sc13[k] = 0.f;
    for (int k = threadIdx.x; k < 8 * 18 * MAXB; k += NTH) sm.sc2[k] = 0.f;
    __syncthreads();
  }
  unsigned nbar = 0;
  const unsigned barbase = *((volatile unsigned*)&c.bar[1]);
  const int B = c.h.B;
  const int nblk = gridDim.x;
  unsigned ev = 0;  // comm events of this launch (per counter kind)
  unsigned ev_attn = 0, ev_mlp = 0, ev_amax = 0;
  for (int i = layer_lo; i < layer_hi; i++) {
    const LayerW& L = c.L[i];
    // A: attention input
    TM(i, 0);
    if (RED) {
      prefetch_l2(L.wqkv, (long)L.qkv_strips * 72 * 2048, blockIdx.x, nblk);
      phase_attn_in<true>(c, i, 0, sm, i > 0, ev_mlp);
      __syncthreads();   // the fragments of every warp are read by the next GEMV
    } else {
      if (blockIdx.x < B) phase_attn_in<false>(c, i, blockIdx.x, sm, i > 0, ev_mlp);
      else prefetch_l2(L.wqkv, (long)L.qkv_strips * 72 * 2048, blockIdx.x - B, nblk - B);
      grid_bar(c, nbar, barbase);
    }
    TM(i, 2);
    // B: qkv
    if (!RED) stage_frags(sm, c.xfrag, 73728);
    { OpQKV<RED> op{i, RED ? &sm.fx[0][0] : c.xfrag, RED ? nullptr : reinterpret_cast<const bf16*>(sm.stage)};
      gemv(c, op, L.qkv_strips, 72); }
    grid_bar(c, nbar, barbase);
    TM(i, 3);
    // C: attention
    {
      int t = c.h.pos;
      int lo = L.glob ? 0 : max(0, t + 1 - WIN);
      int nch = (t + 1 - lo + CHUNK - 1) / CHUNK;
      int nitems = B * NKVL * nch;
      if (blockIdx.x >= nitems && nitems < nblk) prefetch_l2(L.wo, 288L * 24 * 2048, blockIdx.x - nitems, nblk - nitems);
      for (int it = blockIdx.x; it < nitems; it += nblk) {
        int b = it / (NKVL * nch), r = it % (NKVL * nch);
        phase_attention(c, i, b, r / nch, r % nch, nch, sm);
        __syncthreads();
      }
    }
    grid_bar(c, nbar, barbase);
    TM(i, 4);
    // D: o_proj -> all cards
    { OpOproj op{i}; gemv(c, op, 288, 24); }
    xsignal(c, 0, nbar, barbase); ev_attn++;
    TM(i, 5);
    // E: post-attention (token blocks)
    if (RED) {
      prefetch_l2(L.wr, 24L * 72 * 2048, blockIdx.x, nblk);
      phase_post_attn<true>(c, i, 0, sm, true, ev_attn);
      __syncthreads();
    } else {
      if (blockIdx.x < B) phase_post_attn<false>(c, i, blockIdx.x, sm, true, ev_attn);
      else prefetch_l2(L.wr, 24L * 72 * 2048, blockIdx.x - B, nblk - B);
      grid_bar(c, nbar, barbase);
    }
    TM(i, 7);
    // F: router
    if (!RED) stage_frags(sm, c.x2frag, 73728);
    { OpRouter<RED> op{i, RED ? sm.fx2 : reinterpret_cast<const bf16*>(sm.stage)}; gemv(c, op, 24, 72); }
    grid_bar(c, nbar, barbase);
    TM(i, 8);
    // G: routing (every block)
#ifdef ICTEST
    phase_route(c, i, sm);   // a second, i-cache-warm run is timed 31 -> 9
    TM(i, 31);
#endif
    phase_route(c, i, sm);
    TM(i, 9);
    int nu = sm.nuni;
    // H: w13 (+ act, amax to all cards)
    if (!RED) {
      if (L.mx) stage_frags(sm, c.w13frag, 36864, c.w13sc, 144 * MAXB * 4);
      else stage_frags(sm, c.w13frag, 73728);
    }
    { OpW13<RED> op{i, nu, &sm, RED ? sm.f13 : sm.stage,
                    RED ? sm.sc13 : (L.mx ? reinterpret_cast<const float*>(sm.stage + 36864) : c.w13sc), RED ? sm.sc13 : c.w13sc};
      gemv(c, op, (long)nu * 72, 72); }
    {
      long ub = L.mx ? UB8 : UB4, per = 288L * 9 * ub;
      // every block: its share of the union experts' w2 slabs
      for (int u = 0; u < nu; u++) prefetch_l2(L.w2 + (long)sm.uni[u] * per, per, blockIdx.x, nblk);
    }
    xsignal(c, 2, nbar, barbase); ev_amax++;
    TM(i, 10);
    xwait(c, 2, ev_amax);
    TM(i, 11);
    // I: quantize act for w2
    if (RED) {
      phase_quant2_red(c, i, nu, sm);
    } else {
      for (int it = blockIdx.x; it < nu * B; it += nblk) {
        int ui = it / B, b = it % B;
        bool routed = false;
        for (int r = 0; r < TOPK; r++) routed |= (sm.ids[b * TOPK + r] == sm.uni[ui]);
        if (routed) { phase_quant2(c, i, ui, b, sm); __syncthreads(); }
        else {  // not routed: zero scale and zero fragment column (a stale fragment of the other format could be Inf)
          if (threadIdx.x < 18) c.w2sc[(ui * 18 + threadIdx.x) * MAXB + b] = 0.f;
          if (threadIdx.x < ILOC) {
            uint8_t* frag = c.w2frag + (long)ui * 9 * 32 * (L.mx ? 16 : 32);
            if (L.mx) frag[fidx8(b, threadIdx.x)] = 0;
            else reinterpret_cast<__half*>(frag)[fidx16(b, threadIdx.x)] = __float2half_rn(0.f);
          }
        }
      }
      grid_bar(c, nbar, barbase);
    }
    TM(i, 12);
    // J: w2 -> all cards
    { OpW2<RED> op{i, nu, &sm, RED ? sm.f2 : c.w2frag, RED ? sm.sc2 : c.w2sc}; gemv(c, op, 288, nu * 9); }
    xsignal(c, 1, nbar, barbase); ev_mlp++;
    TM(i, 13);
  }
  if (layer_hi == NL) {
    TM(NL, 0);
    if (RED) {
      xwait(c, 1, ev_mlp); TM(NL, 1); phase_final<true>(c, 0, sm);
      __syncthreads();
    } else {
      if (blockIdx.x < B) { xwait(c, 1, ev_mlp); TM(NL, 1); phase_final<false>(c, blockIdx.x, sm); }
      grid_bar(c, nbar, barbase);
    }
    TM(NL, 2);
    for (int k = threadIdx.x; k < NWARP * MAXB; k += NTH) { sm.bestv[k] = -INFINITY; sm.besti[k] = 1 << 30; }
    __syncthreads();
    if (!RED) stage_frags(sm, c.hfrag, 73728);
    { OpUnembed<RED> op{sm.bestv, sm.besti, RED ? sm.fh : reinterpret_cast<const bf16*>(sm.stage)}; gemv(c, op, c.un_strips, 72); }
    __syncthreads();
    // block best per col -> candidates on every card
    if (threadIdx.x < B) {
      int col = threadIdx.x;
      float bv = -INFINITY; int bi = 1 << 30;
      for (int w = 0; w < NWARP; w++) {
        float v = sm.bestv[w * MAXB + col]; int ii = sm.besti[w * MAXB + col];
        if (v > bv || (v == bv && ii < bi)) { bv = v; bi = ii; }
      }
      for (int d = 0; d < NCARD; d++) { c.comm[d]->cand_v[c.h.card][col][blockIdx.x] = bv; c.comm[d]->cand_i[c.h.card][col][blockIdx.x] = bi; }
    }
    xsignal(c, 3, nbar, barbase);
    TM(NL, 3);
    if (blockIdx.x == 0) {
      xwait(c, 3, 1);
      TM(NL, 4);
      if (threadIdx.x < B) {
        int col = threadIdx.x;
        float bv = -INFINITY; int bi = 1 << 30;
        for (int d = 0; d < NCARD; d++)
          for (int k = 0; k < nblk; k++) {
            float v = c.comm[c.h.card]->cand_v[d][col][k]; int ii = c.comm[c.h.card]->cand_i[d][col][k];
            if (v > bv || (v == bv && ii < bi)) { bv = v; bi = ii; }
          }
        c.next_tok[col] = bi;
        if (c.h.gen_out) {
          if (c.h.gen_n) c.h.gen_out[c.h.gen_idx * MAXB + col] = bi + 1;          // host-mapped stream: 0 = not yet
          else c.h.gen_out[c.h.gen_idx * MAXB + col] = bi;
        }
      }
    }
  }
  grid_bar(c, nbar, barbase);
  if (blockIdx.x == 0 && threadIdx.x == 0) c.bar[1] = barbase + nbar * gridDim.x;
}

// the kernel parameters (Ctx, ~14 KB) are copied into shared memory once: every later access is a shared load,
// immune to the L1 invalidations of the barriers' acquire fences
#define CTXB ((sizeof(Ctx) + 127) / 128 * 128)
#define SMEM_TOTAL (CTXB + sizeof(Smem))
__device__ __forceinline__ const Ctx& load_ctx(const Ctx* cp, const Hdr& hdr, unsigned char* smraw) {
  static_assert(sizeof(Ctx) % 8 == 0 && sizeof(Hdr) % 8 == 0, "Ctx size");
  const uint2* src = reinterpret_cast<const uint2*>(cp);
  uint2* dst = reinterpret_cast<uint2*>(smraw);
  const int nh = sizeof(Hdr) / 8;
  for (int k = threadIdx.x; k < (int)(sizeof(Ctx) / 8); k += NTH)
    dst[k] = (k < nh) ? reinterpret_cast<const uint2*>(&hdr)[k] : src[k];   // the per-step header comes by value
  __syncthreads();
  return *reinterpret_cast<const Ctx*>(smraw);
}
extern "C" __global__ void __launch_bounds__(NTH, 1) ink_step_std(const Ctx* __restrict__ cp, const Hdr hdr, int lo, int hi) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Ctx& c = load_ctx(cp, hdr, smraw);
  step_body<false>(c, *reinterpret_cast<Smem*>(smraw + CTXB), lo, hi);
}
extern "C" __global__ void __launch_bounds__(NTH, 1) ink_step_red(const Ctx* __restrict__ cp, const Hdr hdr, int lo, int hi) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Ctx& c = load_ctx(cp, hdr, smraw);
  step_body<true>(c, *reinterpret_cast<Smem*>(smraw + CTXB), lo, hi);
}

// ------------------------------------------------------------------------------------------------ host API
extern "C" int ink_smem_bytes() { return (int)sizeof(Smem); }
extern "C" int ink_ctx_bytes() { return (int)sizeof(Ctx); }
extern "C" int ink_comm_bytes() { return (int)sizeof(Comm); }
extern "C" int ink_layer_bytes() { return (int)sizeof(LayerW); }

extern "C" int ink_setup(int dev) {
  cudaSetDevice(dev);
  cudaError_t e = cudaFuncSetAttribute(ink_step_std, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)SMEM_TOTAL);
  if (e) return (int)e;
  e = cudaFuncSetAttribute(ink_step_red, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)SMEM_TOTAL);
  return (int)e;
}

extern "C" int ink_enable_peer(int n) {
  for (int a = 0; a < n; a++) {
    cudaSetDevice(a);
    for (int b = 0; b < n; b++) if (a != b) {
      cudaError_t e = cudaDeviceEnablePeerAccess(b, 0);
      if (e != cudaSuccess && e != cudaErrorPeerAccessAlreadyEnabled) return (int)e;
      cudaGetLastError();
    }
  }
  return 0;
}
extern "C" void* ink_host_alloc(size_t n) {
  void* p = nullptr;
  if (cudaHostAlloc(&p, n, cudaHostAllocMapped | cudaHostAllocPortable) != cudaSuccess) return nullptr;
  memset(p, 0, n);
  return p;
}
extern "C" int ink_h2d(void* dst, const void* src, size_t n, void* stream) {
  return (int)cudaMemcpyAsync(dst, src, n, cudaMemcpyHostToDevice, (cudaStream_t)stream);
}
extern "C" int ink_launch(int dev, const void* ctx, const void* hdr, int nblk, void* stream, int lo, int hi, int red) {
  cudaSetDevice(dev);
  const Hdr h = *reinterpret_cast<const Hdr*>(hdr);
  if (red) ink_step_red<<<nblk, NTH, SMEM_TOTAL, (cudaStream_t)stream>>>((const Ctx*)ctx, h, lo, hi);
  else ink_step_std<<<nblk, NTH, SMEM_TOTAL, (cudaStream_t)stream>>>((const Ctx*)ctx, h, lo, hi);
  return (int)cudaGetLastError();
}
