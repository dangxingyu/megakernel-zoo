#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
NVCC=${NVCC:-nvcc}
if [ ! -f libmk.so ] || [ mk.cu -nt libmk.so ] || [ build.sh -nt libmk.so ]; then
  $NVCC -O3 -use_fast_math -std=c++17 -arch=sm_90 -maxrregcount=80 -shared -Xcompiler -fPIC ${MK_DEFS:-} -o libmk.so.tmp mk.cu
  mv libmk.so.tmp libmk.so
fi
