"""Qwen3-8B decode engine: one CUDA megakernel (engine/mk.cu) behind the contract.

    Engine(model_dir, max_batch, max_context)
    reset()                      forget every sequence
    step(tokens[B] int64 cuda)   append one token per sequence, return next-token logits [B, vocab] on cuda

Python only loads the weights, re-lays them out for the kernel (once) and launches the kernel; no torch
module and no library call computes anything in a step.
"""

import ctypes
import json
import os
import struct
import subprocess

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
H, NL, VOCAB, INNER = 4096, 36, 151936, 12288
MODE = int(os.environ.get("MK_MODE", "1"))  # 0: one launch per operator, 1: one launch per step


def _load_lib():
    so = os.path.join(HERE, "libmk.so")
    if not os.path.exists(so):
        subprocess.check_call(["bash", os.path.join(HERE, "build.sh")])
    lib = ctypes.CDLL(so)
    lib.mk_create.restype = ctypes.c_void_p
    lib.mk_create.argtypes = [ctypes.c_int, ctypes.c_int] + [ctypes.c_void_p] * 5
    lib.mk_step.restype = None
    lib.mk_step.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
    lib.mk_stat.restype = ctypes.c_longlong
    lib.mk_stat.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.mk_destroy.restype = None
    lib.mk_destroy.argtypes = [ctypes.c_void_p]
    lib.mk_check.restype = ctypes.c_int
    return lib


def pack_matrix(w: torch.Tensor) -> torch.Tensor:
    """[M, K] bf16 -> int16 stream in MMA A-fragment order: [tile][kstep][lane = 4*g + t][ch][rh][e],
    element = W[tile*16 + rh*8 + g][kstep*16 + ch*8 + t*2 + e]. A warp reads 512 contiguous bytes per MMA."""
    m, k = w.shape
    v = w.contiguous().view(torch.int16).view(m // 16, 2, 8, k // 16, 2, 4, 2)
    return v.permute(0, 3, 2, 5, 4, 1, 6).reshape(-1)


class _Weights:
    """Reads tensors from the safetensors shards straight to the GPU, one at a time."""

    def __init__(self, model_dir):
        self.dir = model_dir
        with open(os.path.join(model_dir, "model.safetensors.index.json")) as f:
            self.map = json.load(f)["weight_map"]
        self.headers = {}

    def get(self, name) -> torch.Tensor:
        fn = os.path.join(self.dir, self.map[name])
        if fn not in self.headers:
            with open(fn, "rb") as f:
                n = struct.unpack("<Q", f.read(8))[0]
                self.headers[fn] = (json.loads(f.read(n)), 8 + n)
        hdr, base = self.headers[fn]
        e = hdr[name]
        assert e["dtype"] == "BF16", (name, e["dtype"])
        b0, b1 = e["data_offsets"]
        import numpy as np

        arr = np.memmap(fn, dtype=np.int16, mode="r", offset=base + b0, shape=((b1 - b0) // 2,))
        t = torch.from_numpy(np.ascontiguousarray(arr)).cuda()
        return t.view(torch.bfloat16).view(e["shape"])


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        self.lib = _load_lib()
        self.max_batch, self.max_context = max_batch, max_context
        wts = _Weights(model_dir)
        layer_i16 = (6144 * 4096 + 4096 * 4096 + 24576 * 4096 + 4096 * 12288)
        total = NL * layer_i16 + VOCAB * H
        self.W = torch.empty(total, dtype=torch.int16, device="cuda")
        self.norm_w = torch.empty((2 * NL + 1, H), dtype=torch.float32, device="cuda")
        self.qk_norm_w = torch.empty((NL, 2, 128), dtype=torch.float32, device="cuda")
        off = 0

        def put(w):
            nonlocal off
            p = pack_matrix(w)
            self.W[off : off + p.numel()] = p
            off += p.numel()

        for l in range(NL):
            pre = f"model.layers.{l}."
            q, k, v = (wts.get(pre + f"self_attn.{n}_proj.weight") for n in "qkv")
            put(torch.cat([q, k, v], dim=0))
            del q, k, v
            put(wts.get(pre + "self_attn.o_proj.weight"))
            g = wts.get(pre + "mlp.gate_proj.weight")
            u = wts.get(pre + "mlp.up_proj.weight")
            # tile i = gate rows 8i..8i+7 then up rows 8i..8i+7: silu(gate)*up is computed inside one thread
            put(torch.cat([g.view(INNER // 8, 8, H), u.view(INNER // 8, 8, H)], dim=1).reshape(2 * INNER, H))
            del g, u
            put(wts.get(pre + "mlp.down_proj.weight"))
            self.norm_w[2 * l] = wts.get(pre + "input_layernorm.weight").float()
            self.norm_w[2 * l + 1] = wts.get(pre + "post_attention_layernorm.weight").float()
            self.qk_norm_w[l, 0] = wts.get(pre + "self_attn.q_norm.weight").float()
            self.qk_norm_w[l, 1] = wts.get(pre + "self_attn.k_norm.weight").float()
        put(wts.get("lm_head.weight"))
        assert off == total
        self.norm_w[2 * NL] = wts.get("model.norm.weight").float()
        self.embed = wts.get("model.embed_tokens.weight").contiguous()
        # RoPE table exactly as the reference computes it (float32 angles)
        inv_freq = 1.0 / (1000000.0 ** (torch.arange(0, 128, 2, dtype=torch.float) / 128))
        ang = torch.arange(max_context, dtype=torch.float)[:, None] * inv_freq[None, :]
        self.rope = torch.cat([ang.cos(), ang.sin()], dim=1).contiguous().cuda()
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        self.h = self.lib.mk_create(
            max_batch, max_context, self.W.data_ptr(), self.embed.data_ptr(), self.norm_w.data_ptr(),
            self.qk_norm_w.data_ptr(), self.rope.data_ptr(),
        )
        if not self.h:
            raise RuntimeError("mk_create failed")
        self.pos = 0
        self.mode = MODE
        self._keep = None

    def reset(self) -> None:
        self.pos = 0

    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        if tokens.dtype != torch.int64 or not tokens.is_contiguous():
            tokens = tokens.to(torch.int64).contiguous()
        b = tokens.shape[0]
        logits = torch.empty((b, VOCAB), dtype=torch.float32, device="cuda")
        self.lib.mk_step(self.h, tokens.data_ptr(), logits.data_ptr(), b, self.pos, self.mode)
        self.pos += 1
        self._keep = tokens  # the kernel reads it asynchronously
        return logits

    def close(self) -> None:
        if getattr(self, "h", None):
            self.lib.mk_destroy(self.h)
            self.h = None
        self.W = self.embed = self.norm_w = self.qk_norm_w = self.rope = None

    def stats(self) -> dict:
        return {
            "implementation": "megakernel",
            "mode": "launch per operator" if self.mode == 0 else "one launch per step",
            "kernel_launches": int(self.lib.mk_stat(self.h, 0)),
            "steps": int(self.lib.mk_stat(self.h, 1)),
            "blocks": int(self.lib.mk_stat(self.h, 2)),
            "host_syncs_in_step": 0,
            "max_batch": self.max_batch,
            "max_context": self.max_context,
        }
