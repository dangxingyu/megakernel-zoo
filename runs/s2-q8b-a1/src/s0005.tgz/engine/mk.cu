// Decode megakernel for Qwen3-8B (bf16 weights) on one H100.
// One CUDA source: device code for every operator of a decode step + a small host API (ctypes).
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define H 4096
#define NL 36
#define QKV_ROWS 6144
#define INNER 12288
#define VOCAB 151936
#define NWARP 32
#define NTHREAD 1024
#define MAXB 8
#define NLOAD 31           // warps 0..30 stream weights
#define CW 31              // coordinator warp: sums the partial accumulators, runs the epilogue, drives the barrier

// tiles x ksteps of each matrix (tile = 16 output rows, kstep = 16 input dims, 512 bytes per (tile,kstep))
#define QKV_T 384
#define O_T 256
#define GU_T 1536
#define DN_T 256
#define LM_T 9496
#define KS_H 256
#define KS_I 768
// offsets inside a layer, in uint4 (16 byte) units
#define OFF_QKV 0ull
#define OFF_O (OFF_QKV + (size_t)QKV_T * KS_H * 32)
#define OFF_GU (OFF_O + (size_t)O_T * KS_H * 32)
#define OFF_DN (OFF_GU + (size_t)GU_T * KS_H * 32)
#define LAYER_U4 (OFF_DN + (size_t)DN_T * KS_I * 32)

#define SX_BYTES (KS_I * 32 * 8)
#define RED_BYTES (2 * 32 * 32 * 16)
#define MISC_OFF (SX_BYTES + RED_BYTES)   // Params copy, tile table, small scratch
#define MISC_BYTES 1024
#define TB_OFF (MISC_OFF + 256)           // int[8]: this block's [t0,t1) for qkv, o/down, gate+up, lm
#define SCR_OFF (MISC_OFF + 320)          // float[176]
#define SMEM_BYTES (SX_BYTES + RED_BYTES + MISC_BYTES)
#define ATT_OFF_BYTES (KS_H * 32 * 8)     // attention scratch lives in sx beyond the K=4096 fragments
#define MAX_CTX_SMEM 3904

#define BARRIERS_PER_STEP (1 + NL * 5)

struct Params {
  const uint4* W;             // packed weights: 36 layers (qkv, o, gateup, down), then lm_head
  const unsigned short* embed;// [VOCAB][H] bf16
  const float* norm_w;        // [2*NL+1][H]: input norm l, post-attention norm l, ..., final norm
  const float* qk_norm_w;     // [NL][2][128]
  const float* rope;          // [max_ctx][128]: cos[64], sin[64]
  float* xres;                // [MAXB][H] residual stream, float32
  float* qkv;                 // [MAXB][QKV_ROWS]
  unsigned short* afrag;      // [MAXB][KS_H][4][4] bf16: attention output as MMA B-fragments
  unsigned short* mfrag;      // [MAXB][KS_I][4][4] bf16: silu(gate)*up as MMA B-fragments
  uint4* kc;                  // K cache, MMA A-fragment layout: [NL][MAXB][8][ctx_tiles][8][32]
  uint4* vc;                  // V cache (transposed), [NL][MAXB][8][ctx_tiles][8][32]
  unsigned* sync;             // barrier counter
  const int* tiles;           // [blocks][8]: tile ranges per block
  const long long* tokens;    // [B]
  float* logits;              // [B][VOCAB]
  size_t kv_stride;           // uint4 per (layer, seq, kv head)
  unsigned sync_base;
  int B, pos;
};

#define MMA(c, a, b) asm volatile( \
  "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
  : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) \
  : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y))

__device__ __forceinline__ unsigned short f2bf(float f) {
  unsigned u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (unsigned short)(u >> 16);
}
__device__ __forceinline__ float bf2f(unsigned v) { return __uint_as_float(v << 16); }

// index (in bf16 units) of element k of batch column n inside a B-fragment buffer of `stride` entries per kstep
// smem layout: [kstep][lane = 4n + t][slot]; global compact layout: [n][kstep][t][slot]
__device__ __forceinline__ int frag_slot(int k) { return (k & 1) + 2 * ((k >> 3) & 1); }
__device__ __forceinline__ int frag_t(int k) { return (k & 7) >> 1; }
__device__ __forceinline__ int sx_index(int k, int n) { return (((k >> 4) * 32 + 4 * n + frag_t(k)) << 2) + frag_slot(k); }
__device__ __forceinline__ size_t gfrag_index(int k, int n, int ksteps) { return ((((size_t)n * ksteps + (k >> 4)) * 4 + frag_t(k)) << 2) + frag_slot(k); }

__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
__device__ __forceinline__ float warp_max(float v) {
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 16));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 8));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 4));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 2));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 1));
  return v;
}

// ---------------------------------------------------------------------------------------------------------
// entries: put the bf16 input of a matvec into shared memory as MMA B-fragments
// ---------------------------------------------------------------------------------------------------------

// x = embedding row (bf16 -> f32)
__device__ __noinline__ void op_embed(unsigned char* smem) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  int b = blockIdx.x;
  if (b < P.B) {
    long long tok = P.tokens[b];
    const uint2* e = (const uint2*)(P.embed + (size_t)tok * H);
    uint2 v = e[threadIdx.x];
    float4 f = make_float4(bf2f(v.x & 0xffffu), bf2f(v.x >> 16), bf2f(v.y & 0xffffu), bf2f(v.y >> 16));
    ((float4*)(P.xres + (size_t)b * H))[threadIdx.x] = f;
    __threadfence();
  }
  __syncthreads();
}

// sx <- bf16( w * x * rsqrt(mean(x^2) + eps) ) for every sequence; every block computes it for itself
__device__ __noinline__ void entry_norm(unsigned char* smem, const float* wn) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  unsigned short* sx16 = (unsigned short*)smem;
  float* scr = (float*)(smem + SX_BYTES);
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5, B = P.B;
  float4 xv[MAXB];
#pragma unroll
  for (int n = 0; n < MAXB; n++) {
    if (n < B) {
      xv[n] = __ldcg((const float4*)(P.xres + (size_t)n * H) + tid);
      float p = xv[n].x * xv[n].x + xv[n].y * xv[n].y + xv[n].z * xv[n].z + xv[n].w * xv[n].w;
      p = warp_sum(p);
      if (lane == 0) scr[w * MAXB + n] = p;
    }
  }
  __syncthreads();
  if (w == 0 && lane < B) {
    float ss = 0.f;
    for (int i = 0; i < NWARP; i++) ss += scr[i * MAXB + lane];
    scr[NWARP * MAXB + lane] = 1.0f / sqrtf(ss * (1.0f / H) + 1e-6f);
  }
  __syncthreads();
  float4 wv = ((const float4*)wn)[tid];
#pragma unroll
  for (int n = 0; n < MAXB; n++) {
    if (n < B) {
      float r = scr[NWARP * MAXB + n];
      int k = tid * 4;
      sx16[sx_index(k + 0, n)] = f2bf(wv.x * (xv[n].x * r));
      sx16[sx_index(k + 1, n)] = f2bf(wv.y * (xv[n].y * r));
      sx16[sx_index(k + 2, n)] = f2bf(wv.z * (xv[n].z * r));
      sx16[sx_index(k + 3, n)] = f2bf(wv.w * (xv[n].w * r));
    }
  }
  __syncthreads();
}

// sx <- fragments written to global memory by the previous phase ([n][kstep][4 lanes][4 bf16])
template <int KS>
__device__ __noinline__ void entry_copy(unsigned char* smem, const unsigned short* g) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  uint4* sx4 = (uint4*)smem;
  const int per = KS * 2, tot = per * P.B;
  // flat index over (sequence, entry) so that the loads are spread over all threads of the block
  for (int i = threadIdx.x; i < tot; i += NTHREAD) {
    int n = i / per, r = i - n * per;
    sx4[(r >> 1) * 16 + 2 * n + (r & 1)] = __ldcg((const uint4*)g + i);
  }
  __syncthreads();
}

// ---------------------------------------------------------------------------------------------------------
// matvec: block team. Block b owns tiles [b*T/nb, (b+1)*T/nb); loader warp w streams ksteps
// [w*ks/NLOAD, (w+1)*ks/NLOAD) of each tile; warp REDW sums the partials in fixed order and runs the epilogue.
// ---------------------------------------------------------------------------------------------------------
enum { EP_QKV = 0, EP_ADD = 1, EP_GU = 2, EP_LM = 3 };

template <int EP>
__device__ __forceinline__ void epilogue(const Params& P, int tile, int lane, float4 c) {
  const int g = lane >> 2, t = lane & 3, B = P.B;
  const int n0 = 2 * t, n1 = 2 * t + 1;
  if (EP == EP_QKV) {
    int row = tile * 16 + g;
    if (n0 < B) { P.qkv[(size_t)n0 * QKV_ROWS + row] = c.x; P.qkv[(size_t)n0 * QKV_ROWS + row + 8] = c.z; }
    if (n1 < B) { P.qkv[(size_t)n1 * QKV_ROWS + row] = c.y; P.qkv[(size_t)n1 * QKV_ROWS + row + 8] = c.w; }
  } else if (EP == EP_ADD) {
    int row = tile * 16 + g;
    if (n0 < B) {
      float* p = P.xres + (size_t)n0 * H + row;
      float a = __ldcg(p), b = __ldcg(p + 8);
      p[0] = a + c.x; p[8] = b + c.z;
    }
    if (n1 < B) {
      float* p = P.xres + (size_t)n1 * H + row;
      float a = __ldcg(p), b = __ldcg(p + 8);
      p[0] = a + c.y; p[8] = b + c.w;
    }
  } else if (EP == EP_GU) {
    int j = tile * 8 + g;           // rows 0..7 of the tile are gate[j], rows 8..15 are up[j]
    if (n0 < B) { float m = c.x / (1.0f + __expf(-c.x)) * c.z; P.mfrag[gfrag_index(j, n0, KS_I)] = f2bf(m); }
    if (n1 < B) { float m = c.y / (1.0f + __expf(-c.y)) * c.w; P.mfrag[gfrag_index(j, n1, KS_I)] = f2bf(m); }
  } else {
    int row = tile * 16 + g;
    if (n0 < B) { P.logits[(size_t)n0 * VOCAB + row] = c.x; P.logits[(size_t)n0 * VOCAB + row + 8] = c.z; }
    if (n1 < B) { P.logits[(size_t)n1 * VOCAB + row] = c.y; P.logits[(size_t)n1 * VOCAB + row + 8] = c.w; }
  }
}

__device__ __forceinline__ float4 add4(float4 a, float4 b) { return make_float4(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w); }

// KS = ksteps of the matrix (256 or 768); loader warp w streams BASE (+1 for the first EXTRA warps) ksteps
template <int EP, int KS>
__device__ __noinline__ void gemv(unsigned char* smem, const uint4* W, int tsel) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const uint2* sx = (const uint2*)smem;
  float4* red = (float4*)(smem + SX_BYTES);
  const int* tb = (const int*)(smem + TB_OFF);
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int t0 = tb[2 * tsel], t1 = tb[2 * tsel + 1];
  enum { BASE = KS / NLOAD, EXTRA = KS % NLOAD };
  const int s0 = w * BASE + min(w, (int)EXTRA);
  const bool extra = w < EXTRA;
  for (int t = t0; t <= t1; t++) {
    if (w < NLOAD && t < t1) {
      const uint4* p = W + ((size_t)t * KS + s0) * 32 + lane;
      const uint2* xb = sx + s0 * 32 + lane;
      float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
      for (int j = 0; j < BASE; j += 8) {
        uint4 a[8];
#pragma unroll
        for (int u = 0; u < 8; u++) a[u] = p[(j + u) * 32];
#pragma unroll
        for (int u = 0; u < 8; u++) { uint2 bb = xb[(j + u) * 32]; MMA(c, a[u], bb); }
      }
      if (extra) { uint4 a = p[BASE * 32]; uint2 bb = xb[BASE * 32]; MMA(c, a, bb); }
      red[((t & 1) * 32 + w) * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
    }
    __syncthreads();
    if (w == CW && t < t1) {
      // fixed-order sum of the 31 partials (tree: short dependency chains)
      const float4* r = red + (t & 1) * 32 * 32 + lane;
#define R_(i) r[(i) * 32]
#define S8_(o) add4(add4(add4(R_(o), R_(o + 1)), add4(R_(o + 2), R_(o + 3))), add4(add4(R_(o + 4), R_(o + 5)), add4(R_(o + 6), R_(o + 7))))
      float4 q0 = S8_(0), q1 = S8_(8), q2 = S8_(16);
      float4 q3 = add4(add4(add4(R_(24), R_(25)), add4(R_(26), R_(27))), add4(add4(R_(28), R_(29)), R_(30)));
#undef S8_
#undef R_
      float4 c = add4(add4(q0, q1), add4(q2, q3));
      epilogue<EP>(P, t, lane, c);
      if (t == t1 - 1) __threadfence();
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// attention: block b < 8B handles (sequence n = b/8, kv head g = b%8): q/k norms, RoPE, append K/V,
// scores (MMA over the K cache), softmax, weighted V sum (MMA over the V cache)
// ---------------------------------------------------------------------------------------------------------
__device__ __noinline__ void op_attention(unsigned char* smem, int layer) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const int b = blockIdx.x, B = P.B;
  if (b >= 8 * B) return;
  const int n = b >> 3, g = b & 7;
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int pos = P.pos, T = pos + 1, nt = (T + 15) >> 4, NTP = nt * 16;
  float* y = (float*)(smem + ATT_OFF_BYTES);                 // [5][128]
  unsigned short* qfrag16 = (unsigned short*)(y + 768);      // [8][32][4]
  const uint2* qfrag = (const uint2*)qfrag16;
  float* sc = (float*)(qfrag16 + 8 * 32 * 4);                // [4][NTP]
  unsigned short* pfrag16 = (unsigned short*)(sc + 4 * NTP); // [nt][32][4]
  const uint2* pfrag = (const uint2*)pfrag16;
  float* scr = (float*)(smem + SCR_OFF);
  float4* red = (float4*)(smem + SX_BYTES);
  uint4* Kc = P.kc + (((size_t)layer * MAXB + n) * 8 + g) * P.kv_stride;
  uint4* Vc = P.vc + (((size_t)layer * MAXB + n) * 8 + g) * P.kv_stride;

  // ---- step 1: q (4 heads), k, v of the new token
  const int vec = tid >> 7, d = tid & 127;   // vec 0..3: q heads, 4: k, 5: v
  float x = 0.f, yv = 0.f;
  if (vec < 6) {
    int row = vec < 4 ? ((4 * g + vec) * 128 + d) : (vec == 4 ? 4096 + g * 128 + d : 5120 + g * 128 + d);
    x = __ldcg(P.qkv + (size_t)n * QKV_ROWS + row);
    if (vec < 5) { float p = warp_sum(x * x); if (lane == 0) scr[w] = p; }
  }
  __syncthreads();
  if (vec < 5) {
    float ss = scr[4 * vec] + scr[4 * vec + 1] + scr[4 * vec + 2] + scr[4 * vec + 3];
    float r = 1.0f / sqrtf(ss * (1.0f / 128) + 1e-6f);
    yv = P.qk_norm_w[(layer * 2 + (vec < 4 ? 0 : 1)) * 128 + d] * (x * r);
    y[vec * 128 + d] = yv;
  }
  __syncthreads();
  if (vec < 5) {
    float cs = P.rope[(size_t)pos * 128 + (d & 63)], sn = P.rope[(size_t)pos * 128 + 64 + (d & 63)];
    float other = y[vec * 128 + (d ^ 64)];
    float o = d < 64 ? yv * cs - other * sn : yv * cs + other * sn;
    unsigned short ob = f2bf(o);
    if (vec < 4) {
      qfrag16[(((d >> 4) * 32 + 4 * vec + frag_t(d)) << 2) + frag_slot(d)] = ob;
    } else {
      int m = pos & 15, kcol = d & 15;
      int ln = (m & 7) * 4 + ((kcol & 7) >> 1), el = (kcol >> 3) * 4 + (m >> 3) * 2 + (kcol & 1);
      ((unsigned short*)Kc)[((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ln) << 3) + el] = ob;
    }
  } else if (vec == 5) {
    int kcol = pos & 15, m = d & 15;
    int ln = (m & 7) * 4 + ((kcol & 7) >> 1), el = (kcol >> 3) * 4 + (m >> 3) * 2 + (kcol & 1);
    ((unsigned short*)Vc)[((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ln) << 3) + el] = f2bf(x);
  }
  __threadfence();
  __syncthreads();

  // ---- step 2: scores[h][j] = q_h . K_j / sqrt(128)
  for (int tile = w; tile < nt; tile += NWARP) {
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    const uint4* p = Kc + (size_t)tile * 256 + lane;
#pragma unroll
    for (int s = 0; s < 8; s++) {
      uint4 a = __ldcg(p + s * 32);
      uint2 bq = make_uint2(0, 0);
      if (lane < 16) bq = qfrag[s * 32 + lane];
      MMA(c, a, bq);
    }
    int t = lane & 3, j = tile * 16 + (lane >> 2);
    if (t < 2) {
      const float scale = 0.08838834764831845f;
      const float ninf = -__int_as_float(0x7f800000);
      sc[(2 * t) * NTP + j] = j < T ? c[0] * scale : ninf;
      sc[(2 * t + 1) * NTP + j] = j < T ? c[1] * scale : ninf;
      sc[(2 * t) * NTP + j + 8] = j + 8 < T ? c[2] * scale : ninf;
      sc[(2 * t + 1) * NTP + j + 8] = j + 8 < T ? c[3] * scale : ninf;
    }
  }
  __syncthreads();

  // ---- step 3: softmax per head; warp w: head w&3, slice w>>2 of 8
  {
    const int h = w & 3, r = w >> 2;
    const float* s = sc + h * NTP;
    float mx = -__int_as_float(0x7f800000);
    for (int j = r + 8 * lane; j < NTP; j += 256) mx = fmaxf(mx, s[j]);
    mx = warp_max(mx);
    if (lane == 0) scr[w] = mx;
    __syncthreads();
    mx = scr[h];
    for (int i = 1; i < 8; i++) mx = fmaxf(mx, scr[h + 4 * i]);
    float sum = 0.f;
    for (int j = r + 8 * lane; j < NTP; j += 256) { float e = __expf(s[j] - mx); sc[h * NTP + j] = e; sum += e; }
    sum = warp_sum(sum);
    if (lane == 0) scr[32 + w] = sum;
    __syncthreads();
    float Z = scr[32 + h];
    for (int i = 1; i < 8; i++) Z += scr[32 + h + 4 * i];
    for (int j = r + 8 * lane; j < NTP; j += 256) {
      float p = s[j] / Z;
      pfrag16[(((j >> 4) * 32 + 4 * h + frag_t(j)) << 2) + frag_slot(j)] = f2bf(p);
    }
    __syncthreads();
  }

  // ---- step 4: out[h][d] = sum_j p[h][j] V[j][d]; warp w: dim tile w&7, kstep segment w>>3 of 4
  {
    const int dt = w & 7, r = w >> 3;
    const int s0 = r * nt / 4, s1 = (r + 1) * nt / 4;
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    for (int s = s0; s < s1; s++) {
      uint4 a = __ldcg(Vc + ((size_t)s * 8 + dt) * 32 + lane);
      uint2 bp = make_uint2(0, 0);
      if (lane < 16) bp = pfrag[s * 32 + lane];
      MMA(c, a, bp);
    }
    red[w * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
    __syncthreads();
    if (w < 8) {
      float4 v = red[w * 32 + lane];
      for (int i = 1; i < 4; i++) { float4 u = red[(w + 8 * i) * 32 + lane]; v.x += u.x; v.y += u.y; v.z += u.z; v.w += u.w; }
      int t = lane & 3, m = lane >> 2;
      if (t < 2) {
        int base0 = (4 * g + 2 * t) * 128 + dt * 16 + m, base1 = (4 * g + 2 * t + 1) * 128 + dt * 16 + m;
        P.afrag[gfrag_index(base0, n, KS_H)] = f2bf(v.x);
        P.afrag[gfrag_index(base1, n, KS_H)] = f2bf(v.y);
        P.afrag[gfrag_index(base0 + 8, n, KS_H)] = f2bf(v.z);
        P.afrag[gfrag_index(base1 + 8, n, KS_H)] = f2bf(v.w);
      }
      __threadfence();
    }
    // the scratch lives where the down-projection keeps its input fragments: lanes of unused batch columns
    // must read as zero there, so wipe what this block dirtied (with B = 8 every lane is overwritten anyway)
#ifndef NO_CLEAN
    if (B < MAXB) {
      uint4* z = (uint4*)(smem + ATT_OFF_BYTES);
      const int nz = (5120 + 32 * NTP + 15) / 16;
      for (int i = tid; i < nz; i += NTHREAD) z[i] = make_uint4(0, 0, 0, 0);
    }
#endif
    __syncthreads();
  }
}

// ---------------------------------------------------------------------------------------------------------
// the kernel: the whole decode step in one launch
// ---------------------------------------------------------------------------------------------------------
enum { T_QKV = 0, T_OD = 1, T_GU = 2, T_LM = 3 };

// grid-wide barrier: every block adds one, then waits until all have. Every operator ends with its global
// stores fenced and a block barrier, so only the coordinator thread touches the counter.
__device__ __forceinline__ void barrier(const Params& P, unsigned idx) {
  if (threadIdx.x == CW * 32) {
    atomicAdd(P.sync, 1u);
    unsigned target = P.sync_base + (idx + 1u) * gridDim.x;
    while ((int)(*(volatile unsigned*)P.sync - target) < 0) {}
  }
  __syncthreads();
}

__global__ void k_step(Params Pk) {
  extern __shared__ __align__(16) unsigned char smem[];
  {
    uint4* sx4 = (uint4*)smem;
    for (int i = threadIdx.x; i < SX_BYTES / 16; i += NTHREAD) sx4[i] = make_uint4(0, 0, 0, 0);
    const unsigned* src = (const unsigned*)&Pk;
    if (threadIdx.x < sizeof(Params) / 4) ((unsigned*)(smem + MISC_OFF))[threadIdx.x] = src[threadIdx.x];
    if (threadIdx.x < 8) ((int*)(smem + TB_OFF))[threadIdx.x] = Pk.tiles[blockIdx.x * 8 + threadIdx.x];
    __syncthreads();
  }
  const Params& P = *(const Params*)(smem + MISC_OFF);
  unsigned bi = 0;
  op_embed(smem); barrier(P, bi++);
  for (int l = 0; l < NL; l++) {
    const uint4* WL = P.W + (size_t)l * LAYER_U4;
    entry_norm(smem, P.norm_w + (size_t)(2 * l) * H);
    gemv<EP_QKV, KS_H>(smem, WL + OFF_QKV, T_QKV); barrier(P, bi++);
    op_attention(smem, l); barrier(P, bi++);
    entry_copy<KS_H>(smem, P.afrag);
    gemv<EP_ADD, KS_H>(smem, WL + OFF_O, T_OD); barrier(P, bi++);
    entry_norm(smem, P.norm_w + (size_t)(2 * l + 1) * H);
    gemv<EP_GU, KS_H>(smem, WL + OFF_GU, T_GU); barrier(P, bi++);
    entry_copy<KS_I>(smem, P.mfrag);
    gemv<EP_ADD, KS_I>(smem, WL + OFF_DN, T_OD); barrier(P, bi++);
  }
  entry_norm(smem, P.norm_w + (size_t)(2 * NL) * H);
  gemv<EP_LM, KS_H>(smem, P.W + (size_t)NL * LAYER_U4, T_LM);
}

// ---------------------------------------------------------------------------------------------------------
// host API
// ---------------------------------------------------------------------------------------------------------
struct Engine {
  Params P;
  int nsm, max_batch, max_ctx;
  long long launches, steps, errors;
};

#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "CUDA error %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); abort(); } } while (0)

extern "C" {

void* mk_create(int max_batch, int max_ctx, const void* W, const void* embed, const void* norm_w, const void* qk_norm_w, const void* rope) {
  if (max_batch > MAXB || max_ctx > MAX_CTX_SMEM) { fprintf(stderr, "mk_create: unsupported max_batch %d / max_ctx %d\n", max_batch, max_ctx); return nullptr; }
  Engine* E = new Engine();
  memset(E, 0, sizeof(Engine));
  int dev = 0; CK(cudaGetDevice(&dev));
  cudaDeviceProp prop; CK(cudaGetDeviceProperties(&prop, dev));
  E->nsm = prop.multiProcessorCount;
  E->max_batch = max_batch; E->max_ctx = max_ctx;
  Params& P = E->P;
  P.W = (const uint4*)W; P.embed = (const unsigned short*)embed; P.norm_w = (const float*)norm_w;
  P.qk_norm_w = (const float*)qk_norm_w; P.rope = (const float*)rope;
  size_t ctx_tiles = (max_ctx + 15) / 16;
  P.kv_stride = ctx_tiles * 256;
  size_t kv_bytes = (size_t)NL * MAXB * 8 * P.kv_stride * 16;
  CK(cudaMalloc(&P.xres, sizeof(float) * MAXB * H));
  CK(cudaMalloc(&P.qkv, sizeof(float) * MAXB * QKV_ROWS));
  CK(cudaMalloc(&P.afrag, 2 * MAXB * H));
  CK(cudaMalloc(&P.mfrag, 2 * MAXB * INNER));
  CK(cudaMalloc(&P.kc, kv_bytes));
  CK(cudaMalloc(&P.vc, kv_bytes));
  CK(cudaMalloc(&P.sync, 64));
  {
    int nb = E->nsm; int* tb = new int[nb * 8];
    const int nt[4] = {QKV_T, O_T, GU_T, LM_T};
    for (int b = 0; b < nb; b++) for (int k = 0; k < 4; k++) {
      tb[b * 8 + 2 * k] = (int)((long long)b * nt[k] / nb); tb[b * 8 + 2 * k + 1] = (int)((long long)(b + 1) * nt[k] / nb);
    }
    int* d; CK(cudaMalloc(&d, sizeof(int) * nb * 8)); CK(cudaMemcpy(d, tb, sizeof(int) * nb * 8, cudaMemcpyHostToDevice));
    P.tiles = d; delete[] tb;
  }
  CK(cudaMemset(P.xres, 0, sizeof(float) * MAXB * H));
  CK(cudaMemset(P.qkv, 0, sizeof(float) * MAXB * QKV_ROWS));
  CK(cudaMemset(P.afrag, 0, 2 * MAXB * H));
  CK(cudaMemset(P.mfrag, 0, 2 * MAXB * INNER));
  CK(cudaMemset(P.kc, 0, kv_bytes));
  CK(cudaMemset(P.vc, 0, kv_bytes));   // V must stay finite: masked positions are multiplied by p = 0
  CK(cudaMemset(P.sync, 0, 64));
  CK(cudaFuncSetAttribute(k_step, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES));
  return E;
}

void mk_step(void* h, const void* tokens, void* logits, int B, int pos, int mode) {
  Engine* E = (Engine*)h;
  Params P = E->P;
  P.tokens = (const long long*)tokens; P.logits = (float*)logits; P.B = B; P.pos = pos;
  k_step<<<E->nsm, NTHREAD, SMEM_BYTES>>>(P);
  E->P.sync_base += (unsigned)BARRIERS_PER_STEP * E->nsm;
  E->launches += 1;
  E->steps += 1;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess && E->errors++ < 5) fprintf(stderr, "mk_step: launch error: %s\n", cudaGetErrorString(e));
}

long long mk_stat(void* h, int which) {
  Engine* E = (Engine*)h;
  return which == 0 ? E->launches : which == 1 ? E->steps : which == 2 ? E->nsm : which == 3 ? E->errors : 0;
}

int mk_check() { cudaError_t e = cudaGetLastError(); if (e != cudaSuccess) fprintf(stderr, "mk_check: %s\n", cudaGetErrorString(e)); return (int)e; }

void mk_destroy(void* h) {
  Engine* E = (Engine*)h;
  cudaDeviceSynchronize();
  Params& P = E->P;
  cudaFree(P.xres); cudaFree(P.qkv); cudaFree(P.afrag); cudaFree(P.mfrag); cudaFree(P.kc); cudaFree(P.vc); cudaFree(P.sync); cudaFree((void*)P.tiles);
  delete E;
}

}  // extern "C"
