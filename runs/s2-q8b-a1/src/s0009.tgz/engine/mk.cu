// Decode megakernel for Qwen3-8B (bf16 weights) on one H100.
// One CUDA source: device code for every operator of a decode step + a small host API (ctypes).
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define H 4096
#define NL 36
#define QKV_ROWS 6144
#define INNER 12288
#define VOCAB 151936
#define NWARP 32
#define NTHREAD 1024
#define MAXB 8
#define NLOAD 31           // warps 0..30 stream weights
#define CW 31              // coordinator warp: sums the partial accumulators, runs the epilogue, drives the barrier

// tiles x ksteps of each matrix (tile = 16 output rows, kstep = 16 input dims, 512 bytes per (tile,kstep))
#define QKV_T 384
#define O_T 256
#define GU_T 1536
#define DN_T 256
#define LM_T 9496
#define KS_H 256
#define KS_I 768
// offsets inside a layer, in uint4 (16 byte) units
#define OFF_QKV 0ull
#define OFF_O (OFF_QKV + (size_t)QKV_T * KS_H * 32)
#define OFF_GU (OFF_O + (size_t)O_T * KS_H * 32)
#define OFF_DN (OFF_GU + (size_t)GU_T * KS_H * 32)
#define LAYER_U4 (OFF_DN + (size_t)DN_T * KS_I * 32)

#define SX_BYTES (KS_I * 32 * 8)
#define RED_BYTES (2 * 32 * 32 * 16)
#define MISC_OFF (SX_BYTES + RED_BYTES)   // Params copy, tile table, small scratch
#define MISC_BYTES 1024
#define TB_OFF (MISC_OFF + 256)           // int[8]: this block's [t0,t1) for qkv, down, gate+up, lm
#define TBO_OFF (TB_OFF + 48)             // int[2]: this block's [t0,t1) for o (depends on the batch size)
#define RN_OFF (MISC_OFF + 320)           // float[8]: 1/rms of the current norm, per sequence
#define SCR_OFF (MISC_OFF + 352)          // float[168]
#define SMEM_BYTES (SX_BYTES + RED_BYTES + MISC_BYTES)
#define ATT_OFF_BYTES (KS_H * 32 * 8)     // attention scratch lives in sx beyond the K=4096 fragments
#define STASH_OFF (KS_H * 32 * 8)         // non-attention blocks: image of their first o tile (256 ksteps x 512 B)
#define MAX_CTX_SMEM 3904

#define BARRIERS_PER_LAYER 5
#define BARRIERS_PER_STEP (1 + NL * BARRIERS_PER_LAYER)
#define BARRIERS_PER_GEN_STEP (2 + NL * BARRIERS_PER_LAYER)

struct Params {
  const uint4* W;             // packed weights: 36 layers (qkv, o, gateup, down), then lm_head
  const unsigned short* embed;// [VOCAB][H] bf16
  const float* norm_w;        // [2*NL+1][H]: input norm l, post-attention norm l, ..., final norm
  const float* qk_norm_w;     // [NL][2][128]
  const float* rope;          // [max_ctx][128]: cos[64], sin[64]
  float* xres;                // [MAXB][H] residual stream, float32
  float* qkv;                 // [MAXB][QKV_ROWS]
  unsigned short* afrag;      // [MAXB][KS_H][4][4] bf16: attention output as MMA B-fragments
  unsigned short* mfrag;      // [MAXB][KS_I][4][4] bf16: silu(gate)*up as MMA B-fragments
  unsigned short* xfrag;      // [MAXB][KS_H][4][4] bf16: w_norm * x (not yet scaled by 1/rms) for the next norm+matvec
  float* ssq;                 // [MAXB][256]: per 16-row tile sum of x^2 (partial sums of the next RMSNorm)
  uint4* kc;                  // K cache, MMA A-fragment layout: [NL][MAXB][8][ctx_tiles][8][32]
  uint4* vc;                  // V cache (transposed), [NL][MAXB][8][ctx_tiles][8][32]
  unsigned* sync;             // barrier counter
  unsigned char* flags;       // barrier: one byte per block = number (mod 256) of the last barrier it reached
  const int* tiles;           // [blocks][8]: tile ranges per block
  const int* tiles_o;         // [MAXB][blocks][2]: tile ranges of the o projection per batch size
  const long long* tokens;    // [B]
  float* logits;              // [B][VOCAB]
  long long* gen_out;         // generate(): [B][n_steps] tokens
  float* bm_val;              // generate(): [MAXB][blocks] best logit seen by each block
  int* bm_idx;                // generate(): [MAXB][blocks] its row
  int n_steps;
  unsigned* clk;              // TRACE: software clock
  unsigned* trace;            // TRACE: [blocks][8 phases][8 points]
  int nwork;                  // number of working blocks (TRACE: one less than the grid)
  unsigned trace_stop;        // TRACE: value of *sync at which the clock stops
  size_t kv_stride;           // uint4 per (layer, seq, kv head)
  unsigned sync_base;
  int B, pos;
};

#define TSEL_O T_O
enum { T_QKV = 0, T_DN = 1, T_GU = 2, T_LM = 3, T_O = 6 };   // index into the block's tile table (T_O: per batch size)

// TRACE build: the last block is a software clock (a counter in global memory), the coordinator thread of every
// working block timestamps points of the phases of one layer. Diagnosis only; never in a submission.
#ifdef TRACE
#ifndef TRACE_LAYER
#define TRACE_LAYER 17
#endif
#define TR_PARAM , int tr
#define TR_ARG(x) , (x)
#define TP(i) do { if (tr >= 0 && threadIdx.x == CW * 32) P.trace[(blockIdx.x * 8 + tr) * 8 + (i)] = *(volatile unsigned*)P.clk; } while (0)
#define NWORK (P.nwork)
#define TRACE_EXTRA 1
#else
#define TRACE_EXTRA 0
#define TR_PARAM
#define TR_ARG(x)
#define TP(i) do { } while (0)
#define NWORK ((int)gridDim.x)
#endif

#define MMA(c, a, b) asm volatile( \
  "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
  : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) \
  : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y))

__device__ __forceinline__ unsigned short f2bf(float f) {
  unsigned u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (unsigned short)(u >> 16);
}
__device__ __forceinline__ float bf2f(unsigned v) { return __uint_as_float(v << 16); }

// index (in bf16 units) of element k of batch column n inside a B-fragment buffer of `stride` entries per kstep
// smem layout: [kstep][lane = 4n + t][slot]; global compact layout: [n][kstep][t][slot]
__device__ __forceinline__ int frag_slot(int k) { return (k & 1) + 2 * ((k >> 3) & 1); }
__device__ __forceinline__ int frag_t(int k) { return (k & 7) >> 1; }
__device__ __forceinline__ int sx_index(int k, int n) { return (((k >> 4) * 32 + 4 * n + frag_t(k)) << 2) + frag_slot(k); }
__device__ __forceinline__ size_t gfrag_index(int k, int n, int ksteps) { return ((((size_t)n * ksteps + (k >> 4)) * 4 + frag_t(k)) << 2) + frag_slot(k); }

__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
__device__ __forceinline__ float warp_max(float v) {
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 16));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 8));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 4));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 2));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 1));
  return v;
}

// ---------------------------------------------------------------------------------------------------------
// entries: put the bf16 input of a matvec into shared memory as MMA B-fragments
// ---------------------------------------------------------------------------------------------------------

// x = embedding row (bf16 -> f32); also publishes the input of the first RMSNorm+matvec:
// fragments of bf16(w * x) and per-tile partial sums of x^2 (the 1/rms factor is applied to matvec OUTPUTS)
// gs < 0: step(): token = tokens[b]. gs >= 0: generate() step gs: token = tokens[b] for gs == 0, otherwise the
// argmax of the previous step's logits (reduced over the per-block maxima, ties -> lowest row, like torch.argmax),
// which is also stored as output token gs-1. embed == 0: only the argmax (after the last step).
__device__ __noinline__ void op_embed(unsigned char* smem, int gs, int embed) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const int b = blockIdx.x, tid = threadIdx.x, lane = tid & 31;
  if (b < P.B) {
    long long tok;
    if (gs <= 0) {
      tok = P.tokens[b];
    } else {
      int* stok = (int*)(smem + SCR_OFF);
      if (tid < 32) {
        const int nb = NWORK;
        float bv = -__int_as_float(0x7f800000); int bidx = 0x7fffffff;
        for (int i = lane; i < nb; i += 32) {
          float v = __ldcg(P.bm_val + b * nb + i); int ix = __ldcg(P.bm_idx + b * nb + i);
          if (v > bv || (v == bv && ix < bidx)) { bv = v; bidx = ix; }
        }
#pragma unroll
        for (int o = 16; o > 0; o >>= 1) {
          float v = __shfl_xor_sync(0xffffffffu, bv, o); int ix = __shfl_xor_sync(0xffffffffu, bidx, o);
          if (v > bv || (v == bv && ix < bidx)) { bv = v; bidx = ix; }
        }
        if (lane == 0) { stok[0] = bidx; P.gen_out[(size_t)b * P.n_steps + gs - 1] = bidx; __threadfence(); }
      }
      __syncthreads();
      tok = stok[0];
    }
    if (embed) {
      const uint2* e = (const uint2*)(P.embed + (size_t)tok * H);
      uint2 v = e[tid];
      float4 f = make_float4(bf2f(v.x & 0xffffu), bf2f(v.x >> 16), bf2f(v.y & 0xffffu), bf2f(v.y >> 16));
      ((float4*)(P.xres + (size_t)b * H))[tid] = f;
      float4 wv = ((const float4*)P.norm_w)[tid];
      const int k = tid * 4;
      P.xfrag[gfrag_index(k + 0, b, KS_H)] = f2bf(wv.x * f.x);
      P.xfrag[gfrag_index(k + 1, b, KS_H)] = f2bf(wv.y * f.y);
      P.xfrag[gfrag_index(k + 2, b, KS_H)] = f2bf(wv.z * f.z);
      P.xfrag[gfrag_index(k + 3, b, KS_H)] = f2bf(wv.w * f.w);
      float p = (f.x * f.x + f.y * f.y) + (f.z * f.z + f.w * f.w);
      p += __shfl_xor_sync(0xffffffffu, p, 1);
      p += __shfl_xor_sync(0xffffffffu, p, 2);
      if ((tid & 3) == 0) P.ssq[b * 256 + (tid >> 2)] = p;
      __threadfence();
    }
  }
  __syncthreads();
}

// sx <- fragments written to global memory by the previous phase ([n][kstep][4 lanes][4 bf16]).
// NORM: the fragments are bf16(w * x); also compute 1/rms per sequence from the per-tile partial sums
// (fixed order, the same in every block); the matvec epilogue multiplies its outputs by it.
template <int KS, bool NORM>
__device__ __forceinline__ void entry_copy_body(unsigned char* smem, const unsigned short* g TR_PARAM) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  uint4* sx4 = (uint4*)smem;
  const int per = KS * 2, tot = per * P.B;
  // flat index over (sequence, entry) so that the loads are spread over all threads of the block
  for (int i = threadIdx.x; i < tot; i += NTHREAD) {
    int n = i / per, r = i - n * per;
    sx4[(r >> 1) * 16 + 2 * n + (r & 1)] = __ldcg((const uint4*)g + i);
  }
  if (NORM) {
    const int n = threadIdx.x >> 5, lane = threadIdx.x & 31;
    if (n < P.B) {
      const float4* q = (const float4*)(P.ssq + n * 256) + lane * 2;
      float4 a = __ldcg(q), b = __ldcg(q + 1);
      float v = ((a.x + a.y) + (a.z + a.w)) + ((b.x + b.y) + (b.z + b.w));
      v = warp_sum(v);
      if (lane == 0) ((float*)(smem + RN_OFF))[n] = 1.0f / sqrtf(v * (1.0f / H) + 1e-6f);
    }
  }
  __syncthreads();
  TP(0);
}
template <int KS, bool NORM>
__device__ __noinline__ void entry_copy(unsigned char* smem, const unsigned short* g TR_PARAM) {
  entry_copy_body<KS, NORM>(smem, g TR_ARG(tr));
}

// ---------------------------------------------------------------------------------------------------------
// matvec: block team. Block b owns tiles [b*T/nb, (b+1)*T/nb); loader warp w streams ksteps
// [w*ks/NLOAD, (w+1)*ks/NLOAD) of each tile; warp REDW sums the partials in fixed order and runs the epilogue.
// ---------------------------------------------------------------------------------------------------------
enum { EP_QKV = 0, EP_ADD = 1, EP_GU = 2, EP_LM = 3, EP_LMARG = 4 };

// r0, r1: 1/rms of the input norm for the two batch columns of this lane (QKV, GU, LM);
// aux: weight of the NEXT RMSNorm (ADD: the residual add publishes that norm's input)
template <int EP>
__device__ __forceinline__ void epilogue(const Params& P, int tile, int lane, float4 c, float r0, float r1, float w0, float w1, float4 xin) {
  const int g = lane >> 2, t = lane & 3, B = P.B;
  const int n0 = 2 * t, n1 = 2 * t + 1;
  if (EP == EP_QKV) {
    int row = tile * 16 + g;
    if (n0 < B) { P.qkv[(size_t)n0 * QKV_ROWS + row] = c.x * r0; P.qkv[(size_t)n0 * QKV_ROWS + row + 8] = c.z * r0; }
    if (n1 < B) { P.qkv[(size_t)n1 * QKV_ROWS + row] = c.y * r1; P.qkv[(size_t)n1 * QKV_ROWS + row + 8] = c.w * r1; }
  } else if (EP == EP_ADD) {
    // w0, w1: next norm weight of the two rows; xin: residual rows (x: n0,row; y: n0,row+8; z: n1,row; w: n1,row+8),
    // both requested by the coordinator before the tile's barrier
    int row = tile * 16 + g;
    float s0 = 0.f, s1 = 0.f;
    if (n0 < B) {
      float* p = P.xres + (size_t)n0 * H + row;
      float a = xin.x + c.x, b = xin.y + c.z;
      p[0] = a; p[8] = b;
      P.xfrag[gfrag_index(row, n0, KS_H)] = f2bf(w0 * a);
      P.xfrag[gfrag_index(row + 8, n0, KS_H)] = f2bf(w1 * b);
      s0 = a * a + b * b;
    }
    if (n1 < B) {
      float* p = P.xres + (size_t)n1 * H + row;
      float a = xin.z + c.y, b = xin.w + c.w;
      p[0] = a; p[8] = b;
      P.xfrag[gfrag_index(row, n1, KS_H)] = f2bf(w0 * a);
      P.xfrag[gfrag_index(row + 8, n1, KS_H)] = f2bf(w1 * b);
      s1 = a * a + b * b;
    }
    // sum of x^2 over the 16 rows of the tile: lanes with the same t hold the 8 row pairs
    s0 += __shfl_xor_sync(0xffffffffu, s0, 4); s1 += __shfl_xor_sync(0xffffffffu, s1, 4);
    s0 += __shfl_xor_sync(0xffffffffu, s0, 8); s1 += __shfl_xor_sync(0xffffffffu, s1, 8);
    s0 += __shfl_xor_sync(0xffffffffu, s0, 16); s1 += __shfl_xor_sync(0xffffffffu, s1, 16);
    if (g == 0) {
      if (n0 < B) P.ssq[n0 * 256 + tile] = s0;
      if (n1 < B) P.ssq[n1 * 256 + tile] = s1;
    }
  } else if (EP == EP_GU) {
    int j = tile * 8 + g;           // rows 0..7 of the tile are gate[j], rows 8..15 are up[j]
    if (n0 < B) { float gt = c.x * r0; float m = gt / (1.0f + __expf(-gt)) * (c.z * r0); P.mfrag[gfrag_index(j, n0, KS_I)] = f2bf(m); }
    if (n1 < B) { float gt = c.y * r1; float m = gt / (1.0f + __expf(-gt)) * (c.w * r1); P.mfrag[gfrag_index(j, n1, KS_I)] = f2bf(m); }
  } else {
    int row = tile * 16 + g;
    if (n0 < B) { P.logits[(size_t)n0 * VOCAB + row] = c.x * r0; P.logits[(size_t)n0 * VOCAB + row + 8] = c.z * r0; }
    if (n1 < B) { P.logits[(size_t)n1 * VOCAB + row] = c.y * r1; P.logits[(size_t)n1 * VOCAB + row + 8] = c.w * r1; }
  }
}

__device__ __forceinline__ float4 add4(float4 a, float4 b) { return make_float4(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w); }

// KS = ksteps of the matrix (256 or 768); loader warp w streams BASE (+1 for the first EXTRA warps) ksteps
// PRE: this block's first tile was preloaded into shared memory (the `stash`, a 131 KB image of the tile
// behind the K=4096 input fragments)
template <int EP, int KS, bool PRE>
__device__ __forceinline__ void gemv_body(unsigned char* smem, const uint4* W, int tsel, const float* aux TR_PARAM) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const uint2* sx = (const uint2*)smem;
  float4* red = (float4*)(smem + SX_BYTES);
  const int* tb = (const int*)(smem + TB_OFF);
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int t0 = tb[2 * tsel], t1 = tb[2 * tsel + 1];
  enum { BASE = KS / NLOAD, EXTRA = KS % NLOAD };
  const int s0 = w * BASE + min(w, (int)EXTRA);
  const bool extra = w < EXTRA;
  const float* rn = (const float*)(smem + RN_OFF);
  const float r0 = rn[2 * (lane & 3)], r1 = rn[2 * (lane & 3) + 1];
  float bv0 = -__int_as_float(0x7f800000), bv1 = bv0;   // EP_LMARG: running argmax of this lane's rows
  int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
  for (int t = t0; t <= t1; t++) {
    if (w < NLOAD && t < t1) {
      const uint4* p = W + ((size_t)t * KS + s0) * 32 + lane;
      if (PRE && t == t0) p = (const uint4*)(smem + STASH_OFF) + s0 * 32 + lane;
      const uint2* xb = sx + s0 * 32 + lane;
      float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
      for (int j = 0; j < BASE; j += 8) {
        uint4 a[8];
#pragma unroll
        for (int u = 0; u < 8; u++) a[u] = p[(j + u) * 32];
#pragma unroll
        for (int u = 0; u < 8; u++) { uint2 bb = xb[(j + u) * 32]; MMA(c, a[u], bb); }
      }
      if (extra) { uint4 a = p[BASE * 32]; uint2 bb = xb[BASE * 32]; MMA(c, a, bb); }
      red[((t & 1) * 32 + w) * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
    }
    // the coordinator requests the inputs of this tile's epilogue now; they arrive while the loaders stream
    float w0 = 0.f, w1 = 0.f;
    float4 xin = make_float4(0.f, 0.f, 0.f, 0.f);
    if (EP == EP_ADD && w == CW && t < t1) {
      const int row = t * 16 + (lane >> 2), n0 = 2 * (lane & 3), n1 = n0 + 1;
      w0 = aux[row]; w1 = aux[row + 8];
      if (n0 < P.B) { const float* q = P.xres + (size_t)n0 * H + row; xin.x = __ldcg(q); xin.y = __ldcg(q + 8); }
      if (n1 < P.B) { const float* q = P.xres + (size_t)n1 * H + row; xin.z = __ldcg(q); xin.w = __ldcg(q + 8); }
    }
    __syncthreads();
    if (t == t0) TP(1);
    if (t == t1 - 1) TP(2);
    if (w == CW && t < t1) {
      // fixed-order sum of the 31 partials (tree: short dependency chains)
      const float4* r = red + (t & 1) * 32 * 32 + lane;
#define R_(i) r[(i) * 32]
#define S8_(o) add4(add4(add4(R_(o), R_(o + 1)), add4(R_(o + 2), R_(o + 3))), add4(add4(R_(o + 4), R_(o + 5)), add4(R_(o + 6), R_(o + 7))))
      float4 q0 = S8_(0), q1 = S8_(8), q2 = S8_(16);
      float4 q3 = add4(add4(add4(R_(24), R_(25)), add4(R_(26), R_(27))), add4(add4(R_(28), R_(29)), R_(30)));
#undef S8_
#undef R_
      float4 c = add4(add4(q0, q1), add4(q2, q3));
      if (EP == EP_LMARG) {
        // same values as the logits of step(): c * r; rows ascend, so strict > keeps the lowest row among equals
        const int row = t * 16 + (lane >> 2);
        float v;
        v = c.x * r0; if (v > bv0) { bv0 = v; bi0 = row; }
        v = c.z * r0; if (v > bv0) { bv0 = v; bi0 = row + 8; }
        v = c.y * r1; if (v > bv1) { bv1 = v; bi1 = row; }
        v = c.w * r1; if (v > bv1) { bv1 = v; bi1 = row + 8; }
        if (t == t1 - 1) {
#pragma unroll
          for (int o = 16; o >= 4; o >>= 1) {
            float u = __shfl_xor_sync(0xffffffffu, bv0, o); int ix = __shfl_xor_sync(0xffffffffu, bi0, o);
            if (u > bv0 || (u == bv0 && ix < bi0)) { bv0 = u; bi0 = ix; }
            u = __shfl_xor_sync(0xffffffffu, bv1, o); ix = __shfl_xor_sync(0xffffffffu, bi1, o);
            if (u > bv1 || (u == bv1 && ix < bi1)) { bv1 = u; bi1 = ix; }
          }
          if (lane < 4) {
            const int n0 = 2 * lane, n1 = 2 * lane + 1, nb = NWORK, b = blockIdx.x;
            if (n0 < P.B) { P.bm_val[n0 * nb + b] = bv0; P.bm_idx[n0 * nb + b] = bi0; }
            if (n1 < P.B) { P.bm_val[n1 * nb + b] = bv1; P.bm_idx[n1 * nb + b] = bi1; }
          }
        }
      } else {
        epilogue<EP>(P, t, lane, c, r0, r1, w0, w1, xin);
      }
      if (t == t1 - 1) __threadfence();
      if (t == t1 - 1) TP(3);
    }
  }
}
template <int EP, int KS>
__device__ __noinline__ void gemv(unsigned char* smem, const uint4* W, int tsel, const float* aux TR_PARAM) {
  gemv_body<EP, KS, false>(smem, W, tsel, aux TR_ARG(tr));
}

// touch the weights this block will stream in a later phase (same warps, same addresses), so that they sit
// in L2 when the phase starts; used by blocks that would otherwise idle
template <int KS>
__device__ __forceinline__ void prefetch(unsigned char* smem, const uint4* W, int tsel) {
  const int* tb = (const int*)(smem + TB_OFF);
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  if (w >= NLOAD) return;
  const int t0 = tb[2 * tsel], t1 = tb[2 * tsel + 1];
  enum { BASE = KS / NLOAD, EXTRA = KS % NLOAD };
  const int s0 = w * BASE + min(w, (int)EXTRA);
  unsigned acc = 0;
  for (int t = t0 + 1; t < t1; t++) {   // the first tile is preloaded into registers
    const uint4* p = W + ((size_t)t * KS + s0) * 32 + lane;
#pragma unroll
    for (int u = 0; u < BASE; u++) { uint4 a = p[u * 32]; acc ^= a.x ^ a.y ^ a.z ^ a.w; }
    if (w < EXTRA) { uint4 a = p[BASE * 32]; acc ^= a.x ^ a.y ^ a.z ^ a.w; }
  }
  if (acc == 0x9e3779b9u) ((unsigned*)(smem + SCR_OFF))[lane] = acc;   // keeps the loads alive
}

// ---------------------------------------------------------------------------------------------------------
// attention: block b < 8B handles (sequence n = b/8, kv head g = b%8): q/k norms, RoPE, append K/V,
// scores (MMA over the K cache), softmax, weighted V sum (MMA over the V cache)
// ---------------------------------------------------------------------------------------------------------
__device__ __forceinline__ void attention_body(unsigned char* smem, int layer TR_PARAM) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const int b = blockIdx.x, B = P.B;
  const int n = b >> 3, g = b & 7;
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int pos = P.pos, T = pos + 1, nt = (T + 15) >> 4, NTP = nt * 16;
  float* y = (float*)(smem + ATT_OFF_BYTES);                 // [5][128]
  unsigned short* qfrag16 = (unsigned short*)(y + 768);      // [8][32][4]
  const uint2* qfrag = (const uint2*)qfrag16;
  float* sc = (float*)(qfrag16 + 8 * 32 * 4);                // [4][NTP]
  unsigned short* pfrag16 = (unsigned short*)(sc + 4 * NTP); // [nt][32][4]
  const uint2* pfrag = (const uint2*)pfrag16;
  float* scr = (float*)(smem + SCR_OFF);
  float4* red = (float4*)(smem + SX_BYTES);
  uint4* Kc = P.kc + (((size_t)layer * MAXB + n) * 8 + g) * P.kv_stride;
  uint4* Vc = P.vc + (((size_t)layer * MAXB + n) * 8 + g) * P.kv_stride;

  // ---- step 1: q (4 heads), k, v of the new token
  const int vec = tid >> 7, d = tid & 127;   // vec 0..3: q heads, 4: k, 5: v
  float x = 0.f, yv = 0.f;
  if (vec < 6) {
    int row = vec < 4 ? ((4 * g + vec) * 128 + d) : (vec == 4 ? 4096 + g * 128 + d : 5120 + g * 128 + d);
    x = __ldcg(P.qkv + (size_t)n * QKV_ROWS + row);
    if (vec < 5) { float p = warp_sum(x * x); if (lane == 0) scr[w] = p; }
  }
  __syncthreads();
  if (vec < 5) {
    float ss = scr[4 * vec] + scr[4 * vec + 1] + scr[4 * vec + 2] + scr[4 * vec + 3];
    float r = 1.0f / sqrtf(ss * (1.0f / 128) + 1e-6f);
    yv = P.qk_norm_w[(layer * 2 + (vec < 4 ? 0 : 1)) * 128 + d] * (x * r);
    y[vec * 128 + d] = yv;
  }
  __syncthreads();
  if (vec < 5) {
    float cs = P.rope[(size_t)pos * 128 + (d & 63)], sn = P.rope[(size_t)pos * 128 + 64 + (d & 63)];
    float other = y[vec * 128 + (d ^ 64)];
    float o = d < 64 ? yv * cs - other * sn : yv * cs + other * sn;
    unsigned short ob = f2bf(o);
    if (vec < 4) {
      qfrag16[(((d >> 4) * 32 + 4 * vec + frag_t(d)) << 2) + frag_slot(d)] = ob;
    } else {
      int m = pos & 15, kcol = d & 15;
      int ln = (m & 7) * 4 + ((kcol & 7) >> 1), el = (kcol >> 3) * 4 + (m >> 3) * 2 + (kcol & 1);
      ((unsigned short*)Kc)[((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ln) << 3) + el] = ob;
    }
  } else if (vec == 5) {
    int kcol = pos & 15, m = d & 15;
    int ln = (m & 7) * 4 + ((kcol & 7) >> 1), el = (kcol >> 3) * 4 + (m >> 3) * 2 + (kcol & 1);
    ((unsigned short*)Vc)[((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ln) << 3) + el] = f2bf(x);
  }
  __threadfence();
  __syncthreads();

  // ---- step 2: scores[h][j] = q_h . K_j / sqrt(128)
  for (int tile = w; tile < nt; tile += NWARP) {
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    const uint4* p = Kc + (size_t)tile * 256 + lane;
#pragma unroll
    for (int s = 0; s < 8; s++) {
      uint4 a = __ldcg(p + s * 32);
      uint2 bq = make_uint2(0, 0);
      if (lane < 16) bq = qfrag[s * 32 + lane];
      MMA(c, a, bq);
    }
    int t = lane & 3, j = tile * 16 + (lane >> 2);
    if (t < 2) {
      const float scale = 0.08838834764831845f;
      const float ninf = -__int_as_float(0x7f800000);
      sc[(2 * t) * NTP + j] = j < T ? c[0] * scale : ninf;
      sc[(2 * t + 1) * NTP + j] = j < T ? c[1] * scale : ninf;
      sc[(2 * t) * NTP + j + 8] = j + 8 < T ? c[2] * scale : ninf;
      sc[(2 * t + 1) * NTP + j + 8] = j + 8 < T ? c[3] * scale : ninf;
    }
  }
  __syncthreads();

  // ---- step 3: softmax per head; warp w: head w&3, slice w>>2 of 8
  {
    const int h = w & 3, r = w >> 2;
    const float* s = sc + h * NTP;
    float mx = -__int_as_float(0x7f800000);
    for (int j = r + 8 * lane; j < NTP; j += 256) mx = fmaxf(mx, s[j]);
    mx = warp_max(mx);
    if (lane == 0) scr[w] = mx;
    __syncthreads();
    mx = scr[h];
    for (int i = 1; i < 8; i++) mx = fmaxf(mx, scr[h + 4 * i]);
    float sum = 0.f;
    for (int j = r + 8 * lane; j < NTP; j += 256) { float e = __expf(s[j] - mx); sc[h * NTP + j] = e; sum += e; }
    sum = warp_sum(sum);
    if (lane == 0) scr[32 + w] = sum;
    __syncthreads();
    float Z = scr[32 + h];
    for (int i = 1; i < 8; i++) Z += scr[32 + h + 4 * i];
    for (int j = r + 8 * lane; j < NTP; j += 256) {
      float p = s[j] / Z;
      pfrag16[(((j >> 4) * 32 + 4 * h + frag_t(j)) << 2) + frag_slot(j)] = f2bf(p);
    }
    __syncthreads();
  }

  // ---- step 4: out[h][d] = sum_j p[h][j] V[j][d]; warp w: dim tile w&7, kstep segment w>>3 of 4
  {
    const int dt = w & 7, r = w >> 3;
    const int s0 = r * nt / 4, s1 = (r + 1) * nt / 4;
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    for (int s = s0; s < s1; s++) {
      uint4 a = __ldcg(Vc + ((size_t)s * 8 + dt) * 32 + lane);
      uint2 bp = make_uint2(0, 0);
      if (lane < 16) bp = pfrag[s * 32 + lane];
      MMA(c, a, bp);
    }
    red[w * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
    __syncthreads();
    if (w < 8) {
      float4 v = red[w * 32 + lane];
      for (int i = 1; i < 4; i++) { float4 u = red[(w + 8 * i) * 32 + lane]; v.x += u.x; v.y += u.y; v.z += u.z; v.w += u.w; }
      int t = lane & 3, m = lane >> 2;
      if (t < 2) {
        int base0 = (4 * g + 2 * t) * 128 + dt * 16 + m, base1 = (4 * g + 2 * t + 1) * 128 + dt * 16 + m;
        P.afrag[gfrag_index(base0, n, KS_H)] = f2bf(v.x);
        P.afrag[gfrag_index(base1, n, KS_H)] = f2bf(v.y);
        P.afrag[gfrag_index(base0 + 8, n, KS_H)] = f2bf(v.z);
        P.afrag[gfrag_index(base1 + 8, n, KS_H)] = f2bf(v.w);
      }
      __threadfence();
    }
    __syncthreads();
  }
}

// grid-wide barrier: every block adds one to a counter, then waits until all have (132 blocks: 0.54 us when all
// arrive together; a per-block flag variant measured slower). Every operator ends with its global stores
// fenced and a block barrier, so only the coordinator thread touches the counter.
__device__ __forceinline__ void barrier(const Params& P, unsigned idx TR_PARAM) {
  if (threadIdx.x == CW * 32) {
    atomicAdd(P.sync, 1u);
    TP(4);
    unsigned target = P.sync_base + (idx + 1u) * NWORK;
    while ((int)(*(volatile unsigned*)P.sync - target) < 0) {}
    TP(5);
  }
  __syncthreads();
}

// attention and the o projection in ONE function. While the 8B attention blocks work, every other SM would
// idle: its loader warps stream their share of the block's first o tile into shared memory (the 131 KB behind
// the K=4096 input fragments, which only attention blocks and the down projection use), so those bytes cross
// HBM during attention; the o matvec then takes its first tile from there. Attention blocks own a single o
// tile (tile table), the others share the rest.
__device__ __noinline__ void phase_att_o(unsigned char* smem, int l, unsigned bi TR_PARAM) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const uint4* WO = P.W + (size_t)l * LAYER_U4 + OFF_O;
  const float* wnext = P.norm_w + (size_t)(2 * l + 1) * H;
#ifdef TRACE
  const int tr0 = tr;
  tr = tr0 + 1;
#endif
  TP(0);
  if (blockIdx.x < 8 * P.B) {
    attention_body(smem, l TR_ARG(tr));
    TP(3);
    barrier(P, bi TR_ARG(tr));
#ifdef TRACE
    tr = tr0 + 2;
#endif
    entry_copy_body<KS_H, false>(smem, P.afrag TR_ARG(tr));
    gemv_body<EP_ADD, KS_H, false>(smem, WO, T_O, wnext TR_ARG(tr));
  } else {
#ifndef NO_PRELOAD_O
    {
      const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
      enum { BASE = KS_H / NLOAD, EXTRA = KS_H % NLOAD };
      if (w < NLOAD) {
        const int s0 = w * BASE + min(w, (int)EXTRA);
        const uint4* p = WO + ((size_t)((const int*)(smem + TB_OFF))[2 * T_O] * KS_H + s0) * 32 + lane;
        uint4* st = (uint4*)(smem + STASH_OFF) + s0 * 32 + lane;
        uint4 a[8];
#pragma unroll
        for (int u = 0; u < 8; u++) a[u] = p[u * 32];
#pragma unroll
        for (int u = 0; u < 8; u++) st[u * 32] = a[u];
        if (w < EXTRA) st[BASE * 32] = p[BASE * 32];
      }
    }
#endif
#ifdef TOUCH_O
    prefetch<KS_H>(smem, WO, T_O);
#endif
    TP(3);
    barrier(P, bi TR_ARG(tr));
#ifdef TRACE
    tr = tr0 + 2;
#endif
    entry_copy_body<KS_H, false>(smem, P.afrag TR_ARG(tr));
#ifndef NO_PRELOAD_O
    gemv_body<EP_ADD, KS_H, true>(smem, WO, T_O, wnext TR_ARG(tr));
#else
    gemv_body<EP_ADD, KS_H, false>(smem, WO, T_O, wnext TR_ARG(tr));
#endif
  }
}

// ---------------------------------------------------------------------------------------------------------
// the kernel: the whole decode step in one launch
// ---------------------------------------------------------------------------------------------------------

__device__ __forceinline__ void kernel_init(unsigned char* smem, const Params& Pk) {
  uint4* sx4 = (uint4*)smem;
  for (int i = threadIdx.x; i < SX_BYTES / 16; i += NTHREAD) sx4[i] = make_uint4(0, 0, 0, 0);
  const unsigned* src = (const unsigned*)&Pk;
  if (threadIdx.x < sizeof(Params) / 4) ((unsigned*)(smem + MISC_OFF))[threadIdx.x] = src[threadIdx.x];
  if (threadIdx.x < 8) ((int*)(smem + TB_OFF))[threadIdx.x] = Pk.tiles[blockIdx.x * 8 + threadIdx.x];
  if (threadIdx.x < 2) ((int*)(smem + TBO_OFF))[threadIdx.x] = Pk.tiles_o[((Pk.B - 1) * Pk.nwork + blockIdx.x) * 2 + threadIdx.x];
  __syncthreads();
}

// the 36 layers and the final norm entry; everything between the embedding and the lm_head matvec
__device__ __forceinline__ void layers(unsigned char* smem, unsigned& bi) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  for (int l = 0; l < NL; l++) {
    const uint4* WL = P.W + (size_t)l * LAYER_U4;
#ifdef TRACE
    const int trl = (l == TRACE_LAYER) ? 0 : -100;
#endif
    entry_copy<KS_H, true>(smem, P.xfrag TR_ARG(trl + 0));
    gemv<EP_QKV, KS_H>(smem, WL + OFF_QKV, T_QKV, nullptr TR_ARG(trl + 0)); barrier(P, bi++ TR_ARG(trl + 0));
    phase_att_o(smem, l, bi++ TR_ARG(trl)); barrier(P, bi++ TR_ARG(trl + 2));
    entry_copy<KS_H, true>(smem, P.xfrag TR_ARG(trl + 3));
    gemv<EP_GU, KS_H>(smem, WL + OFF_GU, T_GU, nullptr TR_ARG(trl + 3)); barrier(P, bi++ TR_ARG(trl + 3));
    entry_copy<KS_I, false>(smem, P.mfrag TR_ARG(trl + 4));
    gemv<EP_ADD, KS_I>(smem, WL + OFF_DN, T_DN, P.norm_w + (size_t)(2 * l + 2) * H TR_ARG(trl + 4)); barrier(P, bi++ TR_ARG(trl + 4));
  }
  entry_copy<KS_H, true>(smem, P.xfrag TR_ARG(-100));
}

// one decode step per launch: logits out
__global__ void k_step(Params Pk) {
  extern __shared__ __align__(16) unsigned char smem[];
#ifdef TRACE
  if (blockIdx.x == Pk.nwork) {   // the clock
    if (threadIdx.x == 0) {
      const unsigned stop = Pk.sync_base + (unsigned)(BARRIERS_PER_STEP + 1) * Pk.nwork;
      unsigned c = 0;
      for (;;) {
        c++;
        *(volatile unsigned*)Pk.clk = c;
        if ((c & 255u) == 0 && (int)(*(volatile unsigned*)Pk.sync - stop) >= 0) break;
      }
    }
    return;
  }
#endif
  kernel_init(smem, Pk);
  const Params& P = *(const Params*)(smem + MISC_OFF);
  unsigned bi = 0;
  op_embed(smem, -1, 1); barrier(P, bi++ TR_ARG(-100));
  layers(smem, bi);
  gemv<EP_LM, KS_H>(smem, P.W + (size_t)NL * LAYER_U4, T_LM, nullptr TR_ARG(-100));
#ifdef TRACE
  if (threadIdx.x == 0) atomicAdd(P.sync, 1u);   // one more count per block: lets the clock block stop
#endif
}

// greedy generation: n_steps decode steps in one launch; argmax, token feedback and the loop are on the device
__global__ void k_generate(Params Pk) {
  extern __shared__ __align__(16) unsigned char smem[];
  kernel_init(smem, Pk);
  Params& P = *(Params*)(smem + MISC_OFF);
  const int n_steps = Pk.n_steps, pos0 = Pk.pos;
  unsigned bi = 0;
  for (int s = 0; s < n_steps; s++) {
    if (threadIdx.x == 0) P.pos = pos0 + s;
    __syncthreads();
    op_embed(smem, s, 1); barrier(P, bi++ TR_ARG(-100));
    layers(smem, bi);
    gemv<EP_LMARG, KS_H>(smem, P.W + (size_t)NL * LAYER_U4, T_LM, nullptr TR_ARG(-100)); barrier(P, bi++ TR_ARG(-100));
  }
  op_embed(smem, n_steps, 0);
}

#ifdef BENCH_LM
// lm_head streaming benchmark. V=0: the engine's matvec. V=1: no reduce/epilogue (per-tile block barrier kept).
// V=2: no block barrier either (each warp free-runs over its K slice of the block's tiles; partials dropped).
// V=3: like 2 but warps take whole tiles (16 rows x all K) round-robin: the microbenchmark pattern.
template <int V>
__global__ void k_lm(Params Pk) {
  extern __shared__ __align__(16) unsigned char smem[];
  kernel_init(smem, Pk);
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const uint4* W = P.W + (size_t)NL * LAYER_U4;
  if (V == 0) { gemv<EP_LM, KS_H>(smem, W, T_LM, nullptr TR_ARG(-100)); return; }
  const uint2* sx = (const uint2*)smem;
  float4* red = (float4*)(smem + SX_BYTES);
  const int* tb = (const int*)(smem + TB_OFF);
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int t0 = tb[2 * T_LM], t1 = tb[2 * T_LM + 1];
  enum { KS = KS_H, BASE = KS / NLOAD, EXTRA = KS % NLOAD };
  const int s0 = w * BASE + min(w, (int)EXTRA);
  float acc = 0.f;
  if (V == 3) {
    for (int t = t0 + w; t < t1; t += NWARP) {
      const uint4* p = W + (size_t)t * KS * 32 + lane;
      float c[4] = {0.f, 0.f, 0.f, 0.f};
      for (int s = 0; s < KS; s += 8) {
        uint4 a[8];
#pragma unroll
        for (int u = 0; u < 8; u++) a[u] = p[(s + u) * 32];
#pragma unroll
        for (int u = 0; u < 8; u++) { uint2 bb = sx[(s + u) * 32 + lane]; MMA(c, a[u], bb); }
      }
      acc += c[0] + c[1] + c[2] + c[3];
    }
  } else {
    for (int t = t0; t < t1; t++) {
      if (w < NLOAD) {
        const uint4* p = W + ((size_t)t * KS + s0) * 32 + lane;
        const uint2* xb = sx + s0 * 32 + lane;
        float c[4] = {0.f, 0.f, 0.f, 0.f};
        uint4 a[8];
#pragma unroll
        for (int u = 0; u < 8; u++) a[u] = p[u * 32];
#pragma unroll
        for (int u = 0; u < 8; u++) { uint2 bb = xb[u * 32]; MMA(c, a[u], bb); }
        if (w < EXTRA) { uint4 a1 = p[BASE * 32]; uint2 bb = xb[BASE * 32]; MMA(c, a1, bb); }
        if (V == 1) red[((t & 1) * 32 + w) * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
        else acc += c[0] + c[1] + c[2] + c[3];
      }
      if (V == 1) __syncthreads();
    }
  }
  if (acc == 1.2345f) P.logits[tid] = acc;
}
#endif

// ---------------------------------------------------------------------------------------------------------
// host API
// ---------------------------------------------------------------------------------------------------------
struct Engine {
  Params P;
  int nsm, max_batch, max_ctx;
  long long launches, steps, errors;
};

#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "CUDA error %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); abort(); } } while (0)

extern "C" {

void* mk_create(int max_batch, int max_ctx, const void* W, const void* embed, const void* norm_w, const void* qk_norm_w, const void* rope) {
  if (max_batch > MAXB || max_ctx > MAX_CTX_SMEM) { fprintf(stderr, "mk_create: unsupported max_batch %d / max_ctx %d\n", max_batch, max_ctx); return nullptr; }
  Engine* E = new Engine();
  memset(E, 0, sizeof(Engine));
  int dev = 0; CK(cudaGetDevice(&dev));
  cudaDeviceProp prop; CK(cudaGetDeviceProperties(&prop, dev));
  E->nsm = prop.multiProcessorCount;
  E->max_batch = max_batch; E->max_ctx = max_ctx;
  Params& P = E->P;
  P.W = (const uint4*)W; P.embed = (const unsigned short*)embed; P.norm_w = (const float*)norm_w;
  P.qk_norm_w = (const float*)qk_norm_w; P.rope = (const float*)rope;
  size_t ctx_tiles = (max_ctx + 15) / 16;
  P.kv_stride = ctx_tiles * 256;
  size_t kv_bytes = (size_t)NL * MAXB * 8 * P.kv_stride * 16;
  CK(cudaMalloc(&P.xres, sizeof(float) * MAXB * H));
  CK(cudaMalloc(&P.qkv, sizeof(float) * MAXB * QKV_ROWS));
  CK(cudaMalloc(&P.afrag, 2 * MAXB * H));
  CK(cudaMalloc(&P.mfrag, 2 * MAXB * INNER));
  CK(cudaMalloc(&P.xfrag, 2 * MAXB * H));
  CK(cudaMalloc(&P.ssq, sizeof(float) * MAXB * 256));
  CK(cudaMemset(P.xfrag, 0, 2 * MAXB * H));
  CK(cudaMemset(P.ssq, 0, sizeof(float) * MAXB * 256));
  CK(cudaMalloc(&P.kc, kv_bytes));
  CK(cudaMalloc(&P.vc, kv_bytes));
  CK(cudaMalloc(&P.sync, 64));
  CK(cudaMalloc(&P.flags, 256)); CK(cudaMemset(P.flags, 0, 256));
  CK(cudaMalloc(&P.bm_val, sizeof(float) * MAXB * E->nsm));
  CK(cudaMalloc(&P.bm_idx, sizeof(int) * MAXB * E->nsm));
  {
#ifdef TRACE
    int nb = E->nsm - 1;
#else
    int nb = E->nsm;
#endif
    P.nwork = nb;
    CK(cudaMalloc(&P.clk, 64)); CK(cudaMemset(P.clk, 0, 64));
    CK(cudaMalloc(&P.trace, sizeof(unsigned) * 64 * 256)); CK(cudaMemset(P.trace, 0, sizeof(unsigned) * 64 * 256));
    int* tb = new int[nb * 8];
    const int nt[4] = {QKV_T, O_T, GU_T, LM_T};
    for (int b = 0; b < nb; b++) for (int k = 0; k < 4; k++) {
      tb[b * 8 + 2 * k] = (int)((long long)b * nt[k] / nb); tb[b * 8 + 2 * k + 1] = (int)((long long)(b + 1) * nt[k] / nb);
    }
    int* d; CK(cudaMalloc(&d, sizeof(int) * nb * 8)); CK(cudaMemcpy(d, tb, sizeof(int) * nb * 8, cudaMemcpyHostToDevice));
    P.tiles = d; delete[] tb;
    // o projection: blocks 0..8B-1 are busy with attention while the others preload, so (O_ATT_TILES=1) the
    // attention blocks own one o tile each and the other blocks share the rest evenly
    int* to = new int[MAXB * nb * 2];
    for (int B = 1; B <= MAXB; B++) {
      int A = 8 * B < nb ? 8 * B : nb, N = nb - A;
      int cnt[1024];
#ifdef O_EVEN
      for (int b = 0; b < nb; b++) cnt[b] = (int)((long long)(b + 1) * O_T / nb) - (int)((long long)b * O_T / nb);
      (void)A; (void)N;
#else
      int rest = O_T - A;
      for (int b = 0; b < A; b++) cnt[b] = 1;
      for (int b = A; b < nb; b++) cnt[b] = (int)((long long)(b - A + 1) * rest / N) - (int)((long long)(b - A) * rest / N);
#endif
      int t = 0;
      for (int b = 0; b < nb; b++) {
        if (cnt[b] < 1) { fprintf(stderr, "mk_create: block without o tiles\n"); abort(); }
        to[((B - 1) * nb + b) * 2] = t; t += cnt[b]; to[((B - 1) * nb + b) * 2 + 1] = t;
      }
      if (t != O_T) { fprintf(stderr, "mk_create: o tile table broken\n"); abort(); }
    }
    CK(cudaMalloc(&d, sizeof(int) * MAXB * nb * 2)); CK(cudaMemcpy(d, to, sizeof(int) * MAXB * nb * 2, cudaMemcpyHostToDevice));
    P.tiles_o = d; delete[] to;
  }
  CK(cudaMemset(P.xres, 0, sizeof(float) * MAXB * H));
  CK(cudaMemset(P.qkv, 0, sizeof(float) * MAXB * QKV_ROWS));
  CK(cudaMemset(P.afrag, 0, 2 * MAXB * H));
  CK(cudaMemset(P.mfrag, 0, 2 * MAXB * INNER));
  CK(cudaMemset(P.kc, 0, kv_bytes));
  CK(cudaMemset(P.vc, 0, kv_bytes));   // V must stay finite: masked positions are multiplied by p = 0
  CK(cudaMemset(P.sync, 0, 64));
  CK(cudaFuncSetAttribute(k_step, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES));
  CK(cudaFuncSetAttribute(k_generate, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES));
  return E;
}

void mk_step(void* h, const void* tokens, void* logits, int B, int pos, int mode) {
  Engine* E = (Engine*)h;
  Params P = E->P;
  P.tokens = (const long long*)tokens; P.logits = (float*)logits; P.B = B; P.pos = pos;
  k_step<<<E->nsm, NTHREAD, SMEM_BYTES>>>(P);
  E->P.sync_base += (unsigned)(BARRIERS_PER_STEP + TRACE_EXTRA) * E->P.nwork;
  E->launches += 1;
  E->steps += 1;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess && E->errors++ < 5) fprintf(stderr, "mk_step: launch error: %s\n", cudaGetErrorString(e));
}

void mk_generate(void* h, const void* tokens, void* out, int B, int pos, int n_steps) {
  Engine* E = (Engine*)h;
  Params P = E->P;
  P.tokens = (const long long*)tokens; P.gen_out = (long long*)out; P.B = B; P.pos = pos; P.n_steps = n_steps;
  k_generate<<<E->nsm, NTHREAD, SMEM_BYTES>>>(P);
  E->P.sync_base += (unsigned)BARRIERS_PER_GEN_STEP * n_steps * E->P.nwork;
  E->launches += 1;
  E->steps += n_steps;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess && E->errors++ < 5) fprintf(stderr, "mk_generate: launch error: %s\n", cudaGetErrorString(e));
}

// TRACE: copy out [blocks][8][8] timestamps and the final clock value
void mk_trace(void* h, unsigned* out, unsigned* clk) {
  Engine* E = (Engine*)h;
  CK(cudaDeviceSynchronize());
  CK(cudaMemcpy(out, E->P.trace, sizeof(unsigned) * 64 * 256, cudaMemcpyDeviceToHost));
  CK(cudaMemcpy(clk, E->P.clk, sizeof(unsigned), cudaMemcpyDeviceToHost));
}

// debug: read the barrier flags while a kernel is running (second stream)
void mk_peek(void* h, unsigned char* flags, unsigned* sync) {
  Engine* E = (Engine*)h;
  static cudaStream_t st = nullptr;
  if (!st) CK(cudaStreamCreateWithFlags(&st, cudaStreamNonBlocking));
  CK(cudaMemcpyAsync(flags, E->P.flags, 256, cudaMemcpyDeviceToHost, st));
  CK(cudaMemcpyAsync(sync, E->P.sync, 4, cudaMemcpyDeviceToHost, st));
  CK(cudaStreamSynchronize(st));
}

// debug: the o tile table of batch size B ([blocks][2])
void mk_tiles_o(void* h, int B, int* out) {
  Engine* E = (Engine*)h;
  CK(cudaDeviceSynchronize());
  CK(cudaMemcpy(out, E->P.tiles_o + (size_t)(B - 1) * E->P.nwork * 2, sizeof(int) * E->P.nwork * 2, cudaMemcpyDeviceToHost));
}

#ifdef BENCH_LM
void mk_bench_lm(void* h, void* logits, int variant) {
  Engine* E = (Engine*)h;
  Params P = E->P;
  P.logits = (float*)logits; P.B = 1; P.pos = 0;
  if (variant == 0) { CK(cudaFuncSetAttribute(k_lm<0>, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES)); k_lm<0><<<E->nsm, NTHREAD, SMEM_BYTES>>>(P); }
  if (variant == 1) { CK(cudaFuncSetAttribute(k_lm<1>, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES)); k_lm<1><<<E->nsm, NTHREAD, SMEM_BYTES>>>(P); }
  if (variant == 2) { CK(cudaFuncSetAttribute(k_lm<2>, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES)); k_lm<2><<<E->nsm, NTHREAD, SMEM_BYTES>>>(P); }
  if (variant == 3) { CK(cudaFuncSetAttribute(k_lm<3>, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES)); k_lm<3><<<E->nsm, NTHREAD, SMEM_BYTES>>>(P); }
  CK(cudaGetLastError());
}
#endif

long long mk_stat(void* h, int which) {
  Engine* E = (Engine*)h;
  return which == 0 ? E->launches : which == 1 ? E->steps : which == 2 ? E->nsm : which == 3 ? E->errors : 0;
}

int mk_check() { cudaError_t e = cudaGetLastError(); if (e != cudaSuccess) fprintf(stderr, "mk_check: %s\n", cudaGetErrorString(e)); return (int)e; }

void mk_destroy(void* h) {
  Engine* E = (Engine*)h;
  cudaDeviceSynchronize();
  Params& P = E->P;
  cudaFree(P.xres); cudaFree(P.qkv); cudaFree(P.afrag); cudaFree(P.mfrag); cudaFree(P.xfrag); cudaFree(P.ssq); cudaFree(P.kc); cudaFree(P.vc); cudaFree(P.sync); cudaFree(P.flags); cudaFree(P.bm_val); cudaFree(P.bm_idx); cudaFree((void*)P.tiles); cudaFree((void*)P.tiles_o);
  delete E;
}

}  // extern "C"
