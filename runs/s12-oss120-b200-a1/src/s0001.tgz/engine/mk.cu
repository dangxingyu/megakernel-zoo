// gpt-oss-120b decode megakernel for one B200 (sm_100a): one persistent cooperative kernel per step / generate call /
// served cohort. 152 blocks (one per SM) x 512 threads.
//
// Every matrix-vector product is a chain of mma.m16n8k16 (bf16 x bf16 -> f32); the 8 columns of the B operand are
// the sequences of the batch. Weights are re-laid at load time (a permutation of the stored bytes, no value change):
//  - BF16 matrices: 512-byte tiles [rowtile][kstep][32 lanes][16 B] in A-fragment order.
//  - MXFP4 experts: per (rowtile, 64-column chunk) 512 B of codes [32 lanes][16 B] (4 mma A fragments of 4 bytes,
//    each byte = 2 e2m1 codes = one bf16x2 register after cvt.rn.bf16x2.e2m1x2) and 32 B of E8M0 scales [8 g][4 B].
//    The scale is applied in float32 to the partial sum of each 32-column group (exact: power of two).
// Phases per layer (v1: grid barrier between phases):
//  A  norm1 + qkv (+bias, bf16, RoPE) -> q buffer, K/V cache
//  B  attention, one block per (sequence, kv head) -> attn
//  C  o_proj (+bias) + residual -> xm
//  D  norm2 (every block) ; router on 8 blocks -> logits
//  E  top-4 (every block) ; gate_up of the union of chosen experts (+bias, swiglu) -> act
//  F  down for owned rows x all chosen experts, weighted sum, residual -> x
// Head: final norm, lm_head -> logits / argmax.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cooperative_groups.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef unsigned u32;
typedef unsigned short u16;
typedef unsigned long long u64;
typedef __nv_bfloat16 bf16;

#define HID 2880
#define NL 36
#define NQH 64
#define NKV 8
#define HD 64
#define QKVR 5120
#define NE 128
#define VOCAB 201088
#define NB 152
#define NT 512
#define NW 16
#define MAXB 8
#define XSH (HID + 8)      // smem row stride (bf16) of a hidden-size vector
#define XSA (4096 + 8)     // smem row stride of the attention output
#define KS_H 180           // ksteps (16) of K=2880
#define KS_A 256           // ksteps of K=4096
#define KC 45              // 64-chunks of K=2880
#define RT_QKV 320
#define RT_O 180
#define RT_GU 360
#define RT_DN 180
#define RT_HEAD 12568
#define NSEG_QKV 8
#define NSEG_O 16
#define NSEG_GU 5
#define NSEG_DN 3
#ifndef ROUTER_BF16
#define ROUTER_BF16 1      // router logits rounded to bf16 before top-4 (as the BF16 path and the general engines do)
#endif

struct LayerP {
  const uint4* wqkv; const float* bqkv;
  const uint4* wo; const float* bo;
  const uint4* wr; const float* br;
  const uint4* gu_c; const u32* gu_s; const float* gu_b;
  const uint4* dn_c; const u32* dn_s; const float* dn_b;
  const float* ln1; const float* ln2; const float* sinks;
  bf16* kc; bf16* vc;
  int sliding;
};

struct Params {
  LayerP L[NL];
  const bf16* embed; const uint4* head; const float* lnf;
  const float* cosT; const float* sinT;     // [maxctx][32] (bf16 values as float)
  bf16 *x, *xm, *q, *attn, *act;           // act: [32 slots][MAXB][HID]
  float* rlog;                              // [MAXB][128]
  float* amv; int* ami;                     // [NB][MAXB]
  u32* bar;                                 // [0] barrier counter, [1] exit counter
  int maxctx;
};

struct RunArgs {
  const long long* tok; int tok_stride;     // mode 0/1: tok[b]; mode 2: tok[b*tok_stride + t] (prompt ids)
  float* logits;                            // mode 0: [B][VOCAB]
  long long* out_tok;                       // mode 1: [B][nsteps]
  int* host_tok; volatile int* host_prog;   // mode 2: host-mapped [B][nsteps] and progress
  int B, pos0, nprompt, nsteps, mode;
};

// ------------------------------------------------------------------------------------------------ primitives
__device__ __forceinline__ void mma16816(float* c, u32 a0, u32 a1, u32 a2, u32 a3, u32 b0, u32 b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3},{%4,%5,%6,%7},{%8,%9},{%0,%1,%2,%3};"
               : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma16816z(float* d, u32 a0, u32 a1, u32 a2, u32 a3, u32 b0, u32 b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3},{%4,%5,%6,%7},{%8,%9},{%10,%10,%10,%10};"
               : "=f"(d[0]), "=f"(d[1]), "=f"(d[2]), "=f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1), "f"(0.f));
}
__device__ __forceinline__ uint4 ldw(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3},[%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ u32 ldw32(const void* p) {
  u32 r; asm volatile("ld.global.nc.L1::no_allocate.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r;
}
// data written by other blocks during this launch: bypass L1
__device__ __forceinline__ u32 ldcg32(const void* p) { u32 r; asm volatile("ld.global.cg.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ float ldcgf(const float* p) { float r; asm volatile("ld.global.cg.f32 %0,[%1];" : "=f"(r) : "l"(p)); return r; }
__device__ __forceinline__ int ldcgi(const int* p) { int r; asm volatile("ld.global.cg.s32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ u16 ldcg16(const void* p) { u16 r; asm volatile("ld.global.cg.u16 %0,[%1];" : "=h"(r) : "l"(p)); return r; }
__device__ __forceinline__ uint4 ldcg128(const void* p) {
  uint4 r; asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3},[%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p)); return r;
}
__device__ __forceinline__ u32 ld_acquire(const u32* p) { u32 r; asm volatile("ld.acquire.gpu.global.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ void cvt4(u32 x, u32& r0, u32& r1, u32& r2, u32& r3) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4; cvt.rn.bf16x2.e2m1x2 %0, b0; cvt.rn.bf16x2.e2m1x2 %1, b1;"
      " cvt.rn.bf16x2.e2m1x2 %2, b2; cvt.rn.bf16x2.e2m1x2 %3, b3; }"
      : "=r"(r0), "=r"(r1), "=r"(r2), "=r"(r3) : "r"(x));
}
__device__ __forceinline__ float bfr(float v) { return __bfloat162float(__float2bfloat16_rn(v)); }
__device__ __forceinline__ float bf2f(bf16 v) { return __bfloat162float(v); }
__device__ __forceinline__ float u16f(u16 v) { return __uint_as_float(((u32)v) << 16); }
__device__ __forceinline__ u16 f2u16(float v) { bf16 h = __float2bfloat16_rn(v); return *reinterpret_cast<u16*>(&h); }
__device__ __forceinline__ float scale_f(u32 s, int k) { return __uint_as_float(((s >> (8 * k)) & 0xffu) << 23); }

__device__ __forceinline__ void grid_bar(u32* ctr, u32& target) {
  __syncthreads();
  target += NB;
  if (threadIdx.x == 0) {
    __threadfence();
    atomicAdd(ctr, 1u);
    while (ld_acquire(ctr) < target) { }
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ GEMV tasks
// C fragment of one task = 16 rows x 8 columns; lane (g,t): c0,c1 = row g cols 2t,2t+1; c2,c3 = row g+8.
// bf16 task: W = rowtile base (tiles of 32 x uint4), ksteps [k0,k1); B from smem xs (row stride xst, B valid columns)
__device__ __forceinline__ void task_bf16(const uint4* W, int k0, int k1, const u16* xs, int xst, bool bval, float* c) {
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const u16* xr = xs + g * xst + 2 * t;
  int k = k0;
  for (; k + 8 <= k1; k += 8) {
    uint4 a[8];
#pragma unroll
    for (int u = 0; u < 8; u++) a[u] = ldw(W + (size_t)(k + u) * 32 + lane);
#pragma unroll
    for (int u = 0; u < 8; u++) {
      u32 b0 = bval ? *(const u32*)(xr + 16 * (k + u)) : 0u;
      u32 b1 = bval ? *(const u32*)(xr + 16 * (k + u) + 8) : 0u;
      mma16816(c, a[u].x, a[u].y, a[u].z, a[u].w, b0, b1);
    }
  }
  if (k < k1) {
    uint4 a[8];
#pragma unroll
    for (int u = 0; u < 8; u++) if (k + u < k1) a[u] = ldw(W + (size_t)(k + u) * 32 + lane);
#pragma unroll
    for (int u = 0; u < 8; u++) if (k + u < k1) {
      u32 b0 = bval ? *(const u32*)(xr + 16 * (k + u)) : 0u;
      u32 b1 = bval ? *(const u32*)(xr + 16 * (k + u) + 8) : 0u;
      mma16816(c, a[u].x, a[u].y, a[u].z, a[u].w, b0, b1);
    }
  }
}

// one 64-column chunk of an MXFP4 rowtile: codes q (16 B of this lane), scale word s (4 B), B fragments b[8]
__device__ __forceinline__ void chunk_fp4(float* c, uint4 q, u32 s, const u32* b) {
  float tacc[4];
  u32 a0, a1, a2, a3;
  // group 0 (columns 0..31 of the chunk): mma j = 0, 1
  cvt4(q.x, a0, a1, a2, a3); mma16816z(tacc, a0, a1, a2, a3, b[0], b[1]);
  cvt4(q.y, a0, a1, a2, a3); mma16816(tacc, a0, a1, a2, a3, b[2], b[3]);
  {
    float sa = scale_f(s, 0), sb = scale_f(s, 2);
    c[0] = fmaf(tacc[0], sa, c[0]); c[1] = fmaf(tacc[1], sa, c[1]);
    c[2] = fmaf(tacc[2], sb, c[2]); c[3] = fmaf(tacc[3], sb, c[3]);
  }
  cvt4(q.z, a0, a1, a2, a3); mma16816z(tacc, a0, a1, a2, a3, b[4], b[5]);
  cvt4(q.w, a0, a1, a2, a3); mma16816(tacc, a0, a1, a2, a3, b[6], b[7]);
  {
    float sa = scale_f(s, 1), sb = scale_f(s, 3);
    c[0] = fmaf(tacc[0], sa, c[0]); c[1] = fmaf(tacc[1], sa, c[1]);
    c[2] = fmaf(tacc[2], sb, c[2]); c[3] = fmaf(tacc[3], sb, c[3]);
  }
}

// MXFP4 task, B from smem: codes rowtile base Cw ([45][32] uint4), scales Sw ([45][8] u32), chunks [c0,c1)
__device__ __forceinline__ void task_fp4_smem(const uint4* Cw, const u32* Sw, int c0, int c1, const u16* xs, int xst, bool bval, float* c) {
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const u16* xr = xs + g * xst + 2 * t;
  for (int k = c0; k < c1; k += 4) {
    uint4 q[4]; u32 s[4];
#pragma unroll
    for (int u = 0; u < 4; u++) if (k + u < c1) { q[u] = ldw(Cw + (size_t)(k + u) * 32 + lane); s[u] = ldw32(Sw + (k + u) * 8 + g); }
#pragma unroll
    for (int u = 0; u < 4; u++) if (k + u < c1) {
      u32 b[8];
#pragma unroll
      for (int j = 0; j < 4; j++) {
        b[2 * j] = bval ? *(const u32*)(xr + 64 * (k + u) + 16 * j) : 0u;
        b[2 * j + 1] = bval ? *(const u32*)(xr + 64 * (k + u) + 16 * j + 8) : 0u;
      }
      chunk_fp4(c, q[u], s[u], b);
    }
  }
}

// MXFP4 task, B from global (act of one slot: [MAXB][HID] bf16), column valid flag per lane
__device__ __forceinline__ void task_fp4_glob(const uint4* Cw, const u32* Sw, int c0, int c1, const u16* act, bool bval, float* c) {
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const u16* xr = act + g * HID + 2 * t;
  for (int k = c0; k < c1; k += 4) {
    uint4 q[4]; u32 s[4]; u32 b[4][8];
#pragma unroll
    for (int u = 0; u < 4; u++) if (k + u < c1) {
      q[u] = ldw(Cw + (size_t)(k + u) * 32 + lane); s[u] = ldw32(Sw + (k + u) * 8 + g);
#pragma unroll
      for (int j = 0; j < 4; j++) {
        b[u][2 * j] = bval ? ldcg32(xr + 64 * (k + u) + 16 * j) : 0u;
        b[u][2 * j + 1] = bval ? ldcg32(xr + 64 * (k + u) + 16 * j + 8) : 0u;
      }
    }
#pragma unroll
    for (int u = 0; u < 4; u++) if (k + u < c1) chunk_fp4(c, q[u], s[u], b[u]);
  }
}

__device__ __forceinline__ void store_task(float* red, int slot, const float* c) {
  const int lane = threadIdx.x & 31;
  *reinterpret_cast<float4*>(red + slot * 128 + lane * 4) = make_float4(c[0], c[1], c[2], c[3]);
}
// element (row i, column b) of a task's 16 x 8 result in red slot
__device__ __forceinline__ float red_at(const float* red, int slot, int i, int b) {
  return red[slot * 128 + ((i & 7) * 4 + (b >> 1)) * 4 + (i >> 3) * 2 + (b & 1)];
}

// ------------------------------------------------------------------------------------------------ norms
// xs[b][k] = bf16(w[k] * (x[b][k] * rsqrt(mean(x^2) + eps))), x read with ld.cg (bf16 [B][HID] at src, or embed rows)
__device__ void norm_to_smem(const bf16* const* rows, int B, const float* w, u16* xs, float* scratch) {
  const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31;
  // sum of squares: warp w handles column b = w (w < B); lanes stride over 2880 in 8-byte pieces
  if (warp < B) {
    const u16* r = reinterpret_cast<const u16*>(rows[warp]);
    float s = 0.f;
    for (int k = lane * 4; k < HID; k += 128) {
      uint2 v; asm volatile("ld.global.cg.v2.u32 {%0,%1},[%2];" : "=r"(v.x), "=r"(v.y) : "l"(r + k));
      float a = __uint_as_float(v.x << 16), b = __uint_as_float(v.x & 0xffff0000u);
      float c = __uint_as_float(v.y << 16), d = __uint_as_float(v.y & 0xffff0000u);
      s += a * a + b * b + c * c + d * d;
    }
#pragma unroll
    for (int o = 16; o; o >>= 1) s += __shfl_xor_sync(0xffffffffu, s, o);
    if (lane == 0) scratch[warp] = rsqrtf(s / (float)HID + 1e-5f);
  }
  __syncthreads();
  for (int i = tid; i < B * (HID / 4); i += NT) {
    int b = i / (HID / 4), k = (i % (HID / 4)) * 4;
    const u16* r = reinterpret_cast<const u16*>(rows[b]);
    uint2 v; asm volatile("ld.global.cg.v2.u32 {%0,%1},[%2];" : "=r"(v.x), "=r"(v.y) : "l"(r + k));
    float ri = scratch[b];
    float4 wv = *reinterpret_cast<const float4*>(w + k);
    u16 o0 = f2u16(wv.x * (__uint_as_float(v.x << 16) * ri));
    u16 o1 = f2u16(wv.y * (__uint_as_float(v.x & 0xffff0000u) * ri));
    u16 o2 = f2u16(wv.z * (__uint_as_float(v.y << 16) * ri));
    u16 o3 = f2u16(wv.w * (__uint_as_float(v.y & 0xffff0000u) * ri));
    *reinterpret_cast<uint2*>(xs + b * XSH + k) = make_uint2(o0 | ((u32)o1 << 16), o2 | ((u32)o3 << 16));
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ smem layout
// [0, 65664)          xs: bf16 [8][4104] (hidden vectors use stride 2888)
// [65664, +40960)     red: float [80][128]
// attention reuses: sc float [8][2048] at 0 (64 KB), ps bf16 [8][2048+16] at 65664 (32.3 KB), ared aliases sc
// small scalars at SM_MISC
#define SM_XS 0
#define SM_RED 65664
#define SM_MISC (65664 + 40960)
#define SM_TOTAL (SM_MISC + 4096)

struct Misc {
  float rinv[MAXB];
  int U;                 // number of chosen experts (union over the batch)
  int sexp[32];          // slot -> expert id (ascending)
  float rw[MAXB][32];    // routing weight of (sequence, slot), 0 if not routed
  u32 smask[32];         // bit b set if sequence b routed to slot
  int tok[MAXB];
  float tmpf[128];
  int tmpi[128];
};

// ------------------------------------------------------------------------------------------------ the kernel
extern "C" __global__ void __launch_bounds__(NT, 1) mk_kernel(const __grid_constant__ Params p, const __grid_constant__ RunArgs a) {
  extern __shared__ __align__(16) unsigned char smem[];
  u16* xs = reinterpret_cast<u16*>(smem + SM_XS);
  float* red = reinterpret_cast<float*>(smem + SM_RED);
  Misc* ms = reinterpret_cast<Misc*>(smem + SM_MISC);
  const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31, g = lane >> 2, t = lane & 3;
  const int bid = blockIdx.x;
  const int B = a.B;
  u32 bar_target = 0;
  u32* bar = p.bar;
  // P = prompt length (mode 0/1: 1); total steps = P + nsteps - 1; step st reads token st of the prompt while
  // st < P, otherwise the argmax of the previous step (= generated token st - P); the head runs for st >= P - 1.
  const int P = (a.mode == 2) ? a.nprompt : 1;
  const int total = P + a.nsteps - 1;

  for (int st = 0; st < total; st++) {
    const int pos = a.pos0 + st;
    if (tid < B) {
      long long tk;
      if (st < P) tk = a.tok[(size_t)tid * a.tok_stride + st];
      else {
        float bv = -INFINITY; int bi = 0x7fffffff;
        for (int k = 0; k < NB; k++) {
          float v = ldcgf(p.amv + k * MAXB + tid); int ix = ldcgi(p.ami + k * MAXB + tid);
          if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
        }
        tk = (bi >= 0 && bi < VOCAB) ? bi : 0;
        if (bid == 0) {
          if (a.mode == 1) a.out_tok[(size_t)tid * a.nsteps + (st - P)] = tk;
          else a.host_tok[tid * a.nsteps + (st - P)] = (int)tk;
        }
      }
      ms->tok[tid] = (int)tk;
    }
    __syncthreads();
    if (a.mode == 2 && bid == 0 && tid == 0 && st > P - 1 + 0 && st >= P) { __threadfence_system(); *a.host_prog = st - P + 1; }

    const bf16* rows_in[MAXB];
    for (int layer = 0; layer < NL; layer++) {
      const LayerP& Lp = p.L[layer];
      // ---------------- phase A: norm1 + qkv
      for (int b = 0; b < MAXB; b++)
        rows_in[b] = (layer == 0) ? p.embed + (size_t)(b < B ? ms->tok[b] : 0) * HID : p.x + b * HID;
      norm_to_smem(rows_in, B, Lp.ln1, xs, ms->rinv);
      {
        const int r0 = bid * RT_QKV / NB, r1 = (bid + 1) * RT_QKV / NB, R = r1 - r0;
        const int ntask = R * NSEG_QKV;
        for (int task = warp; task < ntask; task += NW) {
          int r = task / NSEG_QKV, s = task % NSEG_QKV;
          float c[4] = {0.f, 0.f, 0.f, 0.f};
          task_bf16(Lp.wqkv + (size_t)(r0 + r) * KS_H * 32, s * KS_H / NSEG_QKV, (s + 1) * KS_H / NSEG_QKV, xs, XSH, g < B, c);
          store_task(red, task, c);
        }
        __syncthreads();
        // epilogue: item = (r, i<8, b)
        for (int it = tid; it < R * 8 * B; it += NT) {
          int r = it / (8 * B), i = (it / B) % 8, b = it % B;
          float v1 = 0.f, v2 = 0.f;
          for (int s = 0; s < NSEG_QKV; s++) { v1 += red_at(red, r * NSEG_QKV + s, i, b); v2 += red_at(red, r * NSEG_QKV + s, i + 8, b); }
          int grt = r0 + r;
          v1 = bfr(v1 + Lp.bqkv[grt * 16 + i]);
          v2 = bfr(v2 + Lp.bqkv[grt * 16 + i + 8]);
          if (grt < 288) {     // q or k: rows i, i+8 = dims d, d+32 of one head
            int j = grt & 3, d = 8 * j + i;
            float cs = p.cosT[pos * 32 + d], sn = p.sinT[pos * 32 + d];
            float o1 = bfr(bfr(v1 * cs) - bfr(v2 * sn));
            float o2 = bfr(bfr(v2 * cs) + bfr(v1 * sn));
            if (grt < 256) {
              int h = grt >> 2;
              p.q[(size_t)b * 4096 + h * 64 + d] = __float2bfloat16_rn(o1);
              p.q[(size_t)b * 4096 + h * 64 + d + 32] = __float2bfloat16_rn(o2);
            } else {
              int kvh = (grt - 256) >> 2;
              bf16* kp = Lp.kc + (((size_t)b * NKV + kvh) * p.maxctx + pos) * HD;
              kp[d] = __float2bfloat16_rn(o1); kp[d + 32] = __float2bfloat16_rn(o2);
            }
          } else {
            int kvh = (grt - 288) >> 2, jj = (grt - 288) & 3;
            int d1 = 16 * jj + i, d2 = d1 + 8;
            bf16* vp = Lp.vc + (((size_t)b * NKV + kvh) * (p.maxctx / 16) + pos / 16) * HD * 16;
            vp[d1 * 16 + (pos & 15)] = __float2bfloat16_rn(v1);
            vp[d2 * 16 + (pos & 15)] = __float2bfloat16_rn(v2);
          }
        }
      }
      grid_bar(bar, bar_target);
      // ---------------- phase B: attention, block = (b, kvh)
      if (bid < B * NKV) {
        const int b = bid >> 3, kvh = bid & 7;
        const int lo = Lp.sliding ? max(0, pos - 127) : 0;
        const int n = pos - lo + 1;
        float* sc = reinterpret_cast<float*>(smem);                     // [8][2048]
        u16* ps = reinterpret_cast<u16*>(smem + SM_RED);                // [8][2048+16] (overlaps red, misc untouched)
        u16* qs = reinterpret_cast<u16*>(smem + SM_RED + 8 * 2064 * 2); // [8][72]
        if (tid < 8 * 32) {
          int h = tid >> 5, d = (tid & 31) * 2;
          u32 v = ldcg32(p.q + (size_t)b * 4096 + (kvh * 8 + h) * 64 + d);
          *reinterpret_cast<u32*>(qs + h * 72 + d) = v;
        }
        __syncthreads();
        u32 qa[4][2];
#pragma unroll
        for (int ks = 0; ks < 4; ks++) {
          qa[ks][0] = *reinterpret_cast<const u32*>(qs + g * 72 + 16 * ks + 2 * t);
          qa[ks][1] = *reinterpret_cast<const u32*>(qs + g * 72 + 16 * ks + 2 * t + 8);
        }
        const bf16* kbase = Lp.kc + ((size_t)b * NKV + kvh) * p.maxctx * HD;
        const int ngrp = (n + 7) >> 3;
        for (int gr = warp; gr < ngrp; gr += NW) {
          int key = lo + 8 * gr + g;
          bool valid = key <= pos;
          const u16* kr = reinterpret_cast<const u16*>(kbase + (size_t)(valid ? key : lo) * HD) + 2 * t;
          u32 kb[8];
#pragma unroll
          for (int ks = 0; ks < 4; ks++) { kb[2 * ks] = ldcg32(kr + 16 * ks); kb[2 * ks + 1] = ldcg32(kr + 16 * ks + 8); }
          float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
          for (int ks = 0; ks < 4; ks++) mma16816(c, qa[ks][0], 0u, qa[ks][1], 0u, kb[2 * ks], kb[2 * ks + 1]);
          int j0 = 8 * gr + 2 * t;
          sc[g * 2048 + j0] = (lo + j0 <= pos) ? c[0] * 0.125f : -INFINITY;
          sc[g * 2048 + j0 + 1] = (lo + j0 + 1 <= pos) ? c[1] * 0.125f : -INFINITY;
        }
        __syncthreads();
        // softmax per head (warps 0..7), sink joins the denominator
        if (warp < 8) {
          const int h = warp;
          float sink = Lp.sinks[kvh * 8 + h];
          float m = sink;
          for (int j = lane; j < n; j += 32) m = fmaxf(m, sc[h * 2048 + j]);
#pragma unroll
          for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, o));
          float l = 0.f;
          for (int j = lane; j < n; j += 32) { float e = expf(sc[h * 2048 + j] - m); sc[h * 2048 + j] = e; l += e; }
#pragma unroll
          for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffffu, l, o);
          l += expf(sink - m);
          float il = 1.f / l;
          // P as bf16 at absolute key offset (key - (lo & ~15)) so that 16-key blocks align with the V layout
          const int base = lo & ~15;
          for (int j = lane; j < n; j += 32) ps[h * 2064 + (lo + j - base)] = f2u16(sc[h * 2048 + j] * il);
          // zero the slots before lo in the first block and after pos in the last block
          for (int j = lane; j < 16; j += 32) {
            if (base + j < lo) ps[h * 2064 + j] = 0;
            int e = (pos - base) + 1 + j;   // offset after the last key
            if (e < 2064) ps[h * 2064 + e] = 0;
          }
        }
        __syncthreads();
        // P V: 16-key blocks aligned at multiples of 16 (absolute); warps round-robin; acc[8 dim groups][4]
        {
          const int base = lo & ~15;
          const int nblk = ((pos - base) >> 4) + 1;
          const bf16* vbase = Lp.vc + ((size_t)b * NKV + kvh) * (p.maxctx / 16) * HD * 16;
          float acc[8][4];
#pragma unroll
          for (int nb = 0; nb < 8; nb++) { acc[nb][0] = acc[nb][1] = acc[nb][2] = acc[nb][3] = 0.f; }
          for (int kb = warp; kb < nblk; kb += NW) {
            int blk = (base >> 4) + kb;
            u32 a0 = *reinterpret_cast<const u32*>(ps + g * 2064 + 16 * kb + 2 * t);
            u32 a2 = *reinterpret_cast<const u32*>(ps + g * 2064 + 16 * kb + 2 * t + 8);
            const u16* vb = reinterpret_cast<const u16*>(vbase + (size_t)blk * HD * 16);
#pragma unroll
            for (int nb = 0; nb < 8; nb++) {
              u32 b0 = ldcg32(vb + (8 * nb + g) * 16 + 2 * t);
              u32 b1 = ldcg32(vb + (8 * nb + g) * 16 + 2 * t + 8);
              mma16816(acc[nb], a0, 0u, a2, 0u, b0, b1);
            }
          }
          __syncthreads();   // sc no longer needed: reuse as ared [16 warps][8 heads][64]
          float* ared = sc;
#pragma unroll
          for (int nb = 0; nb < 8; nb++) {
            ared[(warp * 8 + g) * 64 + 8 * nb + 2 * t] = acc[nb][0];
            ared[(warp * 8 + g) * 64 + 8 * nb + 2 * t + 1] = acc[nb][1];
          }
          __syncthreads();
          {
            int h = tid >> 6, d = tid & 63;
            float s = 0.f;
            for (int w = 0; w < NW; w++) s += ared[(w * 8 + h) * 64 + d];
            p.attn[(size_t)b * 4096 + (kvh * 8 + h) * 64 + d] = __float2bfloat16_rn(s);
          }
        }
      }
      grid_bar(bar, bar_target);
      // ---------------- phase C: o_proj + residual
      {
        for (int i = tid; i < B * 1024; i += NT) {
          int b = i >> 10, k = (i & 1023) * 4;
          uint2 v; asm volatile("ld.global.cg.v2.u32 {%0,%1},[%2];" : "=r"(v.x), "=r"(v.y) : "l"(p.attn + (size_t)b * 4096 + k));
          *reinterpret_cast<uint2*>(xs + b * XSA + k) = v;
        }
        __syncthreads();
        const int r0 = bid * RT_O / NB, r1 = (bid + 1) * RT_O / NB, R = r1 - r0;
        const int ntask = R * NSEG_O;
        for (int task = warp; task < ntask; task += NW) {
          int r = task / NSEG_O, s = task % NSEG_O;
          float c[4] = {0.f, 0.f, 0.f, 0.f};
          task_bf16(Lp.wo + (size_t)(r0 + r) * KS_A * 32, s * KS_A / NSEG_O, (s + 1) * KS_A / NSEG_O, xs, XSA, g < B, c);
          store_task(red, task, c);
        }
        __syncthreads();
        for (int it = tid; it < R * 16 * B; it += NT) {
          int r = it / (16 * B), i = (it / B) % 16, b = it % B;
          float v = 0.f;
          for (int s = 0; s < NSEG_O; s++) v += red_at(red, r * NSEG_O + s, i, b);
          int row = (r0 + r) * 16 + i;
          float o = bfr(v + Lp.bo[row]);
          const bf16* xin = (layer == 0) ? p.embed + (size_t)ms->tok[b] * HID : p.x + b * HID;
          float xv = u16f(ldcg16(xin + row));
          p.xm[b * HID + row] = __float2bfloat16_rn(xv + o);
        }
      }
      grid_bar(bar, bar_target);
      // ---------------- phase D: norm2 (all blocks), router (blocks NB-8 .. NB-1)
      for (int b = 0; b < MAXB; b++) rows_in[b] = p.xm + b * HID;
      norm_to_smem(rows_in, B, Lp.ln2, xs, ms->rinv);
      if (bid >= NB - 8) {
        const int rt = bid - (NB - 8);
        // 180 ksteps over 16 warps
        float c[4] = {0.f, 0.f, 0.f, 0.f};
        task_bf16(Lp.wr + (size_t)rt * KS_H * 32, warp * KS_H / NW, (warp + 1) * KS_H / NW, xs, XSH, g < B, c);
        store_task(red, warp, c);
        __syncthreads();
        if (tid < 16 * B) {
          int i = tid / B, b = tid % B;
          float v = 0.f;
          for (int w = 0; w < NW; w++) v += red_at(red, w, i, b);
          v += Lp.br[rt * 16 + i];
#if ROUTER_BF16
          v = bfr(v);
#endif
          p.rlog[b * NE + rt * 16 + i] = v;
        }
      }
      grid_bar(bar, bar_target);
      // ---------------- phase E: top-4 + union (every block), gate_up
      {
        __shared__ int sel[MAXB][4];
        __shared__ float selw[MAXB][4];
        if (warp < B) {
          const int b = warp;
          float v[4]; int ix[4];
#pragma unroll
          for (int k = 0; k < 4; k++) { ix[k] = lane + 32 * k; v[k] = ldcgf(p.rlog + b * NE + ix[k]); }
          float tv[4]; int ti[4];
#pragma unroll
          for (int r = 0; r < 4; r++) {
            float bv = -INFINITY; int bi = 1 << 30;
#pragma unroll
            for (int k = 0; k < 4; k++) if (v[k] > bv || (v[k] == bv && ix[k] < bi)) { bv = v[k]; bi = ix[k]; }
#pragma unroll
            for (int o = 16; o; o >>= 1) {
              float ov = __shfl_xor_sync(0xffffffffu, bv, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
              if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
            }
            tv[r] = bv; ti[r] = bi;
#pragma unroll
            for (int k = 0; k < 4; k++) if (ix[k] == bi) v[k] = -INFINITY;
          }
          if (lane == 0) {
            float e[4], s = 0.f;
#pragma unroll
            for (int r = 0; r < 4; r++) { e[r] = expf(tv[r] - tv[0]); s += e[r]; }
#pragma unroll
            for (int r = 0; r < 4; r++) { sel[b][r] = ti[r]; selw[b][r] = e[r] / s; }
          }
        }
        __syncthreads();
        if (tid == 0) {
          u32 m[4] = {0, 0, 0, 0};
          for (int b = 0; b < B; b++) for (int r = 0; r < 4; r++) m[sel[b][r] >> 5] |= 1u << (sel[b][r] & 31);
          int U = 0;
          for (int w = 0; w < 4; w++) for (int k = 0; k < 32; k++) if (m[w] >> k & 1) ms->sexp[U++] = w * 32 + k;
          ms->U = U;
          for (int s = 0; s < U; s++) {
            ms->smask[s] = 0;
            for (int b = 0; b < MAXB; b++) ms->rw[b][s] = 0.f;
            for (int b = 0; b < B; b++) for (int r = 0; r < 4; r++)
              if (sel[b][r] == ms->sexp[s]) { ms->smask[s] |= 1u << b; ms->rw[b][s] = selw[b][r]; }
          }
        }
        __syncthreads();
        const int U = ms->U;
        const int N = U * RT_GU;
        const int u0 = (int)((long)bid * N / NB), u1 = (int)((long)(bid + 1) * N / NB);
        for (int ub = u0; ub < u1; ub += 16) {
          const int nu = min(16, u1 - ub);
          const int ntask = nu * NSEG_GU;
          for (int task = warp; task < ntask; task += NW) {
            int uu = ub + task / NSEG_GU, s = task % NSEG_GU;
            int slot = uu / RT_GU, rt = uu % RT_GU, e = ms->sexp[slot];
            float c[4] = {0.f, 0.f, 0.f, 0.f};
            const uint4* Cw = Lp.gu_c + ((size_t)e * RT_GU + rt) * KC * 32;
            const u32* Sw = Lp.gu_s + ((size_t)e * RT_GU + rt) * KC * 8;
            task_fp4_smem(Cw, Sw, s * KC / NSEG_GU, (s + 1) * KC / NSEG_GU, xs, XSH, g < B, c);
            store_task(red, task, c);
          }
          __syncthreads();
          // epilogue: item = (unit, pair i<8, b): gate = row 2i, up = row 2i+1
          for (int it = tid; it < nu * 8 * B; it += NT) {
            int ul = it / (8 * B), i = (it / B) % 8, b = it % B;
            int uu = ub + ul, slot = uu / RT_GU, rt = uu % RT_GU, e = ms->sexp[slot];
            if (!(ms->smask[slot] >> b & 1)) continue;
            float gt = 0.f, up = 0.f;
            for (int s = 0; s < NSEG_GU; s++) { gt += red_at(red, ul * NSEG_GU + s, 2 * i, b); up += red_at(red, ul * NSEG_GU + s, 2 * i + 1, b); }
            gt += Lp.gu_b[(size_t)e * 5760 + rt * 16 + 2 * i];
            up += Lp.gu_b[(size_t)e * 5760 + rt * 16 + 2 * i + 1];
            gt = fminf(gt, 7.0f);
            up = fmaxf(fminf(up, 7.0f), -7.0f);
            float glu = gt * (1.0f / (1.0f + expf(-1.702f * gt)));
            float o = (up + 1.0f) * glu;
            p.act[((size_t)slot * MAXB + b) * HID + rt * 8 + i] = __float2bfloat16_rn(o);
          }
          __syncthreads();
        }
      }
      grid_bar(bar, bar_target);
      // ---------------- phase F: down for owned rowtiles x all slots, weighted sum, residual
      {
        const int U = ms->U;
        const int r0 = bid * RT_DN / NB, r1 = (bid + 1) * RT_DN / NB, R = r1 - r0;   // 1 or 2
        float* oacc = reinterpret_cast<float*>(smem + SM_XS);   // [2][16][8] (xs not needed in F)
        for (int i = tid; i < 2 * 16 * 8; i += NT) oacc[i] = 0.f;
        const int N = U * R;   // units ordered slot-major: u -> (slot = u / R, r = u % R)
        for (int ub = 0; ub < N; ub += 16) {
          const int nu = min(16, N - ub);
          const int ntask = nu * NSEG_DN;
          for (int task = warp; task < ntask; task += NW) {
            int uu = ub + task / NSEG_DN, s = task % NSEG_DN;
            int slot = uu / R, r = uu % R, e = ms->sexp[slot];
            float c[4] = {0.f, 0.f, 0.f, 0.f};
            const uint4* Cw = Lp.dn_c + ((size_t)e * RT_DN + r0 + r) * KC * 32;
            const u32* Sw = Lp.dn_s + ((size_t)e * RT_DN + r0 + r) * KC * 8;
            bool bv = (g < B) && (ms->smask[slot] >> g & 1);
            task_fp4_glob(Cw, Sw, s * KC / NSEG_DN, (s + 1) * KC / NSEG_DN,
                          reinterpret_cast<const u16*>(p.act + (size_t)slot * MAXB * HID), bv, c);
            store_task(red, task, c);
          }
          __syncthreads();
          // accumulate in unit order (slot ascending per rowtile): item = (r, i, b)
          for (int it = tid; it < R * 16 * B; it += NT) {
            int r = it / (16 * B), i = (it / B) % 16, b = it % B;
            float acc = oacc[(r * 16 + i) * 8 + b];
            for (int ul = 0; ul < nu; ul++) {
              int uu = ub + ul, slot = uu / R, rr = uu % R;
              if (rr != r || !(ms->smask[slot] >> b & 1)) continue;
              int e = ms->sexp[slot];
              float y = 0.f;
              for (int s = 0; s < NSEG_DN; s++) y += red_at(red, ul * NSEG_DN + s, i, b);
              y += Lp.dn_b[(size_t)e * HID + (r0 + r) * 16 + i];
              acc = fmaf(ms->rw[b][slot], y, acc);
            }
            oacc[(r * 16 + i) * 8 + b] = acc;
          }
          __syncthreads();
        }
        for (int it = tid; it < R * 16 * B; it += NT) {
          int r = it / (16 * B), i = (it / B) % 16, b = it % B;
          int row = (r0 + r) * 16 + i;
          float moe = bfr(oacc[(r * 16 + i) * 8 + b]);
          float xv = u16f(ldcg16(p.xm + b * HID + row));
          p.x[b * HID + row] = __float2bfloat16_rn(xv + moe);
        }
      }
      grid_bar(bar, bar_target);
    }  // layers
    // ---------------- head
    const bool need_head = st >= P - 1;
    if (need_head) {
      for (int b = 0; b < MAXB; b++) rows_in[b] = p.x + b * HID;
      norm_to_smem(rows_in, B, p.lnf, xs, ms->rinv);
      const int r0 = (int)((long)bid * RT_HEAD / NB), r1 = (int)((long)(bid + 1) * RT_HEAD / NB);
      float bv = -INFINITY; int bi = 0x7fffffff;   // this lane's best for column (2t or 2t+1) — tracked per lane below
      float bv2 = -INFINITY; int bi2 = 0x7fffffff;
      for (int rt = r0 + warp; rt < r1; rt += NW) {
        float c[4] = {0.f, 0.f, 0.f, 0.f};
        task_bf16(p.head + (size_t)rt * KS_H * 32, 0, KS_H, xs, XSH, g < B, c);
        int row0 = rt * 16 + g, row1 = row0 + 8;
        int b0 = 2 * t, b1 = 2 * t + 1;
        if (a.mode == 0) {
          if (b0 < B) { a.logits[(size_t)b0 * VOCAB + row0] = c[0]; a.logits[(size_t)b0 * VOCAB + row1] = c[2]; }
          if (b1 < B) { a.logits[(size_t)b1 * VOCAB + row0] = c[1]; a.logits[(size_t)b1 * VOCAB + row1] = c[3]; }
        } else {
          if (c[0] > bv || (c[0] == bv && row0 < bi)) { bv = c[0]; bi = row0; }
          if (c[2] > bv || (c[2] == bv && row1 < bi)) { bv = c[2]; bi = row1; }
          if (c[1] > bv2 || (c[1] == bv2 && row0 < bi2)) { bv2 = c[1]; bi2 = row0; }
          if (c[3] > bv2 || (c[3] == bv2 && row1 < bi2)) { bv2 = c[3]; bi2 = row1; }
        }
      }
      if (a.mode != 0) {
        // reduce over g (lanes with the same t), then over warps
        #pragma unroll
        for (int o = 4; o < 32; o <<= 1) {
          float ov = __shfl_xor_sync(0xffffffffu, bv, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
          if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
          ov = __shfl_xor_sync(0xffffffffu, bv2, o); oi = __shfl_xor_sync(0xffffffffu, bi2, o);
          if (ov > bv2 || (ov == bv2 && oi < bi2)) { bv2 = ov; bi2 = oi; }
        }
        if (g == 0) {
          ms->tmpf[warp * 8 + 2 * t] = bv; ms->tmpi[warp * 8 + 2 * t] = bi;
          ms->tmpf[warp * 8 + 2 * t + 1] = bv2; ms->tmpi[warp * 8 + 2 * t + 1] = bi2;
        }
        __syncthreads();
        if (tid < B) {
          float v = -INFINITY; int ix = 0x7fffffff;
          for (int w = 0; w < NW; w++) {
            float ov = ms->tmpf[w * 8 + tid]; int oi = ms->tmpi[w * 8 + tid];
            if (ov > v || (ov == v && oi < ix)) { v = ov; ix = oi; }
          }
          p.amv[bid * MAXB + tid] = v; p.ami[bid * MAXB + tid] = ix;
        }
      }
      grid_bar(bar, bar_target);
    }
  }  // steps
  // the last token chosen: reduce once more and record
  if (a.mode != 0) {
    if (tid < B) {
      float bv = -INFINITY; int bi = 0x7fffffff;
      for (int k = 0; k < NB; k++) {
        float v = ldcgf(p.amv + k * MAXB + tid); int ix = ldcgi(p.ami + k * MAXB + tid);
        if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
      }
      if (bid == 0) {
        if (a.mode == 1) a.out_tok[tid * a.nsteps + a.nsteps - 1] = bi;
        else a.host_tok[tid * a.nsteps + a.nsteps - 1] = bi;
      }
    }
    __syncthreads();
    if (a.mode == 2 && bid == 0 && tid == 0) { __threadfence_system(); *a.host_prog = a.nsteps; }
  }
  // reset the barrier counter for the next launch: the last block out
  if (tid == 0) {
    __threadfence();
    u32 v = atomicAdd(bar + 1, 1u);
    if (v == NB - 1) { bar[0] = 0; bar[1] = 0; __threadfence(); }
  }
}

// ------------------------------------------------------------------------------------------------ host side
struct Engine {
  Params p;
  int* host_tok; int* host_prog; int* dev_host_tok; int* dev_host_prog;
  int ntok_cap;
  cudaStream_t stream;
};

extern "C" void* mk_create(const void* params) {
  Engine* e = new Engine;
  memcpy(&e->p, params, sizeof(Params));
  if (cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, SM_TOTAL) != cudaSuccess) return nullptr;
  e->ntok_cap = MAXB * 8192;
  cudaHostAlloc(&e->host_tok, e->ntok_cap * sizeof(int), cudaHostAllocMapped);
  cudaHostAlloc(&e->host_prog, 64, cudaHostAllocMapped);
  cudaHostGetDevicePointer(&e->dev_host_tok, e->host_tok, 0);
  cudaHostGetDevicePointer(&e->dev_host_prog, e->host_prog, 0);
  e->stream = 0;
  return e;
}
extern "C" int mk_params_size() { return (int)sizeof(Params); }
extern "C" int mk_layer_size() { return (int)sizeof(LayerP); }

extern "C" int mk_run(void* h, const void* tok, int tok_stride, void* logits, void* out_tok, int B, int pos0, int nprompt, int nsteps, int mode, void* stream) {
  Engine* e = (Engine*)h;
  RunArgs a;
  a.tok = (const long long*)tok; a.tok_stride = tok_stride; a.logits = (float*)logits; a.out_tok = (long long*)out_tok;
  a.host_tok = e->dev_host_tok; a.host_prog = e->dev_host_prog; a.B = B; a.pos0 = pos0; a.nprompt = nprompt; a.nsteps = nsteps; a.mode = mode;
  if (mode == 2) { *(volatile int*)e->host_prog = 0; if (B * nsteps > e->ntok_cap) return -3; }
  void* args[] = {(void*)&e->p, (void*)&a};
  cudaError_t err = cudaLaunchCooperativeKernel((void*)mk_kernel, dim3(NB), dim3(NT), args, SM_TOTAL, (cudaStream_t)stream);
  if (err != cudaSuccess) { fprintf(stderr, "mk_run: %s\n", cudaGetErrorString(err)); return -1; }
  return 0;
}
extern "C" int mk_poll(void* h, int* buf, int B, int nsteps) {
  Engine* e = (Engine*)h;
  int done = *(volatile int*)e->host_prog;
  if (done > 0) memcpy(buf, e->host_tok, sizeof(int) * B * nsteps);
  return done;
}
