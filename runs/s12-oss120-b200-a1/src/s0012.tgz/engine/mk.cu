// gpt-oss-120b decode megakernel for one B200 (sm_100a): one persistent cooperative kernel per step / generate call /
// served cohort. 152 blocks (one per SM) x 512 threads.
//
// Every matrix-vector product is a chain of mma.m16n8k16 (bf16 x bf16 -> f32); the 8 columns of the B operand are
// the sequences of the batch. Weights are re-laid at load time (a permutation of the stored bytes, no value change):
//  - BF16 matrices: 512-byte tiles [rowtile][kstep][32 lanes][16 B] in A-fragment order.
//  - MXFP4 experts: per (rowtile, 64-column chunk) 512 B of codes [32 lanes][16 B] (4 mma A fragments of 4 bytes,
//    each byte = 2 e2m1 codes = one bf16x2 register after cvt.rn.bf16x2.e2m1x2) and 32 B of E8M0 scales [8 g][4 B].
//    The scale is applied in float32 to the partial sum of each 32-column group (exact: power of two).
// Phases per layer (v1: grid barrier between phases):
//  A  norm1 + qkv (+bias, bf16, RoPE) -> q buffer, K/V cache
//  B  attention, one block per (sequence, kv head) -> attn
//  C  o_proj (+bias) + residual -> xm
//  D  norm2 (every block) ; router on 8 blocks -> logits
//  E  top-4 (every block) ; gate_up of the union of chosen experts (+bias, swiglu) -> act
//  F  down for owned rows x all chosen experts, weighted sum, residual -> x
// Head: final norm, lm_head -> logits / argmax.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cooperative_groups.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include "mkprof.cuh"

typedef unsigned u32;
typedef unsigned short u16;
typedef unsigned long long u64;
typedef __nv_bfloat16 bf16;

#define HID 2880
#define NL 36
#define NQH 64
#define NKV 8
#define HD 64
#define QKVR 5120
#define NE 128
#define VOCAB 201088
#define NB 152
#ifndef NT
#define NT 256
#endif
#define NW (NT / 32)
#define MAXB 8
#define XSH (HID + 8)      // smem row stride (bf16) of a hidden-size vector
#define XSA (4096 + 8)     // smem row stride of the attention output
#define KS_H 180           // ksteps (16) of K=2880
#define KS_A 256           // ksteps of K=4096
#define KC 45              // 64-chunks of K=2880
#define RT_QKV 320
#define RT_O 180
#define RT_GU 360
#define RT_DN 180
#define RT_HEAD 12568
#define NSEG_QKV 10
#define NSEG_O 16
#define NSEG_GU 5
#define NSEG_DN 5
#ifndef DA
#define DA 8
#endif
#ifndef DB
#define DB 4
#endif
#ifndef ROUTER_BF16
#define ROUTER_BF16 1      // router logits rounded to bf16 before top-4 (as the BF16 path and the general engines do)
#endif

struct LayerP {
  const uint4* wqkv; const float* bqkv;
  const uint4* wo; const float* bo;
  const uint4* wr; const float* br;
  const uint4* gu_c; const u32* gu_s; const float* gu_b;
  const uint4* dn_c; const u32* dn_s; const float* dn_b;
  const float* ln1; const float* ln2; const float* sinks;
  const u16* ln1b; const u16* ln2b;        // the same norm weights as BF16 (exact: they are stored BF16)
  bf16* kc; bf16* vc;
  int sliding;
};

struct Params {
  LayerP L[NL];
  const bf16* embed; const uint4* head; const float* lnf; const u16* lnfb;
  const float* cosT; const float* sinT;     // [maxctx][32] (bf16 values as float)
  bf16 *x, *xm, *q, *attn, *act;           // act: [32 slots][MAXB][HID]
  float* rlog;                              // [MAXB][128]
  float* ypart;                             // [32 slots][MAXB][HID] down outputs (+bias, unweighted), flat path (B <= 2)
  u32* ecnt;                                // [32] gate_up rowtiles finished per expert slot (grows; reset at exit)
  float* apart;                             // [64 units][32 chunks][8 heads][66] attention partials (acc, m, l)
  u32* acnt;                                // [64] chunks finished per (sequence, kv head); reset by the merging warp
  float* amv; int* ami;                     // [NB][MAXB]
  u32* bar;                                 // [0] barrier counter, [1] exit counter
  int maxctx;
  unsigned long long* prof; unsigned prof_cap;   // mkprof dump (only with -DMKPROF)
  const unsigned char* skel;                // -DSKEL: every weight load reads a 512 KB window here (results wrong)
};

struct RunArgs {
  const long long* tok; int tok_stride;     // mode 0/1: tok[b]; mode 2: tok[b*tok_stride + t] (prompt ids)
  float* logits;                            // mode 0: [B][VOCAB]
  long long* out_tok;                       // mode 1: [B][nsteps]
  int* host_tok; volatile int* host_prog;   // mode 2: host-mapped [B][nsteps] and progress
  int B, pos0, nprompt, nsteps, mode;
};

// ------------------------------------------------------------------------------------------------ primitives
__device__ __forceinline__ void mma16816(float* c, u32 a0, u32 a1, u32 a2, u32 a3, u32 b0, u32 b1) {
  asm("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3},{%4,%5,%6,%7},{%8,%9},{%0,%1,%2,%3};"
               : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma16816z(float* d, u32 a0, u32 a1, u32 a2, u32 a3, u32 b0, u32 b1) {
  asm("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3},{%4,%5,%6,%7},{%8,%9},{%10,%10,%10,%10};"
               : "=f"(d[0]), "=f"(d[1]), "=f"(d[2]), "=f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1), "f"(0.f));
}
#ifdef SKEL
__device__ const unsigned char* g_skel;
#define WP(p) ((const void*)(g_skel + ((uintptr_t)(p) & 0x7FFF0ull)))
#else
#define WP(p) (p)
#endif
__device__ __forceinline__ uint4 ldw(const void* p) {
  p = WP(p);
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3},[%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ u32 ldw32(const void* p) {
  p = WP(p);
  u32 r; asm volatile("ld.global.nc.L1::no_allocate.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r;
}
// data written by other blocks during this launch: bypass L1
__device__ __forceinline__ u32 ldcg32(const void* p) { u32 r; asm volatile("ld.global.cg.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ float ldcgf(const float* p) { float r; asm volatile("ld.global.cg.f32 %0,[%1];" : "=f"(r) : "l"(p)); return r; }
__device__ __forceinline__ int ldcgi(const int* p) { int r; asm volatile("ld.global.cg.s32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ u16 ldcg16(const void* p) { u16 r; asm volatile("ld.global.cg.u16 %0,[%1];" : "=h"(r) : "l"(p)); return r; }
__device__ __forceinline__ uint4 ldcg128(const void* p) {
  uint4 r; asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3},[%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p)); return r;
}
__device__ __forceinline__ u32 ld_acquire(const u32* p) { u32 r; asm volatile("ld.acquire.gpu.global.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ void cvt4(u32 x, u32& r0, u32& r1, u32& r2, u32& r3) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4; cvt.rn.bf16x2.e2m1x2 %0, b0; cvt.rn.bf16x2.e2m1x2 %1, b1;"
      " cvt.rn.bf16x2.e2m1x2 %2, b2; cvt.rn.bf16x2.e2m1x2 %3, b3; }"
      : "=r"(r0), "=r"(r1), "=r"(r2), "=r"(r3) : "r"(x));
}
__device__ __forceinline__ float bfr(float v) { return __bfloat162float(__float2bfloat16_rn(v)); }
__device__ __forceinline__ float bf2f(bf16 v) { return __bfloat162float(v); }
__device__ __forceinline__ float u16f(u16 v) { return __uint_as_float(((u32)v) << 16); }
__device__ __forceinline__ u16 f2u16(float v) { bf16 h = __float2bfloat16_rn(v); return *reinterpret_cast<u16*>(&h); }
__device__ __forceinline__ float scale_f(u32 s, int k) { return __uint_as_float(((s >> (8 * k)) & 0xffu) << 23); }

#define MARK(tag) do { if (threadIdx.x == 0) MKPROF_MARK(prof, pn, tag); } while (0)
__device__ __forceinline__ void grid_bar(u32* ctr, u32& target) {
#ifdef NOBAR
  __syncthreads(); return;
#endif
  __syncthreads();
  target += NB;
  if (threadIdx.x == 0) {
    __threadfence();
    atomicAdd(ctr, 1u);
    while (ld_acquire(ctr) < target) { }
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ GEMV tasks
// C fragment of one task = 16 rows x 8 columns; lane (g,t): c0,c1 = row g cols 2t,2t+1; c2,c3 = row g+8.
// one 64-column chunk of an MXFP4 rowtile: codes q (16 B of this lane), scale word s (4 B), B fragments b[8].
// cvt.rn.scaled::n2::ue8m0.bf16x2.e2m1x2 converts two e2m1 codes and multiplies each by 2^(S-127) of its own scale
// byte: exact for every code and every scale in 100..150 (bench/cvt3.cu, exhaustive; the checkpoint's are 111..138),
// so the A operand is the dequantised BF16 weight and the mma accumulates as the BF16-weight data flow does.
#ifndef FP4_POSTSCALE
__device__ __forceinline__ void cvt4s(u32 x, u32 sa, u32 sb, u32& r0, u32& r1, u32& r2, u32& r3) {
  asm("{ .reg .b8 b0,b1,b2,b3; .reg .b16 ha, hb; mov.b32 {b0,b1,b2,b3}, %4; cvt.u16.u32 ha, %5; cvt.u16.u32 hb, %6;"
      " cvt.rn.scaled::n2::ue8m0.bf16x2.e2m1x2 %0, b0, ha; cvt.rn.scaled::n2::ue8m0.bf16x2.e2m1x2 %1, b1, hb;"
      " cvt.rn.scaled::n2::ue8m0.bf16x2.e2m1x2 %2, b2, ha; cvt.rn.scaled::n2::ue8m0.bf16x2.e2m1x2 %3, b3, hb; }"
      : "=r"(r0), "=r"(r1), "=r"(r2), "=r"(r3) : "r"(x), "r"(sa), "r"(sb));
}
__device__ __forceinline__ void chunk_fp4(float* c, uint4 q, u32 s, const u32* b) {
  const u32 sg0 = __byte_perm(s, 0, 0x0000), sg1 = __byte_perm(s, 0, 0x1111);
  const u32 sh0 = __byte_perm(s, 0, 0x2222), sh1 = __byte_perm(s, 0, 0x3333);
  u32 a0, a1, a2, a3;
  cvt4s(q.x, sg0, sh0, a0, a1, a2, a3); mma16816(c, a0, a1, a2, a3, b[0], b[1]);
  cvt4s(q.y, sg0, sh0, a0, a1, a2, a3); mma16816(c, a0, a1, a2, a3, b[2], b[3]);
  cvt4s(q.z, sg1, sh1, a0, a1, a2, a3); mma16816(c, a0, a1, a2, a3, b[4], b[5]);
  cvt4s(q.w, sg1, sh1, a0, a1, a2, a3); mma16816(c, a0, a1, a2, a3, b[6], b[7]);
}
#else
__device__ __forceinline__ void chunk_fp4(float* c, uint4 q, u32 s, const u32* b) {
  float t0[4], t1[4];
  u32 a0, a1, a2, a3, e0, e1, e2, e3;
  cvt4(q.x, a0, a1, a2, a3); cvt4(q.z, e0, e1, e2, e3);
  mma16816z(t0, a0, a1, a2, a3, b[0], b[1]);
  mma16816z(t1, e0, e1, e2, e3, b[4], b[5]);
  cvt4(q.y, a0, a1, a2, a3); cvt4(q.w, e0, e1, e2, e3);
  mma16816(t0, a0, a1, a2, a3, b[2], b[3]);
  mma16816(t1, e0, e1, e2, e3, b[6], b[7]);
  const float s0 = scale_f(s, 0), s2 = scale_f(s, 2), s1 = scale_f(s, 1), s3 = scale_f(s, 3);
  c[0] = fmaf(t0[0], s0, c[0]); c[1] = fmaf(t0[1], s0, c[1]);
  c[2] = fmaf(t0[2], s2, c[2]); c[3] = fmaf(t0[3], s2, c[3]);
  c[0] = fmaf(t1[0], s1, c[0]); c[1] = fmaf(t1[1], s1, c[1]);
  c[2] = fmaf(t1[2], s3, c[2]); c[3] = fmaf(t1[3], s3, c[3]);
}
#endif
__device__ __forceinline__ void store_task(float* red, int slot, const float* c) {
  const int lane = threadIdx.x & 31;
  *reinterpret_cast<float4*>(red + slot * 128 + lane * 4) = make_float4(c[0], c[1], c[2], c[3]);
}

// ------------------------------------------------------------------------------------------------ TMA task runner
// Every warp streams its weights through its own ring of RS stages in shared memory, filled by bulk copies
// (cp.async.bulk, completion on an mbarrier per stage) that lane 0 issues: bytes in flight cost no registers.
// A warp runs tasks warp, warp+NW, ... < ntask (at most 32 per warp and call). A task = n consecutive items of one
// rowtile, contiguous in memory (bf16: 512 B tile = one mma; fp4: 512 B codes + 32 B scales = four mmas). A stage
// holds up to RI items of one task. B operands come from shared memory: row (rows8 >> 8g & 255) of the task's x
// base, live when bit g of bm is set. fin(slot, c) consumes a task's 16x8 result fragment.
#ifndef RS
#define RS 3
#endif
#ifndef RI
#define RI 9
#endif
#define RING_ITEM 544
#define RING_WARP (RS * RI * RING_ITEM)
struct TD {
  const uint4* w;      // codes / tiles of item 0 (32 uint4 per item)
  const u32* s;        // fp4: scales of item 0 (8 words per item)
  const u16* x;        // B base for item 0 (smem): element (row, k) at x + row * xst + k
  int n;               // items
  int slot;            // where the result goes
  u32 bm;              // bit g set: B column g is live
  u64 rows8;           // byte g: smem row of column g
  int k0;              // first kstep (bf16) / chunk (fp4) of the task inside the B rows
};
struct TT { const uint4* w; const u32* s; const u16* x; u64 rows8; int n; int slot; u32 bm; int k0; };
#define SM_TT_BYTES (NW * 32 * (int)sizeof(TT))
#define ROWS_ID 0x0706050403020100ull

__device__ __forceinline__ u32 smaddr(const void* p) { return (u32)__cvta_generic_to_shared(p); }
__device__ __forceinline__ void mbar_init(u32 b, u32 n) { asm volatile("mbarrier.init.shared::cta.b64 [%0], %1;" :: "r"(b), "r"(n)); }
__device__ __forceinline__ void mbar_expect(u32 b, u32 bytes) {
  asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%0], %1;" :: "r"(b), "r"(bytes) : "memory");
}
__device__ __forceinline__ void mbar_wait(u32 b, u32 ph) {
  asm volatile("{ .reg .pred p; W%=: mbarrier.try_wait.parity.shared::cta.b64 p, [%0], %1; @!p bra W%=; }" :: "r"(b), "r"(ph) : "memory");
}
__device__ __forceinline__ void tma_load(u32 dst, const void* src, u32 bytes, u32 bar) {
#ifdef SKEL
  src = WP(src);
#endif
  asm volatile("cp.async.bulk.shared::cta.global.mbarrier::complete_tx::bytes.L2::cache_hint [%0], [%1], %2, [%3], %4;"
               :: "r"(dst), "l"(src), "r"(bytes), "r"(bar), "l"(0x12F0000000000000ull) : "memory");
}

__device__ __forceinline__ void l2_prefetch(const void* src, u32 bytes) {
#ifdef SKEL
  src = WP(src);
#endif
  asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(src), "r"(bytes) : "memory");
}
struct Ring { u32 data; u32 bars; u32 pos; const unsigned char* gdata; };   // smem addresses of this warp's stages and mbarriers; stages consumed
// producer state of a warp's task list (kept in shared memory across a grid barrier)
struct PState { int nt, pt, pi, kind; u32 issued; int pad[3]; };

// lane 0 issues one stage: the next (up to RI) items of the current task
template <int KIND>
__device__ __forceinline__ void issue_stage(const TT* tt, PState& ps, const Ring& rg, int lane) {
  constexpr int IB = 512, SB = (KIND == 1) ? 32 : 0;
  const u32 sidx = ps.issued % RS;
  const u32 bar = rg.bars + sidx * 8, dst = rg.data + sidx * (RI * RING_ITEM);
  const TT& q = tt[ps.pt];
  const int m = min(RI, q.n - ps.pi);
  if (lane == 0) {
    mbar_expect(bar, m * (IB + SB));
    if (KIND == 1) tma_load(dst, q.w + (size_t)ps.pi * 34, m * 544, bar);   // records: 512 B codes + 32 B scales
    else tma_load(dst, q.w + (size_t)ps.pi * 32, m * IB, bar);
  }
  ps.pi += m;
  if (ps.pi == q.n) { ps.pt++; ps.pi = 0; }
  ps.issued++;
}

// build the warp's task table and issue the first RS stages (the ring must be drained: rg.pos == issued)
template <int KIND, class Desc>
__device__ __forceinline__ void prefetch_tasks(int ntask, TT* table, const Ring& rg, PState& ps, Desc desc) {
  const int warp = threadIdx.x >> 5, lane = threadIdx.x & 31;
  const int nt = (ntask > warp) ? (ntask - warp + NW - 1) / NW : 0;
  TT* tt = table + warp * 32;
  if (lane < nt) {
    TD d; d.s = nullptr; d.rows8 = ROWS_ID; d.k0 = 0; desc(warp + NW * lane, d);
    tt[lane] = TT{d.w, d.s, d.x, d.rows8, d.n, d.slot, d.bm, d.k0};
  }
  __syncwarp();
#ifndef L2PF
#define L2PF 0     // bit 0: fp4 (expert) task lists, bit 1: bf16 task lists of at most 64 items per task (not the head)
#endif
  // the whole task list into L2 at once (the ring then reads at L2 speed); the first RS stages are skipped
  if (lane < nt && (((L2PF & 1) && KIND == 1) || ((L2PF & 2) && KIND == 0 && tt[0].n <= 64))) {
    const TT& q = tt[lane];
    const int skip = (lane == 0) ? min(q.n, RS * RI) : 0;
    if (q.n > skip) {
      if (KIND == 1) l2_prefetch(q.w + (size_t)skip * 34, (q.n - skip) * 544);
      else l2_prefetch(q.w + (size_t)skip * 32, (q.n - skip) * 512);
    }
  }
  PState q; q.nt = nt; q.pt = 0; q.pi = 0; q.kind = KIND; q.issued = rg.pos;
#ifndef PF_STAGES
#define PF_STAGES 2
#endif
  for (int k = 0; k < PF_STAGES && q.pt < nt; k++) issue_stage<KIND>(tt, q, rg, lane);
  if (lane == 0) ps = q;
  __syncwarp();
}

__device__ __forceinline__ u32 lds32(u32 a) { u32 r; asm("ld.shared.u32 %0, [%1];" : "=r"(r) : "r"(a)); return r; }
__device__ __forceinline__ uint4 lds128(u32 a) {
  uint4 r; asm("ld.shared.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "r"(a)); return r;
}
// one item of a stage: A from the ring stage at st, B from shared memory at xb (byte address of this lane's row)
template <int KIND>
__device__ __forceinline__ void item(float* c, u32 st, u32 xb, int kb, int i, int lane, int g, bool cb) {
  constexpr int IB = 512, SB = 32;
  const uint4 q = lds128(st + i * (KIND == 1 ? 544 : IB) + lane * 16);
  if (KIND == 0) {
    const int k = kb + i;
    u32 b0, b1;
    asm("ld.shared.v2.u32 {%0,%1}, [%2];" : "=r"(b0), "=r"(b1) : "r"(xb + (k >> 2) * 128 + (k & 3) * 8));
    b0 = cb ? b0 : 0u; b1 = cb ? b1 : 0u;
    mma16816(c, q.x, q.y, q.z, q.w, b0, b1);
  } else {
    const u32 sw = lds32(st + i * 544 + 512 + g * 4);
    const uint4 x0 = lds128(xb + (kb + i) * 128), x1 = lds128(xb + (kb + i) * 128 + 16);
    u32 b[8] = {x0.x, x0.y, x0.z, x0.w, x1.x, x1.y, x1.z, x1.w};
#ifndef NOSEL
#pragma unroll
    for (int j = 0; j < 8; j++) b[j] = cb ? b[j] : 0u;
#endif
#ifdef NOCVT
    { float t0[4]; mma16816z(t0, q.x, q.y, q.z, q.w, b[0], b[1]); mma16816(t0, q.y, q.x, q.z, q.w, b[2], b[3]);
      mma16816(t0, q.z, q.y, q.x, q.w, b[4], b[5]); mma16816(t0, q.w, q.y, q.z, q.x, b[6], b[7]);
      c[0] = fmaf(t0[0], scale_f(sw, 0), c[0]); c[1] += t0[1]; c[2] += t0[2]; c[3] += t0[3]; }
#else
    chunk_fp4(c, q, sw, b);
#endif
  }
}

// issue more stages of the prefetched list until RS are in flight (call right after a barrier)
template <int KIND>
__device__ __forceinline__ void topup_tasks(TT* table, const Ring& rg, PState& psm) {
  const int warp = threadIdx.x >> 5, lane = threadIdx.x & 31;
  PState ps = psm;
  const TT* tt = table + warp * 32;
  bool any = false;
  while (ps.pt < ps.nt && (int)(ps.issued - rg.pos) < RS) { issue_stage<KIND>(tt, ps, rg, lane); any = true; }
  if (any) { __syncwarp(); if (lane == 0) psm = ps; __syncwarp(); }
}

// consume the prefetched task list (more stages are issued as stages are freed)
template <int KIND, class Fin>
__device__ __forceinline__ void consume_tasks(TT* table, int xst, Ring& rg, PState& psm, Fin fin) {
  const int warp = threadIdx.x >> 5, lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  PState ps = psm;
  const int nt = ps.nt;
  if (nt == 0) return;
  const TT* tt = table + warp * 32;
  while (ps.pt < nt && (int)(ps.issued - rg.pos) < RS) issue_stage<KIND>(tt, ps, rg, lane);   // top up the ring
  constexpr int IB = 512, SB = (KIND == 1) ? 32 : 0;
  constexpr int XST = (KIND == 0) ? 16 : 64;
  int ct = 0, ci = 0;
  TT cq = tt[0];
  u32 cx; bool cb;   // shared-space byte address of this lane's B row
  auto setx = [&]() {
    int row = (int)((cq.rows8 >> (8 * g)) & 0xff);
    cb = (cq.bm >> g) & 1;
    cx = smaddr(cq.x + row * xst) + t * 32;
  };
  setx();
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  float ua[4] = {0.f, 0.f, 0.f, 0.f};     // segmented tasks (slot bit 30): sum of the per-stage partials, in order
  while (ct < nt) {
    const u32 sidx = rg.pos % RS;
    const int n = min(RI, cq.n - ci);
    mbar_wait(rg.bars + sidx * 8, (rg.pos / RS) & 1);
    const u32 st = rg.data + sidx * (RI * RING_ITEM);
    const int kb = cq.k0 + ci;
    if (n == RI) {
#pragma unroll
      for (int i = 0; i < RI; i++) item<KIND>(c, st, cx, kb, i, lane, g, cb);
    } else {
#pragma unroll 1
      for (int i = 0; i < n; i++) item<KIND>(c, st, cx, kb, i, lane, g, cb);
    }
    __syncwarp();
    rg.pos++;
    if (ps.pt < nt) {
      if (lane == 0) asm volatile("fence.proxy.async.shared::cta;" ::: "memory");
      issue_stage<KIND>(tt, ps, rg, lane);
    }
    ci += n;
    if (cq.slot >> 30) {
#pragma unroll
      for (int j = 0; j < 4; j++) { ua[j] += c[j]; c[j] = 0.f; }
    }
    if (ci == cq.n) {
      if (cq.slot >> 30) {
        fin(cq.slot & 0xffff, ua);
#pragma unroll
        for (int j = 0; j < 4; j++) ua[j] = 0.f;
      } else {
        fin(cq.slot, c);
      }
      c[0] = c[1] = c[2] = c[3] = 0.f;
      ci = 0;
      if (++ct < nt) { cq = tt[ct]; setx(); }
    }
  }
  if (lane == 0) psm = ps;
  __syncwarp();
}

template <int KIND, class Desc, class Fin>
__device__ __forceinline__ void run_tasks(int ntask, TT* table, int xst, Ring& rg, PState& ps, Desc desc, Fin fin) {
  prefetch_tasks<KIND>(ntask, table, rg, ps, desc);
  consume_tasks<KIND>(table, xst, rg, ps, fin);
}

// element (row i, column b) of a task's 16 x 8 result in red slot
__device__ __forceinline__ float red_at(const float* red, int slot, int i, int b) {
  return red[slot * 128 + ((i & 7) * 4 + (b >> 1)) * 4 + (i >> 3) * 2 + (b & 1)];
}

// B operands in shared memory are kept in fragment order: inside each 64-column chunk, lane t's eight words
// (j = 0..3: columns 16j+2t, +1 and 16j+2t+8, +9) are contiguous, so a chunk is two 16-byte loads per lane.
// element offset (bf16 units) of column k inside a row
__device__ __forceinline__ int xfo(int k) {
  const int c = k >> 6, r = k & 63, j = r >> 4, rr = r & 15;
  return c * 64 + (((rr & 7) >> 1) * 8 + j * 2 + (rr >> 3)) * 2 + (rr & 1);
}
// write 4 consecutive columns k..k+3 (k % 4 == 0) given as two bf16x2 words
__device__ __forceinline__ void xfo_store4(u16* row, int k, u32 w01, u32 w23) {
  *reinterpret_cast<u32*>(row + xfo(k)) = w01;
  *reinterpret_cast<u32*>(row + xfo(k + 2)) = w23;
}
// write 8 consecutive columns k..k+7 (k % 8 == 0): words land at t = 0..3 for the same (j, half)
__device__ __forceinline__ void xfo_store8(u16* row, int k, uint4 v) {
  *reinterpret_cast<u32*>(row + xfo(k)) = v.x; *reinterpret_cast<u32*>(row + xfo(k + 2)) = v.y;
  *reinterpret_cast<u32*>(row + xfo(k + 4)) = v.z; *reinterpret_cast<u32*>(row + xfo(k + 6)) = v.w;
}

// ------------------------------------------------------------------------------------------------ norms
// xs[b][k] = bf16(w[k] * (x[b][k] * rsqrt(mean(x^2) + eps))), x read with ld.cg (bf16 [B][HID] at src, or embed rows)
__device__ __forceinline__ uint2 ldrow(const u16* r, int k, bool sm) {
  uint2 v;
  if (sm) asm("ld.shared.v2.u32 {%0,%1},[%2];" : "=r"(v.x), "=r"(v.y) : "r"((u32)__cvta_generic_to_shared(r + k)));
  else v = __ldcg(reinterpret_cast<const uint2*>(r + k));
  return v;
}
__device__ void norm_to_smem(const bf16* const* rows, int B, const u16* wsm, u16* xs, float* scratch, bool sm = false) {
  const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31;
  // sum of squares: warp w handles column b = w (w < B); lanes stride over 2880 in 8-byte pieces
  if (warp < B) {
    const u16* r = reinterpret_cast<const u16*>(rows[warp]);
    float s = 0.f;
    // loads in two batches (12 + 11 per lane) so that they are in flight together; same order of the sums
#pragma unroll
    for (int k0 = lane * 4; k0 < HID; k0 += 128 * 12) {
      uint2 v[12];
#pragma unroll
      for (int u = 0; u < 12; u++) if (k0 + 128 * u < HID) v[u] = ldrow(r, k0 + 128 * u, sm);
#pragma unroll
      for (int u = 0; u < 12; u++) if (k0 + 128 * u < HID) {
        float a = __uint_as_float(v[u].x << 16), b = __uint_as_float(v[u].x & 0xffff0000u);
        float c = __uint_as_float(v[u].y << 16), d = __uint_as_float(v[u].y & 0xffff0000u);
        s += a * a + b * b + c * c + d * d;
      }
    }
#pragma unroll
    for (int o = 16; o; o >>= 1) s += __shfl_xor_sync(0xffffffffu, s, o);
    if (lane == 0) scratch[warp] = rsqrtf(s / (float)HID + 1e-5f);
  }
  __syncthreads();
#pragma unroll 4
  for (int i = tid; i < B * (HID / 4); i += NT) {
    int b = i / (HID / 4), k = (i % (HID / 4)) * 4;
    const u16* r = reinterpret_cast<const u16*>(rows[b]);
    uint2 v = ldrow(r, k, sm);
    float ri = scratch[b];
    const uint2 wb = *reinterpret_cast<const uint2*>(wsm + k);
    const float4 wv = make_float4(__uint_as_float(wb.x << 16), __uint_as_float(wb.x & 0xffff0000u),
                                  __uint_as_float(wb.y << 16), __uint_as_float(wb.y & 0xffff0000u));
    u16 o0 = f2u16(wv.x * (__uint_as_float(v.x << 16) * ri));
    u16 o1 = f2u16(wv.y * (__uint_as_float(v.x & 0xffff0000u) * ri));
    u16 o2 = f2u16(wv.z * (__uint_as_float(v.y << 16) * ri));
    u16 o3 = f2u16(wv.w * (__uint_as_float(v.y & 0xffff0000u) * ri));
    xfo_store4(xs + b * XSH, k, o0 | ((u32)o1 << 16), o2 | ((u32)o3 << 16));
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ smem layout
// flat down path (B <= 2): the layer output from the down partials, for all rows, into shared memory (row-major
// bf16 [B][HID] at dst); the block also stores its share (every NB-th group of 4 columns) to x.
// [0, 65664)          xs: bf16 [8][4104] (hidden vectors use stride 2888)
// [65664, +40960)     red: float [80][128]
// attention reuses: sc float [8][2048] at 0 (64 KB), ps bf16 [8][2048+16] at 65664 (32.3 KB), ared aliases sc
// small scalars at SM_MISC
#define SM_XS 0
#define SM_RED 65664
#define RED_SLOTS 50
#define SM_MISC (65664 + RED_SLOTS * 512)
#define SM_TT (SM_MISC + 4096)
#define SM_BARS (SM_TT + SM_TT_BYTES)
#define SM_NWBAR (SM_BARS + NW * RS * 8)
#define SM_PS (SM_BARS + NW * RS * 8 + 64)
#define SM_RING (SM_PS + NW * 32)
#define SM_NWB (SM_RING + NW * RING_WARP)
#define SM_TOTAL (SM_NWB + HID * 2)

struct Misc {
  float rinv[MAXB];
  int U;                 // number of chosen experts (union over the batch)
  int sexp[32];          // slot -> expert id (ascending)
  float rw[MAXB][32];    // routing weight of (sequence, slot), 0 if not routed
  u32 smask[32];         // bit b set if sequence b routed to slot
  int tok[MAXB];
  int fr_s0, fr_s1, fr_np, fr_u0, fr_u1, fr_cur, fr_rs;
  int nrs[MAXB]; int rsl[MAXB][4];     // routed slots of each column, ascending
  int eep[32];          // per slot: how many layers have used it in this launch (target of ecnt = 360 x eep)
  u64 srows[32];
  float tmpf[128];
  int tmpi[128];
};

__device__ void combine_flat(const Params& p, const Misc* ms, int B, u16* dst) {
  const int tid = threadIdx.x;
  for (int i = tid; i < B * (HID / 4); i += NT) {
    const int b = i / (HID / 4), k = (i % (HID / 4)) * 4;
    const int nr = ms->nrs[b];
    uint4 y[4];
#pragma unroll
    for (int q = 0; q < 4; q++)
      y[q] = (q < nr) ? __ldcg(reinterpret_cast<const uint4*>(p.ypart + ((size_t)ms->rsl[b][q] * MAXB + b) * HID + k)) : make_uint4(0, 0, 0, 0);
    const uint2 xv = __ldcg(reinterpret_cast<const uint2*>(p.xm + b * HID + k));
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
    for (int q = 0; q < 4; q++) if (q < nr) {
      const float wv = ms->rw[b][ms->rsl[b][q]];
      acc[0] = fmaf(wv, __uint_as_float(y[q].x), acc[0]); acc[1] = fmaf(wv, __uint_as_float(y[q].y), acc[1]);
      acc[2] = fmaf(wv, __uint_as_float(y[q].z), acc[2]); acc[3] = fmaf(wv, __uint_as_float(y[q].w), acc[3]);
    }
    u16 o0 = f2u16(__uint_as_float(xv.x << 16) + bfr(acc[0]));
    u16 o1 = f2u16(__uint_as_float(xv.x & 0xffff0000u) + bfr(acc[1]));
    u16 o2 = f2u16(__uint_as_float(xv.y << 16) + bfr(acc[2]));
    u16 o3 = f2u16(__uint_as_float(xv.y & 0xffff0000u) + bfr(acc[3]));
    uint2 o = make_uint2(o0 | ((u32)o1 << 16), o2 | ((u32)o3 << 16));
    *reinterpret_cast<uint2*>(dst + b * HID + k) = o;
    if ((k >> 2) % NB == (int)blockIdx.x) *reinterpret_cast<uint2*>(p.x + b * HID + k) = o;
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ the kernel
extern "C" __global__ void __launch_bounds__(NT, 1) mk_kernel(const __grid_constant__ Params p, const __grid_constant__ RunArgs a) {
  extern __shared__ __align__(16) unsigned char smem[];
  u16* xs = reinterpret_cast<u16*>(smem + SM_XS);
  float* red = reinterpret_cast<float*>(smem + SM_RED);
  Misc* ms = reinterpret_cast<Misc*>(smem + SM_MISC);
  TT* ttab = reinterpret_cast<TT*>(smem + SM_TT);
  PState* pst = reinterpret_cast<PState*>(smem + SM_PS);

  const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31, g = lane >> 2, t = lane & 3;
  Ring rg;
  rg.data = smaddr(smem + SM_RING) + warp * RING_WARP;
  rg.gdata = smem + SM_RING + warp * RING_WARP;
  rg.bars = smaddr(smem + SM_BARS) + warp * RS * 8;
  rg.pos = 0;
  if (lane == 0) for (int k = 0; k < RS; k++) mbar_init(rg.bars + k * 8, 1);
  const u32 nwbar = smaddr(smem + SM_NWBAR), nwdst = smaddr(smem + SM_NWB);
  const u16* nwb = reinterpret_cast<const u16*>(smem + SM_NWB);
  u32 nwpos = 0;   // norm-weight loads waited for
  if (tid == 0) mbar_init(nwbar, 1);
  if (tid < 32) ms->eep[tid] = 0;
  asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  __syncthreads();
  const int bid = blockIdx.x;
  const int B = a.B;
  u32 bar_target = 0;
  MkProf prof{p.prof, p.prof_cap};
  MKPROF_DECL(pn);
#ifdef SKEL
  if (tid == 0 && bid == 0) g_skel = p.skel;
  // (every block reads g_skel after the first barrier; set again by each block: same value)
  g_skel = p.skel;
#endif
  u32* bar = p.bar;
  // P = prompt length (mode 0/1: 1); total steps = P + nsteps - 1; step st reads token st of the prompt while
  // st < P, otherwise the argmax of the previous step (= generated token st - P); the head runs for st >= P - 1.
  const int P = (a.mode == 2) ? a.nprompt : 1;
#ifndef FLAT_MAXB
#define FLAT_MAXB 2
#endif
  const bool flat = B <= FLAT_MAXB;   // down phase: even (slot, rowtile) units, partials summed by the next phase
  const int total = P + a.nsteps - 1;

  // ---- the next norm's weights (BF16, 5760 B) into shared memory by one bulk copy; wait_nw() before use
  auto issue_nw = [&](const u16* src) {
    if (tid == 0) { asm volatile("fence.proxy.async.shared::cta;" ::: "memory"); mbar_expect(nwbar, HID * 2); tma_load(nwdst, src, HID * 2, nwbar); }
  };
  auto wait_nw = [&]() { mbar_wait(nwbar, nwpos & 1); nwpos++; };
  // ---- prefetch helpers: build a warp's task table and issue its first ring stages (weights only, no data needed)
  auto pf_qkv = [&](int l) {
    const LayerP& L = p.L[l];
    const int r0 = bid * RT_QKV / NB, R = (bid + 1) * RT_QKV / NB - r0;
    prefetch_tasks<0>(R * NSEG_QKV, ttab, rg, pst[warp], [&](int task, TD& d) {
      int r = task / NSEG_QKV, s = task % NSEG_QKV, k0 = s * KS_H / NSEG_QKV, k1 = (s + 1) * KS_H / NSEG_QKV;
      d.w = L.wqkv + ((size_t)(r0 + r) * KS_H + k0) * 32; d.x = xs; d.k0 = k0; d.n = k1 - k0; d.slot = task; d.bm = (1u << B) - 1;
    });
  };
  auto pf_o = [&](int l) {
    const LayerP& L = p.L[l];
    const int r0 = bid * RT_O / NB, R = (bid + 1) * RT_O / NB - r0;
    prefetch_tasks<0>(R * NSEG_O, ttab, rg, pst[warp], [&](int task, TD& d) {
      int r = task / NSEG_O, s = task % NSEG_O, k0 = s * KS_A / NSEG_O, k1 = (s + 1) * KS_A / NSEG_O;
      d.w = L.wo + ((size_t)(r0 + r) * KS_A + k0) * 32; d.x = xs; d.k0 = k0; d.n = k1 - k0; d.slot = task; d.bm = (1u << B) - 1;
    });
  };
#ifndef RQ
#define RQ 4        // the router's K is split in RQ quarters over 8 * RQ blocks; E sums the RQ partials
#endif
  auto pf_router = [&](int l) {
    const LayerP& L = p.L[l];
    const int rr = bid - (NB - 8 * RQ), rt = rr & 7, q = rr >> 3;
    const int kq0 = q * KS_H / RQ, kq1 = (q + 1) * KS_H / RQ;
    prefetch_tasks<0>(NW, ttab, rg, pst[warp], [&](int task, TD& d) {
      int k0 = kq0 + task * (kq1 - kq0) / NW, k1 = kq0 + (task + 1) * (kq1 - kq0) / NW;
      d.w = L.wr + ((size_t)rt * KS_H + k0) * 32; d.x = xs; d.k0 = k0; d.n = k1 - k0; d.slot = task; d.bm = (1u << B) - 1;
    });
  };
  auto pf_head = [&]() {
    const int r0 = (int)((long)bid * RT_HEAD / NB), r1 = (int)((long)(bid + 1) * RT_HEAD / NB);
    prefetch_tasks<0>(r1 - r0, ttab, rg, pst[warp], [&](int task, TD& d) {
      d.w = p.head + (size_t)(r0 + task) * KS_H * 32; d.x = xs; d.n = KS_H; d.slot = r0 + task; d.bm = (1u << B) - 1;
    });
  };
  pf_qkv(0);
  issue_nw(p.L[0].ln1b);

  for (int st = 0; st < total; st++) {
    const int pos = a.pos0 + st;
    if (tid < B) {
      long long tk;
      if (st < P) tk = a.tok[(size_t)tid * a.tok_stride + st];
      else {
        float bv = -INFINITY; int bi = 0x7fffffff;
        for (int k = 0; k < NB; k++) {
          float v = ldcgf(p.amv + k * MAXB + tid); int ix = ldcgi(p.ami + k * MAXB + tid);
          if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
        }
        tk = (bi >= 0 && bi < VOCAB) ? bi : 0;
        if (bid == 0) {
          if (a.mode == 1) a.out_tok[(size_t)tid * a.nsteps + (st - P)] = tk;
          else a.host_tok[tid * a.nsteps + (st - P)] = (int)tk;
        }
      }
      ms->tok[tid] = (int)tk;
    }
    __syncthreads();
    MARK(MKPROF_STEP);
    if (a.mode == 2 && bid == 0 && tid == 0 && st > P - 1 + 0 && st >= P) { __threadfence_system(); *a.host_prog = st - P + 1; }

    const bf16* rows_in[MAXB];
    for (int layer = 0; layer < NL; layer++) {
      const LayerP& Lp = p.L[layer];
      const int dr0 = bid * RT_DN / NB, dR = (bid + 1) * RT_DN / NB - dr0;   // down rowtiles of this block (1 or 2)
      // rounds of the down phase: slots [s0, s1) whose live (slot, column) activation rows fit in xs (11 rows)
      auto fround = [&](int s0) {
        const int U = ms->U;
        const u32 bmask = (1u << B) - 1;
        if (tid == 0) {
          int s1 = s0, np = 0;
          while (s1 < U && np + __popc(ms->smask[s1] & bmask) <= 11 && (s1 + 1 - s0) * dR * NSEG_DN <= RED_SLOTS) { np += __popc(ms->smask[s1] & bmask); s1++; }
          ms->fr_s0 = s0; ms->fr_s1 = s1; ms->fr_np = np;
          int base = 0;
          for (int k = s0; k < s1; k++) {
            u32 m = ms->smask[k] & bmask;
            u64 r8 = 0;
            for (int b = 0; b < 8; b++) if (m >> b & 1) r8 |= (u64)(base++) << (8 * b);
            ms->srows[k - s0] = r8;
          }
        }
      };
      // flat path: units u in [u0, u1) of U * 180 (slot = u / 180, rowtile = u % 180); staged rows: the routed
      // (slot, column) pairs of the slots [fs0, fs1] this block touches
      // the gate_up rowtiles of slots [s0, s1) are all written (replaces the E -> F grid barrier)
      auto wait_slots = [&](int s0, int s1) {
#ifndef EF_BARRIER
        if (tid < s1 - s0) {
          const u32 target = (u32)RT_GU * (u32)ms->eep[s0 + tid];
          while (ld_acquire(p.ecnt + s0 + tid) < target) { }
        }
        __syncthreads();
#endif
      };
      auto fround_flat = [&]() {
        const int N = ms->U * RT_DN;
        if (tid == 0) {
          const int u0 = (int)((long)bid * N / NB), u1 = (int)((long)(bid + 1) * N / NB);
          const u32 bmask = (1u << B) - 1;
          int s0 = u1 > u0 ? u0 / RT_DN : 0, s1 = u1 > u0 ? (u1 - 1) / RT_DN + 1 : 0;
          ms->fr_s0 = s0; ms->fr_s1 = s1; ms->fr_u0 = u0; ms->fr_u1 = u1;
          int base = 0;
          for (int k = s0; k < s1; k++) {
            u32 m = ms->smask[k] & bmask;
            u64 r8 = 0;
            for (int b = 0; b < 8; b++) if (m >> b & 1) r8 |= (u64)(base++) << (8 * b);
            ms->srows[k - s0] = r8;
          }
          ms->fr_np = base;
        }
      };
      auto pf_down_flat = [&]() {
        const int u0 = ms->fr_u0, s0 = ms->fr_s0;
        prefetch_tasks<1>((ms->fr_u1 - u0) * NSEG_DN, ttab, rg, pst[warp], [&](int task, TD& d) {
          int uu = u0 + task / NSEG_DN, sg = task % NSEG_DN;
          int slot = uu / RT_DN, rt = uu % RT_DN, e = ms->sexp[slot];
          int k0 = sg * KC / NSEG_DN, k1 = (sg + 1) * KC / NSEG_DN;
          d.w = Lp.dn_c + (((size_t)e * RT_DN + rt) * KC + k0) * 34;
          d.s = Lp.dn_s + (((size_t)e * RT_DN + rt) * KC + k0) * 8;
          d.x = xs; d.k0 = k0; d.rows8 = ms->srows[slot - s0];
          d.n = k1 - k0; d.slot = task; d.bm = ms->smask[slot] & ((1u << B) - 1);
        });
      };
      // wide path (B >= 3): the same even (slot, rowtile) units as the flat path, done one slot at a time (its routed
      // activation rows staged in xs), one warp per unit with the 5 segments summed in order (bits of the flat path)
      // a round = slots [s, fr_cur) of this block whose routed activation rows fit in xs (11 rows)
      auto fround_wide = [&](int s) {
        if (tid == 0) {
          const u32 bmask = (1u << B) - 1;
          int e = s, base = 0;
          while (e < ms->fr_s1 && base + __popc(ms->smask[e] & bmask) <= 11) {
            const u32 m = ms->smask[e] & bmask;
            u64 r8 = 0;
            for (int b = 0; b < 8; b++) if (m >> b & 1) r8 |= (u64)(base++) << (8 * b);
            ms->srows[e - s] = r8;
            e++;
          }
          ms->fr_np = base; ms->fr_rs = s; ms->fr_cur = e;
        }
      };
      auto pf_down_wide = [&]() {
        const int s = ms->fr_rs, e2 = ms->fr_cur;
        const int ua = max(ms->fr_u0, s * RT_DN), ub = min(ms->fr_u1, e2 * RT_DN);
        prefetch_tasks<1>(ub - ua, ttab, rg, pst[warp], [&](int task, TD& d) {
          int uu = ua + task, sl = uu / RT_DN, rt = uu % RT_DN, e = ms->sexp[sl];
          d.w = Lp.dn_c + (((size_t)e * RT_DN + rt) * KC) * 34;
          d.s = Lp.dn_s + (((size_t)e * RT_DN + rt) * KC) * 8;
          d.x = xs; d.k0 = 0; d.rows8 = ms->srows[sl - s];
          d.n = KC; d.slot = task | (1 << 30); d.bm = ms->smask[sl] & ((1u << B) - 1);
        });
      };
      auto pf_down = [&](int s0, int s1) {
        prefetch_tasks<1>((s1 - s0) * dR * NSEG_DN, ttab, rg, pst[warp], [&](int task, TD& d) {
          int uu = task / NSEG_DN, sg = task % NSEG_DN;
          int slot = s0 + uu / dR, r = uu % dR, e = ms->sexp[slot];
          int k0 = sg * KC / NSEG_DN, k1 = (sg + 1) * KC / NSEG_DN;
          d.w = Lp.dn_c + (((size_t)e * RT_DN + dr0 + r) * KC + k0) * 34;
          d.s = Lp.dn_s + (((size_t)e * RT_DN + dr0 + r) * KC + k0) * 8;
          d.x = xs; d.k0 = k0; d.rows8 = ms->srows[uu / dR];
          d.n = k1 - k0; d.slot = task; d.bm = ms->smask[slot] & ((1u << B) - 1);
        });
      };
      // ---------------- phase A: norm1 + qkv
      MARK(1);
#ifdef TOPUP
      topup_tasks<0>(ttab, rg, pst[warp]);
#endif
      if (flat && layer > 0) {
        u16* stg = reinterpret_cast<u16*>(red);
        combine_flat(p, ms, B, stg);
        MARK(16);
        for (int b = 0; b < MAXB; b++) rows_in[b] = reinterpret_cast<const bf16*>(stg + b * HID);
        wait_nw(); norm_to_smem(rows_in, B, nwb, xs, ms->rinv, true);
      } else {
        for (int b = 0; b < MAXB; b++)
          rows_in[b] = (layer == 0) ? p.embed + (size_t)(b < B ? ms->tok[b] : 0) * HID : p.x + b * HID;
        wait_nw(); norm_to_smem(rows_in, B, nwb, xs, ms->rinv);
      }
      MARK(11);
      {
        const int r0 = bid * RT_QKV / NB, r1 = (bid + 1) * RT_QKV / NB, R = r1 - r0;
        consume_tasks<0>(ttab, XSH, rg, pst[warp], [&](int slot, const float* c) { store_task(red, slot, c); });
        __syncthreads();
        // epilogue: item = (r, i<8, b)
        for (int it = tid; it < R * 8 * B; it += NT) {
          int r = it / (8 * B), i = (it / B) % 8, b = it % B;
          float v1 = 0.f, v2 = 0.f;
          for (int s = 0; s < NSEG_QKV; s++) { v1 += red_at(red, r * NSEG_QKV + s, i, b); v2 += red_at(red, r * NSEG_QKV + s, i + 8, b); }
          int grt = r0 + r;
          v1 = bfr(v1 + Lp.bqkv[grt * 16 + i]);
          v2 = bfr(v2 + Lp.bqkv[grt * 16 + i + 8]);
          if (grt < 288) {     // q or k: rows i, i+8 = dims d, d+32 of one head
            int j = grt & 3, d = 8 * j + i;
            float cs = p.cosT[pos * 32 + d], sn = p.sinT[pos * 32 + d];
            float o1 = bfr(bfr(v1 * cs) - bfr(v2 * sn));
            float o2 = bfr(bfr(v2 * cs) + bfr(v1 * sn));
            if (grt < 256) {
              int h = grt >> 2;
              p.q[(size_t)b * 4096 + h * 64 + d] = __float2bfloat16_rn(o1);
              p.q[(size_t)b * 4096 + h * 64 + d + 32] = __float2bfloat16_rn(o2);
            } else {
              int kvh = (grt - 256) >> 2;
              bf16* kp = Lp.kc + (((size_t)b * NKV + kvh) * p.maxctx + pos) * HD;
              kp[d] = __float2bfloat16_rn(o1); kp[d + 32] = __float2bfloat16_rn(o2);
            }
          } else {
            int kvh = (grt - 288) >> 2, jj = (grt - 288) & 3;
            int d1 = 16 * jj + i, d2 = d1 + 8;
            bf16* vp = Lp.vc + (((size_t)b * NKV + kvh) * (p.maxctx / 16) + pos / 16) * HD * 16;
            vp[d1 * 16 + (pos & 15)] = __float2bfloat16_rn(v1);
            vp[d2 * 16 + (pos & 15)] = __float2bfloat16_rn(v2);
          }
        }
      }
      pf_o(layer);
      MARK(MKPROF_WAIT);
      grid_bar(bar, bar_target);
      MARK(2);
      // ---------------- phase B: attention. Work item = (sequence, kv head, 64-key chunk aligned to positions
      // 64c..64c+63), one warp each, spread over all blocks. A warp computes the chunk's scores for the 8 query heads
      // (mma: q rows x 8 keys), the chunk max m, l = sum exp(s - m) and acc = sum bf16(exp(s - m)) v (fp32), as
      // flash decoding does; the last warp of a (sequence, head) to finish merges the chunks with the sink:
      // out = sum_c e^(m_c - M) acc_c / (sum_c e^(m_c - M) l_c + e^(sink - M)), M = max(sink, m_c).
#ifndef ATT_HYB
#define ATT_HYB 0    // 1: sliding layers keep one block per (sequence, kv head) (no merge); 2: also full layers below 128 keys
#endif
      const bool split_att = !((ATT_HYB >= 1 && Lp.sliding) || (ATT_HYB >= 2 && pos < 128));
      if (split_att) {
        const int lo = Lp.sliding ? max(0, pos - 127) : 0;
        const int c0 = lo >> 6, c1 = pos >> 6, nch = c1 - c0 + 1;
        const int nitem = B * NKV * nch;
        for (int item = bid + NB * warp; item < nitem; item += NB * NW) {
          const int unit = item / nch, ch = c0 + item % nch;
          const int b = unit >> 3, kvh = unit & 7;
          // q fragments of the 8 heads (A operand rows g = head, rows g+8 zero)
          const u16* qg = reinterpret_cast<const u16*>(p.q) + (size_t)b * 4096 + (kvh * 8 + g) * 64 + 2 * t;
          u32 qa[4][2];
#pragma unroll
          for (int ks = 0; ks < 4; ks++) { qa[ks][0] = ldcg32(qg + 16 * ks); qa[ks][1] = ldcg32(qg + 16 * ks + 8); }
          const u16* kb0 = reinterpret_cast<const u16*>(Lp.kc + ((size_t)b * NKV + kvh) * p.maxctx * HD);
          // scores of the 8 key groups: lane (g,t) gets head g, keys 8 gr + 2t, +1
          float sc[8][2];
          u32 kf[8][8];
#pragma unroll
          for (int gr = 0; gr < 8; gr++) {
            const int key = ch * 64 + 8 * gr + g;
            const u16* kr = kb0 + (size_t)min(key, pos) * HD + 2 * t;
#pragma unroll
            for (int ks = 0; ks < 4; ks++) { kf[gr][2 * ks] = ldcg32(kr + 16 * ks); kf[gr][2 * ks + 1] = ldcg32(kr + 16 * ks + 8); }
          }
          float m = -INFINITY;
#pragma unroll
          for (int gr = 0; gr < 8; gr++) {
            float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
            for (int ks = 0; ks < 4; ks++) mma16816(c, qa[ks][0], 0u, qa[ks][1], 0u, kf[gr][2 * ks], kf[gr][2 * ks + 1]);
            const int k0 = ch * 64 + 8 * gr + 2 * t;
            sc[gr][0] = (k0 >= lo && k0 <= pos) ? c[0] * 0.125f : -INFINITY;
            sc[gr][1] = (k0 + 1 >= lo && k0 + 1 <= pos) ? c[1] * 0.125f : -INFINITY;
            m = fmaxf(m, fmaxf(sc[gr][0], sc[gr][1]));
          }
          m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, 1));
          m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, 2));
          // e = exp(s - m); P (bf16) for the V mix comes straight from the score layout
          float l = 0.f;
          u32 pa[8];
#pragma unroll
          for (int gr = 0; gr < 8; gr++) {
            const float e0 = expf(sc[gr][0] - m), e1 = expf(sc[gr][1] - m);
            l += e0 + e1;
            pa[gr] = (u32)f2u16(e0) | ((u32)f2u16(e1) << 16);
          }
          l += __shfl_xor_sync(0xffffffffu, l, 1);
          l += __shfl_xor_sync(0xffffffffu, l, 2);
          // V mix: 4 key blocks of 16 (groups 2kb, 2kb+1), 8 dim groups of 8
          const u16* vb0 = reinterpret_cast<const u16*>(Lp.vc + ((size_t)b * NKV + kvh) * (p.maxctx / 16) * HD * 16);
          float acc[8][4];
#pragma unroll
          for (int nb = 0; nb < 8; nb++) { acc[nb][0] = acc[nb][1] = acc[nb][2] = acc[nb][3] = 0.f; }
#pragma unroll
          for (int kb = 0; kb < 4; kb++) {
            const u16* vb = vb0 + (size_t)(ch * 4 + kb) * HD * 16;
            u32 vf[8][2];
#pragma unroll
            for (int nb = 0; nb < 8; nb++) { vf[nb][0] = ldcg32(vb + (8 * nb + g) * 16 + 2 * t); vf[nb][1] = ldcg32(vb + (8 * nb + g) * 16 + 2 * t + 8); }
#pragma unroll
            for (int nb = 0; nb < 8; nb++) mma16816(acc[nb], pa[2 * kb], 0u, pa[2 * kb + 1], 0u, vf[nb][0], vf[nb][1]);
          }
          const float sink = Lp.sinks[kvh * 8 + g];
          if (nch == 1) {
            // single chunk: finish here
            const float M = fmaxf(m, sink);
            const float sc_ = expf(m - M), L = l * sc_ + expf(sink - M);
            const float f = sc_ / L;
            bf16* out = p.attn + (size_t)b * 4096 + (kvh * 8 + g) * 64 + 2 * t;
#pragma unroll
            for (int nb = 0; nb < 8; nb++) {
              out[8 * nb] = __float2bfloat16_rn(acc[nb][0] * f);
              out[8 * nb + 1] = __float2bfloat16_rn(acc[nb][1] * f);
            }
          } else {
            // partial: [unit][chunk slot][8 heads][64 + 2]
            float* pp = p.apart + (((size_t)unit * 32 + (ch - c0)) * 8 + g) * 68;
#pragma unroll
            for (int nb = 0; nb < 8; nb++) { pp[8 * nb + 2 * t] = acc[nb][0]; pp[8 * nb + 2 * t + 1] = acc[nb][1]; }
            if (t == 0) { pp[64] = m; pp[65] = l; }
            __threadfence();
            __syncwarp();
            u32 last = 0;
            if (lane == 0) last = (atomicAdd(p.acnt + unit, 1u) == (u32)(nch - 1));
            last = __shfl_sync(0xffffffffu, last, 0);
            if (last) {
              __threadfence();
              if (lane == 0) p.acnt[unit] = 0;
              // lane (g, t): head g, dims 16t .. 16t+15
              const float* base = p.apart + ((size_t)unit * 32 * 8 + g) * 68;
              float M = sink;
              for (int c = 0; c < nch; c++) M = fmaxf(M, ldcgf(base + (size_t)c * 8 * 68 + 64));
              float L = expf(sink - M);
              float o[16];
#pragma unroll
              for (int d = 0; d < 16; d++) o[d] = 0.f;
              for (int c = 0; c < nch; c++) {
                const float* pc = base + (size_t)c * 8 * 68;
                const float w = expf(ldcgf(pc + 64) - M);
                L += w * ldcgf(pc + 65);
#pragma unroll
                for (int d = 0; d < 16; d += 4) {
                  const float4 v = __ldcg(reinterpret_cast<const float4*>(pc + 16 * t + d));
                  o[d] += w * v.x; o[d + 1] += w * v.y; o[d + 2] += w * v.z; o[d + 3] += w * v.w;
                }
              }
              const float iL = 1.f / L;
              bf16* out = p.attn + (size_t)b * 4096 + (kvh * 8 + g) * 64 + 16 * t;
#pragma unroll
              for (int d = 0; d < 16; d++) out[d] = __float2bfloat16_rn(o[d] * iL);
            }
          }
        }
      } else if (bid < B * NKV) {
        const int b = bid >> 3, kvh = bid & 7;
        const int lo = Lp.sliding ? max(0, pos - 127) : 0;
        const int n = pos - lo + 1;
        float* sc = reinterpret_cast<float*>(smem);                     // [8][2048]
        u16* qs = reinterpret_cast<u16*>(smem + SM_RED);                // [8][72] (red is free during attention)
        float* ilh = reinterpret_cast<float*>(smem + SM_RED + 8 * 72 * 2);   // [8] 1 / denominator per head
        if (tid < 8 * 32) {
          int h = tid >> 5, d = (tid & 31) * 2;
          u32 v = ldcg32(p.q + (size_t)b * 4096 + (kvh * 8 + h) * 64 + d);
          *reinterpret_cast<u32*>(qs + h * 72 + d) = v;
        }
        __syncthreads();
        u32 qa[4][2];
#pragma unroll
        for (int ks = 0; ks < 4; ks++) {
          qa[ks][0] = *reinterpret_cast<const u32*>(qs + g * 72 + 16 * ks + 2 * t);
          qa[ks][1] = *reinterpret_cast<const u32*>(qs + g * 72 + 16 * ks + 2 * t + 8);
        }
        const bf16* kbase = Lp.kc + ((size_t)b * NKV + kvh) * p.maxctx * HD;
        const int ngrp = (n + 7) >> 3;
        for (int gr = warp; gr < ngrp; gr += NW) {
          int key = lo + 8 * gr + g;
          bool valid = key <= pos;
          const u16* kr = reinterpret_cast<const u16*>(kbase + (size_t)(valid ? key : lo) * HD) + 2 * t;
          u32 kb[8];
#pragma unroll
          for (int ks = 0; ks < 4; ks++) { kb[2 * ks] = ldcg32(kr + 16 * ks); kb[2 * ks + 1] = ldcg32(kr + 16 * ks + 8); }
          float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
          for (int ks = 0; ks < 4; ks++) mma16816(c, qa[ks][0], 0u, qa[ks][1], 0u, kb[2 * ks], kb[2 * ks + 1]);
          int j0 = 8 * gr + 2 * t;
          sc[g * 2048 + j0] = (lo + j0 <= pos) ? c[0] * 0.125f : -INFINITY;
          sc[g * 2048 + j0 + 1] = (lo + j0 + 1 <= pos) ? c[1] * 0.125f : -INFINITY;
        }
        __syncthreads();
        // softmax per head (warps 0..7), sink joins the denominator
        if (warp < 8) {
          const int h = warp;
          float sink = Lp.sinks[kvh * 8 + h];
          float m = sink;
          for (int j = lane; j < n; j += 32) m = fmaxf(m, sc[h * 2048 + j]);
#pragma unroll
          for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, o));
          float l = 0.f;
          for (int j = lane; j < n; j += 32) { float e = expf(sc[h * 2048 + j] - m); sc[h * 2048 + j] = e; l += e; }
#pragma unroll
          for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffffu, l, o);
          l += expf(sink - m);
          if (lane == 0) ilh[h] = 1.f / l;
        }
        __syncthreads();
        // P V: 16-key blocks aligned at multiples of 16 (absolute); warps round-robin; acc[8 dim groups][4]
        {
          const int base = lo & ~15;
          const int nblk = ((pos - base) >> 4) + 1;
          const bf16* vbase = Lp.vc + ((size_t)b * NKV + kvh) * (p.maxctx / 16) * HD * 16;
          float acc[8][4];
#pragma unroll
          for (int nb = 0; nb < 8; nb++) { acc[nb][0] = acc[nb][1] = acc[nb][2] = acc[nb][3] = 0.f; }
          for (int kb = warp; kb < nblk; kb += NW) {
            int blk = (base >> 4) + kb;
            // P = bf16(e * (1/l)) of keys base+16kb+2t(+1) and +8(+9); 0 outside [lo, pos]
            const float il = ilh[g];
            auto pk = [&](int key) -> u32 {
              int j = key - lo;
              float v0 = (j >= 0 && key <= pos) ? sc[g * 2048 + j] * il : 0.f;
              float v1 = (j + 1 >= 0 && key + 1 <= pos) ? sc[g * 2048 + j + 1] * il : 0.f;
              return (u32)f2u16(v0) | ((u32)f2u16(v1) << 16);
            };
            u32 a0 = pk(base + 16 * kb + 2 * t), a2 = pk(base + 16 * kb + 2 * t + 8);
            const u16* vb = reinterpret_cast<const u16*>(vbase + (size_t)blk * HD * 16);
#pragma unroll
            for (int nb = 0; nb < 8; nb++) {
              u32 b0 = ldcg32(vb + (8 * nb + g) * 16 + 2 * t);
              u32 b1 = ldcg32(vb + (8 * nb + g) * 16 + 2 * t + 8);
              mma16816(acc[nb], a0, 0u, a2, 0u, b0, b1);
            }
          }
          __syncthreads();   // sc no longer needed: reuse as ared [16 warps][8 heads][64]
          float* ared = sc;
#pragma unroll
          for (int nb = 0; nb < 8; nb++) {
            ared[(warp * 8 + g) * 64 + 8 * nb + 2 * t] = acc[nb][0];
            ared[(warp * 8 + g) * 64 + 8 * nb + 2 * t + 1] = acc[nb][1];
          }
          __syncthreads();
          for (int it = tid; it < 512; it += NT) {
            int h = it >> 6, d = it & 63;
            float s = 0.f;
            for (int w = 0; w < NW; w++) s += ared[(w * 8 + h) * 64 + d];
            p.attn[(size_t)b * 4096 + (kvh * 8 + h) * 64 + d] = __float2bfloat16_rn(s);
          }
        }
      }
      MARK(MKPROF_WAIT);
      grid_bar(bar, bar_target);
      MARK(3);
      // ---------------- phase C: o_proj + residual
      {
#ifdef TOPUP
        topup_tasks<0>(ttab, rg, pst[warp]);
#endif
        for (int i = tid; i < B * 1024; i += NT) {
          int b = i >> 10, k = (i & 1023) * 4;
          uint2 v; asm volatile("ld.global.cg.v2.u32 {%0,%1},[%2];" : "=r"(v.x), "=r"(v.y) : "l"(p.attn + (size_t)b * 4096 + k));
          xfo_store4(xs + b * XSA, k, v.x, v.y);
        }
        __syncthreads();
        const int r0 = bid * RT_O / NB, r1 = (bid + 1) * RT_O / NB, R = r1 - r0;
        consume_tasks<0>(ttab, XSA, rg, pst[warp], [&](int slot, const float* c) { store_task(red, slot, c); });
        __syncthreads();
        for (int it = tid; it < R * 16 * B; it += NT) {
          int r = it / (16 * B), i = (it / B) % 16, b = it % B;
          float v = 0.f;
          for (int s = 0; s < NSEG_O; s++) v += red_at(red, r * NSEG_O + s, i, b);
          int row = (r0 + r) * 16 + i;
          float o = bfr(v + Lp.bo[row]);
          const bf16* xin = (layer == 0) ? p.embed + (size_t)ms->tok[b] * HID : p.x + b * HID;
          float xv = u16f(ldcg16(xin + row));
          p.xm[b * HID + row] = __float2bfloat16_rn(xv + o);
        }
      }
      if (bid >= NB - 8 * RQ) pf_router(layer);
      issue_nw(Lp.ln2b);
      MARK(MKPROF_WAIT);
      grid_bar(bar, bar_target);
      MARK(4);
      // ---------------- phase D: norm2 (all blocks), router (blocks NB-8 .. NB-1)
      for (int b = 0; b < MAXB; b++) rows_in[b] = p.xm + b * HID;
      wait_nw(); norm_to_smem(rows_in, B, nwb, xs, ms->rinv);
      if (bid >= NB - 8 * RQ) {
        const int rr = bid - (NB - 8 * RQ), rt = rr & 7, q = rr >> 3;
        consume_tasks<0>(ttab, XSH, rg, pst[warp], [&](int slot, const float* c) { store_task(red, slot, c); });
        __syncthreads();
        if (tid < 16 * B) {
          int i = tid / B, b = tid % B;
          float v = 0.f;
          for (int w = 0; w < NW; w++) v += red_at(red, w, i, b);
          p.rlog[(q * MAXB + b) * NE + rt * 16 + i] = v;
        }
      }
      MARK(MKPROF_WAIT);
      grid_bar(bar, bar_target);
      MARK(5);
      // ---------------- phase E: top-4 + union (every block), gate_up
      {
        __shared__ int sel[MAXB][4];
        __shared__ float selw[MAXB][4];
        __syncthreads();
        MARK(15);
        if (warp < B) {
          const int b = warp;
          float v[4]; int ix[4];
#pragma unroll
          for (int k = 0; k < 4; k++) {
            ix[k] = lane + 32 * k;
            float pq[RQ];
#pragma unroll
            for (int q = 0; q < RQ; q++) pq[q] = ldcgf(p.rlog + (q * MAXB + b) * NE + ix[k]);
            float vv = 0.f;
#pragma unroll
            for (int q = 0; q < RQ; q++) vv += pq[q];
            vv += Lp.br[ix[k]];
#if ROUTER_BF16
            vv = bfr(vv);
#endif
            v[k] = vv;
          }
          // top 4 by one warp-wide integer max per round: key = order-preserving 16-bit image of the bf16
          // logit, then 0xFFFF - expert (equal logits: the lower expert wins, as torch.topk on equal values here)
          u32 key[4];
#pragma unroll
          for (int k = 0; k < 4; k++) {
#if ROUTER_BF16
            const u32 hb = __float_as_uint(v[k]) >> 16;          // exact: v is bf16-rounded
#else
            const u32 hb = __float_as_uint(v[k]) >> 16;          // (fp32 logits: ordering by the top 16 bits only)
#endif
            const u32 ord = (hb & 0x8000u) ? (~hb & 0xffffu) : (hb | 0x8000u);
            key[k] = (ord << 16) | (0xffffu - (u32)ix[k]);
          }
          u32 tk[4];
#pragma unroll
          for (int r = 0; r < 4; r++) {
            const u32 lm = max(max(key[0], key[1]), max(key[2], key[3]));
            const u32 best = __reduce_max_sync(0xffffffffu, lm);
            tk[r] = best;
#pragma unroll
            for (int k = 0; k < 4; k++) if (key[k] == best) key[k] = 0;
          }
          if (lane < 4) {
            // lane r: expert and logit of rank r; softmax over the 4 (fp32)
            const u32 kr = tk[lane];
            const int e = 0xffff - (int)(kr & 0xffffu);
            const u32 ord = kr >> 16, hb = (ord & 0x8000u) ? (ord & 0x7fffu) : (~ord & 0xffffu);
            const float lv = __uint_as_float(hb << 16);
            const float l0 = __shfl_sync(0x0000000fu, lv, 0);
            const float ex = expf(lv - l0);
            float sum = ex;
            sum += __shfl_xor_sync(0x0000000fu, sum, 1);
            sum += __shfl_xor_sync(0x0000000fu, sum, 2);
            sel[b][lane] = e; selw[b][lane] = ex / sum;
          }
        }
        __syncthreads();
        MARK(14);
        // union of the chosen experts in ascending expert order, by warp 0: lane i < 4B holds (b = i / 4, r = i % 4)
        if (warp == 0) {
          const bool on = lane < 4 * B;
          const int bb = lane >> 2;
          const int e = on ? sel[bb][lane & 3] : 1000;
          const float wv = on ? selw[bb][lane & 3] : 0.f;
          u32 w4[4];
#pragma unroll
          for (int q = 0; q < 4; q++) w4[q] = __reduce_or_sync(0xffffffffu, (on && (e >> 5) == q) ? (1u << (e & 31)) : 0u);
          int slot = 0;
          if (on) {
            const int q = e >> 5;
#pragma unroll
            for (int qq = 0; qq < 4; qq++) if (qq < q) slot += __popc(w4[qq]);
            slot += __popc(w4[q] & ((1u << (e & 31)) - 1));
          }
          const u32 same = __match_any_sync(0xffffffffu, e);       // lanes holding the same expert
          u32 sm = 0;
          for (u32 m2 = same; m2; m2 &= m2 - 1) sm |= 1u << ((__ffs(m2) - 1) >> 2);
          // rank of this expert's slot among the column's 4 (all distinct)
          int rk = 0;
#pragma unroll
          for (int j = 0; j < 4; j++) { const int os = __shfl_sync(0xffffffffu, slot, (lane & ~3) + j); rk += os < slot; }
          if (on) {
            if ((int)(__ffs(same) - 1) == lane) { ms->sexp[slot] = e; ms->smask[slot] = sm; }
            ms->rw[bb][slot] = wv;
            ms->rsl[bb][rk] = slot;
            if ((lane & 3) == 0) ms->nrs[bb] = 4;
          }
          if (lane == 0) ms->U = __popc(w4[0]) + __popc(w4[1]) + __popc(w4[2]) + __popc(w4[3]);
        }
        __syncthreads();
        const int U = ms->U;
        if (tid < U) ms->eep[tid]++;
        MARK(12);
        const int N = U * RT_GU;
        const int u0 = (int)((long)bid * N / NB), u1 = (int)((long)(bid + 1) * N / NB);
        if (B >= 3) {
          // one warp per unit (all 45 chunks; the 5 segments of 9 chunks are summed in order as in the split
          // form, so the bits are those of B <= 2), epilogue by the warp: no reduction rounds, the ring never drains
          run_tasks<1>(u1 - u0, ttab, XSH, rg, pst[warp], [&](int task, TD& d) {
            int uu = u0 + task, slot = uu / RT_GU, rt = uu % RT_GU, e = ms->sexp[slot];
            d.w = Lp.gu_c + (((size_t)e * RT_GU + rt) * KC) * 34;
            d.s = Lp.gu_s + (((size_t)e * RT_GU + rt) * KC) * 8;
            d.x = xs; d.k0 = 0; d.n = KC; d.slot = task | (1 << 30); d.bm = (1u << B) - 1;
          }, [&](int task, const float* c) {
            const int uu = u0 + task, slot = uu / RT_GU, rt = uu % RT_GU, e = ms->sexp[slot];
            // lane (g,t): rows g, g+8 x columns 2t, 2t+1; gate = even rows, up = odd rows (partner lane g+1 = lane+4)
            float o[4];
#pragma unroll
            for (int j = 0; j < 4; j++) o[j] = __shfl_xor_sync(0xffffffffu, c[j], 4);
            if (!(g & 1)) {
#pragma unroll
              for (int h = 0; h < 2; h++) {          // h = 0: rows g / g+1, h = 1: rows g+8 / g+9
                const int i = (g >> 1) + 4 * h;        // pair index in the rowtile
                const float bg = Lp.gu_b[(size_t)e * 5760 + rt * 16 + 2 * i], bu = Lp.gu_b[(size_t)e * 5760 + rt * 16 + 2 * i + 1];
#pragma unroll
                for (int q = 0; q < 2; q++) {
                  const int b = 2 * t + q;
                  if (b < B && (ms->smask[slot] >> b & 1)) {
                    float gt = c[2 * h + q] + bg, up = o[2 * h + q] + bu;
                    gt = fminf(gt, 7.0f);
                    up = fmaxf(fminf(up, 7.0f), -7.0f);
                    float glu = gt * (1.0f / (1.0f + expf(-1.702f * gt)));
                    p.act[((size_t)slot * MAXB + b) * HID + rt * 8 + i] = __float2bfloat16_rn((up + 1.0f) * glu);
                  }
                }
              }
            }
          });
#ifndef EF_BARRIER
          // one signal per block and slot once all of the block's units are written
          __threadfence();
          __syncthreads();
          if (tid == 0) {
            for (int sl = u0 / RT_GU; u1 > u0 && sl <= (u1 - 1) / RT_GU; sl++) {
              const int a0 = max(u0, sl * RT_GU), a1 = min(u1, (sl + 1) * RT_GU);
              atomicAdd(p.ecnt + sl, (u32)(a1 - a0));
            }
          }
#endif
        } else
        for (int ub = u0; ub < u1; ub += RED_SLOTS / NSEG_GU) {
          const int nu = min(RED_SLOTS / NSEG_GU, u1 - ub);
          const int ntask = nu * NSEG_GU;
          run_tasks<1>(ntask, ttab, XSH, rg, pst[warp], [&](int task, TD& d) {
            int uu = ub + task / NSEG_GU, s = task % NSEG_GU;
            int slot = uu / RT_GU, rt = uu % RT_GU, e = ms->sexp[slot];
            int k0 = s * KC / NSEG_GU, k1 = (s + 1) * KC / NSEG_GU;
            d.w = Lp.gu_c + (((size_t)e * RT_GU + rt) * KC + k0) * 34;
            d.s = Lp.gu_s + (((size_t)e * RT_GU + rt) * KC + k0) * 8;
            d.x = xs; d.k0 = k0; d.n = k1 - k0; d.slot = task; d.bm = (1u << B) - 1;
          }, [&](int slot, const float* c) { store_task(red, slot, c); });
          MARK(13);
          __syncthreads();
          // epilogue: item = (unit, pair i<8, b): gate = row 2i, up = row 2i+1
          for (int it = tid; it < nu * 8 * B; it += NT) {
            int ul = it / (8 * B), i = (it / B) % 8, b = it % B;
            int uu = ub + ul, slot = uu / RT_GU, rt = uu % RT_GU, e = ms->sexp[slot];
            if (!(ms->smask[slot] >> b & 1)) continue;
            float gt = 0.f, up = 0.f;
            for (int s = 0; s < NSEG_GU; s++) { gt += red_at(red, ul * NSEG_GU + s, 2 * i, b); up += red_at(red, ul * NSEG_GU + s, 2 * i + 1, b); }
            gt += Lp.gu_b[(size_t)e * 5760 + rt * 16 + 2 * i];
            up += Lp.gu_b[(size_t)e * 5760 + rt * 16 + 2 * i + 1];
            gt = fminf(gt, 7.0f);
            up = fmaxf(fminf(up, 7.0f), -7.0f);
            float glu = gt * (1.0f / (1.0f + expf(-1.702f * gt)));
            float o = (up + 1.0f) * glu;
            p.act[((size_t)slot * MAXB + b) * HID + rt * 8 + i] = __float2bfloat16_rn(o);
          }
#ifndef EF_BARRIER
          __threadfence();
          __syncthreads();
          if (tid == 0) {
            for (int sl = ub / RT_GU; sl <= (ub + nu - 1) / RT_GU; sl++) {
              const int a0 = max(ub, sl * RT_GU), a1 = min(ub + nu, (sl + 1) * RT_GU);
              atomicAdd(p.ecnt + sl, (u32)(a1 - a0));
            }
          }
#endif
          __syncthreads();
        }
        // the down phase's first round: row table and prefetch of its weights
        if (flat) {
          fround_flat();
          __syncthreads();
          pf_down_flat();
        } else {
          fround_flat();
          __syncthreads();
          if (ms->fr_s1 > ms->fr_s0) { fround_wide(ms->fr_s0); __syncthreads(); pf_down_wide(); }
        }
      }
#ifdef EF_BARRIER
      MARK(MKPROF_WAIT);
      grid_bar(bar, bar_target);
#endif
      MARK(6);
      // ---------------- phase F: down for owned rowtiles x all slots, weighted sum, residual
      if (flat) {
        const int s0 = ms->fr_s0, s1 = ms->fr_s1, np = ms->fr_np, u0 = ms->fr_u0, u1 = ms->fr_u1;
        u16* xa = xs;
        wait_slots(s0, s1);
        for (int it = tid; it < np * (HID / 8); it += NT) {
          int pr = it / (HID / 8), k = (it % (HID / 8)) * 8;
          int q = pr, sl = s0, b = 0;
          for (; sl < s1; sl++) { int c = __popc(ms->smask[sl] & ((1u << B) - 1)); if (q < c) break; q -= c; }
          u32 m = ms->smask[sl] & ((1u << B) - 1);
          for (b = 0; b < 8; b++) if (m >> b & 1) { if (q == 0) break; q--; }
          uint4 v = ldcg128(p.act + ((size_t)sl * MAXB + b) * HID + k);
          xfo_store8(xa + pr * XSH, k, v);
        }
        __syncthreads();
        consume_tasks<1>(ttab, XSH, rg, pst[warp], [&](int slot, const float* c) { store_task(red, slot, c); });
        __syncthreads();
        for (int it = tid; it < (u1 - u0) * 16 * B; it += NT) {
          int ul = it / (16 * B), i = (it / B) % 16, b = it % B;
          int uu = u0 + ul, slot = uu / RT_DN, rt = uu % RT_DN, e = ms->sexp[slot];
          if (!(ms->smask[slot] >> b & 1)) continue;
          float y = 0.f;
          for (int sg = 0; sg < NSEG_DN; sg++) y += red_at(red, ul * NSEG_DN + sg, i, b);
          y += Lp.dn_b[(size_t)e * HID + rt * 16 + i];
          p.ypart[((size_t)slot * MAXB + b) * HID + rt * 16 + i] = y;
        }
      } else {
        // wide path: rounds of slots whose activation rows fit in xs
        bool first = true;
        while (ms->fr_s1 > ms->fr_s0) {
          if (!first) { if (ms->fr_cur >= ms->fr_s1) break; fround_wide(ms->fr_cur); __syncthreads(); }
          const int rs = ms->fr_rs, re = ms->fr_cur, np = ms->fr_np;
          const u32 bmask = (1u << B) - 1;
          wait_slots(rs, re);
          for (int it = tid; it < np * (HID / 8); it += NT) {
            const int pr = it / (HID / 8), k = (it % (HID / 8)) * 8;
            int q = pr, sl = rs, b = 0;
            for (; sl < re; sl++) { const int c = __popc(ms->smask[sl] & bmask); if (q < c) break; q -= c; }
            const u32 m = ms->smask[sl] & bmask;
            for (b = 0; b < 8; b++) if (m >> b & 1) { if (q == 0) break; q--; }
            const uint4 v = ldcg128(p.act + ((size_t)sl * MAXB + b) * HID + k);
            xfo_store8(xs + pr * XSH, k, v);
          }
          __syncthreads();
          if (!first) pf_down_wide();
          first = false;
          const int ua = max(ms->fr_u0, rs * RT_DN);
          consume_tasks<1>(ttab, XSH, rg, pst[warp], [&](int task, const float* c) {
            const int uu = ua + task, sl = uu / RT_DN, rt = uu % RT_DN, e = ms->sexp[sl];
            const u32 m = ms->smask[sl] & bmask;
            // lane (g,t): rows g, g+8 of the rowtile, columns 2t, 2t+1
#pragma unroll
            for (int h = 0; h < 2; h++) {
              const int row = rt * 16 + g + 8 * h;
              const float bias = Lp.dn_b[(size_t)e * HID + row];
#pragma unroll
              for (int q = 0; q < 2; q++) {
                const int b = 2 * t + q;
                if (b < B && (m >> b & 1)) p.ypart[((size_t)sl * MAXB + b) * HID + row] = c[2 * h + q] + bias;
              }
            }
          });
          __syncthreads();
        }
      }
      if (layer < NL - 1) { pf_qkv(layer + 1); issue_nw(p.L[layer + 1].ln1b); }
      else if (st >= P - 1) { pf_head(); issue_nw(p.lnfb); }
      else if (st + 1 < total) { pf_qkv(0); issue_nw(p.L[0].ln1b); }
      MARK(MKPROF_WAIT);
      grid_bar(bar, bar_target);
      if (!flat) {
        // wide path: the layer output x = bf16(xm + bf16(sum over the routed slots of w * y)), rows owned by blocks
        MARK(8);
        const int g0 = bid * (HID / 4) / NB, g1 = (bid + 1) * (HID / 4) / NB;
        for (int it = tid; it < (g1 - g0) * B; it += NT) {
          const int b = it / (g1 - g0), k = (g0 + it % (g1 - g0)) * 4;
          const int nr = ms->nrs[b];
          uint4 y[4];
#pragma unroll
          for (int q = 0; q < 4; q++)
            y[q] = (q < nr) ? __ldcg(reinterpret_cast<const uint4*>(p.ypart + ((size_t)ms->rsl[b][q] * MAXB + b) * HID + k)) : make_uint4(0, 0, 0, 0);
          const uint2 xv = __ldcg(reinterpret_cast<const uint2*>(p.xm + b * HID + k));
          float acc[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
          for (int q = 0; q < 4; q++) if (q < nr) {
            const float wv = ms->rw[b][ms->rsl[b][q]];
            acc[0] = fmaf(wv, __uint_as_float(y[q].x), acc[0]); acc[1] = fmaf(wv, __uint_as_float(y[q].y), acc[1]);
            acc[2] = fmaf(wv, __uint_as_float(y[q].z), acc[2]); acc[3] = fmaf(wv, __uint_as_float(y[q].w), acc[3]);
          }
          u16 o0 = f2u16(__uint_as_float(xv.x << 16) + bfr(acc[0]));
          u16 o1 = f2u16(__uint_as_float(xv.x & 0xffff0000u) + bfr(acc[1]));
          u16 o2 = f2u16(__uint_as_float(xv.y << 16) + bfr(acc[2]));
          u16 o3 = f2u16(__uint_as_float(xv.y & 0xffff0000u) + bfr(acc[3]));
          *reinterpret_cast<uint2*>(p.x + b * HID + k) = make_uint2(o0 | ((u32)o1 << 16), o2 | ((u32)o3 << 16));
        }
        MARK(MKPROF_WAIT);
        grid_bar(bar, bar_target);
      }
    }  // layers
    // ---------------- head
    const bool need_head = st >= P - 1;
    if (need_head) {
      MARK(7);
      if (flat) {
        u16* stg = reinterpret_cast<u16*>(red);
        combine_flat(p, ms, B, stg);
        for (int b = 0; b < MAXB; b++) rows_in[b] = reinterpret_cast<const bf16*>(stg + b * HID);
        wait_nw(); norm_to_smem(rows_in, B, nwb, xs, ms->rinv, true);
      } else {
        for (int b = 0; b < MAXB; b++) rows_in[b] = p.x + b * HID;
        wait_nw(); norm_to_smem(rows_in, B, nwb, xs, ms->rinv);
      }
      const int r0 = (int)((long)bid * RT_HEAD / NB), r1 = (int)((long)(bid + 1) * RT_HEAD / NB);
      float bv = -INFINITY; int bi = 0x7fffffff;   // this lane's best for column (2t or 2t+1) — tracked per lane below
      float bv2 = -INFINITY; int bi2 = 0x7fffffff;
      (void)r1;
      consume_tasks<0>(ttab, XSH, rg, pst[warp], [&](int rt, const float* c) {
        int row0 = rt * 16 + g, row1 = row0 + 8;
        int b0 = 2 * t, b1 = 2 * t + 1;
        if (a.mode == 0) {
          if (b0 < B) { a.logits[(size_t)b0 * VOCAB + row0] = c[0]; a.logits[(size_t)b0 * VOCAB + row1] = c[2]; }
          if (b1 < B) { a.logits[(size_t)b1 * VOCAB + row0] = c[1]; a.logits[(size_t)b1 * VOCAB + row1] = c[3]; }
        } else {
          if (c[0] > bv || (c[0] == bv && row0 < bi)) { bv = c[0]; bi = row0; }
          if (c[2] > bv || (c[2] == bv && row1 < bi)) { bv = c[2]; bi = row1; }
          if (c[1] > bv2 || (c[1] == bv2 && row0 < bi2)) { bv2 = c[1]; bi2 = row0; }
          if (c[3] > bv2 || (c[3] == bv2 && row1 < bi2)) { bv2 = c[3]; bi2 = row1; }
        }
      });
      if (a.mode != 0) {
        // reduce over g (lanes with the same t), then over warps
        #pragma unroll
        for (int o = 4; o < 32; o <<= 1) {
          float ov = __shfl_xor_sync(0xffffffffu, bv, o); int oi = __shfl_xor_sync(0xffffffffu, bi, o);
          if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
          ov = __shfl_xor_sync(0xffffffffu, bv2, o); oi = __shfl_xor_sync(0xffffffffu, bi2, o);
          if (ov > bv2 || (ov == bv2 && oi < bi2)) { bv2 = ov; bi2 = oi; }
        }
        if (g == 0) {
          ms->tmpf[warp * 8 + 2 * t] = bv; ms->tmpi[warp * 8 + 2 * t] = bi;
          ms->tmpf[warp * 8 + 2 * t + 1] = bv2; ms->tmpi[warp * 8 + 2 * t + 1] = bi2;
        }
        __syncthreads();
        if (tid < B) {
          float v = -INFINITY; int ix = 0x7fffffff;
          for (int w = 0; w < NW; w++) {
            float ov = ms->tmpf[w * 8 + tid]; int oi = ms->tmpi[w * 8 + tid];
            if (ov > v || (ov == v && oi < ix)) { v = ov; ix = oi; }
          }
          p.amv[bid * MAXB + tid] = v; p.ami[bid * MAXB + tid] = ix;
        }
      }
      if (st + 1 < total) { pf_qkv(0); issue_nw(p.L[0].ln1b); }
      MARK(MKPROF_WAIT);
      grid_bar(bar, bar_target);
    }
  }  // steps
  // the last token chosen: reduce once more and record
  if (a.mode != 0) {
    if (tid < B) {
      float bv = -INFINITY; int bi = 0x7fffffff;
      for (int k = 0; k < NB; k++) {
        float v = ldcgf(p.amv + k * MAXB + tid); int ix = ldcgi(p.ami + k * MAXB + tid);
        if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
      }
      if (bid == 0) {
        if (a.mode == 1) a.out_tok[tid * a.nsteps + a.nsteps - 1] = bi;
        else a.host_tok[tid * a.nsteps + a.nsteps - 1] = bi;
      }
    }
    __syncthreads();
    if (a.mode == 2 && bid == 0 && tid == 0) { __threadfence_system(); *a.host_prog = a.nsteps; }
  }
  // reset the barrier counter for the next launch: the last block out
  if (tid == 0) {
    __threadfence();
    u32 v = atomicAdd(bar + 1, 1u);
    if (v == NB - 1) { bar[0] = 0; bar[1] = 0; for (int k = 0; k < 32; k++) p.ecnt[k] = 0; __threadfence(); }
  }
}

// ------------------------------------------------------------------------------------------------ host side
struct Engine {
  Params p;
  int* host_tok; int* host_prog; int* dev_host_tok; int* dev_host_prog;
  int ntok_cap;
  cudaStream_t stream;
};

extern "C" void* mk_create(const void* params) {
  Engine* e = new Engine;
  memcpy(&e->p, params, sizeof(Params));
  if (cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, SM_TOTAL) != cudaSuccess) return nullptr;
  e->ntok_cap = MAXB * 8192;
  cudaHostAlloc(&e->host_tok, e->ntok_cap * sizeof(int), cudaHostAllocMapped);
  cudaHostAlloc(&e->host_prog, 64, cudaHostAllocMapped);
  cudaHostGetDevicePointer(&e->dev_host_tok, e->host_tok, 0);
  cudaHostGetDevicePointer(&e->dev_host_prog, e->host_prog, 0);
  e->stream = 0;
  return e;
}
extern "C" int mk_params_size() { return (int)sizeof(Params); }
extern "C" int mk_layer_size() { return (int)sizeof(LayerP); }

extern "C" int mk_run(void* h, const void* tok, int tok_stride, void* logits, void* out_tok, int B, int pos0, int nprompt, int nsteps, int mode, void* stream) {
  Engine* e = (Engine*)h;
  RunArgs a;
  a.tok = (const long long*)tok; a.tok_stride = tok_stride; a.logits = (float*)logits; a.out_tok = (long long*)out_tok;
  a.host_tok = e->dev_host_tok; a.host_prog = e->dev_host_prog; a.B = B; a.pos0 = pos0; a.nprompt = nprompt; a.nsteps = nsteps; a.mode = mode;
  if (mode == 2) { *(volatile int*)e->host_prog = 0; if (B * nsteps > e->ntok_cap) return -3; }
  void* args[] = {(void*)&e->p, (void*)&a};
  cudaError_t err = cudaLaunchCooperativeKernel((void*)mk_kernel, dim3(NB), dim3(NT), args, SM_TOTAL, (cudaStream_t)stream);
  if (err != cudaSuccess) { fprintf(stderr, "mk_run: %s\n", cudaGetErrorString(err)); return -1; }
  return 0;
}
extern "C" int mk_poll(void* h, int* buf, int B, int nsteps) {
  Engine* e = (Engine*)h;
  int done = *(volatile int*)e->host_prog;
  if (done > 0) memcpy(buf, e->host_tok, sizeof(int) * B * nsteps);
  return done;
}
