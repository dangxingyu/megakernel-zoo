"""The checkpoint's DSpark draft head (mtp.safetensors, config mtp_config) for exact draft-and-verify (track C).

The draft only proposes tokens; the verify pass of the target (mk.cu, mk_step<true>) decides. Its function follows the
harness's description of vLLM's DSpark (BF16 storage and GEMMs, FP32 norms / RoPE / softmax / Markov gate math, the
hidden_out x unembed fold in float64 stored BF16), written here on static buffers so that one draft-and-verify cycle
is a fixed sequence of kernels (captured once as a CUDA graph):

  after a verify pass of 8 rows (x_c, d_1 .. d_7 at positions c .. c+7): the target's tokens tgt[0..7] (argmax per
  row), a = number of leading drafts equal to tgt, committed tokens tgt[0..a]; every row's four target features
  (partials at the start of applications 5, 23, 41 and the final-norm output) become the draft's context K/V at its
  position (rows > a are overwritten by later cycles before any read: the block attends to positions < c_new only);
  c_new = c + a + 1, anchor = tgt[a]; the block of 8 rows (embedding of the anchor, 7 mask rows) through the 3 layers,
  the Markov recurrence -> 7 drafts; the next verify pass reads (anchor, drafts) at position c_new.
"""
from __future__ import annotations

import json
from pathlib import Path

import torch
import torch.nn.functional as F

BF16 = torch.bfloat16
NB = 8          # block rows = verify rows


class Draft:
    def __init__(self, model_dir: str, maxctx: int, embed: torch.Tensor, embed_norm: torch.Tensor, unembed: torch.Tensor,
                 dev):
        from safetensors.torch import load_file
        cfg = json.loads((Path(model_dir) / "config.json").read_text())
        mc, tc = cfg["mtp_config"], cfg["text_config"]
        assert mc["markov_head_type"] == "rnn_hidden" and mc["block_size"] == NB
        self.H, self.L = mc["hidden_size"], mc["num_hidden_layers"]
        self.nh, self.nkv, self.hd = mc["num_attention_heads"], mc["num_key_value_heads"], mc["head_dim"]
        self.eps, self.rank, self.window = mc["rms_norm_eps"], mc["markov_rank"], mc["sliding_window_size"]
        self.local = set(mc["local_layer_ids"])
        assert mc["target_layer_ids"] == [5, 23, 41, 48]
        self.vocab = tc["unpadded_vocab_size"]
        self.cap = tc["final_logit_softcapping"]
        self.dev = dev
        self.maxctx = maxctx
        w = load_file(str(Path(model_dir) / "mtp.safetensors"), device=str(dev))
        self.embed = embed                                   # [rows, H] bf16 (the target's, shared)
        self.embed_norm = embed_norm.float()
        self.unembed = unembed[: self.vocab].contiguous()    # [V, H] bf16 row-major
        self.w = []
        for l in range(self.L):
            p = f"layers.{l}."
            g = lambda k: w[p + k]  # noqa: E731
            self.w.append({
                "qkv": torch.cat([g("self_attn.q_proj.weight"), g("self_attn.k_proj.weight"), g("self_attn.v_proj.weight")]).contiguous(),
                "kv_ctx": torch.cat([g("self_attn.k_proj_ctx.weight"), g("self_attn.v_proj_ctx.weight")]).contiguous(),
                "o": g("self_attn.o_proj.weight"),
                "gate_up": torch.cat([g("mlp.gate_proj.weight"), g("mlp.up_proj.weight")]).contiguous(),
                "down": g("mlp.down_proj.weight"),
                **{k: g(n).float() for k, n in (("in_ln", "input_layernorm.weight"), ("post_ln", "post_attention_layernorm.weight"),
                                                ("dflare", "dflare_norm.weight"), ("q_norm", "self_attn.q_norm.weight"),
                                                ("k_norm", "self_attn.k_norm.weight"), ("k_norm_ctx", "self_attn.k_norm_ctx.weight"))},
            })
        self.norm = w["norm.weight"].float()
        self.mask_embed = w["mask_embed"]
        self.alpha = torch.softmax(w["fuse_weight"].float(), dim=-1).to(BF16).float()   # [L + 1, 4]
        mh = "markov_head."
        self.m_norm = w[mh + "dflare_norm.weight"].float()
        self.w1 = w[mh + "markov_w1.weight"]                                              # [padded vocab, r]
        rnn_w = w[mh + "rnn_proj.weight"]
        r = self.rank
        self.w_rec = rnn_w[:, :2 * r].float().t().contiguous()                            # [2r, 3r]
        self.w_ctx = rnn_w[:, 2 * r:].float().t().contiguous()                            # [2H, 3r]
        self.rnn_b = w[mh + "rnn_proj.bias"].float()
        ho_w, ho_b = w[mh + "hidden_out.weight"], w[mh + "hidden_out.bias"]
        fw = torch.empty(self.vocab, r, dtype=BF16, device=dev)
        fb = torch.empty(self.vocab, dtype=BF16, device=dev)
        hw, hb = ho_w.double(), ho_b.double()
        for s in range(0, self.vocab, 8192):
            head = self.unembed[s:s + 8192].double()
            fw[s:s + 8192] = (head @ hw).to(BF16)
            fb[s:s + 8192] = (head @ hb).to(BF16)
        self.fold_w, self.fold_b = fw, fb
        del w
        self.inv_freq = 1.0 / (mc["rope_theta"] ** (torch.arange(0, self.hd, 2, dtype=torch.float32, device=dev) / self.hd))
        # context K/V cache (sequence 0) per layer: rows 0..maxctx-1 = positions, rows maxctx.. = the block's own 8 rows
        T = maxctx + NB
        self.kc = [torch.zeros(T, self.nkv, self.hd, dtype=BF16, device=dev) for _ in range(self.L)]
        self.vc = [torch.zeros(T, self.nkv, self.hd, dtype=BF16, device=dev) for _ in range(self.L)]
        self.tpos = torch.arange(maxctx, device=dev)
        self.ar8 = torch.arange(NB, device=dev)
        # cycle state (device)
        self.vtok = torch.zeros(NB, dtype=torch.int32, device=dev)     # verify input: anchor, 7 drafts
        self.vpos = torch.zeros(1, dtype=torch.int32, device=dev)      # verify position c
        self.c_new = torch.zeros(1, dtype=torch.long, device=dev)
        self.anchor = torch.zeros(1, dtype=torch.long, device=dev)
        self.frow = torch.zeros(1, dtype=torch.long, device=dev)
        self.feats = torch.zeros(NB, 4, self.H, dtype=BF16, device=dev)  # target features of the verify rows
        self.emit = torch.zeros(NB + 1, dtype=torch.int32, device=dev)   # [n, tokens...] of the last cycle

    # ------------------------------------------------------------------------------------------------ pieces
    def _rms(self, x, weight):
        u = x.float()
        return (u * torch.rsqrt(u.square().mean(-1, keepdim=True) + self.eps) * weight).to(BF16)

    def _add_rms(self, x, residual, weight):
        s = x.float() + residual.float()
        u = s * torch.rsqrt(s.square().mean(-1, keepdim=True) + self.eps) * weight
        return u.to(BF16), s.to(BF16)

    def _rope(self, x, pos):
        f = pos.to(torch.float32)[:, None] * self.inv_freq[None]
        cos, sin = f.cos()[:, None], f.sin()[:, None]
        h = self.hd // 2
        x1, x2 = x[..., :h].float(), x[..., h:].float()
        return torch.cat([x1 * cos - x2 * sin, x2 * cos + x1 * sin], -1).to(BF16)

    def _mix(self, feats, row, weight):
        m = torch.einsum("tjh,j->th", feats.float(), self.alpha[row])
        return (m * torch.rsqrt(m.square().mean(-1, keepdim=True) + self.eps) * weight).to(BF16)

    def ctx_append(self, feats, pos):
        """feats [n, 4, H] bf16 of positions pos [n] (long, device) -> context K/V rows at those positions."""
        for l in range(self.L):
            w = self.w[l]
            u = self._mix(feats, l, w["dflare"])
            kv = F.linear(u, w["kv_ctx"])
            k, v = kv.split([self.nkv * self.hd, self.nkv * self.hd], -1)
            k = self._rms(k.reshape(-1, self.nkv, self.hd), w["k_norm_ctx"])
            self.kc[l].index_copy_(0, pos, self._rope(k, pos))
            self.vc[l].index_copy_(0, pos, v.reshape(-1, self.nkv, self.hd))

    def propose(self):
        """state c_new, anchor, frow (feature row of position c_new - 1) -> vtok = [anchor, 7 drafts], vpos = c_new."""
        n, H, T = NB, self.H, self.maxctx
        c = self.c_new
        e = self.embed.index_select(0, self.anchor).float()
        e = (e * torch.rsqrt(e.square().mean(-1, keepdim=True) + self.eps) * self.embed_norm).to(BF16)
        x = torch.cat([e, self.mask_embed[None].expand(n - 1, H)], 0)                      # [8, H]
        pos = c + self.ar8                                                                  # [8]
        valid_g = self.tpos < c
        valid_l = valid_g & (self.tpos >= c - self.window)
        ones = torch.ones(n, dtype=torch.bool, device=self.dev)
        mask_g = torch.cat([valid_g, ones])
        mask_l = torch.cat([valid_l, ones])
        residual = None
        g = self.nh // self.nkv
        for l in range(self.L):
            w = self.w[l]
            if residual is None:
                residual, h = x, self._rms(x, w["in_ln"])
            else:
                h, residual = self._add_rms(x, residual, w["in_ln"])
            qkv = F.linear(h, w["qkv"])
            q, k, v = qkv.split([self.nh * self.hd, self.nkv * self.hd, self.nkv * self.hd], -1)
            q = self._rope(self._rms(q.reshape(n, self.nh, self.hd), w["q_norm"]), pos)
            k = self._rope(self._rms(k.reshape(n, self.nkv, self.hd), w["k_norm"]), pos)
            self.kc[l][T:] = k
            self.vc[l][T:] = v.reshape(n, self.nkv, self.hd)
            keys, vals = self.kc[l].float(), self.vc[l].float()                             # [T + 8, nkv, D]
            mask = mask_l if l in self.local else mask_g
            qf = q.float().view(n, self.nkv, g, self.hd)
            s = torch.einsum("qkgd,tkd->kgqt", qf, keys) * self.hd ** -0.5
            s = s.masked_fill(~mask, float("-inf"))
            a = torch.einsum("kgqt,tkd->qkgd", torch.softmax(s, -1), vals)
            o = F.linear(a.reshape(n, self.nh * self.hd).to(BF16), w["o"])
            h, residual = self._add_rms(o, residual, w["post_ln"])
            gu = F.linear(h, w["gate_up"]).float()
            gate, up = gu.chunk(2, -1)
            x = F.linear((F.silu(gate) * up).to(BF16), w["down"])
        hid, _ = self._add_rms(x, residual, self.norm)
        hid = hid[1:]                                                                       # [7, H]
        # Markov head
        r = self.rank
        f = self._mix(self.feats.index_select(0, self.frow), self.L, self.m_norm)          # [1, H]
        inp = torch.cat([hid, f.expand(n - 1, H)], -1)                                      # [7, 2H]
        context = inp.float() @ self.w_ctx + self.rnn_b                                     # [7, 3r]
        base = F.linear(hid, self.unembed)                                                  # [7, V] bf16
        state = torch.zeros(1, r, dtype=BF16, device=self.dev)
        prev = self.anchor
        rd = lambda t: t.to(BF16).float()  # noqa: E731
        drafts = []
        for i in range(n - 1):
            raw = context[i:i + 1] + torch.cat([state, self.w1.index_select(0, prev)], -1).float() @ self.w_rec
            gt, cand, out = rd(raw[:, :r]), rd(raw[:, r:2 * r]), rd(raw[:, 2 * r:])
            gt = rd(1.0 / (1.0 + torch.exp(-gt)))
            cand = rd(torch.tanh(cand))
            state = (rd(gt * state.float()) + rd(rd(1.0 - gt) * cand)).to(BF16)
            latent = torch.tanh(out).to(BF16)
            bias = torch.addmm(self.fold_b[None], latent, self.fold_w.t())                  # [1, V] bf16
            z = (base[i:i + 1].float() + bias.float()).to(BF16).float()
            lg = (self.cap * torch.tanh(z / self.cap)).to(BF16)
            prev = lg.float().argmax(-1)
            drafts.append(prev)
        self.vtok[0:1].copy_(self.anchor)
        self.vtok[1:].copy_(torch.cat(drafts))
        self.vpos.copy_(c)

    def accept(self, tgt, feats):
        """After a verify pass of 8 rows: tgt [8] (int32 target tokens), feats [8, 4, H] -> c_new, anchor, frow, emit."""
        self.feats.copy_(feats)
        t = tgt.long()
        match = (self.vtok[1:].long() == t[:NB - 1]).long()
        a = match.cumprod(0).sum(0, keepdim=True)                                            # [1]
        c = self.vpos.long()
        self.ctx_append(self.feats, c + self.ar8)
        self.c_new.copy_(c + a + 1)
        self.anchor.copy_(t.index_select(0, a))
        self.frow.copy_(a)
        self.emit[0:1].copy_(a + 1)
        self.emit[1:].copy_(tgt)

    # ------------------------------------------------------------------------------------------------ graphs
    def capture(self, tgt_fn, feats_fn):
        """CUDA graphs of the draft side of a cycle: cyc = accept (reads the verify pass's tokens and features) +
        propose; prop = propose alone (after a prefill)."""
        s = torch.cuda.Stream()
        s.wait_stream(torch.cuda.current_stream())
        save = [t.clone() for t in (self.vtok, self.vpos, self.c_new, self.anchor, self.frow)]
        with torch.cuda.stream(s):
            for _ in range(2):
                self.accept(tgt_fn(), feats_fn())
                self.propose()
        torch.cuda.current_stream().wait_stream(s)
        self.g_cyc = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.g_cyc):
            self.accept(tgt_fn(), feats_fn())
            self.propose()
        self.g_prop = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.g_prop):
            self.propose()
        for t, v in zip((self.vtok, self.vpos, self.c_new, self.anchor, self.frow), save):
            t.copy_(v)
        for l in range(self.L):
            self.kc[l].zero_(); self.vc[l].zero_()
        torch.cuda.synchronize()
