// Inkling-2-Mini "wide" pass: up to MAXR rows (sequence slot, position, token) through the whole text decoder in
// one persistent cooperative kernel, phases separated by grid barriers. Used by step() for B >= 2 and by the B >= 2
// draft-and-verify path (rows = several consecutive positions of each sequence).
//
// Batch invariance by construction: every value of a row is computed from that row's own inputs with an order that
// does not depend on the other rows (GEMMs: fixed unit -> warp split and fixed partial-sum order per output, each row
// a column of an mma whose result does not depend on the other columns; attention: absolute 128-key chunks merged in
// increasing order; expert GEMMs: per (expert, token) column; routing, norms and mixes per row). So a row's logits are
// the same whether it is the only row of a step or one of 64 rows of a verify pass.
//
// Weights: the megakernel's device tensors (engine/mk.cu Ctx, LayerW: fragment layouts frag_bf16 / frag_nvfp4 /
// frag_mxfp8) plus an interleaved F/G copy of the loop-gate controllers. Expert inputs are exact: bf16 activations as
// f16 hi + lo * 2^-24 columns with a power-of-two scale (as the megakernel), weights decoded exactly.
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstddef>

typedef __nv_bfloat16 bf16;

#define H 2304
#define NQH 24
#define NKV 8
#define HD 128
#define QW 3072
#define NE 128
#define TOPK 8
#define IE 1152
#define NLW 24
#define NAPP 48
#define MAXB 8
#define NSQ 8            // sequence slots
#define MAXR 64          // rows per pass
#define RING 16
#define VOCAB_REAL 200058
#define UN_STRIPS 12504
#define R_G 3072
#define R_R 6144
#define R_S 6528
#define QG_STRIPS 410
#define K0 6560
#define V0 7616
#define QKVR 8672
#define NT 512
#define NW (NT / 32)
#define ACH 128          // attention keys per chunk (absolute: chunk c = keys [128 c, 128 c + 128))
#define MAXCHW 40        // chunks per row (positions < 5120)
#define XTOK 8           // tokens per expert chunk (2 n-groups of 4 hi/lo column pairs)
#define WRING 6144       // per-warp weight ring (bytes): 10 NVFP4 units / 5 MXFP8 units

// ------------------------------------------------------------------------------------------------ mk.cu structs
struct W12M { const uint8_t* data; const int* base; const int* hdr; const int* esc; };
struct LayerW {
  const uint8_t* wqkv; const uint8_t* wo; const uint8_t* wr; const float* rbias;
  const uint8_t* w13; const uint8_t* w2; const float* f13; const float* f2;
  const bf16* norm[3]; const bf16* mlp_norm;
  const bf16* ksc; const bf16* vsc; const bf16* attn_sc; const bf16* mlp_sc;
  const bf16* qscale; const bf16* rscale; const bf16* relp;
  const float* aq; const float* mq;
  const uint8_t* cD; const bf16* cFG;
  W12M qkv12, wo12;
  int nsk, mx, glob, naq;
};
struct App { int layer, pass, slot, bnd, nblk, blk[4], pin, nmsg, msg[2], loopl, out, pad; };
struct Ctx {
  LayerW L[NLW];
  App A[NAPP];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm; const uint8_t* unembed;
  const float* loopq;
  W12M un12;
  int nfin, fin[4], fin_pin, maxctx;
  // (the megakernel's runtime buffers follow; not used here)
};

struct WCtx {
  const Ctx* c;
  const uint8_t* fg[NLW];   // core layers: frag_bf16 of [4 ctrl][2304 (forget, gain) row pairs][64]
  int maxctx, pad0;
  bf16 *kc, *vc;            // [NAPP][NSQ][NKV][maxctx][HD]
  bf16 *hk, *hv;            // [NAPP][NSQ][RING][1024] raw k / v
  bf16 *ha, *hm;            // [NAPP][NSQ][RING][H] raw o_proj output / raw MoE output
  bf16* pb;                 // [NAPP + 1][MAXR][H] partials (index 0: h0)
  bf16* X;                  // [3][MAXR][H] normalized attention-input streams
  float* qkv;               // [MAXR][QKVR]
  float* arec;              // [MAXR][NQH][MAXCHW][130] attention chunk records (m, l, o[128])
  unsigned* acnt;           // [NSQ][NKV] chunk counters (last arriver merges)
  bf16* ao;                 // [MAXR][QW]
  bf16* as;                 // [MAXR][H] attention conv output
  bf16* y;                  // [MAXR][H] router input
  __half* x16;              // [MAXR][2][H] expert input hi / lo (scaled by 2^sh)
  float* s16;               // [MAXR] 2^-sh
  float* rl;                // [MAXR][NE] router logits
  __half* act16;            // [MAXR * TOPK][2][IE]
  float* w2c;               // [MAXR * TOPK][H]
  bf16* xm;                 // [MAXR][H] raw MoE output (bf16)
  float* xg; float* mg;     // [MAXR][4][H] gate x, m
  bf16* ub;                 // [MAXR][4][2 H] gate unit vectors
  float* gv;                // [MAXR][4][64]
  float* xp;                // [MAXR][4][H] gated x'
  bf16* xf;                 // [MAXR][H] final-norm rows
  unsigned long long* amax; // [MAXR]
  int* next_tok;            // [MAXR]
  unsigned* bar;            // [4]
  unsigned long long* prof; // (unused)
  int* rtab;                // routing tables between the w13 and w2 kernels
};
struct WHdr { int R; int flags; const int* rows; float* logits; int* out_tok; };   // rows: device [0] = R, then [MAXR][4] (seq, pos, tok, -); R (host) = upper bound

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ uint32_t cvt_e4m3x2(uint32_t w16) {
  uint32_t r; unsigned short h = (unsigned short)w16;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(h));
  return r;
}
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }
__device__ __forceinline__ uint32_t pack_bf2(float lo, float hi) {
  return (uint32_t)__bfloat16_as_ushort(tobf(lo)) | ((uint32_t)__bfloat16_as_ushort(tobf(hi)) << 16);
}
__device__ __forceinline__ float bf_lo(uint32_t v) { return __uint_as_float(v << 16); }
__device__ __forceinline__ float bf_hi(uint32_t v) { return __uint_as_float(v & 0xffff0000u); }
__device__ __forceinline__ int lane_id() { int l; asm("mov.u32 %0, %%laneid;" : "=r"(l)); return l; }
__device__ __forceinline__ unsigned ld_acq(const unsigned* p) { unsigned v; asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void red_release_gpu(unsigned* p, unsigned v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void cp_async16(void* smem, const void* gmem) {
  const unsigned sa = (unsigned)__cvta_generic_to_shared(smem);
  asm volatile("cp.async.cg.shared.global [%0], [%1], 16;" :: "r"(sa), "l"(gmem) : "memory");
}
__device__ __forceinline__ void cp_commit() { asm volatile("cp.async.commit_group;" ::: "memory"); }
template <int N> __device__ __forceinline__ void cp_wait() { asm volatile("cp.async.wait_group %0;" :: "n"(N) : "memory"); }
__device__ __forceinline__ void ldsm_x4(uint32_t* r, const void* p) {
  const unsigned a = (unsigned)__cvta_generic_to_shared(p);
  asm volatile("ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0,%1,%2,%3}, [%4];" : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]) : "r"(a));
}
__device__ __forceinline__ void ldsm_x4_t(uint32_t* r, const void* p) {
  const unsigned a = (unsigned)__cvta_generic_to_shared(p);
  asm volatile("ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 {%0,%1,%2,%3}, [%4];" : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]) : "r"(a));
}
__device__ __forceinline__ void gsync(int id) { asm volatile("bar.sync %0, %1;" :: "r"(id), "r"(128) : "memory"); }
__device__ __forceinline__ float ldf(const float* p) { return __ldcg(p); }
__device__ __forceinline__ uint32_t ldu(const void* p) { return __ldcg(reinterpret_cast<const unsigned int*>(p)); }

// ------------------------------------------------------------------------------------------------ shared memory
struct GemmSm { bf16 b[2][64][264]; };                  // dense GEMM: two k-slices of 256 for up to 64 rows
struct AttSm {
  bf16 kk[ACH][HD + 8]; bf16 vv[ACH][HD + 8]; bf16 qb[24][HD + 8];
  bf16 ph[32][ACH + 8]; bf16 pl[32][ACH + 8];
  float sc[24][ACH]; float pr[16][ACH]; float rr[24][16];
  int tq[8];                                               // positions of the item's rows
};
struct Smem {
  float red[NW][32];
  int rows[MAXR][4];
  int R;
  int nsq; int sq_seq[NSQ], sq_r0[NSQ], sq_n[NSQ];   // the pass's sequences (rows of one sequence are consecutive)
  float mlm[32], mll[32];
  unsigned long long ubest[MAXR];
  int flag;
  // routing tables (identical in every block)
  int tex[MAXR][TOPK]; float twt[MAXR][TOPK];
  int eoff[NE + 1]; short elist[MAXR * TOPK];              // per expert: (row << 3 | rank) in row order
  int nchk; int chk_e[NE * 4]; int chk_j0[NE * 4]; int chk_n[NE * 4]; int chk_cost0[NE * 4 + 1];
  union __align__(16) {
    GemmSm g;
    struct { bf16 b[32 * (36 * 64 + 8)]; float red[16 * 4 * 4 * 32]; } g2;   // dgemm2: B chunk (<= 32 rows x 2312) + lane partials
    AttSm at;
    struct { __half xs[XTOK][2][H + 8]; unsigned char ring[NW][WRING]; } m13;   // expert inputs + weight rings
    struct { __half xs[XTOK][2][IE + 8]; unsigned char ring[NW][WRING]; } m2;
    bf16 gvs[MAXR][4][72];                                 // F/G GEMM B operand
  } u;
};
// routing tables as stored in global memory between the w13 and w2 kernels (the Smem fields tex .. chk_cost0)
#define RT_BEGIN offsetof(Smem, tex)
#define RT_END offsetof(Smem, u)


// ------------------------------------------------------------------------------------------------ barrier
__device__ __forceinline__ void grid_bar(const WCtx& w, unsigned& nbar, unsigned base) {
  __syncthreads();
  nbar += 1;
  if (threadIdx.x == 0) {
    const unsigned target = base + nbar * gridDim.x;
    __threadfence();
    red_release_gpu(&w.bar[0], 1);
    while ((int)(ld_acq(&w.bar[0]) - target) < 0) { }
    if (w.prof && blockIdx.x == 0 && nbar < 4096) { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); w.prof[nbar] = t; }
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ row vectors
// A "row job" runs on a group of 4 warps (128 threads); thread gt owns element pairs p = gt + 128 j (j < 9).
#define RPJ 9
#define REL(j) (2 * (gt + 128 * (j)))
template <int N>
__device__ __forceinline__ void gsum(float* v, Smem& sm, int gi, int gt) {
#pragma unroll
  for (int i = 0; i < N; i++) {
    float x = v[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x += __shfl_xor_sync(0xffffffffu, x, o);
    v[i] = x;
  }
  const int wl = gt >> 5, lane = gt & 31;
  float* rd = &sm.red[gi * 4][0];   // [4 warps][32]
  gsync(1 + gi);
  if (lane == 0) {
#pragma unroll
    for (int i = 0; i < N; i++) rd[wl * 32 + i] = v[i];
  }
  gsync(1 + gi);
#pragma unroll
  for (int i = 0; i < N; i++) v[i] = ((rd[i] + rd[32 + i]) + rd[64 + i]) + rd[96 + i];
}
__device__ __forceinline__ float gmax1(float x, Smem& sm, int gi, int gt) {
#pragma unroll
  for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffffu, x, o));
  const int wl = gt >> 5, lane = gt & 31;
  float* rd = &sm.red[gi * 4][0];
  gsync(1 + gi);
  if (lane == 0) rd[wl * 32 + 31] = x;
  gsync(1 + gi);
  return fmaxf(fmaxf(rd[31], rd[63]), fmaxf(rd[95], rd[127]));
}
// bf16 row -> packed pairs
__device__ __forceinline__ void ld_row(const bf16* p, uint32_t* v, int gt) {
#pragma unroll
  for (int j = 0; j < RPJ; j++) v[j] = ldu(p + REL(j));
}
// softmax over depth of NS sources (packed bf16 rows; slot FS, if >= 0, is f32) with query q (f32 [H]):
// out[k] = sum_s softmax_s(<v_s / rms(v_s), q> / sqrt(H)) * v_s / rms(v_s)
template <int NS>
__device__ __forceinline__ void g_mix(const uint32_t (*v)[RPJ], const float* fsrc, int fs, unsigned msk, const float* q, float* out, Smem& sm, int gi, int gt) {
  float red[2 * NS];
#pragma unroll
  for (int i = 0; i < 2 * NS; i++) red[i] = 0.f;
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const float2 qq = __ldg(reinterpret_cast<const float2*>(q + REL(j)));
#pragma unroll
    for (int s = 0; s < NS; s++) {
      if (!((msk >> s) & 1u)) continue;
      const float x0 = (s == fs) ? fsrc[2 * j] : bf_lo(v[s][j]), x1 = (s == fs) ? fsrc[2 * j + 1] : bf_hi(v[s][j]);
      red[s] = fmaf(x1, x1, fmaf(x0, x0, red[s]));
      red[NS + s] = fmaf(x1, qq.y, fmaf(x0, qq.x, red[NS + s]));
    }
  }
  gsum<2 * NS>(red, sm, gi, gt);
  float inv[NS], lg[NS], mx = -1e30f;
#pragma unroll
  for (int s = 0; s < NS; s++) {
    inv[s] = rsqrtf(red[s] / (float)H + 1e-6f);
    lg[s] = ((msk >> s) & 1u) ? red[NS + s] * 0.020833333333333332f * inv[s] : -1e30f;
    mx = fmaxf(mx, lg[s]);
  }
  float den = 0.f;
#pragma unroll
  for (int s = 0; s < NS; s++) { lg[s] = ((msk >> s) & 1u) ? expf(lg[s] - mx) : 0.f; den += lg[s]; }
  const float rd = 1.0f / den;
#pragma unroll
  for (int s = 0; s < NS; s++) lg[s] = lg[s] * rd * inv[s];
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    float o0 = 0.f, o1 = 0.f;
#pragma unroll
    for (int s = 0; s < NS; s++) {
      if (!((msk >> s) & 1u)) continue;
      const float x0 = (s == fs) ? fsrc[2 * j] : bf_lo(v[s][j]), x1 = (s == fs) ? fsrc[2 * j + 1] : bf_hi(v[s][j]);
      o0 = fmaf(lg[s], x0, o0); o1 = fmaf(lg[s], x1, o1);
    }
    out[2 * j] = o0; out[2 * j + 1] = o1;
  }
}
// rmsnorm(x) * w -> bf16 row dst
__device__ __forceinline__ void g_norm_store(const float* x, const bf16* w, bf16* dst, Smem& sm, int gi, int gt) {
  float s[1] = {0.f};
#pragma unroll
  for (int k = 0; k < 2 * RPJ; k++) s[0] = fmaf(x[k], x[k], s[0]);
  gsum<1>(s, sm, gi, gt);
  const float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const __nv_bfloat162 wv = *reinterpret_cast<const __nv_bfloat162*>(w + REL(j));
    *reinterpret_cast<uint32_t*>(dst + REL(j)) = pack_bf2(x[2 * j] * r * bf(wv.x), x[2 * j + 1] * r * bf(wv.y));
  }
}

// ------------------------------------------------------------------------------------------------ dense GEMM
// out = W x for the strips [sb, se) (at most 16 / WPS) of one task; W in frag_bf16 order ([strips][U][4][32 lanes][16 B]).
// Arithmetic (fixed per GEMM, independent of R): unit u of a strip is accumulated by unit lane u % WPS, each lane in
// increasing u; the WPS lane partials are summed in lane order. Rows are processed in chunks of 8 NGC; the chunk's B
// rows (bf16, row stride ldb) are staged in shared memory for SK units (k = 64 SK) at a time; every warp keeps three
// units of weights in flight across stage and chunk boundaries. epi(strip, ng, a0, a1, a2, a3) on the strip's first
// warp for every n-group ng of every chunk (lane (g, t): a0 = (row g, col 2t), a1 = (g, 2t+1), a2 = (g+8, 2t), a3).
__device__ unsigned long long* g_dprof = nullptr;
__device__ __forceinline__ void dmark(int k) {
#ifdef WDPROF
  if (g_dprof && threadIdx.x == 0 && g_dprof[blockIdx.x * 8 + k] == 0) { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); g_dprof[blockIdx.x * 8 + k] = t; }
#endif
}
template <int NGC, int WPS, int SK, class EPI>
__device__ __forceinline__ void dgemm2(Smem& sm, const uint8_t* W, int U, int sb, int se, const bf16* Bg, long ldb, int R, EPI epi) {
  dmark(1);
  constexpr int SPB = 16 / WPS, RC = NGC * 8, KSP = SK * 64 + 8;
  static_assert(SK % WPS == 0, "stage = whole lane rounds");
  const int w = threadIdx.x >> 5, lane = lane_id(), q = w / WPS, wl = w % WPS;
  const int strip = sb + q;
  const bool act = q < SPB && strip < se;
  const int g = lane >> 2, t = lane & 3;
  const int nch = (R + RC - 1) / RC;
  const int nuL = (U + WPS - 1) / WPS;
  constexpr int SQ = SK / WPS;                        // lane units per stage
  const int NQ = nch * nuL;
  bf16* bs = reinterpret_cast<bf16*>(&sm.u.g2.b[0]);  // [RC][KSP]
  float* red = sm.u.g2.red;                           // [16][NGC][4][32]
  const uint8_t* ws = W + (long)strip * U * 2048;
  float acc[NGC][4];
#pragma unroll
  for (int ng = 0; ng < NGC; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  auto ldw = [&](uint4* d, int qq) {
    const int u = wl + (qq % nuL) * WPS;
    if (act && qq < NQ && u < U) {
#pragma unroll
      for (int jj = 0; jj < 4; jj++) d[jj] = ldg_nc(ws + ((long)u * 4 + jj) * 512 + lane * 16);
    }
  };
  auto finish = [&](int c) {   // lane partials of chunk c -> epilogue
#pragma unroll
    for (int ng = 0; ng < NGC; ng++)
#pragma unroll
      for (int i = 0; i < 4; i++) red[((w * NGC + ng) * 4 + i) * 32 + lane] = acc[ng][i];
    __syncthreads();
    if (act && wl == 0) {
#pragma unroll
      for (int ng = 0; ng < NGC; ng++) {
        if ((c * NGC + ng) * 8 >= R) break;
        float sv[4];
#pragma unroll
        for (int i = 0; i < 4; i++) {
          float x = 0.f;
#pragma unroll
          for (int k = 0; k < WPS; k++) x += red[(((w + k) * NGC + ng) * 4 + i) * 32 + lane];
          sv[i] = x;
        }
        epi(strip, c * NGC + ng, sv[0], sv[1], sv[2], sv[3]);
      }
    }
#pragma unroll
    for (int ng = 0; ng < NGC; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  };
  auto step = [&](int qq, const uint4* wv) {
    if (qq >= NQ) return;
    const int c = qq / nuL, ql = qq % nuL;
    if (ql % SQ == 0) {   // new stage (uniform over the block)
      if (ql == 0 && c > 0) finish(c - 1);
      __syncthreads();
      const int k0 = (ql * WPS) * 64, kw = min(SK * 64, U * 64 - k0), nck = kw / 8;
      const int r0 = c * RC;
      for (int i = threadIdx.x; i < RC * nck; i += NT) {
        const int r = i / nck, cc = i - r * nck;
        if (r0 + r < R) cp_async16(bs + (long)r * KSP + cc * 8, Bg + (long)(r0 + r) * ldb + k0 + cc * 8);
        else *reinterpret_cast<uint4*>(bs + (long)r * KSP + cc * 8) = make_uint4(0, 0, 0, 0);
      }
      cp_commit(); cp_wait<0>();
      __syncthreads();
      dmark(2);
    }
    const int u = wl + ql * WPS;
    if (act && u < U) {
      const int kl = ((ql % SQ) * WPS + wl) * 64;
#pragma unroll
      for (int jj = 0; jj < 4; jj++) {
        const int kk = kl + jj * 16 + 2 * t;
#pragma unroll
        for (int ng = 0; ng < NGC; ng++) {
          const uint32_t b0 = *reinterpret_cast<const uint32_t*>(bs + (long)(ng * 8 + g) * KSP + kk);
          const uint32_t b1 = *reinterpret_cast<const uint32_t*>(bs + (long)(ng * 8 + g) * KSP + kk + 8);
          mma_bf16(acc[ng], wv[jj].x, wv[jj].y, wv[jj].z, wv[jj].w, b0, b1);
        }
      }
    }
  };
#ifndef DGD
#define DGD 6
#endif
#if DGD == 6
  uint4 w0[4], w1[4], w2[4], w3[4], w4[4], w5[4];
  ldw(w0, 0); ldw(w1, 1); ldw(w2, 2); ldw(w3, 3); ldw(w4, 4); ldw(w5, 5);
#pragma unroll 1
  for (int qq = 0; qq < NQ; qq += 6) {
    step(qq, w0); ldw(w0, qq + 6);
    step(qq + 1, w1); ldw(w1, qq + 7);
    step(qq + 2, w2); ldw(w2, qq + 8);
    step(qq + 3, w3); ldw(w3, qq + 9);
    step(qq + 4, w4); ldw(w4, qq + 10);
    step(qq + 5, w5); ldw(w5, qq + 11);
  }
#else
  uint4 w0[4], w1[4], w2[4];
  ldw(w0, 0); ldw(w1, 1); ldw(w2, 2);
#pragma unroll 1
  for (int qq = 0; qq < NQ; qq += 3) {
    step(qq, w0); ldw(w0, qq + 3);
    step(qq + 1, w1); ldw(w1, qq + 4);
    step(qq + 2, w2); ldw(w2, qq + 5);
  }
#endif
  dmark(3);
  finish(nch - 1);
  __syncthreads();
  dmark(4);
}
// NG dispatch by R: one chunk of 8 / 16 rows, else chunks of 32
#define DG2(R, WPS, SK, ...) do { \
  if ((R) <= 8) dgemm2<1, WPS, SK>(__VA_ARGS__); else if ((R) <= 16) dgemm2<2, WPS, SK>(__VA_ARGS__); \
  else dgemm2<4, WPS, SK>(__VA_ARGS__); } while (0)

// ------------------------------------------------------------------------------------------------ expert pieces
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
template <int NG>
__device__ __forceinline__ void load_b16_unit(const __half* const* colp, int u, uint2 (*bfr)[4]) {
  const int t = lane_id() & 3;
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    const __half* p = colp[ng];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      if (p) {
        const __half* q = p + u * 64 + j * 16 + 2 * t;
        bfr[ng][j] = make_uint2(*reinterpret_cast<const uint32_t*>(q), *reinterpret_cast<const uint32_t*>(q + 8));
      } else bfr[ng][j] = make_uint2(0, 0);
    }
  }
}
template <int NG>
__device__ __forceinline__ void unit_fp4(const uint4& cw, const uint2& sw, const uint2 (*bfr)[4], float (*acc)[4]) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t ss[2] = {sw.x, sw.y};
#pragma unroll
  for (int jj = 0; jj < 2; jj++) {
    uint32_t sc[4];
    scl4(ss[jj], sc);
#pragma unroll
    for (int h = 0; h < 2; h++) {
      const int j = jj * 2 + h;
      uint32_t a[4];
      cvt4(cc[j], a);
      const uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
      const uint32_t a0 = hmul2(a[0], sg), a1 = hmul2(a[1], sg8), a2 = hmul2(a[2], sg), a3 = hmul2(a[3], sg8);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) mma_f16(acc[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
    }
  }
}
template <int NG>
__device__ __forceinline__ void unit_fp8(const uint4& c0, const uint4& c1, uint32_t sw, const uint2 (*bfr)[4], float (*acc)[4]) {
  uint32_t cc[8] = {c0.x, c0.y, c0.z, c0.w, c1.x, c1.y, c1.z, c1.w};
#pragma unroll
  for (int blk = 0; blk < 2; blk++) {
    float d[NG][4];
#pragma unroll
    for (int ng = 0; ng < NG; ng++) { d[ng][0] = d[ng][1] = d[ng][2] = d[ng][3] = 0.f; }
#pragma unroll
    for (int h = 0; h < 2; h++) {
      const int j = blk * 2 + h;
      const uint32_t x0 = cc[2 * j], x1 = cc[2 * j + 1];
      const uint32_t a0 = cvt_e4m3x2(x0 & 0xffff), a1 = cvt_e4m3x2(x0 >> 16), a2 = cvt_e4m3x2(x1 & 0xffff), a3 = cvt_e4m3x2(x1 >> 16);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) mma_f16(d[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
    }
    const uint32_t e0 = (sw >> (16 * blk)) & 0xff, e1 = (sw >> (16 * blk + 8)) & 0xff;
    const float s0 = e0 ? __int_as_float(e0 << 23) : __int_as_float(0x00400000), s1 = e1 ? __int_as_float(e1 << 23) : __int_as_float(0x00400000);
#pragma unroll
    for (int ng = 0; ng < NG; ng++) {
      acc[ng][0] = fmaf(d[ng][0], s0, acc[ng][0]); acc[ng][1] = fmaf(d[ng][1], s0, acc[ng][1]);
      acc[ng][2] = fmaf(d[ng][2], s1, acc[ng][2]); acc[ng][3] = fmaf(d[ng][3], s1, acc[ng][3]);
    }
  }
}
// a whole expert strip (U units, increasing order) on one warp
template <int NG>
__device__ __forceinline__ void strip_fp4(const uint8_t* wst, int U, const __half* const* colp, float (*acc)[4]) {
  const int lane = lane_id(), g = lane >> 2;
  constexpr int UNR = 6;
#pragma unroll 1
  for (int u = 0; u < U; u += UNR) {
    uint4 cw[UNR]; uint2 sw[UNR];
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      cw[q] = ldg_nc(wst + (long)(u + q) * 576 + lane * 16);
      sw[q] = ldg_nc2(wst + (long)(u + q) * 576 + 512 + g * 8);
    }
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      uint2 bfr[NG][4];
      load_b16_unit<NG>(colp, u + q, bfr);
      unit_fp4<NG>(cw[q], sw[q], bfr, acc);
    }
  }
}
template <int NG>
__device__ __forceinline__ void strip_fp8(const uint8_t* wst, int U, const __half* const* colp, float (*acc)[4]) {
  const int lane = lane_id(), g = lane >> 2;
  constexpr int UNR = 3;
#pragma unroll 1
  for (int u = 0; u < U; u += UNR) {
    uint4 c0[UNR], c1[UNR]; uint32_t sw[UNR];
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      c0[q] = ldg_nc(wst + (long)(u + q) * 1056 + lane * 32);
      c1[q] = ldg_nc(wst + (long)(u + q) * 1056 + lane * 32 + 16);
      sw[q] = ldg_nc1(wst + (long)(u + q) * 1056 + 1024 + g * 4);
    }
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      uint2 bfr[NG][4];
      load_b16_unit<NG>(colp, u + q, bfr);
      unit_fp8<NG>(c0[q], c1[q], sw[q], bfr, acc);
    }
  }
}
__device__ __forceinline__ float act_fn(float g, float u) {
  float a = 4.0f * tanhf(g / 4.0f) * sigm(g);
  return a * (25.0f * tanhf(u / 25.0f));
}
__device__ __forceinline__ float sconv_static(float x, float x1, float x2, float x3, const bf16* w4) {
  float acc = __fmul_rn(x3, bf(w4[0]));
  acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
  acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
  acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
  return __fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f);
}

// ------------------------------------------------------------------------------------------------ phases
#define WARGS const WCtx& w, const Ctx& c, const WHdr& hd, Smem& sm
#define GROUPS ((int)gridDim.x * 4)
#define GI ((int)(threadIdx.x >> 7))
#define GT ((int)(threadIdx.x & 127))
#define GID ((int)blockIdx.x * 4 + GI)
__device__ __forceinline__ int rseq(const Smem& sm, int r) { return sm.rows[r][0]; }
__device__ __forceinline__ int rpos(const Smem& sm, int r) { return sm.rows[r][1]; }
__device__ __forceinline__ long ring_row(int slot, int seq, int t) { return ((long)slot * NSQ + seq) * RING + (t & (RING - 1)); }

// attention-input sources of application a for row r: blocks + pin
__device__ __forceinline__ void attn_srcs(const WCtx& w, const App& ap, int r, uint32_t (*v)[RPJ], unsigned& msk, int gt) {
  msk = ((1u << ap.nblk) - 1u) | 16u;
#pragma unroll
  for (int s = 0; s < 5; s++) {
    const int idx = s < 4 ? ap.blk[s] : ap.pin;
    if ((msk >> s) & 1u) ld_row(w.pb + ((long)idx * MAXR + r) * H, v[s], gt);
    else {
#pragma unroll
      for (int j = 0; j < RPJ; j++) v[s][j] = 0u;
    }
  }
}
// ungated attention input: jobs (row, stream q < nq) -> X[q][r]
__device__ __forceinline__ void ph_attn_in(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int nq = L.glob ? 3 : 1, R = sm.R, gi = GI, gt = GT;
  for (int job = GID; job < R * nq; job += GROUPS) {
    const int r = job / nq, q = job % nq;
    float x[2 * RPJ];
    if (a == 0) {
      const int tok = min(max(sm.rows[r][2], 0), 201023);
      const bf16* er = c.embed + (long)tok * H;
      float s[1] = {0.f};
#pragma unroll
      for (int j = 0; j < RPJ; j++) {
        const __nv_bfloat162 e2 = *reinterpret_cast<const __nv_bfloat162*>(er + REL(j));
        x[2 * j] = bf(e2.x); x[2 * j + 1] = bf(e2.y);
        s[0] = fmaf(x[2 * j + 1], x[2 * j + 1], fmaf(x[2 * j], x[2 * j], s[0]));
      }
      gsum<1>(s, sm, gi, gt);
      const float rr = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
      for (int j = 0; j < RPJ; j++) {
        const __nv_bfloat162 nw = *reinterpret_cast<const __nv_bfloat162*>(c.embed_norm + REL(j));
        const uint32_t hv = pack_bf2(x[2 * j] * rr * bf(nw.x), x[2 * j + 1] * rr * bf(nw.y));
        if (q == 0) *reinterpret_cast<uint32_t*>(w.pb + (long)r * H + REL(j)) = hv;
        x[2 * j] = bf_lo(hv); x[2 * j + 1] = bf_hi(hv);
      }
    } else {
      uint32_t v[5][RPJ];
      unsigned msk;
      attn_srcs(w, ap, r, v, msk, gt);
      g_mix<5>(v, nullptr, -1, msk, L.aq + q * H, x, sm, gi, gt);
    }
    g_norm_store(x, L.norm[q], w.X + ((long)q * MAXR + r) * H, sm, gi, gt);
  }
}

// the attention conv (from the ha ring, all of this pass's rows written by o_proj) -> as[r]; the MLP mix -> x
__device__ __forceinline__ void mlp_x(WARGS, int a, int r, float* x) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int gi = GI, gt = GT;
  const int seq = rseq(sm, r), t = rpos(sm, r);
  float asv[2 * RPJ];
  {
    const bf16* h0 = w.ha + ring_row(ap.slot, seq, t) * H;
    const bf16* h1 = w.ha + ring_row(ap.slot, seq, t - 1) * H;
    const bf16* h2 = w.ha + ring_row(ap.slot, seq, t - 2) * H;
    const bf16* h3 = w.ha + ring_row(ap.slot, seq, t - 3) * H;
#pragma unroll
    for (int j = 0; j < RPJ; j++) {
      const int el = REL(j);
      const uint32_t v0 = ldu(h0 + el), v1 = ldu(h1 + el), v2 = ldu(h2 + el), v3 = ldu(h3 + el);
      const uint2 wa = *reinterpret_cast<const uint2*>(L.attn_sc + el * 4), wb = *reinterpret_cast<const uint2*>(L.attn_sc + el * 4 + 4);
      const float y0 = sconv_static(bf_lo(v0), bf_lo(v1), bf_lo(v2), bf_lo(v3), reinterpret_cast<const bf16*>(&wa));
      const float y1 = sconv_static(bf_hi(v0), bf_hi(v1), bf_hi(v2), bf_hi(v3), reinterpret_cast<const bf16*>(&wb));
      const uint32_t pk = pack_bf2(y0, y1);
      *reinterpret_cast<uint32_t*>(w.as + (long)r * H + el) = pk;
      asv[2 * j] = bf_lo(pk); asv[2 * j + 1] = bf_hi(pk);
    }
  }
  const bool add_pin = !(a == 0 || ap.bnd);
  const unsigned msk = ((a == 0) ? 1u : (((1u << ap.nblk) - 1u) | (ap.bnd ? 16u : 0u))) | 32u;
  uint32_t v[6][RPJ];
#ifdef WDBG
  if (blockIdx.x == 0 && gt == 96) printf("mlp_x a=%d r=%d msk=%u pin=%d blk=%d %d %d %d nblk=%d pb=%p seq=%d t=%d\n", a, r, msk, ap.pin, ap.blk[0], ap.blk[1], ap.blk[2], ap.blk[3], ap.nblk, w.pb, seq, t);
#endif
#pragma unroll
  for (int s = 0; s < 5; s++) {
    const int idx = s == 0 ? (a == 0 ? 0 : ap.blk[0]) : (s < 4 ? ap.blk[s] : ap.pin);
    if ((msk >> s) & 1u) ld_row(w.pb + ((long)idx * MAXR + r) * H, v[s], gt);
    else {
#pragma unroll
      for (int j = 0; j < RPJ; j++) v[s][j] = 0u;
    }
  }
  if (add_pin) {
    uint32_t pv[RPJ];
    ld_row(w.pb + ((long)ap.pin * MAXR + r) * H, pv, gt);
#pragma unroll
    for (int j = 0; j < RPJ; j++) { asv[2 * j] = bf_lo(pv[j]) + asv[2 * j]; asv[2 * j + 1] = bf_hi(pv[j]) + asv[2 * j + 1]; }
  }
#pragma unroll
  for (int j = 0; j < RPJ; j++) v[5][j] = 0u;
  g_mix<6>(v, asv, 5, msk, L.mq, x, sm, gi, gt);
}
// MLP input of row r from x (f32): router input y (bf16), expert input x16 (f16 hi / lo with scale 2^sh), s16
__device__ __forceinline__ void mlp_norm(WARGS, int a, int r, const float* x) {
  const LayerW& L = c.L[c.A[a].layer];
  const int gi = GI, gt = GT;
  float wv[2 * RPJ];
  float s[1] = {0.f}, mx = 0.f;
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const __nv_bfloat162 w2 = *reinterpret_cast<const __nv_bfloat162*>(L.mlp_norm + REL(j));
    wv[2 * j] = bf(w2.x); wv[2 * j + 1] = bf(w2.y);
  }
#pragma unroll
  for (int k = 0; k < 2 * RPJ; k++) { s[0] = fmaf(x[k], x[k], s[0]); mx = fmaxf(mx, fabsf(x[k] * wv[k])); }
  gsum<1>(s, sm, gi, gt);
  mx = gmax1(mx, sm, gi, gt);
  const float rr = rsqrtf(s[0] / (float)H + 1e-6f);
  int e2 = 0;
  const float bound = mx * rr;
  frexpf(bound, &e2);
  const int sh = (bound > 0.f) ? 15 - e2 : 0;
  const float scl = ldexpf(1.0f, sh);
  __half* xh = w.x16 + (long)r * 2 * H;
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const int el = REL(j);
    const uint32_t yb = pack_bf2(x[2 * j] * rr * wv[2 * j], x[2 * j + 1] * rr * wv[2 * j + 1]);
    *reinterpret_cast<uint32_t*>(w.y + (long)r * H + el) = yb;
    const float y0 = bf_lo(yb) * scl, y1 = bf_hi(yb) * scl;
    const __half h0 = __float2half_rn(y0), h1 = __float2half_rn(y1);
    const __half l0 = __float2half_rn((y0 - __half2float(h0)) * 16777216.0f), l1 = __float2half_rn((y1 - __half2float(h1)) * 16777216.0f);
    *reinterpret_cast<__half2*>(xh + el) = __halves2half2(h0, h1);
    *reinterpret_cast<__half2*>(xh + H + el) = __halves2half2(l0, l1);
  }
  if (gt == 0) w.s16[r] = ldexpf(1.0f, -sh);
}
__device__ __forceinline__ void ph_mlp_in(WARGS, int a) {
  for (int r = GID; r < sm.R; r += GROUPS) {
    float x[2 * RPJ];
    mlp_x(w, c, hd, sm, a, r, x);
    mlp_norm(w, c, hd, sm, a, r, x);
  }
}

// gate jobs (row, controller in [c0, c0 + nc)): x = the stream's mix (controller 3: the MLP mix), m = the loop
// message mix -> xg, mg (f32), ub = [bf16(x / rms x), bf16(m / rms m)]
__device__ __forceinline__ void ph_gate_mix(WARGS, int a, int c0, int nc) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R, gi = GI, gt = GT;
  for (int job = GID; job < R * nc; job += GROUPS) {
    const int r = job / nc, ctrl = c0 + job % nc;
    float x[2 * RPJ], m[2 * RPJ];
    {
      uint32_t ms[2][RPJ];
      ld_row(w.pb + ((long)ap.msg[0] * MAXR + r) * H, ms[0], gt);
      ld_row(w.pb + ((long)ap.msg[1] * MAXR + r) * H, ms[1], gt);
      g_mix<2>(ms, nullptr, -1, 3u, c.loopq + ((long)ap.loopl * 4 + ctrl) * H, m, sm, gi, gt);
    }
    if (ctrl < 3) {
      uint32_t v[5][RPJ];
      unsigned msk;
      attn_srcs(w, ap, r, v, msk, gt);
      g_mix<5>(v, nullptr, -1, msk, L.aq + (L.glob ? ctrl : 0) * H, x, sm, gi, gt);
    } else mlp_x(w, c, hd, sm, a, r, x);
    float s2[2] = {0.f, 0.f};
#pragma unroll
    for (int k = 0; k < 2 * RPJ; k++) { s2[0] = fmaf(x[k], x[k], s2[0]); s2[1] = fmaf(m[k], m[k], s2[1]); }
    gsum<2>(s2, sm, gi, gt);
    const float rx = rsqrtf(s2[0] / (float)H + 1e-6f), rm = rsqrtf(s2[1] / (float)H + 1e-6f);
    const long o = ((long)r * 4 + ctrl) * H;
    bf16* u = w.ub + ((long)r * 4 + ctrl) * 2 * H;
#pragma unroll
    for (int j = 0; j < RPJ; j++) {
      const int el = REL(j);
      *reinterpret_cast<float2*>(w.xg + o + el) = make_float2(x[2 * j], x[2 * j + 1]);
      *reinterpret_cast<float2*>(w.mg + o + el) = make_float2(m[2 * j], m[2 * j + 1]);
      *reinterpret_cast<uint32_t*>(u + el) = pack_bf2(x[2 * j] * rx, x[2 * j + 1] * rx);
      *reinterpret_cast<uint32_t*>(u + H + el) = pack_bf2(m[2 * j] * rm, m[2 * j + 1] * rm);
    }
  }
}
// gate D: gv[r][ctrl][j] = bf16((D_ctrl ub[r][ctrl])[j]); tasks (ctrl, strip of 16)
__device__ __forceinline__ void ph_gate_dg(WARGS, int a, int c0, int nc) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R;
  for (int task = blockIdx.x; task < nc * 4; task += gridDim.x) {
    const int ctrl = c0 + task / 4, strip = ctrl * 4 + task % 4;
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = (s - ctrl * 4) * 16 + g + 8 * (i >> 1);
        if (r < R) w.gv[((long)r * 4 + ctrl) * 64 + row] = rbf(av[i]);
      }
    };
    DG2(R, 16, 32, sm, L.cD, 72, strip, strip + 1, w.ub + (long)ctrl * 2 * H, 4L * 2 * H, R, epi);
  }
}
// gate F / G: x' = (1 - tanh(F gv)) x + tanh(G gv) m; one warp per (ctrl, strip of 8 (F, G) row pairs)
template <int NG>
__device__ __forceinline__ void gate_fg_t(WARGS, int a, int c0, int nc) {
  const App& ap = c.A[a];
  const uint8_t* FG = w.fg[ap.layer];
  const int R = sm.R;
  for (int i = threadIdx.x; i < R * 4 * 64; i += NT) {
    const int r = i / 256, cc = (i / 64) & 3, j = i & 63;
    sm.u.gvs[r][cc][j] = tobf(ldf(w.gv + i));
  }
  for (int i = threadIdx.x; i < (NG * 8 - R) * 4 * 64; i += NT) {
    const int r = R + i / 256, cc = (i / 64) & 3, j = i & 63;
    sm.u.gvs[r][cc][j] = tobf(0.f);
  }
  __syncthreads();
  const int lane = lane_id(), g = lane >> 2, t = lane & 3;
  const int nt = nc * 288;
  for (int wt = blockIdx.x * NW + (threadIdx.x >> 5); wt < nt; wt += gridDim.x * NW) {
    const int ctrl = c0 + wt / 288, strip = wt % 288;
    const uint8_t* ws = FG + ((long)ctrl * 288 + strip) * 2048;
    uint4 wc[4];
#pragma unroll
    for (int jj = 0; jj < 4; jj++) wc[jj] = ldg_nc(ws + jj * 512 + lane * 16);
    float acc[NG][4];
#pragma unroll
    for (int ng = 0; ng < NG; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
#pragma unroll
    for (int jj = 0; jj < 4; jj++)
#pragma unroll
      for (int ng = 0; ng < NG; ng++) {
        const uint32_t b0 = *reinterpret_cast<const uint32_t*>(&sm.u.gvs[ng * 8 + g][ctrl][jj * 16 + 2 * t]);
        const uint32_t b1 = *reinterpret_cast<const uint32_t*>(&sm.u.gvs[ng * 8 + g][ctrl][jj * 16 + 8 + 2 * t]);
        mma_bf16(acc[ng], wc[jj].x, wc[jj].y, wc[jj].z, wc[jj].w, b0, b1);
      }
    // rows strip*16 + g (+8): pair i = row / 2, F if row even, G if odd; the partner row is lane ^ 4
#pragma unroll
    for (int ng = 0; ng < NG; ng++)
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const float f = tanhf(acc[ng][i]);
        const float o = __shfl_xor_sync(0xffffffffu, f, 4);
        const int r = ng * 8 + 2 * t + (i & 1), row = strip * 16 + g + 8 * (i >> 1), ch = row >> 1;
        if ((g & 1) == 0 && r < R) {
          const long off = ((long)r * 4 + ctrl) * H + ch;
          const float mine = (1.f - f) * ldf(w.xg + off), other = o * ldf(w.mg + off);
          w.xp[off] = mine + other;
        }
      }
  }
}
__device__ __forceinline__ void ph_gate_fg(WARGS, int a, int c0, int nc) {
  const int R = sm.R;
  if (R <= 8) gate_fg_t<1>(w, c, hd, sm, a, c0, nc);
  else if (R <= 16) gate_fg_t<2>(w, c, hd, sm, a, c0, nc);
  else if (R <= 32) gate_fg_t<4>(w, c, hd, sm, a, c0, nc);
  else gate_fg_t<8>(w, c, hd, sm, a, c0, nc);
}
// gated rows -> the attention-input streams (ctrl < 3) or the MLP input (ctrl 3)
__device__ __forceinline__ void ph_gate_norm(WARGS, int a, int c0, int nc) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R, gi = GI, gt = GT;
  for (int job = GID; job < R * nc; job += GROUPS) {
    const int r = job / nc, ctrl = c0 + job % nc;
    float x[2 * RPJ];
    const float* src = w.xp + ((long)r * 4 + ctrl) * H;
#pragma unroll
    for (int j = 0; j < RPJ; j++) { const float2 f = __ldcg(reinterpret_cast<const float2*>(src + REL(j))); x[2 * j] = f.x; x[2 * j + 1] = f.y; }
    if (ctrl < 3) g_norm_store(x, L.norm[ctrl], w.X + ((long)ctrl * MAXR + r) * H, sm, gi, gt);
    else mlp_norm(w, c, hd, sm, a, r, x);
  }
}

// qkv: tasks of up to 4 strips of one input stream; epilogue: qkv[r][row] = bf16-rounded; raw k / v -> rings
__device__ __forceinline__ void ph_qkv(WARGS, int a, int nq) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R, nsk = L.nsk;
  const int nst = QG_STRIPS + 2 * nsk;
  int nt0, nt1;
  if (nq == 1) { nt0 = (nst + 3) / 4; nt1 = 0; }
  else { nt0 = (QG_STRIPS + 3) / 4; nt1 = (nsk + 3) / 4; }
  const int ntask = nt0 + 2 * nt1;
  for (int task = blockIdx.x; task < ntask; task += gridDim.x) {
    int sb, se, st;
    if (nq == 1) { sb = task * 4; se = min(sb + 4, nst); st = 0; }
    else if (task < nt0) { sb = task * 4; se = min(sb + 4, QG_STRIPS); st = 0; }
    else { const int k = task - nt0; st = 1 + k / nt1; const int b0 = QG_STRIPS + (st - 1) * nsk; sb = b0 + (k % nt1) * 4; se = min(sb + 4, b0 + nsk); }
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const int orow = s < QG_STRIPS ? s * 16 : (s < QG_STRIPS + nsk ? K0 + (s - QG_STRIPS) * 16 : V0 + (s - QG_STRIPS - nsk) * 16);
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = orow + g + 8 * (i >> 1);
        if (r >= R) continue;
        const float v = rbf(av[i]);
        w.qkv[(long)r * QKVR + row] = v;
        if (row >= K0 && row < K0 + 1024) w.hk[ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * 1024 + row - K0] = tobf(v);
        else if (row >= V0 && row < V0 + 1024) w.hv[ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * 1024 + row - V0] = tobf(v);
      }
    };
    DG2(R, 4, 36, sm, L.wqkv, 36, sb, se, w.X + (long)st * MAXR * H, (long)H, R, epi);
  }
}
// k / v of every row: short conv over positions (raw values from the rings), clip (k) / rms norm (v) -> caches
__device__ __forceinline__ void ph_kv(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R, lane = lane_id();
  for (int wt = blockIdx.x * NW + (threadIdx.x >> 5); wt < R * 16; wt += gridDim.x * NW) {
    const int r = wt >> 4, g = (wt >> 1) & 7, isv = wt & 1;
    const int seq = rseq(sm, r), t = rpos(sm, r);
    const int base = isv ? V0 : K0;
    const bf16* hist = (isv ? w.hv : w.hk);
    const bf16* sc = isv ? L.vsc : L.ksc;
    const float* qr = w.qkv + (long)r * QKVR;
    float kv[4], ss = 0.f;
    float dyn[4] = {0.f, 0.f, 0.f, 0.f};
    if (L.glob) {
#pragma unroll
      for (int lag = 0; lag < 4; lag++) dyn[lag] = ldf(qr + base + 1024 + g * 4 + lag);
    }
#pragma unroll
    for (int k = 0; k < 4; k++) {
      const int ch = g * HD + lane * 4 + k;
      const float x = ldf(qr + base + ch);
      const float x1 = bf(hist[ring_row(ap.slot, seq, t - 1) * 1024 + ch]);
      const float x2 = bf(hist[ring_row(ap.slot, seq, t - 2) * 1024 + ch]);
      const float x3 = bf(hist[ring_row(ap.slot, seq, t - 3) * 1024 + ch]);
      float y;
      if (!L.glob) {
        const uint2 wv = *reinterpret_cast<const uint2*>(sc + ch * 4);
        const bf16* w4 = reinterpret_cast<const bf16*>(&wv);
        float acc = __fmul_rn(x3, bf(w4[0]));
        acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
        acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
        acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
        y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f));
      } else {
        const float xs4[4] = {x, x1, x2, x3};
        float acc = 0.f;
#pragma unroll
        for (int lag = 0; lag < 4; lag++) acc = __fadd_rn(acc, __fmul_rn(xs4[lag], __fadd_rn(bf(sc[lag * 1024 + ch]), dyn[lag])));
        y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.33333333333333333f));
      }
      kv[k] = y;
      ss = fmaf(y, y, ss);
    }
#pragma unroll
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
    const float f = isv ? rsqrtf(ss / 128.f + 1e-6f) : fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
    bf16* dst = (isv ? w.vc : w.kc) + ((((long)ap.slot * NSQ + seq) * NKV + g) * w.maxctx + t) * HD + lane * 4;
    uint2 pk;
    pk.x = pack_bf2(kv[0] * f, kv[1] * f);
    pk.y = pack_bf2(kv[2] * f, kv[3] * f);
    *reinterpret_cast<uint2*>(dst) = pk;
  }
}

// attention: items (sequence, kv head g, chunk c of 128 absolute key positions); every row of the sequence (<= 8) x
// 3 query heads = 24 query rows; per (row, head, chunk) a record (m, l, o); the last item of (sequence, g) merges the
// records of each row's own chunk range in increasing order and applies the output gate and the sink
__device__ __forceinline__ void ph_attn(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int glob = L.glob;
  const int tid = threadIdx.x, wp = tid >> 5, lane = tid & 31, g8 = lane >> 2, t4 = lane & 3;
  auto& at = sm.u.at;
  int ncs[NSQ], cmn[NSQ], nitem = 0;
  for (int i = 0; i < sm.nsq; i++) {
    const int t0 = rpos(sm, sm.sq_r0[i]), t1 = t0 + sm.sq_n[i] - 1;
    cmn[i] = (glob ? 0 : max(0, t0 + 1 - 1024)) / ACH;
    ncs[i] = t1 / ACH - cmn[i] + 1;
    nitem += NKV * ncs[i];
  }
  const float NEG = -__int_as_float(0x7f800000);
  for (int it = blockIdx.x; it < nitem; it += gridDim.x) {
    int i = 0, rem = it;
    while (rem >= NKV * ncs[i]) { rem -= NKV * ncs[i]; i++; }
    const int g = rem / ncs[i], ch = cmn[i] + rem % ncs[i];
    const int seq = sm.sq_seq[i], r0 = sm.sq_r0[i], n = sm.sq_n[i], t0 = rpos(sm, r0), tmax = t0 + n - 1;
    const int k0 = ch * ACH, nk = min(ACH, tmax + 1 - k0), ntile = (nk + 15) >> 4;
    const long cb = (((long)ap.slot * NSQ + seq) * NKV + g) * w.maxctx;
    {
      const bf16* kb = w.kc + (cb + k0) * HD;
      const bf16* vb = w.vc + (cb + k0) * HD;
      for (int q = tid; q < nk * 16; q += NT) {
        const int rr = q >> 4, cc = (q & 15) * 8;
        cp_async16(&at.kk[rr][cc], kb + (long)q * 8);
        cp_async16(&at.vv[rr][cc], vb + (long)q * 8);
      }
      cp_commit();
      for (int q = tid; q < (ntile * 16 - nk) * 16; q += NT) {
        const int rr = nk + (q >> 4), cc = (q & 15) * 8;
        *reinterpret_cast<uint4*>(&at.kk[rr][cc]) = make_uint4(0, 0, 0, 0);
        *reinterpret_cast<uint4*>(&at.vv[rr][cc]) = make_uint4(0, 0, 0, 0);
      }
      for (int q = tid; q < 8 * (ACH + 8) / 2; q += NT) {
        reinterpret_cast<uint32_t*>(&at.ph[24][0])[q] = 0u;
        reinterpret_cast<uint32_t*>(&at.pl[24][0])[q] = 0u;
      }
    }
    // q (scaled, L2-clipped) and the relative-position features, per query row qi = 3 j + hh
    for (int qi = wp; qi < 24; qi += NW) {
      const int j = qi / 3, hh = qi % 3, h = 3 * g + hh;
      if (j < n) {
        const float* qr = w.qkv + (long)(r0 + j) * QKVR;
        float qv[4], ss = 0.f;
#pragma unroll
        for (int k = 0; k < 4; k++) {
          const int d = lane * 4 + k;
          qv[k] = ldf(qr + h * HD + d) * bf(L.qscale[h * HD + d]);
          ss = fmaf(qv[k], qv[k], ss);
        }
#pragma unroll
        for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
        const float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
#pragma unroll
        for (int k = 0; k < 4; k++) at.qb[qi][lane * 4 + k] = tobf(qv[k] * f);
        float rv = 0.f, s2 = 0.f;
        if (lane < 16) { rv = ldf(qr + R_R + h * 16 + lane) * bf(L.rscale[h * 16 + lane]); s2 = rv * rv; }
#pragma unroll
        for (int o = 16; o; o >>= 1) s2 += __shfl_xor_sync(0xffffffffu, s2, o);
        const float f2 = fminf(8.0f / (sqrtf(s2) + 1e-6f), 1.0f);
        if (lane < 16) at.rr[qi][lane] = rbf(rv * f2);
      } else {
#pragma unroll
        for (int k = 0; k < 4; k++) at.qb[qi][lane * 4 + k] = tobf(0.f);
        if (lane < 16) at.rr[qi][lane] = 0.f;
      }
    }
    __syncthreads();
    // relative bias (0 beyond distance 1023) or -inf outside the row's window
    for (int q = tid; q < 24 * ACH; q += NT) {
      const int qi = q / ACH, kk = q % ACH, j = qi / 3;
      float v = NEG;
      if (j < n && kk < nk) {
        const int key = k0 + kk, t = t0 + j, lo = glob ? 0 : max(0, t + 1 - 1024);
        if (key >= lo && key <= t) {
          const int dist = t - key;
          if (dist < 1024) {
            float bsum = 0.f;
#pragma unroll
            for (int rr = 0; rr < 16; rr++) bsum += at.rr[qi][rr] * bf(L.relp[rr * 1024 + dist]);
            v = rbf(bsum);
          } else v = 0.f;
        }
      }
      at.sc[qi][kk] = v;
    }
    cp_wait<0>();
    __syncthreads();
    // scores S[qi][key] = (K q) / sqrt(128) + bias: warp task (key tile, query n-tile)
    for (int task = wp; task < ntile * 3; task += NW) {
      const int kt = task / 3, nt = task % 3;
      float acc[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
      for (int ks = 0; ks < HD / 16; ks++) {
        uint32_t af[4];
        ldsm_x4(af, &at.kk[16 * kt + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        const uint32_t b0 = *reinterpret_cast<const uint32_t*>(&at.qb[nt * 8 + g8][16 * ks + 2 * t4]);
        const uint32_t b1 = *reinterpret_cast<const uint32_t*>(&at.qb[nt * 8 + g8][16 * ks + 8 + 2 * t4]);
        mma_bf16(acc, af[0], af[1], af[2], af[3], b0, b1);
      }
#pragma unroll
      for (int q = 0; q < 4; q++) {
        const int key = 16 * kt + g8 + (q >> 1) * 8, qi = nt * 8 + 2 * t4 + (q & 1);
        if (key < nk) { const float b = at.sc[qi][key]; if (b != NEG) at.sc[qi][key] = acc[q] * 0.08838834764831845f + b; }
      }
    }
    __syncthreads();
    // softmax per query row over the chunk: p = exp(s - m) as bf16 hi + lo
    for (int qi = wp; qi < 24; qi += NW) {
      float m = NEG;
#pragma unroll
      for (int k = 0; k < 4; k++) { const int kk = lane + 32 * k; if (kk < nk) m = fmaxf(m, at.sc[qi][kk]); }
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, o));
      float l = 0.f;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int kk = lane + 32 * k;
        const float s = kk < nk ? at.sc[qi][kk] : NEG;
        const float e = (s != NEG) ? expf(s - m) : 0.f;
        const bf16 eh = tobf(e);
        at.ph[qi][kk] = eh;
        at.pl[qi][kk] = tobf(e - bf(eh));
        l += e;
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffffu, l, o);
      if (lane == 0) { sm.mlm[qi] = m; sm.mll[qi] = l; }
    }
    __syncthreads();
    // O[qi][d] = sum_key (Phi + Plo)[qi][key] V[key][d]: warp = (m-tile w / 8, dims 16 (w % 8) .. + 15)
    {
      const int mt = wp >> 3, wd = wp & 7;
      float acc[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
      for (int ks = 0; ks < ntile; ks++) {
        uint32_t ah[4], al[4], bv[4];
        ldsm_x4(ah, &at.ph[16 * mt + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        ldsm_x4(al, &at.pl[16 * mt + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        ldsm_x4_t(bv, &at.vv[16 * ks + (lane & 15)][16 * wd + (lane >> 4) * 8]);
        mma_bf16(acc[0], ah[0], ah[1], ah[2], ah[3], bv[0], bv[1]);
        mma_bf16(acc[0], al[0], al[1], al[2], al[3], bv[0], bv[1]);
        mma_bf16(acc[1], ah[0], ah[1], ah[2], ah[3], bv[2], bv[3]);
        mma_bf16(acc[1], al[0], al[1], al[2], al[3], bv[2], bv[3]);
      }
#pragma unroll
      for (int nt = 0; nt < 2; nt++)
#pragma unroll
        for (int q = 0; q < 4; q++) {
          const int qi = 16 * mt + g8 + 8 * (q >> 1), d = 16 * wd + 8 * nt + 2 * t4 + (q & 1);
          if (qi < 3 * n) {
            const int r = r0 + qi / 3, h = 3 * g + qi % 3;
            w.arec[(((long)r * NQH + h) * MAXCHW + ch) * 130 + 2 + d] = acc[nt][q];
          }
        }
    }
    if (tid < 3 * n) {
      const int r = r0 + tid / 3, h = 3 * g + tid % 3;
      w.arec[(((long)r * NQH + h) * MAXCHW + ch) * 130] = sm.mlm[tid];
      w.arec[(((long)r * NQH + h) * MAXCHW + ch) * 130 + 1] = sm.mll[tid];
    }
    __threadfence();
    __syncthreads();
    if (tid == 0) {
      const unsigned old = atomicAdd(&w.acnt[seq * NKV + g], 1u);
      sm.flag = (old == (unsigned)(ncs[i] - 1));
    }
    __syncthreads();
    if (sm.flag) {
      __threadfence();
      for (int q = tid; q < 3 * n * HD; q += NT) {
        const int qi = q / HD, d = q % HD, j = qi / 3, h = 3 * g + qi % 3, r = r0 + j, t = t0 + j;
        const int cl = (glob ? 0 : max(0, t + 1 - 1024)) / ACH, chh = t / ACH;
        const float* rec = w.arec + ((long)r * NQH + h) * MAXCHW * 130;
        float M = NEG;
        for (int k = cl; k <= chh; k++) M = fmaxf(M, ldf(rec + k * 130));
        float S = 0.f, O = 0.f;
        for (int k = cl; k <= chh; k++) {
          const float e = expf(ldf(rec + k * 130) - M);
          S = fmaf(ldf(rec + k * 130 + 1), e, S);
          O = fmaf(ldf(rec + k * 130 + 2 + d), e, O);
        }
        const float* qr = w.qkv + (long)r * QKVR;
        const float gate = ldf(qr + R_G + h * HD + d), sink = ldf(qr + R_S + h);
        const float lse = M + logf(S);
        w.ao[(long)r * QW + h * HD + d] = tobf((O / S) * sigm(gate) * sigm(lse - sink));
      }
      if (tid == 0) w.acnt[seq * NKV + g] = 0u;
    }
    __syncthreads();
  }
}

// o_proj: one strip per task; epilogue: raw output (bf16) -> the ha ring (the conv runs in the MLP-input phase)
__device__ __forceinline__ void ph_oproj(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R;
  for (int task = blockIdx.x; task < 144; task += gridDim.x) {
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = s * 16 + g + 8 * (i >> 1);
        if (r < R) w.ha[ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * H + row] = tobf(av[i]);
      }
    };
    DG2(R, 16, 32, sm, L.wo, 48, task, task + 1, w.ao, (long)QW, R, epi);
  }
}
__device__ __forceinline__ void ph_router(WARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R;
  for (int task = blockIdx.x; task < 8; task += gridDim.x) {
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = s * 16 + g + 8 * (i >> 1);
        if (r < R) w.rl[(long)r * NE + row] = av[i];
      }
    };
    DG2(R, 16, 32, sm, L.wr, 36, task, task + 1, w.y, (long)H, R, epi);
  }
}
// top-8 per row (every block, identical) + per expert the (row, rank) list in row order + chunks of <= XTOK tokens
__device__ __forceinline__ void routing(WARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R, wp = threadIdx.x >> 5, lane = lane_id();
  for (int r = wp; r < R; r += NW) {
    float lg[4], sel[4];
#pragma unroll
    for (int k = 0; k < 4; k++) {
      const int e = lane + 32 * k;
      lg[k] = ldf(w.rl + (long)r * NE + e);
      sel[k] = sigm(lg[k]) + L.rbias[e];
      if (!(sel[k] == sel[k])) sel[k] = -1e30f;
    }
    unsigned taken = 0, key[4];
    int myid = 0; float mylg = 0.f;
#pragma unroll
    for (int k = 0; k < 4; k++) { const unsigned u = __float_as_uint(sel[k]); key[k] = (u & 0x80000000u) ? ~u : (u | 0x80000000u); }
    for (int rk = 0; rk < TOPK; rk++) {
      unsigned bk = 0u; int bi_l = 0x7fffffff; float bl_l = 0.f;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const bool ok = !(taken & (1u << k));
        if (ok && (key[k] > bk || bi_l == 0x7fffffff)) { bk = key[k]; bi_l = lane + 32 * k; bl_l = lg[k]; }
      }
      const unsigned mk = __reduce_max_sync(0xffffffffu, bk);
      int bi = (int)__reduce_min_sync(0xffffffffu, (bk == mk && bi_l != 0x7fffffff) ? (unsigned)bi_l : 0x7fffffffu);
      bi = bi < NE ? bi : 0;
      const float bl = __shfl_sync(0xffffffffu, bl_l, bi & 31);
      if ((bi & 31) == lane) taken |= 1u << (bi >> 5);
      if (lane == rk) { myid = bi; mylg = bl; }
    }
    const float sg = sigm(mylg);
    float den = 0.f;
#pragma unroll
    for (int rk = 0; rk < TOPK; rk++) den += __shfl_sync(0xffffffffu, sg, rk);
    const float wt = sg / den * 8.0f;
    int rank = 0;
#pragma unroll
    for (int rk = 0; rk < TOPK; rk++) rank += (__shfl_sync(0xffffffffu, myid, rk) < myid);
    if (lane < TOPK) { sm.tex[r][rank] = myid; sm.twt[r][rank] = wt; }
  }
  __syncthreads();
  if (threadIdx.x < NE) {
    const int e = threadIdx.x;
    int n = 0;
    for (int r = 0; r < R; r++)
      for (int k = 0; k < TOPK; k++) n += (sm.tex[r][k] == e);
    sm.eoff[e + 1] = n;
  }
  __syncthreads();
  if (threadIdx.x == 0) {
    sm.eoff[0] = 0;
    for (int e = 0; e < NE; e++) sm.eoff[e + 1] += sm.eoff[e];
    int nc = 0, cost = 0;
    for (int e = 0; e < NE; e++) {
      const int n = sm.eoff[e + 1] - sm.eoff[e];
      for (int j0 = 0; j0 < n; j0 += XTOK) {
        const int m = min(XTOK, n - j0);
        sm.chk_e[nc] = e; sm.chk_j0[nc] = sm.eoff[e] + j0; sm.chk_n[nc] = m; sm.chk_cost0[nc] = cost;
        cost += 144 * (3 + (m + 3) / 4);
        nc++;
      }
    }
    sm.chk_cost0[nc] = cost;
    sm.nchk = nc;
  }
  __syncthreads();
  if (threadIdx.x < NE) {
    const int e = threadIdx.x;
    int p = sm.eoff[e];
    for (int r = 0; r < R; r++)
      for (int k = 0; k < TOPK; k++)
        if (sm.tex[r][k] == e) sm.elist[p++] = (short)(r * TOPK + k);
  }
  __syncthreads();
}
// the block's item range [ib, ie) of (chunk, strip) items, balanced by cost
__device__ __forceinline__ int item_at_cost(const Smem& sm, long x) {
  int k = 0;
  while (k < sm.nchk && sm.chk_cost0[k + 1] <= x) k++;
  if (k >= sm.nchk) return sm.nchk * 144;
  const int cu = (sm.chk_cost0[k + 1] - sm.chk_cost0[k]) / 144;
  const long s = (x - sm.chk_cost0[k] + cu - 1) / cu;
  return k * 144 + (int)min(s, 144L);
}
// a warp's items it = i0 + wp + 16 k (< i1) of one (expert, chunk) group, their units streamed through the warp's
// shared-memory ring (cp.async, D units ahead, across item boundaries); per item the units in increasing order
template <bool W13, bool MX, int NGN>
__device__ __forceinline__ void moe_warp(const WCtx& w, const LayerW& L, Smem& sm, int e, int j0, int n, int i0, int i1, const __half* xs) {
  constexpr int U = W13 ? 36 : 18;
  constexpr int UB = MX ? 1056 : 576;
  constexpr int D = WRING / UB;
  constexpr int KS = (W13 ? H : IE) + 8;
  const int lane = lane_id(), g = lane >> 2, t = lane & 3, wp = threadIdx.x >> 5;
  const int nit = (i1 - i0 - wp + NW - 1) / NW;
  if (nit <= 0) return;
  const int N = nit * U;
  unsigned char* ring = W13 ? sm.u.m13.ring[wp] : sm.u.m2.ring[wp];
  const uint8_t* wbase = (W13 ? L.w13 : L.w2) + (long)e * 144 * U * UB;
  auto issue = [&](int q) {
    if (q < N) {
      const int it = i0 + wp + NW * (q / U), strip = it % 144;
      const uint8_t* src = wbase + ((long)strip * U + q % U) * UB;
      unsigned char* dst = ring + (q % D) * UB;
      if (MX) { cp_async16(dst + lane * 32, src + lane * 32); cp_async16(dst + lane * 32 + 16, src + lane * 32 + 16); if (lane < 2) cp_async16(dst + 1024 + lane * 16, src + 1024 + lane * 16); }
      else { cp_async16(dst + lane * 16, src + lane * 16); if (lane < 4) cp_async16(dst + 512 + lane * 16, src + 512 + lane * 16); }
    }
    cp_commit();
  };
#pragma unroll 1
  for (int q = 0; q < D; q++) issue(q);
  const __half* colp[NGN];
#pragma unroll
  for (int ng = 0; ng < NGN; ng++) {
    const int li = 4 * ng + (g >> 1), part = g & 1;
    colp[ng] = li < n ? xs + ((long)li * 2 + part) * KS : nullptr;
  }
  float acc[NGN][4];
#pragma unroll
  for (int ng = 0; ng < NGN; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  const float fac = MX ? 1.0f : (W13 ? L.f13[e] : L.f2[e]);
#pragma unroll 1
  for (int q = 0; q < N; q++) {
    cp_wait<D - 1>();
    __syncwarp();
    const unsigned char* src = ring + (q % D) * UB;
    const int u = q % U;
    uint2 bfr[NGN][4];
    load_b16_unit<NGN>(colp, u, bfr);
    if (MX) {
      const uint4 c0 = *reinterpret_cast<const uint4*>(src + lane * 32), c1 = *reinterpret_cast<const uint4*>(src + lane * 32 + 16);
      const uint32_t sw = *reinterpret_cast<const uint32_t*>(src + 1024 + g * 4);
      unit_fp8<NGN>(c0, c1, sw, bfr, acc);
    } else {
      const uint4 cw = *reinterpret_cast<const uint4*>(src + lane * 16);
      const uint2 sw = *reinterpret_cast<const uint2*>(src + 512 + g * 8);
      unit_fp4<NGN>(cw, sw, bfr, acc);
    }
    __syncwarp();
    issue(q + D);
    if (u == U - 1) {
      const int strip = (i0 + wp + NW * (q / U)) % 144;
      if (W13) {
#pragma unroll
        for (int ng = 0; ng < NGN; ng++) {
          const int li = 4 * ng + t;
          const bool ok = li < n;
          const int ent = ok ? sm.elist[j0 + li] : 0;
          const int r = ent >> 3, rk = ent & 7;
          const float s16 = ok ? ldf(w.s16 + r) : 0.f;
          const float h0 = rbf((acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * s16 * fac);
          const float h1 = rbf((acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * s16 * fac);
          const float o0 = __shfl_xor_sync(0xffffffffu, h0, 4), o1 = __shfl_xor_sync(0xffffffffu, h1, 4);
          const float wgt = ok ? sm.twt[r][rk] : 0.f;
          const float act0 = rbf(act_fn(h0, o0) * wgt), act1 = rbf(act_fn(h1, o1) * wgt);
          const float v0 = act0 * 16.0f, v1 = act1 * 16.0f;
          const __half hi0 = __float2half_rn(v0), hi1 = __float2half_rn(v1);
          const __half lo0 = __float2half_rn((v0 - __half2float(hi0)) * 16777216.0f), lo1 = __float2half_rn((v1 - __half2float(hi1)) * 16777216.0f);
          if (ok && (g & 1) == 0) {
            __half* dst = w.act16 + (long)ent * 2 * IE;
            const int p0 = strip * 8 + (g >> 1), p1 = strip * 8 + 4 + (g >> 1);
            dst[p0] = hi0; dst[IE + p0] = lo0;
            dst[p1] = hi1; dst[IE + p1] = lo1;
          }
        }
      } else {
        const float f2 = fac * 0.0625f;
#pragma unroll
        for (int ng = 0; ng < NGN; ng++) {
          const int li = 4 * ng + t;
          if (li < n) {
            const int ent = sm.elist[j0 + li];
            float* dst = w.w2c + (long)ent * H + strip * 16;
            dst[g] = (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * f2;
            dst[g + 8] = (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * f2;
          }
        }
      }
#pragma unroll
      for (int ng = 0; ng < NGN; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
    }
  }
  cp_wait<0>();
}
template <bool W13>
__device__ __forceinline__ void ph_moe(WARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const long C = sm.chk_cost0[sm.nchk];
  const int ib = item_at_cost(sm, C * blockIdx.x / gridDim.x);
  const int ie = (blockIdx.x + 1 == gridDim.x) ? sm.nchk * 144 : item_at_cost(sm, C * (blockIdx.x + 1) / gridDim.x);
  constexpr int KK = W13 ? H : IE;
  constexpr int KS = KK + 8;
  __half* xs = W13 ? &sm.u.m13.xs[0][0][0] : &sm.u.m2.xs[0][0][0];
  for (int i0 = ib; i0 < ie;) {
    const int k = i0 / 144, i1 = min(ie, (k + 1) * 144);
    const int e = sm.chk_e[k], j0 = sm.chk_j0[k], n = sm.chk_n[k];
    {
      constexpr int NCK = KK / 8;
      for (int q = threadIdx.x; q < n * 2 * NCK; q += NT) {
        const int li = q / (2 * NCK), part = (q / NCK) & 1, cc = q % NCK;
        const int ent = sm.elist[j0 + li];
        const __half* src = W13 ? w.x16 + ((long)(ent >> 3) * 2 + part) * H : w.act16 + ((long)ent * 2 + part) * IE;
        cp_async16(xs + ((long)li * 2 + part) * KS + cc * 8, src + cc * 8);
      }
      cp_commit(); cp_wait<0>();
    }
    __syncthreads();
    if (n > 4) { if (L.mx) moe_warp<W13, true, 2>(w, L, sm, e, j0, n, i0, i1, xs); else moe_warp<W13, false, 2>(w, L, sm, e, j0, n, i0, i1, xs); }
    else { if (L.mx) moe_warp<W13, true, 1>(w, L, sm, e, j0, n, i0, i1, xs); else moe_warp<W13, false, 1>(w, L, sm, e, j0, n, i0, i1, xs); }
    __syncthreads();
    i0 = i1;
  }
}
// MoE output: per row the 8 expert rows summed in expert-id order -> xm and the hm ring
__device__ __forceinline__ void ph_w2sum(WARGS, int a) {
  const App& ap = c.A[a];
  const int R = sm.R;
  for (int q = blockIdx.x * NT + threadIdx.x; q < R * (H / 2); q += gridDim.x * NT) {
    const int r = q / (H / 2), i = (q % (H / 2)) * 2;
    float s0 = 0.f, s1 = 0.f;
#pragma unroll
    for (int k = 0; k < TOPK; k++) {
      const float2 v = __ldcg(reinterpret_cast<const float2*>(w.w2c + ((long)r * TOPK + k) * H + i));
      s0 += v.x; s1 += v.y;
    }
    const uint32_t pk = pack_bf2(s0, s1);
    *reinterpret_cast<uint32_t*>(w.xm + (long)r * H + i) = pk;
    *reinterpret_cast<uint32_t*>(w.hm + ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * H + i) = pk;
  }
}
// MoE conv + the new partial pb[out] = (pin + as) + ms (boundary layers: as + ms)
__device__ __forceinline__ void ph_w2conv(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R;
  const bool addp = !(a == 0 || ap.bnd);
  for (int q = blockIdx.x * NT + threadIdx.x; q < R * (H / 2); q += gridDim.x * NT) {
    const int r = q / (H / 2), i = (q % (H / 2)) * 2;
    const int seq = rseq(sm, r), t = rpos(sm, r);
    const uint32_t v0 = ldu(w.xm + (long)r * H + i);
    const uint32_t v1 = ldu(w.hm + ring_row(ap.slot, seq, t - 1) * H + i);
    const uint32_t v2 = ldu(w.hm + ring_row(ap.slot, seq, t - 2) * H + i);
    const uint32_t v3 = ldu(w.hm + ring_row(ap.slot, seq, t - 3) * H + i);
    const uint2 wa = *reinterpret_cast<const uint2*>(L.mlp_sc + i * 4), wb = *reinterpret_cast<const uint2*>(L.mlp_sc + i * 4 + 4);
    const float m0 = rbf(sconv_static(bf_lo(v0), bf_lo(v1), bf_lo(v2), bf_lo(v3), reinterpret_cast<const bf16*>(&wa)));
    const float m1 = rbf(sconv_static(bf_hi(v0), bf_hi(v1), bf_hi(v2), bf_hi(v3), reinterpret_cast<const bf16*>(&wb)));
    const uint32_t av = ldu(w.as + (long)r * H + i);
    float n0, n1;
    if (addp) {
      const uint32_t pv = ldu(w.pb + ((long)ap.pin * MAXR + r) * H + i);
      n0 = (bf_lo(pv) + bf_lo(av)) + m0; n1 = (bf_hi(pv) + bf_hi(av)) + m1;
    } else { n0 = bf_lo(av) + m0; n1 = bf_hi(av) + m1; }
    *reinterpret_cast<uint32_t*>(w.pb + ((long)ap.out * MAXR + r) * H + i) = pack_bf2(n0, n1);
  }
}
// final: output mix -> norm -> xf; unembedding -> 30 tanh(z / 30) -> logits, argmax
__device__ __forceinline__ void ph_fin_mix(WARGS) {
  const int gi = GI, gt = GT;
  for (int r = GID; r < sm.R; r += GROUPS) {
    uint32_t v[5][RPJ];
    const unsigned msk = ((1u << c.nfin) - 1u) | 16u;
#pragma unroll
    for (int s = 0; s < 5; s++) {
      const int idx = s < 4 ? c.fin[s] : c.fin_pin;
      if ((msk >> s) & 1u) ld_row(w.pb + ((long)idx * MAXR + r) * H, v[s], gt);
      else {
#pragma unroll
        for (int j = 0; j < RPJ; j++) v[s][j] = 0u;
      }
    }
    float x[2 * RPJ];
    g_mix<5>(v, nullptr, -1, msk, c.oq, x, sm, gi, gt);
    g_norm_store(x, c.fnorm, w.xf + (long)r * H, sm, gi, gt);
  }
}
template <int NG>
__device__ __forceinline__ void unembed_t(WARGS) {
  const int R = sm.R;
  const int ntask = (UN_STRIPS + 3) / 4;
  for (int i = threadIdx.x; i < MAXR; i += NT) sm.ubest[i] = 0ull;
  __syncthreads();
  for (int task = blockIdx.x; task < ntask; task += gridDim.x) {
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
      unsigned long long kb[2] = {0ull, 0ull};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = s * 16 + g + 8 * (i >> 1);
        if (r >= R || row >= VOCAB_REAL) continue;
        const float z = 30.0f * tanhf(av[i] / 30.0f);
        if (hd.logits) hd.logits[(long)r * VOCAB_REAL + row] = z;
        unsigned u = __float_as_uint(z);
        u = (u & 0x80000000u) ? ~u : (u | 0x80000000u);
        const unsigned long long key = ((unsigned long long)u << 32) | (unsigned)(0xFFFFFFFFu - row);
        if (key > kb[i & 1]) kb[i & 1] = key;
      }
#pragma unroll
      for (int cc = 0; cc < 2; cc++) {
        unsigned long long k = kb[cc];
#pragma unroll
        for (int o = 4; o < 32; o <<= 1) { const unsigned long long ok = __shfl_xor_sync(0xffffffffu, k, o); if (ok > k) k = ok; }
        const int r = ng * 8 + 2 * t + cc;
        if (g == 0 && r < R && k) atomicMax(&sm.ubest[r], k);
      }
    };
    dgemm2<(NG > 4 ? 4 : NG), 4, 36>(sm, c.unembed, 36, task * 4, min(task * 4 + 4, UN_STRIPS), w.xf, (long)H, R, epi);
  }
  __syncthreads();
  for (int r = threadIdx.x; r < R; r += NT) if (sm.ubest[r]) atomicMax(w.amax + r, sm.ubest[r]);
}

// ------------------------------------------------------------------------------------------------ kernels
// one kernel per phase (own registers and shared-memory size); the host launches them in order on one stream
__device__ __forceinline__ void load_rows(const WHdr& hd, Smem& sm) {
  const int R = min(max(hd.rows[0], 0), MAXR);
  for (int i = threadIdx.x; i < R * 4; i += NT) sm.rows[i >> 2][i & 3] = hd.rows[4 + i];
  if (threadIdx.x == 0) sm.R = R;
  __syncthreads();
  if (threadIdx.x == 0) {
    int ns = 0;
    for (int r = 0; r < R; r++) {
      if (r == 0 || sm.rows[r][0] != sm.rows[r - 1][0] || sm.rows[r][1] != sm.rows[r - 1][1] + 1 || sm.sq_n[ns - 1] >= 8) {
        sm.sq_seq[ns] = sm.rows[r][0]; sm.sq_r0[ns] = r; sm.sq_n[ns] = 1; ns++;
      } else sm.sq_n[ns - 1]++;
    }
    sm.nsq = ns;
  }
  __syncthreads();
}
#define KHEAD extern __shared__ __align__(16) unsigned char smraw[]; Smem& sm = *reinterpret_cast<Smem*>(smraw); \
  const WCtx& w = *wp; const Ctx& c = *w.c; load_rows(hd, sm);
#define KDEF(name) extern "C" __global__ void __launch_bounds__(NT, 1) name(const WCtx* __restrict__ wp, WHdr hd, int a, int x0, int x1)
KDEF(k_attn_in) { KHEAD ph_attn_in(w, c, hd, sm, a); }
KDEF(k_gate_mix) { KHEAD ph_gate_mix(w, c, hd, sm, a, x0, x1); }
KDEF(k_gate_dg) { KHEAD ph_gate_dg(w, c, hd, sm, a, x0, x1); }
KDEF(k_gate_fg) { KHEAD ph_gate_fg(w, c, hd, sm, a, x0, x1); }
KDEF(k_gate_norm) { KHEAD ph_gate_norm(w, c, hd, sm, a, x0, x1); }
KDEF(k_qkv) { dmark(0); KHEAD ph_qkv(w, c, hd, sm, a, x0); dmark(5); }
KDEF(k_kv) { KHEAD ph_kv(w, c, hd, sm, a); }
KDEF(k_attn) { KHEAD ph_attn(w, c, hd, sm, a); }
KDEF(k_oproj) { KHEAD ph_oproj(w, c, hd, sm, a); }
KDEF(k_mlp_in) { KHEAD ph_mlp_in(w, c, hd, sm, a); }
KDEF(k_router) { KHEAD ph_router(w, c, hd, sm, a); }
KDEF(k_w13) {
  KHEAD routing(w, c, hd, sm, a);
  if (blockIdx.x == 0) {   // the tables for the w2 kernel
    const int n = (int)((RT_END - RT_BEGIN) / 4);
    for (int i = threadIdx.x; i < n; i += NT) w.rtab[i] = reinterpret_cast<const int*>(smraw + RT_BEGIN)[i];
  }
  ph_moe<true>(w, c, hd, sm, a);
}
KDEF(k_w2) {
  KHEAD
  const int n = (int)((RT_END - RT_BEGIN) / 4);
  for (int i = threadIdx.x; i < n; i += NT) reinterpret_cast<int*>(smraw + RT_BEGIN)[i] = __ldcg(w.rtab + i);
  __syncthreads();
  ph_moe<false>(w, c, hd, sm, a);
}
KDEF(k_w2sum) { KHEAD ph_w2sum(w, c, hd, sm, a); }
KDEF(k_w2conv) { KHEAD ph_w2conv(w, c, hd, sm, a); }
KDEF(k_fin_mix) { KHEAD ph_fin_mix(w, c, hd, sm); }
KDEF(k_unembed) {
  KHEAD
  const int R = sm.R;
  if (R <= 0) return;
  if (R <= 8) unembed_t<1>(w, c, hd, sm); else if (R <= 16) unembed_t<2>(w, c, hd, sm);
  else if (R <= 32) unembed_t<4>(w, c, hd, sm); else unembed_t<8>(w, c, hd, sm);
}
// device loop of the B >= 2 decoding: rows r < R advance one position and take their own argmax as the next token
extern "C" __global__ void k_feed(int* hdr, const int* next_tok) {
  const int R = min(max(hdr[0], 0), MAXR);
  if ((int)threadIdx.x < R) { hdr[4 + 4 * threadIdx.x + 1] += 1; hdr[4 + 4 * threadIdx.x + 2] = next_tok[threadIdx.x]; }
}
KDEF(k_tokens) {
  const WCtx& w = *wp;
  if ((int)threadIdx.x < min(hd.rows[0], MAXR)) {
    const unsigned long long k = w.amax[threadIdx.x];
    const int tok = (int)(0xFFFFFFFFu - (unsigned)(k & 0xFFFFFFFFu));
    w.next_tok[threadIdx.x] = tok;
    w.amax[threadIdx.x] = 0ull;
    if (hd.out_tok) hd.out_tok[threadIdx.x] = tok + ((hd.flags >> 8) & 1);   // flag bit 8: write 1 + id (host polls for != 0)
  }
}

// ------------------------------------------------------------------------------------------------ host API
typedef void (*KFn)(const WCtx*, WHdr, int, int, int);
enum { K_ATTN_IN, K_GATE_MIX, K_GATE_DG, K_GATE_FG, K_GATE_NORM, K_QKV, K_KV, K_ATTN, K_OPROJ, K_MLP_IN, K_ROUTER, K_W13, K_W2,
       K_W2SUM, K_W2CONV, K_FIN_MIX, K_UNEMBED, K_TOKENS, K_N };
static KFn kfn[K_N] = {k_attn_in, k_gate_mix, k_gate_dg, k_gate_fg, k_gate_norm, k_qkv, k_kv, k_attn, k_oproj, k_mlp_in, k_router,
                       k_w13, k_w2, k_w2sum, k_w2conv, k_fin_mix, k_unembed, k_tokens};
static size_t ksm[K_N];
static int napp_layer[NAPP], napp_nmsg[NAPP], layer_glob[NLW];
extern "C" {
int wk_smem_bytes() { return (int)sizeof(Smem); }
int wk_wctx_bytes() { return (int)sizeof(WCtx); }
int wk_ctx_head_bytes() { return (int)sizeof(Ctx); }
int wk_layer_bytes() { return (int)sizeof(LayerW); }
int wk_off_embed() { return (int)offsetof(Ctx, embed); }
int wk_set_dprof(void* p) { return cudaMemcpyToSymbol(g_dprof, &p, sizeof(p)) == cudaSuccess ? 0 : 1; }
int wk_feed(void* hdr, const void* next_tok, void* stream) {
  k_feed<<<1, MAXR, 0, (cudaStream_t)stream>>>((int*)hdr, (const int*)next_tok);
  return cudaGetLastError() == cudaSuccess ? 0 : 1;
}
int wk_rtab_bytes() { return (int)(RT_END - RT_BEGIN); }
// app table from the host copy of the megakernel's Ctx (layer, nmsg per application; glob per layer)
int wk_setup(const void* ctx_host) {
  const Ctx* c = reinterpret_cast<const Ctx*>(ctx_host);
  for (int a = 0; a < NAPP; a++) { napp_layer[a] = c->A[a].layer; napp_nmsg[a] = c->A[a].nmsg; }
  for (int i = 0; i < NLW; i++) layer_glob[i] = c->L[i].glob;
  const size_t hdr = offsetof(Smem, u);
  Smem* z = nullptr;
  const size_t sg = hdr + sizeof(z->u.g), sat = hdr + sizeof(z->u.at), s13 = hdr + sizeof(z->u.m13), s2 = hdr + sizeof(z->u.m2), sgv = hdr + sizeof(z->u.gvs);
  for (int k = 0; k < K_N; k++) ksm[k] = hdr;
  ksm[K_GATE_DG] = ksm[K_QKV] = ksm[K_OPROJ] = ksm[K_ROUTER] = ksm[K_UNEMBED] = hdr + sizeof(z->u.g2); (void)sg;
  ksm[K_ATTN] = sat; ksm[K_W13] = s13; ksm[K_W2] = s2; ksm[K_GATE_FG] = sgv;
  for (int k = 0; k < K_N; k++) {
    cudaError_t e = cudaFuncSetAttribute((const void*)kfn[k], cudaFuncAttributeMaxDynamicSharedMemorySize, (int)ksm[k]);
    if (e != cudaSuccess) { fprintf(stderr, "wk_setup %d: %s\n", k, cudaGetErrorString(e)); return 1; }
  }
  return 0;
}
static int launch(int k, int nblk, const void* wdev, const WHdr& h, int a, int x0, int x1, cudaStream_t st) {
  kfn[k]<<<nblk, NT, ksm[k], st>>>(reinterpret_cast<const WCtx*>(wdev), h, a, x0, x1);
  return 0;
}
// one pass: every application's kernels in order, then the final mix, the unembedding and the tokens
int wk_launch(const void* wdev, const WHdr* hd, int nblk, void* stream) {
  const WHdr h = *hd;
  cudaStream_t st = (cudaStream_t)stream;
  const int R = h.R;
  const int gj = (R * 3 + 3) / 4;   // row-job blocks (4 groups each)
  const int napp = (h.flags & 0xff) ? (h.flags & 0xff) : NAPP;
  for (int a = 0; a < napp; a++) {
    const int glob = layer_glob[napp_layer[a]];
    int nq;
    if (!napp_nmsg[a]) { launch(K_ATTN_IN, min(nblk, (R * (glob ? 3 : 1) + 3) / 4), wdev, h, a, 0, 0, st); nq = glob ? 3 : 1; }
    else {
      launch(K_GATE_MIX, min(nblk, gj), wdev, h, a, 0, 3, st);
      launch(K_GATE_DG, 12, wdev, h, a, 0, 3, st);
      launch(K_GATE_FG, nblk, wdev, h, a, 0, 3, st);
      launch(K_GATE_NORM, min(nblk, gj), wdev, h, a, 0, 3, st);
      nq = 3;
    }
    launch(K_QKV, nblk, wdev, h, a, nq, 0, st);
    launch(K_KV, min(nblk, (R * 16 + NW - 1) / NW), wdev, h, a, 0, 0, st);
    launch(K_ATTN, nblk, wdev, h, a, 0, 0, st);
    launch(K_OPROJ, min(nblk, 144), wdev, h, a, 0, 0, st);
    if (!napp_nmsg[a]) launch(K_MLP_IN, min(nblk, (R + 3) / 4), wdev, h, a, 0, 0, st);
    else {
      launch(K_GATE_MIX, min(nblk, (R + 3) / 4), wdev, h, a, 3, 1, st);
      launch(K_GATE_DG, 4, wdev, h, a, 3, 1, st);
      launch(K_GATE_FG, min(nblk, 18), wdev, h, a, 3, 1, st);
      launch(K_GATE_NORM, min(nblk, (R + 3) / 4), wdev, h, a, 3, 1, st);
    }
    launch(K_ROUTER, 8, wdev, h, a, 0, 0, st);
    launch(K_W13, nblk, wdev, h, a, 0, 0, st);
    launch(K_W2, nblk, wdev, h, a, 0, 0, st);
    launch(K_W2SUM, nblk, wdev, h, a, 0, 0, st);
    launch(K_W2CONV, nblk, wdev, h, a, 0, 0, st);
  }
  if (napp == NAPP) {
    launch(K_FIN_MIX, (R + 3) / 4, wdev, h, 0, 0, 0, st);
    launch(K_UNEMBED, nblk, wdev, h, 0, 0, 0, st);
    launch(K_TOKENS, 1, wdev, h, 0, 0, 0, st);
  }
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) { fprintf(stderr, "wk_launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}
}
