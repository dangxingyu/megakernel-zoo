// Inkling-2-Mini "wide" pass: up to MAXR rows (sequence slot, position, token) through the whole text decoder in
// one persistent cooperative kernel, phases separated by grid barriers. Used by step() for B >= 2 and by the B >= 2
// draft-and-verify path (rows = several consecutive positions of each sequence).
//
// Batch invariance by construction: every value of a row is computed from that row's own inputs with an order that
// does not depend on the other rows (GEMMs: fixed unit -> warp split and fixed partial-sum order per output, each row
// a column of an mma whose result does not depend on the other columns; attention: absolute 128-key chunks merged in
// increasing order; expert GEMMs: per (expert, token) column; routing, norms and mixes per row). So a row's logits are
// the same whether it is the only row of a step or one of 64 rows of a verify pass.
//
// Weights: the megakernel's device tensors (engine/mk.cu Ctx, LayerW: fragment layouts frag_bf16 / frag_nvfp4 /
// frag_mxfp8) plus an interleaved F/G copy of the loop-gate controllers. Expert inputs are exact: bf16 activations as
// f16 hi + lo * 2^-24 columns with a power-of-two scale (as the megakernel), weights decoded exactly.
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstddef>

typedef __nv_bfloat16 bf16;

#define H 2304
#define NQH 24
#define NKV 8
#define HD 128
#define QW 3072
#define NE 128
#define TOPK 8
#define IE 1152
#define NLW 24
#define NAPP 48
#define MAXB 8
#define NSQ 8            // sequence slots
#define MAXR 64          // rows per pass
#define RING 16
#define VOCAB_REAL 200058
#define UN_STRIPS 12504
#define R_G 3072
#define R_R 6144
#define R_S 6528
#define QG_STRIPS 410
#define K0 6560
#define V0 7616
#define QKVR 8672
#define NT 512
#define NW (NT / 32)
#define NTM 768          // the MoE kernels: 24 warps (80 registers)
#define NWM (NTM / 32)
#define ACH 128          // attention keys per chunk (absolute: chunk c = keys [128 c, 128 c + 128))
#define MAXCHW 40        // chunks per row (positions < 5120)
#define XTOK 8           // tokens per expert chunk (2 n-groups of 4 hi/lo column pairs)
#ifndef MOE_F16S
#define MOE_F16S 0   // 1: NVFP4 experts from the 640-B copy with f16 block scales (measured no gain; needs MK_F16S=1)
#endif
#ifndef MOE_PF
#define MOE_PF 0
#endif
#ifndef MOE2ACC
#define MOE2ACC 0
#endif
#ifndef WRING
#define WRING 6144       // per-warp weight ring (bytes): 10 NVFP4 units / 5 MXFP8 units
#endif

// ------------------------------------------------------------------------------------------------ mk.cu structs
struct W12M { const uint8_t* data; const int* base; const int* hdr; const int* esc; };
struct LayerW {
  const uint8_t* wqkv; const uint8_t* wo; const uint8_t* wr; const float* rbias;
  const uint8_t* w13; const uint8_t* w2; const float* f13; const float* f2;
  const bf16* norm[3]; const bf16* mlp_norm;
  const bf16* ksc; const bf16* vsc; const bf16* attn_sc; const bf16* mlp_sc;
  const bf16* qscale; const bf16* rscale; const bf16* relp;
  const float* aq; const float* mq;
  const uint8_t* cD; const bf16* cFG;
  W12M qkv12, wo12;
  int nsk, mx, glob, naq;
};
struct App { int layer, pass, slot, bnd, nblk, blk[4], pin, nmsg, msg[2], loopl, out, pad; };
struct Ctx {
  LayerW L[NLW];
  App A[NAPP];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm; const uint8_t* unembed;
  const float* loopq;
  W12M un12;
  int nfin, fin[4], fin_pin, maxctx;
  // (the megakernel's runtime buffers follow; not used here)
};

struct WCtx {
  const Ctx* c;
  const uint8_t* fg[NLW];   // core layers: frag_bf16 of [4 ctrl][2304 (forget, gain) row pairs][64]
  int maxctx, pad0;
  bf16 *kc, *vc;            // [NAPP][NSQ][NKV][maxctx][HD]
  bf16 *hk, *hv;            // [NAPP][NSQ][RING][1024] raw k / v
  bf16 *ha, *hm;            // [NAPP][NSQ][RING][H] raw o_proj output / raw MoE output
  bf16* pb;                 // [NAPP + 1][MAXR][H] partials (index 0: h0)
  bf16* X;                  // [3][MAXR][H] normalized attention-input streams
  float* qkv;               // [MAXR][QKVR]
  float* arec;              // [MAXR][NQH][MAXCHW][130] attention chunk records (m, l, o[128])
  unsigned* acnt;           // [NSQ][NKV] chunk counters (last arriver merges)
  bf16* ao;                 // [MAXR][QW]
  bf16* as;                 // [MAXR][H] attention conv output
  bf16* y;                  // [MAXR][H] router input
  __half* x16;              // [MAXR][2][H] expert input hi / lo (scaled by 2^sh)
  float* s16;               // [MAXR] 2^-sh
  float* rl;                // [MAXR][NE] router logits
  __half* act16;            // [MAXR * TOPK][2][IE]
  float* w2c;               // [MAXR * TOPK][H]
  bf16* xm;                 // [MAXR][H] raw MoE output (bf16)
  float* xg; float* mg;     // [MAXR][4][H] gate x, m
  bf16* ub;                 // [MAXR][4][2 H] gate unit vectors
  float* gv;                // [MAXR][4][64]
  float* xp;                // [MAXR][4][H] (f, g) pairs of the gates (float2 per channel: [MAXR][4][H][2])
  bf16* xf;                 // [MAXR][H] final-norm rows
  unsigned long long* amax; // [MAXR]
  int* next_tok;            // [MAXR]
  unsigned* bar;            // [4]
  unsigned long long* prof; // (unused)
  int* rtab;                // routing tables between the w13 and w2 kernels
  float* gpart;             // dgemm3: lane partials [strips][16][8][4][32]
  bf16* qp;                 // [MAXR][NQH][HD] clipped q (bf16), by k_kv
  float* rp;                // [MAXR][NQH][16] clipped relative features
  const uint8_t* w13h[NLW]; const uint8_t* w2h[NLW];   // NVFP4 layers: 640-B units (512 B codes + f16 block scales [g][j][h])
  unsigned* gcnt;           // dgemm3: per strip arrival counters
};
struct WHdr { int R; int flags; const int* rows; float* logits; int* out_tok; };   // rows: device [0] = R, then [MAXR][4] (seq, pos, tok, -); R (host) = upper bound

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ uint32_t cvt_e4m3x2(uint32_t w16) {
  uint32_t r; unsigned short h = (unsigned short)w16;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(h));
  return r;
}
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }
__device__ __forceinline__ uint32_t pack_bf2(float lo, float hi) {
  return (uint32_t)__bfloat16_as_ushort(tobf(lo)) | ((uint32_t)__bfloat16_as_ushort(tobf(hi)) << 16);
}
__device__ __forceinline__ float bf_lo(uint32_t v) { return __uint_as_float(v << 16); }
__device__ __forceinline__ float bf_hi(uint32_t v) { return __uint_as_float(v & 0xffff0000u); }
__device__ __forceinline__ int lane_id() { int l; asm("mov.u32 %0, %%laneid;" : "=r"(l)); return l; }
__device__ __forceinline__ unsigned ld_acq(const unsigned* p) { unsigned v; asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void red_release_gpu(unsigned* p, unsigned v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void cp_async16(void* smem, const void* gmem) {
  const unsigned sa = (unsigned)__cvta_generic_to_shared(smem);
  asm volatile("cp.async.cg.shared.global [%0], [%1], 16;" :: "r"(sa), "l"(gmem) : "memory");
}
__device__ __forceinline__ void cp_commit() { asm volatile("cp.async.commit_group;" ::: "memory"); }
template <int N> __device__ __forceinline__ void cp_wait() { asm volatile("cp.async.wait_group %0;" :: "n"(N) : "memory"); }
__device__ __forceinline__ void ldsm_x4(uint32_t* r, const void* p) {
  const unsigned a = (unsigned)__cvta_generic_to_shared(p);
  asm volatile("ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0,%1,%2,%3}, [%4];" : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]) : "r"(a));
}
__device__ __forceinline__ void ldsm_x4_t(uint32_t* r, const void* p) {
  const unsigned a = (unsigned)__cvta_generic_to_shared(p);
  asm volatile("ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 {%0,%1,%2,%3}, [%4];" : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]) : "r"(a));
}
__device__ __forceinline__ void pf_l2(const void* p, int bytes) {   // bytes: multiple of 16, pieces of <= 64 KB
  const char* q = reinterpret_cast<const char*>(p);
  for (int o = 0; o < bytes; o += 65536) {
    const unsigned n = (unsigned)min(65536, bytes - o);
    asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(q + o), "r"(n) : "memory");
  }
}
#ifdef WTPROF   // per-launch timeline: [li][0] start min, [1] wait done min, [2] wait done max, [3] end max (globaltimer)
__device__ unsigned long long* g_tprof = nullptr;
__shared__ int s_li;
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); return t; }
__device__ __forceinline__ void tmark(int m) {
  if (g_tprof && threadIdx.x == 0 && s_li >= 0) { unsigned long long* p = g_tprof + s_li * 4 + m; const unsigned long long t = gtime();
    if (m == 0 || m == 1) atomicMin(p, t); else atomicMax(p, t); } }
struct TEnd { __device__ ~TEnd() { if (g_tprof && (threadIdx.x & 31) == 0 && s_li >= 0) atomicMax(g_tprof + s_li * 4 + 3, gtime()); } };
#define TSTART(hd) if (threadIdx.x == 0) s_li = (hd).flags >> 16; __syncthreads(); tmark(0); TEnd _tend;
#else
#define TSTART(hd)
__device__ __forceinline__ void tmark(int) {}
#endif
__device__ __forceinline__ void pdl_wait() { asm volatile("griddepcontrol.wait;" ::: "memory"); tmark(1); tmark(2); }
__device__ __forceinline__ void pdl_launch() { asm volatile("griddepcontrol.launch_dependents;" ::: "memory"); }
__device__ __forceinline__ void gsync(int id) { asm volatile("bar.sync %0, %1;" :: "r"(id), "r"(128) : "memory"); }
__device__ __forceinline__ float ldf(const float* p) { return __ldcg(p); }
__device__ __forceinline__ uint32_t ldu(const void* p) { return __ldcg(reinterpret_cast<const unsigned int*>(p)); }

// ------------------------------------------------------------------------------------------------ shared memory
struct GemmSm { bf16 b[2][64][264]; };                  // dense GEMM: two k-slices of 256 for up to 64 rows
struct AttSm {
  bf16 kk[2][ACH][HD + 8]; bf16 vv[2][ACH][HD + 8]; bf16 qb[24][HD + 8];
  bf16 ph[32][ACH + 8]; bf16 pl[32][ACH + 8];
  float sc[24][ACH]; float pr[16][ACH + 16]; float rr[24][16]; float mw[24][MAXCHW]; float ms[24]; float mS[24]; float snk[24];
  int tq[8];                                               // positions of the item's rows
};
struct Smem {
  float red[NW][32];
  int rows[MAXR][4];
  int R;
  int nsq; int sq_seq[NSQ], sq_r0[NSQ], sq_n[NSQ];   // the pass's sequences (rows of one sequence are consecutive)
  float mlm[32], mll[32];
  unsigned long long ubest[MAXR];
  int flag;
  // row-job kernels: the layer's vectors staged in u.rjb before the wait on the previous kernel (or global pointers)
  const float* qv[8];   // 0..2 attention-input queries, 3..5 loop-message queries (controllers 0..2), 6 MLP query, 7 loop query 3
  const bf16* nwv[4];   // norm weights of the streams (3: embed_norm at application 0)
  const bf16* mlpn; const bf16* tap;
  int rjoff;
  // routing tables (identical in every block)
  int tex[MAXR][TOPK]; float twt[MAXR][TOPK];
  int eoff[NE + 1]; short elist[MAXR * TOPK];              // per expert: (row << 3 | rank) in row order
  int eoff2[NE]; int echk[NE]; unsigned emask[MAXR][4]; unsigned rmask[NE][2]; unsigned char epre[MAXR][4]; int ecst[NE];
  int nchk; int chk_e[NE * 4]; int chk_j0[NE * 4]; int chk_n[NE * 4]; int chk_cost0[NE * 4 + 1];
  union __align__(16) {
    GemmSm g;
    struct { bf16 b[32 * (36 * 64 + 8)]; } g2;   // dgemm2: B chunk (<= 32 rows x 2312, or 64 rows x 1032) / lane partials
    AttSm at;
    struct { __half xs[2][XTOK][2][H + 8]; } m13;   // expert inputs of up to 2 (expert, chunk) groups
    struct { __half xs[4][XTOK][2][IE + 8]; } m2;    // ... 4 groups
    bf16 gvs[MAXR][4][72];                                 // F/G GEMM B operand
    unsigned char rjb[57344];                              // row-job kernels: staged weight vectors
  } u;
};
// routing tables as stored in global memory between the w13 and w2 kernels (the Smem fields tex .. chk_cost0)
#define RT_BEGIN offsetof(Smem, tex)
#define RT_END offsetof(Smem, u)


// ------------------------------------------------------------------------------------------------ barrier
__device__ __forceinline__ void grid_bar(const WCtx& w, unsigned& nbar, unsigned base) {
  __syncthreads();
  nbar += 1;
  if (threadIdx.x == 0) {
    const unsigned target = base + nbar * gridDim.x;
    __threadfence();
    red_release_gpu(&w.bar[0], 1);
    while ((int)(ld_acq(&w.bar[0]) - target) < 0) { }
    if (w.prof && blockIdx.x == 0 && nbar < 4096) { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); w.prof[nbar] = t; }
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ row vectors
// A "row job" runs on a group of 4 warps (128 threads); thread gt owns element pairs p = gt + 128 j (j < 9).
#define RPJ 9
#define REL(j) (2 * (gt + 128 * (j)))
template <int N>
__device__ __forceinline__ void gsum(float* v, Smem& sm, int gi, int gt) {
#pragma unroll
  for (int i = 0; i < N; i++) {
    float x = v[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x += __shfl_xor_sync(0xffffffffu, x, o);
    v[i] = x;
  }
  const int wl = gt >> 5, lane = gt & 31;
  float* rd = &sm.red[gi * 4][0];   // [4 warps][32]
  gsync(1 + gi);
  if (lane == 0) {
#pragma unroll
    for (int i = 0; i < N; i++) rd[wl * 32 + i] = v[i];
  }
  gsync(1 + gi);
#pragma unroll
  for (int i = 0; i < N; i++) v[i] = ((rd[i] + rd[32 + i]) + rd[64 + i]) + rd[96 + i];
}
__device__ __forceinline__ float gmax1(float x, Smem& sm, int gi, int gt) {
#pragma unroll
  for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffffu, x, o));
  const int wl = gt >> 5, lane = gt & 31;
  float* rd = &sm.red[gi * 4][0];
  gsync(1 + gi);
  if (lane == 0) rd[wl * 32 + 31] = x;
  gsync(1 + gi);
  return fmaxf(fmaxf(rd[31], rd[63]), fmaxf(rd[95], rd[127]));
}
// bf16 row -> packed pairs
__device__ __forceinline__ void ld_row(const bf16* p, uint32_t* v, int gt) {
#pragma unroll
  for (int j = 0; j < RPJ; j++) v[j] = ldu(p + REL(j));
}
// softmax over depth of NS sources (packed bf16 rows; slot FS, if >= 0, is f32) with query q (f32 [H]):
// out[k] = sum_s softmax_s(<v_s / rms(v_s), q> / sqrt(H)) * v_s / rms(v_s)
template <int NS>
__device__ __forceinline__ void g_mix(const uint32_t (*v)[RPJ], const float* fsrc, int fs, unsigned msk, const float* q, float* out, Smem& sm, int gi, int gt) {
  float red[2 * NS];
#pragma unroll
  for (int i = 0; i < 2 * NS; i++) red[i] = 0.f;
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const float2 qq = *reinterpret_cast<const float2*>(q + REL(j));
#pragma unroll
    for (int s = 0; s < NS; s++) {
      if (!((msk >> s) & 1u)) continue;
      const float x0 = (s == fs) ? fsrc[2 * j] : bf_lo(v[s][j]), x1 = (s == fs) ? fsrc[2 * j + 1] : bf_hi(v[s][j]);
      red[s] = fmaf(x1, x1, fmaf(x0, x0, red[s]));
      red[NS + s] = fmaf(x1, qq.y, fmaf(x0, qq.x, red[NS + s]));
    }
  }
  gsum<2 * NS>(red, sm, gi, gt);
  float inv[NS], lg[NS], mx = -1e30f;
#pragma unroll
  for (int s = 0; s < NS; s++) {
    inv[s] = rsqrtf(red[s] / (float)H + 1e-6f);
    lg[s] = ((msk >> s) & 1u) ? red[NS + s] * 0.020833333333333332f * inv[s] : -1e30f;
    mx = fmaxf(mx, lg[s]);
  }
  float den = 0.f;
#pragma unroll
  for (int s = 0; s < NS; s++) { lg[s] = ((msk >> s) & 1u) ? expf(lg[s] - mx) : 0.f; den += lg[s]; }
  const float rd = 1.0f / den;
#pragma unroll
  for (int s = 0; s < NS; s++) lg[s] = lg[s] * rd * inv[s];
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    float o0 = 0.f, o1 = 0.f;
#pragma unroll
    for (int s = 0; s < NS; s++) {
      if (!((msk >> s) & 1u)) continue;
      const float x0 = (s == fs) ? fsrc[2 * j] : bf_lo(v[s][j]), x1 = (s == fs) ? fsrc[2 * j + 1] : bf_hi(v[s][j]);
      o0 = fmaf(lg[s], x0, o0); o1 = fmaf(lg[s], x1, o1);
    }
    out[2 * j] = o0; out[2 * j + 1] = o1;
  }
}
// rmsnorm(x) * w -> bf16 row dst
__device__ __forceinline__ void g_norm_store(const float* x, const bf16* w, bf16* dst, Smem& sm, int gi, int gt) {
  float s[1] = {0.f};
#pragma unroll
  for (int k = 0; k < 2 * RPJ; k++) s[0] = fmaf(x[k], x[k], s[0]);
  gsum<1>(s, sm, gi, gt);
  const float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const __nv_bfloat162 wv = *reinterpret_cast<const __nv_bfloat162*>(w + REL(j));
    *reinterpret_cast<uint32_t*>(dst + REL(j)) = pack_bf2(x[2 * j] * r * bf(wv.x), x[2 * j + 1] * r * bf(wv.y));
  }
}

// ------------------------------------------------------------------------------------------------ dense GEMM
// out = W x for the strips [sb, se) (at most 16 / WPS) of one task; W in frag_bf16 order ([strips][U][4][32 lanes][16 B]).
// Arithmetic (fixed per GEMM, independent of R): unit u of a strip is accumulated by unit lane u % WPS, each lane in
// increasing u; the WPS lane partials are summed in lane order. Rows are processed in chunks of 8 NGC; the chunk's B
// rows (bf16, row stride ldb) are staged in shared memory for SK units (k = 64 SK) at a time; every warp keeps three
// units of weights in flight across stage and chunk boundaries. epi(strip, ng, a0, a1, a2, a3) on the strip's first
// warp for every n-group ng of every chunk (lane (g, t): a0 = (row g, col 2t), a1 = (g, 2t+1), a2 = (g+8, 2t), a3).
__device__ unsigned long long* g_dprof = nullptr;
__device__ unsigned long long* g_aprof = nullptr;
__device__ __forceinline__ void cmark(int ci, int k) {   // the item's chunk ci == 1 only (region 2)
#ifdef WDPROF
  if (ci == 1) { unsigned long long* p = g_aprof ? g_aprof + 2 * 160 * 16 : nullptr;
    if (p && threadIdx.x == 0 && p[blockIdx.x * 16 + k] == 0) { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); p[blockIdx.x * 16 + k] = t; } }
#endif
}
__device__ __forceinline__ void amark(int k, int region = 0) {
#ifdef WDPROF
  unsigned long long* p = g_aprof ? g_aprof + region * 160 * 16 : nullptr;
  if (p && threadIdx.x == 0 && p[blockIdx.x * 16 + k] == 0) { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); p[blockIdx.x * 16 + k] = t; }
#endif
}
__device__ __forceinline__ void dmark(int k) {
#ifdef WDPROF
  if (g_dprof && threadIdx.x == 0 && g_dprof[blockIdx.x * 8 + k] == 0) { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); g_dprof[blockIdx.x * 8 + k] = t; }
#endif
}
template <int NGC, int WPS, int SK, class EPI>
__device__ __forceinline__ void dgemm2(Smem& sm, const uint8_t* W, int U, int sb, int se, const bf16* Bg, long ldb, int R, EPI epi) {
  dmark(1);
  constexpr int SPB = 16 / WPS, RC = NGC * 8, KSP = SK * 64 + 8;
  static_assert(SK % WPS == 0, "stage = whole lane rounds");
  const int w = threadIdx.x >> 5, lane = lane_id(), q = w / WPS, wl = w % WPS;
  const int strip = sb + q;
  const bool act = q < SPB && strip < se;
  const int g = lane >> 2, t = lane & 3;
  const int nch = (R + RC - 1) / RC;
  const int nuL = (U + WPS - 1) / WPS;
  constexpr int SQ = SK / WPS;                        // lane units per stage
  const int NQ = nch * nuL;
#ifndef DGDB
#define DGDB 1
#endif
  // two B stage buffers when they fit: the next stage of the chunk is copied while the current one is used
  constexpr bool DB = DGDB && 2 * RC * KSP <= (int)(sizeof(sm.u.g2.b) / 2);
  bf16* bs0 = reinterpret_cast<bf16*>(&sm.u.g2.b[0]);  // [RC][KSP] (x2)
  bf16* bs = bs0;
  float* red = reinterpret_cast<float*>(&sm.u.g2.b[0]);   // [16][NGC][4][32]: over B (free when the partials are summed)
  static_assert(RC * KSP * 2 <= (int)sizeof(sm.u.g2.b) && 16 * NGC * 4 * 32 * 4 <= (int)sizeof(sm.u.g2.b), "dgemm2 smem");
  const uint8_t* ws = W + (long)strip * U * 2048;
  float acc[NGC][4];
#pragma unroll
  for (int ng = 0; ng < NGC; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  auto ldw = [&](uint4* d, int qq) {
    const int u = wl + (qq % nuL) * WPS;
    if (act && qq < NQ && u < U) {
#pragma unroll
      for (int jj = 0; jj < 4; jj++) d[jj] = ldg_nc(ws + ((long)u * 4 + jj) * 512 + lane * 16);
    }
  };
  auto finish = [&](int c) {   // lane partials of chunk c -> epilogue (red is over B: every warp done with B first)
    __syncthreads();
#pragma unroll
    for (int ng = 0; ng < NGC; ng++)
#pragma unroll
      for (int i = 0; i < 4; i++) red[((w * NGC + ng) * 4 + i) * 32 + lane] = acc[ng][i];
    __syncthreads();
    if (act && wl == 0) {
#pragma unroll
      for (int ng = 0; ng < NGC; ng++) {
        if ((c * NGC + ng) * 8 >= R) break;
        float sv[4];
#pragma unroll
        for (int i = 0; i < 4; i++) {
          float x = 0.f;
#pragma unroll
          for (int k = 0; k < WPS; k++) x += red[(((w + k) * NGC + ng) * 4 + i) * 32 + lane];
          sv[i] = x;
        }
        epi(strip, c * NGC + ng, sv[0], sv[1], sv[2], sv[3]);
      }
    }
#pragma unroll
    for (int ng = 0; ng < NGC; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  };
  auto stage = [&](int c, int ql) {
    const int k0 = (ql * WPS) * 64, kw = min(SK * 64, U * 64 - k0), nck = kw / 8;
    const int r0 = c * RC;
    bf16* bs = bs0 + (DB ? ((ql / SQ) & 1) * RC * KSP : 0);
    for (int i = threadIdx.x; i < RC * nck; i += NT) {
      const int r = i / nck, cc = i - r * nck;
      if (r0 + r < R) cp_async16(bs + (long)r * KSP + cc * 8, Bg + (long)(r0 + r) * ldb + k0 + cc * 8);
      else *reinterpret_cast<uint4*>(bs + (long)r * KSP + cc * 8) = make_uint4(0, 0, 0, 0);
    }
    cp_commit();
  };
  auto step = [&](int qq, const uint4* wv) {
    if (qq >= NQ) return;
    const int c = qq / nuL, ql = qq % nuL;
    if (ql % SQ == 0) {   // new stage (uniform over the block); the first one was issued before the weight prologue
      if (ql == 0 && c > 0) finish(c - 1);
      if (DB) {
        if (qq > 0 && ql == 0) stage(c, 0);   // (a chunk's first stage is not prefetched)
        cp_wait<0>();
        __syncthreads();   // this stage landed for every thread; every warp is done with the other buffer
        if (ql + SQ < nuL) stage(c, ql + SQ);
        bs = bs0 + ((ql / SQ) & 1) * RC * KSP;
      } else {
        if (qq > 0) { __syncthreads(); stage(c, ql); }
        cp_wait<0>();
        __syncthreads();
      }
      dmark(2);
    }
    const int u = wl + ql * WPS;
    if (act && u < U) {
      const int kl = ((ql % SQ) * WPS + wl) * 64;
#pragma unroll
      for (int jj = 0; jj < 4; jj++) {
        const int kk = kl + jj * 16 + 2 * t;
#pragma unroll
        for (int ng = 0; ng < NGC; ng++) {
          const uint32_t b0 = *reinterpret_cast<const uint32_t*>(bs + (long)(ng * 8 + g) * KSP + kk);
          const uint32_t b1 = *reinterpret_cast<const uint32_t*>(bs + (long)(ng * 8 + g) * KSP + kk + 8);
          mma_bf16(acc[ng], wv[jj].x, wv[jj].y, wv[jj].z, wv[jj].w, b0, b1);
        }
      }
    }
  };
#ifndef DG4
#define DG4 1
#endif
  if constexpr (DG4 && NGC <= 2) {   // four units of weights in flight per warp (64 registers); three for 32-row chunks
  uint4 w0[4], w1[4], w2[4], w3[4];
#ifndef GPF
#define GPF 1   // 1: strip -> L2 before the wait; 2: after B is staged; 0: none
#endif
  if (GPF == 1 && act && wl == 0 && lane == 0) pf_l2(ws, U * 2048);   // the strip's weights into L2 (not produced by the previous kernel)
  ldw(w0, 0); ldw(w1, 1); ldw(w2, 2); ldw(w3, 3);   // (weights: issued before the wait, while the previous kernel ends)
  pdl_wait();
  stage(0, 0);
#pragma unroll 1
  for (int qq = 0; qq < NQ; qq += 4) {
    step(qq, w0); ldw(w0, qq + 4);
    step(qq + 1, w1); ldw(w1, qq + 5);
    step(qq + 2, w2); ldw(w2, qq + 6);
    step(qq + 3, w3); ldw(w3, qq + 7);
  }
  } else {
  uint4 w0[4], w1[4], w2[4];
  if (GPF == 1 && act && wl == 0 && lane == 0) pf_l2(ws, U * 2048);
  ldw(w0, 0); ldw(w1, 1); ldw(w2, 2);
  pdl_wait();
  stage(0, 0);
#pragma unroll 1
  for (int qq = 0; qq < NQ; qq += 3) {
    step(qq, w0); ldw(w0, qq + 3);
    step(qq + 1, w1); ldw(w1, qq + 4);
    step(qq + 2, w2); ldw(w2, qq + 5);
  }
  }
  dmark(3);
  if (nch > 0) finish(nch - 1);   // (a pass with no rows: no epilogue)
  __syncthreads();
  dmark(4);
}
// The 16-lane GEMMs (o_proj, router, gate D) with each strip's unit lanes split over 4 blocks: block = (group of SPB
// strips, lane group lg); warp w: strip slot w / 4, lane 4 lg + w % 4, its units u = lane + 16 k in increasing order
// (as dgemm2<.., 16, ..>). A block stages only its lanes' units (256 k per lane round, all rows), writes its lane
// partials to global; the last of the strip's 4 lane-group blocks sums the 16 partials in lane order and runs epi:
// the same arithmetic as dgemm2 with WPS 16.
template <int NG, int SPB, class EPI>
__device__ __forceinline__ void dgemm3(const WCtx& w, Smem& sm, const uint8_t* W, int U, int sb, int se, int lg, const bf16* Bg, long ldb, int R, EPI epi) {
  constexpr int R8 = NG * 8, KSP = 256 + 8;
  const int wp = threadIdx.x >> 5, lane = lane_id(), q = wp >> 2, wl = 4 * lg + (wp & 3);
  const int strip = sb + q;
  const bool act = q < SPB && strip < se;
  const int g = lane >> 2, t = lane & 3;
  const int nr = (U + 15) / 16;   // lane rounds
  bf16* bs = reinterpret_cast<bf16*>(&sm.u.g2.b[0]);   // [R8][KSP]
  const uint8_t* ws = W + (long)strip * U * 2048;
  float acc[NG][4];
#pragma unroll
  for (int ng = 0; ng < NG; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  auto ldw = [&](uint4* d, int k) {
    const int u = wl + 16 * k;
    if (act && k < nr && u < U) {
#pragma unroll
      for (int jj = 0; jj < 4; jj++) d[jj] = ldg_nc(ws + ((long)u * 4 + jj) * 512 + lane * 16);
    }
  };
  auto stage = [&](int k, int slot) {   // units 16 k + 4 lg .. + 3 (those < U) of every row -> slot
    const int u0 = 16 * k + 4 * lg, nu = max(0, min(4, U - u0)), nck = nu * 8;
    bf16* b = bs + (long)slot * R8 * KSP;
    for (int i = threadIdx.x; i < R8 * 32; i += NT) {
      const int r = i >> 5, cc = i & 31;
      if (r < R && cc < nck) cp_async16(b + (long)r * KSP + cc * 8, Bg + (long)r * ldb + u0 * 64 + cc * 8);
      else *reinterpret_cast<uint4*>(b + (long)r * KSP + cc * 8) = make_uint4(0, 0, 0, 0);
    }
  };
  constexpr int NRB = (int)(sizeof(sm.u.g2.b) / (R8 * KSP * 2));   // rounds staged per batch
  if (act && (wp & 3) == 0 && lane == 0) pf_l2(ws, U * 2048);
  uint4 w0[4], w1[4];
  pdl_wait();
  for (int k = 0; k < min(nr, NRB); k++) stage(k, k);
  cp_commit();
  ldw(w0, 0); ldw(w1, 1);
  for (int kb = 0; kb < nr; kb += NRB) {
    if (kb > 0) { __syncthreads(); for (int k = kb; k < min(nr, kb + NRB); k++) stage(k, k - kb); cp_commit(); }
    cp_wait<0>(); __syncthreads();
    for (int k = kb; k < min(nr, kb + NRB); k++) {
      const int u = wl + 16 * k;
      const bf16* b = bs + (long)(k - kb) * R8 * KSP;
      if (act && u < U) {
#pragma unroll
        for (int jj = 0; jj < 4; jj++) {
          const int kk = (wp & 3) * 64 + jj * 16 + 2 * t;
#pragma unroll
          for (int ng = 0; ng < NG; ng++) {
            const uint32_t b0 = *reinterpret_cast<const uint32_t*>(b + (long)(ng * 8 + g) * KSP + kk);
            const uint32_t b1 = *reinterpret_cast<const uint32_t*>(b + (long)(ng * 8 + g) * KSP + kk + 8);
            mma_bf16(acc[ng], w0[jj].x, w0[jj].y, w0[jj].z, w0[jj].w, b0, b1);
          }
        }
      }
#pragma unroll
      for (int jj = 0; jj < 4; jj++) w0[jj] = w1[jj];
      ldw(w1, k + 2);
    }
  }
  // lane partials -> global; the last lane group of a strip sums them in lane order
  float* part = w.gpart + ((long)strip * 16 + wl) * (8 * 4 * 32);
  if (act) {
#pragma unroll
    for (int ng = 0; ng < NG; ng++)
#pragma unroll
      for (int i = 0; i < 4; i++) part[(ng * 4 + i) * 32 + lane] = acc[ng][i];
  }
  __threadfence();
  __syncthreads();
  if (threadIdx.x < SPB) {
    const int st = sb + threadIdx.x;
    int mine = 0;
    if (st < se) { const unsigned old = atomicAdd(&w.gcnt[st], 1u); mine = old == 3u; if (mine) w.gcnt[st] = 0u; }
    sm.mlm[threadIdx.x] = mine ? 1.f : 0.f;
  }
  __syncthreads();
  if (act && (wp & 3) == 0 && sm.mlm[q] != 0.f) {
    __threadfence();
    const float* pb0 = w.gpart + (long)strip * 16 * (8 * 4 * 32);
#pragma unroll
    for (int ng = 0; ng < NG; ng++) {
      if (ng * 8 >= R) break;
      float sv[4];
#pragma unroll
      for (int i = 0; i < 4; i++) {
        float x = 0.f;
#pragma unroll
        for (int k = 0; k < 16; k++) x += __ldcg(pb0 + (long)k * (8 * 4 * 32) + (ng * 4 + i) * 32 + lane);
        sv[i] = x;
      }
      epi(strip, ng, sv[0], sv[1], sv[2], sv[3]);
    }
  }
  __syncthreads();
}
#define DG3(R, SPB, ...) do { \
  if ((R) <= 8) dgemm3<1, SPB>(__VA_ARGS__); else if ((R) <= 16) dgemm3<2, SPB>(__VA_ARGS__); \
  else if ((R) <= 32) dgemm3<4, SPB>(__VA_ARGS__); else dgemm3<8, SPB>(__VA_ARGS__); } while (0)
#ifndef DG3_ON
#define DG3_ON 0   // (measured slower: o_proj 20 -> 32 us at 64 rows, bit-identical)
#endif
// NG dispatch by R: one chunk of 8 / 16 rows, else chunks of 32
#ifndef DG64
#define DG64 1
#endif
// k-stage units per n-group count: 4-lane GEMMs 36 / 16 / 16 / 8 (smem <= 66.5 KB for every R), 16-lane GEMMs SK.
// The launch's smem (dg_smem) is the maximum over the variants up to the pass's row bound (R is read on the device).
#define DG2(R, WPS, SK, ...) do { \
  if ((R) <= 8) dgemm2<1, WPS, (WPS == 4 ? 36 : SK)>(__VA_ARGS__); else if ((R) <= 16) dgemm2<2, WPS, (WPS == 4 ? 16 : SK)>(__VA_ARGS__); \
  else if ((R) <= 32 || !DG64) dgemm2<4, WPS, (WPS == 4 ? 16 : SK)>(__VA_ARGS__); else dgemm2<8, WPS, (WPS == 4 ? 8 : 16)>(__VA_ARGS__); } while (0)

// ------------------------------------------------------------------------------------------------ expert pieces
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
#ifndef MOE_DIAG
#define MOE_DIAG 0
#endif
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
#if MOE_DIAG == 1   // diagnostic: no FP4 conversion (bits as f16x2 magnitudes; wrong results)
  o[0] = w & 0x3bff3bffu; o[1] = (w >> 4) & 0x3bff3bffu; o[2] = (w >> 8) & 0x3bff3bffu; o[3] = (w >> 12) & 0x3bff3bffu; return;
#endif
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
#ifdef CVT2   // diagnostic: every conversion twice (results unchanged)
  uint32_t d[4];
  asm volatile("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(d[0]), "=r"(d[1]), "=r"(d[2]), "=r"(d[3]) : "r"(w ^ 0x11111111u));
  if ((d[0] ^ d[1] ^ d[2] ^ d[3]) == 0x7fffffffu) o[0] ^= 1u;
#endif
}
template <int NG>
__device__ __forceinline__ void load_b16_unit(const __half* const* colp, int u, uint2 (*bfr)[4]) {
  const int t = lane_id() & 3;
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    const __half* p = colp[ng];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      if (p) {
        const __half* q = p + u * 64 + j * 16 + 2 * t;
        bfr[ng][j] = make_uint2(*reinterpret_cast<const uint32_t*>(q), *reinterpret_cast<const uint32_t*>(q + 8));
      } else bfr[ng][j] = make_uint2(0, 0);
    }
  }
}
template <int NG>
__device__ __forceinline__ void unit_fp4(const uint4& cw, const uint2& sw, const uint2 (*bfr)[4], float (*acc)[4]) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t ss[2] = {sw.x, sw.y};
#pragma unroll
  for (int jj = 0; jj < 2; jj++) {
    uint32_t sc[4];
    scl4(ss[jj], sc);
#pragma unroll
    for (int h = 0; h < 2; h++) {
      const int j = jj * 2 + h;
      uint32_t a[4];
      cvt4(cc[j], a);
      const uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
      const uint32_t a0 = hmul2(a[0], sg), a1 = hmul2(a[1], sg8), a2 = hmul2(a[2], sg), a3 = hmul2(a[3], sg8);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) mma_f16(acc[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
    }
  }
}
// the same with k16 tiles 0, 2 into acc and 1, 3 into acc2 (two independent mma chains; acc + acc2 at the end)
template <int NG>
__device__ __forceinline__ void unit_fp4_2(const uint4& cw, const uint2& sw, const uint2 (*bfr)[4], float (*acc)[4], float (*acc2)[4]) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t ss[2] = {sw.x, sw.y};
#pragma unroll
  for (int jj = 0; jj < 2; jj++) {
    uint32_t sc[4];
    scl4(ss[jj], sc);
#pragma unroll
    for (int h = 0; h < 2; h++) {
      const int j = jj * 2 + h;
      uint32_t a[4];
      cvt4(cc[j], a);
      const uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
      const uint32_t a0 = hmul2(a[0], sg), a1 = hmul2(a[1], sg8), a2 = hmul2(a[2], sg), a3 = hmul2(a[3], sg8);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) mma_f16(h ? acc2[ng] : acc[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
    }
  }
}
// NVFP4 unit with f16 block scales: lane (g, t) holds 8 f16 = (row g, row g+8) for k16 tiles 0..3
template <int NG>
__device__ __forceinline__ void unit_fp4h(const uint4& cw, const uint4& sv, const uint2 (*bfr)[4], float (*acc)[4]) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t pr[4] = {sv.x, sv.y, sv.z, sv.w};
#pragma unroll
  for (int j = 0; j < 4; j++) {
    uint32_t a[4];
    cvt4(cc[j], a);
    uint32_t sg, sg8;
    asm("prmt.b32 %0, %1, %1, 0x1010;" : "=r"(sg) : "r"(pr[j]));
    asm("prmt.b32 %0, %1, %1, 0x3232;" : "=r"(sg8) : "r"(pr[j]));
    const uint32_t a0 = hmul2(a[0], sg), a1 = hmul2(a[1], sg8), a2 = hmul2(a[2], sg), a3 = hmul2(a[3], sg8);
#pragma unroll
    for (int ng = 0; ng < NG; ng++) mma_f16(acc[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
  }
}
template <int NG>
__device__ __forceinline__ void unit_fp8(const uint4& c0, const uint4& c1, uint32_t sw, const uint2 (*bfr)[4], float (*acc)[4]) {
  uint32_t cc[8] = {c0.x, c0.y, c0.z, c0.w, c1.x, c1.y, c1.z, c1.w};
#pragma unroll
  for (int blk = 0; blk < 2; blk++) {
    float d[NG][4];
#pragma unroll
    for (int ng = 0; ng < NG; ng++) { d[ng][0] = d[ng][1] = d[ng][2] = d[ng][3] = 0.f; }
#pragma unroll
    for (int h = 0; h < 2; h++) {
      const int j = blk * 2 + h;
      const uint32_t x0 = cc[2 * j], x1 = cc[2 * j + 1];
      const uint32_t a0 = cvt_e4m3x2(x0 & 0xffff), a1 = cvt_e4m3x2(x0 >> 16), a2 = cvt_e4m3x2(x1 & 0xffff), a3 = cvt_e4m3x2(x1 >> 16);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) mma_f16(d[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
    }
    const uint32_t e0 = (sw >> (16 * blk)) & 0xff, e1 = (sw >> (16 * blk + 8)) & 0xff;
    const float s0 = e0 ? __int_as_float(e0 << 23) : __int_as_float(0x00400000), s1 = e1 ? __int_as_float(e1 << 23) : __int_as_float(0x00400000);
#pragma unroll
    for (int ng = 0; ng < NG; ng++) {
      acc[ng][0] = fmaf(d[ng][0], s0, acc[ng][0]); acc[ng][1] = fmaf(d[ng][1], s0, acc[ng][1]);
      acc[ng][2] = fmaf(d[ng][2], s1, acc[ng][2]); acc[ng][3] = fmaf(d[ng][3], s1, acc[ng][3]);
    }
  }
}
// a whole expert strip (U units, increasing order) on one warp
template <int NG>
__device__ __forceinline__ void strip_fp4(const uint8_t* wst, int U, const __half* const* colp, float (*acc)[4]) {
  const int lane = lane_id(), g = lane >> 2;
  constexpr int UNR = 6;
#pragma unroll 1
  for (int u = 0; u < U; u += UNR) {
    uint4 cw[UNR]; uint2 sw[UNR];
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      cw[q] = ldg_nc(wst + (long)(u + q) * 576 + lane * 16);
      sw[q] = ldg_nc2(wst + (long)(u + q) * 576 + 512 + g * 8);
    }
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      uint2 bfr[NG][4];
      load_b16_unit<NG>(colp, u + q, bfr);
      unit_fp4<NG>(cw[q], sw[q], bfr, acc);
    }
  }
}
template <int NG>
__device__ __forceinline__ void strip_fp8(const uint8_t* wst, int U, const __half* const* colp, float (*acc)[4]) {
  const int lane = lane_id(), g = lane >> 2;
  constexpr int UNR = 3;
#pragma unroll 1
  for (int u = 0; u < U; u += UNR) {
    uint4 c0[UNR], c1[UNR]; uint32_t sw[UNR];
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      c0[q] = ldg_nc(wst + (long)(u + q) * 1056 + lane * 32);
      c1[q] = ldg_nc(wst + (long)(u + q) * 1056 + lane * 32 + 16);
      sw[q] = ldg_nc1(wst + (long)(u + q) * 1056 + 1024 + g * 4);
    }
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      uint2 bfr[NG][4];
      load_b16_unit<NG>(colp, u + q, bfr);
      unit_fp8<NG>(c0[q], c1[q], sw[q], bfr, acc);
    }
  }
}
__device__ __forceinline__ float act_fn(float g, float u) {
  float a = 4.0f * tanhf(g / 4.0f) * sigm(g);
  return a * (25.0f * tanhf(u / 25.0f));
}
__device__ __forceinline__ float sconv_static(float x, float x1, float x2, float x3, const bf16* w4) {
  float acc = __fmul_rn(x3, bf(w4[0]));
  acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
  acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
  acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
  return __fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f);
}

// ------------------------------------------------------------------------------------------------ phases
#define WARGS const WCtx& w, const Ctx& c, const WHdr& hd, Smem& sm
#define GROUPS ((int)gridDim.x * 4)
#define GI ((int)(threadIdx.x >> 7))
#define GT ((int)(threadIdx.x & 127))
#define GID ((int)blockIdx.x * 4 + GI)
__device__ __forceinline__ int rseq(const Smem& sm, int r) { return sm.rows[r][0]; }
__device__ __forceinline__ int rpos(const Smem& sm, int r) { return sm.rows[r][1]; }
__device__ __forceinline__ long ring_row(int slot, int seq, int t) { return ((long)slot * NSQ + seq) * RING + (t & (RING - 1)); }

// attention-input sources of application a for row r: blocks + pin
__device__ __forceinline__ void attn_srcs(const WCtx& w, const App& ap, int r, uint32_t (*v)[RPJ], unsigned& msk, int gt) {
  msk = ((1u << ap.nblk) - 1u) | 16u;
#pragma unroll
  for (int s = 0; s < 5; s++) {
    const int idx = s < 4 ? ap.blk[s] : ap.pin;
    if ((msk >> s) & 1u) ld_row(w.pb + ((long)idx * MAXR + r) * H, v[s], gt);
    else {
#pragma unroll
      for (int j = 0; j < RPJ; j++) v[s][j] = 0u;
    }
  }
}
// ungated attention input: jobs (row, stream q < nq) -> X[q][r]
__device__ __forceinline__ void ph_attn_in(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int nq = L.glob ? 3 : 1, R = sm.R, gi = GI, gt = GT;
  for (int job = GID; job < R * nq; job += GROUPS) {
    const int r = job / nq, q = job % nq;
    float x[2 * RPJ];
    if (a == 0) {
      const int tok = min(max(sm.rows[r][2], 0), 201023);
      const bf16* er = c.embed + (long)tok * H;
      float s[1] = {0.f};
#pragma unroll
      for (int j = 0; j < RPJ; j++) {
        const __nv_bfloat162 e2 = *reinterpret_cast<const __nv_bfloat162*>(er + REL(j));
        x[2 * j] = bf(e2.x); x[2 * j + 1] = bf(e2.y);
        s[0] = fmaf(x[2 * j + 1], x[2 * j + 1], fmaf(x[2 * j], x[2 * j], s[0]));
      }
      gsum<1>(s, sm, gi, gt);
      const float rr = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
      for (int j = 0; j < RPJ; j++) {
        const __nv_bfloat162 nw = *reinterpret_cast<const __nv_bfloat162*>(sm.nwv[3] + REL(j));
        const uint32_t hv = pack_bf2(x[2 * j] * rr * bf(nw.x), x[2 * j + 1] * rr * bf(nw.y));
        if (q == 0) *reinterpret_cast<uint32_t*>(w.pb + (long)r * H + REL(j)) = hv;
        x[2 * j] = bf_lo(hv); x[2 * j + 1] = bf_hi(hv);
      }
    } else {
      uint32_t v[5][RPJ];
      unsigned msk;
      attn_srcs(w, ap, r, v, msk, gt);
      g_mix<5>(v, nullptr, -1, msk, sm.qv[q], x, sm, gi, gt);
    }
    g_norm_store(x, sm.nwv[q], w.X + ((long)q * MAXR + r) * H, sm, gi, gt);
  }
}

// the attention conv (from the ha ring, all of this pass's rows written by o_proj) -> as[r]; the MLP mix -> x
__device__ __forceinline__ void mlp_x(WARGS, int a, int r, float* x) {
  const App& ap = c.A[a];
  const int gi = GI, gt = GT;
  const int seq = rseq(sm, r), t = rpos(sm, r);
  const bool add_pin = !(a == 0 || ap.bnd);
  const unsigned msk = ((a == 0) ? 1u : (((1u << ap.nblk) - 1u) | (ap.bnd ? 16u : 0u))) | 32u;
  // every load first: the mix sources, the pin row, the four ring rows of the attention conv
  uint32_t v[6][RPJ];
#pragma unroll
  for (int s5 = 0; s5 < 5; s5++) {
    const int idx = s5 == 0 ? (a == 0 ? 0 : ap.blk[0]) : (s5 < 4 ? ap.blk[s5] : ap.pin);
    if ((msk >> s5) & 1u) ld_row(w.pb + ((long)idx * MAXR + r) * H, v[s5], gt);
    else {
#pragma unroll
      for (int j = 0; j < RPJ; j++) v[s5][j] = 0u;
    }
  }
  uint32_t pv[RPJ];
  if (add_pin) ld_row(w.pb + ((long)ap.pin * MAXR + r) * H, pv, gt);
  float asv[2 * RPJ];
  {
    const bf16* h0 = w.ha + ring_row(ap.slot, seq, t) * H;
    const bf16* h1 = w.ha + ring_row(ap.slot, seq, t - 1) * H;
    const bf16* h2 = w.ha + ring_row(ap.slot, seq, t - 2) * H;
    const bf16* h3 = w.ha + ring_row(ap.slot, seq, t - 3) * H;
    uint32_t hv[4][RPJ];
#pragma unroll
    for (int j = 0; j < RPJ; j++) { const int el = REL(j); hv[0][j] = ldu(h0 + el); hv[1][j] = ldu(h1 + el); hv[2][j] = ldu(h2 + el); hv[3][j] = ldu(h3 + el); }
#pragma unroll
    for (int j = 0; j < RPJ; j++) {
      const int el = REL(j);
      const uint2 wa = *reinterpret_cast<const uint2*>(sm.tap + el * 4), wb = *reinterpret_cast<const uint2*>(sm.tap + el * 4 + 4);
      const float y0 = sconv_static(bf_lo(hv[0][j]), bf_lo(hv[1][j]), bf_lo(hv[2][j]), bf_lo(hv[3][j]), reinterpret_cast<const bf16*>(&wa));
      const float y1 = sconv_static(bf_hi(hv[0][j]), bf_hi(hv[1][j]), bf_hi(hv[2][j]), bf_hi(hv[3][j]), reinterpret_cast<const bf16*>(&wb));
      const uint32_t pk = pack_bf2(y0, y1);
      *reinterpret_cast<uint32_t*>(w.as + (long)r * H + el) = pk;
      asv[2 * j] = bf_lo(pk); asv[2 * j + 1] = bf_hi(pk);
    }
  }
  if (add_pin) {
#pragma unroll
    for (int j = 0; j < RPJ; j++) { asv[2 * j] = bf_lo(pv[j]) + asv[2 * j]; asv[2 * j + 1] = bf_hi(pv[j]) + asv[2 * j + 1]; }
  }
#pragma unroll
  for (int j = 0; j < RPJ; j++) v[5][j] = 0u;
  g_mix<6>(v, asv, 5, msk, sm.qv[6], x, sm, gi, gt);
}
// MLP input of row r from x (f32): router input y (bf16), expert input x16 (f16 hi / lo with scale 2^sh), s16
__device__ __forceinline__ void mlp_norm(WARGS, int a, int r, const float* x) {
  const LayerW& L = c.L[c.A[a].layer];
  const int gi = GI, gt = GT;
  float wv[2 * RPJ];
  float s[1] = {0.f}, mx = 0.f;
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const __nv_bfloat162 w2 = *reinterpret_cast<const __nv_bfloat162*>(sm.mlpn + REL(j));
    wv[2 * j] = bf(w2.x); wv[2 * j + 1] = bf(w2.y);
  }
#pragma unroll
  for (int k = 0; k < 2 * RPJ; k++) { s[0] = fmaf(x[k], x[k], s[0]); mx = fmaxf(mx, fabsf(x[k] * wv[k])); }
  gsum<1>(s, sm, gi, gt);
  mx = gmax1(mx, sm, gi, gt);
  const float rr = rsqrtf(s[0] / (float)H + 1e-6f);
  int e2 = 0;
  const float bound = mx * rr;
  frexpf(bound, &e2);
  const int sh = (bound > 0.f) ? 15 - e2 : 0;
  const float scl = ldexpf(1.0f, sh);
  __half* xh = w.x16 + (long)r * 2 * H;
#pragma unroll
  for (int j = 0; j < RPJ; j++) {
    const int el = REL(j);
    const uint32_t yb = pack_bf2(x[2 * j] * rr * wv[2 * j], x[2 * j + 1] * rr * wv[2 * j + 1]);
    *reinterpret_cast<uint32_t*>(w.y + (long)r * H + el) = yb;
    const float y0 = bf_lo(yb) * scl, y1 = bf_hi(yb) * scl;
    const __half h0 = __float2half_rn(y0), h1 = __float2half_rn(y1);
    const __half l0 = __float2half_rn((y0 - __half2float(h0)) * 16777216.0f), l1 = __float2half_rn((y1 - __half2float(h1)) * 16777216.0f);
    *reinterpret_cast<__half2*>(xh + el) = __halves2half2(h0, h1);
    *reinterpret_cast<__half2*>(xh + H + el) = __halves2half2(l0, l1);
  }
  if (gt == 0) w.s16[r] = ldexpf(1.0f, -sh);
}
__device__ __forceinline__ void ph_mlp_in(WARGS, int a) {
  for (int r = GID; r < sm.R; r += GROUPS) {
    float x[2 * RPJ];
    mlp_x(w, c, hd, sm, a, r, x);
    mlp_norm(w, c, hd, sm, a, r, x);
  }
}

// gate jobs (row, controller in [c0, c0 + nc)): x = the stream's mix (controller 3: the MLP mix), m = the loop
// message mix -> xg, mg (f32), ub = [bf16(x / rms x), bf16(m / rms m)]
__device__ __forceinline__ void ph_gate_mix(WARGS, int a, int c0, int nc) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R, gi = GI, gt = GT;
  for (int job = GID; job < R * nc; job += GROUPS) {
    const int r = job / nc, ctrl = c0 + job % nc;
    float x[2 * RPJ], m[2 * RPJ];
    if (ctrl < 3) {   // the x sources and the messages loaded together, then the two mixes
      uint32_t v[5][RPJ], ms[2][RPJ];
      unsigned msk;
      ld_row(w.pb + ((long)ap.msg[0] * MAXR + r) * H, ms[0], gt);
      ld_row(w.pb + ((long)ap.msg[1] * MAXR + r) * H, ms[1], gt);
      attn_srcs(w, ap, r, v, msk, gt);
      g_mix<2>(ms, nullptr, -1, 3u, sm.qv[3 + ctrl], m, sm, gi, gt);
      g_mix<5>(v, nullptr, -1, msk, sm.qv[ctrl], x, sm, gi, gt);
    } else {
      uint32_t ms[2][RPJ];
      ld_row(w.pb + ((long)ap.msg[0] * MAXR + r) * H, ms[0], gt);
      ld_row(w.pb + ((long)ap.msg[1] * MAXR + r) * H, ms[1], gt);
      mlp_x(w, c, hd, sm, a, r, x);
      g_mix<2>(ms, nullptr, -1, 3u, sm.qv[7], m, sm, gi, gt);
    }
    float s2[2] = {0.f, 0.f};
#pragma unroll
    for (int k = 0; k < 2 * RPJ; k++) { s2[0] = fmaf(x[k], x[k], s2[0]); s2[1] = fmaf(m[k], m[k], s2[1]); }
    gsum<2>(s2, sm, gi, gt);
    const float rx = rsqrtf(s2[0] / (float)H + 1e-6f), rm = rsqrtf(s2[1] / (float)H + 1e-6f);
    const long o = ((long)r * 4 + ctrl) * H;
    bf16* u = w.ub + ((long)r * 4 + ctrl) * 2 * H;
#pragma unroll
    for (int j = 0; j < RPJ; j++) {
      const int el = REL(j);
      *reinterpret_cast<float2*>(w.xg + o + el) = make_float2(x[2 * j], x[2 * j + 1]);
      *reinterpret_cast<float2*>(w.mg + o + el) = make_float2(m[2 * j], m[2 * j + 1]);
      *reinterpret_cast<uint32_t*>(u + el) = pack_bf2(x[2 * j] * rx, x[2 * j + 1] * rx);
      *reinterpret_cast<uint32_t*>(u + H + el) = pack_bf2(m[2 * j] * rm, m[2 * j + 1] * rm);
    }
  }
}
// gate D: gv[r][ctrl][j] = bf16((D_ctrl ub[r][ctrl])[j]); tasks (ctrl, strip of 16)
__device__ __forceinline__ void ph_gate_dg(WARGS, int a, int c0, int nc) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R;
  for (int task = blockIdx.x; task < nc * 4 * (DG3_ON ? 4 : 1); task += gridDim.x) {
    const int tk = DG3_ON ? task >> 2 : task;
    const int ctrl = c0 + tk / 4, strip = ctrl * 4 + tk % 4;
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = (s - ctrl * 4) * 16 + g + 8 * (i >> 1);
        if (r < R) w.gv[((long)r * 4 + ctrl) * 64 + row] = rbf(av[i]);
      }
    };
    if (DG3_ON) DG3(R, 1, w, sm, L.cD, 72, strip, strip + 1, task & 3, w.ub + (long)ctrl * 2 * H, 4L * 2 * H, R, epi);
    else DG2(R, 16, 16, sm, L.cD, 72, strip, strip + 1, w.ub + (long)ctrl * 2 * H, 4L * 2 * H, R, epi);
  }
}
// gate F / G: x' = (1 - tanh(F gv)) x + tanh(G gv) m; one warp per (ctrl, strip of 8 (F, G) row pairs)
template <int NG>
__device__ __forceinline__ void gate_fg_t(WARGS, int a, int c0, int nc) {
  const App& ap = c.A[a];
  const uint8_t* FG = w.fg[ap.layer];
  const int R = sm.R;
  for (int i = threadIdx.x; i < R * 4 * 64; i += NT) {
    const int r = i / 256, cc = (i / 64) & 3, j = i & 63;
    sm.u.gvs[r][cc][j] = tobf(ldf(w.gv + i));
  }
  for (int i = threadIdx.x; i < (NG * 8 - R) * 4 * 64; i += NT) {
    const int r = R + i / 256, cc = (i / 64) & 3, j = i & 63;
    sm.u.gvs[r][cc][j] = tobf(0.f);
  }
  __syncthreads();
  const int lane = lane_id(), g = lane >> 2, t = lane & 3;
  const int nt = nc * 288;
  for (int wt = blockIdx.x * NW + (threadIdx.x >> 5); wt < nt; wt += gridDim.x * NW) {
    const int ctrl = c0 + wt / 288, strip = wt % 288;
    const uint8_t* ws = FG + ((long)ctrl * 288 + strip) * 2048;
    uint4 wc[4];
#pragma unroll
    for (int jj = 0; jj < 4; jj++) wc[jj] = ldg_nc(ws + jj * 512 + lane * 16);
    float acc[NG][4];
#pragma unroll
    for (int ng = 0; ng < NG; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
#pragma unroll
    for (int jj = 0; jj < 4; jj++)
#pragma unroll
      for (int ng = 0; ng < NG; ng++) {
        const uint32_t b0 = *reinterpret_cast<const uint32_t*>(&sm.u.gvs[ng * 8 + g][ctrl][jj * 16 + 2 * t]);
        const uint32_t b1 = *reinterpret_cast<const uint32_t*>(&sm.u.gvs[ng * 8 + g][ctrl][jj * 16 + 8 + 2 * t]);
        mma_bf16(acc[ng], wc[jj].x, wc[jj].y, wc[jj].z, wc[jj].w, b0, b1);
      }
    // rows strip*16 + g (+8): pair i = row / 2, F if row even, G if odd; the partner row is lane ^ 4
#pragma unroll
    for (int ng = 0; ng < NG; ng++)
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const float f = tanhf(acc[ng][i]);
        const float o = __shfl_xor_sync(0xffffffffu, f, 4);
        const int r = ng * 8 + 2 * t + (i & 1), row = strip * 16 + g + 8 * (i >> 1), ch = row >> 1;
        if ((g & 1) == 0 && r < R) {   // (f, g) of the channel; x' = (1 - f) x + g m in the gate-norm phase
          const long off = ((long)r * 4 + ctrl) * H + ch;
          reinterpret_cast<float2*>(w.xp)[off] = make_float2(f, o);
        }
      }
  }
}
__device__ __forceinline__ void ph_gate_fg(WARGS, int a, int c0, int nc) {
  const int R = sm.R;
  if (R <= 8) gate_fg_t<1>(w, c, hd, sm, a, c0, nc);
  else if (R <= 16) gate_fg_t<2>(w, c, hd, sm, a, c0, nc);
  else if (R <= 32) gate_fg_t<4>(w, c, hd, sm, a, c0, nc);
  else gate_fg_t<8>(w, c, hd, sm, a, c0, nc);
}
// gated rows -> the attention-input streams (ctrl < 3) or the MLP input (ctrl 3)
__device__ __forceinline__ void ph_gate_norm(WARGS, int a, int c0, int nc) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R, gi = GI, gt = GT;
  for (int job = GID; job < R * nc; job += GROUPS) {
    const int r = job / nc, ctrl = c0 + job % nc;
    float x[2 * RPJ];
    const long o0 = ((long)r * 4 + ctrl) * H;
    const float2* fg = reinterpret_cast<const float2*>(w.xp) + o0;
#pragma unroll
    for (int j = 0; j < RPJ; j++) {
      const int el = REL(j);
      const float2 xv = __ldcg(reinterpret_cast<const float2*>(w.xg + o0 + el)), mv = __ldcg(reinterpret_cast<const float2*>(w.mg + o0 + el));
      const float4 fv = __ldcg(reinterpret_cast<const float4*>(fg + el));   // (f, g) of channels el, el + 1
      // x' = fma(1 - f, x, g m): the operation sequence the F/G epilogue compiled to before (bit-identical)
      x[2 * j] = __fmaf_rn(__fsub_rn(1.f, fv.x), xv.x, __fmul_rn(fv.y, mv.x));
      x[2 * j + 1] = __fmaf_rn(__fsub_rn(1.f, fv.z), xv.y, __fmul_rn(fv.w, mv.y));
    }
    if (ctrl < 3) g_norm_store(x, sm.nwv[ctrl], w.X + ((long)ctrl * MAXR + r) * H, sm, gi, gt);
    else mlp_norm(w, c, hd, sm, a, r, x);
  }
}

// qkv: tasks of up to 4 strips of one input stream; epilogue: qkv[r][row] = bf16-rounded; raw k / v -> rings
__device__ __forceinline__ void ph_qkv(WARGS, int a, int nq) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R, nsk = L.nsk;
  const int nst = QG_STRIPS + 2 * nsk;
  int nt0, nt1;
  if (nq == 1) { nt0 = (nst + 3) / 4; nt1 = 0; }
  else { nt0 = (QG_STRIPS + 3) / 4; nt1 = (nsk + 3) / 4; }
  const int ntask = nt0 + 2 * nt1;
  for (int task = blockIdx.x; task < ntask; task += gridDim.x) {
    int sb, se, st;
    if (nq == 1) { sb = task * 4; se = min(sb + 4, nst); st = 0; }
    else if (task < nt0) { sb = task * 4; se = min(sb + 4, QG_STRIPS); st = 0; }
    else { const int k = task - nt0; st = 1 + k / nt1; const int b0 = QG_STRIPS + (st - 1) * nsk; sb = b0 + (k % nt1) * 4; se = min(sb + 4, b0 + nsk); }
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const int orow = s < QG_STRIPS ? s * 16 : (s < QG_STRIPS + nsk ? K0 + (s - QG_STRIPS) * 16 : V0 + (s - QG_STRIPS - nsk) * 16);
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = orow + g + 8 * (i >> 1);
        if (r >= R) continue;
        const float v = rbf(av[i]);
        w.qkv[(long)r * QKVR + row] = v;
        if (row >= K0 && row < K0 + 1024) w.hk[ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * 1024 + row - K0] = tobf(v);
        else if (row >= V0 && row < V0 + 1024) w.hv[ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * 1024 + row - V0] = tobf(v);
      }
    };
    DG2(R, 4, 36, sm, L.wqkv, 36, sb, se, w.X + (long)st * MAXR * H, (long)H, R, epi);
  }
}
// k / v of every row: short conv over positions (raw values from the rings), clip (k) / rms norm (v) -> caches
__device__ __forceinline__ void ph_kv(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R, lane = lane_id();
  // q (scaled, L2-clipped, bf16) and the relative features (clipped) of every (row, head), for the attention items
  for (int wt = blockIdx.x * NW + (threadIdx.x >> 5); wt < R * NQH; wt += gridDim.x * NW) {
    const int r = wt / NQH, h = wt % NQH;
    const float* qr = w.qkv + (long)r * QKVR;
    float qv[4], ss = 0.f;
#pragma unroll
    for (int k = 0; k < 4; k++) { const int d = lane * 4 + k; qv[k] = ldf(qr + h * HD + d) * bf(L.qscale[h * HD + d]); }
#pragma unroll
    for (int k = 0; k < 4; k++) ss = fmaf(qv[k], qv[k], ss);
#pragma unroll
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
    const float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
    uint2 pk; pk.x = pack_bf2(qv[0] * f, qv[1] * f); pk.y = pack_bf2(qv[2] * f, qv[3] * f);
    *reinterpret_cast<uint2*>(w.qp + ((long)r * NQH + h) * HD + lane * 4) = pk;
    const float rv = lane < 16 ? ldf(qr + R_R + h * 16 + lane) * bf(L.rscale[h * 16 + lane]) : 0.f;
    float s2 = rv * rv;
#pragma unroll
    for (int o = 16; o; o >>= 1) s2 += __shfl_xor_sync(0xffffffffu, s2, o);
    const float f2 = fminf(8.0f / (sqrtf(s2) + 1e-6f), 1.0f);
    if (lane < 16) w.rp[((long)r * NQH + h) * 16 + lane] = rbf(rv * f2);
  }
  for (int wt = blockIdx.x * NW + (threadIdx.x >> 5); wt < R * 16; wt += gridDim.x * NW) {
    const int r = wt >> 4, g = (wt >> 1) & 7, isv = wt & 1;
    const int seq = rseq(sm, r), t = rpos(sm, r);
    const int base = isv ? V0 : K0;
    const bf16* hist = (isv ? w.hv : w.hk);
    const bf16* sc = isv ? L.vsc : L.ksc;
    const float* qr = w.qkv + (long)r * QKVR;
    float kv[4], ss = 0.f;
    float dyn[4] = {0.f, 0.f, 0.f, 0.f};
    if (L.glob) {
#pragma unroll
      for (int lag = 0; lag < 4; lag++) dyn[lag] = ldf(qr + base + 1024 + g * 4 + lag);
    }
#pragma unroll
    for (int k = 0; k < 4; k++) {
      const int ch = g * HD + lane * 4 + k;
      const float x = ldf(qr + base + ch);
      const float x1 = bf(hist[ring_row(ap.slot, seq, t - 1) * 1024 + ch]);
      const float x2 = bf(hist[ring_row(ap.slot, seq, t - 2) * 1024 + ch]);
      const float x3 = bf(hist[ring_row(ap.slot, seq, t - 3) * 1024 + ch]);
      float y;
      if (!L.glob) {
        const uint2 wv = *reinterpret_cast<const uint2*>(sc + ch * 4);
        const bf16* w4 = reinterpret_cast<const bf16*>(&wv);
        float acc = __fmul_rn(x3, bf(w4[0]));
        acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
        acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
        acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
        y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f));
      } else {
        const float xs4[4] = {x, x1, x2, x3};
        float acc = 0.f;
#pragma unroll
        for (int lag = 0; lag < 4; lag++) acc = __fadd_rn(acc, __fmul_rn(xs4[lag], __fadd_rn(bf(sc[lag * 1024 + ch]), dyn[lag])));
        y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.33333333333333333f));
      }
      kv[k] = y;
      ss = fmaf(y, y, ss);
    }
#pragma unroll
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
    const float f = isv ? rsqrtf(ss / 128.f + 1e-6f) : fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
    bf16* dst = (isv ? w.vc : w.kc) + ((((long)ap.slot * NSQ + seq) * NKV + g) * w.maxctx + t) * HD + lane * 4;
    uint2 pk;
    pk.x = pack_bf2(kv[0] * f, kv[1] * f);
    pk.y = pack_bf2(kv[2] * f, kv[3] * f);
    *reinterpret_cast<uint2*>(dst) = pk;
  }
}

// attention: items (sequence, kv head g, chunk c of 128 absolute key positions); every row of the sequence (<= 8) x
// 3 query heads = 24 query rows; per (row, head, chunk) a record (m, l, o); the last item of (sequence, g) merges the
// records of each row's own chunk range in increasing order and applies the output gate and the sink
__device__ __forceinline__ void ph_attn(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int glob = L.glob;
  const int tid = threadIdx.x, wp = tid >> 5, lane = tid & 31, g8 = lane >> 2, t4 = lane & 3;
  auto& at = sm.u.at;
  int ncs[NSQ], cmn[NSQ], npt[NSQ], nitem = 0, tch = 0;
  for (int i = 0; i < sm.nsq; i++) {
    const int t0 = rpos(sm, sm.sq_r0[i]), t1 = t0 + sm.sq_n[i] - 1;
    cmn[i] = (glob ? 0 : max(0, t0 + 1 - 1024)) / ACH;
    ncs[i] = t1 / ACH - cmn[i] + 1;
    tch += NKV * ncs[i];
  }
  // an item = (sequence, kv head, part of up to CPI consecutive chunks), the chunks' K / V double-buffered
#ifndef ATT_CPI
#define ATT_CPI 0
#endif
  const int CPI = ATT_CPI > 0 ? ATT_CPI : max(1, (tch + (int)gridDim.x - 1) / (int)gridDim.x);
  for (int i = 0; i < sm.nsq; i++) { npt[i] = (ncs[i] + CPI - 1) / CPI; nitem += NKV * npt[i]; }
  const float NEG = -__int_as_float(0x7f800000);
  amark(0);
  for (int it = blockIdx.x; it < nitem; it += gridDim.x) {
    amark(1);
    int i = 0, rem = it;
    while (rem >= NKV * npt[i]) { rem -= NKV * npt[i]; i++; }
    const int g = rem / npt[i], part = rem % npt[i];
    const int cA = cmn[i] + part * CPI, cB = min(cmn[i] + ncs[i], cA + CPI);
    const int seq = sm.sq_seq[i], r0 = sm.sq_r0[i], n = sm.sq_n[i], t0 = rpos(sm, r0), tmax = t0 + n - 1;
    const long cb = (((long)ap.slot * NSQ + seq) * NKV + g) * w.maxctx;
    auto issue_kv = [&](int chq, int bq) {
      const int kq0 = chq * ACH, nkq = min(ACH, tmax + 1 - kq0), ntq = (nkq + 15) >> 4;
      const bf16* kb = w.kc + (cb + kq0) * HD;
      const bf16* vb = w.vc + (cb + kq0) * HD;
      for (int q = tid; q < nkq * 16; q += NT) {
        const int rr = q >> 4, cc = (q & 15) * 8;
        cp_async16(&at.kk[bq][rr][cc], kb + (long)q * 8);
        cp_async16(&at.vv[bq][rr][cc], vb + (long)q * 8);
      }
      cp_commit();
      for (int q = tid; q < (ntq * 16 - nkq) * 16; q += NT) {
        const int rr = nkq + (q >> 4), cc = (q & 15) * 8;
        *reinterpret_cast<uint4*>(&at.kk[bq][rr][cc]) = make_uint4(0, 0, 0, 0);
        *reinterpret_cast<uint4*>(&at.vv[bq][rr][cc]) = make_uint4(0, 0, 0, 0);
      }
    };
    // q (clipped, bf16) and the relative features of the 3 n query rows qi = 3 j + hh (prepared by k_kv)
    for (int q = tid; q < 24 * 16; q += NT) {
      const int qi = q >> 4, cc = q & 15;
      if (qi < 3 * n) cp_async16(&at.qb[qi][cc * 8], w.qp + ((long)(r0 + qi / 3) * NQH + 3 * g + qi % 3) * HD + cc * 8);
      else *reinterpret_cast<uint4*>(&at.qb[qi][cc * 8]) = make_uint4(0, 0, 0, 0);
    }
    cp_commit();   // (qb: used by the scores, after the K / V wait)
    for (int q = tid; q < 24 * 16; q += NT) {   // rr: used by the bias before that wait -> plain loads
      const int qi = q >> 4, k = q & 15;
      at.rr[qi][k] = qi < 3 * n ? ldf(w.rp + ((long)(r0 + qi / 3) * NQH + 3 * g + qi % 3) * 16 + k) : 0.f;
    }
    for (int q = tid; q < 8 * (ACH + 8) / 2; q += NT) {
      reinterpret_cast<uint32_t*>(&at.ph[24][0])[q] = 0u;
      reinterpret_cast<uint32_t*>(&at.pl[24][0])[q] = 0u;
    }
    issue_kv(cA, 0);
    for (int ch = cA; ch < cB; ch++) {
    const int buf = (ch - cA) & 1;
    cmark(ch - cA, 0);
    const int k0 = ch * ACH, nk = min(ACH, tmax + 1 - k0), ntile = (nk + 15) >> 4;
    // relp rows of the chunk's distances -> smem; the next chunk's K / V into the other buffer
    const int dmin = max(0, t0 - (k0 + nk - 1)), dmax = min(1023, tmax - k0), nd = max(0, dmax - dmin + 1);
    for (int q = tid; q < 16 * nd; q += NT) { const int rr = q / nd, dd = q % nd; at.pr[rr][dd] = bf(L.relp[rr * 1024 + dmin + dd]); }
    const bool nxt = ch + 1 < cB;
    if (nxt) issue_kv(ch + 1, buf ^ 1);
    cmark(ch - cA, 1);
    __syncthreads();
    amark(2);
    // relative bias (0 beyond distance 1023) or -inf outside the row's window
    for (int q = tid; q < 24 * ACH; q += NT) {
      const int qi = q / ACH, kk = q % ACH, j = qi / 3;
      float v = NEG;
      if (j < n && kk < nk) {
        const int key = k0 + kk, t = t0 + j, lo = glob ? 0 : max(0, t + 1 - 1024);
        if (key >= lo && key <= t) {
          const int dist = t - key;
          if (dist < 1024) {
            float bsum = 0.f;
#pragma unroll
            for (int rr = 0; rr < 16; rr++) bsum += at.rr[qi][rr] * at.pr[rr][dist - dmin];
            v = rbf(bsum);
          } else v = 0.f;
        }
      }
      at.sc[qi][kk] = v;
    }
    amark(3);
    cmark(ch - cA, 2);
    if (nxt) cp_wait<1>(); else cp_wait<0>();
    __syncthreads();
    amark(4);
    cmark(ch - cA, 3);
    // scores S[qi][key] = (K q) / sqrt(128) + bias: warp task (key tile, query n-tile)
    for (int task = wp; task < ntile * 3; task += NW) {
      const int kt = task / 3, nt = task % 3;
      float acc[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
      for (int ks = 0; ks < HD / 16; ks++) {
        uint32_t af[4];
        ldsm_x4(af, &at.kk[buf][16 * kt + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        const uint32_t b0 = *reinterpret_cast<const uint32_t*>(&at.qb[nt * 8 + g8][16 * ks + 2 * t4]);
        const uint32_t b1 = *reinterpret_cast<const uint32_t*>(&at.qb[nt * 8 + g8][16 * ks + 8 + 2 * t4]);
        mma_bf16(acc, af[0], af[1], af[2], af[3], b0, b1);
      }
#pragma unroll
      for (int q = 0; q < 4; q++) {
        const int key = 16 * kt + g8 + (q >> 1) * 8, qi = nt * 8 + 2 * t4 + (q & 1);
        if (key < nk) { const float b = at.sc[qi][key]; if (b != NEG) at.sc[qi][key] = acc[q] * 0.08838834764831845f + b; }
      }
    }
    __syncthreads();
    amark(5);
    cmark(ch - cA, 4);
    // softmax per query row over the chunk: p = exp(s - m) as bf16 hi + lo
    for (int qi = wp; qi < 24; qi += NW) {
      float m = NEG;
#pragma unroll
      for (int k = 0; k < 4; k++) { const int kk = lane + 32 * k; if (kk < nk) m = fmaxf(m, at.sc[qi][kk]); }
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, o));
      float l = 0.f;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int kk = lane + 32 * k;
        const float s = kk < nk ? at.sc[qi][kk] : NEG;
        const float e = (s != NEG) ? expf(s - m) : 0.f;
        const bf16 eh = tobf(e);
        at.ph[qi][kk] = eh;
        at.pl[qi][kk] = tobf(e - bf(eh));
        l += e;
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffffu, l, o);
      if (lane == 0) { sm.mlm[qi] = m; sm.mll[qi] = l; }
    }
    __syncthreads();
    amark(6);
    cmark(ch - cA, 5);
    // O[qi][d] = sum_key (Phi + Plo)[qi][key] V[key][d]: warp = (m-tile w / 8, dims 16 (w % 8) .. + 15)
    {
      const int mt = wp >> 3, wd = wp & 7;
      float acc[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
      for (int ks = 0; ks < ntile; ks++) {
        uint32_t ah[4], al[4], bv[4];
        ldsm_x4(ah, &at.ph[16 * mt + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        ldsm_x4(al, &at.pl[16 * mt + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        ldsm_x4_t(bv, &at.vv[buf][16 * ks + (lane & 15)][16 * wd + (lane >> 4) * 8]);
        mma_bf16(acc[0], ah[0], ah[1], ah[2], ah[3], bv[0], bv[1]);
        mma_bf16(acc[0], al[0], al[1], al[2], al[3], bv[0], bv[1]);
        mma_bf16(acc[1], ah[0], ah[1], ah[2], ah[3], bv[2], bv[3]);
        mma_bf16(acc[1], al[0], al[1], al[2], al[3], bv[2], bv[3]);
      }
#pragma unroll
      for (int nt = 0; nt < 2; nt++)
#pragma unroll
        for (int q = 0; q < 4; q++) {
          const int qi = 16 * mt + g8 + 8 * (q >> 1), d = 16 * wd + 8 * nt + 2 * t4 + (q & 1);
          if (qi < 3 * n) {
            const int r = r0 + qi / 3, h = 3 * g + qi % 3;
            w.arec[(((long)r * NQH + h) * MAXCHW + ch) * 132 + 2 + d] = acc[nt][q];
          }
        }
    }
    if (tid < 3 * n) {
      const int r = r0 + tid / 3, h = 3 * g + tid % 3;
      w.arec[(((long)r * NQH + h) * MAXCHW + ch) * 132] = sm.mlm[tid];
      w.arec[(((long)r * NQH + h) * MAXCHW + ch) * 132 + 1] = sm.mll[tid];
    }
    __syncthreads();   // smem of this chunk (sc, ph / pl, pr, mlm, the K / V buffer) free for the next
    cmark(ch - cA, 6);
    }   // chunks
    __threadfence();
    __syncthreads();
    if (tid == 0) {
      const unsigned old = atomicAdd(&w.acnt[seq * NKV + g], 1u);
      sm.flag = (old == (unsigned)(npt[i] - 1));
    }
    __syncthreads();
    amark(7);
    if (sm.flag) {
      __threadfence();
      // the records of the (row, head)s of this (sequence, g), G of them at a time, in smem (over K / V: 69632 B)
      const int nck = ncs[i], c0 = cmn[i];
      const int G = min(3 * n, 139264 / (nck * 132 * 4));
      float* rs = reinterpret_cast<float*>(&at.kk[0][0][0]);   // [G][nck][132]
      // the output gates of the 3 n (row, head)s -> sc rows (async, waited with the first records), the sinks
      for (int q = tid; q < 3 * n * 32; q += NT) {
        const int qi = q >> 5, cc = q & 31, h = 3 * g + qi % 3;
        cp_async16(&at.sc[qi][cc * 4], w.qkv + (long)(r0 + qi / 3) * QKVR + R_G + h * HD + cc * 4);
      }
      cp_commit();
      if (tid < 3 * n) at.snk[tid] = ldf(w.qkv + (long)(r0 + tid / 3) * QKVR + R_S + 3 * g + tid % 3);
      for (int qb0 = 0; qb0 < 3 * n; qb0 += G) {
        const int gn = min(G, 3 * n - qb0);
        for (int q = tid; q < gn * nck * 33; q += NT) {   // 16-byte pieces
          const int qi = qb0 + q / (nck * 33), rest = q % (nck * 33), k = rest / 33, e = rest % 33;
          const int r = r0 + qi / 3, h = 3 * g + qi % 3;
          cp_async16(rs + (long)(q / 33) * 132 + e * 4, w.arec + (((long)r * NQH + h) * MAXCHW + c0 + k) * 132 + e * 4);
        }
        cp_commit(); cp_wait<0>();
        __syncthreads();
        // per (row, head): M over the row's own chunks, e_k = exp(m_k - M), S = sum l_k e_k (increasing k)
        for (int ql = wp; ql < gn; ql += NW) {
          const int qi = qb0 + ql, t = t0 + qi / 3;
          const int cl = (glob ? 0 : max(0, t + 1 - 1024)) / ACH - c0, chh = t / ACH - c0;
          const float* rq = rs + (long)ql * nck * 132;
          if (lane == 0) {
            float M = NEG;
            for (int k = cl; k <= chh; k++) M = fmaxf(M, rq[k * 132]);
            float S = 0.f;
            for (int k = cl; k <= chh; k++) {
              const float e = expf(rq[k * 132] - M);
              at.mw[qi][k] = e;
              S = fmaf(rq[k * 132 + 1], e, S);
            }
            at.ms[qi] = M + logf(S);
            at.mS[qi] = S;
          }
        }
        __syncthreads();
        for (int q = tid; q < gn * HD; q += NT) {
          const int ql = q / HD, qi = qb0 + ql, d = q % HD, r = r0 + qi / 3, h = 3 * g + qi % 3;
          const int t = t0 + qi / 3;
          const int cl = (glob ? 0 : max(0, t + 1 - 1024)) / ACH - c0, chh = t / ACH - c0;
          const float* rq = rs + (long)ql * nck * 132;
          float O = 0.f;
          for (int k = cl; k <= chh; k++) O = fmaf(rq[k * 132 + 2 + d], at.mw[qi][k], O);
          const float S = at.mS[qi];
          const float gate = at.sc[qi][d], sink = at.snk[qi];
          (void)h;
          w.ao[(long)r * QW + h * HD + d] = tobf((O / S) * sigm(gate) * sigm(at.ms[qi] - sink));
        }
        __syncthreads();
      }
      if (tid == 0) w.acnt[seq * NKV + g] = 0u;
      amark(9);
    }
    __syncthreads();
    amark(8);
  }
  amark(10);
}

// o_proj: one strip per task; epilogue: raw output (bf16) -> the ha ring (the conv runs in the MLP-input phase)
__device__ __forceinline__ void ph_oproj(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R;
  for (int task = blockIdx.x; task < 144; task += gridDim.x) {
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = s * 16 + g + 8 * (i >> 1);
        if (r < R) w.ha[ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * H + row] = tobf(av[i]);
      }
    };
    if (DG3_ON) DG3(R, 4, w, sm, L.wo, 48, (task >> 2) * 4, min((task >> 2) * 4 + 4, 144), task & 3, w.ao, (long)QW, R, epi);
    else DG2(R, 16, 16, sm, L.wo, 48, task, task + 1, w.ao, (long)QW, R, epi);
  }
}
__device__ __forceinline__ void ph_router(WARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R;
  for (int task = blockIdx.x; task < (DG3_ON ? 32 : 8); task += gridDim.x) {
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = s * 16 + g + 8 * (i >> 1);
        if (r < R) w.rl[(long)r * NE + row] = av[i];
      }
    };
    if (DG3_ON) DG3(R, 1, w, sm, L.wr, 36, task >> 2, (task >> 2) + 1, task & 3, w.y, (long)H, R, epi);
    else DG2(R, 16, 16, sm, L.wr, 36, task, task + 1, w.y, (long)H, R, epi);
  }
}
// top-8 per row (every block, identical) + per expert the (row, rank) list in row order + chunks of <= XTOK tokens
#ifndef TOP8B
#define TOP8B 0
#endif
__device__ __forceinline__ void routing(WARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int R = sm.R, wp = threadIdx.x >> 5, lane = lane_id(), nwb = blockDim.x >> 5;
  // two rows per warp at a time (rows r and r + nwb, interleaved: two independent selection chains); per row the same
  // operations as one row at a time
  for (int r0 = wp; r0 < R; r0 += 2 * nwb) {
    const int rr[2] = {r0, r0 + nwb < R ? r0 + nwb : r0};
    const bool live1 = r0 + nwb < R;
    float lg[2][4], sel[2][4];
#pragma unroll
    for (int q = 0; q < 2; q++)
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int e = lane + 32 * k;
        lg[q][k] = ldf(w.rl + (long)rr[q] * NE + e);
      }
    if (r0 == wp && lg[0][0] == 12345.f) sel[0][0] = 0.f;   // (keeps the loads ahead of the mark)
    amark(1, 1);
#pragma unroll
    for (int q = 0; q < 2; q++)
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int e = lane + 32 * k;
        sel[q][k] = sigm(lg[q][k]) + L.rbias[e];
        if (!(sel[q][k] == sel[q][k])) sel[q][k] = -1e30f;
      }
    amark(2, 1);
    unsigned taken[2] = {0u, 0u}, key[2][4];
    int myid[2] = {0, 0}; float mylg[2] = {0.f, 0.f};
#pragma unroll
    for (int q = 0; q < 2; q++)
#pragma unroll
      for (int k = 0; k < 4; k++) { const unsigned u = __float_as_uint(sel[q][k]); key[q][k] = (u & 0x80000000u) ? ~u : (u | 0x80000000u); }
    for (int rk = 0; rk < TOPK; rk++) {
#pragma unroll
      for (int q = 0; q < 2; q++) {
        unsigned bk = 0u; int bi_l = 0x7fffffff; float bl_l = 0.f;
#pragma unroll
        for (int k = 0; k < 4; k++) {
          const bool ok = !(taken[q] & (1u << k));
          if (ok && (key[q][k] > bk || bi_l == 0x7fffffff)) { bk = key[q][k]; bi_l = lane + 32 * k; bl_l = lg[q][k]; }
        }
        const unsigned mk = __reduce_max_sync(0xffffffffu, bk);
#if TOP8B
        // the winner: the only candidate lane (its own lowest k with the key), else the lowest index among the candidates
        const bool cand = bk == mk && bi_l != 0x7fffffff;
        const unsigned cm = __ballot_sync(0xffffffffu, cand);
        int wl;   // the winner lane (its bi_l is the selected index)
        if (__popc(cm) == 1) wl = __ffs(cm) - 1;
        else { const int bi = (int)__reduce_min_sync(0xffffffffu, cand ? (unsigned)bi_l : 0x7fffffffu); wl = bi < NE ? bi & 31 : -1; }
        if (wl < 0) { if (lane == 0) { taken[q] |= 1u; sm.tex[rr[q]][rk] = 0; sm.twt[rr[q]][rk] = lg[q][0]; } }   // (as the old code: index 0)
        else if (lane == wl) { taken[q] |= 1u << (bi_l >> 5); sm.tex[rr[q]][rk] = bi_l; sm.twt[rr[q]][rk] = bl_l; }
#else
        int bi = (int)__reduce_min_sync(0xffffffffu, (bk == mk && bi_l != 0x7fffffff) ? (unsigned)bi_l : 0x7fffffffu);
        bi = bi < NE ? bi : 0;
        const float bl = __shfl_sync(0xffffffffu, bl_l, bi & 31);
        if ((bi & 31) == lane) taken[q] |= 1u << (bi >> 5);
        if (lane == rk) { myid[q] = bi; mylg[q] = bl; }
#endif
      }
    }
    amark(3, 1);
#if TOP8B
    __syncwarp();
#pragma unroll
    for (int q = 0; q < 2; q++) { myid[q] = lane < TOPK ? sm.tex[rr[q]][lane] : 0; mylg[q] = lane < TOPK ? sm.twt[rr[q]][lane] : 0.f; }
    __syncwarp();
#endif
#pragma unroll
    for (int q = 0; q < 2; q++) {
      if (q == 1 && !live1) break;
      const int r = rr[q];
      const float sg = sigm(mylg[q]);
      float den = 0.f;
#pragma unroll
      for (int rk = 0; rk < TOPK; rk++) den += __shfl_sync(0xffffffffu, sg, rk);
      const float wt = sg / den * 8.0f;
      int rank = 0;
#pragma unroll
      for (int rk = 0; rk < TOPK; rk++) rank += (__shfl_sync(0xffffffffu, myid[q], rk) < myid[q]);
      if (lane < TOPK) { sm.tex[r][rank] = myid[q]; sm.twt[r][rank] = wt; }
      const unsigned m0 = __ballot_sync(0xffffffffu, (taken[q] & 1u) != 0), m1 = __ballot_sync(0xffffffffu, (taken[q] & 2u) != 0);
      const unsigned m2 = __ballot_sync(0xffffffffu, (taken[q] & 4u) != 0), m3 = __ballot_sync(0xffffffffu, (taken[q] & 8u) != 0);
      if (lane == 0) {
        sm.emask[r][0] = m0; sm.emask[r][1] = m1; sm.emask[r][2] = m2; sm.emask[r][3] = m3;
        sm.epre[r][0] = 0; sm.epre[r][1] = __popc(m0); sm.epre[r][2] = __popc(m0) + __popc(m1); sm.epre[r][3] = __popc(m0) + __popc(m1) + __popc(m2);
      }
    }
  }
  __syncthreads();
  amark(14, 1);
  // per expert e: the rows choosing it as a 64-bit mask (ballots: warp w < 2 covers rows 32 w + lane); its count is the
  // popcount, its list the set bits in increasing row order, the rank of e in row r = popcount of r's mask below e
#if 1   // (a per-expert loop over the rows: 1 us; 128 unrolled ballots measured 13 us)
  if (threadIdx.x < NE) {
    const int e = threadIdx.x, wd = e >> 5; const unsigned bit = 1u << (e & 31);
    unsigned lo = 0u, hi = 0u;
    for (int r = 0; r < R; r++) { const bool b = (sm.emask[r][wd] & bit) != 0; if (r < 32) lo |= (b ? 1u : 0u) << r; else hi |= (b ? 1u : 0u) << (r - 32); }
    sm.rmask[e][0] = lo; sm.rmask[e][1] = hi;
  }
  if (false) {
#else
  if (threadIdx.x < 64) {
#endif
    const int r = threadIdx.x;
    unsigned mw[4];
#pragma unroll
    for (int k = 0; k < 4; k++) mw[k] = r < R ? sm.emask[r][k] : 0u;
#pragma unroll
    for (int k = 0; k < 4; k++) {
      unsigned bl = 0u;
#pragma unroll
      for (int bt = 0; bt < 32; bt++) {
        const unsigned b = __ballot_sync(0xffffffffu, (mw[k] >> bt) & 1u);
        if (lane == bt) bl = b;   // lane bt keeps expert 32 k + bt's row mask
      }
      sm.rmask[32 * k + lane][r >> 5] = bl;
    }
  }
  __syncthreads();
  amark(7, 1);
  int cntv = 0;
  unsigned long long rm = 0ull;
  if (threadIdx.x < NE) {
    rm = ((unsigned long long)sm.rmask[threadIdx.x][1] << 32) | sm.rmask[threadIdx.x][0];
    cntv = __popcll(rm);
    int x = cntv;   // inclusive scan within the warp
#pragma unroll
    for (int o = 1; o < 32; o <<= 1) { const int y = __shfl_up_sync(0xffffffffu, x, o); if (lane >= o) x += y; }
    sm.eoff2[threadIdx.x] = x;
  }
  __syncthreads();
  amark(8, 1);
  if (threadIdx.x < NE) {
    const int e = threadIdx.x, wv = e >> 5;
    int add = 0;
    for (int k = 0; k < wv; k++) add += sm.eoff2[32 * k + 31];
    const int incl = sm.eoff2[e] + add;
    sm.eoff[e + 1] = incl;
    if (e == 0) sm.eoff[0] = 0;
    int p = incl - cntv;
    const int wd = e >> 5; const unsigned bit = 1u << (e & 31);
    while (rm) {
      const int r = __ffsll((long long)rm) - 1;
      rm &= rm - 1;
      const int rk = sm.epre[r][wd] + __popc(sm.emask[r][wd] & (bit - 1u));
      sm.elist[p++] = (short)(r * TOPK + rk);
    }
    sm.echk[e] = (cntv + XTOK - 1) / XTOK;
  }
  __syncthreads();
  amark(15, 1);
  // chunk table: expert e's chunks (<= XTOK entries each) at chunk offset = exclusive scan of chunk counts, cost offset
  // = exclusive scan of costs (144 (3 + n-groups) per chunk), both over the experts in id order
  if (threadIdx.x < NE) {
    const int e = threadIdx.x, n = sm.eoff[e + 1] - sm.eoff[e], nc = sm.echk[e];
    int cs = 0;
    for (int k = 0; k < nc; k++) { const int m = min(XTOK, n - k * XTOK); cs += 144 * (3 + (m + 3) / 4); }
    int x = nc, y = cs;
#pragma unroll
    for (int o = 1; o < 32; o <<= 1) {
      const int x2 = __shfl_up_sync(0xffffffffu, x, o), y2 = __shfl_up_sync(0xffffffffu, y, o);
      if (lane >= o) { x += x2; y += y2; }
    }
    sm.eoff2[e] = x; sm.ecst[e] = y;
  }
  __syncthreads();
  if (threadIdx.x < NE) {
    const int e = threadIdx.x, wv = e >> 5, n = sm.eoff[e + 1] - sm.eoff[e], nc = sm.echk[e];
    int ax = 0, ay = 0;
    for (int k = 0; k < wv; k++) { ax += sm.eoff2[32 * k + 31]; ay += sm.ecst[32 * k + 31]; }
    int c0 = sm.eoff2[e] + ax - nc, cc = sm.ecst[e] + ay;
    for (int k = nc - 1; k >= 0; k--) {   // from the last chunk back: cc is the inclusive cost end
      const int m = min(XTOK, n - k * XTOK);
      cc -= 144 * (3 + (m + 3) / 4);
      sm.chk_e[c0 + k] = e; sm.chk_j0[c0 + k] = sm.eoff[e] + k * XTOK; sm.chk_n[c0 + k] = m; sm.chk_cost0[c0 + k] = cc;
    }
    if (e == NE - 1) { sm.nchk = c0 + nc; sm.chk_cost0[c0 + nc] = sm.ecst[e] + ay; }
  }
  __syncthreads();
}
// the block's item range [ib, ie) of (chunk, strip) items, balanced by cost
__device__ __forceinline__ int item_at_cost(const Smem& sm, long x) {
  int k = 0;
  while (k < sm.nchk && sm.chk_cost0[k + 1] <= x) k++;
  if (k >= sm.nchk) return sm.nchk * 144;
  const int cu = (sm.chk_cost0[k + 1] - sm.chk_cost0[k]) / 144;
  const long s = (x - sm.chk_cost0[k] + cu - 1) / cu;
  return k * 144 + (int)min(s, 144L);
}
// register-pipelined MoE warp loop (the MoE kernels run NWM warps): a warp's units of its items it = i0 + wp + NWM k
// (< i1) stream through PD register slots (ldg, PD units ahead); per item the units in increasing order, then the
// epilogue (w13: act -> act16 hi / lo; w2: the token's contribution row)
template <bool W13, bool MX, int NGN>
__device__ __forceinline__ void moe_warp_r(const WCtx& w, const LayerW& L, int lay, Smem& sm, int e, int j0, int n, int i0, int i1, const __half* xs, int wofs) {
  constexpr int U = W13 ? 36 : 18;
  constexpr int UB = MX ? 1056 : (MOE_F16S ? 640 : 576);
  constexpr int KS = (W13 ? H : IE) + 8;
  const int lane = lane_id(), g = lane >> 2, t = lane & 3, wp = threadIdx.x >> 5;
  const int nit = (i1 - i0 - wofs + NWM - 1) / NWM;
  if (nit <= 0) return;
  const int N = nit * U;
  const uint8_t* wbase = ((MX || !MOE_F16S) ? (W13 ? L.w13 : L.w2) : (W13 ? w.w13h[lay] : w.w2h[lay])) + (long)e * 144 * U * UB;
  struct WU { uint4 a, b; uint2 s; };
  int lu = 0, lit = 0;
  const uint8_t* lp = wbase + (long)((i0 + wofs) % 144) * U * UB;
  auto ld = [&](int q, WU& x) {   // called with q = 0, 1, 2, ... in order: running pointer
    if (q < N) {
      const uint8_t* src = lp;
      lp += UB;
      if (++lu == U) { lu = 0; ++lit; lp = wbase + (long)((i0 + wofs + NWM * lit) % 144) * U * UB; }
      if (MX) { x.a = ldg_nc(src + lane * 32); x.b = ldg_nc(src + lane * 32 + 16); x.s.x = ldg_nc1(src + 1024 + g * 4); }
      else if (MOE_F16S) { x.a = ldg_nc(src + lane * 16); x.b = ldg_nc(src + 512 + g * 16); }
      else { x.a = ldg_nc(src + lane * 16); x.s = ldg_nc2(src + 512 + g * 8); }
    }
  };
  // ldmatrix rows: lane l addresses row 8 ng + (l & 7) (token (l & 7) / 2, part l & 1) at k-block (l >> 3) of the x4
  const __half* lrow = xs + (long)(lane & 7) * KS + (lane >> 3) * 8;
  float acc[NGN][4];
#pragma unroll
  for (int ng = 0; ng < NGN; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  const float fac = MX ? 1.0f : (W13 ? L.f13[e] : L.f2[e]);
  auto unit = [&](int q, const WU& x) {
    if (q >= N) return;
    const int u = q % U;
    uint2 bfr[NGN][4];
#pragma unroll
    for (int ng = 0; ng < NGN; ng++) {
      uint32_t r4[4], s4[4];
      ldsm_x4(r4, lrow + (long)(8 * ng) * KS + u * 64);
      ldsm_x4(s4, lrow + (long)(8 * ng) * KS + u * 64 + 32);
      bfr[ng][0] = make_uint2(r4[0], r4[1]); bfr[ng][1] = make_uint2(r4[2], r4[3]);
      bfr[ng][2] = make_uint2(s4[0], s4[1]); bfr[ng][3] = make_uint2(s4[2], s4[3]);
    }
#if MOE_DIAG == 2   // diagnostic: loads only (the weights folded into the accumulators by one op; wrong results)
    acc[0][0] += __uint_as_float((x.a.x ^ x.a.y ^ x.a.z ^ x.a.w ^ x.s.x ^ x.s.y) & 0x3f7fffffu); (void)bfr;
#elif MOE_DIAG == 3   // diagnostic: conversions + loads, no MMA
    { uint32_t a[4], b[4]; cvt4(x.a.x, a); cvt4(x.a.y ^ a[0], b); cvt4(x.a.z ^ b[1], a); cvt4(x.a.w ^ a[2], b); uint32_t sc[4]; scl4(x.s.x ^ b[3], sc); scl4(x.s.y ^ sc[0], a);
      acc[0][0] += __uint_as_float((a[0] ^ a[1] ^ a[2] ^ a[3] ^ sc[1] ^ sc[2] ^ sc[3] ^ bfr[0][0].x) & 0x3f7fffffu); }
#else
    if (MX) unit_fp8<NGN>(x.a, x.b, x.s.x, bfr, acc); else if (MOE_F16S) unit_fp4h<NGN>(x.a, x.b, bfr, acc); else unit_fp4<NGN>(x.a, x.s, bfr, acc);
#endif
    if (u == U - 1) {
      const int strip = (i0 + wofs + NWM * (q / U)) % 144;
      if (W13) {
#pragma unroll
        for (int ng = 0; ng < NGN; ng++) {
          const int li = 4 * ng + t;
          const bool ok = li < n;
          const int ent = ok ? sm.elist[j0 + li] : 0;
          const int r = ent >> 3, rk = ent & 7;
          const float s16 = ok ? ldf(w.s16 + r) : 0.f;
          const float h0 = rbf((acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * s16 * fac);
          const float h1 = rbf((acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * s16 * fac);
          const float o0 = __shfl_xor_sync(0xffffffffu, h0, 4), o1 = __shfl_xor_sync(0xffffffffu, h1, 4);
          const float wgt = ok ? sm.twt[r][rk] : 0.f;
          const float act0 = rbf(act_fn(h0, o0) * wgt), act1 = rbf(act_fn(h1, o1) * wgt);
          const float v0 = act0 * 16.0f, v1 = act1 * 16.0f;
          const __half hi0 = __float2half_rn(v0), hi1 = __float2half_rn(v1);
          const __half lo0 = __float2half_rn((v0 - __half2float(hi0)) * 16777216.0f), lo1 = __float2half_rn((v1 - __half2float(hi1)) * 16777216.0f);
          if (ok && (g & 1) == 0) {
            __half* dst = w.act16 + (long)ent * 2 * IE;
            const int p0 = strip * 8 + (g >> 1), p1 = strip * 8 + 4 + (g >> 1);
            dst[p0] = hi0; dst[IE + p0] = lo0;
            dst[p1] = hi1; dst[IE + p1] = lo1;
          }
        }
      } else {
        const float f2 = fac * 0.0625f;
#pragma unroll
        for (int ng = 0; ng < NGN; ng++) {
          const int li = 4 * ng + t;
          if (li < n) {
            const int ent = sm.elist[j0 + li];
            float* dst = w.w2c + (long)ent * H + strip * 16;
            dst[g] = (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * f2;
            dst[g + 8] = (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * f2;
          }
        }
      }
#pragma unroll
      for (int ng = 0; ng < NGN; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
    }
  };
  if constexpr (!MX && !MOE_F16S) {
    WU x0, x1, x2, x3, x4, x5;
    ld(0, x0); ld(1, x1); ld(2, x2); ld(3, x3); ld(4, x4); ld(5, x5);
#pragma unroll 1
    for (int q = 0; q < N; q += 6) {
      unit(q, x0); ld(q + 6, x0);
      unit(q + 1, x1); ld(q + 7, x1);
      unit(q + 2, x2); ld(q + 8, x2);
      unit(q + 3, x3); ld(q + 9, x3);
      unit(q + 4, x4); ld(q + 10, x4);
      unit(q + 5, x5); ld(q + 11, x5);
    }
  } else {
    WU x0, x1, x2, x3;
    ld(0, x0); ld(1, x1); ld(2, x2); ld(3, x3);
#pragma unroll 1
    for (int q = 0; q < N; q += 4) {
      unit(q, x0); ld(q + 4, x0);
      unit(q + 1, x1); ld(q + 5, x1);
      unit(q + 2, x2); ld(q + 6, x2);
      unit(q + 3, x3); ld(q + 7, x3);
    }
  }
}
#ifndef MOE_REG
#define MOE_REG 1
#endif
template <bool W13>
__device__ __forceinline__ void ph_moe(WARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const long C = sm.chk_cost0[sm.nchk];
  const int ib = item_at_cost(sm, C * blockIdx.x / gridDim.x);
  const int ie = (blockIdx.x + 1 == gridDim.x) ? sm.nchk * 144 : item_at_cost(sm, C * (blockIdx.x + 1) / gridDim.x);
  constexpr int KK = W13 ? H : IE;
  constexpr int KS = KK + 8;
  constexpr int NB = W13 ? 2 : 4;                 // staging buffers (groups in flight)
  constexpr long BS = (long)XTOK * 2 * KS;        // halves per buffer
  __half* xs0 = W13 ? &sm.u.m13.xs[0][0][0][0] : &sm.u.m2.xs[0][0][0][0];
  const int wp = threadIdx.x >> 5;
  if (ib >= ie) return;
  const int g0 = ib / 144, ng = (ie - 1) / 144 - g0 + 1;   // the block's (expert, chunk) groups
  auto stage = [&](int gq) {
    const int k = g0 + gq, n = sm.chk_n[k], j0 = sm.chk_j0[k];
    __half* xs = xs0 + (gq % NB) * BS;
    constexpr int NCK = KK / 8;
    for (int q = threadIdx.x; q < n * 2 * NCK; q += NTM) {
      const int li = q / (2 * NCK), part = (q / NCK) & 1, cc = q % NCK;
      const int ent = sm.elist[j0 + li];
      const __half* src = W13 ? w.x16 + ((long)(ent >> 3) * 2 + part) * H : w.act16 + ((long)ent * 2 + part) * IE;
      cp_async16(xs + ((long)li * 2 + part) * KS + cc * 8, src + cc * 8);
    }
    const int nz = (n > 4 ? 16 : 8) - 2 * n;   // the unused token rows of the n-groups read zeros (ldmatrix rows)
    for (int q = threadIdx.x; q < nz * (KK / 8); q += NTM) {
      const int rr = 2 * n + q / (KK / 8), cc = q % (KK / 8);
      *reinterpret_cast<uint4*>(xs + (long)rr * KS + cc * 8) = make_uint4(0, 0, 0, 0);
    }
  };
  for (int gq = 0; gq < min(ng, NB); gq++) stage(gq);
  cp_commit(); cp_wait<0>();
  __syncthreads();
  // items of the whole range round-robin over the warps (warp wp: items ib + wp + 24 k), group by group without a
  // block barrier between groups (their inputs are already staged)
  for (int gq = 0; gq < ng; gq++) {
    if (gq >= NB) { __syncthreads(); stage(gq); cp_commit(); cp_wait<0>(); __syncthreads(); }
    const int k = g0 + gq;
    const int i0 = max(ib, k * 144), i1 = min(ie, (k + 1) * 144);
    const int e = sm.chk_e[k], j0 = sm.chk_j0[k], n = sm.chk_n[k];
    const int wofs = ((wp - (i0 - ib)) % NWM + NWM) % NWM;
    const __half* xs = xs0 + (gq % NB) * BS;
    if (n > 4) { if (L.mx) moe_warp_r<W13, true, 2>(w, L, c.A[a].layer, sm, e, j0, n, i0, i1, xs, wofs); else moe_warp_r<W13, false, 2>(w, L, c.A[a].layer, sm, e, j0, n, i0, i1, xs, wofs); }
    else { if (L.mx) moe_warp_r<W13, true, 1>(w, L, c.A[a].layer, sm, e, j0, n, i0, i1, xs, wofs); else moe_warp_r<W13, false, 1>(w, L, c.A[a].layer, sm, e, j0, n, i0, i1, xs, wofs); }
  }
  __syncthreads();
}
// MoE output: per row the 8 expert rows summed in expert-id order -> xm and the hm ring
__device__ __forceinline__ void ph_w2sum(WARGS, int a) {
  const App& ap = c.A[a];
  const int R = sm.R;
  for (int q = blockIdx.x * NT + threadIdx.x; q < R * (H / 2); q += gridDim.x * NT) {
    const int r = q / (H / 2), i = (q % (H / 2)) * 2;
    float s0 = 0.f, s1 = 0.f;
#pragma unroll
    for (int k = 0; k < TOPK; k++) {
      const float2 v = __ldcg(reinterpret_cast<const float2*>(w.w2c + ((long)r * TOPK + k) * H + i));
      s0 += v.x; s1 += v.y;
    }
    const uint32_t pk = pack_bf2(s0, s1);
    *reinterpret_cast<uint32_t*>(w.xm + (long)r * H + i) = pk;
    *reinterpret_cast<uint32_t*>(w.hm + ring_row(ap.slot, rseq(sm, r), rpos(sm, r)) * H + i) = pk;
  }
}
// MoE conv + the new partial pb[out] = (pin + as) + ms (boundary layers: as + ms)
__device__ __forceinline__ void ph_w2conv(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R;
  const bool addp = !(a == 0 || ap.bnd);
  for (int q = blockIdx.x * NT + threadIdx.x; q < R * (H / 2); q += gridDim.x * NT) {
    const int r = q / (H / 2), i = (q % (H / 2)) * 2;
    const int seq = rseq(sm, r), t = rpos(sm, r);
    const uint32_t v0 = ldu(w.xm + (long)r * H + i);
    const uint32_t v1 = ldu(w.hm + ring_row(ap.slot, seq, t - 1) * H + i);
    const uint32_t v2 = ldu(w.hm + ring_row(ap.slot, seq, t - 2) * H + i);
    const uint32_t v3 = ldu(w.hm + ring_row(ap.slot, seq, t - 3) * H + i);
    const uint2 wa = *reinterpret_cast<const uint2*>(L.mlp_sc + i * 4), wb = *reinterpret_cast<const uint2*>(L.mlp_sc + i * 4 + 4);
    const float m0 = rbf(sconv_static(bf_lo(v0), bf_lo(v1), bf_lo(v2), bf_lo(v3), reinterpret_cast<const bf16*>(&wa)));
    const float m1 = rbf(sconv_static(bf_hi(v0), bf_hi(v1), bf_hi(v2), bf_hi(v3), reinterpret_cast<const bf16*>(&wb)));
    const uint32_t av = ldu(w.as + (long)r * H + i);
    float n0, n1;
    if (addp) {
      const uint32_t pv = ldu(w.pb + ((long)ap.pin * MAXR + r) * H + i);
      n0 = (bf_lo(pv) + bf_lo(av)) + m0; n1 = (bf_hi(pv) + bf_hi(av)) + m1;
    } else { n0 = bf_lo(av) + m0; n1 = bf_hi(av) + m1; }
    *reinterpret_cast<uint32_t*>(w.pb + ((long)ap.out * MAXR + r) * H + i) = pack_bf2(n0, n1);
  }
}
// MoE output sum + conv + new partial in one kernel: a thread owns an element pair of one sequence's rows (in
// increasing position), so the conv lags of in-pass rows come from its registers (the same bf16 values the ring holds)
__device__ __forceinline__ void ph_w2fused(WARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int R = sm.R;
  const bool addp = !(a == 0 || ap.bnd);
  // sequence groups of rows (consecutive rows with the same slot)
  int ng = 0, gs[MAXR + 1];
  for (int r = 0; r < R; r++) if (r == 0 || sm.rows[r][0] != sm.rows[r - 1][0]) gs[ng++] = r;
  gs[ng] = R;
  for (int q = blockIdx.x * NT + threadIdx.x; q < ng * (H / 2); q += gridDim.x * NT) {
    const int gi = q / (H / 2), i = (q % (H / 2)) * 2;
    const int r0 = gs[gi], r1 = gs[gi + 1];
    const int seq = rseq(sm, r0), t0 = rpos(sm, r0);
    const uint2 wa = *reinterpret_cast<const uint2*>(L.mlp_sc + i * 4), wb = *reinterpret_cast<const uint2*>(L.mlp_sc + i * 4 + 4);
    uint32_t h1 = ldu(w.hm + ring_row(ap.slot, seq, t0 - 1) * H + i);
    uint32_t h2 = ldu(w.hm + ring_row(ap.slot, seq, t0 - 2) * H + i);
    uint32_t h3 = ldu(w.hm + ring_row(ap.slot, seq, t0 - 3) * H + i);
    if (r1 - r0 > 8) continue;   // (never: a sequence has at most 8 rows per pass)
    uint32_t pk[8];
#pragma unroll
    for (int j = 0; j < 8; j++) {
      pk[j] = 0u;
      if (r0 + j < r1) {
        float s0 = 0.f, s1 = 0.f;
#pragma unroll
        for (int k = 0; k < TOPK; k++) {
          const float2 v = __ldcg(reinterpret_cast<const float2*>(w.w2c + ((long)(r0 + j) * TOPK + k) * H + i));
          s0 += v.x; s1 += v.y;
        }
        pk[j] = pack_bf2(s0, s1);
      }
    }
#pragma unroll
    for (int j = 0; j < 8; j++) {
      if (r0 + j >= r1) break;
      const int r = r0 + j;
      *reinterpret_cast<uint32_t*>(w.hm + ring_row(ap.slot, seq, rpos(sm, r)) * H + i) = pk[j];
      const float m0 = rbf(sconv_static(bf_lo(pk[j]), bf_lo(h1), bf_lo(h2), bf_lo(h3), reinterpret_cast<const bf16*>(&wa)));
      const float m1 = rbf(sconv_static(bf_hi(pk[j]), bf_hi(h1), bf_hi(h2), bf_hi(h3), reinterpret_cast<const bf16*>(&wb)));
      h3 = h2; h2 = h1; h1 = pk[j];
      const uint32_t av = ldu(w.as + (long)r * H + i);
      float n0, n1;
      if (addp) {
        const uint32_t pv = ldu(w.pb + ((long)ap.pin * MAXR + r) * H + i);
        n0 = (bf_lo(pv) + bf_lo(av)) + m0; n1 = (bf_hi(pv) + bf_hi(av)) + m1;
      } else { n0 = bf_lo(av) + m0; n1 = bf_hi(av) + m1; }
      *reinterpret_cast<uint32_t*>(w.pb + ((long)ap.out * MAXR + r) * H + i) = pack_bf2(n0, n1);
    }
  }
}
// final: output mix -> norm -> xf; unembedding -> 30 tanh(z / 30) -> logits, argmax
__device__ __forceinline__ void ph_fin_mix(WARGS) {
  const int gi = GI, gt = GT;
  for (int r = GID; r < sm.R; r += GROUPS) {
    uint32_t v[5][RPJ];
    const unsigned msk = ((1u << c.nfin) - 1u) | 16u;
#pragma unroll
    for (int s = 0; s < 5; s++) {
      const int idx = s < 4 ? c.fin[s] : c.fin_pin;
      if ((msk >> s) & 1u) ld_row(w.pb + ((long)idx * MAXR + r) * H, v[s], gt);
      else {
#pragma unroll
        for (int j = 0; j < RPJ; j++) v[s][j] = 0u;
      }
    }
    float x[2 * RPJ];
    g_mix<5>(v, nullptr, -1, msk, sm.qv[0], x, sm, gi, gt);
    g_norm_store(x, sm.nwv[0], w.xf + (long)r * H, sm, gi, gt);
  }
}
template <int NG>
__device__ __forceinline__ void unembed_t(WARGS) {
  const int R = sm.R;
  const int ntask = (UN_STRIPS + 3) / 4;
  for (int i = threadIdx.x; i < MAXR; i += NT) sm.ubest[i] = 0ull;
  __syncthreads();
  for (int task = blockIdx.x; task < ntask; task += gridDim.x) {
    auto epi = [&](int s, int ng, float a0, float a1, float a2, float a3) {
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
      const float av[4] = {a0, a1, a2, a3};
      unsigned long long kb[2] = {0ull, 0ull};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int r = ng * 8 + 2 * t + (i & 1), row = s * 16 + g + 8 * (i >> 1);
        if (r >= R || row >= VOCAB_REAL) continue;
        const float z = 30.0f * tanhf(av[i] / 30.0f);
        if (hd.logits) hd.logits[(long)r * VOCAB_REAL + row] = z;
        unsigned u = __float_as_uint(z);
        u = (u & 0x80000000u) ? ~u : (u | 0x80000000u);
        const unsigned long long key = ((unsigned long long)u << 32) | (unsigned)(0xFFFFFFFFu - row);
        if (key > kb[i & 1]) kb[i & 1] = key;
      }
#pragma unroll
      for (int cc = 0; cc < 2; cc++) {
        unsigned long long k = kb[cc];
#pragma unroll
        for (int o = 4; o < 32; o <<= 1) { const unsigned long long ok = __shfl_xor_sync(0xffffffffu, k, o); if (ok > k) k = ok; }
        const int r = ng * 8 + 2 * t + cc;
        if (g == 0 && r < R && k) atomicMax(&sm.ubest[r], k);
      }
    };
    if constexpr (NG > 4 && DG64) dgemm2<8, 4, 8>(sm, c.unembed, 36, task * 4, min(task * 4 + 4, UN_STRIPS), w.xf, (long)H, R, epi);
    else if constexpr (NG == 1) dgemm2<1, 4, 36>(sm, c.unembed, 36, task * 4, min(task * 4 + 4, UN_STRIPS), w.xf, (long)H, R, epi);
    else dgemm2<(NG > 4 ? 4 : NG), 4, 16>(sm, c.unembed, 36, task * 4, min(task * 4 + 4, UN_STRIPS), w.xf, (long)H, R, epi);
  }
  __syncthreads();
  for (int r = threadIdx.x; r < R; r += NT) if (sm.ubest[r]) atomicMax(w.amax + r, sm.ubest[r]);
}

// ------------------------------------------------------------------------------------------------ kernels
// one kernel per phase (own registers and shared-memory size); the host launches them in order on one stream
__device__ __forceinline__ void load_rows(const WHdr& hd, Smem& sm, bool seqtab = false) {
  const int R = min(max(hd.rows[0], 0), MAXR);
  for (int i = threadIdx.x; i < R * 4; i += blockDim.x) sm.rows[i >> 2][i & 3] = hd.rows[4 + i];
  if (threadIdx.x == 0) sm.R = R;
  __syncthreads();
  if (!seqtab) return;
  if (threadIdx.x == 0) {
    int ns = 0;
    for (int r = 0; r < R; r++) {
      if (r == 0 || sm.rows[r][0] != sm.rows[r - 1][0] || sm.rows[r][1] != sm.rows[r - 1][1] + 1 || sm.sq_n[ns - 1] >= 8) {
        sm.sq_seq[ns] = sm.rows[r][0]; sm.sq_r0[ns] = r; sm.sq_n[ns] = 1; ns++;
      } else sm.sq_n[ns - 1]++;
    }
    sm.nsq = ns;
  }
  __syncthreads();
}
template <class T>
__device__ __forceinline__ const T* rj_stage(Smem& sm, const T* src, int bytes) {   // every thread, same arguments
  unsigned char* dst = sm.u.rjb + sm.rjoff;
  for (int i = threadIdx.x; i < bytes / 16; i += blockDim.x) cp_async16(dst + i * 16, reinterpret_cast<const unsigned char*>(src) + i * 16);
  __syncthreads();
  if (threadIdx.x == 0) sm.rjoff += (bytes + 15) & ~15;
  __syncthreads();
  return reinterpret_cast<const T*>(dst);
}
#define KHEAD0 extern __shared__ __align__(16) unsigned char smraw[]; Smem& sm = *reinterpret_cast<Smem*>(smraw); \
  TSTART(hd) pdl_launch(); const WCtx& w = *wp; const Ctx& c = *w.c; load_rows(hd, sm);
#define KHEAD KHEAD0 pdl_wait();
#define KDEF(name) extern "C" __global__ void __launch_bounds__(NT, 1) name(const WCtx* __restrict__ wp, WHdr hd, int a, int x0, int x1)
#define RJ_BEGIN if (threadIdx.x == 0) sm.rjoff = 0; __syncthreads();
#define RJ_END cp_commit(); pdl_wait(); cp_wait<0>(); __syncthreads();
__device__ __forceinline__ void B_attn_in(WARGS, int a, int x0, int x1) {
  const App& ap = c.A[a]; const LayerW& L = c.L[ap.layer];
  const int nq = L.glob ? 3 : 1;
  RJ_BEGIN
  for (int q = 0; q < nq; q++) {
    const float* qp = a > 0 ? rj_stage(sm, L.aq + q * H, 4 * H) : nullptr;
    const bf16* np = rj_stage(sm, L.norm[q], 2 * H);
    if (threadIdx.x == 0) { sm.qv[q] = qp; sm.nwv[q] = np; }
  }
  if (a == 0) { const bf16* en = rj_stage(sm, c.embed_norm, 2 * H); if (threadIdx.x == 0) sm.nwv[3] = en; }
  RJ_END
  ph_attn_in(w, c, hd, sm, a);
}
KDEF(k_attn_in) { KHEAD0 B_attn_in(w, c, hd, sm, a, x0, x1); }
__device__ __forceinline__ void B_gate_mix(WARGS, int a, int x0, int x1) {
  const App& ap = c.A[a]; const LayerW& L = c.L[ap.layer];
  RJ_BEGIN
  for (int ctrl = x0; ctrl < x0 + x1; ctrl++) {
    const float* mq = rj_stage(sm, c.loopq + ((long)ap.loopl * 4 + ctrl) * H, 4 * H);
    if (ctrl < 3) {
      const float* xq = rj_stage(sm, L.aq + (L.glob ? ctrl : 0) * H, 4 * H);
      if (threadIdx.x == 0) { sm.qv[3 + ctrl] = mq; sm.qv[ctrl] = xq; }
    } else {
      const float* q6 = rj_stage(sm, L.mq, 4 * H);
      const bf16* tp = rj_stage(sm, L.attn_sc, 8 * H);
      if (threadIdx.x == 0) { sm.qv[7] = mq; sm.qv[6] = q6; sm.tap = tp; }
    }
  }
  RJ_END
  ph_gate_mix(w, c, hd, sm, a, x0, x1);
}
KDEF(k_gate_mix) { KHEAD0 B_gate_mix(w, c, hd, sm, a, x0, x1); }
KDEF(k_gate_dg) { KHEAD0 ph_gate_dg(w, c, hd, sm, a, x0, x1); }
KDEF(k_gate_fg) { KHEAD ph_gate_fg(w, c, hd, sm, a, x0, x1); }
__device__ __forceinline__ void B_gate_norm(WARGS, int a, int x0, int x1) {
  const LayerW& L = c.L[c.A[a].layer];
  RJ_BEGIN
  for (int ctrl = x0; ctrl < x0 + x1; ctrl++) {
    if (ctrl < 3) { const bf16* np = rj_stage(sm, L.norm[ctrl], 2 * H); if (threadIdx.x == 0) sm.nwv[ctrl] = np; }
    else { const bf16* mn = rj_stage(sm, L.mlp_norm, 2 * H); if (threadIdx.x == 0) sm.mlpn = mn; }
  }
  RJ_END
  ph_gate_norm(w, c, hd, sm, a, x0, x1);
}
KDEF(k_gate_norm) { KHEAD0 B_gate_norm(w, c, hd, sm, a, x0, x1); }
KDEF(k_qkv) { dmark(0); KHEAD0 ph_qkv(w, c, hd, sm, a, x0); dmark(5); }
KDEF(k_kv) { KHEAD ph_kv(w, c, hd, sm, a); }
KDEF(k_attn) {
  extern __shared__ __align__(16) unsigned char smraw[]; Smem& sm = *reinterpret_cast<Smem*>(smraw);
  TSTART(hd) pdl_launch(); const WCtx& w = *wp; const Ctx& c = *w.c; load_rows(hd, sm, true); pdl_wait();
  ph_attn(w, c, hd, sm, a);
}
KDEF(k_oproj) { KHEAD0 ph_oproj(w, c, hd, sm, a); }
__device__ __forceinline__ void B_mlp_in(WARGS, int a, int x0, int x1) {
  const LayerW& L = c.L[c.A[a].layer];
  RJ_BEGIN
  const float* q6 = rj_stage(sm, L.mq, 4 * H);
  const bf16* tp = rj_stage(sm, L.attn_sc, 8 * H);
  const bf16* mn = rj_stage(sm, L.mlp_norm, 2 * H);
  if (threadIdx.x == 0) { sm.qv[6] = q6; sm.tap = tp; sm.mlpn = mn; }
  RJ_END
  ph_mlp_in(w, c, hd, sm, a);
}
KDEF(k_mlp_in) { KHEAD0 B_mlp_in(w, c, hd, sm, a, x0, x1); }
KDEF(k_router) { KHEAD0 ph_router(w, c, hd, sm, a); }
#define KDEFM(name) extern "C" __global__ void __launch_bounds__(NTM, 1) name(const WCtx* __restrict__ wp, WHdr hd, int a, int x0, int x1)
KDEFM(k_w13) {
  KHEAD amark(12, 1); routing(w, c, hd, sm, a); amark(13, 1);
  if (blockIdx.x == 0) {   // the tables for the w2 kernel
    const int n = (int)((RT_END - RT_BEGIN) / 4);
    for (int i = threadIdx.x; i < n; i += NTM) w.rtab[i] = reinterpret_cast<const int*>(smraw + RT_BEGIN)[i];
  }
  ph_moe<true>(w, c, hd, sm, a);
#ifdef WDPROF
  __syncthreads(); amark(10, 1);
#endif
}
KDEFM(k_w2) {
  KHEAD
  const int n = (int)((RT_END - RT_BEGIN) / 4);
  for (int i = threadIdx.x; i < n; i += NTM) reinterpret_cast<int*>(smraw + RT_BEGIN)[i] = __ldcg(w.rtab + i);
  __syncthreads();
  ph_moe<false>(w, c, hd, sm, a);
}
KDEF(k_w2sum) { KHEAD ph_w2sum(w, c, hd, sm, a); }
KDEF(k_w2conv) { KHEAD ph_w2conv(w, c, hd, sm, a); }
KDEF(k_w2fused) { KHEAD ph_w2fused(w, c, hd, sm, a); }
// ---- fused phase groups: one cooperative kernel per group, grid barriers between the phases (same phase code)
#define KHEADF(SEQT) extern __shared__ __align__(16) unsigned char smraw[]; Smem& sm = *reinterpret_cast<Smem*>(smraw); \
  pdl_launch(); const WCtx& w = *wp; const Ctx& c = *w.c; load_rows(hd, sm, SEQT); pdl_wait(); \
  unsigned nbar = 0; const unsigned base = ld_acq(&w.bar[1]);
#define KENDF if (blockIdx.x == 0 && threadIdx.x == 0) w.bar[1] = base + nbar * gridDim.x;
#define GB() grid_bar(w, nbar, base)
KDEF(kf_in_qkv) {   // x0 = number of qkv input streams
  KHEADF(false)
  const App& ap = c.A[a];
  if (!ap.nmsg) B_attn_in(w, c, hd, sm, a, 0, 0);
  else { B_gate_mix(w, c, hd, sm, a, 0, 3); GB(); ph_gate_dg(w, c, hd, sm, a, 0, 3); GB(); ph_gate_fg(w, c, hd, sm, a, 0, 3); GB(); B_gate_norm(w, c, hd, sm, a, 0, 3); }
  GB();
  ph_qkv(w, c, hd, sm, a, x0);
  KENDF
}
KDEF(kf_kv_attn) {
  KHEADF(true)
  ph_kv(w, c, hd, sm, a);
  GB();
  ph_attn(w, c, hd, sm, a);
  KENDF
}
KDEF(kf_oproj_mlp) {
  KHEADF(false)
  const App& ap = c.A[a];
  ph_oproj(w, c, hd, sm, a);
  GB();
  if (!ap.nmsg) B_mlp_in(w, c, hd, sm, a, 0, 0);
  else { B_gate_mix(w, c, hd, sm, a, 3, 1); GB(); ph_gate_dg(w, c, hd, sm, a, 3, 1); GB(); ph_gate_fg(w, c, hd, sm, a, 3, 1); GB(); B_gate_norm(w, c, hd, sm, a, 3, 1); }
  GB();
  ph_router(w, c, hd, sm, a);
  KENDF
}
KDEF(kf_w2out) {
  KHEADF(false)
  ph_w2sum(w, c, hd, sm, a);
  GB();
  ph_w2conv(w, c, hd, sm, a);
  KENDF
}
KDEF(k_fin_mix) {
  KHEAD0
  RJ_BEGIN
  const float* oq = rj_stage(sm, c.oq, 4 * H);
  const bf16* fn = rj_stage(sm, c.fnorm, 2 * H);
  if (threadIdx.x == 0) { sm.qv[0] = oq; sm.nwv[0] = fn; }
  RJ_END
  ph_fin_mix(w, c, hd, sm);
}
KDEF(k_unembed) {
  KHEAD0
  const int R = sm.R;
  if (R <= 0) return;
  if (R <= 8) unembed_t<1>(w, c, hd, sm); else if (R <= 16) unembed_t<2>(w, c, hd, sm);
  else if (R <= 32) unembed_t<4>(w, c, hd, sm); else unembed_t<8>(w, c, hd, sm);
}
// device loop of the B >= 2 decoding: rows r < R advance one position and take their own argmax as the next token
extern "C" __global__ void k_feed(int* hdr, const int* next_tok) {
  const int R = min(max(hdr[0], 0), MAXR);
  if ((int)threadIdx.x < R) { hdr[4 + 4 * threadIdx.x + 1] += 1; hdr[4 + 4 * threadIdx.x + 2] = next_tok[threadIdx.x]; }
}
// B >= 2 draft-and-verify. gather: the verify rows of every active sequence s (vpos[s] = (c, K), vtok[s][0..K-1] =
// anchor + drafts) -> hdr (rows of one sequence consecutive), K clamped to the positions below `limit`; hdr[260 + s] =
// first row of s, hdr[268 + s] = its rows. scatter: per sequence its rows' argmax -> tgt[s][j], the four draft
// features (partials at the start of applications 5, 23, 41 and the final-norm row) -> feats[s][j][4][H].
#define HX 260
extern "C" __global__ void k_gather(int* hdr, int* vpos, const int* vtok, const int* active, int limit, int kmax) {
  if (threadIdx.x != 0) return;
  int R = 0;
  for (int s = 0; s < NSQ; s++) {
    int K = 0;
    const int c = vpos[2 * s];
    if (active[s]) {
      K = min(max(vpos[2 * s + 1], 1), min(kmax, 8)); K = max(0, min(K, limit - c));
      if (K >= 1) vpos[2 * s + 1] = K;   // the draft's acceptance reads the verified row count from here
    }
    hdr[HX + s] = R; hdr[HX + 8 + s] = K;
    for (int j = 0; j < K; j++) {
      int* rw = hdr + 4 + 4 * R;
      rw[0] = s; rw[1] = c + j; rw[2] = vtok[8 * s + j]; rw[3] = 0;
      R++;
    }
  }
  hdr[0] = R;
}
extern "C" __global__ void k_scatter(const int* hdr, const int* next_tok, const bf16* pb, const bf16* xf, int* tgt, bf16* feats) {
  const int s = blockIdx.x >> 3, j = blockIdx.x & 7;
  const int r0 = hdr[HX + s], K = hdr[HX + 8 + s];
  if (j >= K) return;
  const int r = r0 + j;
  if (threadIdx.x == 0) tgt[8 * s + j] = next_tok[r];
  const int idx[3] = {5, 23, 41};
  bf16* dst = feats + (((long)s * 8 + j) * 4) * H;
  for (int i = threadIdx.x; i < 4 * H / 8; i += blockDim.x) {
    const int f = i / (H / 8), k = (i % (H / 8)) * 8;
    const bf16* src = f < 3 ? pb + ((long)idx[f] * MAXR + r) * H : xf + (long)r * H;
    *reinterpret_cast<uint4*>(dst + (long)f * H + k) = *reinterpret_cast<const uint4*>(src + k);
  }
}
KDEF(k_tokens) {
  TSTART(hd) pdl_wait();
  const WCtx& w = *wp;
  if ((int)threadIdx.x < min(hd.rows[0], MAXR)) {
    const unsigned long long k = w.amax[threadIdx.x];
    const int tok = (int)(0xFFFFFFFFu - (unsigned)(k & 0xFFFFFFFFu));
    w.next_tok[threadIdx.x] = tok;
    w.amax[threadIdx.x] = 0ull;
    if (hd.out_tok) hd.out_tok[threadIdx.x] = tok + ((hd.flags >> 8) & 1);   // flag bit 8: write 1 + id (host polls for != 0)
  }
}

// ------------------------------------------------------------------------------------------------ host API
typedef void (*KFn)(const WCtx*, WHdr, int, int, int);
enum { K_ATTN_IN, K_GATE_MIX, K_GATE_DG, K_GATE_FG, K_GATE_NORM, K_QKV, K_KV, K_ATTN, K_OPROJ, K_MLP_IN, K_ROUTER, K_W13, K_W2,
       K_W2SUM, K_W2CONV, K_FIN_MIX, K_UNEMBED, K_TOKENS, K_W2FUSED, KF_IN_QKV, KF_KV_ATTN, KF_OPROJ_MLP, KF_W2OUT, K_N };
static KFn kfn[K_N] = {k_attn_in, k_gate_mix, k_gate_dg, k_gate_fg, k_gate_norm, k_qkv, k_kv, k_attn, k_oproj, k_mlp_in, k_router,
                       k_w13, k_w2, k_w2sum, k_w2conv, k_fin_mix, k_unembed, k_tokens, k_w2fused,
                       kf_in_qkv, kf_kv_attn, kf_oproj_mlp, kf_w2out};
static size_t ksm[K_N];
#ifndef WFUSE
#define WFUSE 0   // (fused phase groups with grid barriers measured slower in every combination)
#endif
static int g_pdl = 1, g_fuse2 = 0, g_fuse = WFUSE;   // bits: 1 input+qkv, 2 kv+attn, 4 oproj+mlp+router, 8 w2 sum+conv
static int napp_layer[NAPP], napp_nmsg[NAPP], layer_glob[NLW];
static int g_li = 0, g_tkind[2048];
extern "C" {
int wk_smem_bytes() { return (int)sizeof(Smem); }
int wk_wctx_bytes() { return (int)sizeof(WCtx); }
int wk_ctx_head_bytes() { return (int)sizeof(Ctx); }
int wk_layer_bytes() { return (int)sizeof(LayerW); }
int wk_off_embed() { return (int)offsetof(Ctx, embed); }
int wk_set_aprof(void* p) { return cudaMemcpyToSymbol(g_aprof, &p, sizeof(p)) == cudaSuccess ? 0 : 1; }
int wk_set_dprof(void* p) { return cudaMemcpyToSymbol(g_dprof, &p, sizeof(p)) == cudaSuccess ? 0 : 1; }
int wk_feed(void* hdr, const void* next_tok, void* stream) {
  k_feed<<<1, MAXR, 0, (cudaStream_t)stream>>>((int*)hdr, (const int*)next_tok);
  return cudaGetLastError() == cudaSuccess ? 0 : 1;
}
int wk_gather(void* hdr, void* vpos, const void* vtok, const void* active, int limit, int kmax, void* stream) {
  k_gather<<<1, 32, 0, (cudaStream_t)stream>>>((int*)hdr, (int*)vpos, (const int*)vtok, (const int*)active, limit, kmax);
  return cudaGetLastError() == cudaSuccess ? 0 : 1;
}
int wk_scatter(const void* hdr, const void* next_tok, const void* pb, const void* xf, void* tgt, void* feats, void* stream) {
  k_scatter<<<NSQ * 8, 256, 0, (cudaStream_t)stream>>>((const int*)hdr, (const int*)next_tok, (const bf16*)pb, (const bf16*)xf, (int*)tgt, (bf16*)feats);
  return cudaGetLastError() == cudaSuccess ? 0 : 1;
}
int wk_tprof(void* p, int* kinds) {   // set the timeline buffer (WTPROF builds); kinds <- the last pass's launches; returns their count
#ifdef WTPROF
  cudaMemcpyToSymbol(g_tprof, &p, sizeof(p));
#endif
  if (kinds) for (int i = 0; i < g_li && i < 2048; i++) kinds[i] = g_tkind[i];
  return g_li;
}
int wk_set_pdl(int v) { g_pdl = v; return 0; }
int wk_set_fuse2(int v) { g_fuse2 = v; return 0; }
int wk_set_fuse(int v) { g_fuse = v; return 0; }
int wk_smem_hdr() { return (int)offsetof(Smem, u); }
int wk_rtab_bytes() { return (int)(RT_END - RT_BEGIN); }
// app table from the host copy of the megakernel's Ctx (layer, nmsg per application; glob per layer)
int wk_setup(const void* ctx_host) {
  const Ctx* c = reinterpret_cast<const Ctx*>(ctx_host);
  for (int a = 0; a < NAPP; a++) { napp_layer[a] = c->A[a].layer; napp_nmsg[a] = c->A[a].nmsg; }
  for (int i = 0; i < NLW; i++) layer_glob[i] = c->L[i].glob;
  const size_t hdr = offsetof(Smem, u);
  Smem* z = nullptr;
  const size_t sg = hdr + sizeof(z->u.g), sat = hdr + sizeof(z->u.at), s13 = hdr + sizeof(z->u.m13), s2 = hdr + sizeof(z->u.m2), sgv = hdr + sizeof(z->u.gvs);
  for (int k = 0; k < K_N; k++) ksm[k] = hdr;
  ksm[K_GATE_DG] = ksm[K_QKV] = ksm[K_OPROJ] = ksm[K_ROUTER] = ksm[K_UNEMBED] = hdr + sizeof(z->u.g2); (void)sg;
  ksm[K_ATTN] = sat; ksm[K_W13] = s13; ksm[K_W2] = s2; ksm[K_GATE_FG] = sgv;
  ksm[K_ATTN_IN] = ksm[K_GATE_MIX] = ksm[K_MLP_IN] = ksm[K_GATE_NORM] = ksm[K_FIN_MIX] = hdr + sizeof(z->u.rjb);
  ksm[KF_IN_QKV] = ksm[KF_OPROJ_MLP] = hdr + sizeof(z->u.g2); ksm[KF_KV_ATTN] = sat; ksm[KF_W2OUT] = hdr;
  for (int k = 0; k < K_N; k++) {
    cudaError_t e = cudaFuncSetAttribute((const void*)kfn[k], cudaFuncAttributeMaxDynamicSharedMemorySize, (int)ksm[k]);
    if (e != cudaSuccess) { fprintf(stderr, "wk_setup %d: %s\n", k, cudaGetErrorString(e)); return 1; }
  }
  return 0;
}
static size_t dg_smem(int k, int R) {   // dynamic smem of the dense-GEMM kernels: max over the variants for <= R rows
  const int ngmax = R <= 8 ? 1 : R <= 16 ? 2 : R <= 32 ? 4 : 8;
  size_t best = 0;
  for (int ngc = 1; ngc <= ngmax; ngc *= 2) {
    int sk;
    if (k == K_QKV || k == K_UNEMBED) sk = ngc == 1 ? 36 : (ngc == 8 ? 8 : 16); else sk = 16;
    size_t b = (size_t)ngc * 8 * (sk * 64 + 8) * 2;
    if (DGDB && 2 * b <= sizeof(((Smem*)0)->u.g2.b)) b *= 2;   // double-buffered stages (as dgemm2)
    const size_t red = (size_t)16 * ngc * 4 * 32 * 4;
    const size_t need = b > red ? b : red;
    if (need > best) best = need;
  }
  return offsetof(Smem, u) + best;
}
static int launch(int k, int nblk, const void* wdev, const WHdr& h0, int a, int x0, int x1, cudaStream_t st) {
  WHdr h = h0;
#ifdef WTPROF
  if (g_li < 2048) { g_tkind[g_li] = k | (x0 << 8) | (a << 12); h.flags = (h.flags & 0xffff) | (g_li << 16); } else h.flags = (h.flags & 0xffff) | (-1 << 16);
  g_li++;
#endif
  cudaLaunchConfig_t cfg = {};
  size_t smb = ksm[k];
  if (k == K_QKV || k == K_UNEMBED || k == K_OPROJ || k == K_ROUTER || k == K_GATE_DG) { const size_t d = dg_smem(k, h.R); if (d < smb) smb = d; }
  if (k == KF_IN_QKV || k == KF_OPROJ_MLP) {   // the largest of the group's phases
    size_t d = offsetof(Smem, u) + sizeof(((Smem*)0)->u.rjb);
    const int ks[3] = {K_QKV, K_OPROJ, K_GATE_DG};
    for (int q = 0; q < 3; q++) { const size_t e = dg_smem(ks[q], h.R); if (e > d) d = e; }
    const size_t gv = offsetof(Smem, u) + sizeof(((Smem*)0)->u.gvs); if (gv > d) d = gv;
    smb = d;
  }
  const bool coop = k >= KF_IN_QKV;
  cfg.gridDim = dim3(nblk); cfg.blockDim = dim3((k == K_W13 || k == K_W2) ? NTM : NT); cfg.dynamicSmemBytes = smb; cfg.stream = st;
  cudaLaunchAttribute at[2];
  at[0].id = cudaLaunchAttributeProgrammaticStreamSerialization;
  at[0].val.programmaticStreamSerializationAllowed = g_pdl;
  at[1].id = cudaLaunchAttributeCooperative;
  at[1].val.cooperative = 1;
  cfg.attrs = at; cfg.numAttrs = coop ? 2 : 1;
  const WCtx* wc = reinterpret_cast<const WCtx*>(wdev);
  cudaLaunchKernelEx(&cfg, kfn[k], wc, h, a, x0, x1);
  return 0;
}
// one pass: every application's kernels in order, then the final mix, the unembedding and the tokens
int wk_launch(const void* wdev, const WHdr* hd, int nblk, void* stream) {
  const WHdr h = *hd; g_li = 0;
  cudaStream_t st = (cudaStream_t)stream;
  const int R = h.R;
  const int gj = (R * 3 + 3) / 4;   // row-job blocks (4 groups each)
  const int napp = (h.flags & 0xff) ? (h.flags & 0xff) : NAPP;
  for (int a = 0; a < napp; a++) {
    const int glob = layer_glob[napp_layer[a]];
    const int nq = napp_nmsg[a] ? 3 : (glob ? 3 : 1);
    if (g_fuse & 1) launch(KF_IN_QKV, nblk, wdev, h, a, nq, 0, st);
    else if (!napp_nmsg[a]) launch(K_ATTN_IN, min(nblk, (R * (glob ? 3 : 1) + 3) / 4), wdev, h, a, 0, 0, st);
    else {
      launch(K_GATE_MIX, min(nblk, gj), wdev, h, a, 0, 3, st);
      launch(K_GATE_DG, 12 * (DG3_ON ? 4 : 1), wdev, h, a, 0, 3, st);
      launch(K_GATE_FG, nblk, wdev, h, a, 0, 3, st);
      launch(K_GATE_NORM, min(nblk, gj), wdev, h, a, 0, 3, st);
    }
    if (!(g_fuse & 1)) launch(K_QKV, nblk, wdev, h, a, nq, 0, st);
    if (g_fuse & 2) launch(KF_KV_ATTN, nblk, wdev, h, a, 0, 0, st);
    else { launch(K_KV, min(nblk, (R * (16 + NQH) + NW - 1) / NW), wdev, h, a, 0, 0, st); launch(K_ATTN, nblk, wdev, h, a, 0, 0, st); }
    if (g_fuse & 4) launch(KF_OPROJ_MLP, nblk, wdev, h, a, 0, 0, st);
    else {
      launch(K_OPROJ, min(nblk, 144), wdev, h, a, 0, 0, st);
      if (!napp_nmsg[a]) launch(K_MLP_IN, min(nblk, (R + 3) / 4), wdev, h, a, 0, 0, st);
      else {
        launch(K_GATE_MIX, min(nblk, (R + 3) / 4), wdev, h, a, 3, 1, st);
        launch(K_GATE_DG, 4 * (DG3_ON ? 4 : 1), wdev, h, a, 3, 1, st);
        launch(K_GATE_FG, min(nblk, 18), wdev, h, a, 3, 1, st);
        launch(K_GATE_NORM, min(nblk, (R + 3) / 4), wdev, h, a, 3, 1, st);
      }
      launch(K_ROUTER, DG3_ON ? 32 : 8, wdev, h, a, 0, 0, st);
    }
    launch(K_W13, nblk, wdev, h, a, 0, 0, st);
    launch(K_W2, nblk, wdev, h, a, 0, 0, st);
    if (g_fuse & 8) launch(KF_W2OUT, nblk, wdev, h, a, 0, 0, st);
    else if (g_fuse2) launch(K_W2FUSED, min(nblk, (8 * (H / 2) + NT - 1) / NT), wdev, h, a, 0, 0, st);
    else { launch(K_W2SUM, nblk, wdev, h, a, 0, 0, st); launch(K_W2CONV, nblk, wdev, h, a, 0, 0, st); }
    continue;
    if (!napp_nmsg[a]) { launch(K_ATTN_IN, min(nblk, (R * (glob ? 3 : 1) + 3) / 4), wdev, h, a, 0, 0, st); }
    else {
      launch(K_GATE_MIX, min(nblk, gj), wdev, h, a, 0, 3, st);
      launch(K_GATE_DG, 12 * (DG3_ON ? 4 : 1), wdev, h, a, 0, 3, st);
      launch(K_GATE_FG, nblk, wdev, h, a, 0, 3, st);
      launch(K_GATE_NORM, min(nblk, gj), wdev, h, a, 0, 3, st);
    }
    launch(K_QKV, nblk, wdev, h, a, nq, 0, st);
    launch(K_KV, min(nblk, (R * (16 + NQH) + NW - 1) / NW), wdev, h, a, 0, 0, st);
    launch(K_ATTN, nblk, wdev, h, a, 0, 0, st);
    launch(K_OPROJ, min(nblk, 144), wdev, h, a, 0, 0, st);
    if (!napp_nmsg[a]) launch(K_MLP_IN, min(nblk, (R + 3) / 4), wdev, h, a, 0, 0, st);
    else {
      launch(K_GATE_MIX, min(nblk, (R + 3) / 4), wdev, h, a, 3, 1, st);
      launch(K_GATE_DG, 4 * (DG3_ON ? 4 : 1), wdev, h, a, 3, 1, st);
      launch(K_GATE_FG, min(nblk, 18), wdev, h, a, 3, 1, st);
      launch(K_GATE_NORM, min(nblk, (R + 3) / 4), wdev, h, a, 3, 1, st);
    }
    launch(K_ROUTER, DG3_ON ? 32 : 8, wdev, h, a, 0, 0, st);
    launch(K_W13, nblk, wdev, h, a, 0, 0, st);
    launch(K_W2, nblk, wdev, h, a, 0, 0, st);
    if (g_fuse2) launch(K_W2FUSED, min(nblk, (8 * (H / 2) + NT - 1) / NT), wdev, h, a, 0, 0, st);
    else { launch(K_W2SUM, nblk, wdev, h, a, 0, 0, st); launch(K_W2CONV, nblk, wdev, h, a, 0, 0, st); }
  }
  if (napp == NAPP) {
    launch(K_FIN_MIX, (R + 3) / 4, wdev, h, 0, 0, 0, st);
    launch(K_UNEMBED, nblk, wdev, h, 0, 0, 0, st);
    launch(K_TOKENS, 1, wdev, h, 0, 0, 0, st);
  }
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) { fprintf(stderr, "wk_launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}
}
