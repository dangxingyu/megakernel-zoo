"""Host side of the wide pass (engine/wk.cu): up to 64 rows (sequence slot, position, token) per launch, every row's
arithmetic independent of the other rows. Shares the megakernel's weights (api.Engine's device Ctx)."""
from __future__ import annotations
import ctypes, os
from pathlib import Path
import torch

HERE = Path(__file__).resolve().parent
H, NAPP, NE, TOPK, IE, QKVR, QW, NQH = 2304, 48, 128, 8, 1152, 8672, 3072, 24
NSQ, MAXR, RING, MAXCHW = 8, 64, 16, 40
VOCAB_REAL = 200058
P = ctypes.c_void_p


class WCtx(ctypes.Structure):
    _fields_ = [("c", P), ("fg", P * 24), ("maxctx", ctypes.c_int), ("pad0", ctypes.c_int),
                ("kc", P), ("vc", P), ("hk", P), ("hv", P), ("ha", P), ("hm", P), ("pb", P), ("X", P), ("qkv", P),
                ("arec", P), ("acnt", P), ("ao", P), ("as_", P), ("y", P), ("x16", P), ("s16", P), ("rl", P),
                ("act16", P), ("w2c", P), ("xm", P), ("xg", P), ("mg", P), ("ub", P), ("gv", P), ("xp", P), ("xf", P),
                ("amax", P), ("next_tok", P), ("bar", P), ("prof", P), ("rtab", P)]


class WHdr(ctypes.Structure):
    _fields_ = [("R", ctypes.c_int), ("flags", ctypes.c_int), ("rows", P), ("logits", P), ("out_tok", P)]


def frag_bf16(w: torch.Tensor) -> torch.Tensor:
    n, k = w.shape
    x = w.contiguous().view(n // 16, 2, 8, k // 16, 2, 4, 2).permute(0, 3, 2, 5, 4, 1, 6)
    return x.contiguous().view(torch.uint8).flatten()


class Wide:
    def __init__(self, eng, lib_path=None):
        self.eng = eng
        dev = eng.dev
        self.dev = dev
        self.lib = ctypes.CDLL(lib_path or os.environ.get("MK_WKLIB") or str(HERE / "build" / "libwk.so"))
        assert self.lib.wk_wctx_bytes() == ctypes.sizeof(WCtx), (self.lib.wk_wctx_bytes(), ctypes.sizeof(WCtx))
        assert self.lib.wk_layer_bytes() == eng.lib.mk_layer_bytes()
        assert self.lib.wk_setup(ctypes.c_void_p(ctypes.addressof(eng.ctx_host))) == 0
        if os.environ.get("MK_WPDL") == "0":
            self.lib.wk_set_pdl(0)
        self.nblk = eng.nblk
        self.keep = []
        maxctx = eng.maxctx
        self.maxctx = maxctx
        w = WCtx()
        w.c = eng.ctx_dev.data_ptr()
        w.maxctx = maxctx

        def z(*shape, dt=torch.bfloat16):
            t = torch.zeros(*shape, dtype=dt, device=dev)
            self.keep.append(t)
            return t

        for i, FG in eng.fg_rm.items():   # [4][2][H][64] -> rows (F_c, G_c) interleaved per channel -> frag order
            t = frag_bf16(FG.permute(0, 2, 1, 3).reshape(4 * 2 * H, 64))
            self.keep.append(t)
            w.fg[i] = t.data_ptr()
        self.kc = z(NAPP, NSQ, 8, maxctx, 128); w.kc = self.kc.data_ptr()
        self.vc = z(NAPP, NSQ, 8, maxctx, 128); w.vc = self.vc.data_ptr()
        self.rings = []
        for nm, wd in (("hk", 1024), ("hv", 1024), ("ha", H), ("hm", H)):
            t = z(NAPP, NSQ, RING, wd)
            self.rings.append(t)
            setattr(w, nm, t.data_ptr())
        self.pb = z(NAPP + 1, MAXR, H); w.pb = self.pb.data_ptr()
        w.X = z(3, MAXR, H).data_ptr()
        w.qkv = z(MAXR, QKVR, dt=torch.float32).data_ptr()
        w.arec = z(MAXR, NQH, MAXCHW, 132, dt=torch.float32).data_ptr()
        w.acnt = z(NSQ * 8, dt=torch.int32).data_ptr()
        w.ao = z(MAXR, QW).data_ptr()
        w.as_ = z(MAXR, H).data_ptr()
        w.y = z(MAXR, H).data_ptr()
        w.x16 = z(MAXR, 2, H, dt=torch.float16).data_ptr()
        w.s16 = z(MAXR, dt=torch.float32).data_ptr()
        w.rl = z(MAXR, NE, dt=torch.float32).data_ptr()
        w.act16 = z(MAXR * TOPK, 2, IE, dt=torch.float16).data_ptr()
        w.w2c = z(MAXR * TOPK, H, dt=torch.float32).data_ptr()
        w.xm = z(MAXR, H).data_ptr()
        w.xg = z(MAXR, 4, H, dt=torch.float32).data_ptr()
        w.mg = z(MAXR, 4, H, dt=torch.float32).data_ptr()
        w.ub = z(MAXR, 4, 2 * H).data_ptr()
        w.gv = z(MAXR, 4, 64, dt=torch.float32).data_ptr()
        w.xp = z(MAXR, 4, H, dt=torch.float32).data_ptr()
        self.xf = z(MAXR, H); w.xf = self.xf.data_ptr()
        w.amax = z(MAXR, dt=torch.int64).data_ptr()
        self.next_tok = z(MAXR, dt=torch.int32); w.next_tok = self.next_tok.data_ptr()
        w.bar = z(4, dt=torch.int32).data_ptr()
        w.rtab = z(self.lib.wk_rtab_bytes() // 4 + 4, dt=torch.int32).data_ptr()
        self.w = w
        self.hdr = z(4 + 4 * MAXR + 32, dt=torch.int32)
        self.shdr = z(4 + 4 * MAXR + 32, dt=torch.int32)   # the draft-and-verify cycle's rows (k_gather)
        import api as _api
        self.eng_apps = [(i, p) for (i, p, _) in _api.applications()]
        self.wdev = torch.frombuffer(bytearray(bytes(w)), dtype=torch.uint8).to(dev)
        torch.cuda.synchronize()

    PH_PLAIN = ["attn_in", "qkv", "kv", "attn", "oproj", "mlp_in", "router", "w13", "w2", "w2sum", "w2conv"]
    PH_GATED = ["gmix", "gD", "gFG", "gnorm", "qkv", "kv", "attn", "oproj", "mgmix", "mgD", "mgFG", "mgnorm", "router", "w13", "w2", "w2sum", "w2conv"]

    def profile(self):
        """Per phase: mean span (us) over plain / gated applications, from the barrier times of the last pass."""
        import collections
        t = self.prof.cpu().tolist()
        prev, k = t[4095], 1
        acc = collections.defaultdict(list)
        for a in range(NAPP):
            gated = 6 <= self.eng_apps[a][0] < 18 and self.eng_apps[a][1] >= 1
            names = self.PH_GATED if gated else self.PH_PLAIN
            for nm in names:
                acc[("g" if gated else "p", nm)].append((t[k] - prev) / 1e3); prev = t[k]; k += 1
        for nm in ("finmix", "unembed"):
            acc[("f", nm)].append((t[k] - prev) / 1e3); prev = t[k]; k += 1
        tot = (prev - t[4095]) / 1e3
        out = {kk: sum(v) / len(v) for kk, v in acc.items()}
        return out, tot

    FEAT_IDX = (5, 23, 41)

    def feats(self, R):
        """[R, 4, H] bf16 draft features of the last pass's rows."""
        return torch.stack([self.pb[i, :R] for i in self.FEAT_IDX] + [self.xf[:R]], 1)

    def reset(self):
        torch.cuda.synchronize()
        for t in self.rings:
            t.zero_()
        torch.cuda.synchronize()

    def run(self, rows: torch.Tensor, logits: torch.Tensor | None = None, out_tok: torch.Tensor | None = None, flags: int = 0):
        """rows: int32 [R, 4] (sequence slot, position, token, 0) on the device; rows of one sequence consecutive
        positions in increasing order. logits: optional float32 [R, VOCAB_REAL]."""
        R = rows.shape[0]
        assert 1 <= R <= MAXR and rows.dtype == torch.int32 and rows.is_cuda
        self.hdr[0] = R
        self.hdr[4:4 + 4 * R].copy_(rows.reshape(-1))
        self.run_dev(self.hdr, R, logits, out_tok, flags)

    KMAX = int(os.environ.get("MK_WKMAX", "8"))

    def gather(self, vpos, vtok, active, limit):
        st = ctypes.c_void_p(torch.cuda.current_stream().cuda_stream)
        assert self.lib.wk_gather(ctypes.c_void_p(self.shdr.data_ptr()), ctypes.c_void_p(vpos.data_ptr()), ctypes.c_void_p(vtok.data_ptr()),
                                  ctypes.c_void_p(active.data_ptr()), int(limit), int(self.KMAX), st) == 0

    def scatter(self, tgt, feats):
        st = ctypes.c_void_p(torch.cuda.current_stream().cuda_stream)
        assert self.lib.wk_scatter(ctypes.c_void_p(self.shdr.data_ptr()), ctypes.c_void_p(self.next_tok.data_ptr()), ctypes.c_void_p(self.pb.data_ptr()),
                                   ctypes.c_void_p(self.xf.data_ptr()), ctypes.c_void_p(tgt.data_ptr()), ctypes.c_void_p(feats.data_ptr()), st) == 0

    def feed(self, hdr=None):
        """hdr rows advance one position, token = their own argmax of the last pass (device)."""
        hdr = self.hdr if hdr is None else hdr
        assert self.lib.wk_feed(ctypes.c_void_p(hdr.data_ptr()), ctypes.c_void_p(self.next_tok.data_ptr()),
                                ctypes.c_void_p(torch.cuda.current_stream().cuda_stream)) == 0

    def run_dev(self, hdr: torch.Tensor, rmax: int, logits=None, out_tok=None, flags: int = 0):
        """hdr: int32 device [4 + 4 MAXR]: hdr[0] = R (<= rmax), rows from hdr[4]."""
        h = WHdr()
        h.R, h.flags, h.rows = rmax, flags, hdr.data_ptr()
        h.logits = logits.data_ptr() if logits is not None else 0
        h.out_tok = out_tok.data_ptr() if out_tok is not None else 0
        r = self.lib.wk_launch(ctypes.c_void_p(self.wdev.data_ptr()), ctypes.byref(h), self.nblk,
                               ctypes.c_void_p(torch.cuda.current_stream().cuda_stream))
        assert r == 0, "wk launch failed"
