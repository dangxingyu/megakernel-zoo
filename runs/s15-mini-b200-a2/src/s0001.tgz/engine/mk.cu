// Inkling-2-Mini decode engine: one persistent cooperative kernel per step on one B200.
// See notes/plan.md. Phases separated by a counter grid barrier; all reductions in a fixed order.
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef __nv_bfloat16 bf16;

#define H 2304
#define HP (H + 8)
#define NQH 24
#define NKV 8
#define HD 128
#define QW 3072
#define QWP (QW + 8)
#define NE 128
#define TOPK 8
#define IE 1152
#define NLW 24
#define NAPP 48
#define MAXB 8
#ifndef NTH
#define NTH 768
#endif
#define NWARP (NTH / 32)
#define CH 64            // attention positions per item
#define MAXCH 64         // up to 4096 positions
#define MAXU 64          // union experts per layer
#define VOCAB_REAL 200058
#define UN_STRIPS 12504  // 200064 rows
// fused qkv matrix rows (output layout fixed; weight strips: 410 + 2 * nsk)
#define R_G 3072
#define R_R 6144
#define R_S 6528
#define QG_STRIPS 410
#define K0 6560
#define V0 7616
#define QKVR 8672
// pieces (units of 64 k per item)
#define QKV_PU 6
#define QKV_NP 6
#define O_PU 6
#define O_NP 8
#define RT_PU 6
#define RT_NP 6
#define D_PU 6
#define D_NP 12

// ------------------------------------------------------------------------------------------------ parameters
struct LayerW {
  const uint8_t* wqkv; const uint8_t* wo; const uint8_t* wr; const float* rbias;
  const uint8_t* w13; const uint8_t* w2; const float* f13; const float* f2;
  const bf16* norm[3]; const bf16* mlp_norm;
  const bf16* ksc; const bf16* vsc; const bf16* attn_sc; const bf16* mlp_sc;
  const bf16* qscale; const bf16* rscale; const bf16* relp;
  const float* aq; const float* mq;
  const uint8_t* cD; const bf16* cFG;
  int nsk, mx, glob, naq;
};
struct App { int layer, pass, slot, bnd, nblk, blk[4], pin, nmsg, msg[2], loopl, out, pad; };
struct Ctx {
  LayerW L[NLW];
  App A[NAPP];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm; const uint8_t* unembed;
  const float* loopq;
  int nfin, fin[4], fin_pin, maxctx;
  bf16* pbuf; bf16* kc; bf16* vc;
  bf16* hk; bf16* hv; bf16* ha; bf16* hm;
  float* qkv; float* arec; bf16* aout; bf16* attn_s; float* rlog; __half* act16;
  float* part; float* w2p; unsigned* cnt; unsigned* bar;
  float* xg; float* mg; bf16* ub; float* gv; float* xp;
  unsigned long long* amax; int* next_tok;
  long long* prof;
};
struct Hdr { int B, pos, flags, nsteps; const int* tokens; float* logits; int* out_tok; int out_stride, pad; };
#define F_LOGITS 1

// counter regions
#define CN_QKV 0
#define CN_ATT 1024
#define CN_O 1280
#define CN_RT 1536
#define CN_D 1600
#define CN_W13 2048          // MAXU * 144
#define CN_W2 (2048 + 9216)  // MAXB * 144
#define CN_TOTAL (CN_W2 + 1152 + 64)

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldcg_u32(const void* p) {
  uint32_t r;
  asm volatile("ld.global.cg.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ float ldcg_f(const float* p) { return __ldcg(p); }
__device__ __forceinline__ float4 ldcg_f4(const float4* p) { return __ldcg(p); }
__device__ __forceinline__ uint32_t cvt_fp4x2(uint32_t b) {
  uint32_t r; unsigned short bs = (unsigned short)b;
  asm("{ .reg .b8 t; cvt.u8.u16 t, %1; cvt.rn.f16x2.e2m1x2 %0, t; }" : "=r"(r) : "h"(bs));
  return r;
}
__device__ __forceinline__ uint32_t cvt_e4m3x2(uint32_t w16) {
  uint32_t r; unsigned short h = (unsigned short)w16;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(h));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }
__device__ __forceinline__ unsigned ld_relaxed_gpu(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void fence_acqrel_gpu() { asm volatile("fence.acq_rel.gpu;" ::: "memory"); }
__device__ __forceinline__ void red_release_gpu(unsigned* p, unsigned v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %globaltimer;" : "=l"(t)); return t; }
__device__ __forceinline__ int lane_id() { int l; asm("mov.u32 %0, %%laneid;" : "=r"(l)); return l; }

// ------------------------------------------------------------------------------------------------ shared memory
struct Smem {
  union {
    bf16 xs[3][MAXB][HP];                 // B operands (bf16), streams q / k / v (router, unembed: stream 0)
    bf16 xo[MAXB][QWP];                   // o_proj input
    struct { bf16 xr[MAXB][HP]; __half x16[MAXB][2][HP]; } e;   // router input + expert input (f16 hi / lo)
    struct {                               // attention item
      bf16 kk[CH][HD]; bf16 vv[CH][HD];
      float q[3][HD]; float sc[3][CH]; float bias[3][CH]; float rr[3][16];
      float kt[HD]; float vt[HD]; float ml[3][2];
    } at;
  } u;
  float red[NWARP][32];
  float bcast[64];
  float sc16[MAXB];                        // 2^-s of the expert input f16 scaling per token
  // routing tables (identical in every block)
  int nU; int uexp[MAXU]; int uncnt[MAXU]; int utok[MAXU][MAXB];
  int tex[MAXB][TOPK]; float twt[MAXB][TOPK]; int tslot[MAXB][TOPK];   // per token: experts by id, weights, union slot
  int flag;
};

// ------------------------------------------------------------------------------------------------ barrier
__device__ __forceinline__ void grid_bar(const Ctx& c, unsigned& nbar, unsigned base) {
  __syncthreads();
  nbar += 1;
  if (threadIdx.x == 0) {
    unsigned target = base + nbar * gridDim.x;
    __threadfence();
    red_release_gpu(&c.bar[0], 1);
    while ((int)(ld_relaxed_gpu(&c.bar[0]) - target) < 0) { }
    fence_acqrel_gpu();
  }
  __syncthreads();
}

// block-wide sum of N values per thread (all threads get the result)
template <int N>
__device__ __forceinline__ void block_sum(float* v, Smem& sm) {
  const int w = threadIdx.x >> 5, l = threadIdx.x & 31;
#pragma unroll
  for (int i = 0; i < N; i++) {
    float x = v[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x += __shfl_xor_sync(0xffffffff, x, o);
    v[i] = x;
  }
  if (l == 0) {
#pragma unroll
    for (int i = 0; i < N; i++) sm.red[w][i] = v[i];
  }
  __syncthreads();
  if (threadIdx.x < N) {
    float s = 0.f;
    for (int k = 0; k < NWARP; k++) s += sm.red[k][threadIdx.x];
    sm.bcast[threadIdx.x] = s;
  }
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) v[i] = sm.bcast[i];
  __syncthreads();
}
__device__ __forceinline__ float block_max1(float x, Smem& sm) {
  const int w = threadIdx.x >> 5, l = threadIdx.x & 31;
#pragma unroll
  for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffff, x, o));
  if (l == 0) sm.red[w][0] = x;
  __syncthreads();
  if (threadIdx.x == 0) {
    float s = sm.red[0][0];
    for (int k = 1; k < NWARP; k++) s = fmaxf(s, sm.red[k][0]);
    sm.bcast[0] = s;
  }
  __syncthreads();
  float r = sm.bcast[0];
  __syncthreads();
  return r;
}

// ------------------------------------------------------------------------------------------------ mixes
// Every thread holds elements e = threadIdx.x + k * NTH, k < 3 (H = 3 * NTH).
#define EPT 3
static_assert(H == EPT * NTH, "H must be 3 * NTH");

// softmax over depth: sources v[s][k] (f32), queries qs[q] (f32 [H]); out[q][k] (f32). normalize_values = true.
template <int NS_MAX, int NQ_MAX>
__device__ __forceinline__ void depth_mix(float (*v)[EPT], int ns, const float* const* qs, int nq, float (*out)[EPT], Smem& sm) {
  float red[NS_MAX + NQ_MAX * NS_MAX];
#pragma unroll
  for (int i = 0; i < NS_MAX + NQ_MAX * NS_MAX; i++) red[i] = 0.f;
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) {
    if (s < ns) {
#pragma unroll
      for (int k = 0; k < EPT; k++) red[s] += v[s][k] * v[s][k];
    }
  }
#pragma unroll
  for (int q = 0; q < NQ_MAX; q++) {
    if (q < nq) {
      float qv[EPT];
#pragma unroll
      for (int k = 0; k < EPT; k++) qv[k] = qs[q][threadIdx.x + k * NTH];
#pragma unroll
      for (int s = 0; s < NS_MAX; s++)
        if (s < ns) {
#pragma unroll
          for (int k = 0; k < EPT; k++) red[NS_MAX + q * NS_MAX + s] += v[s][k] * qv[k];
        }
    }
  }
  block_sum<NS_MAX + NQ_MAX * NS_MAX>(red, sm);
  float inv[NS_MAX];
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) inv[s] = rsqrtf(red[s] / (float)H + 1e-6f);
  const float hs = rsqrtf((float)H);
#pragma unroll
  for (int q = 0; q < NQ_MAX; q++) {
    if (q >= nq) continue;
    float lg[NS_MAX], mx = -1e30f;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) {
      lg[s] = (s < ns) ? red[NS_MAX + q * NS_MAX + s] * hs * inv[s] : -1e30f;
      mx = fmaxf(mx, lg[s]);
    }
    float den = 0.f;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) { lg[s] = (s < ns) ? expf(lg[s] - mx) : 0.f; den += lg[s]; }
    float rd = 1.0f / den;
#pragma unroll
    for (int k = 0; k < EPT; k++) {
      float o = 0.f;
#pragma unroll
      for (int s = 0; s < NS_MAX; s++)
        if (s < ns) o += (lg[s] * rd) * (v[s][k] * inv[s]);
      out[q][k] = o;
    }
  }
}

// rmsnorm with weight -> bf16 into dst (smem row, length H)
__device__ __forceinline__ void rmsnorm_store(const float* x, const bf16* w, bf16* dst, Smem& sm, float* rs_out = nullptr) {
  float s[1] = {0.f};
#pragma unroll
  for (int k = 0; k < EPT; k++) s[0] += x[k] * x[k];
  block_sum<1>(s, sm);
  float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
  for (int k = 0; k < EPT; k++) {
    int e = threadIdx.x + k * NTH;
    float y = x[k] * r;
    if (w) y = y * bf(w[e]);
    dst[e] = tobf(y);
  }
  if (rs_out) *rs_out = r;
}

__device__ __forceinline__ float ldcg_bf(const bf16* p) { return bf(__ushort_as_bfloat16(__ldcg(reinterpret_cast<const unsigned short*>(p)))); }
__device__ __forceinline__ void load_src(const Ctx& c, int idx, int b, float* v) {
  const bf16* p = c.pbuf + ((long)idx * MAXB + b) * H;
#pragma unroll
  for (int k = 0; k < EPT; k++) v[k] = ldcg_bf(p + threadIdx.x + k * NTH);
}

// ------------------------------------------------------------------------------------------------ GEMV pieces
// B operand loaders. bf16 smem rows: element (k, col n) at base[n * stride + k].
struct BSm {
  const bf16* base; int stride; int ncol;   // columns >= ncol read as zero
  __device__ __forceinline__ uint2 get(int k0) const {
    const int l = lane_id(), g = l >> 2, t = l & 3;
    if (g >= ncol) return make_uint2(0, 0);
    const bf16* p = base + g * stride + k0 + 2 * t;
    return make_uint2(*reinterpret_cast<const uint32_t*>(p), *reinterpret_cast<const uint32_t*>(p + 8));
  }
};
struct BGl {   // bf16 rows in global memory written in this launch (L1 bypass)
  const bf16* base; int stride; int ncol;
  __device__ __forceinline__ uint2 get(int k0) const {
    const int l = lane_id(), g = l >> 2, t = l & 3;
    if (g >= ncol) return make_uint2(0, 0);
    const bf16* p = base + (long)g * stride + k0 + 2 * t;
    return make_uint2(ldcg_u32(p), ldcg_u32(p + 8));
  }
};

template <class BL>
__device__ __forceinline__ void piece_bf16(const uint8_t* wst, int u0, int nu, const BL& bl, float* acc) {
  const int lane = lane_id();
  int u = u0;
  const int ue = u0 + nu;
  for (; u + 2 <= ue; u += 2) {
    uint4 w[8];
#pragma unroll
    for (int q = 0; q < 8; q++) w[q] = ldg_nc(wst + ((long)(u + (q >> 2)) * 4 + (q & 3)) * 512 + lane * 16);
#pragma unroll
    for (int q = 0; q < 8; q++) {
      uint2 b = bl.get((u + (q >> 2)) * 64 + (q & 3) * 16);
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b.x, b.y);
    }
  }
  for (; u < ue; u++) {
    uint4 w[4];
#pragma unroll
    for (int q = 0; q < 4; q++) w[q] = ldg_nc(wst + ((long)u * 4 + q) * 512 + lane * 16);
#pragma unroll
    for (int q = 0; q < 4; q++) {
      uint2 b = bl.get(u * 64 + q * 16);
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b.x, b.y);
    }
  }
}

// f16 B operand for experts: columns n = 2 * li + part (part 0: hi, 1: lo), li = 4 * ng + t-th token of the expert
struct BX16 {   // smem x16[tok][part][k]
  const __half* base; int stride2; int tok[4]; int ok[4];   // per n-group lane mapping prepared by caller
};
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {  // bytes (g,g8) j0, (g,g8) j1 -> {g,g},{g8,g8},{g,g},{g8,g8}
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
// B fragments of one unit (64 k) for NG n-groups: bfr[ng][j] = (b0, b1)
template <int NG>
__device__ __forceinline__ void load_b16_unit(const __half* const* colp, int u, uint2 (*bfr)[4]) {
  const int t = lane_id() & 3;
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    const __half* p = colp[ng];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      if (p) {
        const __half* q = p + u * 64 + j * 16 + 2 * t;
        bfr[ng][j] = make_uint2(*reinterpret_cast<const uint32_t*>(q), *reinterpret_cast<const uint32_t*>(q + 8));
      } else bfr[ng][j] = make_uint2(0, 0);
    }
  }
}
template <int NG>
__device__ __forceinline__ void load_b16_unit_gl(const __half* const* colp, int u, uint2 (*bfr)[4]) {
  const int t = lane_id() & 3;
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    const __half* p = colp[ng];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      if (p) {
        const __half* q = p + u * 64 + j * 16 + 2 * t;
        bfr[ng][j] = make_uint2(ldcg_u32(q), ldcg_u32(q + 8));
      } else bfr[ng][j] = make_uint2(0, 0);
    }
  }
}

// NVFP4: per unit 576 B: codes [lane][16 B], scales [g][8 B]
template <int NG, bool GL>
__device__ __forceinline__ void piece_fp4(const uint8_t* wst, int u0, int nu, const __half* const* colp, float (*acc)[4]) {
  const int lane = lane_id(), g = lane >> 2;
  for (int u = u0; u < u0 + nu; u++) {
    uint4 cw = ldg_nc(wst + (long)u * 576 + lane * 16);
    uint2 sw = ldg_nc2(wst + (long)u * 576 + 512 + g * 8);
    uint2 bfr[NG][4];
    if (GL) load_b16_unit_gl<NG>(colp, u, bfr); else load_b16_unit<NG>(colp, u, bfr);
    uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
    uint32_t ss[2] = {sw.x, sw.y};
#pragma unroll
    for (int jj = 0; jj < 2; jj++) {
      uint32_t sc[4];
      scl4(ss[jj], sc);
#pragma unroll
      for (int h = 0; h < 2; h++) {
        const int j = jj * 2 + h;
        uint32_t a[4];
        cvt4(cc[j], a);
        const uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
        const uint32_t a0 = hmul2(a[0], sg), a1 = hmul2(a[1], sg8), a2 = hmul2(a[2], sg), a3 = hmul2(a[3], sg8);
#pragma unroll
        for (int ng = 0; ng < NG; ng++) mma_f16(acc[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
      }
    }
  }
}
// MXFP8: per unit 1056 B: codes [lane][32 B] ((j, kh) u32 = rows (g, g8) pairs), scales [g][blk][r] 4 B
template <int NG, bool GL>
__device__ __forceinline__ void piece_fp8(const uint8_t* wst, int u0, int nu, const __half* const* colp, float (*acc)[4]) {
  const int lane = lane_id(), g = lane >> 2;
  for (int u = u0; u < u0 + nu; u++) {
    uint4 c0 = ldg_nc(wst + (long)u * 1056 + lane * 32);
    uint4 c1 = ldg_nc(wst + (long)u * 1056 + lane * 32 + 16);
    uint32_t sw = ldg_nc1(wst + (long)u * 1056 + 1024 + g * 4);
    uint2 bfr[NG][4];
    if (GL) load_b16_unit_gl<NG>(colp, u, bfr); else load_b16_unit<NG>(colp, u, bfr);
    uint32_t cc[8] = {c0.x, c0.y, c0.z, c0.w, c1.x, c1.y, c1.z, c1.w};
#pragma unroll
    for (int blk = 0; blk < 2; blk++) {
      float d[NG][4];
#pragma unroll
      for (int ng = 0; ng < NG; ng++) { d[ng][0] = d[ng][1] = d[ng][2] = d[ng][3] = 0.f; }
#pragma unroll
      for (int h = 0; h < 2; h++) {
        const int j = blk * 2 + h;
        const uint32_t x0 = cc[2 * j], x1 = cc[2 * j + 1];
        const uint32_t a0 = cvt_e4m3x2(x0 & 0xffff), a1 = cvt_e4m3x2(x0 >> 16), a2 = cvt_e4m3x2(x1 & 0xffff), a3 = cvt_e4m3x2(x1 >> 16);
#pragma unroll
        for (int ng = 0; ng < NG; ng++) mma_f16(d[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
      }
      const uint32_t e0 = (sw >> (16 * blk)) & 0xff, e1 = (sw >> (16 * blk + 8)) & 0xff;
      const float s0 = e0 ? __int_as_float(e0 << 23) : __int_as_float(0x00400000), s1 = e1 ? __int_as_float(e1 << 23) : __int_as_float(0x00400000);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) {
        acc[ng][0] = fmaf(d[ng][0], s0, acc[ng][0]); acc[ng][1] = fmaf(d[ng][1], s0, acc[ng][1]);
        acc[ng][2] = fmaf(d[ng][2], s1, acc[ng][2]); acc[ng][3] = fmaf(d[ng][3], s1, acc[ng][3]);
      }
    }
  }
}

// write a warp's piece, return true (in all lanes) if this warp is the last of `npieces` for counter `cnt`;
// then a[] holds the sum of all pieces in piece order.
__device__ __forceinline__ bool piece_reduce(float* part, unsigned* cnt, int piece, int npieces, float* acc) {
  const int lane = lane_id();
  float4* slot = reinterpret_cast<float4*>(part);
  slot[piece * 32 + lane] = make_float4(acc[0], acc[1], acc[2], acc[3]);
  __threadfence();
  __syncwarp();
  unsigned old = 0;
  if (lane == 0) old = atomicAdd(cnt, 1u);
  old = __shfl_sync(0xffffffff, old, 0);
  if (old != (unsigned)(npieces - 1)) return false;
  __threadfence();
  float a0 = 0.f, a1 = 0.f, a2 = 0.f, a3 = 0.f;
  for (int p = 0; p < npieces; p++) {
    float4 v = ldcg_f4(slot + p * 32 + lane);
    a0 += v.x; a1 += v.y; a2 += v.z; a3 += v.w;
  }
  acc[0] = a0; acc[1] = a1; acc[2] = a2; acc[3] = a3;
  if (lane == 0) atomicExch(cnt, 0u);
  return true;
}

// ------------------------------------------------------------------------------------------------ sconv
// static short convolution (kernel 4, tap 3 = current), identity residual, x 5^-1/2; ring of the last 3 raw inputs
__device__ __forceinline__ float sconv_static(float x, const bf16* hist_row_base, long ring_stride, int pos, const bf16* w4) {
  // ring[(pos + 2) % 3] = x[t-1], ring[(pos + 1) % 3] = x[t-2], ring[pos % 3] = x[t-3]
  const float x1 = ldcg_bf(hist_row_base + ((pos + 2) % 3) * ring_stride);
  const float x2 = ldcg_bf(hist_row_base + ((pos + 1) % 3) * ring_stride);
  const float x3 = ldcg_bf(hist_row_base + (pos % 3) * ring_stride);
  float acc = __fmul_rn(x3, bf(w4[0]));
  acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
  acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
  acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
  return __fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f);
}

// ------------------------------------------------------------------------------------------------ phases
#define PH_ARGS const Ctx& c, const Hdr& hd, Smem& sm, unsigned& nbar, unsigned base

// The attention input streams of application a (f32, registers) -> normalized bf16 smem streams, or (gated
// applications) the gate phases. nstreams_out: streams in sm.u.xs.
__device__ int ph_attn_in(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = hd.B;
  const int nq = L.glob ? 3 : 1;
  if (ap.nmsg == 0) {
    for (int b = 0; b < B; b++) {
      float v[5][EPT];
      float x[3][EPT];
      if (a == 0) {
        // h0 = rmsnorm(embed[tok]) * embed_norm (bf16); block 0 stores it as pbuf[0]
        const int tok = hd.tokens[b];
        const bf16* er = c.embed + (long)tok * H;
        float e[EPT], s[1] = {0.f};
#pragma unroll
        for (int k = 0; k < EPT; k++) { e[k] = bf(er[threadIdx.x + k * NTH]); s[0] += e[k] * e[k]; }
        block_sum<1>(s, sm);
        const float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
        for (int k = 0; k < EPT; k++) {
          const int el = threadIdx.x + k * NTH;
          const bf16 h0 = tobf(e[k] * r * bf(c.embed_norm[el]));
          if (blockIdx.x == 0) c.pbuf[(long)b * H + el] = h0;
          x[0][k] = bf(h0);
        }
      } else {
        for (int s = 0; s < ap.nblk; s++) load_src(c, ap.blk[s], b, v[s]);
        load_src(c, ap.pin, b, v[ap.nblk]);
        const float* qs[3] = {L.aq, L.aq + H, L.aq + 2 * H};
        depth_mix<5, 3>(v, ap.nblk + 1, qs, nq, x, sm);
      }
      for (int q = 0; q < nq; q++) rmsnorm_store(x[q], L.norm[q], &sm.u.xs[q][b][0], sm);
    }
    __syncthreads();
    return nq;
  }
  // ---- gated (loop passes 2 and 3): G1 on block 0, D GEMV, F/G elementwise, then the norms
  if (blockIdx.x == 0) {
    for (int b = 0; b < B; b++) {
      float v[5][EPT], x[3][EPT], m[3][EPT], ms[2][EPT];
      for (int s = 0; s < ap.nblk; s++) load_src(c, ap.blk[s], b, v[s]);
      load_src(c, ap.pin, b, v[ap.nblk]);
      const float* qs[3] = {L.aq, L.aq + H, L.aq + 2 * H};
      depth_mix<5, 3>(v, ap.nblk + 1, qs, nq, x, sm);
      if (nq == 1) {
#pragma unroll
        for (int k = 0; k < EPT; k++) { x[1][k] = x[0][k]; x[2][k] = x[0][k]; }
      }
      load_src(c, ap.msg[0], b, ms[0]);
      load_src(c, ap.msg[1], b, ms[1]);
      const float* lq = c.loopq + (long)ap.loopl * 4 * H;
      const float* mq[3] = {lq, lq + H, lq + 2 * H};
      depth_mix<2, 3>(ms, 2, mq, 3, m, sm);
      for (int q = 0; q < 3; q++) {
        float s[2] = {0.f, 0.f};
#pragma unroll
        for (int k = 0; k < EPT; k++) { s[0] += x[q][k] * x[q][k]; s[1] += m[q][k] * m[q][k]; }
        block_sum<2>(s, sm);
        const float rx = rsqrtf(s[0] / (float)H + 1e-6f), rm = rsqrtf(s[1] / (float)H + 1e-6f);
#pragma unroll
        for (int k = 0; k < EPT; k++) {
          const int el = threadIdx.x + k * NTH;
          c.xg[((long)b * 4 + q) * H + el] = x[q][k];
          c.mg[((long)b * 4 + q) * H + el] = m[q][k];
          c.ub[((long)b * 4 + q) * 2 * H + el] = tobf(x[q][k] * rx);
          c.ub[((long)b * 4 + q) * 2 * H + H + el] = tobf(m[q][k] * rm);
        }
      }
    }
  }
  return -1;   // caller runs the gate phases
}

// D GEMV of controllers [c0, c0 + nc): 4 strips each, K = 4608; B operand ub[b][ctrl] (global)
__device__ void ph_gate_d(PH_ARGS, int a, int c0, int nc) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = hd.B;
  const int w = threadIdx.x >> 5, lane = lane_id();
  const int N = nc * 4 * D_NP;
  for (int it = blockIdx.x + gridDim.x * w; it < N; it += gridDim.x * NWARP) {
    const int strip = c0 * 4 + it / D_NP, piece = it % D_NP;
    const int ctrl = strip >> 2;
    BGl bl{c.ub + (long)ctrl * 2 * H, 4 * 2 * H, B};
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    piece_bf16(L.cD + (long)strip * 72 * 2048, piece * D_PU, D_PU, bl, acc);
    if (piece_reduce(c.part + (long)strip * D_NP * 128, c.cnt + CN_D + strip, piece, D_NP, acc)) {
      const int g = lane >> 2, t = lane & 3;
      const int row = (strip & 3) * 16 + g;
      for (int h = 0; h < 2; h++)
        for (int cc = 0; cc < 2; cc++) {
          const int tok = 2 * t + cc;
          if (tok < B) c.gv[((long)tok * 4 + ctrl) * 64 + row + 8 * h] = rbf(acc[2 * h + cc]);
        }
    }
  }
}
// F / G elementwise for controllers [c0, c0 + nc): xp[b][ctrl][i]
__device__ void ph_gate_fg(PH_ARGS, int a, int c0, int nc) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = hd.B;
  const int N = nc * B * H;
  for (int it = blockIdx.x * NTH + threadIdx.x; it < N; it += gridDim.x * NTH) {
    const int i = it % H, rest = it / H, b = rest % B, ctrl = c0 + rest / B;
    const bf16* F = L.cFG + ((long)ctrl * 2 * H + i) * 64;
    const bf16* G = L.cFG + ((long)ctrl * 2 * H + H + i) * 64;
    const float* gvv = c.gv + ((long)b * 4 + ctrl) * 64;
    float f = 0.f, gg = 0.f;
#pragma unroll 8
    for (int r = 0; r < 64; r++) {
      const float gr = ldcg_f(gvv + r);
      f = fmaf(bf(F[r]), gr, f);
      gg = fmaf(bf(G[r]), gr, gg);
    }
    f = tanhf(f); gg = tanhf(gg);
    const float xv = ldcg_f(c.xg + ((long)b * 4 + ctrl) * H + i), mv = ldcg_f(c.mg + ((long)b * 4 + ctrl) * H + i);
    c.xp[((long)b * 4 + ctrl) * H + i] = (1.f - f) * xv + gg * mv;
  }
}

// QKV GEMV + epilogue: qkv[b][row] (bf16-rounded f32)
__device__ void ph_qkv(PH_ARGS, int a, int nstreams) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = hd.B;
  const int nsk = L.nsk;
  const int strips = QG_STRIPS + 2 * nsk;
  const int N = strips * QKV_NP;
  const int w = threadIdx.x >> 5, lane = lane_id();
  for (int it = blockIdx.x + gridDim.x * w; it < N; it += gridDim.x * NWARP) {
    const int strip = it / QKV_NP, piece = it % QKV_NP;
    int st = strip < QG_STRIPS ? 0 : (strip < QG_STRIPS + nsk ? 1 : 2);
    const int orow = st == 0 ? strip * 16 : (st == 1 ? K0 + (strip - QG_STRIPS) * 16 : V0 + (strip - QG_STRIPS - nsk) * 16);
    if (st >= nstreams) st = 0;
    BSm bl{&sm.u.xs[st][0][0], HP, B};
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    piece_bf16(L.wqkv + (long)strip * 36 * 2048, piece * QKV_PU, QKV_PU, bl, acc);
    if (piece_reduce(c.part + (long)strip * QKV_NP * 128, c.cnt + CN_QKV + strip, piece, QKV_NP, acc)) {
      const int g = lane >> 2, t = lane & 3;
      for (int h = 0; h < 2; h++)
        for (int cc = 0; cc < 2; cc++) {
          const int tok = 2 * t + cc;
          if (tok < B) c.qkv[(long)tok * QKVR + orow + g + 8 * h] = rbf(acc[2 * h + cc]);
        }
    }
  }
}

// attention: items (b, kv head g, chunk)
__device__ void ph_attn(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = hd.B, t = hd.pos;
  const int lo = L.glob ? 0 : max(0, t + 1 - 1024);
  const int nch = (t - lo + CH) / CH;
  const int N = B * NKV * nch;
  const float tau = L.glob ? (1.0f + 0.1f * logf(fmaxf(1.0f, (float)(t + 1) / 8192.0f))) : 1.0f;
  const bool use_tau = L.glob;
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31;
  auto& at = sm.u.at;
  const long cstride = (long)c.maxctx * HD;   // per (slot, b, head)
  for (int it = blockIdx.x; it < N; it += gridDim.x) {
    const int ch = it % nch, g = (it / nch) % NKV, b = it / (nch * NKV);
    const int j0 = lo + ch * CH, j1 = min(j0 + CH, t + 1), nj = j1 - j0;
    const float* qr = c.qkv + (long)b * QKVR;
    // q and r of heads 3g..3g+2 (warps 0-2: q of head w; warps 3-5: r)
    if (w < 3) {
      const int h = 3 * g + w;
      float qv[4], ss = 0.f;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int d = lane * 4 + k;
        qv[k] = ldcg_f(qr + h * HD + d) * bf(L.qscale[h * HD + d]);
        ss += qv[k] * qv[k];
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
#pragma unroll
      for (int k = 0; k < 4; k++) {
        float y = rbf(qv[k] * f);
        if (use_tau) y = rbf(y * tau);
        at.q[w][lane * 4 + k] = y;
      }
    } else if (w < 6) {
      const int hh = w - 3, h = 3 * g + hh;
      float rv = 0.f, ss = 0.f;
      if (lane < 16) { rv = ldcg_f(qr + R_R + h * 16 + lane) * bf(L.rscale[h * 16 + lane]); ss = rv * rv; }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = fminf(8.0f / (sqrtf(ss) + 1e-6f), 1.0f);
      if (lane < 16) {
        float y = rbf(rv * f);
        if (use_tau) y = rbf(y * tau);
        at.rr[hh][lane] = y;
      }
    } else if (w == 6 && j1 == t + 1) {
      // current k (lane-parallel over 128 dims, 4 per lane): raw, conv, clip
      const long hrow = ((long)ap.slot * MAXB + b) * 3 * 1024;
      float kv[4], ss = 0.f;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int d = lane * 4 + k, ch2 = g * HD + d;
        const float x = ldcg_f(qr + K0 + ch2);
        const bf16* hb = c.hk + hrow + ch2;
        const float x1 = ldcg_bf(hb + ((t + 2) % 3) * 1024), x2 = ldcg_bf(hb + ((t + 1) % 3) * 1024), x3 = ldcg_bf(hb + (t % 3) * 1024);
        float y;
        if (!L.glob) {
          const bf16* w4 = L.ksc + ch2 * 4;
          float acc = __fmul_rn(x3, bf(w4[0]));
          acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
          acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
          acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
          y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f));
        } else {
          const float* dyn = qr + K0 + 1024 + g * 4;
          float acc = 0.f;
          const float xs4[4] = {x, x1, x2, x3};
#pragma unroll
          for (int lag = 0; lag < 4; lag++) acc = __fadd_rn(acc, __fmul_rn(xs4[lag], __fadd_rn(bf(L.ksc[lag * 1024 + ch2]), ldcg_f(dyn + lag))));
          y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.33333333333333333f));
        }
        kv[k] = y; ss += y * y;
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
#pragma unroll
      for (int k = 0; k < 4; k++) at.kt[lane * 4 + k] = rbf(kv[k] * f);
    } else if (w == 7 && j1 == t + 1) {
      const long hrow = ((long)ap.slot * MAXB + b) * 3 * 1024;
      float vv[4], ss = 0.f;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int d = lane * 4 + k, ch2 = g * HD + d;
        const float x = ldcg_f(qr + V0 + ch2);
        const bf16* hb = c.hv + hrow + ch2;
        const float x1 = ldcg_bf(hb + ((t + 2) % 3) * 1024), x2 = ldcg_bf(hb + ((t + 1) % 3) * 1024), x3 = ldcg_bf(hb + (t % 3) * 1024);
        float y;
        if (!L.glob) {
          const bf16* w4 = L.vsc + ch2 * 4;
          float acc = __fmul_rn(x3, bf(w4[0]));
          acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
          acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
          acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
          y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f));
        } else {
          const float* dyn = qr + V0 + 1024 + g * 4;
          float acc = 0.f;
          const float xs4[4] = {x, x1, x2, x3};
#pragma unroll
          for (int lag = 0; lag < 4; lag++) acc = __fadd_rn(acc, __fmul_rn(xs4[lag], __fadd_rn(bf(L.vsc[lag * 1024 + ch2]), ldcg_f(dyn + lag))));
          y = rbf(__fmul_rn(__fadd_rn(acc, x), 0.33333333333333333f));
        }
        vv[k] = y; ss += y * y;
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float r = rsqrtf(ss / 128.f + 1e-6f);
#pragma unroll
      for (int k = 0; k < 4; k++) at.vt[lane * 4 + k] = rbf(vv[k] * r);
    }
    // K / V chunk into smem
    {
      const bf16* kb = c.kc + (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)j0 * HD;
      const bf16* vb = c.vc + (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)j0 * HD;
      for (int i = tid; i < nj * 16; i += NTH) {
        reinterpret_cast<uint4*>(&at.kk[0][0])[i] = __ldcg(reinterpret_cast<const uint4*>(kb) + i);
        reinterpret_cast<uint4*>(&at.vv[0][0])[i] = __ldcg(reinterpret_cast<const uint4*>(vb) + i);
      }
    }
    __syncthreads();
    if (j1 == t + 1) {
      // current position: from the values computed above; write the cache and the conv history
      if (tid < HD) {
        at.kk[nj - 1][tid] = tobf(at.kt[tid]);
        at.vv[nj - 1][tid] = tobf(at.vt[tid]);
        const long co = (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)t * HD + tid;
        c.kc[co] = tobf(at.kt[tid]);
        c.vc[co] = tobf(at.vt[tid]);
        const long hrow = ((long)ap.slot * MAXB + b) * 3 * 1024 + (t % 3) * 1024 + g * HD + tid;
        c.hk[hrow] = tobf(ldcg_f(qr + K0 + g * HD + tid));
        c.hv[hrow] = tobf(ldcg_f(qr + V0 + g * HD + tid));
      }
      __syncthreads();
    }
    // relative bias for the chunk: bias[h][jj] = rel[h][t - j] (0 beyond 1023)
    for (int i = tid; i < 3 * nj; i += NTH) {
      const int hh = i / nj, jj = i % nj, dist = t - (j0 + jj);
      float bsum = 0.f;
      if (dist < 1024) {
#pragma unroll
        for (int r = 0; r < 16; r++) bsum += at.rr[hh][r] * bf(L.relp[r * 1024 + dist]);
        bsum = rbf(bsum);
      }
      at.bias[hh][jj] = bsum;
    }
    // scores: warp per key, lanes over dims
    for (int jj = w; jj < nj; jj += NWARP) {
      float kf[4];
      {
        const uint2 kw = *reinterpret_cast<const uint2*>(&at.kk[jj][lane * 4]);
        const bf16* kp = reinterpret_cast<const bf16*>(&kw);
#pragma unroll
        for (int k = 0; k < 4; k++) kf[k] = bf(kp[k]);
      }
#pragma unroll
      for (int hh = 0; hh < 3; hh++) {
        float s = 0.f;
#pragma unroll
        for (int k = 0; k < 4; k++) s += at.q[hh][lane * 4 + k] * kf[k];
#pragma unroll
        for (int o = 16; o; o >>= 1) s += __shfl_xor_sync(0xffffffff, s, o);
        if (lane == 0) at.sc[hh][jj] = s;
      }
    }
    __syncthreads();
    if (w < 3) {
      float m = -1e30f;
      for (int jj = lane; jj < nj; jj += 32) {
        const float s = at.sc[w][jj] * 0.08838834764831845f + at.bias[w][jj];
        at.sc[w][jj] = s;
        m = fmaxf(m, s);
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float l = 0.f;
      for (int jj = lane; jj < nj; jj += 32) {
        const float e = expf(at.sc[w][jj] - m);
        at.sc[w][jj] = e;
        l += e;
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffff, l, o);
      if (lane == 0) { at.ml[w][0] = m; at.ml[w][1] = l; }
    }
    __syncthreads();
    float* rec = c.arec + ((long)(b * NQH + 3 * g) * MAXCH + ch) * 130;
    if (tid < 3 * HD) {
      const int hh = tid / HD, d = tid % HD;
      float o = 0.f;
      for (int jj = 0; jj < nj; jj++) o += at.sc[hh][jj] * bf(at.vv[jj][d]);
      rec[(long)hh * MAXCH * 130 + 2 + d] = o;
      if (d == 0) { rec[(long)hh * MAXCH * 130] = at.ml[hh][0]; rec[(long)hh * MAXCH * 130 + 1] = at.ml[hh][1]; }
    }
    __threadfence();
    __syncthreads();
    if (tid == 0) {
      const unsigned old = atomicAdd(c.cnt + CN_ATT + b * NKV + g, 1u);
      sm.flag = (old == (unsigned)(nch - 1));
    }
    __syncthreads();
    if (sm.flag) {
      __threadfence();
      if (tid < 3 * HD) {
        const int hh = tid / HD, d = tid % HD, h = 3 * g + hh;
        const float* r0 = c.arec + ((long)(b * NQH + h) * MAXCH) * 130;
        float M = -1e30f;
        for (int k = 0; k < nch; k++) M = fmaxf(M, ldcg_f(r0 + k * 130));
        float S = 0.f, O = 0.f;
        for (int k = 0; k < nch; k++) {
          const float e = expf(ldcg_f(r0 + k * 130) - M);
          S += ldcg_f(r0 + k * 130 + 1) * e;
          O += ldcg_f(r0 + k * 130 + 2 + d) * e;
        }
        const float lse = M + logf(S);
        const float gate = ldcg_f(qr + R_G + h * HD + d);
        const float sink = ldcg_f(qr + R_S + h);
        const float out = (O / S) * sigm(gate) * sigm(lse - sink);
        c.aout[(long)b * QW + h * HD + d] = tobf(out);
      }
      if (tid == 0) atomicExch(c.cnt + CN_ATT + b * NKV + g, 0u);
    }
    __syncthreads();
  }
}

// o_proj + epilogue: attn_raw -> sconv -> attn_s
__device__ void ph_oproj(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = hd.B, t = hd.pos;
  for (int i = threadIdx.x; i < B * QW / 2; i += NTH) {
    const int b = i / (QW / 2), k = (i % (QW / 2)) * 2;
    *reinterpret_cast<uint32_t*>(&sm.u.xo[b][k]) = ldcg_u32(c.aout + (long)b * QW + k);
  }
  __syncthreads();
  const int N = 144 * O_NP;
  const int w = threadIdx.x >> 5, lane = lane_id();
  for (int it = blockIdx.x + gridDim.x * w; it < N; it += gridDim.x * NWARP) {
    const int strip = it / O_NP, piece = it % O_NP;
    BSm bl{&sm.u.xo[0][0], QWP, B};
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    piece_bf16(L.wo + (long)strip * 48 * 2048, piece * O_PU, O_PU, bl, acc);
    if (piece_reduce(c.part + (long)strip * O_NP * 128, c.cnt + CN_O + strip, piece, O_NP, acc)) {
      const int g = lane >> 2, tt = lane & 3;
      for (int h = 0; h < 2; h++)
        for (int cc = 0; cc < 2; cc++) {
          const int tok = 2 * tt + cc;
          if (tok >= B) continue;
          const int row = strip * 16 + g + 8 * h;
          const float x = rbf(acc[2 * h + cc]);
          const bf16* hb = c.ha + ((long)ap.slot * MAXB + tok) * 3 * H + row;
          const float y = rbf(sconv_static(x, hb, H, t, L.attn_sc + row * 4));
          c.ha[((long)ap.slot * MAXB + tok) * 3 * H + (t % 3) * H + row] = tobf(x);
          c.attn_s[(long)tok * H + row] = tobf(y);
        }
    }
  }
}

// mlp input (mix [+ gate]) -> router input xr (bf16) + expert input x16 (f16 hi / lo); router GEMV
__device__ void ph_mlp_in_x(PH_ARGS, int a, float (*xin)[EPT], int b) {
  // xin: the (gated) mlp input of token b (f32) -> norms into smem
  const LayerW& L = c.L[c.A[a].layer];
  float s[1] = {0.f};
#pragma unroll
  for (int k = 0; k < EPT; k++) s[0] += xin[0][k] * xin[0][k];
  block_sum<1>(s, sm);
  const float r = rsqrtf(s[0] / (float)H + 1e-6f);
  float y[EPT], mx = 0.f;
#pragma unroll
  for (int k = 0; k < EPT; k++) {
    const int el = threadIdx.x + k * NTH;
    const bf16 yb = tobf(xin[0][k] * r * bf(L.mlp_norm[el]));
    sm.u.e.xr[b][el] = yb;
    y[k] = bf(yb);
    mx = fmaxf(mx, fabsf(y[k]));
  }
  mx = block_max1(mx, sm);
  int e2 = 0;
  frexpf(mx, &e2);                      // mx in [2^(e2-1), 2^e2)
  const int sh = (mx > 0.f) ? 15 - e2 : 0;
  const float scl = ldexpf(1.0f, sh);
#pragma unroll
  for (int k = 0; k < EPT; k++) {
    const int el = threadIdx.x + k * NTH;
    const float v = y[k] * scl;
    const __half hi = __float2half_rn(v);
    const __half lo = __float2half_rn((v - __half2float(hi)) * 16777216.0f);
    sm.u.e.x16[b][0][el] = hi;
    sm.u.e.x16[b][1][el] = lo;
  }
  if (threadIdx.x == 0) sm.sc16[b] = ldexpf(1.0f, -sh);
}

__device__ void ph_router(PH_ARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = hd.B;
  const int N = 8 * RT_NP;
  const int w = threadIdx.x >> 5, lane = lane_id();
  for (int it = blockIdx.x + gridDim.x * w; it < N; it += gridDim.x * NWARP) {
    const int strip = it / RT_NP, piece = it % RT_NP;
    BSm bl{&sm.u.e.xr[0][0], HP, B};
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    piece_bf16(L.wr + (long)strip * 36 * 2048, piece * RT_PU, RT_PU, bl, acc);
    if (piece_reduce(c.part + (long)strip * RT_NP * 128, c.cnt + CN_RT + strip, piece, RT_NP, acc)) {
      const int g = lane >> 2, t = lane & 3;
      for (int h = 0; h < 2; h++)
        for (int cc = 0; cc < 2; cc++) {
          const int tok = 2 * t + cc;
          if (tok < B) c.rlog[tok * NE + strip * 16 + g + 8 * h] = acc[2 * h + cc];
        }
    }
  }
}

// mlp mix of application a, token b -> x (f32)
__device__ void mlp_mix(const Ctx& c, Smem& sm, int a, int b, float (*x)[EPT]) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  float v[6][EPT];
  int ns = 0;
  if (a == 0) {
    load_src(c, 0, b, v[0]); ns = 1;      // blocks [h0], partial = attn_s
  } else {
    for (int s = 0; s < ap.nblk; s++) load_src(c, ap.blk[s], b, v[s]);
    ns = ap.nblk;
    if (ap.bnd) { load_src(c, ap.pin, b, v[ns]); ns++; }
  }
  // the partial
  {
    float as[EPT];
#pragma unroll
    for (int k = 0; k < EPT; k++) as[k] = ldcg_bf(c.attn_s + (long)b * H + threadIdx.x + k * NTH);
    if (a == 0 || ap.bnd) {
#pragma unroll
      for (int k = 0; k < EPT; k++) v[ns][k] = as[k];
    } else {
      float p[EPT];
      load_src(c, ap.pin, b, p);
#pragma unroll
      for (int k = 0; k < EPT; k++) v[ns][k] = p[k] + as[k];
    }
    ns++;
  }
  const float* qs[1] = {L.mq};
  depth_mix<6, 1>(v, ns, qs, 1, x, sm);
}

__device__ int ph_mlp_in(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const int B = hd.B;
  if (ap.nmsg == 0) {
    for (int b = 0; b < B; b++) {
      float x[1][EPT];
      mlp_mix(c, sm, a, b, x);
      ph_mlp_in_x(c, hd, sm, nbar, base, a, x, b);
    }
    __syncthreads();
    return 0;
  }
  if (blockIdx.x == 0) {
    for (int b = 0; b < B; b++) {
      float x[1][EPT], m[1][EPT], ms[2][EPT];
      mlp_mix(c, sm, a, b, x);
      load_src(c, ap.msg[0], b, ms[0]);
      load_src(c, ap.msg[1], b, ms[1]);
      const float* lq = c.loopq + (long)ap.loopl * 4 * H + 3 * H;
      const float* mq[1] = {lq};
      depth_mix<2, 1>(ms, 2, mq, 1, m, sm);
      float s[2] = {0.f, 0.f};
#pragma unroll
      for (int k = 0; k < EPT; k++) { s[0] += x[0][k] * x[0][k]; s[1] += m[0][k] * m[0][k]; }
      block_sum<2>(s, sm);
      const float rx = rsqrtf(s[0] / (float)H + 1e-6f), rm = rsqrtf(s[1] / (float)H + 1e-6f);
#pragma unroll
      for (int k = 0; k < EPT; k++) {
        const int el = threadIdx.x + k * NTH;
        c.xg[((long)b * 4 + 3) * H + el] = x[0][k];
        c.mg[((long)b * 4 + 3) * H + el] = m[0][k];
        c.ub[((long)b * 4 + 3) * 2 * H + el] = tobf(x[0][k] * rx);
        c.ub[((long)b * 4 + 3) * 2 * H + H + el] = tobf(m[0][k] * rm);
      }
    }
  }
  return -1;
}

// top-8 + union (every block, identical)
__device__ void routing(const Ctx& c, const Hdr& hd, Smem& sm, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = hd.B;
  const int w = threadIdx.x >> 5, lane = lane_id();
  if (w < B) {
    float lg[4], sel[4];
#pragma unroll
    for (int k = 0; k < 4; k++) {
      const int e = lane + 32 * k;
      lg[k] = ldcg_f(c.rlog + w * NE + e);
      sel[k] = sigm(lg[k]) + L.rbias[e];
    }
    int ids[TOPK]; float ws[TOPK];
    unsigned taken = 0;
    for (int r = 0; r < TOPK; r++) {
      float bv = -1e30f; int bi = 1 << 30;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        if (taken & (1u << k)) continue;
        const int e = lane + 32 * k;
        if (sel[k] > bv || (sel[k] == bv && e < bi)) { bv = sel[k]; bi = e; }
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) {
        const float ov = __shfl_xor_sync(0xffffffff, bv, o);
        const int oi = __shfl_xor_sync(0xffffffff, bi, o);
        if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
      }
      ids[r] = bi;
      if ((bi & 31) == lane) taken |= 1u << (bi >> 5);
    }
    // weights: sigmoid(logit) / sum * 8 (in rank order); then sort the 8 by expert id
    float sg[TOPK], den = 0.f;
    for (int r = 0; r < TOPK; r++) {
      const float l = __shfl_sync(0xffffffff, lg[ids[r] >> 5], ids[r] & 31);
      sg[r] = sigm(l);
      den += sg[r];
    }
    for (int r = 0; r < TOPK; r++) ws[r] = sg[r] / den * 8.0f;
    // insertion sort by id
    for (int i = 1; i < TOPK; i++)
      for (int j = i; j > 0 && ids[j - 1] > ids[j]; j--) {
        int ti = ids[j]; ids[j] = ids[j - 1]; ids[j - 1] = ti;
        float tw = ws[j]; ws[j] = ws[j - 1]; ws[j - 1] = tw;
      }
    if (lane == 0)
      for (int r = 0; r < TOPK; r++) { sm.tex[w][r] = ids[r]; sm.twt[w][r] = ws[r]; }
  }
  __syncthreads();
  if (threadIdx.x == 0) {
    unsigned msk[4] = {0, 0, 0, 0};
    for (int b = 0; b < B; b++)
      for (int r = 0; r < TOPK; r++) msk[sm.tex[b][r] >> 5] |= 1u << (sm.tex[b][r] & 31);
    int n = 0;
    for (int e = 0; e < NE; e++)
      if (msk[e >> 5] >> (e & 31) & 1) { sm.uexp[n] = e; sm.uncnt[n] = 0; n++; }
    sm.nU = n;
    for (int b = 0; b < B; b++)
      for (int r = 0; r < TOPK; r++) {
        const int e = sm.tex[b][r];
        int u = 0;
        while (sm.uexp[u] != e) u++;
        sm.tslot[b][r] = u;
        sm.utok[u][sm.uncnt[u]++] = b;
      }
  }
  __syncthreads();
}

__device__ __forceinline__ float act_fn(float g, float u) {
  float a = 4.0f * tanhf(g / 4.0f) * sigm(g);
  return a * (25.0f * tanhf(u / 25.0f));
}

// w13: items (union slot, strip of 16 rows = 8 (gate, up) pairs, piece); the last piece computes act -> act16
__device__ void ph_w13(PH_ARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = hd.B;
  const int np = L.mx ? 6 : 3, pu = L.mx ? 6 : 12;
  const int nU = sm.nU;
  const int N = nU * 144 * np;
  const int w = threadIdx.x >> 5, lane = lane_id(), g = lane >> 2, t = lane & 3;
  for (int it = blockIdx.x + gridDim.x * w; it < N; it += gridDim.x * NWARP) {
    const int piece = it % np, strip = (it / np) % 144, u = it / (np * 144);
    const int e = sm.uexp[u], nt = sm.uncnt[u];
    const int NGN = nt > 4 ? 2 : 1;
    float acc[2][4];
#pragma unroll
    for (int ng = 0; ng < 2; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
    const __half* colp[2];
#pragma unroll
    for (int ng = 0; ng < 2; ng++) {
      const int li = 4 * ng + (g >> 1), part = g & 1;
      colp[ng] = li < nt ? &sm.u.e.x16[sm.utok[u][li]][part][0] : nullptr;
    }
    if (!L.mx) {
      const uint8_t* wst = L.w13 + ((long)e * 144 + strip) * 36 * 576;
      if (NGN == 1) piece_fp4<1, false>(wst, piece * pu, pu, colp, acc); else piece_fp4<2, false>(wst, piece * pu, pu, colp, acc);
    } else {
      const uint8_t* wst = L.w13 + ((long)e * 144 + strip) * 36 * 1056;
      if (NGN == 1) piece_fp8<1, false>(wst, piece * pu, pu, colp, acc); else piece_fp8<2, false>(wst, piece * pu, pu, colp, acc);
    }
    // write both n-group pieces, then one counter arrival
    float4* slot = reinterpret_cast<float4*>(c.part) + (((long)u * 144 + strip) * 2) * 6 * 32;
    slot[piece * 32 + lane] = make_float4(acc[0][0], acc[0][1], acc[0][2], acc[0][3]);
    if (NGN == 2) slot[(6 + piece) * 32 + lane] = make_float4(acc[1][0], acc[1][1], acc[1][2], acc[1][3]);
    __threadfence();
    __syncwarp();
    unsigned old = 0;
    if (lane == 0) old = atomicAdd(c.cnt + CN_W13 + u * 144 + strip, 1u);
    old = __shfl_sync(0xffffffff, old, 0);
    if (old != (unsigned)(np - 1)) continue;
    __threadfence();
    if (lane == 0) atomicExch(c.cnt + CN_W13 + u * 144 + strip, 0u);
    const float fac = L.mx ? 1.0f : L.f13[e];
    for (int ng = 0; ng < NGN; ng++) {
      float a0 = 0.f, a1 = 0.f, a2 = 0.f, a3 = 0.f;
      for (int p = 0; p < np; p++) {
        const float4 v = ldcg_f4(slot + (ng * 6 + p) * 32 + lane);
        a0 += v.x; a1 += v.y; a2 += v.z; a3 += v.w;
      }
      // lane (g, t): rows g, g+8 of token li = 4 ng + t: (hi, lo) = (a0, a1) row g; (a2, a3) row g+8
      const int li = 4 * ng + t;
      const bool ok = li < nt;
      const int tok = ok ? sm.utok[u][li] : 0;
      const float s16 = sm.sc16[tok];
      const float h0 = rbf((a0 + a1 * 5.9604644775390625e-08f) * s16 * fac);
      const float h1 = rbf((a2 + a3 * 5.9604644775390625e-08f) * s16 * fac);
      // pair i: rows 2i (gate), 2i+1 (up): row r held by lane group g = r % 8, half r / 8
      // h0 is row g, h1 is row g + 8. gate rows even, up rows odd -> partner lane g ^ 1 (lane ^ 4)
      const float o0 = __shfl_xor_sync(0xffffffff, h0, 4), o1 = __shfl_xor_sync(0xffffffff, h1, 4);
      if (ok && (g & 1) == 0) {
        // pairs: (row g, row g+1) -> pair index strip*8 + g/2 ; (row g+8, g+9) -> strip*8 + 4 + g/2
        float wgt = 0.f;
        for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) wgt = sm.twt[tok][r];
        const float act0 = rbf(act_fn(h0, o0) * wgt), act1 = rbf(act_fn(h1, o1) * wgt);
        __half* dst = c.act16 + (((long)u * MAXB + li) * 2) * IE;
        const int i0 = strip * 8 + (g >> 1), i1 = strip * 8 + 4 + (g >> 1);
        const float v0 = act0 * 16.0f, v1 = act1 * 16.0f;
        const __half hi0 = __float2half_rn(v0), hi1 = __float2half_rn(v1);
        dst[i0] = hi0; dst[IE + i0] = __float2half_rn((v0 - __half2float(hi0)) * 16777216.0f);
        dst[i1] = hi1; dst[IE + i1] = __float2half_rn((v1 - __half2float(hi1)) * 16777216.0f);
      }
    }
  }
}

// w2: items (union slot, strip of 16 output rows, piece); per (token, strip) counter over 8 experts x pieces
__device__ void ph_w2(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = hd.B, t = hd.pos;
  const int np = L.mx ? 3 : 2, pu = L.mx ? 6 : 9;
  const int nU = sm.nU;
  const int N = nU * 144 * np;
  const int w = threadIdx.x >> 5, lane = lane_id(), g = lane >> 2, tt = lane & 3;
  for (int it = blockIdx.x + gridDim.x * w; it < N; it += gridDim.x * NWARP) {
    const int piece = it % np, strip = (it / np) % 144, u = it / (np * 144);
    const int e = sm.uexp[u], nt = sm.uncnt[u];
    const int NGN = nt > 4 ? 2 : 1;
    float acc[2][4];
#pragma unroll
    for (int ng = 0; ng < 2; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
    const __half* colp[2];
#pragma unroll
    for (int ng = 0; ng < 2; ng++) {
      const int li = 4 * ng + (g >> 1), part = g & 1;
      colp[ng] = li < nt ? c.act16 + (((long)u * MAXB + li) * 2 + part) * IE : nullptr;
    }
    if (!L.mx) {
      const uint8_t* wst = L.w2 + ((long)e * 144 + strip) * 18 * 576;
      if (NGN == 1) piece_fp4<1, true>(wst, piece * pu, pu, colp, acc); else piece_fp4<2, true>(wst, piece * pu, pu, colp, acc);
    } else {
      const uint8_t* wst = L.w2 + ((long)e * 144 + strip) * 18 * 1056;
      if (NGN == 1) piece_fp8<1, true>(wst, piece * pu, pu, colp, acc); else piece_fp8<2, true>(wst, piece * pu, pu, colp, acc);
    }
    const float fac = (L.mx ? 1.0f : L.f2[e]) * 0.0625f;
    // per token of this expert: value = (hi + lo 2^-24) * fac for rows g, g+8 -> w2p[tok][k][piece][strip][16]
    for (int ng = 0; ng < NGN; ng++) {
      const int li = 4 * ng + tt;
      const bool ok = li < nt;
      const int tok = ok ? sm.utok[u][li] : 0;
      int k = 0;
      if (ok) for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) k = r;
      const float v0 = (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * fac;
      const float v1 = (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * fac;
      if (ok) {
        float* dst = c.w2p + ((((long)tok * TOPK + k) * 3 + piece) * 144 + strip) * 16;
        dst[g] = v0; dst[g + 8] = v1;
      }
    }
    __threadfence();
    __syncwarp();
    // arrivals: one per token of this expert
    const int need = TOPK * np;
    for (int li = 0; li < nt; li++) {
      const int tok = sm.utok[u][li];
      unsigned old = 0;
      if (lane == 0) old = atomicAdd(c.cnt + CN_W2 + tok * 144 + strip, 1u);
      old = __shfl_sync(0xffffffff, old, 0);
      if (old != (unsigned)(need - 1)) continue;
      __threadfence();
      if (lane == 0) atomicExch(c.cnt + CN_W2 + tok * 144 + strip, 0u);
      if (lane < 16) {
        const int row = strip * 16 + lane;
        float s = 0.f;
        for (int k = 0; k < TOPK; k++) {
          float sk = 0.f;
          for (int p = 0; p < np; p++) sk += ldcg_f(c.w2p + ((((long)tok * TOPK + k) * 3 + p) * 144 + strip) * 16 + lane);
          s += sk;
        }
        const float x = rbf(s);
        const bf16* hb = c.hm + ((long)ap.slot * MAXB + tok) * 3 * H + row;
        const float ms = rbf(sconv_static(x, hb, H, t, L.mlp_sc + row * 4));
        c.hm[((long)ap.slot * MAXB + tok) * 3 * H + (t % 3) * H + row] = tobf(x);
        const float as = ldcg_bf(c.attn_s + (long)tok * H + row);
        float np_;
        if (a == 0 || ap.bnd) np_ = as + ms;
        else np_ = (ldcg_bf(c.pbuf + ((long)ap.pin * MAXB + tok) * H + row) + as) + ms;
        c.pbuf[((long)ap.out * MAXB + tok) * H + row] = tobf(np_);
      }
    }
  }
}

// final: output mix -> norm -> unembed -> logits, argmax
__device__ void ph_final(PH_ARGS) {
  const int B = hd.B;
  for (int b = 0; b < B; b++) {
    float v[5][EPT], x[1][EPT];
    for (int s = 0; s < c.nfin; s++) load_src(c, c.fin[s], b, v[s]);
    load_src(c, c.fin_pin, b, v[c.nfin]);
    const float* qs[1] = {c.oq};
    depth_mix<5, 1>(v, c.nfin + 1, qs, 1, x, sm);
    rmsnorm_store(x[0], c.fnorm, &sm.u.xs[0][b][0], sm);
  }
  __syncthreads();
  const int w = threadIdx.x >> 5, lane = lane_id(), g = lane >> 2, t = lane & 3;
  unsigned long long best[2] = {0ull, 0ull};
  for (int it = blockIdx.x + gridDim.x * w; it < UN_STRIPS; it += gridDim.x * NWARP) {
    BSm bl{&sm.u.xs[0][0][0], HP, B};
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    piece_bf16(c.unembed + (long)it * 36 * 2048, 0, 36, bl, acc);
    for (int h = 0; h < 2; h++) {
      const int row = it * 16 + g + 8 * h;
      for (int cc = 0; cc < 2; cc++) {
        const int tok = 2 * t + cc;
        if (tok >= B || row >= VOCAB_REAL) continue;
        const float z = 30.0f * tanhf(acc[2 * h + cc] / 30.0f);
        if (hd.logits) hd.logits[(long)tok * VOCAB_REAL + row] = z;
        unsigned u = __float_as_uint(z);
        u = (u & 0x80000000u) ? ~u : (u | 0x80000000u);
        const unsigned long long key = ((unsigned long long)u << 32) | (unsigned)(0xFFFFFFFFu - row);
        if (key > best[cc]) best[cc] = key;
      }
    }
  }
  // per token: max over the warp's lanes holding that token (lanes with t = tok / 2), then one atomic
  for (int cc = 0; cc < 2; cc++) {
    unsigned long long k = best[cc];
#pragma unroll
    for (int o = 4; o < 32; o <<= 1) { const unsigned long long ok = __shfl_xor_sync(0xffffffff, k, o); if (ok > k) k = ok; }
    const int tok = 2 * t + cc;
    if (g == 0 && tok < B && k) atomicMax(c.amax + tok, k);
  }
}

// ------------------------------------------------------------------------------------------------ kernel
extern "C" __global__ void __launch_bounds__(NTH, 1) mk_step(const Ctx* __restrict__ cp, Hdr hd) {
  extern __shared__ __align__(16) unsigned char smraw[];
  Smem& sm = *reinterpret_cast<Smem*>(smraw);
  const Ctx& c = *cp;
  unsigned nbar = 0;
  const unsigned base = c.bar[1];
  for (int a = 0; a < NAPP; a++) {
    const App& ap = c.A[a];
    int ns = ph_attn_in(c, hd, sm, nbar, base, a);
    if (ns < 0) {
      grid_bar(c, nbar, base);
      ph_gate_d(c, hd, sm, nbar, base, a, 0, 3);
      grid_bar(c, nbar, base);
      ph_gate_fg(c, hd, sm, nbar, base, a, 0, 3);
      grid_bar(c, nbar, base);
      const LayerW& L = c.L[ap.layer];
      for (int b = 0; b < hd.B; b++)
        for (int q = 0; q < 3; q++) {
          float x[EPT];
#pragma unroll
          for (int k = 0; k < EPT; k++) x[k] = ldcg_f(c.xp + ((long)b * 4 + q) * H + threadIdx.x + k * NTH);
          rmsnorm_store(x, L.norm[L.glob ? q : 0], &sm.u.xs[q][b][0], sm);
        }
      __syncthreads();
      ns = 3;
    }
    ph_qkv(c, hd, sm, nbar, base, a, ns);
    grid_bar(c, nbar, base);
    ph_attn(c, hd, sm, nbar, base, a);
    grid_bar(c, nbar, base);
    ph_oproj(c, hd, sm, nbar, base, a);
    grid_bar(c, nbar, base);
    int r = ph_mlp_in(c, hd, sm, nbar, base, a);
    if (r < 0) {
      grid_bar(c, nbar, base);
      ph_gate_d(c, hd, sm, nbar, base, a, 3, 1);
      grid_bar(c, nbar, base);
      ph_gate_fg(c, hd, sm, nbar, base, a, 3, 1);
      grid_bar(c, nbar, base);
      for (int b = 0; b < hd.B; b++) {
        float x[1][EPT];
#pragma unroll
        for (int k = 0; k < EPT; k++) x[0][k] = ldcg_f(c.xp + ((long)b * 4 + 3) * H + threadIdx.x + k * NTH);
        ph_mlp_in_x(c, hd, sm, nbar, base, a, x, b);
      }
      __syncthreads();
    }
    ph_router(c, hd, sm, nbar, base, a);
    grid_bar(c, nbar, base);
    routing(c, hd, sm, a);
    ph_w13(c, hd, sm, nbar, base, a);
    grid_bar(c, nbar, base);
    ph_w2(c, hd, sm, nbar, base, a);
    grid_bar(c, nbar, base);
  }
  ph_final(c, hd, sm, nbar, base);
  grid_bar(c, nbar, base);
  if (blockIdx.x == 0) {
    if (threadIdx.x < hd.B) {
      const unsigned long long k = c.amax[threadIdx.x];
      const int tok = (int)(0xFFFFFFFFu - (unsigned)(k & 0xFFFFFFFFu));
      c.next_tok[threadIdx.x] = tok;
      if (hd.out_tok) hd.out_tok[threadIdx.x] = tok + 1;   // 0 = not yet written (host polls)
      c.amax[threadIdx.x] = 0ull;
    }
    if (threadIdx.x == 0) c.bar[1] = base + nbar * gridDim.x;
  }
}

// ------------------------------------------------------------------------------------------------ host API
extern "C" {
int mk_ctx_bytes() { return (int)sizeof(Ctx); }
int mk_layer_bytes() { return (int)sizeof(LayerW); }
int mk_app_bytes() { return (int)sizeof(App); }
int mk_hdr_bytes() { return (int)sizeof(Hdr); }
int mk_smem_bytes() { return (int)sizeof(Smem); }
int mk_nth() { return NTH; }
int mk_cn_total() { return CN_TOTAL; }
int mk_setup() {
  cudaError_t e = cudaFuncSetAttribute(mk_step, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)sizeof(Smem));
  if (e != cudaSuccess) { fprintf(stderr, "mk_setup: %s\n", cudaGetErrorString(e)); return 1; }
  int nb = 0;
  cudaOccupancyMaxActiveBlocksPerMultiprocessor(&nb, mk_step, NTH, sizeof(Smem));
  if (nb < 1) { fprintf(stderr, "mk_setup: occupancy %d\n", nb); return 2; }
  return 0;
}
int mk_launch(const void* ctx_dev, const Hdr* hd, int nblk, void* stream) {
  Hdr h = *hd;
  void* args[] = {(void*)&ctx_dev, (void*)&h};
  cudaError_t e = cudaLaunchCooperativeKernel((const void*)mk_step, dim3(nblk), dim3(NTH), args, sizeof(Smem), (cudaStream_t)stream);
  if (e != cudaSuccess) { fprintf(stderr, "mk_launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}
void* mk_host_alloc(size_t n) { void* p = nullptr; if (cudaHostAlloc(&p, n, cudaHostAllocMapped) != cudaSuccess) return nullptr; memset(p, 0, n); return p; }
}
