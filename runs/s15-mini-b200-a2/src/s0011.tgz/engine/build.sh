#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
rm -f build/${MK_LIBNAME:-libmk.so}
TRACKV=${MK_TRACK:-$(cat TRACK 2>/dev/null || echo A)}
FLAGS=""
if echo "$TRACKV" | grep -qw W12; then FLAGS="-DW12"; fi
nvcc -O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xcompiler -fPIC -shared -Xptxas -v $FLAGS ${MK_CFLAGS:-} \
  -o build/${MK_LIBNAME:-libmk.so} mk.cu 2> build/ptxas.log || { cat build/ptxas.log; exit 1; }
grep -E "mk_step|registers|spill" build/ptxas.log | head -8 || true
