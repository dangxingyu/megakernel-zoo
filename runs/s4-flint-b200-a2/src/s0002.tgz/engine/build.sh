#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
# Track switch: engine/TRACK holds "A" or "B" (default A). MK_TRACK overrides it.
set -euo pipefail
cd "$(dirname "$0")"
TRACK="${MK_TRACK:-$(cat TRACK 2>/dev/null || echo A)}"
mkdir -p build
FLAGS="-O3 -std=c++17 -arch=sm_100 -shared -Xcompiler -fPIC"
if [ "$TRACK" = "B" ]; then FLAGS="$FLAGS -DTRACK_B"; fi
SRC_HASH=$(cat mk.cu build.sh TRACK 2>/dev/null | sha1sum | cut -c1-16)-$TRACK
if [ ! -f build/libmk.so ] || [ "$(cat build/hash 2>/dev/null)" != "$SRC_HASH" ]; then
  nvcc $FLAGS --resource-usage -o build/libmk.so mk.cu
  echo "$SRC_HASH" > build/hash
fi
echo "built track $TRACK"
