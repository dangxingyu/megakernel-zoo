// Flint megakernel: one persistent kernel per decode step (or per generate() call) on one B200.
//
// All 152 SMs run one block each. Blocks 0..127 ("main") stream the weights; blocks 128..151 ("aux") do the router.
// Every matrix-vector product is a chain of tensor-core mma.m16n8k16 (bf16 x bf16 -> f32) over weights that were
// re-laid at load time into "tiles": 16 rows x 16 columns = 512 bytes in exactly the register order of the mma A
// operand, so one 16-byte load per thread feeds one mma. The 8 columns of the B operand are the (up to 8) sequences
// of the batch. Phases are separated by a grid-wide barrier (one atomic counter).
//
// Track A (default): the number formats of the Hugging Face BF16 path (BF16 activations, float32 norms / router /
// attention scores), every rounding point reproduced.  -DTRACK_B switches model-specific lossless changes on.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#define HID 2048
#define NLAYER 49
#define NKV 4
#define NEXP 256
#define TOPK 6
#define VOCAB 150144
#define NMAIN 128
#define NAUXR 16
#define NBLK 152
#define MAXB 8
#define MAXU 48
#define RMS_EPS 1e-6f

struct LayerP {
    const uint4 *qkv, *o, *dgu, *ddown, *router, *sgu, *sdown, *egu, *edown;
    uint4 *kc, *vc;
    const float *ln1, *ln2, *qn, *kn, *sinks;
    int sliding, moe;
};

struct Params {
    LayerP L[NLAYER];
    const u16* embed;
    const uint4* head;
    const float* fnorm;
    const float *cosT, *sinT;
    int maxctx, kgmax;
    // scratch (allocated by mk_create)
    float* x;            // [MAXB][HID] residual stream
    float* xss;          // [NMAIN][MAXB] partial sums of squares of x (rows of each main block)
    float4* qkvp;        // [640 half row-groups][32 lanes] raw partial sums of q, k, v
    u16* attnf;          // attention output as B fragments: 256 chunks x 256 B
    float* rl;           // [MAXB][NEXP] router logits
    int* units;          // [0] = number of units, [1..48] expert id of unit u
    float* uw;           // [MAXU][MAXB] routing weight of unit u for sequence b (0 = not a member)
    u16* hsh;            // shared expert hidden as B fragments: 64 chunks x 256 B
    u16* hx;             // expert hidden: [MAXU][32 chunks][256 B]; dense MLP hidden: 384 chunks
    float* argv;         // [NBLK][MAXB]
    int* argi;           // [NBLK][MAXB]
    long long* curtok;   // [MAXB]
    unsigned* ctr;       // grid barrier counter
    unsigned* actr;      // aux barrier counter
    float* dbg;          // [NLAYER+1][MAXB][HID] or null
};

// ------------------------------------------------------------------------------------------------ small helpers
__device__ __forceinline__ float rb(float f) {       // round to nearest-even BF16, result as float
    u32 u = __float_as_uint(f);
    u += 0x7FFFu + ((u >> 16) & 1u);
    return __uint_as_float(u & 0xFFFF0000u);
}
__device__ __forceinline__ u16 fbits(float f) {      // BF16 bits of f rounded to nearest even
    u32 u = __float_as_uint(f);
    u += 0x7FFFu + ((u >> 16) & 1u);
    return (u16)(u >> 16);
}
__device__ __forceinline__ float b2f(u16 b) { return __uint_as_float(((u32)b) << 16); }
__device__ __forceinline__ float silu(float x) { return x / (1.0f + __expf(-x)); }

__device__ __forceinline__ void mma(float4& c, const uint4& a, const uint2& b) {
    asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
                 : "+f"(c.x), "+f"(c.y), "+f"(c.z), "+f"(c.w)
                 : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y));
}
__device__ __forceinline__ float4 f4add(float4 a, float4 b) { return make_float4(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w); }
__device__ __forceinline__ float cget(const float4& c, int i) { return i == 0 ? c.x : i == 1 ? c.y : i == 2 ? c.z : c.w; }

// u16 index of element (k within chunk, column n) inside a 256-byte B-fragment chunk
__device__ __forceinline__ int bidx(int kk, int n) { return (((n * 4 + ((kk & 7) >> 1)) * 2 + (kk >> 3)) * 2) + (kk & 1); }
// u16 index of element (row m, col k) inside a 512-byte A tile
__device__ __forceinline__ int aidx(int m, int k) { return ((((m & 7) * 4 + ((k & 7) >> 1)) * 4 + (m >> 3) + 2 * (k >> 3)) * 2) + (k & 1); }

__device__ __forceinline__ float warp_sum(float v) {
    for (int o = 16; o > 0; o >>= 1) v += __shfl_xor_sync(0xffffffffu, v, o);
    return v;
}


// flags (profiling / debugging): 1 = __threadfence before every barrier, 2 = skip attention, 4 = skip weight loads and mma,
// 64 = barriers do not wait
__device__ __forceinline__ void barrier(const Params* P, unsigned& bar, int flags) {
    if (!(flags & 1)) __threadfence();
    __syncthreads();
    bar += NBLK;
    if (threadIdx.x == 0 && !(flags & 64)) {
        atomicAdd(P->ctr, 1u);
        volatile unsigned* c = P->ctr;
        while ((int)(*c - bar) < 0) {}
    }
    __syncthreads();
}

template <int N> __device__ __forceinline__ void tload(uint4* T, const uint4* p, int flags) {
    if (flags & 4) return;
#pragma unroll
    for (int i = 0; i < N; i++) T[i] = p[i * 32];
}
// N tiles from registers, B fragments bf[i*32] (bf already offset by chunk and lane); bact = false: zero fragment
template <int N> __device__ __forceinline__ void tmma(float4& c, const uint4* T, const uint2* bf, bool bact, int flags) {
    if (flags & 4) return;
    uint2 b[N];
#pragma unroll
    for (int i = 0; i < N; i++) b[i] = bact ? bf[i * 32] : make_uint2(0u, 0u);
#pragma unroll
    for (int i = 0; i < N; i++) mma(c, T[i], b[i]);
}

// ---- RMSNorm of layer 0's input (the embedding rows): computed in the block, also stores x (block 0)
__device__ __forceinline__ void norm_frag_embed(const u16* emb, const long long* toks, int tstride, const float* w, int B,
                                                u16* xf16, float* sm, float* xstore, float* dbg) {
    int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
    for (int b = 0; b < B; b++) {
        float ss = 0.f;
        for (int j = 0; j < 2; j++) {
            int k = tid + j * 1024;
            float val = b2f(emb[(size_t)toks[(size_t)b * tstride] * HID + k]);
            ss += val * val;
            if (xstore) xstore[b * HID + k] = val;
            if (dbg) dbg[b * HID + k] = val;
        }
        ss = warp_sum(ss);
        if (lane == 0) sm[b * 32 + warp] = ss;
    }
    __syncthreads();
    if (tid < B) {
        float s = 0.f;
        for (int i = 0; i < 32; i++) s += sm[tid * 32 + i];
        sm[512 + tid] = rsqrtf(s * (1.0f / HID) + RMS_EPS);
    }
    __syncthreads();
    for (int b = 0; b < B; b++) {
        float sc = sm[512 + b];
        for (int j = 0; j < 2; j++) {
            int k = tid + j * 1024;
            float val = b2f(emb[(size_t)toks[(size_t)b * tstride] * HID + k]);
            xf16[(k >> 4) * 128 + bidx(k & 15, b)] = fbits(w[k] * (val * sc));
        }
    }
    __syncthreads();
}

// ---- RMSNorm of the residual stream into B fragments. The sum of squares comes from the 128 partial sums the
// producer blocks wrote with x (xss [128][MAXB]).
__device__ __forceinline__ void norm_frag(const float* x, const float* xss, const float* w, int B, u16* xf16, float* sm, float* dbg) {
    int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
    if (tid < NMAIN) {
        for (int b = 0; b < B; b++) {
            float v = warp_sum(xss[tid * MAXB + b]);
            if (lane == 0) sm[b * 4 + warp] = v;
        }
    }
    __syncthreads();
    for (int b = 0; b < B; b++) {
        float s = sm[b * 4] + sm[b * 4 + 1] + sm[b * 4 + 2] + sm[b * 4 + 3];
        float sc = rsqrtf(s * (1.0f / HID) + RMS_EPS);
        for (int j = 0; j < 2; j++) {
            int k = tid + j * 1024;
            float val = x[b * HID + k];
            if (dbg) dbg[b * HID + k] = val;
            xf16[(k >> 4) * 128 + bidx(k & 15, b)] = fbits(w[k] * (val * sc));
        }
    }
    __syncthreads();
}

// Write one hidden unit of a SwiGLU (gate row g of the row group, up row g+8) into B fragments.
__device__ __forceinline__ void h_store(const float4& c, int lr, int lane, int B, u16* hbase) {
    int g = lane >> 2, t = lane & 3;
    int j = 8 * lr + g;
    for (int i = 0; i < 2; i++) {
        int b = 2 * t + i;
        if (b < B) {
            float gate = rb(cget(c, i)), up = rb(cget(c, 2 + i));
            float h = rb(silu(gate)) * up;
            hbase[(j >> 4) * 128 + bidx(j & 15, b)] = fbits(h);
        }
    }
}

// Leader epilogue of a phase that produces the residual stream: x[rows of this block] = bf16(x + delta), plus the
// block's partial sum of squares per sequence.
__device__ __forceinline__ void x_update(const Params* P, int blk, int lane, int B, const float4& delta) {
    int g = lane >> 2, t = lane & 3;
    float* x = P->x;
    float ss[2] = {0.f, 0.f};
    for (int i = 0; i < 4; i++) {
        int b = 2 * t + (i & 1), r = blk * 16 + g + (i >> 1) * 8;
        if (b < B) {
            float v = rb(x[b * HID + r] + cget(delta, i));
            x[b * HID + r] = v;
            ss[i & 1] += v * v;
        }
    }
    for (int i = 0; i < 2; i++) {
        float v = ss[i];
        v += __shfl_xor_sync(0xffffffffu, v, 4);
        v += __shfl_xor_sync(0xffffffffu, v, 8);
        v += __shfl_xor_sync(0xffffffffu, v, 16);
        if (g == 0 && 2 * t + i < B) P->xss[blk * MAXB + 2 * t + i] = v;
    }
}

// ------------------------------------------------------------------------------------------------ attention
__device__ __forceinline__ float qkv_part(const float4* qkvp, int r, int b) {
    int rg = r >> 4, rr = r & 15;
    int ln = (rr & 7) * 4 + (b >> 1), reg = (rr >> 3) * 2 + (b & 1);
    return ((const float*)&qkvp[(2 * rg) * 32 + ln])[reg] + ((const float*)&qkvp[(2 * rg + 1) * 32 + ln])[reg];
}

// One (sequence b, K/V head kvg) pair = 8 query heads, in one block. The key of the current position is handled
// from registers (its score and its value term), so the cache stores of this step are not read back in this step.
__device__ __forceinline__ void attention(const Params* P, const LayerP& L, int b, int kvg, int pos,
                                          u16* qf16, float* sc, u16* wf16, float* tmp, float* sm, float4* red, int flags) {
    const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g = lane >> 2, t = lane & 3;
    const int h = tid >> 7, d = tid & 127;
    const float4* qkvp = P->qkvp;
    const float* cosr = P->cosT + (size_t)pos * 128;
    const float* sinr = P->sinT + (size_t)pos * 128;
    const size_t cbase = ((size_t)(b * NKV + kvg) * P->kgmax) * 8 * 32;
    uint4* kc = L.kc + cbase;
    uint4* vc = L.vc + cbase;
    const int lo = L.sliding ? (pos - 512 > 0 ? pos - 512 : 0) : 0;
    const int kg0 = lo >> 4, nkg = pos > lo ? ((pos - 1) >> 4) - kg0 + 1 : 0;   // key groups holding cached keys lo .. pos-1
    const float scaling = 0.08838834764831845f;
    // cached keys of this warp's first key group: issue the loads now
    uint4 KT[8];
    if (warp < nkg) {
        const uint4* kt = kc + (size_t)((kg0 + warp) * 8) * 32 + lane;
#pragma unroll
        for (int i = 0; i < 8; i++) KT[i] = kt[i * 32];
    }
    // ---- stage 1: q (all threads), k (threads 0..127), v (threads 128..255): raw projections, sums of squares
    float q = rb(qkv_part(qkvp, (kvg * 8 + h) * 128 + d, b));
    float kv = 0.f;
    {
        float ss = warp_sum(q * q);
        if (lane == 0) sm[warp] = ss;
        if (tid < 128) {
            kv = rb(qkv_part(qkvp, 4096 + kvg * 128 + d, b));
            float sk = warp_sum(kv * kv);
            if (lane == 0) sm[32 + warp] = sk;
        } else if (tid < 256) {
            kv = rb(qkv_part(qkvp, 4608 + kvg * 128 + d, b));
        }
    }
    __syncthreads();
    // ---- stage 2: norms, rotary, fragments and cache stores
    {
        float s = sm[h * 4] + sm[h * 4 + 1] + sm[h * 4 + 2] + sm[h * 4 + 3];
        q = rb(L.qn[d] * (q * rsqrtf(s * (1.0f / 128) + RMS_EPS)));
        if (tid < 128) {
            float sk = sm[32] + sm[33] + sm[34] + sm[35];
            kv = rb(L.kn[d] * (kv * rsqrtf(sk * (1.0f / 128) + RMS_EPS)));
        }
        if (L.sliding) {
            tmp[tid] = q;
            if (tid < 128) tmp[1024 + tid] = kv;
            __syncthreads();
            float partner = tmp[tid ^ 64];
            q = rb(rb(q * cosr[d]) + rb((d < 64 ? -partner : partner) * sinr[d]));
            if (tid < 128) {
                float pk = tmp[1024 + (tid ^ 64)];
                kv = rb(rb(kv * cosr[d]) + rb((d < 64 ? -pk : pk) * sinr[d]));
            }
        }
        qf16[(d >> 4) * 128 + bidx(d & 15, h)] = fbits(q);
        const int kg = pos >> 4, tm = pos & 15, dc = d >> 4, dd = d & 15;
        if (tid < 128) {
            tmp[1152 + tid] = kv;
            ((u16*)(kc + (size_t)(kg * 8 + dc) * 32))[aidx(tm, dd)] = fbits(kv);
        } else if (tid < 256) {
            tmp[1280 + d] = kv;
            ((u16*)(vc + (size_t)(kg * 8 + dc) * 32))[aidx(dd, tm)] = fbits(kv);
        }
    }
    __syncthreads();
    // ---- stage 3: score of the current key (partial sums), scores of the cached keys, per-warp maxima
    {
        float ps = warp_sum(q * tmp[1152 + d]);
        if (lane == 0) sm[64 + warp] = ps;
        float mx[2] = {-INFINITY, -INFINITY};
        const uint2* qf = (const uint2*)qf16 + lane;
        for (int kg = kg0 + warp; kg < kg0 + nkg; kg += 32) {
            float4 c = make_float4(0.f, 0.f, 0.f, 0.f);
            if (kg != kg0 + warp) {
                const uint4* kt = kc + (size_t)(kg * 8) * 32 + lane;
#pragma unroll
                for (int i = 0; i < 8; i++) KT[i] = kt[i * 32];
            }
#pragma unroll
            for (int i = 0; i < 8; i++) mma(c, KT[i], qf[i * 32]);
            for (int i = 0; i < 4; i++) {
                int key = (kg - kg0) * 16 + g + (i >> 1) * 8, head = 2 * t + (i & 1);
                int tabs = kg * 16 + g + (i >> 1) * 8;
                float val = (tabs >= lo && tabs < pos) ? cget(c, i) * scaling : -INFINITY;
                sc[key * 8 + head] = val;
                mx[i & 1] = fmaxf(mx[i & 1], val);
            }
        }
        for (int i = 0; i < 2; i++) {
            float m = mx[i];
            m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, 4));
            m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, 8));
            m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, 16));
            if (g == 0) sm[128 + warp * 8 + 2 * t + i] = m;
        }
    }
    __syncthreads();
    // ---- stage 4/5: softmax with the sink. Thread role: head = lane & 7, key class cls = warp*4 + lane/8
    {
        const int head = lane & 7, cls = warp * 4 + (lane >> 3), nkeys = nkg * 16;
        const float sink = L.sinks[kvg * 8 + head];
        const float self = (sm[64 + head * 4] + sm[64 + head * 4 + 1] + sm[64 + head * 4 + 2] + sm[64 + head * 4 + 3]) * scaling;
        float M = fmaxf(sink, self);
        const int nw = nkg < 32 ? nkg : 32;
        for (int i = 0; i < nw; i++) M = fmaxf(M, sm[128 + i * 8 + head]);
        float s = 0.f;
        for (int key = cls; key < nkeys; key += 128) s += __expf(sc[key * 8 + head] - M);
        s += __shfl_xor_sync(0xffffffffu, s, 8);
        s += __shfl_xor_sync(0xffffffffu, s, 16);
        if (lane < 8) sm[400 + warp * 8 + head] = s;
        __syncthreads();
        float S = __expf(sink - M) + __expf(self - M);
        for (int i = 0; i < 32; i++) S += sm[400 + i * 8 + head];
        for (int key = cls; key < nkeys; key += 128)
            wf16[(key >> 4) * 128 + bidx(key & 15, head)] = fbits(__expf(sc[key * 8 + head] - M) / S);
        if (tid < 8) sm[700 + head] = rb(__expf(self - M) / S);
    }
    __syncthreads();
    // ---- stage 6: weighted sum of V. Warp = (dim chunk dc, key-group class q4); the current key's term is added from registers
    {
        const int dc = warp & 7, q4 = warp >> 3;
        float4 c = make_float4(0.f, 0.f, 0.f, 0.f);
        const uint2* wf = (const uint2*)wf16 + lane;
        int i = q4;
        for (; i + 12 < nkg; i += 16) {
            uint4 a0 = vc[(size_t)((kg0 + i) * 8 + dc) * 32 + lane], a1 = vc[(size_t)((kg0 + i + 4) * 8 + dc) * 32 + lane];
            uint4 a2 = vc[(size_t)((kg0 + i + 8) * 8 + dc) * 32 + lane], a3 = vc[(size_t)((kg0 + i + 12) * 8 + dc) * 32 + lane];
            mma(c, a0, wf[i * 32]); mma(c, a1, wf[(i + 4) * 32]); mma(c, a2, wf[(i + 8) * 32]); mma(c, a3, wf[(i + 12) * 32]);
        }
        for (; i < nkg; i += 4) {
            uint4 a0 = vc[(size_t)((kg0 + i) * 8 + dc) * 32 + lane];
            mma(c, a0, wf[i * 32]);
        }
        red[tid] = c;
        __syncthreads();
        if (warp < 8) {
            c = f4add(f4add(red[tid], red[tid + 256]), f4add(red[tid + 512], red[tid + 768]));
            for (int j = 0; j < 4; j++) {
                int dd = g + (j >> 1) * 8, head = 2 * t + (j & 1);
                int chunk = (kvg * 8 + head) * 8 + dc;
                float val = cget(c, j) + sm[700 + head] * tmp[1280 + dc * 16 + dd];
                P->attnf[chunk * 128 + bidx(dd, b)] = fbits(val);
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------ router top-k
// In every main block: top-6 of the sigmoid scores per sequence, then the union over the batch ("units", ascending
// expert id). un[0] = number of units, un[1 + u] = expert of unit u; uwl[u*8 + b] = routing weight (0: not a member).
__device__ __forceinline__ void route_local(const float* rl, int B, float* sm, int* smi, int* un, float* uwl) {
    const int tid = threadIdx.x;
    for (int b = 0; b < B; b++) {
        if (tid < NEXP) sm[tid] = 1.0f / (1.0f + __expf(-rl[b * NEXP + tid]));
        __syncthreads();
        {
            const int e = tid & 255, q = tid >> 8;
            const float se = sm[e];
            int cnt = 0;
            for (int j = q * 64; j < q * 64 + 64; j++) { float o = sm[j]; cnt += (o > se) || (o == se && j < e); }
            smi[tid] = cnt;
        }
        __syncthreads();
        if (tid < NEXP) {
            int rank = smi[tid] + smi[tid + 256] + smi[tid + 512] + smi[tid + 768];
            if (rank < TOPK) { smi[1024 + b * 8 + rank] = tid; sm[256 + b * 8 + rank] = sm[tid]; }
        }
        __syncthreads();
    }
    const bool ent = tid < 8 * B && (tid & 7) < TOPK;
    if (ent) {
        const int b = tid >> 3;
        float sum = 0.f;
        for (int r = 0; r < TOPK; r++) sum += sm[256 + b * 8 + r];
        sm[512 + tid] = sm[256 + tid] / sum;
        const int id = smi[1024 + tid];
        int first = 1;
        for (int j = 0; j < tid; j++) if ((j & 7) < TOPK && smi[1024 + j] == id) first = 0;
        smi[1100 + tid] = first;
    }
    if (tid < MAXU * MAXB) uwl[tid] = 0.f;
    __syncthreads();
    if (ent) {
        const int id = smi[1024 + tid];
        int u = 0, n = 0;
        for (int j = 0; j < 8 * B; j++)
            if ((j & 7) < TOPK && smi[1100 + j]) { n++; u += smi[1024 + j] < id; }
        un[1 + u] = id;
        uwl[u * MAXB + (tid >> 3)] = sm[512 + tid];
        if (tid == 0) un[0] = n;
    }
    __syncthreads();
}

// ------------------------------------------------------------------------------------------------ the kernel
#define SM_XF_BYTES (128 * 256)              // B fragments of a 2048-vector
#define SM_RED_BYTES (64 * 32 * 16)          // 64 partial slots
#define SM_MISC_FLOATS 1024
#define SM_TMP_FLOATS 1536
#define SM_SC_FLOATS (16 * 8)                // per key group
#define SM_TOTAL(kgmax) (SM_XF_BYTES + SM_RED_BYTES + SM_MISC_FLOATS * 4 + SM_TMP_FLOATS * 4 + 2048 /*qf*/ + (kgmax) * (SM_SC_FLOATS * 4 + 256) + 2048 * 4 /*smi*/ + 64 * 4 /*un*/ + MAXU * MAXB * 4 /*uwl*/)

__global__ void __launch_bounds__(1024, 1)
mk_kernel(const Params* Pp, const long long* tok_in, int tstride, float* logits, long long* gen_out, int B, int pos0, int nsteps, int mode,
          unsigned bar0, int flags) {
    extern __shared__ uint4 smem[];
    const Params* P = Pp;
    const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31, g = lane >> 2, t = lane & 3;
    const int blk = blockIdx.x;
    const bool is_main = blk < NMAIN;
    const int aux = blk - NMAIN;                 // 0..23 for aux blocks
    const bool is_router = aux >= 8;             // aux 8..23: one router row group each
    const int kgmax = P->kgmax;
    const bool bact = lane < 4 * B;              // this lane's B-operand column is in use
    // shared memory layout
    u16* xf16 = (u16*)smem;
    const uint2* xf = (const uint2*)smem;
    float4* red = (float4*)((char*)smem + SM_XF_BYTES);
    float* sm = (float*)((char*)red + SM_RED_BYTES);
    float* tmp = sm + SM_MISC_FLOATS;
    u16* qf16 = (u16*)(tmp + SM_TMP_FLOATS);
    float* sc = (float*)((char*)qf16 + 2048);
    u16* wf16 = (u16*)(sc + (size_t)kgmax * SM_SC_FLOATS);
    int* smi = (int*)((char*)wf16 + (size_t)kgmax * 256);
    int* un = smi + 2048;
    float* uwl = (float*)(un + 64);
    for (int i = tid; i < SM_XF_BYTES / 4; i += 1024) ((u32*)smem)[i] = 0u;   // columns >= B stay zero
    __syncthreads();

    unsigned bar = bar0;
    const float4 zero4 = make_float4(0.f, 0.f, 0.f, 0.f);
    uint4 T[10];                                  // preloaded weight tiles of the next phase

    for (int step = 0; step < nsteps; step++) {
        const int pos = pos0 + step;
        const long long* toks = step == 0 ? tok_in : P->curtok;
        const int ts = step == 0 ? tstride : 1;
        if (is_main) tload<10>(T, P->L[0].qkv + (size_t)(blk * 320 + 10 * warp) * 32 + lane, flags);

        for (int l = 0; l < NLAYER; l++) {
            const LayerP& L = P->L[l];
            float* dbg = (P->dbg && blk == 0) ? P->dbg + (size_t)l * MAXB * HID : nullptr;
            // ============ A: input norm, q/k/v projections. A block owns 320 consecutive tiles (5 half row groups).
            if (is_main && !(flags & 256)) {
                if (l == 0) norm_frag_embed(P->embed, toks, ts, L.ln1, B, xf16, sm, blk == 0 ? P->x : nullptr, dbg);
                else norm_frag(P->x, P->xss, L.ln1, B, xf16, sm, dbg);
                const int g0 = 10 * warp;                      // first tile of this warp inside the block (multiple of 64 per half group)
                int nA = 64 - (g0 & 63); if (nA > 10) nA = 10;
                float4 cA = zero4, cB = zero4;
                if (!(flags & 4)) {
                    const uint2* xb = xf + lane;
#pragma unroll
                    for (int i = 0; i < 10; i++) {
                        if (i == nA) { cB = cA; cA = zero4; }
                        mma(cA, T[i], xb[((blk * 320 + g0 + i) & 127) * 32]);
                    }
                }
                tload<8>(T, L.o + (size_t)(blk * 256 + 8 * warp) * 32 + lane, flags);      // preload C
                red[(warp * 2) * 32 + lane] = nA == 10 ? cA : cB;
                red[(warp * 2 + 1) * 32 + lane] = nA == 10 ? zero4 : cA;
                __syncthreads();
                if (warp < 5) {
                    const int w_lo = (64 * warp) / 10, w_hi = (64 * warp + 63) / 10;
                    float4 c = zero4;
                    for (int w = w_lo; w <= w_hi; w++) c = f4add(c, red[(w * 2 + (((10 * w) >> 6) == warp ? 0 : 1)) * 32 + lane]);
                    P->qkvp[(blk * 5 + warp) * 32 + lane] = c;
                }
            }
            barrier(P, bar, flags);
            // ============ B: attention on the aux blocks (pair p = sequence*4 + K/V head; aux a does pairs a and a+24)
            if (!is_main && !(flags & 2)) {
                if (aux < 4 * B) attention(P, L, aux >> 2, aux & 3, pos, qf16, sc, wf16, tmp, sm, red, flags);
                if (aux + 24 < 4 * B) { __syncthreads(); attention(P, L, (aux + 24) >> 2, (aux + 24) & 3, pos, qf16, sc, wf16, tmp, sm, red, flags); }
            }
            barrier(P, bar, flags);
            // ============ C: output projection + residual (one row group per main block, 8 tiles per warp)
            if (is_main && !(flags & 512)) {
                float4 c = zero4;
                tmma<8>(c, T, (const uint2*)P->attnf + (size_t)(8 * warp) * 32 + lane, bact, flags);
                if (L.moe) tload<4>(T, L.sgu + (size_t)(blk * 128 + 4 * warp) * 32 + lane, flags);   // preload D
                red[warp * 32 + lane] = c;
                __syncthreads();
                if (warp == 0) {
                    c = red[lane];
                    for (int w = 1; w < 32; w++) c = f4add(c, red[w * 32 + lane]);
                    x_update(P, blk, lane, B, make_float4(rb(c.x), rb(c.y), rb(c.z), rb(c.w)));
                }
            } else if (is_router && L.moe) {
                tload<4>(T, L.router + (size_t)((aux - 8) * 128 + 4 * warp) * 32 + lane, flags);
            }
            barrier(P, bar, flags);
            if (L.moe) {
                // ============ D: post-attention norm; shared expert gate/up (main), router logits (aux 8..23)
                if ((is_main || is_router) && !(flags & 1024)) {
                    norm_frag(P->x, P->xss, L.ln2, B, xf16, sm, nullptr);
                    float4 c = zero4;
                    tmma<4>(c, T, xf + (size_t)(4 * warp) * 32 + lane, true, flags);
                    red[warp * 32 + lane] = c;
                    __syncthreads();
                    if (warp == 0) {
                        c = red[lane];
                        for (int w = 1; w < 32; w++) c = f4add(c, red[w * 32 + lane]);
                        if (is_main) h_store(c, blk, lane, B, P->hsh);
                        else {
                            for (int i = 0; i < 4; i++) {
                                int b = 2 * t + (i & 1), e = (aux - 8) * 16 + g + (i >> 1) * 8;
                                if (b < B) P->rl[b * NEXP + e] = cget(c, i);
                            }
                        }
                    }
                }
                barrier(P, bar, flags);
                // ============ E: routing (every main block), expert gate/up: 64 row groups per unit, teams of 8 warps
                int U = 0;
                if (is_main && (flags & 2048)) { if (tid == 0) { un[0] = 6; for (int i = 0; i < 6; i++) { un[1 + i] = i * 40 + l; uwl[i * MAXB] = 1.f / 6; } } __syncthreads(); U = 6; }
                if (is_main && !(flags & 2048)) {
                    route_local(P->rl, B, sm, smi, un, uwl);
                    U = un[0];
                    const int G = U * 64;
                    const int e0 = blk * G / NMAIN, e1 = (blk + 1) * G / NMAIN;
                    const int team = warp >> 3, wi = warp & 7;
                    for (int r = e0; r < e1; r += 4) {
                        const int rg = r + team;
                        const bool act = rg < e1;
                        const int u = rg >> 6, lr = rg & 63;
                        float4 c = zero4;
                        if (act) {
                            const uint4* wt = L.egu + ((size_t)(un[1 + u] * 64 + lr) * 128 + 16 * wi) * 32 + lane;
                            const uint2* xb = xf + (size_t)(16 * wi) * 32 + lane;
                            tload<8>(T, wt, flags);
                            tmma<8>(c, T, xb, true, flags);
                            tload<8>(T, wt + 8 * 32, flags);
                            tmma<8>(c, T, xb + 8 * 32, true, flags);
                        }
                        red[warp * 32 + lane] = c;
                        __syncthreads();
                        if (act && wi == 0) {
                            c = red[warp * 32 + lane];
                            for (int w = 1; w < 8; w++) c = f4add(c, red[(warp + w) * 32 + lane]);
                            h_store(c, lr, lane, B, P->hx + (size_t)u * 32 * 128);
                        }
                        if (r + 4 < e1) __syncthreads();
                    }
                    // preload F: the first 8 items (item = warp/4: units in ascending order, then the two halves of the shared expert)
                    {
                        const int it = warp >> 2, wj = warp & 3;
                        if (it < U) tload<8>(T, L.edown + ((size_t)(un[1 + it] * 128 + blk) * 32 + 8 * wj) * 32 + lane, flags);
                        else if (it < U + 2) tload<8>(T, L.sdown + ((size_t)(blk * 64 + (it - U) * 32) + 8 * wj) * 32 + lane, flags);
                    }
                }
                barrier(P, bar, flags);
                // ============ F: down projections (items of 32 chunks, 4 warps each), routing weights, shared expert, residual
                if (is_main && !(flags & 4096)) {
                    const int nitems = U + 2;
                    const int wj = warp & 3;
                    float fin[4] = {0.f, 0.f, 0.f, 0.f}, sh[4] = {0.f, 0.f, 0.f, 0.f};
                    for (int it0 = 0; it0 < nitems; it0 += 8) {
                        const int it = it0 + (warp >> 2);
                        float4 c = zero4;
                        if (it < nitems) {
                            const uint2* hb = (it < U ? (const uint2*)P->hx + (size_t)it * 32 * 32 : (const uint2*)P->hsh + (size_t)(it - U) * 32 * 32) + (size_t)(8 * wj) * 32 + lane;
                            if (it0 > 0) {
                                if (it < U) tload<8>(T, L.edown + ((size_t)(un[1 + it] * 128 + blk) * 32 + 8 * wj) * 32 + lane, flags);
                                else tload<8>(T, L.sdown + ((size_t)(blk * 64 + (it - U) * 32) + 8 * wj) * 32 + lane, flags);
                            }
                            tmma<8>(c, T, hb, bact, flags);
                        }
                        if (it0 + 8 >= nitems && l + 1 < NLAYER) tload<10>(T, P->L[l + 1].qkv + (size_t)(blk * 320 + 10 * warp) * 32 + lane, flags);   // preload A
                        red[warp * 32 + lane] = c;
                        __syncthreads();
                        if (warp == 0) {
                            for (int q = 0; q < 8 && it0 + q < nitems; q++) {
                                const int itq = it0 + q;
                                float4 cq = f4add(f4add(red[(q * 4) * 32 + lane], red[(q * 4 + 1) * 32 + lane]), f4add(red[(q * 4 + 2) * 32 + lane], red[(q * 4 + 3) * 32 + lane]));
                                for (int i = 0; i < 4; i++) {
                                    const int b = 2 * t + (i & 1);
                                    if (b >= B) continue;
                                    if (itq < U) fin[i] += rb(cget(cq, i)) * uwl[itq * MAXB + b];
                                    else sh[i] += cget(cq, i);
                                }
                            }
                        }
                        if (it0 + 8 < nitems) __syncthreads();
                    }
                    if (warp == 0) x_update(P, blk, lane, B, make_float4(rb(rb(fin[0]) + rb(sh[0])), rb(rb(fin[1]) + rb(sh[1])), rb(rb(fin[2]) + rb(sh[2])), rb(rb(fin[3]) + rb(sh[3]))));
                }
                barrier(P, bar, flags);
            } else {
                // ============ dense MLP (layers 0 and 1). D': gate/up, 768 consecutive tiles (6 row groups) per block, 24 per warp
                if (is_main) {
                    norm_frag(P->x, P->xss, L.ln2, B, xf16, sm, nullptr);
                    const int g0 = 24 * warp;
                    int nA = 128 - (g0 & 127); if (nA > 24) nA = 24;
                    float4 cA = zero4, cB = zero4;
                    const uint4* wt = L.dgu + (size_t)(blk * 768 + g0) * 32 + lane;
                    const uint2* xb = xf + lane;
                    for (int i0 = 0; i0 < 24 && !(flags & 4); i0 += 8) {
                        tload<8>(T, wt + (size_t)i0 * 32, flags);
#pragma unroll
                        for (int i = 0; i < 8; i++) {
                            if (i0 + i == nA) { cB = cA; cA = zero4; }
                            mma(cA, T[i], xb[((g0 + i0 + i) & 127) * 32]);
                        }
                    }
                    red[(warp * 2) * 32 + lane] = nA == 24 ? cA : cB;
                    red[(warp * 2 + 1) * 32 + lane] = nA == 24 ? zero4 : cA;
                    __syncthreads();
                    if (warp < 6) {
                        const int w_lo = (128 * warp) / 24, w_hi = (128 * warp + 127) / 24;
                        float4 c = zero4;
                        for (int w = w_lo; w <= w_hi; w++) c = f4add(c, red[(w * 2 + (((24 * w) >> 7) == warp ? 0 : 1)) * 32 + lane]);
                        h_store(c, blk * 6 + warp, lane, B, P->hx);
                    }
                }
                barrier(P, bar, flags);
                // E': down projection (K = 6144: 384 tiles per block, 12 per warp) + residual
                if (is_main) {
                    float4 c = zero4;
                    const uint4* wt = L.ddown + (size_t)(blk * 384 + 12 * warp) * 32 + lane;
                    const uint2* hb = (const uint2*)P->hx + (size_t)(12 * warp) * 32 + lane;
                    tload<8>(T, wt, flags);
                    tmma<8>(c, T, hb, bact, flags);
                    tload<4>(T, wt + 8 * 32, flags);
                    tmma<4>(c, T, hb + 8 * 32, bact, flags);
                    tload<10>(T, P->L[l + 1].qkv + (size_t)(blk * 320 + 10 * warp) * 32 + lane, flags);   // preload A
                    red[warp * 32 + lane] = c;
                    __syncthreads();
                    if (warp == 0) {
                        c = red[lane];
                        for (int w = 1; w < 32; w++) c = f4add(c, red[w * 32 + lane]);
                        x_update(P, blk, lane, B, make_float4(rb(c.x), rb(c.y), rb(c.z), rb(c.w)));
                    }
                }
                barrier(P, bar, flags);
            }
        }
        // ============ final norm + head (9384 row groups; one warp per row group, 128 tiles each)
        if (is_main && !(flags & 8192)) {
            norm_frag(P->x, P->xss, P->fnorm, B, xf16, sm, (P->dbg && blk == 0) ? P->dbg + (size_t)NLAYER * MAXB * HID : nullptr);
            const int G = VOCAB / 16;
            const int e0 = (int)((long long)blk * G / NMAIN), e1 = (int)((long long)(blk + 1) * G / NMAIN);
            float bv[2] = {-INFINITY, -INFINITY};
            int bi[2] = {0, 0};
            const uint2* xb = xf + lane;
            for (int rg = e0 + warp; rg < e1; rg += 32) {
                const uint4* wt = P->head + (size_t)rg * 128 * 32 + lane;
                float4 c = zero4;
                for (int ch = 0; ch < 128 && !(flags & 4); ch += 8) {
                    tload<8>(T, wt + (size_t)ch * 32, flags);
                    tmma<8>(c, T, xb + (size_t)ch * 32, true, flags);
                }
                for (int i = 0; i < 4; i++) {
                    const int b = 2 * t + (i & 1), row = rg * 16 + g + (i >> 1) * 8;
                    if (b < B) {
                        const float val = cget(c, i);
                        if (mode == 0) logits[(size_t)b * VOCAB + row] = val;
                        else if (val > bv[i & 1]) { bv[i & 1] = val; bi[i & 1] = row; }
                    }
                }
            }
            if (mode != 0) {
                for (int i = 0; i < 2; i++) {
                    for (int o = 4; o <= 16; o <<= 1) {
                        float ov = __shfl_xor_sync(0xffffffffu, bv[i], o);
                        int oi = __shfl_xor_sync(0xffffffffu, bi[i], o);
                        if (ov > bv[i] || (ov == bv[i] && oi < bi[i])) { bv[i] = ov; bi[i] = oi; }
                    }
                    if (g == 0) { sm[warp * 8 + 2 * t + i] = bv[i]; smi[warp * 8 + 2 * t + i] = bi[i]; }
                }
                __syncthreads();
                if (tid < B) {
                    float v = sm[tid]; int ix = smi[tid];
                    for (int w = 1; w < 32; w++) {
                        float ov = sm[w * 8 + tid]; int oi = smi[w * 8 + tid];
                        if (ov > v || (ov == v && oi < ix)) { v = ov; ix = oi; }
                    }
                    P->argv[blk * MAXB + tid] = v; P->argi[blk * MAXB + tid] = ix;
                }
            }
        }
        barrier(P, bar, flags);
        if (mode != 0) {
            if (blk == 0 && tid < B) {
                float v = P->argv[tid]; int ix = P->argi[tid];
                for (int w = 1; w < NMAIN; w++) {
                    float ov = P->argv[w * MAXB + tid]; int oi = P->argi[w * MAXB + tid];
                    if (ov > v || (ov == v && oi < ix)) { v = ov; ix = oi; }
                }
                P->curtok[tid] = ix;
                gen_out[(size_t)tid * nsteps + step] = ix;
            }
            barrier(P, bar, flags);
        }
    }
}

// ------------------------------------------------------------------------------------------------ host side
struct Handle {
    Params host;
    Params* dev;
    unsigned bar, abar;
    int smem_bytes, flags;
};

#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "mk: CUDA error %s at line %d\n", cudaGetErrorString(e_), __LINE__); return 0; } } while (0)

template <class T> static int dalloc(T*& p, size_t n) {
    void* q = nullptr;
    if (cudaMalloc(&q, n * sizeof(T)) != cudaSuccess) return 0;
    if (cudaMemset(q, 0, n * sizeof(T)) != cudaSuccess) return 0;
    p = (T*)q;
    return 1;
}

extern "C" {

// slots: per layer 20 entries [qkv, o, dgu, ddown, router, sgu, sdown, egu, edown, kc, vc, ln1, ln2, qn, kn, sinks, sliding, moe, -, -],
// then [embed, head, fnorm, cos, sin, maxctx, debug]
void* mk_create(const long long* s) {
    Handle* h = new Handle();
    memset(h, 0, sizeof(Handle));
    Params& P = h->host;
    for (int l = 0; l < NLAYER; l++) {
        const long long* q = s + l * 20;
        LayerP& L = P.L[l];
        L.qkv = (const uint4*)q[0]; L.o = (const uint4*)q[1]; L.dgu = (const uint4*)q[2]; L.ddown = (const uint4*)q[3];
        L.router = (const uint4*)q[4]; L.sgu = (const uint4*)q[5]; L.sdown = (const uint4*)q[6]; L.egu = (const uint4*)q[7]; L.edown = (const uint4*)q[8];
        L.kc = (uint4*)q[9]; L.vc = (uint4*)q[10];
        L.ln1 = (const float*)q[11]; L.ln2 = (const float*)q[12]; L.qn = (const float*)q[13]; L.kn = (const float*)q[14]; L.sinks = (const float*)q[15];
        L.sliding = (int)q[16]; L.moe = (int)q[17];
    }
    const long long* q = s + NLAYER * 20;
    P.embed = (const u16*)q[0]; P.head = (const uint4*)q[1]; P.fnorm = (const float*)q[2]; P.cosT = (const float*)q[3]; P.sinT = (const float*)q[4];
    P.maxctx = (int)q[5]; P.kgmax = (P.maxctx + 15) / 16;
    int ok = dalloc(P.x, MAXB * HID) && dalloc(P.qkvp, 640 * 32) && dalloc(P.attnf, 256 * 128) && dalloc(P.rl, MAXB * NEXP) &&
             dalloc(P.units, 64) && dalloc(P.uw, MAXU * MAXB) && dalloc(P.hsh, 64 * 128) && dalloc(P.hx, MAXU * 32 * 128) &&
             dalloc(P.xss, NMAIN * MAXB) && dalloc(P.argv, NBLK * MAXB) && dalloc(P.argi, NBLK * MAXB) && dalloc(P.curtok, MAXB) && dalloc(P.ctr, 16) && dalloc(P.actr, 16);
    if (ok && q[6]) ok = dalloc(P.dbg, (size_t)(NLAYER + 1) * MAXB * HID);
    if (!ok) { fprintf(stderr, "mk: allocation failed\n"); return nullptr; }
    void* d = nullptr;
    if (cudaMalloc(&d, sizeof(Params)) != cudaSuccess) return nullptr;
    h->dev = (Params*)d;
    if (cudaMemcpy(h->dev, &P, sizeof(Params), cudaMemcpyHostToDevice) != cudaSuccess) return nullptr;
    h->smem_bytes = SM_TOTAL(P.kgmax);
    if (cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, h->smem_bytes) != cudaSuccess) {
        fprintf(stderr, "mk: cannot set %d bytes of shared memory\n", h->smem_bytes);
        return nullptr;
    }
    return h;
}

// mode 0: one step, logits written. mode 1: nsteps greedy steps, tokens to gen_out [B][nsteps].
int mk_run(void* hv, const long long* tok, int tstride, float* logits, long long* gen_out, int B, int pos0, int nsteps, int mode) {
    Handle* h = (Handle*)hv;
    mk_kernel<<<NBLK, 1024, h->smem_bytes>>>(h->dev, tok, tstride, logits, gen_out, B, pos0, nsteps, mode, h->bar, h->flags);
    const unsigned per_step = 47 * 6 + 2 * 5 + 1 + (mode ? 1 : 0);
    h->bar += (unsigned)nsteps * per_step * NBLK;
    cudaError_t e = cudaGetLastError();
    if (e != cudaSuccess) { fprintf(stderr, "mk: launch failed: %s\n", cudaGetErrorString(e)); return 1; }
    return 0;
}

int mk_read_dbg(void* hv, float* out) {
    Handle* h = (Handle*)hv;
    if (!h->host.dbg) return 1;
    CK(cudaMemcpy(out, h->host.dbg, (size_t)(NLAYER + 1) * MAXB * HID * sizeof(float), cudaMemcpyDeviceToHost));
    return 0;
}

int mk_smem(void* hv) { return ((Handle*)hv)->smem_bytes; }
void mk_set_flags(void* hv, int f) { ((Handle*)hv)->flags = f; }

}  // extern "C"
