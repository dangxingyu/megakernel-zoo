// Flint megakernel (v6): one persistent kernel per decode step, per generate() call or per served cohort, on one B200.
//
// 152 blocks, one per SM. Blocks 0..127 ("main") stream the weights: every matrix-vector product is a chain of
// tensor-core mma.m16n8k16 (bf16 x bf16 -> f32) over weights re-laid at load time into 512-byte "tiles" in the
// register order of the mma A operand (one 16-byte load per thread feeds one mma); the 8 columns of the B operand
// are the sequences of the batch. Blocks 128..151 ("aux") run attention (aux a: pairs a and a+24 of
// (sequence, K/V head)) and the router (aux 8..23, one 16-row group each).
//
// What the card dictates (measured, notes/journal.md): a warp has one global load outstanding and blocks 0.15-0.3 us
// on it; a load costs by the cache lines it touches; shared memory moves only 60-90 GB/s; a register spill reload
// can cost a microsecond. So: blocks of 512 threads (16 warps x 128 registers); weights go DRAM -> registers -> mma,
// and the tiles of the next phase (and the K/V tiles of the next layer) are loaded into registers while a block
// waits for the others; every activation buffer is laid out so that a consumer warp reads contiguous bytes; one
// warp per block does the epilogue stores, fences (stores are not visible to other SMs otherwise) and bumps a
// counter; three counters (main phases, attention, router) replace a global barrier.
//
// Track A (default): the number formats of the Hugging Face BF16 path, every rounding point reproduced.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#define HID 2048
#define NLAYER 49
#define NKV 4
#define NEXP 256
#define TOPK 6
#define VOCAB 150144
#define NMAIN 128
#define NAUX 24
#define NROUT 16
#define NBLK 152
#define MAXB 8
#define MAXU 48
#define RMS_EPS 1e-6f
#define CM 0          // counter of finished main phases (x NMAIN)
#define CX 32         // counter of finished attention phases (x number of attention blocks)
#define CR 64         // counter of finished router phases (x NROUT)
#define HSLOT_SHARED 48
#define HCHUNKS (50 * 32)

struct LayerP {
    const uint4 *qkv, *o, *dgu, *ddown, *router, *sgu, *sdown, *egu, *edown;
    uint4 *kc, *vc;
    const float *ln1, *ln2, *qn, *kn, *sinks;
    int sliding, moe;
};

struct Params {
    LayerP L[NLAYER];
    const u16* embed;
    const uint4* head;
    const float* fnorm;
    const float *cosT, *sinT;
    int maxctx, kgmax;
    // scratch (allocated by mk_create)
    // Activation buffers. Each is laid out so that a consumer warp reads 512 contiguous bytes (a warp load costs by
    // the cache lines it touches).
    uint2* xc;           // residual stream as BF16 bits (it is exactly BF16): [4 column pairs t][128 row groups][8 g] = {row g: col 2t | col 2t+1 << 16, row g+8: ...}
    float4* qraw;        // raw q/k/v sums per sequence: [MAXB][320 row groups][8 g] = {half 0: row g, row g+8; half 1: row g, row g+8}
    uint2* attnf;        // attention output as B fragments, per sequence: [MAXB][256 chunks][4 lanes]
    float* rl;           // [MAXB][NEXP] router logits
    uint2* hbuf;         // SwiGLU hidden as B fragments, per sequence: [MAXB][50 slots x 32 chunks][4 lanes]; slots 48,49 = shared expert; dense MLP: 384 chunks from slot 0
    float* argv;         // [NMAIN][MAXB]
    int* argi;           // [NMAIN][MAXB]
    long long* curtok;   // [MAXB]
    int* gen;            // served cohorts: [MAXB][maxctx] generated tokens; progress in ctr[96]
    unsigned* ctr;       // counters (CM, CX, CR), [96] = generated steps finished
    float* dbg;          // [NLAYER+1][MAXB][HID] or null
    unsigned* prof;      // profiling build: [3][PROF_MAX][2] (id, tick) samples
    unsigned* clk;       // profiling build: free-running counter written by the clock block
    int fence;           // experiment: fence after every epilogue (not needed with ld.global.cg readers)
};

#ifdef MK_PROF
#define PROF_MAX 4096
#define PROF_BLK(b) ((b) == 0 ? 0 : (b) == NMAIN ? 1 : (b) == NMAIN + 8 ? 2 : -1)
#define PROF(id) do { int pb_ = PROF_BLK(blk); if (tid == 0 && pb_ >= 0 && pi < PROF_MAX) { unsigned* q_ = P->prof + (pb_ * PROF_MAX + pi) * 2; q_[0] = (id); q_[1] = *(volatile unsigned*)P->clk; pi++; } } while (0)
#define PROFX(id) do { int pb_ = PROF_BLK(pblk); if (threadIdx.x == 0 && pb_ >= 0 && *ppi < PROF_MAX) { unsigned* q_ = P->prof + (pb_ * PROF_MAX + *ppi) * 2; q_[0] = (id); q_[1] = *(volatile unsigned*)P->clk; (*ppi)++; } } while (0)
#else
#define PROF(id) do {} while (0)
#define PROFX(id) do {} while (0)
#endif

// ------------------------------------------------------------------------------------------------ small helpers
__device__ __forceinline__ float rb(float f) {       // round to nearest-even BF16, result as float
    u32 u = __float_as_uint(f);
    u += 0x7FFFu + ((u >> 16) & 1u);
    return __uint_as_float(u & 0xFFFF0000u);
}
__device__ __forceinline__ u32 fbits(float f) {      // BF16 bits of f rounded to nearest even
    u32 u = __float_as_uint(f);
    u += 0x7FFFu + ((u >> 16) & 1u);
    return u >> 16;
}
__device__ __forceinline__ float b2f(u16 b) { return __uint_as_float(((u32)b) << 16); }
__device__ __forceinline__ float silu(float x) { return x / (1.0f + __expf(-x)); }

__device__ __forceinline__ void mma(float4& c, const uint4& a, const uint2& b) {
    asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
                 : "+f"(c.x), "+f"(c.y), "+f"(c.z), "+f"(c.w)
                 : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y));
}
__device__ __forceinline__ float4 f4add(float4 a, float4 b) { return make_float4(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w); }
__device__ __forceinline__ float cget(const float4& c, int i) { return i == 0 ? c.x : i == 1 ? c.y : i == 2 ? c.z : c.w; }

// u16 index of element (k within chunk, column n) inside a 256-byte B-fragment chunk
__device__ __forceinline__ int bidx(int kk, int n) { return (((n * 4 + ((kk & 7) >> 1)) * 2 + (kk >> 3)) * 2) + (kk & 1); }
// u16 index of element (row m, col k) inside a 512-byte A tile
__device__ __forceinline__ int aidx(int m, int k) { return ((((m & 7) * 4 + ((k & 7) >> 1)) * 4 + (m >> 3) + 2 * (k >> 3)) * 2) + (k & 1); }
// u16 index of element (key 0..15, dim 0..15) inside a 512-byte K-cache tile (two B operands of 8 keys side by side)
__device__ __forceinline__ int kidx(int key, int dd) { return ((((key & 7) * 4 + ((dd & 7) >> 1)) * 4 + (key >> 3) * 2 + (dd >> 3)) * 2) + (dd & 1); }

// Loads of data another block wrote in this launch bypass this SM's L1 (ld.global.cg): L1 caches are not coherent
// across SMs, a default load can return the line as it was a phase ago (tools/bench8.cu: 2.8% stale reads without a
// fence, none with these loads). With them the writers need no __threadfence.
__device__ __forceinline__ float4 ldx(const float4* p) { float4 r; asm volatile("ld.global.cg.v4.f32 {%0,%1,%2,%3}, [%4];" : "=f"(r.x), "=f"(r.y), "=f"(r.z), "=f"(r.w) : "l"(p)); return r; }
__device__ __forceinline__ uint4 ldx(const uint4* p) { uint4 r; asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p)); return r; }
__device__ __forceinline__ uint2 ldx(const uint2* p) { uint2 r; asm volatile("ld.global.cg.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p)); return r; }
__device__ __forceinline__ float ldx(const float* p) { float r; asm volatile("ld.global.cg.f32 %0, [%1];" : "=f"(r) : "l"(p)); return r; }
__device__ __forceinline__ int ldx(const int* p) { int r; asm volatile("ld.global.cg.s32 %0, [%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ long long ldx(const long long* p) { long long r; asm volatile("ld.global.cg.s64 %0, [%1];" : "=l"(r) : "l"(p)); return r; }

__device__ __forceinline__ float warp_sum(float v) {
    for (int o = 16; o > 0; o >>= 1) v += __shfl_xor_sync(0xffffffffu, v, o);
    return v;
}

// Wait until a counter reaches its target. Watchdog: after about a second of spinning the launch is declared dead
// (ctr[100] = 1) and every wait in every block returns at once, so a bug can never leave a kernel spinning forever.
#define CABORT 100
__device__ __forceinline__ void wait_ctr(const Params* P, int which, unsigned target) {
    if (threadIdx.x == 0) {
        volatile unsigned* c = P->ctr;
        unsigned spins = 0;
        while ((int)(c[which] - target) < 0) {
            if ((spins++ & 1023u) == 1023u && (c[CABORT] || spins > (4u << 20))) { c[CABORT] = 1u; break; }
        }
    }
    __syncthreads();
}

// ---- shared-memory B fragments: [chunk][Ls lanes] of 8 bytes; Ls = 4 * (B rounded up to a power of two): only the
// lanes of the sequences in use exist.
__device__ __forceinline__ uint2 xget(const uint2* xf, int Ls, int chunk, int lane) { return lane < Ls ? xf[chunk * Ls + lane] : make_uint2(0u, 0u); }
// u16 index inside a per-sequence global fragment buffer [chunk][4 lanes]
__device__ __forceinline__ int gidx(int chunk, int kk) { return ((chunk * 4 + ((kk & 7) >> 1)) * 2 + (kk >> 3)) * 2 + (kk & 1); }

template <int N> __device__ __forceinline__ void tload(uint4* T, const uint4* p) {
#pragma unroll
    for (int i = 0; i < N; i++) T[i] = p[i * 32];
}

// norm weights of the next RMSNorm into shared memory: one 16-byte load per thread
__device__ __forceinline__ void nw_load(float* nw, const float* w) {
    const int tid = threadIdx.x;
    ((float4*)nw)[tid] = ((const float4*)w)[tid];
}

// ---- RMSNorm of the residual stream into B fragments. Thread i: row group i/4, rows 2s, 2s+1 and +8 (s = i%4): two
// 16-byte loads per pair of sequences, and its 8 bytes of output are exactly one lane of the B operand.
// emb != null: layer 0, the stream is the embedding rows (block 0 stores it).
__device__ __forceinline__ void norm_frag(const Params* P, const u16* emb, const long long* toks, int tstride, int tcol,
                                          const float* nw, int B, int Ls, uint2* xf, float* sm, bool store_x, float* dbg, float4* xo, int blk) {
    const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
    const int rg = tid >> 2, sub = tid & 3, g0 = 2 * sub, r0 = rg * 16 + g0;
    const int npair = (B + 1) >> 1;
    float4 ka = make_float4(0.f, 0.f, 0.f, 0.f), kb = ka;
    for (int t2 = 0; t2 < npair; t2++) {
        float4 xa, xb;      // xa: rows g0 and g0+8, xb: rows g0+1 and g0+9; (x, z) sequence 2*t2, (y, w) sequence 2*t2+1
        if (emb) {
            const u16* e0 = emb + (size_t)((unsigned long long)ldx(toks + (size_t)(2 * t2) * tstride + tcol) % VOCAB) * HID;
            xa = make_float4(b2f(e0[r0]), 0.f, b2f(e0[r0 + 8]), 0.f);
            xb = make_float4(b2f(e0[r0 + 1]), 0.f, b2f(e0[r0 + 9]), 0.f);
            if (2 * t2 + 1 < B) {
                const u16* e1 = emb + (size_t)((unsigned long long)ldx(toks + (size_t)(2 * t2 + 1) * tstride + tcol) % VOCAB) * HID;
                xa.y = b2f(e1[r0]); xa.w = b2f(e1[r0 + 8]); xb.y = b2f(e1[r0 + 1]); xb.w = b2f(e1[r0 + 9]);
            }
            if (rg == blk) { xo[g0 * 4 + t2] = xa; xo[(g0 + 1) * 4 + t2] = xb; }   // own 16 rows stay in shared memory
        } else {
            const uint4 r = ldx((const uint4*)(P->xc + t2 * 1024 + rg * 8 + g0));     // rows g0, g0+8 | g0+1, g0+9, two sequences each
            xa = make_float4(b2f((u16)r.x), b2f((u16)(r.x >> 16)), b2f((u16)r.y), b2f((u16)(r.y >> 16)));
            xb = make_float4(b2f((u16)r.z), b2f((u16)(r.z >> 16)), b2f((u16)r.w), b2f((u16)(r.w >> 16)));
        }
        if (t2 == 0) { ka = xa; kb = xb; }
        const float s0 = warp_sum(xa.x * xa.x + xa.z * xa.z + xb.x * xb.x + xb.z * xb.z);
        const float s1 = warp_sum(xa.y * xa.y + xa.w * xa.w + xb.y * xb.y + xb.w * xb.w);
        if (lane == 0) { sm[(2 * t2) * 16 + warp] = s0; sm[(2 * t2 + 1) * 16 + warp] = s1; }
        if (dbg) {
            dbg[(2 * t2) * HID + r0] = xa.x; dbg[(2 * t2) * HID + r0 + 8] = xa.z; dbg[(2 * t2) * HID + r0 + 1] = xb.x; dbg[(2 * t2) * HID + r0 + 9] = xb.z;
            if (2 * t2 + 1 < B) { dbg[(2 * t2 + 1) * HID + r0] = xa.y; dbg[(2 * t2 + 1) * HID + r0 + 8] = xa.w; dbg[(2 * t2 + 1) * HID + r0 + 1] = xb.y; dbg[(2 * t2 + 1) * HID + r0 + 9] = xb.w; }
        }
    }
    __syncthreads();
    const float2 wlo = *(const float2*)(nw + r0), whi = *(const float2*)(nw + r0 + 8);
    for (int t2 = 0; t2 < npair; t2++) {
        float4 xa = ka, xb = kb;
        if (t2 > 0) {
            if (emb) {
                const u16* e0 = emb + (size_t)((unsigned long long)ldx(toks + (size_t)(2 * t2) * tstride + tcol) % VOCAB) * HID;
                xa = make_float4(b2f(e0[r0]), 0.f, b2f(e0[r0 + 8]), 0.f);
                xb = make_float4(b2f(e0[r0 + 1]), 0.f, b2f(e0[r0 + 9]), 0.f);
                if (2 * t2 + 1 < B) {
                    const u16* e1 = emb + (size_t)((unsigned long long)ldx(toks + (size_t)(2 * t2 + 1) * tstride + tcol) % VOCAB) * HID;
                    xa.y = b2f(e1[r0]); xa.w = b2f(e1[r0 + 8]); xb.y = b2f(e1[r0 + 1]); xb.w = b2f(e1[r0 + 9]);
                }
            } else {
                const uint4 r = ldx((const uint4*)(P->xc + t2 * 1024 + rg * 8 + g0));
                xa = make_float4(b2f((u16)r.x), b2f((u16)(r.x >> 16)), b2f((u16)r.y), b2f((u16)(r.y >> 16)));
                xb = make_float4(b2f((u16)r.z), b2f((u16)(r.z >> 16)), b2f((u16)r.w), b2f((u16)(r.w >> 16)));
            }
        }
        for (int j = 0; j < 2; j++) {
            const int b = 2 * t2 + j;
            if (b >= B) break;
            float s = 0.f;
            for (int w = 0; w < 16; w++) s += sm[b * 16 + w];
            const float sc = rsqrtf(s * (1.0f / HID) + RMS_EPS);
            const u32 lo = fbits(wlo.x * ((j ? xa.y : xa.x) * sc)) | (fbits(wlo.y * ((j ? xb.y : xb.x) * sc)) << 16);   // rows g0, g0+1
            const u32 hi = fbits(whi.x * ((j ? xa.w : xa.z) * sc)) | (fbits(whi.y * ((j ? xb.w : xb.z) * sc)) << 16);   // rows g0+8, g0+9
            xf[rg * Ls + b * 4 + sub] = make_uint2(lo, hi);
        }
    }
    __syncthreads();
}

// Copy the B fragments of the sequences in use from a per-sequence global buffer into shared memory: nchunks (<= 256)
// chunks, src(b, chunk) = pointer to the 4 lanes of that chunk. One contiguous 16-byte load per thread and sequence.
template <class Src>
__device__ __forceinline__ void frag_copy(uint2* xf, int Ls, int nchunks, int B, Src src) {
    const int tid = threadIdx.x, chunk = tid >> 1, q = tid & 1;
    if (chunk >= nchunks) return;
    for (int b = 0; b < B; b++)
        *(uint4*)(xf + chunk * Ls + b * 4 + 2 * q) = ldx((const uint4*)(src(b, chunk) + 2 * q));
}

// Write one hidden unit of a SwiGLU (gate row g of the row group, up row g+8) into the per-sequence B fragments;
// chunk0: first chunk of the unit in hbuf.
__device__ __forceinline__ void h_store(const Params* P, const float4& c, int lr, int lane, int B, int chunk0) {
    const int g = lane >> 2, t = lane & 3;
    const int j = 8 * lr + g;
    for (int i = 0; i < 2; i++) {
        const int b = 2 * t + i;
        if (b < B) {
            const float gate = rb(cget(c, i)), up = rb(cget(c, 2 + i));
            ((u16*)(P->hbuf + (size_t)b * HCHUNKS * 4))[gidx(chunk0 + (j >> 4), j & 15)] = (u16)fbits(rb(silu(gate)) * up);
        }
    }
}

// Leader epilogue of a phase that produces the residual stream: x[rows of this block] = bf16(x + delta). The block
// is the only writer of its 16 rows, so their current value is kept in shared memory (xo) and never loaded.
__device__ __forceinline__ void x_update(const Params* P, int blk, int lane, int B, const float4& d, float4* xo) {
    const int g = lane >> 2, t = lane & 3;
    if (2 * t < B) {
        const float4 xq = xo[lane];
        const float4 xn = make_float4(rb(xq.x + d.x), rb(xq.y + d.y), rb(xq.z + d.z), rb(xq.w + d.w));
        xo[lane] = xn;
        P->xc[t * 1024 + blk * 8 + g] = make_uint2((__float_as_uint(xn.x) >> 16) | (__float_as_uint(xn.y) & 0xFFFF0000u), (__float_as_uint(xn.z) >> 16) | (__float_as_uint(xn.w) & 0xFFFF0000u));
    }
}

// ------------------------------------------------------------------------------------------------ attention
struct AttnSm {              // shared-memory views of an attention block
    uint4* qA;               // [8 dim chunks][32 lanes] q as mma A operand (rows = heads)
    float* cst;              // [0..127] q_norm w, [128..255] k_norm w, [256..263] sinks, [272..399] cos, [400..527] sin
    float* ks;               // [0..127] k of this position (float), [128..255] v of this position, [256..263] its attention weight, [272..399] rotary exchange of k
    float2* rq;              // [512] rotary exchange of q
    uint4* part;             // [16 warps][8][32] partial sums of the V mix; before that: K tiles of each warp's second key group
    uint4* v2;               // [14 warps][8][32] V tiles of the second key group of warps 0..13
    float* sm;
};

__device__ __forceinline__ void attn_consts(const Params* P, const LayerP& L, int kvg, int pos, const AttnSm& S) {
    const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
    if (warp == 11) ((float4*)S.cst)[lane] = ((const float4*)L.qn)[lane];
    if (warp == 12) ((float4*)S.cst)[32 + lane] = ((const float4*)L.kn)[lane];
    if (warp == 13 && lane < 2) ((float4*)S.cst)[64 + lane] = ((const float4*)L.sinks)[kvg * 2 + lane];
    if (warp == 14) ((float4*)S.cst)[68 + lane] = ((const float4*)(P->cosT + (size_t)pos * 128))[lane];
    if (warp == 15) ((float4*)S.cst)[100 + lane] = ((const float4*)(P->sinT + (size_t)pos * 128))[lane];
}

// Constants (shared memory) and the cached K and V tiles of this warp's first key group (registers T[0..7], T[8..15])
// of the layer this block serves next. Runs while the block is idle.
__device__ __forceinline__ void attn_stage(const Params* P, const LayerP& L, int b, int kvg, int pos, const AttnSm& S, uint4* T) {
    const int lane = threadIdx.x & 31, warp = threadIdx.x >> 5;
    const size_t cbase = ((size_t)(b * NKV + kvg) * P->kgmax) * 8 * 32;
    const int lo = L.sliding ? (pos - 512 > 0 ? pos - 512 : 0) : 0;
    const int kg0 = lo >> 4, nkg = pos > lo ? ((pos - 1) >> 4) - kg0 + 1 : 0;
    attn_consts(P, L, kvg, pos, S);
    if (warp < nkg) {
        tload<8>(T, L.kc + cbase + (size_t)(kg0 + warp) * 8 * 32 + lane);
        tload<8>(T + 8, L.vc + cbase + (size_t)(kg0 + warp) * 8 * 32 + lane);
    }
    // contexts over 256: the second key group of each warp goes to shared memory (slower than registers, but it is
    // loaded while the block is idle instead of on the attention's critical path)
    if (warp + 16 < nkg) {
        const uint4* kt = L.kc + cbase + (size_t)(kg0 + warp + 16) * 8 * 32 + lane;
        for (int dc = 0; dc < 8; dc++) S.part[(warp * 8 + dc) * 32 + lane] = kt[dc * 32];
        if (warp < 14) {
            const uint4* vt = L.vc + cbase + (size_t)(kg0 + warp + 16) * 8 * 32 + lane;
            for (int dc = 0; dc < 8; dc++) S.v2[(warp * 8 + dc) * 32 + lane] = vt[dc * 32];
        }
    }
}

// One (sequence b, K/V head kvg) pair = 8 query heads. The key of the current position is handled from registers.
// staged: attn_stage ran for this layer and position (T holds the K and V tiles of key group kg0 + warp).
__device__ __forceinline__ void attention(const Params* P, const LayerP& L, int b, int kvg, int pos, const AttnSm& S, const uint4* T, bool staged, int pblk, int* ppi) {
    const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, g = lane >> 2, t = lane & 3;
    float* sm = S.sm;
    const size_t cbase = ((size_t)(b * NKV + kvg) * P->kgmax) * 8 * 32;
    uint4* kc = L.kc + cbase;
    uint4* vc = L.vc + cbase;
    const int lo = L.sliding ? (pos - 512 > 0 ? pos - 512 : 0) : 0;
    const int kg0 = lo >> 4, nkg = pos > lo ? ((pos - 1) >> 4) - kg0 + 1 : 0;
    const float scaling = 0.08838834764831845f;
    if (!staged) attn_consts(P, L, kvg, pos, S);   // slow path: constants from global memory now
    // ---- stage 1: raw projections, contiguous 16-byte loads. Every thread: q (head i/64, row group (i/8)%8, g = i%8:
    //      dims rgi*16+g and +8); threads 0..63 also k, 64..127 also v (same dims)
    const int hq = tid >> 6, rgi = (tid >> 3) & 7, gq = tid & 7;
    const int d0 = rgi * 16 + gq, d1 = d0 + 8;
    float v0, v1, k0 = 0.f, k1 = 0.f;
    {
        const float4* qr = P->qraw + (size_t)b * 2560;
        const float4 p = ldx(qr + kvg * 512 + tid);
        v0 = rb(p.x + p.z); v1 = rb(p.y + p.w);
        const float ss = warp_sum(v0 * v0 + v1 * v1);
        if (lane == 0) sm[warp] = ss;
        if (tid < 128) {
            const float4 pk = ldx(qr + (tid < 64 ? (256 + kvg * 8) * 8 : (288 + kvg * 8) * 8 - 64) + tid);
            k0 = rb(pk.x + pk.z); k1 = rb(pk.y + pk.w);
            if (tid < 64) {
                const float sk = warp_sum(k0 * k0 + k1 * k1);
                if (lane == 0) sm[16 + warp] = sk;
            }
        }
    }
    PROFX(61);
    __syncthreads();
    // ---- stage 2: norms, rotary (partner dim d^64 is 32 threads away: exchanged through shared memory), fragments, cache stores
    {
        const float sc = rsqrtf((sm[2 * hq] + sm[2 * hq + 1]) * (1.0f / 128) + RMS_EPS);
        v0 = rb(S.cst[d0] * (v0 * sc)); v1 = rb(S.cst[d1] * (v1 * sc));
        if (tid < 64) {
            const float sck = rsqrtf((sm[16] + sm[17]) * (1.0f / 128) + RMS_EPS);
            k0 = rb(S.cst[128 + d0] * (k0 * sck)); k1 = rb(S.cst[128 + d1] * (k1 * sck));
        }
        if (L.sliding) {
            S.rq[tid] = make_float2(v0, v1);
            if (tid < 64) ((float2*)(S.ks + 272))[tid] = make_float2(k0, k1);
            __syncthreads();
            const float c0 = S.cst[272 + d0], s0 = S.cst[400 + d0], c1 = S.cst[272 + d1], s1 = S.cst[400 + d1];
            const float2 pq = S.rq[tid ^ 32];
            v0 = rb(rb(v0 * c0) + rb((d0 < 64 ? -pq.x : pq.x) * s0));
            v1 = rb(rb(v1 * c1) + rb((d1 < 64 ? -pq.y : pq.y) * s1));
            if (tid < 64) {
                const float2 pk = ((const float2*)(S.ks + 272))[tid ^ 32];
                k0 = rb(rb(k0 * c0) + rb((d0 < 64 ? -pk.x : pk.x) * s0));
                k1 = rb(rb(k1 * c1) + rb((d1 < 64 ? -pk.y : pk.y) * s1));
            }
        }
        u16* q16 = (u16*)(S.qA + rgi * 32);
        q16[aidx(hq, gq)] = (u16)fbits(v0);
        q16[aidx(hq, gq + 8)] = (u16)fbits(v1);
        const int kg = pos >> 4, tm = pos & 15;
        if (tid < 64) {
            S.ks[d0] = k0; S.ks[d1] = k1;
            u16* k16 = (u16*)(kc + (size_t)(kg * 8 + rgi) * 32);
            k16[kidx(tm, gq)] = (u16)fbits(k0);
            k16[kidx(tm, gq + 8)] = (u16)fbits(k1);
        } else if (tid < 128) {
            S.ks[128 + d0] = k0; S.ks[128 + d1] = k1;
            u16* v16 = (u16*)(vc + (size_t)(kg * 8 + rgi) * 32);
            v16[aidx(gq, tm)] = (u16)fbits(k0);
            v16[aidx(gq + 8, tm)] = (u16)fbits(k1);
        }
    }
    PROFX(62);
    __syncthreads();
    PROFX(63);
    // ---- stage 3: score of the current key (partial per warp), scores of the cached keys, per-warp maxima.
    //      Warp w owns key groups kg0 + w (scores e0), + 16, + 32, ... (contexts over 256: ex).
    //      Thread (g, t): head g, keys 2t, 2t+1, 2t+8, 2t+9 of each group.
    float e0[4] = {-INFINITY, -INFINITY, -INFINITY, -INFINITY};
    float ex[7][4];
    {
        const float ps = warp_sum(v0 * S.ks[d0] + v1 * S.ks[d1]);
        if (lane == 0) sm[64 + warp] = ps;
        float mx = -INFINITY;
        int j = 0;
        for (int i = warp; i < nkg; i += 16, j++) {
            float4 c0 = make_float4(0.f, 0.f, 0.f, 0.f), c1 = c0;
            if (j == 0 && staged) {
#pragma unroll
                for (int dc = 0; dc < 8; dc++) {
                    const uint4 a = S.qA[dc * 32 + lane];
                    mma(c0, a, make_uint2(T[dc].x, T[dc].y));
                    mma(c1, a, make_uint2(T[dc].z, T[dc].w));
                }
            } else {
                const uint4* kt = (j == 1 && staged ? S.part + (size_t)warp * 8 * 32 : kc + (size_t)(kg0 + i) * 8 * 32) + lane;
                for (int dc = 0; dc < 8; dc++) {
                    const uint4 k = kt[dc * 32];
                    const uint4 a = S.qA[dc * 32 + lane];
                    mma(c0, a, make_uint2(k.x, k.y));
                    mma(c1, a, make_uint2(k.z, k.w));
                }
            }
            const int base = (kg0 + i) * 16 + 2 * t;
            const float q0 = (base >= lo && base < pos) ? c0.x * scaling : -INFINITY;
            const float q1 = (base + 1 >= lo && base + 1 < pos) ? c0.y * scaling : -INFINITY;
            const float q2 = (base + 8 >= lo && base + 8 < pos) ? c1.x * scaling : -INFINITY;
            const float q3 = (base + 9 >= lo && base + 9 < pos) ? c1.y * scaling : -INFINITY;
            if (j == 0) { e0[0] = q0; e0[1] = q1; e0[2] = q2; e0[3] = q3; }
            else { ex[j - 1][0] = q0; ex[j - 1][1] = q1; ex[j - 1][2] = q2; ex[j - 1][3] = q3; }
            mx = fmaxf(fmaxf(mx, fmaxf(q0, q1)), fmaxf(q2, q3));
        }
        mx = fmaxf(mx, __shfl_xor_sync(0xffffffffu, mx, 1));
        mx = fmaxf(mx, __shfl_xor_sync(0xffffffffu, mx, 2));
        if (t == 0) sm[128 + warp * 8 + g] = mx;
    }
    PROFX(64);
    __syncthreads();
    // ---- stage 4: softmax with the sink (per head g): maximum, exponentials, partial sums
    const float sink = S.cst[256 + g];
    const float self = (sm[64 + 2 * g] + sm[64 + 2 * g + 1]) * scaling;
    float M = fmaxf(sink, self);
    {
        float m = -INFINITY;
        for (int w = t; w < 16; w += 4) m = fmaxf(m, sm[128 + w * 8 + g]);
        m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, 1));
        m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, 2));
        M = fmaxf(M, m);
        float s = 0.f;
        for (int q = 0; q < 4; q++) { e0[q] = __expf(e0[q] - M); s += e0[q]; }
        int j = 1;
        for (int i = warp + 16; i < nkg; i += 16, j++)
            for (int q = 0; q < 4; q++) { ex[j - 1][q] = __expf(ex[j - 1][q] - M); s += ex[j - 1][q]; }
        s += __shfl_xor_sync(0xffffffffu, s, 1);
        s += __shfl_xor_sync(0xffffffffu, s, 2);
        if (t == 0) sm[272 + warp * 8 + g] = s;
    }
    PROFX(65);
    __syncthreads();
    // ---- stage 5: weights (BF16) straight into the B operand of the V mix; sums [dim 16][head 8] per dim chunk
    {
        float Ssum = 0.f;
        for (int w = t; w < 16; w += 4) Ssum += sm[272 + w * 8 + g];
        Ssum += __shfl_xor_sync(0xffffffffu, Ssum, 1);
        Ssum += __shfl_xor_sync(0xffffffffu, Ssum, 2);
        Ssum += __expf(sink - M) + __expf(self - M);
        if (warp == 0 && t == 0) S.ks[256 + g] = rb(__expf(self - M) / Ssum);
        float4 acc[8];
        {
            const uint2 wb = make_uint2(fbits(e0[0] / Ssum) | (fbits(e0[1] / Ssum) << 16), fbits(e0[2] / Ssum) | (fbits(e0[3] / Ssum) << 16));
            const bool have = warp < nkg;
            const uint4* vt = vc + (size_t)(kg0 + warp) * 8 * 32 + lane;
#pragma unroll
            for (int dc = 0; dc < 8; dc++) {
                float4 a4 = make_float4(0.f, 0.f, 0.f, 0.f);
                if (have) {
                    if (staged) mma(a4, T[8 + dc], wb);
                    else { const uint4 a = vt[dc * 32]; mma(a4, a, wb); }
                }
                acc[dc] = a4;
            }
        }
        int j = 1;
        for (int i = warp + 16; i < nkg; i += 16, j++) {
            const uint2 wb = make_uint2(fbits(ex[j - 1][0] / Ssum) | (fbits(ex[j - 1][1] / Ssum) << 16), fbits(ex[j - 1][2] / Ssum) | (fbits(ex[j - 1][3] / Ssum) << 16));
            const uint4* vt = (j == 1 && staged && warp < 14 ? S.v2 + (size_t)warp * 8 * 32 : vc + (size_t)(kg0 + i) * 8 * 32) + lane;
#pragma unroll
            for (int dc = 0; dc < 8; dc++) { const uint4 a = vt[dc * 32]; mma(acc[dc], a, wb); }
        }
#pragma unroll
        for (int dc = 0; dc < 8; dc++) S.part[(warp * 8 + dc) * 32 + lane] = *(const uint4*)&acc[dc];
    }
    PROFX(66);
    __syncthreads();
    PROFX(67);
    // ---- stage 6: leaders (warp dc < 8): sum over the warps that had keys, add the current key's term, and store
    //      each head's 16 dims of this dim chunk as one 8-byte lane of the per-sequence fragment buffer
    if (warp < 8) {
        const int dc = warp, nw = nkg < 16 ? nkg : 16;
        float4 c = make_float4(0.f, 0.f, 0.f, 0.f);
        for (int w = 0; w < nw; w++) c = f4add(c, *(const float4*)&S.part[(w * 8 + dc) * 32 + lane]);
        // c: (dim g, head 2t), (dim g, head 2t+1), (dim g+8, head 2t), (dim g+8, head 2t+1)
        const float vlo = S.ks[128 + dc * 16 + g], vhi = S.ks[128 + dc * 16 + g + 8];
        const float wa = S.ks[256 + 2 * t], wbb = S.ks[256 + 2 * t + 1];
        const u32 b00 = fbits(c.x + wa * vlo), b01 = fbits(c.y + wbb * vlo), b10 = fbits(c.z + wa * vhi), b11 = fbits(c.w + wbb * vhi);
        // partner lane g^1 (lane ^ 4) holds the odd dim of the pair
        const u32 p00 = __shfl_xor_sync(0xffffffffu, b00, 4), p01 = __shfl_xor_sync(0xffffffffu, b01, 4);
        const u32 p10 = __shfl_xor_sync(0xffffffffu, b10, 4), p11 = __shfl_xor_sync(0xffffffffu, b11, 4);
        // hand the packed lanes to warp 0 through shared memory: [dc][head parity][t][g/2]
        if (!(g & 1)) {
            uint2* pk = (uint2*)S.rq;
            pk[(dc * 2 + 0) * 16 + t * 4 + (g >> 1)] = make_uint2(b00 | (p00 << 16), b10 | (p10 << 16));
            pk[(dc * 2 + 1) * 16 + t * 4 + (g >> 1)] = make_uint2(b01 | (p01 << 16), b11 | (p11 << 16));
        }
    }
    __syncthreads();
    if (warp == 0 && lane < 16) {
        // lane = t*4 + g/2: head 2t (+1), lane g/2 of the chunk; 16 store instructions, each 16 lanes on 4 lines
        const int tt = lane >> 2, gh = lane & 3;
        const uint2* pk = (const uint2*)S.rq;
        uint2* out = P->attnf + (size_t)b * 256 * 4;
        for (int dc = 0; dc < 8; dc++) {
            out[((kvg * 8 + 2 * tt) * 8 + dc) * 4 + gh] = pk[(dc * 2 + 0) * 16 + lane];
            out[((kvg * 8 + 2 * tt + 1) * 8 + dc) * 4 + gh] = pk[(dc * 2 + 1) * 16 + lane];
        }
    }
    PROFX(68);
    if (warp == 0) { if (P->fence) __threadfence(); }
    __syncthreads();
}

// ------------------------------------------------------------------------------------------------ router top-k
// In every main block. Per sequence: each of 8 warps extracts its 6 largest sigmoid scores (6 rounds of warp max);
// then ONE warp holds the 48 candidates (two per lane) and extracts the 6 best the same way. Ties go to the lower
// expert id. Then the union over the batch in ascending expert id ("units").
// un[0] = number of units, un[1 + u] = expert of unit u; uwl[u*8 + b] = routing weight (0: not a member).
__device__ __forceinline__ void route_local(const Params* P, const float* rl, int B, float* sm, int* smi, int* un, float* uwl, int pblk, int* ppi) {
    const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
    for (int b = 0; b < B; b++) {
        if (tid < NEXP) {
            float v = 1.0f / (1.0f + __expf(-ldx(rl + b * NEXP + tid)));
            for (int r = 0; r < TOPK; r++) {
                float m = v;
                for (int o = 16; o > 0; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, o));
                const int win = __ffs(__ballot_sync(0xffffffffu, v == m)) - 1;
                if (lane == 0) { sm[warp * 6 + r] = m; smi[warp * 6 + r] = warp * 32 + win; }
                if (lane == win) v = -INFINITY;
            }
        }
        PROFX(71);
        __syncthreads();
        PROFX(72);
        if (warp == 0) {
            // lane holds candidates lane (a) and lane + 32 (c, lanes 0..15); a warp's list is sorted, lists are in id order
            float va = sm[lane], vc = lane < 16 ? sm[32 + lane] : -INFINITY;
            const int ia = smi[lane], ic = lane < 16 ? smi[32 + lane] : 1 << 20;
            float sum = 0.f, ts[TOPK]; int ti[TOPK];
            for (int r = 0; r < TOPK; r++) {
                float m = fmaxf(va, vc);
                for (int o = 16; o > 0; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, o));
                // among the lanes holding m take the smallest expert id
                int id = va == m ? ia : (vc == m ? ic : 1 << 20);
                for (int o = 16; o > 0; o >>= 1) id = min(id, __shfl_xor_sync(0xffffffffu, id, o));
                if (va == m && ia == id) va = -INFINITY; else if (vc == m && ic == id) vc = -INFINITY;
                ts[r] = m; ti[r] = id; sum += m;
            }
            if (lane < TOPK) { sm[64 + b * 8 + lane] = ts[lane] / sum; smi[64 + b * 8 + lane] = ti[lane]; }
        }
        PROFX(73);
        __syncthreads();
    }
    const bool ent = tid < 8 * B && (tid & 7) < TOPK;
    if (ent) {
        const int id = smi[64 + tid];
        int first = 1;
        for (int j = 0; j < tid; j++) if ((j & 7) < TOPK && smi[64 + j] == id) first = 0;
        smi[128 + tid] = first;
    }
    if (B > 1 && tid < MAXU * MAXB) uwl[tid] = 0.f;
    if (B > 1) __syncthreads();
    if (ent) {
        const int id = smi[64 + tid];
        int u = 0, n = 0;
        if (B == 1) { n = TOPK; for (int j = 0; j < TOPK; j++) u += smi[64 + j] < id; }
        else for (int j = 0; j < 8 * B; j++) if ((j & 7) < TOPK && smi[128 + j]) { n++; u += smi[64 + j] < id; }
        if (u < MAXU) { un[1 + u] = id & 255; uwl[u * MAXB + (tid >> 3)] = sm[64 + tid]; }
        if (tid == 0) un[0] = n;
    }
    __syncthreads();
}

// ------------------------------------------------------------------------------------------------ the kernel
// shared memory map (bytes)
#define SM_SM 0                  // 4K: 1024 floats (the last 128: this block's own rows of the residual stream)
#define SM_SMI (4 << 10)         // 2K: 512 ints   | attention: rotary exchange of q (4K, with SM_UN)
#define SM_UN (6 << 10)          // 2K: units
#define SM_NW (8 << 10)          // 8K: norm weights of the next norm
#define SM_RED (16 << 10)        // 16K: 32 partial slots
#define SM_QA (32 << 10)         // 4K: q as A operand
#define SM_CST (36 << 10)        // 4K: attention constants and the current key/value
#define SM_XF (40 << 10)         // 64K: B fragments (256 chunks x Ls lanes x 8 bytes)
#define SM_PART (104 << 10)      // 64K: attention partial sums
#define SM_V2 (168 << 10)        // 56K: attention: V tiles of second key groups
#define SM_TOTAL (224 << 10)
#define NTHR 512

// mode 0: one step, logits out. mode 1: nsteps greedy steps into gen_out [B][nsteps] (int64).
// mode 2: served cohort: npre prompt steps without the head, then nsteps greedy steps into P->gen [B][maxctx] (int32), progress in ctr[96].
// tok_in[b * tstride + step] for the forced steps (0 .. npre) ; later inputs are the chosen tokens.
__global__ void __launch_bounds__(NTHR, 1)
mk_kernel(const Params* Pp, const long long* tok_in, int tstride, float* logits, long long* gen_out, int B, int pos0, int npre, int nsteps, int mode,
          unsigned tm0, unsigned tx0, unsigned tr0) {
    extern __shared__ uint4 smem[];
    const Params* P = Pp;
    const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31, g = lane >> 2, t = lane & 3;
    const int blk = blockIdx.x;
    const bool is_main = blk < NMAIN;
    const int aux = blk - NMAIN;
    const bool is_router = aux >= NAUX - NROUT;
    const int rj = aux - (NAUX - NROUT);                      // router row group of this block
    const int nattn = 4 * B < NAUX ? 4 * B : NAUX;            // attention blocks
    const bool has_attn = !is_main && aux < nattn;
    const bool has_attn2 = !is_main && aux + NAUX < 4 * B;
    const bool stg = !is_router;                               // attention K/V tiles in registers (router blocks keep router tiles there)
    const int Ls = B <= 1 ? 4 : B <= 2 ? 8 : B <= 4 ? 16 : 32;   // lanes per chunk of the shared-memory B fragments
    char* sb = (char*)smem;
    float* sm = (float*)(sb + SM_SM);
    int* smi = (int*)(sb + SM_SMI);
    int* un = (int*)(sb + SM_UN);
    float* uwl = (float*)(un + 64);
    float* nw = (float*)(sb + SM_NW);
    float4* red = (float4*)(sb + SM_RED);
    uint2* xf = (uint2*)(sb + SM_XF);
    float4* xo = (float4*)(sm + 896);            // this block's own 16 rows of the residual stream
    AttnSm AS;
    AS.qA = (uint4*)(sb + SM_QA); AS.cst = (float*)(sb + SM_CST); AS.ks = AS.cst + 528; AS.rq = (float2*)(sb + SM_SMI);
    AS.part = (uint4*)(sb + SM_PART); AS.v2 = (uint4*)(sb + SM_V2); AS.sm = sm;
#ifdef MK_PROF
    int pi = 0;
#define PPI (&pi)
    if (aux == 7) {
        if (tid == 0) {
            unsigned n = 0;
            volatile unsigned* stop = P->clk + 1;
            volatile unsigned* c = P->clk;
            while (true) { n++; *c = n; if ((n & 255u) == 0 && *stop) break; }
        }
        return;
    }
#endif
#ifndef MK_PROF
#define PPI nullptr
#endif
    // zero what is never written: fragment lanes of unused sequences, rows 8..15 of the q operand
    for (int i = tid; i < (64 << 10) / 4; i += NTHR) ((u32*)xf)[i] = 0u;
    for (int i = tid; i < 1024; i += NTHR) ((u32*)AS.qA)[i] = 0u;
    __syncthreads();

    unsigned tm = tm0, tx = tx0, tr = tr0;
    const float4 zero4 = make_float4(0.f, 0.f, 0.f, 0.f);
    const int total = npre + nsteps;
    uint4 T[16];        // weight tiles loaded ahead into registers (main: next phase; router: its 8 tiles; attention: K and V tiles)

    for (int step = 0; step < total; step++) {
        if (tid == 0) smi[500] = (int)*(volatile unsigned*)(P->ctr + CABORT);
        __syncthreads();
        if (smi[500]) break;                      // a wait gave up somewhere: leave
        const int pos = pos0 + step;
        const bool forced = step <= npre;
        const long long* toks = forced ? tok_in : P->curtok;
        const int ts = forced ? tstride : 1, tcol = forced ? step : 0;
        const bool do_head = step >= npre;
        if (is_main) {
            tload<16>(T, P->L[0].qkv + (size_t)(blk * 320 + 20 * warp) * 32 + lane);
            nw_load(nw, P->L[0].ln1);
            if (step > 0) wait_ctr(P, CM, tm); else __syncthreads();
        } else {
            if (has_attn && stg && step == 0) attn_stage(P, P->L[0], aux >> 2, aux & 3, pos, AS, T);
            if (is_router && step == 0) { tload<8>(T, P->L[2].router + (size_t)(rj * 128 + 8 * warp) * 32 + lane); nw_load(nw, P->L[2].ln2); }
            __syncthreads();
        }

        for (int l = 0; l < NLAYER; l++) {
            const LayerP& L = P->L[l];
            if (is_main) {
                // ============ A: input norm, q/k/v projections. A block owns 320 consecutive tiles (5 half row groups), 20 per warp.
                PROF(1);
                norm_frag(P, l == 0 ? P->embed : nullptr, toks, ts, tcol, nw, B, Ls, xf, sm, blk == 0, (P->dbg && blk == 0) ? P->dbg + (size_t)l * MAXB * HID : nullptr, xo, blk);
                PROF(2);
                {
                    const int g0 = 20 * warp;
                    int nA = 64 - (g0 & 63); if (nA > 20) nA = 20;
                    float4 cA = zero4, cB = zero4;
                    const uint4* wt = L.qkv + (size_t)(blk * 320 + g0) * 32 + lane;
#pragma unroll
                    for (int i = 0; i < 16; i++) {
                        const uint2 bb = xget(xf, Ls, (blk * 320 + g0 + i) & 127, lane);
                        if (i < nA) mma(cA, T[i], bb); else mma(cB, T[i], bb);
                    }
                    for (int i = 16; i < 20; i++) {
                        const uint4 a = wt[i * 32];
                        const uint2 bb = xget(xf, Ls, (blk * 320 + g0 + i) & 127, lane);
                        if (i < nA) mma(cA, a, bb); else mma(cB, a, bb);
                    }
                    red[(warp * 2) * 32 + lane] = cA;
                    red[(warp * 2 + 1) * 32 + lane] = cB;
                }
                PROF(31);
                __syncthreads();
                PROF(32);
                if (warp == 0) {
                    for (int h = 0; h < 5; h++) {
                        const int w_lo = (64 * h) / 20, w_hi = (64 * h + 63) / 20;
                        float4 c = zero4;
                        for (int w = w_lo; w <= w_hi; w++) c = f4add(c, red[(w * 2 + (((20 * w) >> 6) == h ? 0 : 1)) * 32 + lane]);
                        // half hh of row group rg of the stacked [q; k; v] matrix: one 8-byte store per lane and sequence
                        const int hg = blk * 5 + h, rg = hg >> 1, hh = hg & 1;
                        for (int j = 0; j < 2; j++) {
                            const int b = 2 * t + j;
                            if (b < B) ((float2*)(P->qraw + (size_t)b * 2560 + rg * 8 + g))[hh] = j ? make_float2(c.y, c.w) : make_float2(c.x, c.z);
                        }
                    }
                    PROF(33);
                    if (P->fence) __threadfence();
                    PROF(34);
                    if (tid == 0) atomicAdd(P->ctr + CM, 1u);
                }
                __syncthreads();      // the leader's stores, fence and counter go out before the preload traffic
                tm += NMAIN;
                PROF(3);
                tload<16>(T, L.o + (size_t)(blk * 256 + 16 * warp) * 32 + lane);      // preload C
                nw_load(nw, L.ln2);
                PROF(35);
                // ============ (B: attention on the aux blocks) ============ C: output projection + residual
                tx += nattn;
                wait_ctr(P, CX, tx);
                PROF(4);
                frag_copy(xf, Ls, 256, B, [&](int b, int chunk) { return P->attnf + ((size_t)b * 256 + chunk) * 4; });
                __syncthreads();
                {
                    float4 c = zero4;
#pragma unroll
                    for (int i = 0; i < 16; i++) mma(c, T[i], xget(xf, Ls, 16 * warp + i, lane));
                    red[warp * 32 + lane] = c;
                }
                __syncthreads();
                if (warp == 0) {
                    float4 c = red[lane];
                    for (int w = 1; w < 16; w++) c = f4add(c, red[w * 32 + lane]);
                    x_update(P, blk, lane, B, make_float4(rb(c.x), rb(c.y), rb(c.z), rb(c.w)), xo);
                    if (P->fence) __threadfence();
                    if (tid == 0) atomicAdd(P->ctr + CM, 1u);
                }
                __syncthreads();
                tm += NMAIN;
                PROF(5);
                if (L.moe) {
                    tload<8>(T, L.sgu + (size_t)(blk * 128 + 8 * warp) * 32 + lane);   // preload D
                    // ============ D: post-attention norm; shared expert gate/up (router logits on aux)
                    wait_ctr(P, CM, tm);
                    PROF(6);
                    norm_frag(P, nullptr, nullptr, 1, 0, nw, B, Ls, xf, sm, false, nullptr, xo, -1);
                    PROF(51);
                    {
                        float4 c = zero4;
#pragma unroll
                        for (int i = 0; i < 8; i++) mma(c, T[i], xget(xf, Ls, 8 * warp + i, lane));
                        red[(16 + warp) * 32 + lane] = c;        // slots 16..31: the expert phase below uses 0..15
                    }
                    PROF(52);
                    __syncthreads();
                    if (warp == 0) {
                        float4 c = red[16 * 32 + lane];
                        for (int w = 1; w < 16; w++) c = f4add(c, red[(16 + w) * 32 + lane]);
                        h_store(P, c, blk, lane, B, HSLOT_SHARED * 32);
                    }
                    tr += NROUT;
                    PROF(7);
                    // ============ E (same main phase: no hand-over between D and E): routing in every main block as soon as
                    // the router blocks are done, then expert gate/up: 64 row groups per unit, 3 teams of 5 warps
                    wait_ctr(P, CR, tr);
                    PROF(8);
                    route_local(P, P->rl, B, sm, smi, un, uwl, blk, PPI);
                    PROF(9);
                    const int U = un[0] < 6 * B ? (un[0] > 0 ? un[0] : 1) : 6 * B;
                    {
                        const int G = U * 64;
                        const int e0 = blk * G / NMAIN, e1 = (blk + 1) * G / NMAIN;
                        const int team = warp / 5, wi = warp - team * 5;
                        for (int r = e0; r < e1; r += 3) {
                            const int rg = r + team;
                            const bool act = team < 3 && rg < e1;
                            const int u = rg >> 6, lr = rg & 63;
                            float4 c = zero4;
                            if (act) {
                                const int c0 = wi * 128 / 5, c1 = (wi + 1) * 128 / 5;
                                const uint4* wt = L.egu + (size_t)((un[1 + u] & 255) * 64 + lr) * 128 * 32 + lane;
                                int ch = c0;
                                for (; ch + 8 <= c1; ch += 8) {
                                    tload<8>(T, wt + ch * 32);
#pragma unroll
                                    for (int i = 0; i < 8; i++) mma(c, T[i], xget(xf, Ls, ch + i, lane));
                                }
                                for (; ch < c1; ch++) { const uint4 a = wt[ch * 32]; mma(c, a, xget(xf, Ls, ch, lane)); }
                            }
                            red[warp * 32 + lane] = c;
                            __syncthreads();
                            if (warp == 0) {
                                for (int q = 0; q < 3 && r + q < e1; q++) {
                                    float4 cq = red[(q * 5) * 32 + lane];
                                    for (int w = 1; w < 5; w++) cq = f4add(cq, red[(q * 5 + w) * 32 + lane]);
                                    h_store(P, cq, (r + q) & 63, lane, B, ((r + q) >> 6) * 32);
                                }
                            }
                            if (r + 3 < e1) __syncthreads();
                        }
                    }
                    if (warp == 0) {
                        if (P->fence) __threadfence();
                        if (tid == 0) atomicAdd(P->ctr + CM, 1u);
                    }
                    __syncthreads();
                    tm += NMAIN;
                    PROF(10);
                    // preload F: the first 8 items (item = warp/2: units in ascending order, then the two halves of the shared expert)
                    const int wj = warp & 1;
                    {
                        const int it = warp >> 1;
                        if (it < U) tload<16>(T, L.edown + ((size_t)((un[1 + it] & 255) * 128 + blk) * 32 + 16 * wj) * 32 + lane);
                        else if (it < U + 2) tload<16>(T, L.sdown + ((size_t)(blk * 64 + (it - U) * 32) + 16 * wj) * 32 + lane);
                    }
                    PROF(48);
                    // ============ F: down projections (items of 32 chunks, 2 warps each), routing weights, shared expert, residual
                    wait_ctr(P, CM, tm);
                    PROF(11);
                    {
                        const int nitems = U + 2;
                        float fin[4] = {0.f, 0.f, 0.f, 0.f}, sh[4] = {0.f, 0.f, 0.f, 0.f};
                        for (int it0 = 0; it0 < nitems; it0 += 8) {
                            const int it = it0 + (warp >> 1);
                            frag_copy(xf, Ls, 256, B, [&](int b, int chunk) {
                                const int itc = it0 + (chunk >> 5);
                                const int hs = itc < U ? itc : HSLOT_SHARED + (itc - U < 2 ? itc - U : 0);
                                return P->hbuf + ((size_t)b * HCHUNKS + hs * 32 + (chunk & 31)) * 4;
                            });
                            PROF(41);
                            __syncthreads();
                            PROF(42);
                            float4 c = zero4;
                            if (it < nitems) {
                                if (it0 > 0) {
                                    if (it < U) tload<16>(T, L.edown + ((size_t)((un[1 + it] & 255) * 128 + blk) * 32 + 16 * wj) * 32 + lane);
                                    else tload<16>(T, L.sdown + ((size_t)(blk * 64 + (it - U) * 32) + 16 * wj) * 32 + lane);
                                }
#pragma unroll
                                for (int i = 0; i < 16; i++) mma(c, T[i], xget(xf, Ls, (warp >> 1) * 32 + 16 * wj + i, lane));
                            }
                            red[warp * 32 + lane] = c;
                            PROF(43);
                            __syncthreads();
                            PROF(44);
                            // team leaders: the item's sum; an expert's output is rounded to BF16 and scaled by its routing weight
                            if (wj == 0 && it < nitems) {
                                float4 cq = f4add(red[warp * 32 + lane], red[(warp + 1) * 32 + lane]);
                                if (it < U) {
                                    const float wa = 2 * t < B ? uwl[it * MAXB + 2 * t] : 0.f, wb = 2 * t + 1 < B ? uwl[it * MAXB + 2 * t + 1] : 0.f;
                                    cq = make_float4(rb(cq.x) * wa, rb(cq.y) * wb, rb(cq.z) * wa, rb(cq.w) * wb);
                                }
                                red[(16 + (warp >> 1)) * 32 + lane] = cq;
                            }
                            __syncthreads();
                            if (warp == 0) {
                                for (int q = 0; q < 8 && it0 + q < nitems; q++) {
                                    const float4 cq = red[(16 + q) * 32 + lane];
                                    if (it0 + q < U) { fin[0] += cq.x; fin[1] += cq.y; fin[2] += cq.z; fin[3] += cq.w; }
                                    else { sh[0] += cq.x; sh[1] += cq.y; sh[2] += cq.z; sh[3] += cq.w; }
                                }
                            }
                            if (it0 + 8 < nitems) __syncthreads();
                        }
                        PROF(45);
                        if (warp == 0) {
                            x_update(P, blk, lane, B, make_float4(rb(rb(fin[0]) + rb(sh[0])), rb(rb(fin[1]) + rb(sh[1])), rb(rb(fin[2]) + rb(sh[2])), rb(rb(fin[3]) + rb(sh[3]))), xo);
                            PROF(46);
                            if (P->fence) __threadfence();
                            PROF(47);
                            if (tid == 0) atomicAdd(P->ctr + CM, 1u);
                        }
                        __syncthreads();
                        tm += NMAIN;
                    }
                    PROF(12);
                } else {
                    // ============ dense MLP (layers 0 and 1). D': gate/up, 768 consecutive tiles (6 row groups) per block, 48 per warp
                    wait_ctr(P, CM, tm);
                    norm_frag(P, nullptr, nullptr, 1, 0, nw, B, Ls, xf, sm, false, nullptr, xo, -1);
                    {
                        const int g0 = 48 * warp;
                        int nA = 128 - (g0 & 127); if (nA > 48) nA = 48;
                        float4 cA = zero4, cB = zero4;
                        const uint4* wt = L.dgu + (size_t)(blk * 768 + g0) * 32 + lane;
                        for (int i = 0; i < 48; i++) {
                            const uint4 a = wt[(size_t)i * 32];
                            const uint2 bb = xget(xf, Ls, (g0 + i) & 127, lane);
                            if (i < nA) mma(cA, a, bb); else mma(cB, a, bb);
                        }
                        red[(warp * 2) * 32 + lane] = cA;
                        red[(warp * 2 + 1) * 32 + lane] = cB;
                    }
                    __syncthreads();
                    if (warp == 0) {
                        for (int h = 0; h < 6; h++) {
                            const int w_lo = (128 * h) / 48, w_hi = (128 * h + 127) / 48;
                            float4 c = zero4;
                            for (int w = w_lo; w <= w_hi; w++) c = f4add(c, red[(w * 2 + (((48 * w) >> 7) == h ? 0 : 1)) * 32 + lane]);
                            h_store(P, c, blk * 6 + h, lane, B, 0);
                        }
                        if (P->fence) __threadfence();
                        if (tid == 0) atomicAdd(P->ctr + CM, 1u);
                    }
                    tm += NMAIN;
                    // E': down projection (K = 6144: 384 tiles per block, 24 per warp) + residual
                    wait_ctr(P, CM, tm);
                    {
                        float4 c = zero4;
                        const uint4* wt = L.ddown + (size_t)(blk * 384 + 24 * warp) * 32 + lane;
                        const uint2* hb = P->hbuf + ((size_t)(lane >> 2) * HCHUNKS + 24 * warp) * 4 + (lane & 3);
                        for (int i = 0; i < 24; i++) {
                            const uint4 a = wt[(size_t)i * 32];
                            uint2 bb = make_uint2(0u, 0u);
                            if (lane < 4 * B) bb = ldx(hb + i * 4);
                            mma(c, a, bb);
                        }
                        red[warp * 32 + lane] = c;
                    }
                    __syncthreads();
                    if (warp == 0) {
                        float4 c = red[lane];
                        for (int w = 1; w < 16; w++) c = f4add(c, red[w * 32 + lane]);
                        x_update(P, blk, lane, B, make_float4(rb(c.x), rb(c.y), rb(c.z), rb(c.w)), xo);
                        if (P->fence) __threadfence();
                        if (tid == 0) atomicAdd(P->ctr + CM, 1u);
                    }
                    __syncthreads();
                    tm += NMAIN;
                }
                // preload A of the next layer (or the final norm weights), then wait for every main block
                if (l + 1 < NLAYER) {
                    tload<16>(T, P->L[l + 1].qkv + (size_t)(blk * 320 + 20 * warp) * 32 + lane);
                    nw_load(nw, P->L[l + 1].ln1);
                } else nw_load(nw, P->fnorm);
                PROF(49);
                if (l + 1 < NLAYER || do_head) wait_ctr(P, CM, tm);
            } else {
                // ---------------- aux blocks
                const unsigned tmA = tm + NMAIN, tmC = tmA + NMAIN;
                if (has_attn) {
                    wait_ctr(P, CM, tmA);
                    PROF(21);
                    attention(P, L, aux >> 2, aux & 3, pos, AS, T, stg, blk, PPI);
                    if (has_attn2) attention(P, L, (aux + NAUX) >> 2, (aux + NAUX) & 3, pos, AS, T, false, blk, PPI);
                    if (tid == 0) atomicAdd(P->ctr + CX, 1u);
                    PROF(22);
                    if (P->fence) __threadfence();     // the K/V stores of this position (read again by this block at the next position)
                    if (stg) {
                        if (l + 1 < NLAYER) attn_stage(P, P->L[l + 1], aux >> 2, aux & 3, pos, AS, T);
                        else if (step + 1 < total) attn_stage(P, P->L[0], aux >> 2, aux & 3, pos + 1, AS, T);
                    }
                    __syncthreads();
                    PROF(23);
                }
                if (is_router && L.moe) {
                    wait_ctr(P, CM, tmC);
                    PROF(24);
                    norm_frag(P, nullptr, nullptr, 1, 0, nw, B, Ls, xf, sm, false, nullptr, xo, -1);
                    {
                        float4 c = zero4;
#pragma unroll
                        for (int i = 0; i < 8; i++) mma(c, T[i], xget(xf, Ls, 8 * warp + i, lane));
                        red[warp * 32 + lane] = c;
                    }
                    __syncthreads();
                    if (warp == 0) {
                        float4 c = red[lane];
                        for (int w = 1; w < 16; w++) c = f4add(c, red[w * 32 + lane]);
                        for (int i = 0; i < 4; i++) {
                            const int b = 2 * t + (i & 1), e = rj * 16 + g + (i >> 1) * 8;
                            if (b < B) P->rl[b * NEXP + e] = cget(c, i);
                        }
                        if (P->fence) __threadfence();
                        if (tid == 0) atomicAdd(P->ctr + CR, 1u);
                    }
                    __syncthreads();
                    PROF(25);
                    // preload the next router duty
                    int ln = l + 1;
                    if (ln >= NLAYER) ln = step + 1 < total ? 2 : -1;
                    if (ln >= 0) { tload<8>(T, P->L[ln].router + (size_t)(rj * 128 + 8 * warp) * 32 + lane); nw_load(nw, P->L[ln].ln2); }
                    __syncthreads();
                }
                tm += 4 * NMAIN;
            }
        }
        // ============ final norm + head (9384 row groups; one warp per row group, 128 tiles each)
        if (!is_main) { if (do_head) tm += NMAIN; if (do_head && mode != 0) tm += NMAIN; continue; }
        if (!do_head) continue;
        PROF(13);
        norm_frag(P, nullptr, nullptr, 1, 0, nw, B, Ls, xf, sm, false, (P->dbg && blk == 0) ? P->dbg + (size_t)NLAYER * MAXB * HID : nullptr, xo, -1);
        {
            const int G = VOCAB / 16;
            const int e0 = (int)((long long)blk * G / NMAIN), e1 = (int)((long long)(blk + 1) * G / NMAIN);
            float bv[2] = {-INFINITY, -INFINITY};
            int bi[2] = {0, 0};
            for (int rg = e0 + warp; rg < e1; rg += 16) {
                const uint4* wt = P->head + (size_t)rg * 128 * 32 + lane;
                float4 c = zero4;
                for (int ch = 0; ch < 128; ch += 8) {
                    tload<8>(T, wt + (size_t)ch * 32);
#pragma unroll
                    for (int i = 0; i < 8; i++) mma(c, T[i], xget(xf, Ls, ch + i, lane));
                }
                for (int i = 0; i < 4; i++) {
                    const int b = 2 * t + (i & 1), row = rg * 16 + g + (i >> 1) * 8;
                    if (b < B) {
                        const float val = cget(c, i);
                        if (mode == 0) logits[(size_t)b * VOCAB + row] = val;
                        else if (val > bv[i & 1]) { bv[i & 1] = val; bi[i & 1] = row; }
                    }
                }
            }
            if (mode != 0) {
                for (int i = 0; i < 2; i++) {
                    for (int o = 4; o <= 16; o <<= 1) {
                        const float ov = __shfl_xor_sync(0xffffffffu, bv[i], o);
                        const int oi = __shfl_xor_sync(0xffffffffu, bi[i], o);
                        if (ov > bv[i] || (ov == bv[i] && oi < bi[i])) { bv[i] = ov; bi[i] = oi; }
                    }
                    if (g == 0) { sm[warp * 8 + 2 * t + i] = bv[i]; smi[warp * 8 + 2 * t + i] = bi[i]; }
                }
                __syncthreads();
                if (tid < B) {
                    float v = sm[tid]; int ix = smi[tid];
                    for (int w = 1; w < 16; w++) {
                        const float ov = sm[w * 8 + tid]; const int oi = smi[w * 8 + tid];
                        if (ov > v || (ov == v && oi < ix)) { v = ov; ix = oi; }
                    }
                    P->argv[blk * MAXB + tid] = v; P->argi[blk * MAXB + tid] = ix;
                }
            }
        }
        __syncthreads();
        if (warp == 0) {
            if (P->fence) __threadfence();
            if (tid == 0) atomicAdd(P->ctr + CM, 1u);
        }
        tm += NMAIN;
        PROF(14);
        if (mode != 0) {
            wait_ctr(P, CM, tm);
            if (blk == 0 && tid < B) {
                float v = ldx(P->argv + tid); int ix = ldx(P->argi + tid);
                for (int w = 1; w < NMAIN; w++) {
                    const float ov = ldx(P->argv + w * MAXB + tid); const int oi = ldx(P->argi + w * MAXB + tid);
                    if (ov > v || (ov == v && oi < ix)) { v = ov; ix = oi; }
                }
                P->curtok[tid] = ix;
                if (mode == 1) gen_out[(size_t)tid * nsteps + (step - npre)] = ix;
                else P->gen[(size_t)tid * P->maxctx + (step - npre)] = ix;
            }
            __syncthreads();
            if (warp == 0) {
                if (blk == 0) {
                    __threadfence();
                    if (tid == 0 && mode == 2) { P->ctr[96] = (unsigned)(step - npre + 1); __threadfence(); }
                }
                if (tid == 0) atomicAdd(P->ctr + CM, 1u);
            }
            tm += NMAIN;
        }
    }
#ifdef MK_PROF
    PROF(30);
    if (blk == 0 && tid == 0) P->clk[1] = 1u;
#endif
}

// ------------------------------------------------------------------------------------------------ host side
struct Handle {
    Params host;
    Params* dev;
    unsigned tm, tx, tr;
    cudaStream_t poll_stream;
    int* poll_host;       // pinned: [0] progress, then tokens
    int serve_B, serve_n, smtot;
};

#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "mk: CUDA error %s at line %d\n", cudaGetErrorString(e_), __LINE__); return 1; } } while (0)

template <class T> static int dalloc(T*& p, size_t n) {
    void* q = nullptr;
    if (cudaMalloc(&q, n * sizeof(T)) != cudaSuccess) return 0;
    if (cudaMemset(q, 0, n * sizeof(T)) != cudaSuccess) return 0;
    p = (T*)q;
    return 1;
}

extern "C" {

// slots: per layer 20 entries [qkv, o, dgu, ddown, router, sgu, sdown, egu, edown, kc, vc, ln1, ln2, qn, kn, sinks, sliding, moe, -, -],
// then [embed, head, fnorm, cos, sin, maxctx, debug]
void* mk_create(const long long* s) {
    Handle* h = new Handle();
    memset(h, 0, sizeof(Handle));
    Params& P = h->host;
    for (int l = 0; l < NLAYER; l++) {
        const long long* q = s + l * 20;
        LayerP& L = P.L[l];
        L.qkv = (const uint4*)q[0]; L.o = (const uint4*)q[1]; L.dgu = (const uint4*)q[2]; L.ddown = (const uint4*)q[3];
        L.router = (const uint4*)q[4]; L.sgu = (const uint4*)q[5]; L.sdown = (const uint4*)q[6]; L.egu = (const uint4*)q[7]; L.edown = (const uint4*)q[8];
        L.kc = (uint4*)q[9]; L.vc = (uint4*)q[10];
        L.ln1 = (const float*)q[11]; L.ln2 = (const float*)q[12]; L.qn = (const float*)q[13]; L.kn = (const float*)q[14]; L.sinks = (const float*)q[15];
        L.sliding = (int)q[16]; L.moe = (int)q[17];
    }
    const long long* q = s + NLAYER * 20;
    P.embed = (const u16*)q[0]; P.head = (const uint4*)q[1]; P.fnorm = (const float*)q[2]; P.cosT = (const float*)q[3]; P.sinT = (const float*)q[4];
    P.maxctx = (int)q[5]; P.kgmax = (P.maxctx + 15) / 16;
    int ok = dalloc(P.xc, 4 * 1024) && dalloc(P.qraw, MAXB * 320 * 8) && dalloc(P.attnf, MAXB * 256 * 4) && dalloc(P.rl, MAXB * NEXP) &&
             dalloc(P.hbuf, (size_t)MAXB * HCHUNKS * 4) && dalloc(P.argv, NMAIN * MAXB) && dalloc(P.argi, NMAIN * MAXB) && dalloc(P.curtok, MAXB) &&
             dalloc(P.gen, (size_t)MAXB * P.maxctx) && dalloc(P.ctr, 128);
    if (ok && q[6]) ok = dalloc(P.dbg, (size_t)(NLAYER + 1) * MAXB * HID);
#ifdef MK_PROF
    if (ok) ok = dalloc(P.prof, 3 * PROF_MAX * 2) && dalloc(P.clk, 16);
#endif
    if (!ok) { fprintf(stderr, "mk: allocation failed\n"); return nullptr; }
    void* d = nullptr;
    if (cudaMalloc(&d, sizeof(Params)) != cudaSuccess) return nullptr;
    h->dev = (Params*)d;
    if (cudaMemcpy(h->dev, &P, sizeof(Params), cudaMemcpyHostToDevice) != cudaSuccess) return nullptr;
    h->smtot = SM_TOTAL;
    if (cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, h->smtot) != cudaSuccess) {
        fprintf(stderr, "mk: cannot set %d bytes of shared memory\n", h->smtot);
        return nullptr;
    }
    if (cudaStreamCreateWithFlags(&h->poll_stream, cudaStreamNonBlocking) != cudaSuccess) return nullptr;
    if (cudaMallocHost((void**)&h->poll_host, sizeof(int) * (1 + (size_t)MAXB * P.maxctx)) != cudaSuccess) return nullptr;
    return h;
}

// mode 0: one step, logits written. mode 1: nsteps greedy steps, tokens to gen_out [B][nsteps].
// mode 2: npre forced prompt steps (tok [B][npre+1] with row stride tstride), then nsteps greedy steps into the device buffer.
int mk_run(void* hv, const long long* tok, int tstride, float* logits, long long* gen_out, int B, int pos0, int npre, int nsteps, int mode) {
    Handle* h = (Handle*)hv;
#ifdef MK_PROF
    cudaMemset(h->host.clk, 0, 64); cudaMemset(h->host.prof, 0, 3 * PROF_MAX * 2 * 4);
#endif
    if (mode == 2) { cudaMemsetAsync(h->host.ctr + 96, 0, 4, 0); h->serve_B = B; h->serve_n = nsteps; }
    cudaMemsetAsync(h->host.ctr + CABORT, 0, 4, 0);
    mk_kernel<<<NBLK, NTHR, h->smtot>>>(h->dev, tok, tstride, logits, gen_out, B, pos0, npre, nsteps, mode, h->tm, h->tx, h->tr);
    const int nattn = 4 * B < NAUX ? 4 * B : NAUX;
    const unsigned layers_m = 49 * 4;
    h->tm += (unsigned)NMAIN * ((unsigned)(npre + nsteps) * layers_m + (unsigned)nsteps * (mode ? 2 : 1));
    h->tx += (unsigned)nattn * (unsigned)(npre + nsteps) * NLAYER;
    h->tr += (unsigned)NROUT * (unsigned)(npre + nsteps) * 47;
    cudaError_t e = cudaGetLastError();
    if (e != cudaSuccess) { fprintf(stderr, "mk: launch failed: %s\n", cudaGetErrorString(e)); return 1; }
    return 0;
}

// Served cohort: copy progress and tokens while the kernel runs. out: [B][n] int32. Returns the number of finished steps.
int mk_poll(void* hv, int* out) {
    Handle* h = (Handle*)hv;
    const Params& P = h->host;
    if (cudaMemcpyAsync(h->poll_host, P.ctr + 96, 4, cudaMemcpyDeviceToHost, h->poll_stream) != cudaSuccess) return -1;
    if (cudaStreamSynchronize(h->poll_stream) != cudaSuccess) return -1;
    int done = h->poll_host[0];
    if (done > h->serve_n) done = h->serve_n;
    if (done > 0) {
        if (cudaMemcpyAsync(h->poll_host + 1, P.gen, sizeof(int) * (size_t)h->serve_B * P.maxctx, cudaMemcpyDeviceToHost, h->poll_stream) != cudaSuccess) return -1;
        if (cudaStreamSynchronize(h->poll_stream) != cudaSuccess) return -1;
        for (int b = 0; b < h->serve_B; b++) memcpy(out + (size_t)b * h->serve_n, h->poll_host + 1 + (size_t)b * P.maxctx, sizeof(int) * done);
    }
    return done;
}

int mk_smem(void* hv) { return ((Handle*)hv)->smtot; }
int mk_set_fence(void* hv, int v) { Handle* h = (Handle*)hv; h->host.fence = v; return cudaMemcpy(h->dev, &h->host, sizeof(Params), cudaMemcpyHostToDevice) != cudaSuccess; }

int mk_read_dbg(void* hv, float* out) {
    Handle* h = (Handle*)hv;
    if (!h->host.dbg) return 1;
    CK(cudaMemcpy(out, h->host.dbg, (size_t)(NLAYER + 1) * MAXB * HID * sizeof(float), cudaMemcpyDeviceToHost));
    return 0;
}

int mk_read_prof(void* hv, unsigned* out) {
#ifdef MK_PROF
    Handle* h = (Handle*)hv;
    CK(cudaMemcpy(out, h->host.prof, 3 * PROF_MAX * 2 * 4, cudaMemcpyDeviceToHost));
    return 0;
#else
    return 1;
#endif
}

}  // extern "C"
