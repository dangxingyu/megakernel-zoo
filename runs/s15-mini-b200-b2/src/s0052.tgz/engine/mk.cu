// Inkling-2-Mini decode engine: one persistent cooperative kernel per step on one B200.
// See notes/plan.md. Phases hand over through tagged data (value + tag in one 8-byte store, the consumer polls
// its own elements); no grid barrier inside a step. All reductions in a fixed order.
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include "mkprof.cuh"

typedef __nv_bfloat16 bf16;

#define H 2304
#define HP (H + 8)
#define NQH 24
#define NKV 8
#define HD 128
#define QW 3072
#define QWP (QW + 8)
#define NE 128
#define TOPK 8
#define IE 1152
#define NLW 24
#define NAPP 48
#define MAXB 8
// kernel variant switches needed by the shared-memory layout (described further down)
#ifndef KB1
#define KB1 0
#endif
#ifndef KBF
#define KBF (KB1 ? 1 : 0)
#endif
// SM1: the batch-1 kernel's shared-memory union sized for one token (64-key attention items, 48 merge records,
// one token column): 133.4 -> 99.3 KB, under the 100 KiB carve-out step (32 KiB more L1 than at 132 KiB). The
// batch-1 kernel then serves contexts up to 48 x 64 = 3072 (mk_maxctx()).
#ifndef SM1
#define SM1 1
#endif
#define SMB1 (SM1 && KBF == 1)
#define MAXB_S (SMB1 ? 1 : MAXB)
#ifndef GDPF
#define GDPF 0
#endif
#ifndef NTH
#define NTH 768
#endif
#define NWARP (NTH / 32)
// ACS: attention positions per item for B > 2 (B <= 2: 64). 256 halves the items per block at long contexts (each
// block runs its items one after another); the records of the online softmax then cover 256 keys.
#ifndef ACS
#define ACS 128
#endif
#define CH (SMB1 ? 64 : ACS)   // attention positions per item (at most; B <= 2 uses 64)
// ATT2 (generic kernel): when a block has several attention items, its two halves (12 warps each) run one item each
// side by side, in lockstep through the same syncs, each with its own buffers; same arithmetic per item
#ifndef ATT2
#define ATT2 0
#endif
#ifndef ATP
#define ATP 0
#endif
#ifndef SMPAD
#define SMPAD 0
#endif
// SMTRIM: drop two unused shared-memory members (4.9 KB): 138.3 -> 133.4 KB, under the 132 KiB carve-out step
#ifndef SMTRIM
#define SMTRIM 1
#endif
#define MAXCH (SMB1 ? 48 : 64)   // chunks per (token, kv head)
#define MAXU 64          // union experts per layer
#define VOCAB_REAL 200058
#define UN_STRIPS 12504  // 200064 rows
// fused qkv matrix rows (output layout fixed; weight strips: 410 + 2 * nsk)
#define R_G 3072
#define R_R 6144
#define R_S 6528
#define QG_STRIPS 410
#define K0 6560
#define V0 7616
#define QKVR 8672
// pieces (units of 64 k per item)
#define QKV_PU 6
#define QKV_NP 6
#define O_PU 6
#define O_NP 8
#define RT_PU 2
#define RT_NP 18
#define D_PU 6
#define D_NP 12

// ------------------------------------------------------------------------------------------------ parameters
struct LayerW {
  const uint8_t* wqkv; const uint8_t* wo; const uint8_t* wr; const float* rbias;
  const uint8_t* w13; const uint8_t* w2; const float* f13; const float* f2;
  const bf16* norm[3]; const bf16* mlp_norm;
  const bf16* ksc; const bf16* vsc; const bf16* attn_sc; const bf16* mlp_sc;
  const bf16* qscale; const bf16* rscale; const bf16* relp;
  const float* aq; const float* mq;
  const uint8_t* cD; const bf16* cFG;
  const uint8_t* q12base;   // track B (W12Q): row bases of the 12-bit qkv strips
  int nsk, mx, glob, naq;
};
struct App { int layer, pass, slot, bnd, nblk, blk[4], pin, nmsg, msg[2], loopl, out, pad; };
struct Ctx {
  LayerW L[NLW];
  App A[NAPP];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm; const uint8_t* unembed;
  const float* loopq;
  int nfin, fin[4], fin_pin, maxctx;
  uint2* pbt; bf16* kc; bf16* vc;          // pbt [49][MAXB][H/2]: (bf16x2, tag) partial after each application
  bf16* hk; bf16* hv; bf16* ha; bf16* hm;
  uint2* qkvt; uint2* arec; uint2* aoutt; uint2* attst; uint2* rlogt; uint2* act16t;
  float* part; float* w2p; unsigned* cnt; unsigned* bar;
  uint2* xgt; uint2* mgt; uint2* ubt; uint2* gvt; uint2* xpt;
  uint2* xst; uint2* xrt; uint2* sht; uint2* w2ct; uint2* ntt;   // ntt: next token per sequence (device loop)     // B >= 2: normalized rows published by designated blocks
  unsigned long long* amax; int* next_tok;
  long long* prof;
  const uint8_t* u12base;   // track B (W12U): row bases of the 12-bit unembedding
  uint2* mzt; uint2* mg2t; uint2* mu2t;  // track B (MSGZ): per pass z_m [12][4][MAXB][64] and messages [12][4][MAXB][H] (tagged)
  // track B (SKH): certified int8 sketch of the unembedding for the greedy path
  const uint8_t* skq; const float* sks; const float* ske; const float* skn; unsigned* skl;
  int* rhist;   // track B (XPF): expert union of every application of the last step [NAPP][MAXU + 1]
  uint2* gvp;   // gate-D K-split partials [2][MAXB][4][DKS][64] (tagged)
  bf16* l0t;    // track B (L0T): layer 0's qkv rows per token id [VOCAB_ROWS][QKVR] (built at load by this kernel, F_L0B)
  uint2* gzt;   // track B (GLIN): D x raw mix sources, [2][MAXB][4][64 rows][8 columns] (tagged f32)
};
struct Hdr { int B, pos, flags, nsteps; const int* tokens; float* logits; int* out_tok; int out_stride; unsigned tag0;
             const int* prompt; int plen; unsigned tok_tag; };   // nsteps > 0: device loop over nsteps steps
// track A (K1): the same source compiled twice: KB1 = 1 gives a kernel for batch 1 only (every B >= 2 path and the
// two-column-group expert code are dead and removed; its registers are allocated for the B = 1 paths alone), KB1 = 0
// the generic kernel. The host launches the one that fits the batch (engine/api.py).
#ifndef KB1
#define KB1 0
#endif
// KBF: the batch as a compile-time constant (1 = the batch-1 kernel, 8 = a batch-8 kernel; 0 = generic)
#ifndef KBF
#define KBF (KB1 ? 1 : 0)
#endif
// KBN: the generic kernel told that the batch is at least 2 (batch 1 goes to the batch-1 kernel): B = 1 paths are dead
#ifndef KBN
#define KBN 0
#endif
#define HDB (KBF ? KBF : (KBN ? max(hd.B, 2) : hd.B))
// track A (NI): phases as out-of-line functions (their own register allocation instead of one for the whole kernel)
#ifndef NI_ALL
#define NI_ALL 0
#endif
#if NI_ALL
#define NI_DEF __noinline__
#else
#define NI_DEF
#endif
#ifndef NI_ATTNIN
#define NI_ATTNIN NI_DEF
#endif
#ifndef NI_GATED
#define NI_GATED NI_DEF
#endif
#ifndef NI_MSGZ
#define NI_MSGZ NI_DEF
#endif
#ifndef NI_GATEFG
#define NI_GATEFG NI_DEF
#endif
#ifndef NI_QKV
#define NI_QKV NI_DEF
#endif
#ifndef NI_ATTN
#define NI_ATTN NI_DEF
#endif
#ifndef NI_OPROJ
#define NI_OPROJ NI_DEF
#endif
#ifndef NI_MLPIN
#define NI_MLPIN NI_DEF
#endif
#ifndef NI_ROUTER
#define NI_ROUTER NI_DEF
#endif
#ifndef NI_ROUTING
#define NI_ROUTING NI_DEF
#endif
#ifndef NI_W13
#define NI_W13 NI_DEF
#endif
#ifndef NI_W2A
#define NI_W2A NI_DEF
#endif
#ifndef NI_W2B
#define NI_W2B NI_DEF
#endif
#ifndef NI_FINAL
#define NI_FINAL NI_DEF
#endif
#define F_LOGITS 1
// track B (S6): NVFP4 block scales as 6-bit codes (E4M3 byte - 76; every scale of the checkpoint is in 76..126):
// 48 B instead of 64 B per unit, decoded through a 4096-entry table of f16 pairs in shared memory
#ifndef S6
#define S6 0
#endif
#define FP4_UB (S6 ? 560 : 576)
#ifndef BPG
#define BPG 0
#endif
// track A (SCS): the NVFP4 block scales of a warp's piece (11% of its bytes) go through cp.async into shared memory,
// so that the registers hold code words only: 6 units in flight per warp in the registers that held 4
#ifndef SCS
#define SCS 0
#endif
#define FP4_SCB (S6 ? 48 : 64)      // scale bytes per unit
#ifndef FP4_UNR
#define FP4_UNR (SCS ? 6 : 4)
#endif
#define S6_BASE 76
#define F_L0B 2   // build mode (L0T): application 0's attention input and qkv rows only, rows into c.l0t
#ifndef L0T
#define L0T 0
#endif
#define L0T_ON(a) (L0T && (a) == 0 && c.l0t && !(hd.flags & F_L0B))

// counter regions
#define CN_QKV 0
#define CN_ATT 1024
#define CN_O 1280
#define CN_RT 1536
#define CN_D 1600
#define CN_W13 2048          // MAXU * 144
#define CN_W2 (2048 + 9216)  // MAXB * 144
#define CN_TOTAL (CN_W2 + 1152 + 64)

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldcg_u32(const void* p) {
  uint32_t r;
  asm volatile("ld.global.cg.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ float ldcg_f(const float* p) { return __ldcg(p); }
__device__ __forceinline__ float4 ldcg_f4(const float4* p) { return __ldcg(p); }
__device__ __forceinline__ uint32_t cvt_fp4x2(uint32_t b) {
  uint32_t r; unsigned short bs = (unsigned short)b;
  asm("{ .reg .b8 t; cvt.u8.u16 t, %1; cvt.rn.f16x2.e2m1x2 %0, t; }" : "=r"(r) : "h"(bs));
  return r;
}
__device__ __forceinline__ uint32_t cvt_e4m3x2(uint32_t w16) {
  uint32_t r; unsigned short h = (unsigned short)w16;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(h));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }
__device__ __forceinline__ unsigned ld_relaxed_gpu(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void fence_acqrel_gpu() { asm volatile("fence.acq_rel.gpu;" ::: "memory"); }
__device__ __forceinline__ void red_release_gpu(unsigned* p, unsigned v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %globaltimer;" : "=l"(t)); return t; }
__device__ __forceinline__ int lane_id() { int l; asm("mov.u32 %0, %%laneid;" : "=r"(l)); return l; }

// ------------------------------------------------------------------------------------------------ shared memory
struct Smem {
  union {
    bf16 xs[3][MAXB_S][HP];               // B operands (bf16), streams q / k / v (router, unembed: stream 0)
    bf16 xo[MAXB_S][QWP];                 // o_proj input
    struct { bf16 xr[MAXB_S][HP]; __half x16[MAXB_S][2][HP]; } e;   // router input + expert input (f16 hi / lo)
    // phases that use the xs area as raw scratch from xs[0] or xs[1] on: gate D column (2H + 8), GLIN columns
    // (8 x (2H + 8) bf16 = 73,856 B), head staging and digits (73,984 B from xs[1])
    unsigned char raw[SMB1 ? 2 * HP + 73984 + 16 : 16];
    struct alignas(16) At {                // attention item (16-byte aligned: cp.async and ldmatrix targets)
      bf16 kk[CH][HD + 8]; bf16 vv[CH][HD + 8]; bf16 qb[8][HD + 8]; bf16 ph[16][CH + 8]; bf16 pl[16][CH + 8];
      float sc[3][CH]; float pr[16][CH]; float rr[3][16];
      float kt[HD]; float vt[HD]; float ml[3][2]; float po[3][HD];
    } at;
    At at2[(ATT2 || ATP) ? 2 : 1];                  // ATT2: two attention items side by side in a block (one per half)
    float mrg[MAXCH * 3 * 130 + 3 * MAXCH];      // attention merge staging
    __half w2s[SMB1 ? 4 : 24][2][IE];            // w2 inputs (expert, token) pairs of a round, hi / lo
  } u;
  float4 red4[NWARP][32];                  // block GEMV: partial fragments per warp
#if !SMTRIM
  float w2o[MAXB][TOPK][16];               // (unused; kept only to reproduce the old footprint)
#endif
  float red[NWARP][32];
  float bcast[64];
  float sc16[MAXB];                        // 2^-s of the expert input f16 scaling per token
  // routing tables (identical in every block)
  int nU; int uexp[MAXU]; int uncnt[MAXU]; int utok[MAXU][MAXB_S];
  int tex[MAXB][TOPK]; float twt[MAXB][TOPK];   // per token: experts sorted by id, weights
  unsigned umask[4];
  unsigned tokm[NE / 4];                   // routing (RTMASK): per expert the bit mask of its tokens (8 bits each)
  int flag;
  unsigned subn;
  float sku[96][MAXB];                     // SKH: per strip of this block, per token: upper bound of the strip
  float sksig[MAXB], skxn[MAXB], skwm[NWARP];   // SKH: digit scale, |x| per token; warp maxima
  int skc[96]; int nskc;                          // SKH: candidate strips of this block
  unsigned long long gdbar; unsigned gdph;        // GDPF: mbarrier + parity of the gate-D strip prefetch
  uint4 scb[SCS ? NTH / 32 : 1][(SCS || !SMTRIM) ? 48 : 1];               // SCS: staged scale bytes of each warp's piece (<= 12 units x 64 B)
  int exq;                                        // EXQ: next expert item of this block (warps take items one at a time)
#if SMPAD
  char smpad[SMPAD * 1024];                       // experiment: shared-memory footprint only
#endif
  uint32_t s6tab[S6 ? 4096 : 4];                  // S6: f16x2 {scale(row g), scale(row g + 8)} per 12-bit code pair
};
static_assert(!GDPF || 9344 + 36 * 2048 <= sizeof(((Smem*)0)->u), "GDPF strip area");
static_assert(8 * (2 * H + 8) * 2 <= sizeof(((Smem*)0)->u), "GLIN columns");
static_assert(MAXB_S * HP * 2 + 73984 <= sizeof(((Smem*)0)->u), "head staging from xs[1]");

// ------------------------------------------------------------------------------------------------ barrier
__device__ __forceinline__ void grid_bar(const Ctx& c, unsigned& nbar, unsigned base) {
  __syncthreads();
  nbar += 1;
  if (threadIdx.x == 0) {
    unsigned target = base + nbar * gridDim.x;
    __threadfence();
    red_release_gpu(&c.bar[0], 1);
    while ((int)(ld_relaxed_gpu(&c.bar[0]) - target) < 0) { }
    fence_acqrel_gpu();
  }
  __syncthreads();
}

// block-wide sum of N values per thread (all threads get the result)
template <int N> struct P2 { static constexpr int v = N <= 1 ? 1 : N <= 2 ? 2 : N <= 4 ? 4 : N <= 8 ? 8 : N <= 16 ? 16 : 32; };
// warp reduce-scatter: after it, lane l holds the warp sum of value index ridx(l) (N padded to a power of two <= 32)
template <int N>
__device__ __forceinline__ float warp_rs(const float* v, int& ridx) {
  constexpr int M = P2<N>::v;
  float x[M];
#pragma unroll
  for (int i = 0; i < M; i++) x[i] = i < N ? v[i] : 0.f;
  const int l = threadIdx.x & 31;
  int idx = 0, off = 16;
#pragma unroll
  for (int n = M; n > 1; n >>= 1) {
    const int half = n >> 1;
    const bool up = (l & off) != 0;
#pragma unroll
    for (int i = 0; i < half; i++) {
      const float send = up ? x[i] : x[i + half];
      const float keep = up ? x[i + half] : x[i];
      x[i] = keep + __shfl_xor_sync(0xffffffff, send, off);
    }
    if (up) idx += half;
    off >>= 1;
  }
  for (; off; off >>= 1) x[0] += __shfl_xor_sync(0xffffffff, x[0], off);
  ridx = idx;
  return x[0];
}
template <int N>
__device__ __forceinline__ void block_sum(float* v, Smem& sm) {
  const int w = threadIdx.x >> 5, l = threadIdx.x & 31;
  int ri;
  const float r = warp_rs<N>(v, ri);
  constexpr int M = P2<N>::v;
  if (ri < N && (l & (32 / M - 1)) == 0) sm.red[w][ri] = r;    // lanes l = idx * (32 / M) hold distinct indices
  __syncthreads();
  if (threadIdx.x < N) {
    float s = 0.f;
#pragma unroll 4
    for (int k = 0; k < NWARP; k++) s += sm.red[k][threadIdx.x];
    sm.bcast[threadIdx.x] = s;
  }
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) v[i] = sm.bcast[i];
  // no third barrier: the next writers of bcast (threads < N of the next call) are behind that call's first barrier,
  // which every thread reaches only after reading bcast here
}
// sums of N values and maxima of M values in one reduction
template <int N, int M>
__device__ __forceinline__ void block_sum_max(float* v, float* mx, Smem& sm) {
  const int w = threadIdx.x >> 5, l = threadIdx.x & 31;
#pragma unroll
  for (int i = 0; i < N; i++) { float x = v[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x += __shfl_xor_sync(0xffffffff, x, o);
    v[i] = x; }
#pragma unroll
  for (int i = 0; i < M; i++) { float x = mx[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffff, x, o));
    mx[i] = x; }
  if (l == 0) {
#pragma unroll
    for (int i = 0; i < N; i++) sm.red[w][i] = v[i];
#pragma unroll
    for (int i = 0; i < M; i++) sm.red[w][N + i] = mx[i];
  }
  __syncthreads();
  if (threadIdx.x < N + M) {
    float s = threadIdx.x < N ? 0.f : -1e30f;
    for (int k = 0; k < NWARP; k++) s = threadIdx.x < N ? s + sm.red[k][threadIdx.x] : fmaxf(s, sm.red[k][threadIdx.x]);
    sm.bcast[threadIdx.x] = s;
  }
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) v[i] = sm.bcast[i];
#pragma unroll
  for (int i = 0; i < M; i++) mx[i] = sm.bcast[N + i];
}
__device__ __forceinline__ float block_max1(float x, Smem& sm) {
  const int w = threadIdx.x >> 5, l = threadIdx.x & 31;
#pragma unroll
  for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffff, x, o));
  if (l == 0) sm.red[w][0] = x;
  __syncthreads();
  if (threadIdx.x == 0) {
    float s = sm.red[0][0];
    for (int k = 1; k < NWARP; k++) s = fmaxf(s, sm.red[k][0]);
    sm.bcast[0] = s;
  }
  __syncthreads();
  return sm.bcast[0];
}


// Block GEMV: the block computes up to NWARP / WG strips at once; warp group q (WG warps) runs strip q, warp wl of the
// group covers units [U*wl/WG, U*(wl+1)/WG) (a split fixed per matrix: the same order for any batch); the fragments
// are summed in warp order through shared memory and epi(q, acc) runs on the group's first warp.
template <int WG, int NG, class RUN, class EPI>
__device__ __forceinline__ void block_strips(Smem& sm, int ns, int U, RUN run, EPI epi) {
  const int w = threadIdx.x >> 5, lane = lane_id();
  const int q = w / WG, wl = w - q * WG;
  float acc[NG][4];
#pragma unroll
  for (int ng = 0; ng < NG; ng++) acc[ng][0] = acc[ng][1] = acc[ng][2] = acc[ng][3] = 0.f;
  const bool act = q < ns && q < NWARP / WG;
  if (act) { const int u0 = U * wl / WG, u1 = U * (wl + 1) / WG; if (u1 > u0) run(q, u0, u1 - u0, acc); }
  float tot[NG][4];
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    if (WG > 1) {
      sm.red4[w][lane] = make_float4(acc[ng][0], acc[ng][1], acc[ng][2], acc[ng][3]);
      __syncthreads();
      tot[ng][0] = tot[ng][1] = tot[ng][2] = tot[ng][3] = 0.f;
      if (act && wl == 0) {
#pragma unroll
        for (int k = 0; k < WG; k++) {
          const float4 v = sm.red4[w + k][lane];
          tot[ng][0] += v.x; tot[ng][1] += v.y; tot[ng][2] += v.z; tot[ng][3] += v.w;
        }
      }
      __syncthreads();
    } else {
      tot[ng][0] = acc[ng][0]; tot[ng][1] = acc[ng][1]; tot[ng][2] = acc[ng][2]; tot[ng][3] = acc[ng][3];
    }
  }
  if (act && wl == 0) epi(q, tot);
}

// L2 prefetch of a contiguous weight range (one thread; bulk prefetches of <= 64 KB)
__device__ __forceinline__ void pf_l2(const void* p, long bytes) {
#ifndef NO_PF
  const char* q = reinterpret_cast<const char*>(p);
  for (long o = 0; o < bytes; o += 65536) {
    const unsigned n = (unsigned)min(65536L, bytes - o);
    asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(q + o), "r"(n) : "memory");
  }
#endif
}

// ------------------------------------------------------------------------------------------------ tagged data
// value and tag travel as ONE 64-bit scalar access (single-copy atomic; a v2.u32 access may tear)
__device__ __forceinline__ void st_tag(uint2* p, uint32_t v, unsigned tag) {
  const unsigned long long w = ((unsigned long long)tag << 32) | v;
  asm volatile("st.relaxed.gpu.global.b64 [%0], %1;" :: "l"(p), "l"(w) : "memory");
}
__device__ __forceinline__ void st_tagf(uint2* p, float v, unsigned tag) { st_tag(p, __float_as_uint(v), tag); }
__device__ __forceinline__ uint2 ld_tag(const uint2* p) {
#ifdef FIRST_CG
  { unsigned long long w; asm volatile("ld.global.cg.b64 %0, [%1];" : "=l"(w) : "l"(p) : "memory"); return make_uint2((uint32_t)w, (uint32_t)(w >> 32)); }
#endif
  // relaxed (coherent) load: ld.global.cg returned current tags with stale values on this card (here and in the
  // Inkling-2-Small engine, e0064-e0067 there); relaxed loads cost ~0.45 us vs ~0.15 us but overlap within a thread
  unsigned long long w;
  asm volatile("ld.relaxed.gpu.global.b64 %0, [%1];" : "=l"(w) : "l"(p) : "memory");
  return make_uint2((uint32_t)w, (uint32_t)(w >> 32));
}
// two consecutive tagged words (16-byte aligned), each 64-bit element single-copy atomic
__device__ __forceinline__ void ld_tag2(const uint2* p, uint2& x, uint2& y) {
  unsigned long long a, b;
  asm volatile("ld.relaxed.gpu.global.v2.b64 {%0, %1}, [%2];" : "=l"(a), "=l"(b) : "l"(p) : "memory");
  x = make_uint2((uint32_t)a, (uint32_t)(a >> 32)); y = make_uint2((uint32_t)b, (uint32_t)(b >> 32));
}
__device__ __forceinline__ uint2 ld_tag_r(const uint2* p) {
  unsigned long long w;
  asm volatile("ld.relaxed.gpu.global.b64 %0, [%1];" : "=l"(w) : "l"(p) : "memory");
  return make_uint2((uint32_t)w, (uint32_t)(w >> 32));
}
#ifndef POLL_NS
#define POLL_NS 0
#endif
__device__ __forceinline__ uint32_t wait_tag(const uint2* p, uint2 v, unsigned tag) {
  while (v.y != tag) { if (POLL_NS) __nanosleep(POLL_NS); v = ld_tag_r(p); }
  return v.x;
}
__device__ __forceinline__ uint32_t poll(const uint2* p, unsigned tag) { return wait_tag(p, ld_tag(p), tag); }
__device__ __forceinline__ float pollf(const uint2* p, unsigned tag) { return __uint_as_float(poll(p, tag)); }
// track A (BPX, bit per site): wait for N already-loaded (value, tag) words together. A consumer that arrives before
// its producer finds every word stale; waiting word by word costs one relaxed-load round trip per word after the data
// is there. Here the whole set is reloaded (unconditional loads at valid addresses: the words stay in registers)
// until every valid word carries its tag.
#ifndef BPX
#define BPX 0
#endif
template <int N, class ADDR, class TAGF>
__device__ __forceinline__ void wait_all2(ADDR addr, TAGF tagf, uint2* r, unsigned valid) {
  for (;;) {
    bool ok = true;
#pragma unroll
    for (int i = 0; i < N; i++) ok &= !((valid >> i) & 1u) || r[i].y == tagf(i);
    if (ok) break;
#pragma unroll
    for (int i = 0; i < N; i++) r[i] = ld_tag_r(addr(i));
  }
}
template <int N, class ADDR>
__device__ __forceinline__ void wait_all(ADDR addr, uint2* r, unsigned tag, unsigned valid = 0xffffffffu) {
  wait_all2<N>(addr, [&](int) { return tag; }, r, valid);
}
__device__ __forceinline__ uint32_t pack_bf2(float lo, float hi) {
  return (uint32_t)__bfloat16_as_ushort(tobf(lo)) | ((uint32_t)__bfloat16_as_ushort(tobf(hi)) << 16);
}
__device__ __forceinline__ float bf_lo(uint32_t v) { return __uint_as_float(v << 16); }
__device__ __forceinline__ float bf_hi(uint32_t v) { return __uint_as_float(v & 0xffff0000u); }
// tags: applications tag0 + a + 1; pbt[idx] tag0 + idx; the final phase tag0 + 50
#define TAGA(a) (hd.tag0 + (unsigned)(a) + 1u)
#define TAGP(i) (hd.tag0 + (unsigned)(i))

// ------------------------------------------------------------------------------------------------ mixes
// Every thread holds element pairs p = threadIdx.x + j * NTH (j < 2, p < H / 2): slot k -> element EL(k).
#define EPT 4
#define NPAIR (H / 2)
static_assert(NPAIR > NTH && NPAIR <= 2 * NTH, "pair layout");
__device__ __forceinline__ int EL(int k) { return 2 * (threadIdx.x + (k >> 1) * NTH) + (k & 1); }
__device__ __forceinline__ bool EV(int k) { return k < 2 || threadIdx.x < NPAIR - NTH; }

// softmax over depth: sources v[s][k] (f32) for the bits s of msk, queries qs[q] (f32 [H]); out[q][k] (f32). normalize_values = true.
template <int NQ_MAX>
__device__ __forceinline__ void load_queries(const float* const* qs, int nq, float (*qv)[EPT]) {
#pragma unroll
  for (int q = 0; q < NQ_MAX; q++)
#pragma unroll
    for (int j = 0; j < 2; j++) {
      float2 f = make_float2(0.f, 0.f);
      if (q < nq) f = __ldg(reinterpret_cast<const float2*>(qs[q]) + (EV(2 * j) ? threadIdx.x + j * NTH : threadIdx.x));
      qv[q][2 * j] = f.x; qv[q][2 * j + 1] = f.y;
    }
}
// one-query depth mix that also returns the coefficient of every raw source: out = sum_s coef[s] v[s]
// (same operations in the same order as depth_mix_q for out)
template <int NS_MAX>
__device__ __forceinline__ void depth_mix_coef(float (*v)[EPT], unsigned msk, const float (*qv)[EPT], float (*out)[EPT], float* coef, Smem& sm) {
  float red[2 * NS_MAX];
#pragma unroll
  for (int i = 0; i < 2 * NS_MAX; i++) red[i] = 0.f;
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) {
    if ((msk >> s) & 1u) {
#pragma unroll
      for (int k = 0; k < EPT; k++) red[s] += v[s][k] * v[s][k];
#pragma unroll
      for (int k = 0; k < EPT; k++) red[NS_MAX + s] += v[s][k] * qv[0][k];
    }
  }
  block_sum<2 * NS_MAX>(red, sm);
  float inv[NS_MAX];
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) inv[s] = rsqrtf(red[s] / (float)H + 1e-6f);
  const float hs = rsqrtf((float)H);
  float lg[NS_MAX], mx = -1e30f;
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) {
    lg[s] = ((msk >> s) & 1u) ? red[NS_MAX + s] * hs * inv[s] : -1e30f;
    mx = fmaxf(mx, lg[s]);
  }
  float den = 0.f;
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) { lg[s] = ((msk >> s) & 1u) ? expf(lg[s] - mx) : 0.f; den += lg[s]; }
  float rd = 1.0f / den;
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) coef[s] = ((msk >> s) & 1u) ? (lg[s] * rd) * inv[s] : 0.f;
#pragma unroll
  for (int k = 0; k < EPT; k++) {
    float o = 0.f;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++)
      if ((msk >> s) & 1u) o += (lg[s] * rd) * (v[s][k] * inv[s]);
    out[0][k] = o;
  }
}
// track B (QLIN): the attention input of an ungated application linearised over the raw sources of its depth mix:
//   W_qkv (w . x) r = sum_s (cf[s] r) W_qkv (w . v_s)        (w: norm weight, r = 1 / rms(x), x = sum_s cf[s] v_s)
// every block puts the columns w . v_s (BF16) into shared memory and starts its qkv strips at once; one block (the
// last, which gets no strips) computes the mixes and publishes cf[q][s] r_q; the qkv epilogue combines the columns.
#ifndef QLIN
#define QLIN 0
#endif
// depth mixes for nq <= 3 queries: only the coefficients cf[q][s] r_q (r_q = 1 / rms of mix q)
template <int NS_MAX>
__device__ __forceinline__ void depth_mix_cf3(float (*v)[EPT], unsigned msk, const float (*qv)[EPT], int nq, float (*cf)[NS_MAX], Smem& sm) {
  float red[4 * NS_MAX];
#pragma unroll
  for (int i = 0; i < 4 * NS_MAX; i++) red[i] = 0.f;
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) {
    if ((msk >> s) & 1u) {
#pragma unroll
      for (int k = 0; k < EPT; k++) red[s] += v[s][k] * v[s][k];
#pragma unroll
      for (int q = 0; q < 3; q++)
#pragma unroll
        for (int k = 0; k < EPT; k++) red[NS_MAX + q * NS_MAX + s] += v[s][k] * qv[q][k];
    }
  }
  block_sum<4 * NS_MAX>(red, sm);
  float inv[NS_MAX];
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) inv[s] = rsqrtf(red[s] / (float)H + 1e-6f);
  const float hs = rsqrtf((float)H);
  float s2[3] = {0.f, 0.f, 0.f};
#pragma unroll
  for (int q = 0; q < 3; q++) {
    float lg[NS_MAX], mx = -1e30f;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) {
      lg[s] = ((msk >> s) & 1u) ? red[NS_MAX + q * NS_MAX + s] * hs * inv[s] : -1e30f;
      mx = fmaxf(mx, lg[s]);
    }
    float den = 0.f;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) { lg[s] = ((msk >> s) & 1u) ? expf(lg[s] - mx) : 0.f; den += lg[s]; }
    float rd = 1.0f / den;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) cf[q][s] = (q < nq && ((msk >> s) & 1u)) ? (lg[s] * rd) * inv[s] : 0.f;
#pragma unroll
    for (int k = 0; k < EPT; k++) {
      float o = 0.f;
#pragma unroll
      for (int s = 0; s < NS_MAX; s++)
        if ((msk >> s) & 1u) o += (lg[s] * rd) * (v[s][k] * inv[s]);
      if (q < nq) s2[q] += o * o;
    }
  }
  block_sum<3>(s2, sm);
#pragma unroll
  for (int q = 0; q < 3; q++) {
    const float r = rsqrtf(s2[q] / (float)H + 1e-6f);
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) cf[q][s] *= r;
  }
}
template <int NS_MAX, int NQ_MAX>
__device__ __forceinline__ void depth_mix_q(float (*v)[EPT], unsigned msk, const float (*qv)[EPT], int nq, float (*out)[EPT], Smem& sm) {
  float red[NS_MAX + NQ_MAX * NS_MAX];
#pragma unroll
  for (int i = 0; i < NS_MAX + NQ_MAX * NS_MAX; i++) red[i] = 0.f;
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) {
    if ((msk >> s) & 1u) {
#pragma unroll
      for (int k = 0; k < EPT; k++) red[s] += v[s][k] * v[s][k];
#pragma unroll
      for (int q = 0; q < NQ_MAX; q++)
#pragma unroll
        for (int k = 0; k < EPT; k++) red[NS_MAX + q * NS_MAX + s] += v[s][k] * qv[q][k];
    }
  }
  block_sum<NS_MAX + NQ_MAX * NS_MAX>(red, sm);
  float inv[NS_MAX];
#pragma unroll
  for (int s = 0; s < NS_MAX; s++) inv[s] = rsqrtf(red[s] / (float)H + 1e-6f);
  const float hs = rsqrtf((float)H);
#pragma unroll
  for (int q = 0; q < NQ_MAX; q++) {
    if (q >= nq) continue;
    float lg[NS_MAX], mx = -1e30f;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) {
      lg[s] = ((msk >> s) & 1u) ? red[NS_MAX + q * NS_MAX + s] * hs * inv[s] : -1e30f;
      mx = fmaxf(mx, lg[s]);
    }
    float den = 0.f;
#pragma unroll
    for (int s = 0; s < NS_MAX; s++) { lg[s] = ((msk >> s) & 1u) ? expf(lg[s] - mx) : 0.f; den += lg[s]; }
    float rd = 1.0f / den;
#pragma unroll
    for (int k = 0; k < EPT; k++) {
      float o = 0.f;
#pragma unroll
      for (int s = 0; s < NS_MAX; s++)
        if ((msk >> s) & 1u) o += (lg[s] * rd) * (v[s][k] * inv[s]);
      out[q][k] = o;
    }
  }
}
template <int NS_MAX, int NQ_MAX>
__device__ __forceinline__ void depth_mix(float (*v)[EPT], unsigned msk, const float* const* qs, int nq, float (*out)[EPT], Smem& sm) {
  float qv[NQ_MAX][EPT];
  load_queries<NQ_MAX>(qs, nq, qv);
  depth_mix_q<NS_MAX, NQ_MAX>(v, msk, qv, nq, out, sm);
}
// norm weights of one stream (bf16 pairs) as floats
__device__ __forceinline__ void load_w(const bf16* w, float* wv) {
#pragma unroll
  for (int j = 0; j < 2; j++) {
    const __nv_bfloat162 x = *reinterpret_cast<const __nv_bfloat162*>(w + (EV(2 * j) ? EL(2 * j) : EL(0)));
    wv[2 * j] = bf(x.x); wv[2 * j + 1] = bf(x.y);
  }
}
// rmsnorm of nq streams at once (one reduction) with prefetched weights -> bf16 smem rows
template <int NQ>
__device__ __forceinline__ void rmsnorm_store_n(const float (*x)[EPT], const float (*wv)[EPT], int nq, bf16* const* dst, Smem& sm) {
  float s[NQ];
#pragma unroll
  for (int q = 0; q < NQ; q++) { s[q] = 0.f;
#pragma unroll
    for (int k = 0; k < EPT; k++) s[q] += x[q][k] * x[q][k]; }
  block_sum<NQ>(s, sm);
#pragma unroll
  for (int q = 0; q < NQ; q++) {
    if (q >= nq) continue;
    const float r = rsqrtf(s[q] / (float)H + 1e-6f);
#pragma unroll
    for (int j = 0; j < 2; j++) {
      if (!EV(2 * j)) continue;
      *reinterpret_cast<uint32_t*>(dst[q] + EL(2 * j)) = pack_bf2(x[q][2 * j] * r * wv[q][2 * j], x[q][2 * j + 1] * r * wv[q][2 * j + 1]);
    }
  }
}
// rmsnorm with weight -> bf16 into dst (smem row, length H)
__device__ __forceinline__ void rmsnorm_store(const float* x, const bf16* w, bf16* dst, Smem& sm) {
  float s[1] = {0.f};
#pragma unroll
  for (int k = 0; k < EPT; k++) s[0] += x[k] * x[k];
  block_sum<1>(s, sm);
  float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
  for (int j = 0; j < 2; j++) {
    if (!EV(2 * j)) continue;
    const int e = EL(2 * j);
    float y0 = x[2 * j] * r, y1 = x[2 * j + 1] * r;
    if (w) { const __nv_bfloat162 wv = *reinterpret_cast<const __nv_bfloat162*>(w + e); y0 = y0 * bf(wv.x); y1 = y1 * bf(wv.y); }
    *reinterpret_cast<uint32_t*>(dst + e) = pack_bf2(y0, y1);
  }
}

__device__ __forceinline__ float ldcg_bf(const bf16* p) { return bf(__ushort_as_bfloat16(__ldcg(reinterpret_cast<const unsigned short*>(p)))); }
// rows of pbt (polled): idx[s] for s < ns, token b
template <int NS>
__device__ __forceinline__ void load_srcs(const Ctx& c, const Hdr& hd, const int* idx, unsigned msk, int b, float (*v)[EPT]) {
  // loads issued unconditionally (clamped addresses): arrays assigned under a condition would live in local memory
  const int p1 = EV(2) ? threadIdx.x + NTH : threadIdx.x;
  uint2 r[NS][2];
#pragma unroll
  for (int s = 0; s < NS; s++) {
    const uint2* base = c.pbt + ((long)idx[s] * MAXB + b) * NPAIR;
    r[s][0] = ld_tag(base + threadIdx.x);
    r[s][1] = ld_tag(base + p1);
  }
#if (BPX >> 2) & 1
  {
    unsigned vm = 0u;
#pragma unroll
    for (int s = 0; s < NS; s++) if ((msk >> s) & 1u) vm |= (EV(2) ? 3u : 1u) << (2 * s);
    wait_all2<2 * NS>([&](int i) { return c.pbt + ((long)idx[i >> 1] * MAXB + b) * NPAIR + ((i & 1) ? p1 : (int)threadIdx.x); },
                      [&](int i) { return TAGP(idx[i >> 1]); }, &r[0][0], vm);
  }
#pragma unroll
  for (int s = 0; s < NS; s++) {
    const uint32_t x0 = ((msk >> s) & 1u) ? r[s][0].x : 0u;
    const uint32_t x1 = (((msk >> s) & 1u) && EV(2)) ? r[s][1].x : 0u;
    v[s][0] = bf_lo(x0); v[s][1] = bf_hi(x0); v[s][2] = bf_lo(x1); v[s][3] = bf_hi(x1);
  }
#else
#pragma unroll
  for (int s = 0; s < NS; s++) {
    const uint2* base = c.pbt + ((long)idx[s] * MAXB + b) * NPAIR;
    const unsigned tg = TAGP(idx[s]);
    const uint32_t x0 = ((msk >> s) & 1u) ? wait_tag(base + threadIdx.x, r[s][0], tg) : 0u;
    const uint32_t x1 = (((msk >> s) & 1u) && EV(2)) ? wait_tag(base + p1, r[s][1], tg) : 0u;
    v[s][0] = bf_lo(x0); v[s][1] = bf_hi(x0); v[s][2] = bf_lo(x1); v[s][3] = bf_hi(x1);
  }
#endif
}
// a tagged f32 vector [H] (pairs of elements as consecutive entries)
__device__ __forceinline__ void load_vec_f(const uint2* p, unsigned tag, float* v) {
  uint2 r[EPT];
#pragma unroll
  for (int k = 0; k < EPT; k++) r[k] = ld_tag(p + (EV(k) ? EL(k) : EL(k & 1)));
#if (BPX >> 1) & 1
  {
    unsigned vm = 0u;
#pragma unroll
    for (int k = 0; k < EPT; k++) if (EV(k)) vm |= 1u << k;
    wait_all<EPT>([&](int i) { return p + (EV(i) ? EL(i) : EL(i & 1)); }, r, tag, vm);
  }
#pragma unroll
  for (int k = 0; k < EPT; k++) v[k] = EV(k) ? __uint_as_float(r[k].x) : 0.f;
#else
#pragma unroll
  for (int k = 0; k < EPT; k++) v[k] = EV(k) ? __uint_as_float(wait_tag(p + EL(k), r[k], tag)) : 0.f;
#endif
}
// a tagged bf16 vector [H] (pairs)
__device__ __forceinline__ void load_vec_bf(const uint2* p, unsigned tag, float* v) {
  const int p1 = EV(2) ? threadIdx.x + NTH : threadIdx.x;
#if (BPX >> 8) & 1
  uint2 r[2] = {ld_tag(p + threadIdx.x), ld_tag(p + p1)};
  wait_all<2>([&](int i) { return p + (i ? p1 : (int)threadIdx.x); }, r, tag, EV(2) ? 3u : 1u);
  const uint32_t x0 = r[0].x;
  const uint32_t x1 = EV(2) ? r[1].x : 0u;
#else
  const uint2 r0 = ld_tag(p + threadIdx.x), r1 = ld_tag(p + p1);
  const uint32_t x0 = wait_tag(p + threadIdx.x, r0, tag);
  const uint32_t x1 = EV(2) ? wait_tag(p + p1, r1, tag) : 0u;
#endif
  v[0] = bf_lo(x0); v[1] = bf_hi(x0); v[2] = bf_lo(x1); v[3] = bf_hi(x1);
}

// ------------------------------------------------------------------------------------------------ GEMV pieces
// B operand loaders. bf16 smem rows: element (k, col n) at base[n * stride + k].
struct BSm {
  const bf16* base; int stride; int ncol;   // columns >= ncol read as zero
  __device__ __forceinline__ uint2 get(int k0) const {
    const int l = lane_id(), g = l >> 2, t = l & 3;
    if (g >= ncol) return make_uint2(0, 0);
    const bf16* p = base + g * stride + k0 + 2 * t;
    return make_uint2(*reinterpret_cast<const uint32_t*>(p), *reinterpret_cast<const uint32_t*>(p + 8));
  }
};
struct BTag {   // tagged bf16 pair rows in global memory (polled): element pair (k / 2) of column n at base[n * stride + k / 2]
  const uint2* base; int stride; int ncol; unsigned tag;
  __device__ __forceinline__ uint2 get(int k0) const {
    const int l = lane_id(), g = l >> 2, t = l & 3;
    if (g >= ncol) return make_uint2(0, 0);
    const uint2* p = base + (long)g * stride + (k0 >> 1) + t;
    return make_uint2(poll(p, tag), poll(p + 4, tag));
  }
};

#ifndef BF_UNR
#define BF_UNR 2
#endif
// ---- track B (W12U): exact 12-bit code of the unembedding (engine/w12pack.py w12_encode, re-laid per strip)
// strip = [512 B header: lane l holds escapes l and l + 32 as (key, value, key, value)] [36 units x 32 lanes x 48 B:
// a lane's 4 ksteps x (plane 0, plane 1, plane 2)]. Register r = prmt of two low bytes with the constant exponent
// bits | plane 2 rotated by 4r (sign, 3 exponent bits); the exponent base b of a row is the exact row scale
// 2^(b - 112) applied to the fp32 sum; escapes (already divided by that scale) are patched before the MMA.
#ifndef W12U
#define W12U 0
#endif
#ifndef MSGZ
#define MSGZ 0
#endif
#ifndef MSGZ_PF
#define MSGZ_PF 0
#endif
#ifndef MSGZ4
#define MSGZ4 0
#endif
#ifndef MSGZ_PIPE
#define MSGZ_PIPE 0
#endif
#define W12_STRIP (512 + 36 * 1536)
#ifndef W12Q
#define W12Q 0
#endif
__device__ __forceinline__ uint32_t w12reg(uint32_t p01, uint32_t p2, int r) {
  uint32_t lo;
  asm("prmt.b32 %0, %1, %2, %3;" : "=r"(lo) : "r"(p01), "r"(0x38383838u), "r"((r & 1) ? 0x4342u : 0x4140u));
  uint32_t hb = p2;
  if (r) asm("shf.l.wrap.b32 %0, %1, %1, %2;" : "=r"(hb) : "r"(p2), "r"(4 * r));
  return lo | (hb & 0x87008700u);
}
#ifndef W12_UNR
#define W12_UNR 3
#endif
template <class BL>
__device__ __forceinline__ void piece_w12(const uint8_t* wst, const uint8_t* bases, const BL& bl, float* acc) {
  const int lane = lane_id(), g = lane >> 2;
  const uint4 hdr = ldg_nc(wst + lane * 16);
  const unsigned bb0 = __ldg(bases + g), bb1 = __ldg(bases + g + 8);
  const uint8_t* cw = wst + 512 + lane * 48;
  auto nextk = [&](unsigned k) {
    const unsigned a0 = (hdr.x >> 8) >= k ? (hdr.x >> 8) : 0xffffffu, a1 = (hdr.z >> 8) >= k ? (hdr.z >> 8) : 0xffffffu;
    return __reduce_min_sync(0xffffffffu, min(a0, a1));
  };
  unsigned nk = nextk(0);
  for (int u = 0; u < 36; u += W12_UNR) {
    uint4 w[3 * W12_UNR];
#pragma unroll
    for (int q = 0; q < 3 * W12_UNR; q++) w[q] = ldg_nc(cw + (long)(u + q / 3) * 1536 + (q % 3) * 16);
#pragma unroll
    for (int uu = 0; uu < W12_UNR; uu++) {
      const uint32_t* wd = reinterpret_cast<const uint32_t*>(&w[3 * uu]);
#pragma unroll
      for (int s = 0; s < 4; s++) {
        const uint32_t p0 = wd[3 * s], p1 = wd[3 * s + 1], p2 = wd[3 * s + 2];
        uint32_t r0 = w12reg(p0, p2, 0), r1 = w12reg(p0, p2, 1), r2 = w12reg(p1, p2, 2), r3 = w12reg(p1, p2, 3);
        const unsigned k = (unsigned)((u + uu) * 4 + s);
        if (k == nk) {   // rare, warp-uniform: patch the exact (rescaled) values of this kstep
#pragma unroll 1
          for (int set = 0; set < 2; set++) {
            const unsigned ek = set ? hdr.z : hdr.x, ev = set ? hdr.w : hdr.y;
            unsigned mm = __ballot_sync(0xffffffffu, (ek >> 8) == k);
            while (mm) {
              const int j = __ffs(mm) - 1; mm &= mm - 1;
              const unsigned key = __shfl_sync(0xffffffffu, ek, j), val = __shfl_sync(0xffffffffu, ev, j);
              if ((int)((key >> 3) & 31) == lane) {
                const int qq = (key >> 1) & 3, hf = key & 1;
                const uint32_t msk = hf ? 0xffff0000u : 0x0000ffffu, v = hf ? (val << 16) : (val & 0xffffu);
                if (qq == 0) r0 = (r0 & ~msk) | v; else if (qq == 1) r1 = (r1 & ~msk) | v;
                else if (qq == 2) r2 = (r2 & ~msk) | v; else r3 = (r3 & ~msk) | v;
              }
            }
          }
          nk = nextk(k + 1);
        }
        const uint2 b = bl.get((u + uu) * 64 + s * 16);
        mma_bf16(acc, r0, r1, r2, r3, b.x, b.y);
      }
    }
  }
  const float sc0 = bb0 == 255 ? 0.f : __int_as_float((int)(bb0 + 15) << 23), sc1 = bb1 == 255 ? 0.f : __int_as_float((int)(bb1 + 15) << 23);
  acc[0] *= sc0; acc[1] *= sc0; acc[2] *= sc1; acc[3] *= sc1;   // exact: powers of two
}
// units [u0, u0 + nu) of a W12 strip (same MMA order as piece_bf16 over the range; the partial is rescaled by the
// rows' powers of two, exact, so block_strips' sum of partials is bit for bit the BF16 one)
template <class BL>
__device__ __forceinline__ void piece_w12r(const uint8_t* wst, const uint8_t* bases, int u0, int nu, const BL& bl, float* acc) {
  const int lane = lane_id(), g = lane >> 2;
  const uint4 hdr = ldg_nc(wst + lane * 16);
  const unsigned bb0 = __ldg(bases + g), bb1 = __ldg(bases + g + 8);
  const uint8_t* cw = wst + 512 + lane * 48;
  auto nextk = [&](unsigned k) {
    const unsigned a0 = (hdr.x >> 8) >= k ? (hdr.x >> 8) : 0xffffffu, a1 = (hdr.z >> 8) >= k ? (hdr.z >> 8) : 0xffffffu;
    return __reduce_min_sync(0xffffffffu, min(a0, a1));
  };
  float p[4] = {0.f, 0.f, 0.f, 0.f};
  unsigned nk = nextk((unsigned)u0 * 4);
  auto unit = [&](const uint4* w, int u) {
    const uint32_t* wd = reinterpret_cast<const uint32_t*>(w);
#pragma unroll
    for (int s = 0; s < 4; s++) {
      const uint32_t p0 = wd[3 * s], p1 = wd[3 * s + 1], p2 = wd[3 * s + 2];
      uint32_t r0 = w12reg(p0, p2, 0), r1 = w12reg(p0, p2, 1), r2 = w12reg(p1, p2, 2), r3 = w12reg(p1, p2, 3);
      const unsigned k = (unsigned)(u * 4 + s);
      if (k == nk) {   // rare, warp-uniform: patch the exact (rescaled) values of this kstep
#pragma unroll 1
        for (int set = 0; set < 2; set++) {
          const unsigned ek = set ? hdr.z : hdr.x, ev = set ? hdr.w : hdr.y;
          unsigned mm = __ballot_sync(0xffffffffu, (ek >> 8) == k);
          while (mm) {
            const int j = __ffs(mm) - 1; mm &= mm - 1;
            const unsigned key = __shfl_sync(0xffffffffu, ek, j), val = __shfl_sync(0xffffffffu, ev, j);
            if ((int)((key >> 3) & 31) == lane) {
              const int qq = (key >> 1) & 3, hf = key & 1;
              const uint32_t msk = hf ? 0xffff0000u : 0x0000ffffu, v = hf ? (val << 16) : (val & 0xffffu);
              if (qq == 0) r0 = (r0 & ~msk) | v; else if (qq == 1) r1 = (r1 & ~msk) | v;
              else if (qq == 2) r2 = (r2 & ~msk) | v; else r3 = (r3 & ~msk) | v;
            }
          }
        }
        nk = nextk(k + 1);
      }
      const uint2 b = bl.get(u * 64 + s * 16);
      mma_bf16(p, r0, r1, r2, r3, b.x, b.y);
    }
  };
  int u = u0;
  for (; u + 3 <= u0 + nu; u += 3) {
    uint4 w[9];
#pragma unroll
    for (int q = 0; q < 9; q++) w[q] = ldg_nc(cw + (long)(u + q / 3) * 1536 + (q % 3) * 16);
#pragma unroll
    for (int uu = 0; uu < 3; uu++) unit(&w[3 * uu], u + uu);
  }
  for (; u < u0 + nu; u++) {
    uint4 w[3];
#pragma unroll
    for (int q = 0; q < 3; q++) w[q] = ldg_nc(cw + (long)u * 1536 + q * 16);
    unit(w, u);
  }
  const float sc0 = bb0 == 255 ? 0.f : __int_as_float((int)(bb0 + 15) << 23), sc1 = bb1 == 255 ? 0.f : __int_as_float((int)(bb1 + 15) << 23);
  acc[0] += p[0] * sc0; acc[1] += p[1] * sc0; acc[2] += p[2] * sc1; acc[3] += p[3] * sc1;
}

// ---- bulk copies into shared memory (TMA) with an mbarrier (GDPF: gate-D strip prefetch)
#ifndef GDPF
#define GDPF 0
#endif
#define GD_OFF 9344                 // byte offset of the prefetched strip in sm.u (after the [1][2H + 8] bf16 B column)
#define GD_UNITS 36                 // units prefetched (x half of the strip: 36 x 2 KB)
__device__ __forceinline__ uint32_t smaddr(const void* p) { return (uint32_t)__cvta_generic_to_shared(p); }
__device__ __forceinline__ void mbar_init(uint32_t b, uint32_t n) { asm volatile("mbarrier.init.shared::cta.b64 [%0], %1;" :: "r"(b), "r"(n)); }
__device__ __forceinline__ void mbar_expect(uint32_t b, uint32_t bytes) {
  asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%0], %1;" :: "r"(b), "r"(bytes) : "memory");
}
__device__ __forceinline__ void mbar_wait(uint32_t b, uint32_t ph) {
  asm volatile("{ .reg .pred p; W%=: mbarrier.try_wait.parity.shared::cta.b64 p, [%0], %1; @!p bra W%=; }" :: "r"(b), "r"(ph) : "memory");
}
__device__ __forceinline__ void tma_load(uint32_t dst, const void* src, uint32_t bytes, uint32_t bar) {
  asm volatile("cp.async.bulk.shared::cta.global.mbarrier::complete_tx::bytes [%0], [%1], %2, [%3];"
               :: "r"(dst), "l"(src), "r"(bytes), "r"(bar) : "memory");
}
// as piece_bf16 (same MMA order: bit-identical), units below GD_UNITS from the copy in shared memory
template <class BL>
__device__ __forceinline__ void piece_bf16_sm(const uint8_t* wsm, const uint8_t* wst, int u0, int nu, const BL& bl, float* acc) {
  const int lane = lane_id();
  for (int u = u0; u < u0 + nu; u++) {
    uint4 w[4];
    if (u < GD_UNITS) {
#pragma unroll
      for (int q = 0; q < 4; q++) w[q] = *reinterpret_cast<const uint4*>(wsm + (u * 4 + q) * 512 + lane * 16);
    } else {
#pragma unroll
      for (int q = 0; q < 4; q++) w[q] = ldg_nc(wst + ((long)u * 4 + q) * 512 + lane * 16);
    }
#pragma unroll
    for (int q = 0; q < 4; q++) {
      uint2 b = bl.get(u * 64 + q * 16);
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b.x, b.y);
    }
  }
}
template <int UNRX = BF_UNR, class BL>
__device__ __forceinline__ void piece_bf16(const uint8_t* wst, int u0, int nu, const BL& bl, float* acc) {
  const int lane = lane_id();
  int u = u0;
  const int ue = u0 + nu;
  for (; u + UNRX <= ue; u += UNRX) {
    uint4 w[4 * UNRX];
#pragma unroll
    for (int q = 0; q < 4 * UNRX; q++) w[q] = ldg_nc(wst + ((long)(u + (q >> 2)) * 4 + (q & 3)) * 512 + lane * 16);
#pragma unroll
    for (int q = 0; q < 4 * UNRX; q++) {
      uint2 b = bl.get((u + (q >> 2)) * 64 + (q & 3) * 16);
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b.x, b.y);
    }
  }
  for (; u < ue; u++) {
    uint4 w[4];
#pragma unroll
    for (int q = 0; q < 4; q++) w[q] = ldg_nc(wst + ((long)u * 4 + q) * 512 + lane * 16);
#pragma unroll
    for (int q = 0; q < 4; q++) {
      uint2 b = bl.get(u * 64 + q * 16);
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b.x, b.y);
    }
  }
}

// f16 B operand for experts: columns n = 2 * li + part (part 0: hi, 1: lo), li = 4 * ng + t-th token of the expert
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {  // bytes (g,g8) j0, (g,g8) j1 -> {g,g},{g8,g8},{g,g},{g8,g8}
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
// B fragments of one unit (64 k) for NG n-groups: bfr[ng][j] = (b0, b1)
template <int NG>
__device__ __forceinline__ void load_b16_unit(const __half* const* colp, int u, uint2 (*bfr)[4]) {
  const int t = lane_id() & 3;
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    const __half* p = colp[ng];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      if (p) {
        const __half* q = p + u * 64 + j * 16 + 2 * t;
        bfr[ng][j] = make_uint2(*reinterpret_cast<const uint32_t*>(q), *reinterpret_cast<const uint32_t*>(q + 8));
      } else bfr[ng][j] = make_uint2(0, 0);
    }
  }
}
// tagged f16 pairs in global memory: colp points at uint2 rows (pair index k / 2), polled with tag; null columns
// read the first non-null column's address (loads unconditional) and give zeros
template <int NG>
__device__ __forceinline__ void load_b16_unit_gl(const __half* const* colp, int u, uint2 (*bfr)[4], unsigned tag) {
  const int t = lane_id() & 3;
  uint2 r[NG][4][2];
  const uint2* p0 = reinterpret_cast<const uint2*>(colp[2]);   // fallback (always valid)
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    const uint2* p = colp[ng] ? reinterpret_cast<const uint2*>(colp[ng]) : p0;
#pragma unroll
    for (int j = 0; j < 4; j++) { r[ng][j][0] = ld_tag(p + u * 32 + j * 8 + t); r[ng][j][1] = ld_tag(p + u * 32 + j * 8 + 4 + t); }
  }
#pragma unroll
  for (int ng = 0; ng < NG; ng++) {
    const uint2* p = reinterpret_cast<const uint2*>(colp[ng]);
#pragma unroll
    for (int j = 0; j < 4; j++) {
      if (p) bfr[ng][j] = make_uint2(wait_tag(p + u * 32 + j * 8 + t, r[ng][j][0], tag), wait_tag(p + u * 32 + j * 8 + 4 + t, r[ng][j][1], tag));
      else bfr[ng][j] = make_uint2(0, 0);
    }
  }
}

// NVFP4: per unit 576 B: codes [lane][16 B], scales [g][8 B]
template <int NG>
__device__ __forceinline__ void unit_fp4(const uint4& cw, const uint2& sw, const uint2 (*bfr)[4], float (*acc)[4], const uint32_t* s6tab = nullptr) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t ss[2] = {sw.x, sw.y};
#if S6
  // the group's 48 bits start at byte 6 g of the unit's scale area; the two words were loaded at (6 g) & ~3
  const unsigned long long x48 = (((unsigned long long)sw.y << 32) | sw.x) >> (((lane_id() >> 2) & 1) * 16);
#endif
#pragma unroll
  for (int jj = 0; jj < 2; jj++) {
    uint32_t sc[4];
#if S6
    {
      const uint32_t lo = s6tab[(uint32_t)(x48 >> (24 * jj)) & 0xFFFu], hi = s6tab[(uint32_t)(x48 >> (24 * jj + 12)) & 0xFFFu];
      asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
          : "=r"(sc[0]), "=r"(sc[1]), "=r"(sc[2]), "=r"(sc[3]) : "r"(lo), "r"(hi));
      (void)ss;
    }
#else
    scl4(ss[jj], sc);
#endif
#pragma unroll
    for (int h = 0; h < 2; h++) {
      const int j = jj * 2 + h;
      uint32_t a[4];
      cvt4(cc[j], a);
      const uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
      const uint32_t a0 = hmul2(a[0], sg), a1 = hmul2(a[1], sg8), a2 = hmul2(a[2], sg), a3 = hmul2(a[3], sg8);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) mma_f16(acc[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
    }
  }
}
__device__ __forceinline__ void cp_async16(void* smem, const void* gmem);
__device__ __forceinline__ void cp_async_wait();
__device__ __forceinline__ uint2 lds_fp4_scales(const uint4* scb, int ui, int g) {   // unit ui of the staged piece
  const uint8_t* b = reinterpret_cast<const uint8_t*>(scb) + ui * FP4_SCB;
#if S6
  const uint32_t* p = reinterpret_cast<const uint32_t*>(b + ((6 * g) & ~3));
  return make_uint2(p[0], p[1]);
#else
  return *reinterpret_cast<const uint2*>(b + g * 8);
#endif
}
__device__ __forceinline__ uint2 ld_fp4_scales(const uint8_t* unit, int g) {
#if S6
  const uint8_t* sp = unit + 512 + ((6 * g) & ~3);
  return make_uint2(ldg_nc1(sp), ldg_nc1(sp + 4));
#else
  return ldg_nc2(unit + 512 + g * 8);
#endif
}
template <int NG, bool GL>
__device__ __forceinline__ void piece_fp4(const uint8_t* wst, int u0, int nu, const __half* const* colp, float (*acc)[4], unsigned tag = 0, const uint32_t* s6tab = nullptr, uint4* scb = nullptr) {
  const int lane = lane_id(), g = lane >> 2;
  constexpr int UNR = FP4_UNR;
  int u = u0;
  const int ue = u0 + nu;
#if SCS
  // all scale bytes of the piece (nu <= 12 units) into this warp's shared-memory row, in flight with the first codes
  for (int i = lane; i < nu * (FP4_SCB / 16); i += 32)
    cp_async16(scb + i, wst + (long)(u0 + i / (FP4_SCB / 16)) * FP4_UB + 512 + (i % (FP4_SCB / 16)) * 16);
#else
  (void)scb;
#endif
  for (; u + UNR <= ue; u += UNR) {
    uint4 cw[UNR];
#pragma unroll
    for (int q = 0; q < UNR; q++) cw[q] = ldg_nc(wst + (long)(u + q) * FP4_UB + lane * 16);
#if SCS
    cp_async_wait();
#else
    uint2 sw[UNR];
#pragma unroll
    for (int q = 0; q < UNR; q++) sw[q] = ld_fp4_scales(wst + (long)(u + q) * FP4_UB, g);
#endif
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      uint2 bfr[NG][4];
      if (GL) load_b16_unit_gl<NG>(colp, u + q, bfr, tag); else load_b16_unit<NG>(colp, u + q, bfr);
#if SCS
      unit_fp4<NG>(cw[q], lds_fp4_scales(scb, u + q - u0, g), bfr, acc, s6tab);
#else
      unit_fp4<NG>(cw[q], sw[q], bfr, acc, s6tab);
#endif
    }
  }
  for (; u < ue; u++) {
    const uint4 cw = ldg_nc(wst + (long)u * FP4_UB + lane * 16);
#if SCS
    cp_async_wait();
    const uint2 sw = lds_fp4_scales(scb, u - u0, g);
#else
    const uint2 sw = ld_fp4_scales(wst + (long)u * FP4_UB, g);
#endif
    uint2 bfr[NG][4];
    if (GL) load_b16_unit_gl<NG>(colp, u, bfr, tag); else load_b16_unit<NG>(colp, u, bfr);
    unit_fp4<NG>(cw, sw, bfr, acc, s6tab);
  }
}
// MXFP8: per unit 1056 B: codes [lane][32 B] ((j, kh) u32 = rows (g, g8) pairs), scales [g][blk][r] 4 B
template <int NG>
__device__ __forceinline__ void unit_fp8(const uint4& c0, const uint4& c1, uint32_t sw, const uint2 (*bfr)[4], float (*acc)[4]) {
  uint32_t cc[8] = {c0.x, c0.y, c0.z, c0.w, c1.x, c1.y, c1.z, c1.w};
#pragma unroll
  for (int blk = 0; blk < 2; blk++) {
    float d[NG][4];
#pragma unroll
    for (int ng = 0; ng < NG; ng++) { d[ng][0] = d[ng][1] = d[ng][2] = d[ng][3] = 0.f; }
#pragma unroll
    for (int h = 0; h < 2; h++) {
      const int j = blk * 2 + h;
      const uint32_t x0 = cc[2 * j], x1 = cc[2 * j + 1];
      const uint32_t a0 = cvt_e4m3x2(x0 & 0xffff), a1 = cvt_e4m3x2(x0 >> 16), a2 = cvt_e4m3x2(x1 & 0xffff), a3 = cvt_e4m3x2(x1 >> 16);
#pragma unroll
      for (int ng = 0; ng < NG; ng++) mma_f16(d[ng], a0, a1, a2, a3, bfr[ng][j].x, bfr[ng][j].y);
    }
    const uint32_t e0 = (sw >> (16 * blk)) & 0xff, e1 = (sw >> (16 * blk + 8)) & 0xff;
    const float s0 = e0 ? __int_as_float(e0 << 23) : __int_as_float(0x00400000), s1 = e1 ? __int_as_float(e1 << 23) : __int_as_float(0x00400000);
#pragma unroll
    for (int ng = 0; ng < NG; ng++) {
      acc[ng][0] = fmaf(d[ng][0], s0, acc[ng][0]); acc[ng][1] = fmaf(d[ng][1], s0, acc[ng][1]);
      acc[ng][2] = fmaf(d[ng][2], s1, acc[ng][2]); acc[ng][3] = fmaf(d[ng][3], s1, acc[ng][3]);
    }
  }
}
template <int NG, bool GL>
#ifndef FP8_UNR
#define FP8_UNR 2
#endif
__device__ __forceinline__ void piece_fp8(const uint8_t* wst, int u0, int nu, const __half* const* colp, float (*acc)[4], unsigned tag = 0) {
  const int lane = lane_id(), g = lane >> 2;
  constexpr int UNR = FP8_UNR;
  int u = u0;
  const int ue = u0 + nu;
  for (; u + UNR <= ue; u += UNR) {
    uint4 c0[UNR], c1[UNR]; uint32_t sw[UNR];
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      c0[q] = ldg_nc(wst + (long)(u + q) * 1056 + lane * 32);
      c1[q] = ldg_nc(wst + (long)(u + q) * 1056 + lane * 32 + 16);
      sw[q] = ldg_nc1(wst + (long)(u + q) * 1056 + 1024 + g * 4);
    }
#pragma unroll
    for (int q = 0; q < UNR; q++) {
      uint2 bfr[NG][4];
      if (GL) load_b16_unit_gl<NG>(colp, u + q, bfr, tag); else load_b16_unit<NG>(colp, u + q, bfr);
      unit_fp8<NG>(c0[q], c1[q], sw[q], bfr, acc);
    }
  }
  for (; u < ue; u++) {
    const uint4 c0 = ldg_nc(wst + (long)u * 1056 + lane * 32);
    const uint4 c1 = ldg_nc(wst + (long)u * 1056 + lane * 32 + 16);
    const uint32_t sw = ldg_nc1(wst + (long)u * 1056 + 1024 + g * 4);
    uint2 bfr[NG][4];
    if (GL) load_b16_unit_gl<NG>(colp, u, bfr, tag); else load_b16_unit<NG>(colp, u, bfr);
    unit_fp8<NG>(c0, c1, sw, bfr, acc);
  }
}

// three chains over units [6k, 6k + 6) (k = 0, 1, 2) of an 18-unit row strip, interleaved so that six units are in
// flight; each chain accumulates its units in increasing order exactly as piece_fp4 / piece_fp8 over its six units
template <int NG, bool MX>
__device__ __forceinline__ void piece3(const uint8_t* wst, const __half* const* colp, float (*acc)[NG][4]) {
  const int lane = lane_id(), g = lane >> 2;
  constexpr int UB = MX ? 1056 : FP4_UB;
#pragma unroll 1
  for (int j = 0; j < 6; j += 2) {
    uint4 c0[6], c1[6]; uint2 s4[6]; uint32_t s8[6];
#pragma unroll
    for (int q = 0; q < 6; q++) {
      const int u = 6 * (q >> 1) + j + (q & 1);
      if (MX) {
        c0[q] = ldg_nc(wst + (long)u * UB + lane * 32);
        c1[q] = ldg_nc(wst + (long)u * UB + lane * 32 + 16);
        s8[q] = ldg_nc1(wst + (long)u * UB + 1024 + g * 4);
      } else {
        c0[q] = ldg_nc(wst + (long)u * UB + lane * 16);
        s4[q] = ldg_nc2(wst + (long)u * UB + 512 + g * 8);
      }
    }
#pragma unroll
    for (int q = 0; q < 6; q++) {
      const int u = 6 * (q >> 1) + j + (q & 1);
      uint2 bfr[NG][4];
      load_b16_unit<NG>(colp, u, bfr);
      if (MX) unit_fp8<NG>(c0[q], c1[q], s8[q], bfr, acc[q >> 1]);
      else unit_fp4<NG>(c0[q], s4[q], bfr, acc[q >> 1]);
    }
  }
}

// write a warp's piece, return true (in all lanes) if this warp is the last of `npieces` for counter `cnt`;
// then a[] holds the sum of all pieces in piece order.
__device__ __forceinline__ bool piece_reduce(float* part, unsigned* cnt, int piece, int npieces, float* acc) {
  const int lane = lane_id();
  float4* slot = reinterpret_cast<float4*>(part);
  slot[piece * 32 + lane] = make_float4(acc[0], acc[1], acc[2], acc[3]);
  __threadfence();
  __syncwarp();
  unsigned old = 0;
  if (lane == 0) old = atomicAdd(cnt, 1u);
  old = __shfl_sync(0xffffffff, old, 0);
  if (old != (unsigned)(npieces - 1)) return false;
  __threadfence();
  float a0 = 0.f, a1 = 0.f, a2 = 0.f, a3 = 0.f;
  for (int p = 0; p < npieces; p++) {
    float4 v = ldcg_f4(slot + p * 32 + lane);
    a0 += v.x; a1 += v.y; a2 += v.z; a3 += v.w;
  }
  acc[0] = a0; acc[1] = a1; acc[2] = a2; acc[3] = a3;
  if (lane == 0) { atomicExch(cnt, 0u); __threadfence(); }
  __syncwarp();
  return true;
}

// ------------------------------------------------------------------------------------------------ phases
#define PH_ARGS const Ctx& c, const Hdr& hd, Smem& sm
#ifdef MKPROF
#define SUBMARK(tag) do { if (c.prof && threadIdx.x == 0) { unsigned n_ = sm.subn++; if (n_ < 1024) { unsigned long long* r_ = (unsigned long long*)c.prof + 2ull * ((unsigned long long)blockIdx.x * 4096 + 3072 + n_); r_[0] = mkprof_gtime(); r_[1] = ((unsigned long long)clock64() << 16) | (tag); } } } while (0)
#else
#define SUBMARK(tag) do {} while (0)
#endif

// static short convolution (kernel 4, tap 3 = current), identity residual, x 5^-1/2; ring of the last 3 raw inputs
__device__ __forceinline__ float sconv_static(float x, const bf16* hist_row_base, long ring_stride, int pos, const bf16* w4) {
  const float x1 = ldcg_bf(hist_row_base + ((pos + 2) % 3) * ring_stride);
  const float x2 = ldcg_bf(hist_row_base + ((pos + 1) % 3) * ring_stride);
  const float x3 = ldcg_bf(hist_row_base + (pos % 3) * ring_stride);
  float acc = __fmul_rn(x3, bf(w4[0]));
  acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
  acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
  acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
  return __fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f);
}

// ---- B >= 2: designated blocks publish normalized rows (tagged bf16 pairs); every block polls them
// x (f32, nq streams) -> rmsnorm with weights -> published pairs dst[q] (row of NPAIR words)
template <int NQ>
__device__ __forceinline__ void norm_publish(const float (*x)[EPT], const float (*wv)[EPT], int nq, uint2* const* dst, unsigned tag, Smem& sm) {
  float s[NQ];
#pragma unroll
  for (int q = 0; q < NQ; q++) { s[q] = 0.f;
#pragma unroll
    for (int k = 0; k < EPT; k++) s[q] += x[q][k] * x[q][k]; }
  block_sum<NQ>(s, sm);
#pragma unroll
  for (int q = 0; q < NQ; q++) {
    if (q >= nq) continue;
    const float r = rsqrtf(s[q] / (float)H + 1e-6f);
#pragma unroll
    for (int j = 0; j < 2; j++)
      if (EV(2 * j)) st_tag(dst[q] + threadIdx.x + j * NTH, pack_bf2(x[q][2 * j] * r * wv[q][2 * j], x[q][2 * j + 1] * r * wv[q][2 * j + 1]), tag);
  }
}
// poll nrows published rows (row r at src + r * NPAIR) into smem rows dst(r) (bf16, pairs)
template <class DST>
__device__ __forceinline__ void poll_rows(const uint2* src, int nrows, DST dst, unsigned tag) {
  const int n = nrows * NPAIR;   // words, two per load
  for (int i0 = 2 * threadIdx.x; i0 < n; i0 += 2 * NTH * 8) {
    uint2 r[8][2];
#pragma unroll
    for (int q = 0; q < 8; q++) ld_tag2(src + min(i0 + q * 2 * NTH, n - 2), r[q][0], r[q][1]);
#if (BPX >> 9) & 1
    {
      unsigned vm = 0u;
#pragma unroll
      for (int q = 0; q < 8; q++) if (i0 + q * 2 * NTH < n) vm |= 3u << (2 * q);
      wait_all<16>([&](int i) { return src + min(i0 + (i >> 1) * 2 * NTH, n - 2) + (i & 1); }, &r[0][0], tag, vm);
    }
#endif
#pragma unroll
    for (int q = 0; q < 8; q++) {
      const int i = i0 + q * 2 * NTH;
      if (i >= n) continue;
      const int row = i / NPAIR, w = i % NPAIR;
      uint32_t* d = reinterpret_cast<uint32_t*>(dst(row)) + w;
      d[0] = wait_tag(src + i, r[q][0], tag);
      d[1] = wait_tag(src + i + 1, r[q][1], tag);
    }
  }
}

// The attention input streams of application a -> normalized bf16 smem streams (returns their number), or for the
// gated applications (loop passes 2 and 3) G1: blocks (token, controller) write x, m and [unit(x), unit(m)] (returns -1)
#ifndef XPF
#define XPF 0
#endif
#ifndef QPF_MINB
#define QPF_MINB 2
#endif
#ifndef XPF_MINB
#define XPF_MINB 2
#endif
__device__ NI_ATTNIN int ph_attn_in(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB;
#if XPF
  // track B: the experts this application is likely to choose (loop passes 2, 3: the same layer's union of the previous
  // pass, ~5 of 8 shared per token; otherwise this application's union at the previous token), into L2 while the
  // attention half runs; each block its 1/gridDim share of every expert's w13 and w2
  if (B >= XPF_MINB && c.rhist && threadIdx.x >= 64 && threadIdx.x < 64 + MAXU) {
    const int src = ap.pass > 0 ? a - 12 : a;
    const int* rh = c.rhist + src * (MAXU + 1);
    const int nu = min(__ldcg(rh + MAXU), MAXU), u = threadIdx.x - 64;
    if (u < nu) {
      const int e = __ldcg(rh + u);
      const long ub = L.mx ? 1056 : FP4_UB;
      const long b13 = 144L * 36 * ub, b2 = 144L * 18 * ub;
      const long o13 = (b13 * blockIdx.x / gridDim.x) & ~15L, e13 = (b13 * (blockIdx.x + 1) / gridDim.x) & ~15L;
      const long o2 = (b2 * blockIdx.x / gridDim.x) & ~15L, e2 = (b2 * (blockIdx.x + 1) / gridDim.x) & ~15L;
      pf_l2(L.w13 + e * b13 + o13, e13 - o13);
      pf_l2(L.w2 + e * b2 + o2, e2 - o2);
    }
  }
#endif
  if (B >= QPF_MINB && threadIdx.x < 4) {   // this block's qkv strips into L2 while the mix waits for its sources (B >= 2: the mix is long enough)
    const int strip = blockIdx.x + threadIdx.x * gridDim.x;
    if (strip < QG_STRIPS + 2 * L.nsk) pf_l2(L.wqkv + (long)strip * (W12Q ? W12_STRIP : 36 * 2048), W12Q ? W12_STRIP : 36 * 2048);
  } else if (B >= 2 && threadIdx.x == 32 && blockIdx.x < 8) pf_l2(L.wr + (long)blockIdx.x * 36 * 2048, 36 * 2048);   // router strip
  const int nq = L.glob ? 3 : 1;
  const int par = a & 1;
  if (ap.nmsg == 0 && B >= 2) {
    uint2* xs_pub = c.xst + (long)par * 3 * MAXB * NPAIR;   // [3][MAXB][NPAIR]
    for (int job = blockIdx.x; job < B * nq; job += gridDim.x) {
      const int b = job / nq, q = job % nq;
      float x[1][EPT];
      if (a == 0) {
        const int tok = hd.tokens ? hd.tokens[b] : (int)poll(c.ntt + b, hd.tok_tag);
        const bf16* er = c.embed + (long)tok * H;
        float e[EPT], s[1] = {0.f};
#pragma unroll
        for (int j = 0; j < 2; j++) {
          __nv_bfloat162 w2 = EV(2 * j) ? *reinterpret_cast<const __nv_bfloat162*>(er + EL(2 * j)) : __floats2bfloat162_rn(0.f, 0.f);
          e[2 * j] = bf(w2.x); e[2 * j + 1] = bf(w2.y);
        }
#pragma unroll
        for (int k = 0; k < EPT; k++) s[0] += e[k] * e[k];
        block_sum<1>(s, sm);
        const float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
        for (int j = 0; j < 2; j++) {
          if (!EV(2 * j)) { x[0][2 * j] = x[0][2 * j + 1] = 0.f; continue; }
          const int el = EL(2 * j);
          const __nv_bfloat162 nw = *reinterpret_cast<const __nv_bfloat162*>(c.embed_norm + el);
          const uint32_t hv = pack_bf2(e[2 * j] * r * bf(nw.x), e[2 * j + 1] * r * bf(nw.y));
          st_tag(c.pbt + (long)b * NPAIR + threadIdx.x + j * NTH, hv, TAGP(0));
          x[0][2 * j] = bf_lo(hv); x[0][2 * j + 1] = bf_hi(hv);
        }
      } else {
        float v[5][EPT];
        const int idx[5] = {ap.blk[0], ap.blk[1], ap.blk[2], ap.blk[3], ap.pin};
        const unsigned msk = ((1u << ap.nblk) - 1u) | 16u;
        const float* qs[1] = {L.aq + q * H};
        float qv[1][EPT];
        load_queries<1>(qs, 1, qv);
        load_srcs<5>(c, hd, idx, msk, b, v);
        depth_mix_q<5, 1>(v, msk, qv, 1, x, sm);
      }
      float wv[1][EPT];
      load_w(L.norm[q], wv[0]);
      uint2* dst[1] = {xs_pub + ((long)q * MAXB + b) * NPAIR};
      norm_publish<1>(x, wv, 1, dst, TAGA(a), sm);
    }
    for (int q = 0; q < nq; q++)
      poll_rows(xs_pub + (long)q * MAXB * NPAIR, B, [&](int r) { return &sm.u.xs[q][r][0]; }, TAGA(a));
    __syncthreads();
    return nq;
  }
  if (ap.nmsg == 0) {
    for (int b = 0; b < B; b++) {
      float v[5][EPT];
      float x[3][EPT];
      if (a == 0) {
        // h0 = rmsnorm(embed[tok]) * embed_norm (bf16); block 0 publishes it as pbt[0]
        const int tok = hd.tokens ? hd.tokens[b] : (int)poll(c.ntt + b, hd.tok_tag);
        const bf16* er = c.embed + (long)tok * H;
        float e[EPT], s[1] = {0.f};
#pragma unroll
        for (int j = 0; j < 2; j++) {
          __nv_bfloat162 w2 = EV(2 * j) ? *reinterpret_cast<const __nv_bfloat162*>(er + EL(2 * j)) : __floats2bfloat162_rn(0.f, 0.f);
          e[2 * j] = bf(w2.x); e[2 * j + 1] = bf(w2.y);
        }
#pragma unroll
        for (int k = 0; k < EPT; k++) s[0] += e[k] * e[k];
        block_sum<1>(s, sm);
        const float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
        for (int j = 0; j < 2; j++) {
          if (!EV(2 * j)) { x[0][2 * j] = x[0][2 * j + 1] = 0.f; continue; }
          const int el = EL(2 * j);
          const __nv_bfloat162 nw = *reinterpret_cast<const __nv_bfloat162*>(c.embed_norm + el);
          const uint32_t hv = pack_bf2(e[2 * j] * r * bf(nw.x), e[2 * j + 1] * r * bf(nw.y));
          if (blockIdx.x == 0) st_tag(c.pbt + (long)b * NPAIR + threadIdx.x + j * NTH, hv, TAGP(0));
          x[0][2 * j] = bf_lo(hv); x[0][2 * j + 1] = bf_hi(hv);
        }
      } else {
        const int idx[5] = {ap.blk[0], ap.blk[1], ap.blk[2], ap.blk[3], ap.pin};
        const unsigned msk = ((1u << ap.nblk) - 1u) | 16u;
        const float* qs[3] = {L.aq, L.aq + H, L.aq + 2 * H};
        float qv[3][EPT];
        SUBMARK(30);
#if QLIN
        if (B == 1) {
          if (blockIdx.x == gridDim.x - 1) {         // the mixer block: coefficients only, no strips
            float cf[3][5];
            load_queries<3>(qs, nq, qv);
            load_srcs<5>(c, hd, idx, msk, b, v);
            depth_mix_cf3<5>(v, msk, qv, nq, cf, sm);
            if (threadIdx.x < 15)
              st_tagf(c.gzt + ((long)(a & 1) * MAXB * 4 + threadIdx.x / 5) * 64 * 8 + threadIdx.x % 5, cf[threadIdx.x / 5][threadIdx.x % 5], TAGA(a));
          } else {                                   // columns w . v_s per stream (BF16), then straight to the qkv strips
            load_srcs<5>(c, hd, idx, msk, b, v);
            float wn[3][EPT];
            for (int q = 0; q < 3; q++) load_w(L.norm[q < nq ? q : 0], wn[q]);
#pragma unroll
            for (int q = 0; q < 3; q++) {
              if (q >= nq) continue;
#pragma unroll
              for (int sx = 0; sx < 5; sx++)
#pragma unroll
                for (int j = 0; j < 2; j++)
                  if (EV(2 * j))
                    *reinterpret_cast<uint32_t*>(&sm.u.xs[q][sx][EL(2 * j)]) =
                      ((msk >> sx) & 1u) ? pack_bf2(v[sx][2 * j] * wn[q][2 * j], v[sx][2 * j + 1] * wn[q][2 * j + 1]) : 0u;
            }
          }
          __syncthreads();
          return nq | 8;
        }
#endif
        load_queries<3>(qs, nq, qv);                 // weights first: independent of the polled sources
        load_srcs<5>(c, hd, idx, msk, b, v);
        SUBMARK(31);
        if (nq == 1) depth_mix_q<5, 1>(v, msk, qv, 1, x, sm); else depth_mix_q<5, 3>(v, msk, qv, 3, x, sm);
        SUBMARK(32);
      }
      float wv[3][EPT];
      for (int q = 0; q < 3; q++) load_w(L.norm[q < nq ? q : 0], wv[q]);
      bf16* dst[3] = {&sm.u.xs[0][b][0], &sm.u.xs[1][b][0], &sm.u.xs[2][b][0]};
      if (nq == 1) rmsnorm_store_n<1>(x, wv, 1, dst, sm); else rmsnorm_store_n<3>(x, wv, 3, dst, sm);
      SUBMARK(33);
    }
    __syncthreads();
    return nq;
  }
  return -1;
}
// mlp-gate G1: block per token (controller 3)
__device__ void mlp_mix(PH_ARGS, int a, int b, float (*x)[EPT]);
__device__ void ph_mlp_g1(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const int B = HDB, par = a & 1;
  for (int b = blockIdx.x; b < B; b += gridDim.x) {
    float x[1][EPT], m[1][EPT], ms[2][EPT];
    mlp_mix(c, hd, sm, a, b, x);
    load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
    const float* mq[1] = {c.loopq + ((long)ap.loopl * 4 + 3) * H};
    depth_mix<2, 1>(ms, 3u, mq, 1, m, sm);
    float s2[2] = {0.f, 0.f};
#pragma unroll
    for (int k = 0; k < EPT; k++) { s2[0] += x[0][k] * x[0][k]; s2[1] += m[0][k] * m[0][k]; }
    block_sum<2>(s2, sm);
    const float rx = rsqrtf(s2[0] / (float)H + 1e-6f), rm = rsqrtf(s2[1] / (float)H + 1e-6f);
    const long o = ((long)(par * MAXB + b) * 4 + 3) * H;
#pragma unroll
    for (int j = 0; j < 2; j++) {
      if (!EV(2 * j)) continue;
      const int el = EL(2 * j);
      st_tagf(c.xgt + o + el, x[0][2 * j], TAGA(a)); st_tagf(c.xgt + o + el + 1, x[0][2 * j + 1], TAGA(a));
      st_tagf(c.mgt + o + el, m[0][2 * j], TAGA(a)); st_tagf(c.mgt + o + el + 1, m[0][2 * j + 1], TAGA(a));
      st_tag(c.ubt + o + el / 2, pack_bf2(x[0][2 * j] * rx, x[0][2 * j + 1] * rx), TAGA(a));
      st_tag(c.ubt + o + NPAIR + el / 2, pack_bf2(m[0][2 * j] * rm, m[0][2 * j + 1] * rm), TAGA(a));
    }
  }
}

// Gate down-projection D [64, 4608] of controllers [c0, c0 + nc) (c0 = 3: the MLP input gate). One block per
// (controller, strip of 16 rows, token): it computes the token's stream x (attention-input or MLP-input mix) and the
// message m itself, the unit vectors [x / rms(x), m / rms(m)] as the B column in shared memory, 24 warps x 3 units;
// strip 0 also publishes x and m (f32) for the F / G phase.
// track B (GLIN): the attention gates' down-projection linearised over the raw sources of the depth mix.
// x = sum_s cx[s] v_s (5 published sources) and m = sum_s cm[s] u_s (2 message sources), so
//   D [x / rms(x); m / rms(m)] = (sum_s cx[s] D_x v_s) / rms(x) + (sum_s cm[s] D_m u_s) / rms(m)   (exactly).
// D jobs (controller, strip of 16 rows, token) no longer wait for the mix: they poll the raw sources into shared
// memory as MMA columns (0..4: [v_s | 0], 5..6: [0 | u_s]) and publish Z = D x columns; mix jobs (controller, token) on
// other blocks compute x, m and the coefficients in parallel, then combine 64 x 7 values of Z into the gate vector.
// The unit vector is no longer rounded to BF16 before the projection.
#ifndef GLIN
#define GLIN 0
#endif
#ifndef GDU
#define GDU BF_UNR   // units per load batch in the linearised gate's D strip (72 units / 24 warps = 3)
#endif
#ifndef GLIN_MF
#define GLIN_MF 0
#endif
#ifndef GLIN_MMF
#define GLIN_MMF 0
#endif
#if GLIN
__device__ NI_GATED void ph_gate_lin(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, par = a & 1;
  constexpr int ST = 2 * H + 8, SW = ST / 2;                      // column stride in bf16 / in pair words
  const int ND = 3 * 4 * B, NM = 3 * B;
  const int idx[5] = {ap.blk[0], ap.blk[1], ap.blk[2], ap.blk[3], ap.pin};
  const unsigned msk = ((1u << ap.nblk) - 1u) | 16u;
  const int p1 = EV(2) ? threadIdx.x + NTH : threadIdx.x;
  // ---- D jobs
  for (int it = blockIdx.x; it < ND; it += gridDim.x) {
    const int b = it % B, sj = it / B, ctrl = sj / 4, j = sj % 4, strip = ctrl * 4 + j;
#if GDL2
    if (threadIdx.x == 0) { pf_l2(L.cD + (long)strip * 72 * 2048, 36 * 2048); }
    if (threadIdx.x == 1) { pf_l2(L.cD + ((long)strip * 72 + 36) * 2048, 36 * 2048); }
#endif
    uint32_t* xw = reinterpret_cast<uint32_t*>(&sm.u.xs[0][0][0]);   // [8 columns][SW] pair words
    uint2 r[7][2];
#pragma unroll
    for (int s = 0; s < 7; s++) {
      const uint2* base = c.pbt + ((long)(s < 5 ? idx[s] : ap.msg[s - 5]) * MAXB + b) * NPAIR;
      r[s][0] = ld_tag(base + threadIdx.x);
      r[s][1] = ld_tag(base + p1);
    }
    // the parts that stay zero: m half of columns 0..4, x half of columns 5..6, column 7, masked-out sources, pads
    for (int i = threadIdx.x; i < 8 * SW; i += NTH) {
      const int col = i / SW, k = i - col * SW;
      const bool keep = (col < 5 && k < NPAIR && ((msk >> col) & 1u)) || ((col == 5 || col == 6) && k >= NPAIR && k < 2 * NPAIR);
      if (!keep) xw[i] = 0u;
    }
#pragma unroll
    for (int s = 0; s < 7; s++) {
      const bool on = s >= 5 || ((msk >> s) & 1u);
      const int src = s < 5 ? idx[s] : ap.msg[s - 5];
      const uint2* base = c.pbt + ((long)src * MAXB + b) * NPAIR;
      const unsigned tg = TAGP(src);
      const uint32_t x0 = on ? wait_tag(base + threadIdx.x, r[s][0], tg) : 0u;
      const uint32_t x1 = (on && EV(2)) ? wait_tag(base + p1, r[s][1], tg) : 0u;
      uint32_t* col = xw + s * SW + (s >= 5 ? NPAIR : 0);
      if (on) { col[threadIdx.x] = x0; if (EV(2)) col[p1] = x1; }
    }
    __syncthreads();
    BSm bl{reinterpret_cast<const bf16*>(xw), ST, 7};
    block_strips<NWARP, 1>(sm, 1, 72,
      [&](int, int u0, int nu, float (*acc)[4]) { piece_bf16<GDU>(L.cD + (long)strip * 72 * 2048, u0, nu, bl, acc[0]); },
      [&](int, float (*acc)[4]) {
        const int lane = lane_id(), g = lane >> 2, t = lane & 3;
        uint2* zp = c.gzt + ((((long)(par * MAXB + b) * 4 + ctrl) * 64) + j * 16) * 8;
        st_tagf(zp + g * 8 + 2 * t, acc[0][0], TAGA(a));       st_tagf(zp + g * 8 + 2 * t + 1, acc[0][1], TAGA(a));
        st_tagf(zp + (g + 8) * 8 + 2 * t, acc[0][2], TAGA(a)); st_tagf(zp + (g + 8) * 8 + 2 * t + 1, acc[0][3], TAGA(a));
      });
    __syncthreads();
  }
  // ---- mix jobs
  for (int km = (int)blockIdx.x - ND; km >= 0 && km < NM; km += gridDim.x) {
    const int ctrl = km / B, b = km % B;
    float v[5][EPT], x[1][EPT], ms[2][EPT], m[1][EPT], cx[5], cm[2];
    {
#if GLIN_MF
      // the message first: its two sources are states of the previous pass (ready), the x mix waits for the newest
      const float* mq[1] = {c.loopq + ((long)ap.loopl * 4 + ctrl) * H};
      float mqv[1][EPT];
      load_queries<1>(mq, 1, mqv);
      load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
      depth_mix_coef<2>(ms, 3u, mqv, m, cm, sm);
      const float* qs[1] = {L.aq + (L.glob ? ctrl : 0) * H};
      float qv[1][EPT];
      load_queries<1>(qs, 1, qv);
      load_srcs<5>(c, hd, idx, msk, b, v);
      depth_mix_coef<5>(v, msk, qv, x, cx, sm);
#else
      const float* qs[1] = {L.aq + (L.glob ? ctrl : 0) * H};
      float qv[1][EPT];
      load_queries<1>(qs, 1, qv);
      load_srcs<5>(c, hd, idx, msk, b, v);
      depth_mix_coef<5>(v, msk, qv, x, cx, sm);
      const float* mq[1] = {c.loopq + ((long)ap.loopl * 4 + ctrl) * H};
      float mqv[1][EPT];
      load_queries<1>(mq, 1, mqv);
      load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
      depth_mix_coef<2>(ms, 3u, mqv, m, cm, sm);
#endif
    }
    float s2[2] = {0.f, 0.f};
#pragma unroll
    for (int k = 0; k < EPT; k++) { s2[0] += x[0][k] * x[0][k]; s2[1] += m[0][k] * m[0][k]; }
    block_sum<2>(s2, sm);
    const float rx = rsqrtf(s2[0] / (float)H + 1e-6f), rm = rsqrtf(s2[1] / (float)H + 1e-6f);
    const long o = ((long)(par * MAXB + b) * 4 + ctrl) * H;
#pragma unroll
    for (int jj = 0; jj < 2; jj++) {
      if (!EV(2 * jj)) continue;
      const int el = EL(2 * jj);
      st_tagf(c.xgt + o + el, x[0][2 * jj], TAGA(a)); st_tagf(c.xgt + o + el + 1, x[0][2 * jj + 1], TAGA(a));
      st_tagf(c.mgt + o + el, m[0][2 * jj], TAGA(a)); st_tagf(c.mgt + o + el + 1, m[0][2 * jj + 1], TAGA(a));
    }
    float* zs = reinterpret_cast<float*>(&sm.u.xs[0][0][0]);
    if (threadIdx.x < 512) zs[threadIdx.x] = pollf(c.gzt + (((long)(par * MAXB + b) * 4 + ctrl) * 64) * 8 + threadIdx.x, TAGA(a));
    __syncthreads();
    if (threadIdx.x < 64) {
      const float* zr = zs + threadIdx.x * 8;
      float zx = 0.f, zm = 0.f;
#pragma unroll
      for (int s = 0; s < 5; s++) zx += cx[s] * zr[s];
      zm = cm[0] * zr[5] + cm[1] * zr[6];
      st_tagf(c.gvt + ((long)(par * MAXB + b) * 4 + ctrl) * 64 + threadIdx.x, rbf(zx * rx + zm * rm), TAGA(a));
    }
    __syncthreads();
  }
}
// the same for the MLP-input gate (controller 3): x = MLP-input mix over the block partials, the pin and the
// attention output (the pin partial may enter twice: as its own source and added to the attention output), so the
// raw columns are 0..3 block partials, 4 pin, 5 attention output, 6..7 message sources
__device__ NI_GATED void ph_mgate_lin(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, par = a & 1;
  constexpr int ST = 2 * H + 8, SW = ST / 2;
  const int ND = 4 * B, NM = B;
  const bool add_pin = !(a == 0 || ap.bnd);
  const int idx[6] = {a == 0 ? 0 : ap.blk[0], ap.blk[1], ap.blk[2], ap.blk[3], ap.pin, ap.pin};
  const unsigned msk = (a == 0) ? 1u : (((1u << ap.nblk) - 1u) | (ap.bnd ? 16u : 0u));
  const unsigned cmsk = msk | (add_pin ? 16u : 0u);               // raw columns 0..4 in use (5: always)
  const int p1 = EV(2) ? threadIdx.x + NTH : threadIdx.x;
  for (int it = blockIdx.x; it < ND; it += gridDim.x) {
    const int b = it % B, j = it / B, strip = 3 * 4 + j;
#if GDL2
    if (threadIdx.x == 0) { pf_l2(L.cD + (long)strip * 72 * 2048, 36 * 2048); }
    if (threadIdx.x == 1) { pf_l2(L.cD + ((long)strip * 72 + 36) * 2048, 36 * 2048); }
#endif
    uint32_t* xw = reinterpret_cast<uint32_t*>(&sm.u.xs[0][0][0]);   // [8 columns][SW] pair words
    const uint2* bases[8]; unsigned tags[8];
#pragma unroll
    for (int s = 0; s < 5; s++) { bases[s] = c.pbt + ((long)idx[s] * MAXB + b) * NPAIR; tags[s] = TAGP(idx[s]); }
    bases[5] = c.attst + (long)(par * MAXB + b) * NPAIR; tags[5] = TAGA(a);
#pragma unroll
    for (int s = 0; s < 2; s++) { bases[6 + s] = c.pbt + ((long)ap.msg[s] * MAXB + b) * NPAIR; tags[6 + s] = TAGP(ap.msg[s]); }
    uint2 r[8][2];
#pragma unroll
    for (int s = 0; s < 8; s++) { r[s][0] = ld_tag(bases[s] + threadIdx.x); r[s][1] = ld_tag(bases[s] + p1); }
    for (int i = threadIdx.x; i < 8 * SW; i += NTH) {
      const int col = i / SW, k = i - col * SW;
      const bool keep = (col < 5 && k < NPAIR && ((cmsk >> col) & 1u)) || (col == 5 && k < NPAIR) || (col >= 6 && k >= NPAIR && k < 2 * NPAIR);
      if (!keep) xw[i] = 0u;
    }
#pragma unroll
    for (int s = 0; s < 8; s++) {
      const bool on = s >= 5 || ((cmsk >> s) & 1u);
      const uint32_t x0 = on ? wait_tag(bases[s] + threadIdx.x, r[s][0], tags[s]) : 0u;
      const uint32_t x1 = (on && EV(2)) ? wait_tag(bases[s] + p1, r[s][1], tags[s]) : 0u;
      uint32_t* col = xw + s * SW + (s >= 6 ? NPAIR : 0);
      if (on) { col[threadIdx.x] = x0; if (EV(2)) col[p1] = x1; }
    }
    __syncthreads();
    BSm bl{reinterpret_cast<const bf16*>(xw), ST, 8};
    block_strips<NWARP, 1>(sm, 1, 72,
      [&](int, int u0, int nu, float (*acc)[4]) { piece_bf16(L.cD + (long)strip * 72 * 2048, u0, nu, bl, acc[0]); },
      [&](int, float (*acc)[4]) {
        const int lane = lane_id(), g = lane >> 2, t = lane & 3;
        uint2* zp = c.gzt + ((((long)(par * MAXB + b) * 4 + 3) * 64) + j * 16) * 8;
        st_tagf(zp + g * 8 + 2 * t, acc[0][0], TAGA(a));       st_tagf(zp + g * 8 + 2 * t + 1, acc[0][1], TAGA(a));
        st_tagf(zp + (g + 8) * 8 + 2 * t, acc[0][2], TAGA(a)); st_tagf(zp + (g + 8) * 8 + 2 * t + 1, acc[0][3], TAGA(a));
      });
    __syncthreads();
  }
  for (int km = (int)blockIdx.x - ND; km >= 0 && km < NM; km += gridDim.x) {
    const int b = km;
    float v[6][EPT], x[1][EPT], ms[2][EPT], m[1][EPT], c6[6], cm[2];
    {
#if GLIN_MMF
      // the message first (its sources are ready); the x mix waits for the attention output
      const float* mq[1] = {c.loopq + ((long)ap.loopl * 4 + 3) * H};
      float mqv[1][EPT];
      load_queries<1>(mq, 1, mqv);
      load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
      depth_mix_coef<2>(ms, 3u, mqv, m, cm, sm);
      const float* qs[1] = {L.mq};
      float qv[1][EPT];
      load_queries<1>(qs, 1, qv);
      load_srcs<6>(c, hd, idx, msk | (add_pin ? 32u : 0u), b, v);
      float as[EPT];
      load_vec_bf(c.attst + (long)(par * MAXB + b) * NPAIR, TAGA(a), as);
#pragma unroll
      for (int k = 0; k < EPT; k++) v[5][k] = add_pin ? v[5][k] + as[k] : as[k];
      depth_mix_coef<6>(v, msk | 32u, qv, x, c6, sm);
#else
      const float* qs[1] = {L.mq};
      float qv[1][EPT];
      load_queries<1>(qs, 1, qv);
      load_srcs<6>(c, hd, idx, msk | (add_pin ? 32u : 0u), b, v);
      float as[EPT];
      load_vec_bf(c.attst + (long)(par * MAXB + b) * NPAIR, TAGA(a), as);
#pragma unroll
      for (int k = 0; k < EPT; k++) v[5][k] = add_pin ? v[5][k] + as[k] : as[k];
      depth_mix_coef<6>(v, msk | 32u, qv, x, c6, sm);
      const float* mq[1] = {c.loopq + ((long)ap.loopl * 4 + 3) * H};
      float mqv[1][EPT];
      load_queries<1>(mq, 1, mqv);
      load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
      depth_mix_coef<2>(ms, 3u, mqv, m, cm, sm);
#endif
    }
    float s2[2] = {0.f, 0.f};
#pragma unroll
    for (int k = 0; k < EPT; k++) { s2[0] += x[0][k] * x[0][k]; s2[1] += m[0][k] * m[0][k]; }
    block_sum<2>(s2, sm);
    const float rx = rsqrtf(s2[0] / (float)H + 1e-6f), rm = rsqrtf(s2[1] / (float)H + 1e-6f);
    const long o = ((long)(par * MAXB + b) * 4 + 3) * H;
#pragma unroll
    for (int jj = 0; jj < 2; jj++) {
      if (!EV(2 * jj)) continue;
      const int el = EL(2 * jj);
      st_tagf(c.xgt + o + el, x[0][2 * jj], TAGA(a)); st_tagf(c.xgt + o + el + 1, x[0][2 * jj + 1], TAGA(a));
      st_tagf(c.mgt + o + el, m[0][2 * jj], TAGA(a)); st_tagf(c.mgt + o + el + 1, m[0][2 * jj + 1], TAGA(a));
    }
    // raw-column coefficients: the pin column gets its own source's weight plus the attention-output source's
    const float cc4 = c6[4] + (add_pin ? c6[5] : 0.f);
    float* zs = reinterpret_cast<float*>(&sm.u.xs[0][0][0]);
    if (threadIdx.x < 512) zs[threadIdx.x] = pollf(c.gzt + (((long)(par * MAXB + b) * 4 + 3) * 64) * 8 + threadIdx.x, TAGA(a));
    __syncthreads();
    if (threadIdx.x < 64) {
      const float* zr = zs + threadIdx.x * 8;
      const float zx = c6[0] * zr[0] + c6[1] * zr[1] + c6[2] * zr[2] + c6[3] * zr[3] + cc4 * zr[4] + c6[5] * zr[5];
      const float zm = cm[0] * zr[6] + cm[1] * zr[7];
      st_tagf(c.gvt + ((long)(par * MAXB + b) * 4 + 3) * 64 + threadIdx.x, rbf(zx * rx + zm * rm), TAGA(a));
    }
    __syncthreads();
  }
}
#endif
// gate-D K-split (track A): at small batches every (controller, strip, token) job is split over DKS blocks by units
// (the blocks would idle otherwise); F/G adds the DKS partials in a fixed order
#ifndef GDL2
#define GDL2 1
#endif
#ifndef DKS
#define DKS 1
#endif
__device__ __forceinline__ int gate_ks(int B, int nc) { return (DKS > 1 && !(GLIN && !MSGZ) && nc * 4 * B * DKS <= 152 / 2) ? DKS : 1; }   // GLIN writes gvt directly
__device__ NI_GATED void ph_gate_d(PH_ARGS, int a, int c0, int nc) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, par = a & 1;
  const int KS = gate_ks(B, nc);
  const int N = nc * 4 * B * KS;
  constexpr int ST = 2 * H + 8;
  bf16* xb = &sm.u.xs[0][0][0];                                   // [1][ST]
#if MSGZ && MSGZ_PF
  {
    // track B (MSGZ_PF): this application's messages and z_m were written at the pass start and have left L2 by now;
    // the highest blocks (no D job) bring them back for the D epilogues and the F/G tasks: one small prefetch each
    const int k = (int)gridDim.x - 1 - (int)blockIdx.x;
    if (threadIdx.x == 0 && k < nc * B) {
      const int ctrl = c0 + k / B, b = k % B;
      pf_l2(c.mg2t + (((long)ap.loopl * 4 + ctrl) * MAXB + b) * H, (long)H * 16);
      pf_l2(c.mzt + (((long)ap.loopl * 4 + ctrl) * MAXB + b) * 64, 64 * 16);
    }
  }
#endif
  for (int it = blockIdx.x; it < N; it += gridDim.x) {
    const int ks = it % KS, b = (it / KS) % B, sj = it / KS / B, ctrl = c0 + sj / 4, j = sj % 4, strip = ctrl * 4 + j;
#if GDL2
    // track A: this job's D strip (weights) into L2 while the block mixes x (one instruction, no wait)
    if (threadIdx.x == 0) pf_l2(L.cD + (long)strip * 72 * 2048, (MSGZ ? 36 : 72) * 2048);
#endif
#if GDPF
    // track A: the D strip (weights, independent of x) into shared memory while the block mixes x
    const uint8_t* wsm = reinterpret_cast<const uint8_t*>(&sm.u) + GD_OFF;
    __syncthreads();
    const unsigned gph = sm.gdph;
    if (threadIdx.x == 0) {
      asm volatile("fence.proxy.async.shared::cta;" ::: "memory");
      const uint32_t bar = smaddr(&sm.gdbar);
      mbar_expect(bar, GD_UNITS * 2048);
      for (int k = 0; k < 4; k++)
        tma_load(smaddr(wsm) + k * (GD_UNITS / 4) * 2048, L.cD + ((long)strip * 72 + k * (GD_UNITS / 4)) * 2048, (GD_UNITS / 4) * 2048, bar);
    }
#endif
    float x[1][EPT], m[1][EPT], ms[2][EPT];
    {
      float mqv[1][EPT];
#if !MSGZ
      const float* mq[1] = {c.loopq + ((long)ap.loopl * 4 + ctrl) * H};
      load_queries<1>(mq, 1, mqv);
#endif
      if (ctrl < 3) {
        float v[5][EPT];
        const int idx[5] = {ap.blk[0], ap.blk[1], ap.blk[2], ap.blk[3], ap.pin};
        const unsigned msk = ((1u << ap.nblk) - 1u) | 16u;
        const float* qs[1] = {L.aq + (L.glob ? ctrl : 0) * H};
        float qv[1][EPT];
        load_queries<1>(qs, 1, qv);
        load_srcs<5>(c, hd, idx, msk, b, v);
        depth_mix_q<5, 1>(v, msk, qv, 1, x, sm);
      } else {
        mlp_mix(c, hd, sm, a, b, x);
      }
#if MSGZ
      (void)ms; (void)mqv;
#else
      load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
      depth_mix_q<2, 1>(ms, 3u, mqv, 1, m, sm);
#endif
    }
    SUBMARK(40 + (c0 == 3 ? 10 : 0));
#if MSGZ
    float s2[1] = {0.f};
#pragma unroll
    for (int k = 0; k < EPT; k++) s2[0] += x[0][k] * x[0][k];
    block_sum<1>(s2, sm);
    const float rx = rsqrtf(s2[0] / (float)H + 1e-6f);
#else
    float s2[2] = {0.f, 0.f};
#pragma unroll
    for (int k = 0; k < EPT; k++) { s2[0] += x[0][k] * x[0][k]; s2[1] += m[0][k] * m[0][k]; }
    block_sum<2>(s2, sm);
    const float rx = rsqrtf(s2[0] / (float)H + 1e-6f), rm = rsqrtf(s2[1] / (float)H + 1e-6f);
#endif
    const long o = ((long)(par * MAXB + b) * 4 + ctrl) * H;
#pragma unroll
    for (int jj = 0; jj < 2; jj++) {
      if (!EV(2 * jj)) continue;
      const int el = EL(2 * jj);
      *reinterpret_cast<uint32_t*>(&xb[el]) = pack_bf2(x[0][2 * jj] * rx, x[0][2 * jj + 1] * rx);
#if !MSGZ
      *reinterpret_cast<uint32_t*>(&xb[H + el]) = pack_bf2(m[0][2 * jj] * rm, m[0][2 * jj + 1] * rm);
#endif
      if (j == 0 && ks == 0) {
        st_tagf(c.xgt + o + el, x[0][2 * jj], TAGA(a)); st_tagf(c.xgt + o + el + 1, x[0][2 * jj + 1], TAGA(a));
#if !MSGZ
        st_tagf(c.mgt + o + el, m[0][2 * jj], TAGA(a)); st_tagf(c.mgt + o + el + 1, m[0][2 * jj + 1], TAGA(a));
#endif
      }
    }
    __syncthreads();
    SUBMARK(41 + (c0 == 3 ? 10 : 0));
    BSm bl{xb, ST, 1};
#if GDPF
    mbar_wait(smaddr(&sm.gdbar), gph);
#endif
#if MSGZ
    // track B: the message half D_m unit(m) of the pass was computed once at the pass start (ph_msgz)
    const unsigned tz = TAGA(a - ap.loopl);
    const uint2* zp = c.mzt + (((long)ap.loopl * 4 + ctrl) * MAXB + b) * 64 + j * 16;
    constexpr int UD = 36;
#else
    constexpr int UD = 72;
#endif
    const int ub = UD * ks / KS, un = UD * (ks + 1) / KS - ub;   // this job's units
    block_strips<NWARP, 1>(sm, 1, un,
#if GDPF
      [&](int, int u0, int nu, float (*acc)[4]) { piece_bf16_sm(wsm, L.cD + (long)strip * 72 * 2048, ub + u0, nu, bl, acc[0]); },
#else
      [&](int, int u0, int nu, float (*acc)[4]) { piece_bf16(L.cD + (long)strip * 72 * 2048, ub + u0, nu, bl, acc[0]); SUBMARK(43 + (c0 == 3 ? 10 : 0)); },
#endif
      [&](int, float (*acc)[4]) {
        SUBMARK(44 + (c0 == 3 ? 10 : 0));
        const int lane = lane_id(), g = lane >> 2, t = lane & 3;
        if (t == 0) {   // column 0 = this token
#if MSGZ
          const float z0 = acc[0][0] + (ks == 0 ? pollf(zp + g, tz) : 0.f), z1 = acc[0][2] + (ks == 0 ? pollf(zp + g + 8, tz) : 0.f);
#else
          const float z0 = acc[0][0], z1 = acc[0][2];
#endif
          if (KS == 1) {
            st_tagf(c.gvt + ((long)(par * MAXB + b) * 4 + ctrl) * 64 + j * 16 + g, rbf(z0), TAGA(a));
            st_tagf(c.gvt + ((long)(par * MAXB + b) * 4 + ctrl) * 64 + j * 16 + g + 8, rbf(z1), TAGA(a));
          } else {   // partial ks of the row: gvp[par][b][ctrl][ks][64]
            uint2* gp = c.gvp + (((long)(par * MAXB + b) * 4 + ctrl) * DKS + ks) * 64 + j * 16;
            st_tagf(gp + g, z0, TAGA(a)); st_tagf(gp + g + 8, z1, TAGA(a));
          }
        }
      });
    __syncthreads();
    SUBMARK(42 + (c0 == 3 ? 10 : 0));
#if GDPF
    if (threadIdx.x == 0) sm.gdph ^= 1u;   // read again only after the next job's __syncthreads
#endif
  }
}
#if MSGZ
// track B: at the first gated application a0 of loop passes 2 and 3, the messages of all 12 loop layers x 4 controllers
// (attention over depth of the previous pass, fixed for the whole pass) and the message half of every gate's down
// projection, z_m = D[:, H:] unit(m), are computed once; the gates add z_m to D[:, :H] unit(x) (exact in exact arithmetic)
__device__ NI_MSGZ void ph_msgz(PH_ARGS, int a, int l0, int l1) {
  // layers [l0, l1) of the pass whose first gated application is a.
  // part 1, items (layer, controller, token): message m (attention over depth of the previous pass), published as f32
  // (mg2t, for the gate's gain term) and as bf16 unit(m) pairs (mu2t);
  // part 2, items (layer, controller, strip of 16 rows), on the highest blocks: z_m = D[:, H:] unit(m) for all tokens
  // at once (tokens = MMA columns), published in mzt
  const App& ap = c.A[a];
  const int B = HDB;
#if MSGZ4
  // MSGZ4: one item per (layer, token): the 4 controllers' messages from one load of the 2 sources (4 queries)
  for (int it = blockIdx.x; it < (l1 - l0) * B; it += gridDim.x) {
    const int b = it % B, l = l0 + it / B;
    float m[4][EPT], ms[2][EPT];
    {
      const float* mq[4] = {c.loopq + ((long)l * 4) * H, c.loopq + ((long)l * 4 + 1) * H, c.loopq + ((long)l * 4 + 2) * H, c.loopq + ((long)l * 4 + 3) * H};
      float mqv[4][EPT];
#pragma unroll
      for (int q = 0; q < 4; q++)
#pragma unroll
        for (int j = 0; j < 2; j++) {
          const float2 f = __ldg(reinterpret_cast<const float2*>(mq[q]) + (EV(2 * j) ? threadIdx.x + j * NTH : threadIdx.x));
          mqv[q][2 * j] = f.x; mqv[q][2 * j + 1] = f.y;
        }
      load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
      depth_mix_q<2, 4>(ms, 3u, mqv, 4, m, sm);
    }
    float s2[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
    for (int q = 0; q < 4; q++)
#pragma unroll
      for (int k = 0; k < EPT; k++) s2[q] += m[q][k] * m[q][k];
    block_sum<4>(s2, sm);
#pragma unroll
    for (int q = 0; q < 4; q++) {
      const float rm = rsqrtf(s2[q] / (float)H + 1e-6f);
      const long o = (((long)l * 4 + q) * MAXB + b) * H;
#pragma unroll
      for (int jj = 0; jj < 2; jj++) {
        if (!EV(2 * jj)) continue;
        const int el = EL(2 * jj);
        st_tagf(c.mg2t + o + el, m[q][2 * jj], TAGA(a)); st_tagf(c.mg2t + o + el + 1, m[q][2 * jj + 1], TAGA(a));
        st_tag(c.mu2t + o / 2 + el / 2, pack_bf2(m[q][2 * jj] * rm, m[q][2 * jj + 1] * rm), TAGA(a));
      }
    }
  }
#else
  const int N1 = (l1 - l0) * 4 * B;
  for (int it = blockIdx.x; it < N1; it += gridDim.x) {
    const int b = it % B, lc = it / B, ctrl = lc % 4, l = l0 + lc / 4;
    float m[1][EPT], ms[2][EPT];
    {
      const float* mq[1] = {c.loopq + ((long)l * 4 + ctrl) * H};
      float mqv[1][EPT];
      load_queries<1>(mq, 1, mqv);
      load_srcs<2>(c, hd, ap.msg, 3u, b, ms);
      depth_mix_q<2, 1>(ms, 3u, mqv, 1, m, sm);
    }
    float s2[1] = {0.f};
#pragma unroll
    for (int k = 0; k < EPT; k++) s2[0] += m[0][k] * m[0][k];
    block_sum<1>(s2, sm);
    const float rm = rsqrtf(s2[0] / (float)H + 1e-6f);
    const long o = (((long)l * 4 + ctrl) * MAXB + b) * H;
#pragma unroll
    for (int jj = 0; jj < 2; jj++) {
      if (!EV(2 * jj)) continue;
      const int el = EL(2 * jj);
      st_tagf(c.mg2t + o + el, m[0][2 * jj], TAGA(a)); st_tagf(c.mg2t + o + el + 1, m[0][2 * jj + 1], TAGA(a));
      st_tag(c.mu2t + o / 2 + el / 2, pack_bf2(m[0][2 * jj] * rm, m[0][2 * jj + 1] * rm), TAGA(a));
    }
  }
#endif
  const int N2 = (l1 - l0) * 16;
  for (int it = (int)gridDim.x - 1 - (int)blockIdx.x; it < N2; it += gridDim.x) {
    const int j = it % 4, lc = it / 4, ctrl = lc % 4, l = l0 + lc / 4;
    __syncthreads();
    poll_rows(c.mu2t + (((long)l * 4 + ctrl) * MAXB) * NPAIR, B, [&](int r) { return &sm.u.xs[0][r][0]; }, TAGA(a));
    __syncthreads();
    BSm bl{&sm.u.xs[0][0][0], HP, B};
    const LayerW& Ll = c.L[6 + l];
    const int strip = ctrl * 4 + j;
    block_strips<NWARP, 1>(sm, 1, 36,
      [&](int, int u0, int nu, float (*acc)[4]) { piece_bf16(Ll.cD + ((long)strip * 72 + 36) * 2048, u0, nu, bl, acc[0]); },
      [&](int, float (*acc)[4]) {
        const int lane = lane_id(), g = lane >> 2, t = lane & 3;
#pragma unroll
        for (int cc = 0; cc < 2; cc++) {
          const int b = 2 * t + cc;
          if (b >= B) continue;
          uint2* zp = c.mzt + (((long)l * 4 + ctrl) * MAXB + b) * 64 + j * 16;
          st_tagf(zp + g, acc[0][cc], TAGA(a)); st_tagf(zp + g + 8, acc[0][2 + cc], TAGA(a));
        }
      });
    __syncthreads();
  }
}
#endif
// F / G elementwise for controllers [c0, c0 + nc): xpt[b][ctrl][i]; one thread per (ctrl, b, i)
#ifndef FGPLACE
#define FGPLACE 1
#endif
// FGR: rounds of F/G tasks allowed on the blocks without a D job before falling back to all blocks
#ifndef FGR
#define FGR 1
#endif
__device__ NI_GATEFG void ph_gate_fg(PH_ARGS, int a, int c0, int nc) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = HDB, par = a & 1;
  const int N = nc * B * H;
  // track A (from s15-mini-b200-a2 s0007): tasks only on the blocks without a D job (those start late, after their own
  // job), unless every block has one
  const int nd = nc * 4 * B * gate_ks(B, nc) + ((GLIN && !MSGZ && (c0 == 0 || GLIN >= 2)) ? nc * B : 0);
  const int f0 = (FGPLACE && nd < (int)gridDim.x && ((int)gridDim.x - nd) * (NTH / 2) * FGR >= N) ? nd : 0, nf = (int)gridDim.x - f0;
  if ((int)blockIdx.x < f0) return;
  const int fb = blockIdx.x - f0;
  bool any = false;
  for (int it = threadIdx.x * nf + fb; it < N; it += nf * NTH) any = true;
  if (!__syncthreads_or(any)) return;
  float* gs = reinterpret_cast<float*>(&sm.u.xs[0][0][0]);   // [B][4][64]
  // two lanes per (ctrl, b, i): even lane the forget row, odd lane the gain row
  const int tsk0 = (threadIdx.x >> 1) * nf + fb, odd = threadIdx.x & 1;
  for (int it0 = 0; it0 < N; it0 += nf * (NTH / 2)) {
    const int it = it0 + tsk0;
    const bool ok = it < N;
    const int itc = ok ? it : 0;
    const int i = itc % H, rest = itc / H, b = rest % B, ctrl = c0 + rest / B;
    // independent loads first: the weight row and x (or m), then the gate vector g
    const uint4* R = reinterpret_cast<const uint4*>(L.cFG + ((long)ctrl * 2 * H + odd * H + i) * 64);
    uint4 fw[8];
#pragma unroll
    for (int q = 0; q < 8; q++) fw[q] = ldg_nc(R + q);
    const long o = ((long)(par * MAXB + b) * 4 + ctrl) * H + i;
#if MSGZ
    const App& apg = c.A[a];
    const uint2* mp = c.mg2t + (((long)apg.loopl * 4 + ctrl) * MAXB + b) * H + i;
    const unsigned tmv = TAGA(a - apg.loopl);
#else
    const uint2* mp = c.mgt + o;
    const unsigned tmv = TAGA(a);
#endif
    const uint2 rx = ld_tag(odd ? mp : c.xgt + o);
    if (it0 == 0) {
      for (int k = threadIdx.x; k < B * nc * 64; k += NTH) {
        const int r = k % 64, bc = k / 64, bb = bc / nc, cc = c0 + bc % nc;
        if (gate_ks(B, nc) == 1) gs[(bb * 4 + cc) * 64 + r] = pollf(c.gvt + ((long)(par * MAXB + bb) * 4 + cc) * 64 + r, TAGA(a));
        else {
          const uint2* gp = c.gvp + ((long)(par * MAXB + bb) * 4 + cc) * DKS * 64 + r;
          float z = 0.f;
#pragma unroll
          for (int k = 0; k < DKS; k++) z += pollf(gp + k * 64, TAGA(a));
          gs[(bb * 4 + cc) * 64 + r] = rbf(z);
        }
      }
      __syncthreads();
    }
    const float* gvv = gs + (b * 4 + ctrl) * 64;
    float f = 0.f;
#pragma unroll
    for (int q = 0; q < 8; q++) {
      const bf16* fp = reinterpret_cast<const bf16*>(&fw[q]);
#pragma unroll
      for (int r = 0; r < 8; r++) f = fmaf(bf(fp[r]), gvv[q * 8 + r], f);
    }
    f = tanhf(f);
    const float val = ok ? __uint_as_float(wait_tag(odd ? mp : c.xgt + o, rx, odd ? tmv : TAGA(a))) : 0.f;
    const float mine = odd ? f * val : (1.f - f) * val;   // gain * m  |  (1 - forget) * x
    const float other = __shfl_xor_sync(0xffffffff, mine, 1);
    if (ok && !odd) st_tagf(c.xpt + o, mine + other, TAGA(a));
  }
}

// QKV GEMV + epilogue: qkvt[par][b][row] (bf16-rounded f32). Block b: strips b, b + G, b + 2G, b + 3G; 6 warps per strip.
// track B (L0T): application 0's attention input and qkv rows without the GEMV: block 0 (B = 1) or block b (B >= 2)
// publishes h0 = rmsnorm(embed[tok]) * embed_norm (pbt[0]); every block copies its share of the rows the qkv GEMV would
// write from the token table (built by mk_l0b with the same arithmetic: bit for bit). Out of line (register pressure).
#ifndef L0T_INL
#define L0T_INL 0
#endif
#if L0T_INL
__device__ __forceinline__ void l0t_app0(const Ctx& c, const Hdr& hd, Smem& sm) {
#else
__device__ __noinline__ void l0t_app0(const Ctx& c, const Hdr& hd, Smem& sm) {
#endif
  const int B = HDB, G = gridDim.x;
  for (int b = blockIdx.x; b < B; b += G) {
    const int tok = hd.tokens ? hd.tokens[b] : (int)poll(c.ntt + b, hd.tok_tag);
    const bf16* er = c.embed + (long)tok * H;
    float e[EPT], s[1] = {0.f};
#pragma unroll
    for (int j = 0; j < 2; j++) {
      __nv_bfloat162 w2 = EV(2 * j) ? *reinterpret_cast<const __nv_bfloat162*>(er + EL(2 * j)) : __floats2bfloat162_rn(0.f, 0.f);
      e[2 * j] = bf(w2.x); e[2 * j + 1] = bf(w2.y);
    }
#pragma unroll
    for (int k = 0; k < EPT; k++) s[0] += e[k] * e[k];
    block_sum<1>(s, sm);
    const float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
    for (int j = 0; j < 2; j++) {
      if (!EV(2 * j)) continue;
      const int el = EL(2 * j);
      const __nv_bfloat162 nw = *reinterpret_cast<const __nv_bfloat162*>(c.embed_norm + el);
      st_tag(c.pbt + (long)b * NPAIR + threadIdx.x + j * NTH, pack_bf2(e[2 * j] * r * bf(nw.x), e[2 * j + 1] * r * bf(nw.y)), TAGP(0));
    }
  }
  const int nsk = c.L[c.A[0].layer].nsk, npair = QKVR / 2;
  for (int i = blockIdx.x * NTH + threadIdx.x; i < B * npair; i += G * NTH) {
    const int tok = i / npair, row = 2 * (i - tok * npair);
    if ((row >= K0 + 16 * nsk && row < V0) || row >= V0 + 16 * nsk) continue;
    const int id = hd.tokens ? hd.tokens[tok] : (int)poll(c.ntt + tok, hd.tok_tag);
    const __nv_bfloat162 v = *reinterpret_cast<const __nv_bfloat162*>(c.l0t + (long)id * QKVR + row);
    uint2* o = c.qkvt + (long)tok * QKVR + row;   // parity 0
    st_tagf(o, bf(v.x), TAGA(0)); st_tagf(o + 1, bf(v.y), TAGA(0));
  }
}
template <bool BUILD = false>
__device__ NI_QKV void ph_qkv(PH_ARGS, int a, int nstreams) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = HDB, par = a & 1;
  const int nsk = L.nsk;
  const int strips = QG_STRIPS + 2 * nsk;
  const bool lin = QLIN && (nstreams & 8);      // QLIN: the columns are the mix sources; the last block has no strips
  nstreams &= 7;
  const int G = lin ? (int)gridDim.x - 1 : (int)gridDim.x;
  const int ns = (int)blockIdx.x < G ? (strips - (int)blockIdx.x + G - 1) / G : 0;
  block_strips<6, 1>(sm, ns, 36,
    [&](int q, int u0, int nu, float (*acc)[4]) {
      const int strip = blockIdx.x + q * G;
      int st = strip < QG_STRIPS ? 0 : (strip < QG_STRIPS + nsk ? 1 : 2);
      if (st >= nstreams) st = 0;
      BSm bl{&sm.u.xs[st][0][0], HP, lin ? 5 : B};
#if W12Q
      piece_w12r(L.wqkv + (long)strip * W12_STRIP, L.q12base + (long)strip * 16, u0, nu, bl, acc[0]);
#else
      piece_bf16(L.wqkv + (long)strip * 36 * 2048, u0, nu, bl, acc[0]);
#endif
    },
    [&](int q, float (*acc)[4]) {
      const int strip = blockIdx.x + q * G;
      const int st = strip < QG_STRIPS ? 0 : (strip < QG_STRIPS + nsk ? 1 : 2);
      const int orow = st == 0 ? strip * 16 : (st == 1 ? K0 + (strip - QG_STRIPS) * 16 : V0 + (strip - QG_STRIPS - nsk) * 16);
      const int lane = lane_id(), g = lane >> 2, t = lane & 3;
#if QLIN
      if (lin) {   // out[row] = sum_s (cf[s] r) Z[row][s]: this lane holds columns 2t, 2t + 1 of rows g, g + 8
        const uint2* cfp = c.gzt + ((long)par * MAXB * 4 + (st < nstreams ? st : 0)) * 64 * 8;
        const float c0 = 2 * t < 5 ? pollf(cfp + min(2 * t, 4), TAGA(a)) : 0.f;
        const float c1 = 2 * t + 1 < 5 ? pollf(cfp + min(2 * t + 1, 4), TAGA(a)) : 0.f;
#pragma unroll
        for (int h = 0; h < 2; h++) {
          float val = c0 * acc[0][2 * h] + c1 * acc[0][2 * h + 1];
          val += __shfl_xor_sync(0xffffffffu, val, 1);
          val += __shfl_xor_sync(0xffffffffu, val, 2);
          if (t == 0) st_tagf(c.qkvt + (long)(par * MAXB) * QKVR + orow + g + 8 * h, rbf(val), TAGA(a));
        }
        return;
      }
#endif
      for (int h = 0; h < 2; h++)
        for (int cc = 0; cc < 2; cc++) {
          const int tok = 2 * t + cc;
          if (tok < B) st_tagf(c.qkvt + (long)(par * MAXB + tok) * QKVR + orow + g + 8 * h, rbf(acc[0][2 * h + cc]), TAGA(a));
          if (BUILD && tok < B) c.l0t[(long)hd.tokens[tok] * QKVR + orow + g + 8 * h] = __float2bfloat16(rbf(acc[0][2 * h + cc]));
        }
    });
}

// attention: items (b, kv head g, chunk of csz positions); the last chunk of (b, g) to finish merges
__device__ __forceinline__ void cp_async16(void* smem, const void* gmem) {
  const unsigned sa = (unsigned)__cvta_generic_to_shared(smem);
  asm volatile("cp.async.cg.shared.global [%0], [%1], 16;" :: "r"(sa), "l"(gmem) : "memory");
}
__device__ __forceinline__ void cp_async_wait() { asm volatile("cp.async.wait_all;" ::: "memory"); }

__device__ __forceinline__ float kv_conv(const LayerW& L, const uint2* qr, unsigned tag, const bf16* hist, const bf16* sc, int base_row, int ch2, int g, int t) {
  // raw current value, history ring, conv (static for local layers, dynamic taps for global)
  uint2 rd[5];
  rd[0] = ld_tag(qr + base_row + ch2);
#pragma unroll
  for (int lag = 0; lag < 4; lag++) rd[1 + lag] = ld_tag(qr + base_row + 1024 + (L.glob ? g * 4 + lag : 0));
  const float x = __uint_as_float(wait_tag(qr + base_row + ch2, rd[0], tag));
  const bf16* hb = hist + ch2;
  const float x1 = ldcg_bf(hb + ((t + 2) % 3) * 1024), x2 = ldcg_bf(hb + ((t + 1) % 3) * 1024), x3 = ldcg_bf(hb + (t % 3) * 1024);
  if (!L.glob) {
    const uint2 wv = *reinterpret_cast<const uint2*>(sc + ch2 * 4);
    const bf16* w4 = reinterpret_cast<const bf16*>(&wv);
    float acc = __fmul_rn(x3, bf(w4[0]));
    acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
    acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
    acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
    return rbf(__fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f));
  }
  const uint2* dyn = qr + base_row + 1024 + g * 4;
  const float xs4[4] = {x, x1, x2, x3};
  float acc = 0.f;
#pragma unroll
  for (int lag = 0; lag < 4; lag++) acc = __fadd_rn(acc, __fmul_rn(xs4[lag], __fadd_rn(bf(sc[lag * 1024 + ch2]), __uint_as_float(wait_tag(dyn + lag, rd[1 + lag], tag)))));
  return rbf(__fmul_rn(__fadd_rn(acc, x), 0.33333333333333333f));
}

#ifndef KVC4
#define KVC4 1
#endif
// (port of s15-mini-b200-a2 s0022, exact)
// raw current values, history ring, conv (static for local layers, dynamic taps for global) of 4 consecutive channels
// ch0 .. ch0 + 3; every independent load is issued before the first wait (per channel the same arithmetic as before)
__device__ __forceinline__ void kv_conv4(const LayerW& L, const uint2* qr, unsigned tag, const bf16* hist, const bf16* sc, int base_row, int ch0, int g, int t, float* out) {
  uint2 rd[4], rt[4];
#pragma unroll
  for (int k = 0; k < 4; k++) rd[k] = ld_tag(qr + base_row + ch0 + k);
#pragma unroll
  for (int lag = 0; lag < 4; lag++) rt[lag] = ld_tag(qr + base_row + 1024 + (L.glob ? g * 4 + lag : 0));
  // history rows (t + 2) % 3 = x1 (newest), (t + 1) % 3 = x2, t % 3 = x3, 4 channels each (8-byte loads)
  const uint2 h1 = __ldcg(reinterpret_cast<const uint2*>(hist + ((t + 2) % 3) * 1024 + ch0));
  const uint2 h2 = __ldcg(reinterpret_cast<const uint2*>(hist + ((t + 1) % 3) * 1024 + ch0));
  const uint2 h3 = __ldcg(reinterpret_cast<const uint2*>(hist + (t % 3) * 1024 + ch0));
  uint2 wsc[4];
  if (!L.glob) {
#pragma unroll
    for (int k = 0; k < 4; k++) wsc[k] = *reinterpret_cast<const uint2*>(sc + (ch0 + k) * 4);   // taps of channel k
  } else {
#pragma unroll
    for (int lag = 0; lag < 4; lag++) wsc[lag] = *reinterpret_cast<const uint2*>(sc + lag * 1024 + ch0);   // lag-major taps
  }
  const bf16* p1 = reinterpret_cast<const bf16*>(&h1);
  const bf16* p2 = reinterpret_cast<const bf16*>(&h2);
  const bf16* p3 = reinterpret_cast<const bf16*>(&h3);
  float dyn[4] = {0.f, 0.f, 0.f, 0.f};
  if (L.glob) {
#pragma unroll
    for (int lag = 0; lag < 4; lag++) dyn[lag] = __uint_as_float(wait_tag(qr + base_row + 1024 + g * 4 + lag, rt[lag], tag));
  }
#pragma unroll
  for (int k = 0; k < 4; k++) {
    const float x = __uint_as_float(wait_tag(qr + base_row + ch0 + k, rd[k], tag));
    const float x1 = bf(p1[k]), x2 = bf(p2[k]), x3 = bf(p3[k]);
    if (!L.glob) {
      const bf16* w4 = reinterpret_cast<const bf16*>(&wsc[k]);
      float acc = __fmul_rn(x3, bf(w4[0]));
      acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
      acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
      acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
      out[k] = rbf(__fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f));
    } else {
      const float xs4[4] = {x, x1, x2, x3};
      float acc = 0.f;
#pragma unroll
      for (int lag = 0; lag < 4; lag++) acc = __fadd_rn(acc, __fmul_rn(xs4[lag], __fadd_rn(bf(reinterpret_cast<const bf16*>(&wsc[lag])[k]), dyn[lag])));
      out[k] = rbf(__fmul_rn(__fadd_rn(acc, x), 0.33333333333333333f));
    }
  }
}
__device__ __forceinline__ void ldsm_x4(uint32_t* r, const void* p) {
  const unsigned a = (unsigned)__cvta_generic_to_shared(p);
  asm volatile("ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0,%1,%2,%3}, [%4];" : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]) : "r"(a));
}
__device__ __forceinline__ void ldsm_x4_t(uint32_t* r, const void* p) {
  const unsigned a = (unsigned)__cvta_generic_to_shared(p);
  asm volatile("ldmatrix.sync.aligned.m8n8.x4.trans.shared.b16 {%0,%1,%2,%3}, [%4];" : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]) : "r"(a));
}
#ifndef ATL2
#define ATL2 0
#endif
// track A: the K / V rows of this block's attention items (known before the token's q / k / v) into L2, issued
// before the block's qkv work (the attention item's own loads then hit L2); same item order as ph_attn
__device__ __noinline__ void attn_pf(const Ctx& c, const Hdr& hd, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, t = hd.pos;
  const int csz = B <= 2 ? 64 : ACS;
  const int lo = L.glob ? 0 : max(0, t + 1 - 1024);
  const int nch = (t - lo + csz) / csz;
  const int N = B * NKV * nch;
  const long cstride = (long)c.maxctx * HD;
  const int it = blockIdx.x + (threadIdx.x >> 1) * gridDim.x;
  if ((threadIdx.x & 1) || threadIdx.x >= 4 || it >= N) return;   // threads 0, 2: the block's first two items
  const int ch = nch - 1 - it / (B * NKV), bg = it % (B * NKV), g = bg % NKV, b = bg / NKV;
  const int j0 = lo + ch * csz, j1 = min(j0 + csz, t);   // rows before the current position
  if (j1 <= j0) return;
  const long o = (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)j0 * HD;
  pf_l2(c.kc + o, (long)(j1 - j0) * HD * 2);
  pf_l2(c.vc + o, (long)(j1 - j0) * HD * 2);
}
__device__ NI_ATTN void ph_attn(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, t = hd.pos;
  const int csz = B <= 2 ? 64 : ACS;
  const int lo = L.glob ? 0 : max(0, t + 1 - 1024);
  const int nch = (t - lo + csz) / csz;
  const int N = B * NKV * nch;
  const unsigned tag = TAGA(a);
  const int par = a & 1;
  const float tau = L.glob ? (1.0f + 0.1f * logf(fmaxf(1.0f, (float)(t + 1) / 8192.0f))) : 1.0f;
  const bool use_tau = L.glob;
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31, g8 = lane >> 2, t4 = lane & 3;
  const long cstride = (long)c.maxctx * HD;   // per (slot, b, head)
#if ATP
  // ATP: the K / V rows of the block's next item are copied (cp.async) into the other of two buffers while the
  // current item is computed; an item then starts with its keys and values already in shared memory
  auto issue_kv = [&](int it2, int buf) {
    if (it2 >= N) return;
    const int ch2 = nch - 1 - it2 / (B * NKV), bg2 = it2 % (B * NKV), g2 = bg2 % NKV, b2 = bg2 / NKV;
    const int j02 = lo + ch2 * csz, j12 = min(j02 + csz, t + 1), nj2 = j12 - j02;
    const bf16* kb = c.kc + (((long)ap.slot * MAXB + b2) * NKV + g2) * cstride + (long)j02 * HD;
    const bf16* vb = c.vc + (((long)ap.slot * MAXB + b2) * NKV + g2) * cstride + (long)j02 * HD;
    const int nld = ((j12 == t + 1) ? nj2 - 1 : nj2) * 16;
    for (int i = tid; i < nld; i += NTH) {
      const int r = i >> 4, cc = (i & 15) * 8;
      cp_async16(&sm.u.at2[buf].kk[r][cc], reinterpret_cast<const uint4*>(kb) + i);
      cp_async16(&sm.u.at2[buf].vv[r][cc], reinterpret_cast<const uint4*>(vb) + i);
    }
  };
  issue_kv(blockIdx.x, 0);
  int kidx = 0;
#else
  auto& at = sm.u.at;
#endif
  // items: chunk-major from the last chunk down; chunk 0 of (b, g) merges and comes last in every block's order
  for (int it = blockIdx.x; it < N; it += gridDim.x) {
#if ATP
    auto& at = sm.u.at2[kidx & 1];
#endif
    const int ch = nch - 1 - it / (B * NKV), bg = it % (B * NKV), g = bg % NKV, b = bg / NKV;
    const int j0 = lo + ch * csz, j1 = min(j0 + csz, t + 1), nj = j1 - j0;
    const bool cur = (j1 == t + 1);
    const uint2* qr = c.qkvt + (long)(par * MAXB + b) * QKVR;
#if ATL2 == 3
    // track A: a block runs its attention items one after another; the K / V rows of its next item go into L2 while
    // it works on this one (two prefetches of <= 32 KB in a phase that reads little)
    if (tid < 2) {
      const int it2 = it + (int)gridDim.x;
      if (it2 < N) {
        const int ch2 = nch - 1 - it2 / (B * NKV), bg2 = it2 % (B * NKV), g2 = bg2 % NKV, b2 = bg2 / NKV;
        const int j02 = lo + ch2 * csz, j12 = min(j02 + csz, t);
        if (j12 > j02) {
          const long o2 = (((long)ap.slot * MAXB + b2) * NKV + g2) * cstride + (long)j02 * HD;
          pf_l2((tid ? c.vc : c.kc) + o2, (long)(j12 - j02) * HD * 2);
        }
      }
    }
#endif
    SUBMARK(20);
    // ---- one wave of loads: K / V chunk (async), relative-bias rows, q / r, current k / v
#if !ATP
    {
      const bf16* kb = c.kc + (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)j0 * HD;
      const bf16* vb = c.vc + (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)j0 * HD;
      const int nld = (cur ? nj - 1 : nj) * 16;
      for (int i = tid; i < nld; i += NTH) {
        const int r = i >> 4, cc = (i & 15) * 8;
        cp_async16(&at.kk[r][cc], reinterpret_cast<const uint4*>(kb) + i);
        cp_async16(&at.vv[r][cc], reinterpret_cast<const uint4*>(vb) + i);
      }
    }
#endif
    for (int i = tid; i < 16 * nj; i += NTH) {
      const int r = i / nj, jj = i % nj, dist = t - (j0 + jj);
      at.pr[r][jj] = dist < 1024 ? bf(L.relp[r * 1024 + min(dist, 1023)]) : 0.f;   // index clamped: the select may load
    }
    // zero: P rows 3..15, q rows 3..7, V rows beyond nj up to the next 16
    for (int i = tid; i < 13 * (CH + 8) / 2; i += NTH) {
      reinterpret_cast<uint32_t*>(&at.ph[3][0])[i] = 0u;
      reinterpret_cast<uint32_t*>(&at.pl[3][0])[i] = 0u;
    }
    for (int i = tid; i < 5 * (HD + 8) / 2; i += NTH) reinterpret_cast<uint32_t*>(&at.qb[3][0])[i] = 0u;
    {
      const int nj16 = (nj + 15) & ~15;
      for (int i = tid; i < (nj16 - nj) * (HD / 2); i += NTH) reinterpret_cast<uint32_t*>(&at.vv[nj + i / (HD / 2)][0])[i % (HD / 2)] = 0u;
    }
    if (w < 3) {
      const int h = 3 * g + w;
      float qv[4], ss = 0.f;
      uint2 rq[4];
#pragma unroll
      for (int k = 0; k < 4; k++) rq[k] = ld_tag(qr + h * HD + lane * 4 + k);
#if (BPX >> 4) & 1
      wait_all<4>([&](int i) { return qr + h * HD + lane * 4 + i; }, rq, tag);
#endif
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int d = lane * 4 + k;
        qv[k] = __uint_as_float(wait_tag(qr + h * HD + d, rq[k], tag)) * bf(L.qscale[h * HD + d]);
        ss += qv[k] * qv[k];
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
#pragma unroll
      for (int k = 0; k < 4; k++) {
        float y = rbf(qv[k] * f);
        if (use_tau) y = rbf(y * tau);
        at.qb[w][lane * 4 + k] = tobf(y);
      }
    } else if (w < 6) {
      const int hh = w - 3, h = 3 * g + hh;
      float rv = 0.f, ss = 0.f;
      if (lane < 16) { rv = pollf(qr + R_R + h * 16 + lane, tag) * bf(L.rscale[h * 16 + lane]); ss = rv * rv; }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = fminf(8.0f / (sqrtf(ss) + 1e-6f), 1.0f);
      if (lane < 16) {
        float y = rbf(rv * f);
        if (use_tau) y = rbf(y * tau);
        at.rr[hh][lane] = y;
      }
    } else if ((w == 6 || w == 7) && cur) {
      const bool isv = (w == 7);
      const bf16* hist = (isv ? c.hv : c.hk) + ((long)ap.slot * MAXB + b) * 3 * 1024;
      float kv[4], ss = 0.f;
#if KVC4
      kv_conv4(L, qr, tag, hist, isv ? L.vsc : L.ksc, isv ? V0 : K0, g * HD + lane * 4, g, t, kv);
#pragma unroll
      for (int k = 0; k < 4; k++) ss += kv[k] * kv[k];
#else
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int ch2 = g * HD + lane * 4 + k;
        kv[k] = kv_conv(L, qr, tag, hist, isv ? L.vsc : L.ksc, isv ? V0 : K0, ch2, g, t);
        ss += kv[k] * kv[k];
      }
#endif
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = isv ? rsqrtf(ss / 128.f + 1e-6f) : fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
      float* dst = isv ? at.vt : at.kt;
#pragma unroll
      for (int k = 0; k < 4; k++) dst[lane * 4 + k] = rbf(kv[k] * f);
    }
    cp_async_wait();
#if ATP
    issue_kv(it + (int)gridDim.x, (kidx + 1) & 1);   // the next item's keys and values, in flight during this item
    kidx++;
#endif
    __syncthreads();
    SUBMARK(21);
    if (cur && tid < HD) {
      // current position: from the values computed above; write the cache and the conv history
      at.kk[nj - 1][tid] = tobf(at.kt[tid]);
      at.vv[nj - 1][tid] = tobf(at.vt[tid]);
      const long co = (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)t * HD + tid;
      c.kc[co] = tobf(at.kt[tid]);
      c.vc[co] = tobf(at.vt[tid]);
      const long hrow = ((long)ap.slot * MAXB + b) * 3 * 1024 + (t % 3) * 1024 + g * HD + tid;
      c.hk[hrow] = tobf(pollf(qr + K0 + g * HD + tid, tag));
      c.hv[hrow] = tobf(pollf(qr + V0 + g * HD + tid, tag));
    }
    // relative bias: bias[h][jj] = bf16(sum_r rr[h][r] * P[r][t - j]) (0 beyond 1023); kept in sc until the scores
    if (tid < 3 * CH) {
      const int hh = tid / CH, jj = tid % CH;
      if (jj < nj) {
        float bsum = 0.f;
#pragma unroll
        for (int r = 0; r < 16; r++) bsum += at.rr[hh][r] * at.pr[r][jj];
        at.sc[hh][jj] = (t - (j0 + jj) < 1024) ? rbf(bsum) : 0.f;
      }
    }
    __syncthreads();
    SUBMARK(22);
    // scores on the tensor cores: S^T[key][head] = K[key][:] . q[head][:]; one warp per 16 keys
    if (w < (nj + 15) / 16) {
      float acc[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
      for (int ks = 0; ks < HD / 16; ks++) {
        uint32_t af[4];
        ldsm_x4(af, &at.kk[16 * w + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        const uint32_t b0 = *reinterpret_cast<const uint32_t*>(&at.qb[g8][16 * ks + 2 * t4]);
        const uint32_t b1 = *reinterpret_cast<const uint32_t*>(&at.qb[g8][16 * ks + 8 + 2 * t4]);
        mma_bf16(acc, af[0], af[1], af[2], af[3], b0, b1);
      }
#pragma unroll
      for (int q = 0; q < 4; q++) {
        const int key = 16 * w + g8 + (q >> 1) * 8, head = 2 * t4 + (q & 1);
        if (head < 3 && key < nj) at.sc[head][key] = acc[q] * 0.08838834764831845f + at.sc[head][key];
      }
    }
    __syncthreads();
    if (w < 3) {
      float m = -1e30f;
      for (int jj = lane; jj < nj; jj += 32) m = fmaxf(m, at.sc[w][jj]);
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float l = 0.f;
      for (int jj = lane; jj < CH; jj += 32) {
        const float e = jj < nj ? expf(at.sc[w][jj] - m) : 0.f;
        const bf16 eh = tobf(e);
        at.ph[w][jj] = eh;
        at.pl[w][jj] = tobf(e - bf(eh));
        l += e;
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffff, l, o);
      if (lane == 0) { at.ml[w][0] = m; at.ml[w][1] = l; }
    }
    __syncthreads();
    SUBMARK(23);
    // PV on the tensor cores: O[head][d] = sum_j (Phi + Plo)[head][j] V[j][d]; warp w < 8: dims 16w .. 16w + 15
    const bool merger = (ch == 0) && nch > 1;
    if (w < 8) {
      float acc[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
      for (int ks = 0; ks < (nj + 15) / 16; ks++) {
        uint32_t ah[4], al[4], bv[4];
        ldsm_x4(ah, &at.ph[lane & 15][16 * ks + (lane >> 4) * 8]);
        ldsm_x4(al, &at.pl[lane & 15][16 * ks + (lane >> 4) * 8]);
        ldsm_x4_t(bv, &at.vv[16 * ks + (lane & 15)][16 * w + (lane >> 4) * 8]);
        mma_bf16(acc[0], ah[0], ah[1], ah[2], ah[3], bv[0], bv[1]);
        mma_bf16(acc[0], al[0], al[1], al[2], al[3], bv[0], bv[1]);
        mma_bf16(acc[1], ah[0], ah[1], ah[2], ah[3], bv[2], bv[3]);
        mma_bf16(acc[1], al[0], al[1], al[2], al[3], bv[2], bv[3]);
      }
      if (g8 < 3) {
        const int hh = g8;
#pragma unroll
        for (int nt = 0; nt < 2; nt++)
#pragma unroll
          for (int q = 0; q < 2; q++) {
            const int d = 16 * w + 8 * nt + 2 * t4 + q;
            if (merger || nch == 1) at.po[hh][d] = acc[nt][q];
            else st_tagf(c.arec + ((long)(b * NQH + 3 * g + hh) * MAXCH + ch) * 130 + 2 + d, acc[nt][q], tag);
          }
      }
    } else if (w == 8 && lane < 3 && !(merger || nch == 1)) {
      uint2* rec = c.arec + ((long)(b * NQH + 3 * g + lane) * MAXCH + ch) * 130;
      st_tagf(rec, at.ml[lane][0], tag);
      st_tagf(rec + 1, at.ml[lane][1], tag);
    }
    SUBMARK(24);
    if (merger || nch == 1) {
      __syncthreads();
      float gate = 0.f, sink = 0.f;
      if (tid < 3 * HD) {
        const int hh = tid / HD, d = tid % HD, h = 3 * g + hh;
        const uint2 rg = ld_tag(qr + R_G + h * HD + d), rs = ld_tag(qr + R_S + h);
        gate = __uint_as_float(wait_tag(qr + R_G + h * HD + d, rg, tag));
        sink = __uint_as_float(wait_tag(qr + R_S + h, rs, tag));
      }
      float* st = sm.u.mrg;   // [3][nch][130]; chunk 0 from this block
      // (from a2 s0014) the own record first, through registers: the staging of the other records reaches at.po /
      // at.ml (same union) beyond ~58 chunks; the own record's slots never do
      {
      const float pv = tid < 3 * HD ? at.po[tid / HD][tid % HD] : 0.f;
      const float m0 = tid < 3 * HD ? at.ml[tid / HD][0] : 0.f, l0 = tid < 3 * HD ? at.ml[tid / HD][1] : 0.f;
      __syncthreads();
      if (tid < 3 * HD) {
        const int hh = tid / HD, d = tid % HD;
        st[hh * nch * 130 + 2 + d] = pv;
        if (d == 0) { st[hh * nch * 130] = m0; st[hh * nch * 130 + 1] = l0; }
      }
      }
      __syncthreads();
      const int nrec = 3 * (nch - 1) * 130;
      for (int i0 = tid; i0 < nrec; i0 += NTH * 8) {
        uint2 v[8];
#pragma unroll
        for (int q = 0; q < 8; q++) {
          const int i = min(i0 + q * NTH, nrec - 1);
          const int hh = i / ((nch - 1) * 130), rest = i % ((nch - 1) * 130);
          v[q] = ld_tag(c.arec + ((long)(b * NQH + 3 * g + hh) * MAXCH + 1) * 130 + rest);
        }
#pragma unroll
        for (int q = 0; q < 8; q++) {
          const int i = i0 + q * NTH;
          if (i < nrec) {
            const int hh = i / ((nch - 1) * 130), rest = i % ((nch - 1) * 130);
            const uint2* p = c.arec + ((long)(b * NQH + 3 * g + hh) * MAXCH + 1) * 130 + rest;
            while (v[q].y != tag) v[q] = ld_tag(p);
            st[hh * nch * 130 + 130 + rest] = __uint_as_float(v[q].x);
          }
        }
      }
      const int ewt = 3 * nch * 130;
      __syncthreads();
      if (w < 3) {
        const float* r0 = st + w * nch * 130;
        float M = -1e30f;
        for (int k = lane; k < nch; k += 32) M = fmaxf(M, r0[k * 130]);
#pragma unroll
        for (int o = 16; o; o >>= 1) M = fmaxf(M, __shfl_xor_sync(0xffffffff, M, o));
        float S = 0.f;
        for (int k = lane; k < nch; k += 32) {
          const float e = expf(r0[k * 130] - M);
          st[ewt + w * MAXCH + k] = e;
          S += r0[k * 130 + 1] * e;
        }
#pragma unroll
        for (int o = 16; o; o >>= 1) S += __shfl_xor_sync(0xffffffff, S, o);
        if (lane == 0) { sm.bcast[2 * w] = M; sm.bcast[2 * w + 1] = S; }
      }
      __syncthreads();
      if (tid < 3 * HD) {
        const int hh = tid / HD, d = tid % HD;
        const float* r0 = st + hh * nch * 130;
        float O = 0.f;
        for (int k = 0; k < nch; k++) O += r0[k * 130 + 2 + d] * st[ewt + hh * MAXCH + k];
        const float S = sm.bcast[2 * hh + 1];
        const float lse = sm.bcast[2 * hh] + logf(S);
        const float out = (O / S) * sigm(gate) * sigm(lse - sink);
        const float o1 = __shfl_down_sync(0xffffffff, out, 1);
        if ((d & 1) == 0) st_tag(c.aoutt + (long)(par * MAXB + b) * (QW / 2) + ((3 * g + hh) * HD + d) / 2, pack_bf2(out, o1), tag);
      }
      SUBMARK(26);
    }
    __syncthreads();
    SUBMARK(27);
  }
}
#if ATT2
__device__ NI_ATTN void ph_attn2(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, t = hd.pos;
  const int csz = B <= 2 ? 64 : ACS;
  const int lo = L.glob ? 0 : max(0, t + 1 - 1024);
  const int nch = (t - lo + csz) / csz;
  const int N = B * NKV * nch;
  const unsigned tag = TAGA(a);
  const int par = a & 1;
  const float tau = L.glob ? (1.0f + 0.1f * logf(fmaxf(1.0f, (float)(t + 1) / 8192.0f))) : 1.0f;
  const bool use_tau = L.glob;
  const int G = gridDim.x;
  const int NH = N > G ? 2 : 1;                 // items side by side in a block
  const int NTL = NTH / NH;                     // threads of a half
  const int half = threadIdx.x / NTL, tid = threadIdx.x - half * NTL, w = tid >> 5, lane = tid & 31, g8 = lane >> 2, t4 = lane & 3;
  auto& at = sm.u.at2[half];
  float* const st = reinterpret_cast<float*>(&sm.u.at2[half]);   // merge staging: this half's own buffer (nch <= 58)
  const long cstride = (long)c.maxctx * HD;   // per (slot, b, head)
  const int GV = G * NH;                        // virtual blocks: half h of block x is virtual block x + h G
  const int vbm = blockIdx.x + half * G, vbx = blockIdx.x + (NH - 1 - half) * G;
  // items: chunk-major from the last chunk down; chunk 0 of (b, g) merges and comes last in every block's order.
  // Both halves run every iteration (half 0 always has an item); a half without an item only passes the syncs.
  for (int kit = 0; (int)blockIdx.x + kit * GV < N; kit++) {
    const int it = vbm + kit * GV;
    const bool valid = it < N;
    const int itc = valid ? it : 0;
    const int ch = nch - 1 - itc / (B * NKV), bg = itc % (B * NKV), g = bg % NKV, b = bg / NKV;
    const int j0 = lo + ch * csz, j1 = min(j0 + csz, t + 1), nj = j1 - j0;
    const bool cur = valid && (j1 == t + 1);
    const bool mine_m = valid && ch == 0;       // this half merges (chunk 0; also the only chunk)
    const int ito = vbx + kit * GV;
    const bool other_m = NH == 2 && ito < N && (nch - 1 - ito / (B * NKV)) == 0;
    const uint2* qr = c.qkvt + (long)(par * MAXB + b) * QKVR;
    if (valid) {
    SUBMARK(20);
    // ---- one wave of loads: K / V chunk (async), relative-bias rows, q / r, current k / v
    {
      const bf16* kb = c.kc + (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)j0 * HD;
      const bf16* vb = c.vc + (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)j0 * HD;
      const int nld = (cur ? nj - 1 : nj) * 16;
      for (int i = tid; i < nld; i += NTL) {
        const int r = i >> 4, cc = (i & 15) * 8;
        cp_async16(&at.kk[r][cc], reinterpret_cast<const uint4*>(kb) + i);
        cp_async16(&at.vv[r][cc], reinterpret_cast<const uint4*>(vb) + i);
      }
    }
    for (int i = tid; i < 16 * nj; i += NTL) {
      const int r = i / nj, jj = i % nj, dist = t - (j0 + jj);
      at.pr[r][jj] = dist < 1024 ? bf(L.relp[r * 1024 + min(dist, 1023)]) : 0.f;   // index clamped: the select may load
    }
    // zero: P rows 3..15, q rows 3..7, V rows beyond nj up to the next 16
    for (int i = tid; i < 13 * (CH + 8) / 2; i += NTL) {
      reinterpret_cast<uint32_t*>(&at.ph[3][0])[i] = 0u;
      reinterpret_cast<uint32_t*>(&at.pl[3][0])[i] = 0u;
    }
    for (int i = tid; i < 5 * (HD + 8) / 2; i += NTL) reinterpret_cast<uint32_t*>(&at.qb[3][0])[i] = 0u;
    {
      const int nj16 = (nj + 15) & ~15;
      for (int i = tid; i < (nj16 - nj) * (HD / 2); i += NTL) reinterpret_cast<uint32_t*>(&at.vv[nj + i / (HD / 2)][0])[i % (HD / 2)] = 0u;
    }
    if (w < 3) {
      const int h = 3 * g + w;
      float qv[4], ss = 0.f;
      uint2 rq[4];
#pragma unroll
      for (int k = 0; k < 4; k++) rq[k] = ld_tag(qr + h * HD + lane * 4 + k);
#if (BPX >> 4) & 1
      wait_all<4>([&](int i) { return qr + h * HD + lane * 4 + i; }, rq, tag);
#endif
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int d = lane * 4 + k;
        qv[k] = __uint_as_float(wait_tag(qr + h * HD + d, rq[k], tag)) * bf(L.qscale[h * HD + d]);
        ss += qv[k] * qv[k];
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
#pragma unroll
      for (int k = 0; k < 4; k++) {
        float y = rbf(qv[k] * f);
        if (use_tau) y = rbf(y * tau);
        at.qb[w][lane * 4 + k] = tobf(y);
      }
    } else if (w < 6) {
      const int hh = w - 3, h = 3 * g + hh;
      float rv = 0.f, ss = 0.f;
      if (lane < 16) { rv = pollf(qr + R_R + h * 16 + lane, tag) * bf(L.rscale[h * 16 + lane]); ss = rv * rv; }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = fminf(8.0f / (sqrtf(ss) + 1e-6f), 1.0f);
      if (lane < 16) {
        float y = rbf(rv * f);
        if (use_tau) y = rbf(y * tau);
        at.rr[hh][lane] = y;
      }
    } else if ((w == 6 || w == 7) && cur) {
      const bool isv = (w == 7);
      const bf16* hist = (isv ? c.hv : c.hk) + ((long)ap.slot * MAXB + b) * 3 * 1024;
      float kv[4], ss = 0.f;
#if KVC4
      kv_conv4(L, qr, tag, hist, isv ? L.vsc : L.ksc, isv ? V0 : K0, g * HD + lane * 4, g, t, kv);
#pragma unroll
      for (int k = 0; k < 4; k++) ss += kv[k] * kv[k];
#else
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const int ch2 = g * HD + lane * 4 + k;
        kv[k] = kv_conv(L, qr, tag, hist, isv ? L.vsc : L.ksc, isv ? V0 : K0, ch2, g, t);
        ss += kv[k] * kv[k];
      }
#endif
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
      const float f = isv ? rsqrtf(ss / 128.f + 1e-6f) : fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
      float* dst = isv ? at.vt : at.kt;
#pragma unroll
      for (int k = 0; k < 4; k++) dst[lane * 4 + k] = rbf(kv[k] * f);
    }
    }
    cp_async_wait();
    __syncthreads();
    SUBMARK(21);
    if (cur && tid < HD) {
      // current position: from the values computed above; write the cache and the conv history
      at.kk[nj - 1][tid] = tobf(at.kt[tid]);
      at.vv[nj - 1][tid] = tobf(at.vt[tid]);
      const long co = (((long)ap.slot * MAXB + b) * NKV + g) * cstride + (long)t * HD + tid;
      c.kc[co] = tobf(at.kt[tid]);
      c.vc[co] = tobf(at.vt[tid]);
      const long hrow = ((long)ap.slot * MAXB + b) * 3 * 1024 + (t % 3) * 1024 + g * HD + tid;
      c.hk[hrow] = tobf(pollf(qr + K0 + g * HD + tid, tag));
      c.hv[hrow] = tobf(pollf(qr + V0 + g * HD + tid, tag));
    }
    // relative bias: bias[h][jj] = bf16(sum_r rr[h][r] * P[r][t - j]) (0 beyond 1023); kept in sc until the scores
    if (valid && tid < 3 * CH) {
      const int hh = tid / CH, jj = tid % CH;
      if (jj < nj) {
        float bsum = 0.f;
#pragma unroll
        for (int r = 0; r < 16; r++) bsum += at.rr[hh][r] * at.pr[r][jj];
        at.sc[hh][jj] = (t - (j0 + jj) < 1024) ? rbf(bsum) : 0.f;
      }
    }
    __syncthreads();
    SUBMARK(22);
    // scores on the tensor cores: S^T[key][head] = K[key][:] . q[head][:]; one warp per 16 keys
    if (valid && w < (nj + 15) / 16) {
      float acc[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
      for (int ks = 0; ks < HD / 16; ks++) {
        uint32_t af[4];
        ldsm_x4(af, &at.kk[16 * w + (lane & 15)][16 * ks + (lane >> 4) * 8]);
        const uint32_t b0 = *reinterpret_cast<const uint32_t*>(&at.qb[g8][16 * ks + 2 * t4]);
        const uint32_t b1 = *reinterpret_cast<const uint32_t*>(&at.qb[g8][16 * ks + 8 + 2 * t4]);
        mma_bf16(acc, af[0], af[1], af[2], af[3], b0, b1);
      }
#pragma unroll
      for (int q = 0; q < 4; q++) {
        const int key = 16 * w + g8 + (q >> 1) * 8, head = 2 * t4 + (q & 1);
        if (head < 3 && key < nj) at.sc[head][key] = acc[q] * 0.08838834764831845f + at.sc[head][key];
      }
    }
    __syncthreads();
    if (valid && w < 3) {
      float m = -1e30f;
      for (int jj = lane; jj < nj; jj += 32) m = fmaxf(m, at.sc[w][jj]);
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float l = 0.f;
      for (int jj = lane; jj < CH; jj += 32) {
        const float e = jj < nj ? expf(at.sc[w][jj] - m) : 0.f;
        const bf16 eh = tobf(e);
        at.ph[w][jj] = eh;
        at.pl[w][jj] = tobf(e - bf(eh));
        l += e;
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffff, l, o);
      if (lane == 0) { at.ml[w][0] = m; at.ml[w][1] = l; }
    }
    __syncthreads();
    SUBMARK(23);
    // PV on the tensor cores: O[head][d] = sum_j (Phi + Plo)[head][j] V[j][d]; warp w < 8: dims 16w .. 16w + 15
    if (valid && w < 8) {
      float acc[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
      for (int ks = 0; ks < (nj + 15) / 16; ks++) {
        uint32_t ah[4], al[4], bv[4];
        ldsm_x4(ah, &at.ph[lane & 15][16 * ks + (lane >> 4) * 8]);
        ldsm_x4(al, &at.pl[lane & 15][16 * ks + (lane >> 4) * 8]);
        ldsm_x4_t(bv, &at.vv[16 * ks + (lane & 15)][16 * w + (lane >> 4) * 8]);
        mma_bf16(acc[0], ah[0], ah[1], ah[2], ah[3], bv[0], bv[1]);
        mma_bf16(acc[0], al[0], al[1], al[2], al[3], bv[0], bv[1]);
        mma_bf16(acc[1], ah[0], ah[1], ah[2], ah[3], bv[2], bv[3]);
        mma_bf16(acc[1], al[0], al[1], al[2], al[3], bv[2], bv[3]);
      }
      if (g8 < 3) {
        const int hh = g8;
#pragma unroll
        for (int nt = 0; nt < 2; nt++)
#pragma unroll
          for (int q = 0; q < 2; q++) {
            const int d = 16 * w + 8 * nt + 2 * t4 + q;
            if (mine_m) at.po[hh][d] = acc[nt][q];
            else st_tagf(c.arec + ((long)(b * NQH + 3 * g + hh) * MAXCH + ch) * 130 + 2 + d, acc[nt][q], tag);
          }
      }
    } else if (valid && w == 8 && lane < 3 && !mine_m) {
      uint2* rec = c.arec + ((long)(b * NQH + 3 * g + lane) * MAXCH + ch) * 130;
      st_tagf(rec, at.ml[lane][0], tag);
      st_tagf(rec + 1, at.ml[lane][1], tag);
    }
    SUBMARK(24);
    if (mine_m || other_m) {
      __syncthreads();
      float gate = 0.f, sink = 0.f;
      if (mine_m && tid < 3 * HD) {
        const int hh = tid / HD, d = tid % HD, h = 3 * g + hh;
        const uint2 rg = ld_tag(qr + R_G + h * HD + d), rs = ld_tag(qr + R_S + h);
        gate = __uint_as_float(wait_tag(qr + R_G + h * HD + d, rg, tag));
        sink = __uint_as_float(wait_tag(qr + R_S + h, rs, tag));
      }
      // (from a2 s0014) the own record first, through registers: the staging of the other records reaches at.po /
      // at.ml (same union) beyond ~58 chunks; the own record's slots never do
      {
      const float pv = (mine_m && tid < 3 * HD) ? at.po[tid / HD][tid % HD] : 0.f;
      const float m0 = (mine_m && tid < 3 * HD) ? at.ml[tid / HD][0] : 0.f, l0 = (mine_m && tid < 3 * HD) ? at.ml[tid / HD][1] : 0.f;
      __syncthreads();
      if (mine_m && tid < 3 * HD) {
        const int hh = tid / HD, d = tid % HD;
        st[hh * nch * 130 + 2 + d] = pv;
        if (d == 0) { st[hh * nch * 130] = m0; st[hh * nch * 130 + 1] = l0; }
      }
      }
      __syncthreads();
      const int nrec = mine_m ? 3 * (nch - 1) * 130 : 0;
      for (int i0 = tid; i0 < nrec; i0 += NTL * 8) {
        uint2 v[8];
#pragma unroll
        for (int q = 0; q < 8; q++) {
          const int i = min(i0 + q * NTL, nrec - 1);
          const int hh = i / ((nch - 1) * 130), rest = i % ((nch - 1) * 130);
          v[q] = ld_tag(c.arec + ((long)(b * NQH + 3 * g + hh) * MAXCH + 1) * 130 + rest);
        }
#pragma unroll
        for (int q = 0; q < 8; q++) {
          const int i = i0 + q * NTL;
          if (i < nrec) {
            const int hh = i / ((nch - 1) * 130), rest = i % ((nch - 1) * 130);
            const uint2* p = c.arec + ((long)(b * NQH + 3 * g + hh) * MAXCH + 1) * 130 + rest;
            while (v[q].y != tag) v[q] = ld_tag(p);
            st[hh * nch * 130 + 130 + rest] = __uint_as_float(v[q].x);
          }
        }
      }
      const int ewt = 3 * nch * 130;
      __syncthreads();
      if (mine_m && w < 3) {
        const float* r0 = st + w * nch * 130;
        float M = -1e30f;
        for (int k = lane; k < nch; k += 32) M = fmaxf(M, r0[k * 130]);
#pragma unroll
        for (int o = 16; o; o >>= 1) M = fmaxf(M, __shfl_xor_sync(0xffffffff, M, o));
        float S = 0.f;
        for (int k = lane; k < nch; k += 32) {
          const float e = expf(r0[k * 130] - M);
          st[ewt + w * MAXCH + k] = e;
          S += r0[k * 130 + 1] * e;
        }
#pragma unroll
        for (int o = 16; o; o >>= 1) S += __shfl_xor_sync(0xffffffff, S, o);
        if (lane == 0) { sm.bcast[8 * half + 2 * w] = M; sm.bcast[8 * half + 2 * w + 1] = S; }
      }
      __syncthreads();
      if (mine_m && tid < 3 * HD) {
        const int hh = tid / HD, d = tid % HD;
        const float* r0 = st + hh * nch * 130;
        float O = 0.f;
        for (int k = 0; k < nch; k++) O += r0[k * 130 + 2 + d] * st[ewt + hh * MAXCH + k];
        const float S = sm.bcast[8 * half + 2 * hh + 1];
        const float lse = sm.bcast[8 * half + 2 * hh] + logf(S);
        const float out = (O / S) * sigm(gate) * sigm(lse - sink);
        const float o1 = __shfl_down_sync(0xffffffff, out, 1);
        if ((d & 1) == 0) st_tag(c.aoutt + (long)(par * MAXB + b) * (QW / 2) + ((3 * g + hh) * HD + d) / 2, pack_bf2(out, o1), tag);
      }
      SUBMARK(26);
    }
    __syncthreads();
    SUBMARK(27);
  }
}
#endif

// o_proj + epilogue: attn_raw -> sconv -> attst
__device__ NI_OPROJ void ph_oproj(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, t = hd.pos, par = a & 1;
  if (blockIdx.x >= 144) return;
  // this warp's two units of the block's strip, loaded before waiting for the attention output (same order as
  // piece_bf16 over units 2w, 2w + 1, and block_strips' warp-order sum: bit-identical to the generic path)
  const int wq = threadIdx.x >> 5, lq = lane_id();
  uint4 wpre[8];
  {
    const uint8_t* wst = L.wo + (long)blockIdx.x * 48 * 2048;
#pragma unroll
    for (int q = 0; q < 8; q++) wpre[q] = ldg_nc(wst + ((long)(2 * wq + (q >> 2)) * 4 + (q & 3)) * 512 + lq * 16);
  }
  {
    const int n = B * QW / 2;
    const uint2* src = c.aoutt + (long)par * MAXB * (QW / 2);
    for (int i0 = threadIdx.x; i0 < n; i0 += NTH * 4) {
      uint2 r[4];
#pragma unroll
      for (int q = 0; q < 4; q++) r[q] = ld_tag(src + min(i0 + q * NTH, n - 1));
#if (BPX >> 5) & 1
      {
        unsigned vm = 0u;
#pragma unroll
        for (int q = 0; q < 4; q++) if (i0 + q * NTH < n) vm |= 1u << q;
        wait_all<4>([&](int i) { return src + min(i0 + i * NTH, n - 1); }, r, TAGA(a), vm);
      }
#endif
#pragma unroll
      for (int q = 0; q < 4; q++) {
        const int i = i0 + q * NTH;
        if (i < n) {
          const int b = i / (QW / 2), k = (i % (QW / 2)) * 2;
          *reinterpret_cast<uint32_t*>(&sm.u.xo[b][k]) = wait_tag(src + i, r[q], TAGA(a));
        }
      }
    }
  }
  __syncthreads();
  // one block per output strip (144), 24 warps x 2 units (preloaded)
  for (int strip = blockIdx.x; strip < 144; strip += gridDim.x) {
    BSm bl{&sm.u.xo[0][0], QWP, B};
    block_strips<NWARP, 1>(sm, 1, 48,
      [&](int, int u0, int nu, float (*acc)[4]) {
#pragma unroll
        for (int q = 0; q < 8; q++) {
          const uint2 b = bl.get((u0 + (q >> 2)) * 64 + (q & 3) * 16);
          mma_bf16(acc[0], wpre[q].x, wpre[q].y, wpre[q].z, wpre[q].w, b.x, b.y);
        }
      },
      [&](int, float (*acc4)[4]) {
      const float* acc = acc4[0];
      const int lane = lane_id(), g = lane >> 2, tt = lane & 3;
      float y[4];
      for (int h = 0; h < 2; h++)
        for (int cc = 0; cc < 2; cc++) {
          const int tok = 2 * tt + cc;
          y[2 * h + cc] = 0.f;
          if (tok >= B) continue;
          const int row = strip * 16 + g + 8 * h;
          const float x = rbf(acc[2 * h + cc]);
          const bf16* hb = c.ha + ((long)ap.slot * MAXB + tok) * 3 * H + row;
          y[2 * h + cc] = sconv_static(x, hb, H, t, L.attn_sc + row * 4);
          c.ha[((long)ap.slot * MAXB + tok) * 3 * H + (t % 3) * H + row] = tobf(x);
        }
      // rows (g, g + 1) are lanes (l, l + 4): pack pairs on even g
      float yo[4];
#pragma unroll
      for (int q = 0; q < 4; q++) yo[q] = __shfl_down_sync(0xffffffff, y[q], 4);
      if ((g & 1) == 0)
        for (int h = 0; h < 2; h++)
          for (int cc = 0; cc < 2; cc++) {
            const int tok = 2 * tt + cc;
            if (tok >= B) continue;
            const int row = strip * 16 + g + 8 * h;
            st_tag(c.attst + (long)(par * MAXB + tok) * NPAIR + row / 2, pack_bf2(y[2 * h + cc], yo[2 * h + cc]), TAGA(a));
          }
      });
  }
}

// mlp mix of application a, token b -> x (f32). Sources: blocks in slots 0..3, the boundary layer's old partial in
// slot 4, the partial (partial + attention output in f32, or the attention output alone) in slot 5.
__device__ void mlp_mix(PH_ARGS, int a, int b, float (*x)[EPT]) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  float v[6][EPT];
  const bool add_pin = !(a == 0 || ap.bnd);
  const int idx[6] = {a == 0 ? 0 : ap.blk[0], ap.blk[1], ap.blk[2], ap.blk[3], ap.pin, ap.pin};
  unsigned msk = (a == 0) ? 1u : (((1u << ap.nblk) - 1u) | (ap.bnd ? 16u : 0u));
  const float* qs[1] = {L.mq};
  float qv[1][EPT];
  load_queries<1>(qs, 1, qv);
  load_srcs<6>(c, hd, idx, msk | (add_pin ? 32u : 0u), b, v);
  float as[EPT];
  load_vec_bf(c.attst + (long)((a & 1) * MAXB + b) * NPAIR, TAGA(a), as);
#pragma unroll
  for (int k = 0; k < EPT; k++) v[5][k] = add_pin ? v[5][k] + as[k] : as[k];
  depth_mix_q<6, 1>(v, msk | 32u, qv, 1, x, sm);
}

// (gated) mlp input of token b (f32) -> router input xr (bf16) + expert input x16 (f16 hi / lo) in smem
__device__ void mlp_in_x(PH_ARGS, int a, float (*xin)[EPT], int b) {
  const LayerW& L = c.L[c.A[a].layer];
  float wv[EPT];
  load_w(L.mlp_norm, wv);
  float s[1] = {0.f}, mx[1] = {0.f};
#pragma unroll
  for (int k = 0; k < EPT; k++) { s[0] += xin[0][k] * xin[0][k]; mx[0] = fmaxf(mx[0], fabsf(xin[0][k] * wv[k])); }
  block_sum_max<1, 1>(s, mx, sm);
  const float r = rsqrtf(s[0] / (float)H + 1e-6f);
  // scale: max |y| <= bf16 rounding of r * max |x w|: y * 2^sh stays below 2^15 (f16 exact for the hi part)
  int e2 = 0;
  const float bound = mx[0] * r;
  frexpf(bound, &e2);                    // bound in [2^(e2-1), 2^e2)
  const int sh = (bound > 0.f) ? 15 - e2 : 0;
  const float scl = ldexpf(1.0f, sh);
#pragma unroll
  for (int j = 0; j < 2; j++) {
    if (!EV(2 * j)) continue;
    const int el = EL(2 * j);
    const uint32_t yb = pack_bf2(xin[0][2 * j] * r * wv[2 * j], xin[0][2 * j + 1] * r * wv[2 * j + 1]);
    *reinterpret_cast<uint32_t*>(&sm.u.e.xr[b][el]) = yb;
    const float y0 = bf_lo(yb) * scl, y1 = bf_hi(yb) * scl;
    const __half h0 = __float2half_rn(y0), h1 = __float2half_rn(y1);
    sm.u.e.x16[b][0][el] = h0; sm.u.e.x16[b][0][el + 1] = h1;
    sm.u.e.x16[b][1][el] = __float2half_rn((y0 - __half2float(h0)) * 16777216.0f);
    sm.u.e.x16[b][1][el + 1] = __float2half_rn((y1 - __half2float(h1)) * 16777216.0f);
  }
  if (threadIdx.x == 0) sm.sc16[b] = ldexpf(1.0f, -sh);
}

// B >= 2: the designated block of token b publishes the router input row (bf16 pairs) and the f16 scale exponent
__device__ void mlp_publish(PH_ARGS, int a, float (*xin)[EPT], int b) {
  const LayerW& L = c.L[c.A[a].layer];
  const int par = a & 1;
  float wv[EPT];
  load_w(L.mlp_norm, wv);
  float s[1] = {0.f}, mx[1] = {0.f};
#pragma unroll
  for (int k = 0; k < EPT; k++) { s[0] += xin[0][k] * xin[0][k]; mx[0] = fmaxf(mx[0], fabsf(xin[0][k] * wv[k])); }
  block_sum_max<1, 1>(s, mx, sm);
  const float r = rsqrtf(s[0] / (float)H + 1e-6f);
  int e2 = 0;
  const float bound = mx[0] * r;
  frexpf(bound, &e2);
  const int sh = (bound > 0.f) ? 15 - e2 : 0;
  uint2* dst = c.xrt + (long)(par * MAXB + b) * NPAIR;
#pragma unroll
  for (int j = 0; j < 2; j++)
    if (EV(2 * j)) st_tag(dst + threadIdx.x + j * NTH, pack_bf2(xin[0][2 * j] * r * wv[2 * j], xin[0][2 * j + 1] * r * wv[2 * j + 1]), TAGA(a));
  if (threadIdx.x == 0) st_tag(c.sht + par * MAXB + b, (uint32_t)sh, TAGA(a));
}
// every block: router input rows + the expert input (f16 hi / lo, the same arithmetic as mlp_in_x)
__device__ void mlp_poll(PH_ARGS, int a) {
  const int B = HDB, par = a & 1;
  poll_rows(c.xrt + (long)par * MAXB * NPAIR, B, [&](int r) { return &sm.u.e.xr[r][0]; }, TAGA(a));
  if (threadIdx.x < B) {
    const int sh = (int)poll(c.sht + par * MAXB + threadIdx.x, TAGA(a));
    sm.bcast[32 + threadIdx.x] = (float)sh;
    sm.sc16[threadIdx.x] = ldexpf(1.0f, -sh);
  }
  __syncthreads();
  for (int b = 0; b < B; b++) {
    const float scl = ldexpf(1.0f, (int)sm.bcast[32 + b]);
#pragma unroll
    for (int j = 0; j < 2; j++) {
      if (!EV(2 * j)) continue;
      const int el = EL(2 * j);
      const uint32_t yb = *reinterpret_cast<const uint32_t*>(&sm.u.e.xr[b][el]);
      const float y0 = bf_lo(yb) * scl, y1 = bf_hi(yb) * scl;
      const __half h0 = __float2half_rn(y0), h1 = __float2half_rn(y1);
      sm.u.e.x16[b][0][el] = h0; sm.u.e.x16[b][0][el + 1] = h1;
      sm.u.e.x16[b][1][el] = __float2half_rn((y0 - __half2float(h0)) * 16777216.0f);
      sm.u.e.x16[b][1][el + 1] = __float2half_rn((y1 - __half2float(h1)) * 16777216.0f);
    }
  }
  __syncthreads();
}

#ifndef RTL2
#define RTL2 0
#endif
#ifndef RTL1
#define RTL1 0
#endif
__device__ NI_MLPIN int ph_mlp_in(PH_ARGS, int a) {
  const App& ap = c.A[a];
#if RTL1
  // (port of s15-mini-b200-a2 s0021) at B = 1 this block's router strip (74 KB) into its L1 during the MLP-input mix
  if (HDB == 1 && blockIdx.x < 8) {
    const uint8_t* p = c.L[ap.layer].wr + (long)blockIdx.x * 36 * 2048;
    for (int i = threadIdx.x; i < 36 * 2048 / 128; i += NTH) asm volatile("prefetch.global.L1 [%0];" :: "l"(p + i * 128));
  }
#endif
#if RTL2
  // track A: at B = 1 the router strip of this block into L2 while the MLP input is mixed (B >= 2: at attn_in)
  if (HDB == 1 && threadIdx.x == 32 && blockIdx.x < 8) pf_l2(c.L[ap.layer].wr + (long)blockIdx.x * 36 * 2048, 36 * 2048);
#endif
  if (ap.nmsg) return -1;   // the gate's D blocks compute the mix themselves
  if (HDB >= 2) {
    for (int b = blockIdx.x; b < HDB; b += gridDim.x) {
      float x[1][EPT];
      mlp_mix(c, hd, sm, a, b, x);
      mlp_publish(c, hd, sm, a, x, b);
    }
    mlp_poll(c, hd, sm, a);
    return 0;
  }
  for (int b = 0; b < HDB; b++) {
    float x[1][EPT];
    mlp_mix(c, hd, sm, a, b, x);
    mlp_in_x(c, hd, sm, a, x, b);
  }
  __syncthreads();
  return 0;
}

__device__ NI_ROUTER void ph_router(PH_ARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = HDB, par = a & 1;
  for (int strip = blockIdx.x; strip < 8; strip += gridDim.x) {
    BSm bl{&sm.u.e.xr[0][0], HP, B};
    block_strips<NWARP, 1>(sm, 1, 36,
      [&](int, int u0, int nu, float (*acc)[4]) { piece_bf16(L.wr + (long)strip * 36 * 2048, u0, nu, bl, acc[0]); },
      [&](int, float (*acc)[4]) {
        const int lane = lane_id(), g = lane >> 2, t = lane & 3;
        for (int h = 0; h < 2; h++)
          for (int cc = 0; cc < 2; cc++) {
            const int tok = 2 * t + cc;
            if (tok < B) st_tagf(c.rlogt + (par * MAXB + tok) * NE + strip * 16 + g + 8 * h, acc[0][2 * h + cc], TAGA(a));
          }
      });
  }
}

// top-8 + union (every block, identical)
#ifndef RTMASK
#define RTMASK 1
#endif
#ifndef RTREDUX
#define RTREDUX 1
#endif
__device__ NI_ROUTING void routing(const Ctx& c, const Hdr& hd, Smem& sm, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int B = HDB;
  const int w = threadIdx.x >> 5, lane = lane_id();
  if (threadIdx.x < 4) sm.umask[threadIdx.x] = 0u;
#if RTMASK
  if (threadIdx.x < NE / 4) sm.tokm[threadIdx.x] = 0u;
#endif
  __syncthreads();
  if (w < B) {
    float lg[4], sel[4];
    uint2 rl[4];
#pragma unroll
    for (int k = 0; k < 4; k++) rl[k] = ld_tag(c.rlogt + ((a & 1) * MAXB + w) * NE + lane + 32 * k);
#if (BPX >> 3) & 1
    wait_all<4>([&](int i) { return c.rlogt + ((a & 1) * MAXB + w) * NE + lane + 32 * i; }, rl, TAGA(a));
#endif
#pragma unroll
    for (int k = 0; k < 4; k++) {
      const int e = lane + 32 * k;
      lg[k] = __uint_as_float(wait_tag(c.rlogt + ((a & 1) * MAXB + w) * NE + e, rl[k], TAGA(a)));
      sel[k] = sigm(lg[k]) + L.rbias[e];
      if (!(sel[k] == sel[k])) { sel[k] = -1e30f; atomicOr(c.bar + 2, 1u << (a & 31)); }   // NaN: never chosen, flagged
    }
    unsigned taken = 0;
    int myid = 0; float mylg = 0.f;
    // (from a2 s0015) order-preserving integer keys of the selection scores; per round this lane's best untaken entry
    // (ties: the lower index), then the warp's largest key and, among equal keys, the lowest index (redux.sync): the
    // same choice as the comparison tree with (value, lower index) ordering
#if RTREDUX
    unsigned key[4];
#pragma unroll
    for (int k = 0; k < 4; k++) { const unsigned u = __float_as_uint(sel[k]); key[k] = (u & 0x80000000u) ? ~u : (u | 0x80000000u); }
    for (int r = 0; r < TOPK; r++) {
      unsigned bk = 0u; int bi_l = 0x7fffffff; float bl_l = 0.f;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const bool ok = !(taken & (1u << k));
        if (ok && (key[k] > bk || bi_l == 0x7fffffff)) { bk = key[k]; bi_l = lane + 32 * k; bl_l = lg[k]; }
      }
      const unsigned mk = __reduce_max_sync(0xffffffffu, bk);
      int bi = (int)__reduce_min_sync(0xffffffffu, (bk == mk && bi_l != 0x7fffffff) ? (unsigned)bi_l : 0x7fffffffu);
      bi = bi < NE ? bi : 0;   // cannot happen; keeps every index in range
      const float bl = __shfl_sync(0xffffffffu, bl_l, bi & 31);
#else
    for (int r = 0; r < TOPK; r++) {
      float bv = -1e30f, bl = 0.f; int bi = 1 << 30;
#pragma unroll
      for (int k = 0; k < 4; k++) {
        const bool ok = !(taken & (1u << k));
        if (ok && sel[k] > bv) { bv = sel[k]; bi = lane + 32 * k; bl = lg[k]; }
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) {
        const float ov = __shfl_xor_sync(0xffffffff, bv, o);
        const int oi = __shfl_xor_sync(0xffffffff, bi, o);
        const float ol = __shfl_xor_sync(0xffffffff, bl, o);
        if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; bl = ol; }
      }
      bi = bi < NE ? bi : 0;
#endif
      if ((bi & 31) == lane) taken |= 1u << (bi >> 5);
      if (lane == r) { myid = bi; mylg = bl; }
    }
    // lanes 0..7 hold (id, logit) in rank order: weights sigmoid / sum * 8 (sum in rank order)
    const float sg = sigm(mylg);
    float den = 0.f;
#pragma unroll
    for (int r = 0; r < TOPK; r++) den += __shfl_sync(0xffffffff, sg, r);
    const float wt = sg / den * 8.0f;
    int rank = 0;
#pragma unroll
    for (int r = 0; r < TOPK; r++) rank += (__shfl_sync(0xffffffff, myid, r) < myid);
    if (lane < TOPK) {
      sm.tex[w][rank] = myid; sm.twt[w][rank] = wt;
      atomicOr(&sm.umask[myid >> 5], 1u << (myid & 31));
#if RTMASK
      atomicOr(&sm.tokm[myid >> 2], 1u << (8 * (myid & 3) + w));
#endif
    }
  }
  __syncthreads();
  if (w == 0) {
    int n = 0;
#pragma unroll
    for (int k = 0; k < 4; k++) {
      const bool used = (sm.umask[k] >> lane) & 1u;
      const unsigned bal = __ballot_sync(0xffffffff, used);
      if (used) sm.uexp[n + __popc(bal & ((1u << lane) - 1u))] = 32 * k + lane;
      n += __popc(bal);
    }
    if (lane == 0) sm.nU = n;
#if XPF
    if (blockIdx.x == gridDim.x - 1 && c.rhist) {
      for (int u = lane; u < n; u += 32) c.rhist[a * (MAXU + 1) + u] = sm.uexp[u];
      if (lane == 0) c.rhist[a * (MAXU + 1) + MAXU] = n;
    }
#endif
    __syncwarp();
    for (int u = lane; u < n; u += 32) {
      const int e = sm.uexp[u];
      int cnt = 0;
#if RTMASK
      // (port of s15-mini-b200-a2 s0020) tokens of the expert from its bit mask, in ascending order as before
      unsigned mk = (sm.tokm[e >> 2] >> (8 * (e & 3))) & 0xffu;
      while (mk) { sm.utok[u][cnt++] = __ffs(mk) - 1; mk &= mk - 1; }
#else
      for (int b = 0; b < B; b++)
        for (int r = 0; r < TOPK; r++)
          if (sm.tex[b][r] == e) sm.utok[u][cnt++] = b;
#endif
      sm.uncnt[u] = cnt;
    }
  }
  __syncthreads();
}

__device__ __forceinline__ float act_fn(float g, float u) {
  float a = 4.0f * tanhf(g / 4.0f) * sigm(g);
  return a * (25.0f * tanhf(u / 25.0f));
}

// w13: work items (union slot u, strip of 16 rows = 8 (gate, up) pairs), round robin over blocks, 8 per round,
// 3 warps x 12 units each; the epilogue computes act * routing weight -> act16t (f16 hi / lo, x16)
template <int NG>
__device__ __forceinline__ void w13_run(const Ctx& c, Smem& sm, const LayerW& L, int u, int strip, int u0, int nu, float (*acc)[4]) {
  const int g = lane_id() >> 2;
  const int e = sm.uexp[u], nt = sm.uncnt[u];
  const __half* colp[3];
#pragma unroll
  for (int ng = 0; ng < 2; ng++) {
    const int li = 4 * ng + (g >> 1), part = g & 1;
    colp[ng] = li < nt ? &sm.u.e.x16[sm.utok[u][li]][part][0] : nullptr;
  }
  colp[2] = nullptr;
  if (!L.mx) piece_fp4<NG, false>(L.w13 + ((long)e * 144 + strip) * 36 * FP4_UB, u0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
  else piece_fp8<NG, false>(L.w13 + ((long)e * 144 + strip) * 36 * 1056, u0, nu, colp, acc);
}
__device__ void w13_epi(const Ctx& c, const Hdr& hd, Smem& sm, const LayerW& L, int a, int u, int strip, int NGN, float (*acc)[4]) {
  const int lane = lane_id(), g = lane >> 2, t = lane & 3, par = a & 1;
  const int e = sm.uexp[u], nt = sm.uncnt[u];
  const float fac = L.mx ? 1.0f : L.f13[e];
  for (int ng = 0; ng < NGN; ng++) {
    const float a0 = acc[ng][0], a1 = acc[ng][1], a2 = acc[ng][2], a3 = acc[ng][3];
    // lane (g, t): rows g, g+8 of token li = 4 ng + t: (hi, lo) = (a0, a1) row g; (a2, a3) row g+8
    const int li = 4 * ng + t;
    const bool ok = li < nt;
    const int tok = ok ? sm.utok[u][li] : 0;
    const float s16 = sm.sc16[tok];
    const float h0 = rbf((a0 + a1 * 5.9604644775390625e-08f) * s16 * fac);
    const float h1 = rbf((a2 + a3 * 5.9604644775390625e-08f) * s16 * fac);
    // pair i: rows 2i (gate), 2i+1 (up); partner row g ^ 1 is lane ^ 4
    const float o0 = __shfl_xor_sync(0xffffffff, h0, 4), o1 = __shfl_xor_sync(0xffffffff, h1, 4);
    float wgt = 0.f;
    if (ok) for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) wgt = sm.twt[tok][r];
    const float act0 = rbf(act_fn(h0, o0) * wgt), act1 = rbf(act_fn(h1, o1) * wgt);
    const float v0 = act0 * 16.0f, v1 = act1 * 16.0f;
    const __half hi0 = __float2half_rn(v0), hi1 = __float2half_rn(v1);
    const __half lo0 = __float2half_rn((v0 - __half2float(hi0)) * 16777216.0f), lo1 = __float2half_rn((v1 - __half2float(hi1)) * 16777216.0f);
    const uint32_t q0 = __half_as_ushort(hi0), q1 = __half_as_ushort(lo0), q2 = __half_as_ushort(hi1), q3 = __half_as_ushort(lo1);
    // pairs i0 = strip*8 + g/2 (g even) and i0 + 1 (g + 2): lanes l and l + 8
    const uint32_t p0 = __shfl_down_sync(0xffffffff, q0, 8), p1 = __shfl_down_sync(0xffffffff, q1, 8);
    const uint32_t p2 = __shfl_down_sync(0xffffffff, q2, 8), p3 = __shfl_down_sync(0xffffffff, q3, 8);
    if (ok && (g & 3) == 0) {
      uint2* dst = c.act16t + (((long)(par * MAXU + u) * MAXB + li) * 2) * (IE / 2);
      const int i0 = strip * 8 + (g >> 1), i1 = strip * 8 + 4 + (g >> 1);
      st_tag(dst + i0 / 2, q0 | (p0 << 16), TAGA(a));
      st_tag(dst + IE / 2 + i0 / 2, q1 | (p1 << 16), TAGA(a));
      st_tag(dst + i1 / 2, q2 | (p2 << 16), TAGA(a));
      st_tag(dst + IE / 2 + i1 / 2, q3 | (p3 << 16), TAGA(a));
    }
  }
}
#ifndef W13PF0
#define W13PF0 0
#endif
__device__ __noinline__ void w2_pf(const Smem& sm, const LayerW& L);
#ifndef W2PFL
#define W2PFL 0
#endif
// part `part` of `nparts` of this block's w2 item range (expert-major, contiguous strips; <= two experts) into L2
__device__ __noinline__ void w2_pf_part(const Smem& sm, const LayerW& L, int part, int nparts) {
  const int T = sm.nU * 144;
  const int ib = (int)((long)T * blockIdx.x / gridDim.x), ie = (int)((long)T * (blockIdx.x + 1) / gridDim.x);
  if (ib >= ie) return;
  const int a0 = ib + (int)((long)(ie - ib) * part / nparts), a1 = ib + (int)((long)(ie - ib) * (part + 1) / nparts);
  if (a1 <= a0) return;
  const long ub = L.mx ? 18 * 1056 : 18 * FP4_UB;
  const int ua = a0 / 144, uz = (a1 - 1) / 144;
  if (ua == uz) pf_l2(L.w2 + ((long)sm.uexp[ua] * 144 + a0 % 144) * ub, (long)(a1 - a0) * ub);
  else {
    pf_l2(L.w2 + ((long)sm.uexp[ua] * 144 + a0 % 144) * ub, (long)(144 - a0 % 144) * ub);
    pf_l2(L.w2 + (long)sm.uexp[uz] * 144 * ub, (long)((a1 - 1) % 144 + 1) * ub);
  }
}
// track A (EXQ): expert items taken by the warps of a block one at a time from a counter in shared memory (no rounds
// of 8 items with block-wide syncs): each item is accumulated by one warp in the same three parts and summed in the
// same order as the three-warp split of the round path (bit-identical). For the generic kernel (several rounds).
#ifndef EXQ
#define EXQ 0
#endif
__device__ __noinline__ void w13_item2(const Ctx& c, const Hdr& hd, Smem& sm, const LayerW& L, int a, int u, int strip) {
  float tot[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
#pragma unroll 1
  for (int part = 0; part < 3; part++) {
    float acc[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
    w13_run<2>(c, sm, L, u, strip, 12 * part, 12, acc);
#pragma unroll
    for (int i = 0; i < 4; i++) { tot[0][i] += acc[0][i]; tot[1][i] += acc[1][i]; }
  }
  w13_epi(c, hd, sm, L, a, u, strip, 2, tot);
}
// track A (NG2NI): a round that contains an expert with more than 4 tokens (two MMA column groups; 1.7% of the
// union's experts at B = 8) runs out of line, so that its registers are not part of the common path's allocation
#ifndef NG2NI
#define NG2NI 0
#endif
// W13IL: w13 items (union expert, strip) numbered strip-major, so that every expert's 144 strips are spread over the
// whole phase and all activations complete together (w2 blocks wait for their experts); one mapping for all paths
#ifndef W13IL
#define W13IL 0
#endif
#if W13IL
#define W13U(it) ((it) % sm.nU)
#define W13S(it) ((it) / sm.nU)
#else
#define W13U(it) ((it) / 144)
#define W13S(it) ((it) % 144)
#endif
__device__ __noinline__ void w13_round2(const Ctx& c, const Hdr& hd, Smem& sm, const LayerW& L, int a, int r0, int ns) {
  const int G = gridDim.x;
  constexpr int WG = 3;
  auto run2 = [&](int q, int u0, int nu, float (*acc)[4]) {
    const int it = blockIdx.x + (r0 + q) * G;
    if (sm.uncnt[W13U(it)] > 4) w13_run<2>(c, sm, L, W13U(it), W13S(it), u0, nu, acc);
    else w13_run<1>(c, sm, L, W13U(it), W13S(it), u0, nu, acc);
  };
  auto epi = [&](int q, float (*acc)[4]) { const int it = blockIdx.x + (r0 + q) * G; w13_epi(c, hd, sm, L, a, W13U(it), W13S(it), sm.uncnt[W13U(it)] > 4 ? 2 : 1, acc); };
  block_strips<WG, 2>(sm, ns, 36, run2, epi);
}
__device__ NI_W13 void ph_w13(PH_ARGS, int a) {
  const LayerW& L = c.L[c.A[a].layer];
  const int nU = sm.nU;

  const int T = nU * 144, G = gridDim.x;
  constexpr int WG = 3, PER = NWARP / WG;
  const int mine = (T - (int)blockIdx.x + G - 1) / G;      // items blockIdx.x + k G
#if W2PF
  if (HDB <= W2PF) w2_pf(sm, L);
#endif
#if EXQ
  if (mine > PER) {
    if (threadIdx.x == 0) sm.exq = 0;
    __syncthreads();
    for (;;) {
      int k = 0;
      if (lane_id() == 0) k = atomicAdd(&sm.exq, 1);
      k = __shfl_sync(0xffffffffu, k, 0);
      if (k >= mine) break;
      const int it = blockIdx.x + k * G, u = W13U(it), strip = W13S(it);
      if (HDB > 4 && sm.uncnt[u] > 4) { w13_item2(c, hd, sm, L, a, u, strip); continue; }
      float tot[1][4] = {{0.f, 0.f, 0.f, 0.f}};
#pragma unroll 1
      for (int part = 0; part < 3; part++) {
        float acc[1][4] = {{0.f, 0.f, 0.f, 0.f}};
        w13_run<1>(c, sm, L, u, strip, 12 * part, 12, acc);
#pragma unroll
        for (int i = 0; i < 4; i++) tot[0][i] += acc[0][i];
      }
      w13_epi(c, hd, sm, L, a, u, strip, 1, tot);
    }
    __syncthreads();
    return;
  }
#endif
  for (int r0 = 0; r0 < mine; r0 += PER) {
    const int ns = min(PER, mine - r0);
#if W13PF == 1
    if (threadIdx.x < PER && r0 + PER + (int)threadIdx.x < mine) {   // next round's items into L2
      const int it = blockIdx.x + (r0 + PER + threadIdx.x) * G;
      const long ub = L.mx ? 36 * 1056 : 36 * FP4_UB;
      pf_l2(L.w13 + ((long)sm.uexp[W13U(it)] * 144 + W13S(it)) * ub, ub);
    }
#endif
#if W13PF0
    // this round's items into L2 as well: each warp keeps only FP4_UNR units in flight (registers), so the later
    // batches of a round find their lines in L2 (or on the way) instead of starting a new HBM round trip
    if (r0 == 0 && threadIdx.x >= 32 && threadIdx.x < 32 + PER && (int)threadIdx.x - 32 < mine) {
      const int it = blockIdx.x + (threadIdx.x - 32) * G;
      const long ub = L.mx ? 36 * 1056 : 36 * FP4_UB;
      pf_l2(L.w13 + ((long)sm.uexp[W13U(it)] * 144 + W13S(it)) * ub, ub);
    }
#endif
    // one n-group unless an expert of this round has more than 4 tokens
    bool two = false;
    if (HDB > 4) for (int q = 0; q < ns; q++) two |= sm.uncnt[W13U(blockIdx.x + (r0 + q) * G)] > 4;   // an expert has at most B tokens
    // after a warp's last loads of the round (its MMAs done; the block now reduces and runs the epilogue): L2
    // prefetches of bytes that are certain to be read next, in the window where the memory system would idle
    auto tail = [&](int q, int u0, int nu) {
      (void)q; (void)u0; (void)nu;
#if W13PF == 2
      if (lane_id() == 0 && r0 + PER + q < mine) {     // this warp's units of the same slot of the next round
        const int it = blockIdx.x + (r0 + PER + q) * G;
        const long ub1 = L.mx ? 1056 : FP4_UB;
        pf_l2(L.w13 + (((long)sm.uexp[W13U(it)] * 144 + W13S(it)) * 36 + u0) * ub1, nu * ub1);
      }
#endif
#if W2PFL
      if (HDB <= W2PFL && lane_id() == 0 && r0 + PER >= mine) w2_pf_part(sm, L, threadIdx.x >> 5, ns * WG);   // last round: the block's w2 range
#endif
    };
    auto run1 = [&](int q, int u0, int nu, float (*acc)[4]) { const int it = blockIdx.x + (r0 + q) * G; w13_run<1>(c, sm, L, W13U(it), W13S(it), u0, nu, acc); tail(q, u0, nu); };
    auto run2 = [&](int q, int u0, int nu, float (*acc)[4]) {
      const int it = blockIdx.x + (r0 + q) * G;
      if (HDB > 4 && sm.uncnt[W13U(it)] > 4) w13_run<2>(c, sm, L, W13U(it), W13S(it), u0, nu, acc);
      else w13_run<1>(c, sm, L, W13U(it), W13S(it), u0, nu, acc);
      tail(q, u0, nu);
    };
    auto epi = [&](int q, float (*acc)[4]) { const int it = blockIdx.x + (r0 + q) * G; w13_epi(c, hd, sm, L, a, W13U(it), W13S(it), (HDB > 4 && sm.uncnt[W13U(it)] > 4) ? 2 : 1, acc); };
#if NG2NI
    auto epi1 = [&](int q, float (*acc)[4]) { const int it = blockIdx.x + (r0 + q) * G; w13_epi(c, hd, sm, L, a, W13U(it), W13S(it), 1, acc); };
    if (!two) block_strips<WG, 1>(sm, ns, 36, run1, epi1);
    else w13_round2(c, hd, sm, L, a, r0, ns);
    (void)run2; (void)epi;
#else
    if (!two) block_strips<WG, 1>(sm, ns, 36, run1, epi);
    else block_strips<WG, 2>(sm, ns, 36, run2, epi);
#endif
  }
}

// track A (EXPF): L2 prefetches of expert bytes that are certain to be read (the union is known after routing):
//  W2PF: this block's w2 range (<= two experts, contiguous strips), issued before its w13 work;
//  W13PF: the block's w13 items of the next round, issued at the start of a round (B >= 2: several rounds per block)
#ifndef W2PF
#define W2PF 0
#endif
#ifndef W13PF
#define W13PF 0
#endif
__device__ __noinline__ void w2_pf(const Smem& sm, const LayerW& L) {
  const int T = sm.nU * 144;
  const int ib = (int)((long)T * blockIdx.x / gridDim.x), ie = (int)((long)T * (blockIdx.x + 1) / gridDim.x);
  if (ib >= ie || threadIdx.x >= 2) return;
  const long ub = L.mx ? 18 * 1056 : 18 * FP4_UB;
  const int u0 = ib / 144, u1 = (ie - 1) / 144;
  if (threadIdx.x == 1 && u1 == u0) return;
  const int u = threadIdx.x == 0 ? u0 : u1;
  const int s0 = threadIdx.x == 0 ? ib % 144 : 0, s1 = (u == u1) ? (ie - 1) % 144 + 1 : 144;
  pf_l2(L.w2 + ((long)sm.uexp[u] * 144 + s0) * ub, (long)(s1 - s0) * ub);
}
// w2, part 1: work items (union expert u, output strip) expert-major in block-contiguous ranges (at most two experts
// per block, their inputs staged in shared memory once); 8 items per round, 3 warps x 6 units each (a fixed split).
// Each item publishes its contribution per token as tagged f32 rows w2ct[par][token][rank of the expert][row].
__device__ __noinline__ void w2a_item2(const Ctx& c, const Hdr& hd, Smem& sm, const LayerW& L, int a, int r0, int u0, int n0) {
  const int par = a & 1, lane = lane_id();
  const __half* w2sb = &sm.u.w2s[0][0][0];
  auto run = [&](int q, int uu0, int nu, float (*acc)[4]) {
    const int it = r0 + q, u = it / 144, strip = it % 144;
    const int e = sm.uexp[u], nt = sm.uncnt[u], j0 = (u == u0) ? 0 : n0;
    const int g = lane >> 2;
    const __half* colp[3];
#pragma unroll
    for (int ng = 0; ng < 2; ng++) {
      const int li = 4 * ng + (g >> 1), part = g & 1;
      colp[ng] = li < nt ? w2sb + ((long)(j0 + li) * 2 + part) * IE : nullptr;
    }
    colp[2] = nullptr;
    if (HDB > 4 && nt > 4) {
      if (!L.mx) piece_fp4<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
      else piece_fp8<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
    } else {
      if (!L.mx) piece_fp4<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
      else piece_fp8<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
    }
  };
  auto epi = [&](int q, float (*acc)[4]) {
    const int it = r0 + q, u = it / 144, strip = it % 144;
    const int e = sm.uexp[u], nt = sm.uncnt[u];
    const int g = lane >> 2, tt = lane & 3;
    const float fac = (L.mx ? 1.0f : L.f2[e]) * 0.0625f;
    for (int ng = 0; ng < ((HDB > 4 && nt > 4) ? 2 : 1); ng++) {
      const int li = 4 * ng + tt;
      if (li >= nt) continue;
      const int tok = sm.utok[u][li];
      int k = 0;
      for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) k = r;
      uint2* dst = c.w2ct + (((long)(par * MAXB + tok) * TOPK + k) * H) + strip * 16;
      st_tagf(dst + g, (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * fac, TAGA(a));
      st_tagf(dst + g + 8, (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * fac, TAGA(a));
    }
  };
  float tot[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
#pragma unroll 1
  for (int part = 0; part < 3; part++) {
    float acc[2][4] = {{0.f, 0.f, 0.f, 0.f}, {0.f, 0.f, 0.f, 0.f}};
    run(0, 6 * part, 6, acc);
#pragma unroll
    for (int i = 0; i < 4; i++) { tot[0][i] += acc[0][i]; tot[1][i] += acc[1][i]; }
  }
  epi(0, tot);
}
__device__ __noinline__ void w2a_round2(const Ctx& c, const Hdr& hd, Smem& sm, const LayerW& L, int a, int r0, int ns, int u0, int n0) {
  constexpr int WG = 3;
  const int par = a & 1, lane = lane_id();
  const __half* w2sb = &sm.u.w2s[0][0][0];
  auto run = [&](int q, int uu0, int nu, float (*acc)[4]) {
    const int it = r0 + q, u = it / 144, strip = it % 144;
    const int e = sm.uexp[u], nt = sm.uncnt[u], j0 = (u == u0) ? 0 : n0;
    const int g = lane >> 2;
    const __half* colp[3];
#pragma unroll
    for (int ng = 0; ng < 2; ng++) {
      const int li = 4 * ng + (g >> 1), part = g & 1;
      colp[ng] = li < nt ? w2sb + ((long)(j0 + li) * 2 + part) * IE : nullptr;
    }
    colp[2] = nullptr;
    if (HDB > 4 && nt > 4) {
      if (!L.mx) piece_fp4<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
      else piece_fp8<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
    } else {
      if (!L.mx) piece_fp4<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
      else piece_fp8<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
    }
  };
  auto epi = [&](int q, float (*acc)[4]) {
    const int it = r0 + q, u = it / 144, strip = it % 144;
    const int e = sm.uexp[u], nt = sm.uncnt[u];
    const int g = lane >> 2, tt = lane & 3;
    const float fac = (L.mx ? 1.0f : L.f2[e]) * 0.0625f;
    for (int ng = 0; ng < ((HDB > 4 && nt > 4) ? 2 : 1); ng++) {
      const int li = 4 * ng + tt;
      if (li >= nt) continue;
      const int tok = sm.utok[u][li];
      int k = 0;
      for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) k = r;
      uint2* dst = c.w2ct + (((long)(par * MAXB + tok) * TOPK + k) * H) + strip * 16;
      st_tagf(dst + g, (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * fac, TAGA(a));
      st_tagf(dst + g + 8, (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * fac, TAGA(a));
    }
  };
  block_strips<WG, 2>(sm, ns, 18, run, epi);
}
__device__ NI_W2A void ph_w2a(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int par = a & 1;
  const int nU = sm.nU;
  constexpr int WG = 3, PER = NWARP / WG;
  const int lane = lane_id();
  const int T = nU * 144;
  const int ib = (int)((long)T * blockIdx.x / gridDim.x), ie = (int)((long)T * (blockIdx.x + 1) / gridDim.x);
  if (ib >= ie) return;
  const int u0 = ib / 144, u1 = (ie - 1) / 144;
  const int n0 = sm.uncnt[u0];
  {
    const int np = n0 + (u1 > u0 ? sm.uncnt[u1] : 0);
    const int nw = np * 2 * (IE / 2);   // tagged words
    constexpr int SB = 8;
    for (int i0 = 2 * threadIdx.x; i0 < nw; i0 += 2 * NTH * SB) {
      uint2 r[SB][2]; const uint2* pp[SB];
#pragma unroll
      for (int q = 0; q < SB; q++) {
        const int i = min(i0 + q * 2 * NTH, nw - 2);
        const int j = i / IE, w0 = i % IE;
        const int uu = j < n0 ? u0 : u1, jj = j < n0 ? j : j - n0;
        pp[q] = c.act16t + (((long)(par * MAXU + uu) * MAXB + jj) * 2) * (IE / 2) + w0;
        ld_tag2(pp[q], r[q][0], r[q][1]);
      }
#if (BPX >> 6) & 1
      {
        unsigned vm = 0u;
#pragma unroll
        for (int q = 0; q < SB; q++) if (i0 + q * 2 * NTH < nw) vm |= 3u << (2 * q);
        wait_all<2 * SB>([&](int i) { return pp[i >> 1] + (i & 1); }, &r[0][0], TAGA(a), vm);
      }
#endif
#pragma unroll
      for (int q = 0; q < SB; q++) {
        const int i = i0 + q * 2 * NTH;
        if (i >= nw) continue;
        uint32_t* d = reinterpret_cast<uint32_t*>(&sm.u.w2s[0][0][0]) + i;
        d[0] = wait_tag(pp[q], r[q][0], TAGA(a));
        d[1] = wait_tag(pp[q] + 1, r[q][1], TAGA(a));
      }
    }
  }
  __syncthreads();
  const __half* w2sb = &sm.u.w2s[0][0][0];
#if EXQ
  if (ie - ib > PER) {
    if (threadIdx.x == 0) sm.exq = ib;
    __syncthreads();
    for (;;) {
      int r0 = 0;
      if (lane == 0) r0 = atomicAdd(&sm.exq, 1);
      r0 = __shfl_sync(0xffffffffu, r0, 0);
      if (r0 >= ie) break;
      if (HDB > 4 && sm.uncnt[r0 / 144] > 4) { w2a_item2(c, hd, sm, L, a, r0, u0, n0); continue; }
      auto run1 = [&](int q, int uu0, int nu, float (*acc)[4]) {
        const int it = r0 + q, u = it / 144, strip = it % 144;
        const int e = sm.uexp[u], nt = sm.uncnt[u], j0 = (u == u0) ? 0 : n0;
        const int g = lane >> 2;
        const __half* colp[3];
#pragma unroll
        for (int ng = 0; ng < 2; ng++) {
          const int li = 4 * ng + (g >> 1), part = g & 1;
          colp[ng] = li < nt ? w2sb + ((long)(j0 + li) * 2 + part) * IE : nullptr;
        }
        colp[2] = nullptr;
        if (false) {
          if (!L.mx) piece_fp4<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
          else piece_fp8<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
        } else {
          if (!L.mx) piece_fp4<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
          else piece_fp8<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
        }
      };
      auto epi1 = [&](int q, float (*acc)[4]) {
        const int it = r0 + q, u = it / 144, strip = it % 144;
        const int e = sm.uexp[u], nt = sm.uncnt[u];
        const int g = lane >> 2, tt = lane & 3;
        const float fac = (L.mx ? 1.0f : L.f2[e]) * 0.0625f;
        for (int ng = 0; ng < 1; ng++) {
          const int li = 4 * ng + tt;
          if (li >= nt) continue;
          const int tok = sm.utok[u][li];
          int k = 0;
          for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) k = r;
          uint2* dst = c.w2ct + (((long)(par * MAXB + tok) * TOPK + k) * H) + strip * 16;
          st_tagf(dst + g, (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * fac, TAGA(a));
          st_tagf(dst + g + 8, (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * fac, TAGA(a));
        }
      };
      float tot[1][4] = {{0.f, 0.f, 0.f, 0.f}};
#pragma unroll 1
      for (int part = 0; part < 3; part++) {
        float acc[1][4] = {{0.f, 0.f, 0.f, 0.f}};
        run1(0, 6 * part, 6, acc);
#pragma unroll
        for (int i = 0; i < 4; i++) tot[0][i] += acc[0][i];
      }
      epi1(0, tot);
    }
    __syncthreads();
    return;
  }
#endif
  for (int r0 = ib; r0 < ie; r0 += PER) {
    const int ns = min(PER, ie - r0);
    bool two = false;
    if (HDB > 4) for (int q = 0; q < ns; q++) two |= sm.uncnt[(r0 + q) / 144] > 4;
#if NG2NI
    auto run1 = [&](int q, int uu0, int nu, float (*acc)[4]) {
      const int it = r0 + q, u = it / 144, strip = it % 144;
      const int e = sm.uexp[u], nt = sm.uncnt[u], j0 = (u == u0) ? 0 : n0;
      const int g = lane >> 2;
      const __half* colp[3];
#pragma unroll
      for (int ng = 0; ng < 2; ng++) {
        const int li = 4 * ng + (g >> 1), part = g & 1;
        colp[ng] = li < nt ? w2sb + ((long)(j0 + li) * 2 + part) * IE : nullptr;
      }
      colp[2] = nullptr;
      if (false) {
        if (!L.mx) piece_fp4<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
        else piece_fp8<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
      } else {
        if (!L.mx) piece_fp4<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
        else piece_fp8<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
      }
    };
    auto epi1 = [&](int q, float (*acc)[4]) {
      const int it = r0 + q, u = it / 144, strip = it % 144;
      const int e = sm.uexp[u], nt = sm.uncnt[u];
      const int g = lane >> 2, tt = lane & 3;
      const float fac = (L.mx ? 1.0f : L.f2[e]) * 0.0625f;
      for (int ng = 0; ng < 1; ng++) {
        const int li = 4 * ng + tt;
        if (li >= nt) continue;
        const int tok = sm.utok[u][li];
        int k = 0;
        for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) k = r;
        uint2* dst = c.w2ct + (((long)(par * MAXB + tok) * TOPK + k) * H) + strip * 16;
        st_tagf(dst + g, (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * fac, TAGA(a));
        st_tagf(dst + g + 8, (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * fac, TAGA(a));
      }
    };
    if (!two) block_strips<WG, 1>(sm, ns, 18, run1, epi1);
    else w2a_round2(c, hd, sm, L, a, r0, ns, u0, n0);
#else
    auto run = [&](int q, int uu0, int nu, float (*acc)[4]) {
      const int it = r0 + q, u = it / 144, strip = it % 144;
      const int e = sm.uexp[u], nt = sm.uncnt[u], j0 = (u == u0) ? 0 : n0;
      const int g = lane >> 2;
      const __half* colp[3];
#pragma unroll
      for (int ng = 0; ng < 2; ng++) {
        const int li = 4 * ng + (g >> 1), part = g & 1;
        colp[ng] = li < nt ? w2sb + ((long)(j0 + li) * 2 + part) * IE : nullptr;
      }
      colp[2] = nullptr;
      if (HDB > 4 && nt > 4) {
        if (!L.mx) piece_fp4<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
        else piece_fp8<2, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
      } else {
        if (!L.mx) piece_fp4<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * FP4_UB, uu0, nu, colp, acc, 0, sm.s6tab, SCS ? sm.scb[threadIdx.x >> 5] : nullptr);
        else piece_fp8<1, false>(L.w2 + ((long)e * 144 + strip) * 18 * 1056, uu0, nu, colp, acc);
      }
    };
    auto epi = [&](int q, float (*acc)[4]) {
      const int it = r0 + q, u = it / 144, strip = it % 144;
      const int e = sm.uexp[u], nt = sm.uncnt[u];
      const int g = lane >> 2, tt = lane & 3;
      const float fac = (L.mx ? 1.0f : L.f2[e]) * 0.0625f;
      for (int ng = 0; ng < ((HDB > 4 && nt > 4) ? 2 : 1); ng++) {
        const int li = 4 * ng + tt;
        if (li >= nt) continue;
        const int tok = sm.utok[u][li];
        int k = 0;
        for (int r = 0; r < TOPK; r++) if (sm.tex[tok][r] == e) k = r;
        uint2* dst = c.w2ct + (((long)(par * MAXB + tok) * TOPK + k) * H) + strip * 16;
        st_tagf(dst + g, (acc[ng][0] + acc[ng][1] * 5.9604644775390625e-08f) * fac, TAGA(a));
        st_tagf(dst + g + 8, (acc[ng][2] + acc[ng][3] * 5.9604644775390625e-08f) * fac, TAGA(a));
      }
    };
    if (!two) block_strips<WG, 1>(sm, ns, 18, run, epi);
    else block_strips<WG, 2>(sm, ns, 18, run, epi);
#endif
  }
}

// w2, part 2: one block per output strip: per token the 8 expert rows summed in expert-id order, the short
// convolution and the new partial (pbt)
__device__ NI_W2B void ph_w2b(PH_ARGS, int a) {
  const App& ap = c.A[a];
  const LayerW& L = c.L[ap.layer];
  const int B = HDB, t = hd.pos, par = a & 1;
  for (int strip = blockIdx.x; strip < 144; strip += gridDim.x) {
    const bool addp = !(a == 0 || ap.bnd);
    const int et = threadIdx.x >> 4, er = threadIdx.x & 15;    // token et, row er
    const int row = strip * 16 + er;
    float np_ = 0.f;
    if (et < B) {
      // independent loads first: history, taps, attention output, old partial; then the expert rows
      const bf16* hb = c.hm + ((long)ap.slot * MAXB + et) * 3 * H + row;
      const float x1 = ldcg_bf(hb + ((t + 2) % 3) * H), x2 = ldcg_bf(hb + ((t + 1) % 3) * H), x3 = ldcg_bf(hb + (t % 3) * H);
      const uint2 tw = *reinterpret_cast<const uint2*>(L.mlp_sc + row * 4);
      const uint2 ra = ld_tag(c.attst + (long)(par * MAXB + et) * NPAIR + row / 2);
      const uint2 rp = ld_tag(c.pbt + ((long)(addp ? ap.pin : 0) * MAXB + et) * NPAIR + row / 2);
      uint2 rk[TOPK];
      const uint2* src = c.w2ct + ((long)(par * MAXB + et) * TOPK) * H + row;
#pragma unroll
      for (int k = 0; k < TOPK; k++) rk[k] = ld_tag(src + (long)k * H);
      float s = 0.f;
#if (BPX >> 7) & 1
      wait_all<TOPK>([&](int i) { return src + (long)i * H; }, rk, TAGA(a));
#endif
#pragma unroll
      for (int k = 0; k < TOPK; k++) s += __uint_as_float(wait_tag(src + (long)k * H, rk[k], TAGA(a)));
      const float x = rbf(s);
      const bf16* w4 = reinterpret_cast<const bf16*>(&tw);
      float acc = __fmul_rn(x3, bf(w4[0]));
      acc = __fadd_rn(acc, __fmul_rn(x2, bf(w4[1])));
      acc = __fadd_rn(acc, __fmul_rn(x1, bf(w4[2])));
      acc = __fadd_rn(acc, __fmul_rn(x, bf(w4[3])));
      const float ms = rbf(__fmul_rn(__fadd_rn(acc, x), 0.44721359549995793f));
      c.hm[((long)ap.slot * MAXB + et) * 3 * H + (t % 3) * H + row] = tobf(x);
      const uint32_t av = wait_tag(c.attst + (long)(par * MAXB + et) * NPAIR + row / 2, ra, TAGA(a));
      const float as = (row & 1) ? bf_hi(av) : bf_lo(av);
      if (!addp) np_ = as + ms;
      else {
        const uint32_t pv = wait_tag(c.pbt + ((long)ap.pin * MAXB + et) * NPAIR + row / 2, rp, TAGP(ap.pin));
        np_ = (((row & 1) ? bf_hi(pv) : bf_lo(pv)) + as) + ms;
      }
    }
    const float other = __shfl_down_sync(0xffffffff, np_, 1);
    if (et < B && (er & 1) == 0) st_tag(c.pbt + ((long)ap.out * MAXB + et) * NPAIR + row / 2, pack_bf2(np_, other), TAGP(ap.out));
  }
}

#ifndef SKH
#define SKH 0
#endif
#ifndef SK_UNR
#define SK_UNR 12
#endif
__device__ __forceinline__ void mma_s8(int* d, uint4 a, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+r"(d[0]), "+r"(d[1]), "+r"(d[2]), "+r"(d[3]) : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float wmaxf(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v = fmaxf(v, __shfl_xor_sync(0xffffffff, v, o));
  return v;
}
__device__ __forceinline__ unsigned fsort(float z) { unsigned u = __float_as_uint(z); return (u & 0x80000000u) ? ~u : (u | 0x80000000u); }
__device__ __forceinline__ float funsort(unsigned u) { return __uint_as_float((u & 0x80000000u) ? (u & 0x7fffffffu) : ~u); }
// exact strip (the track-A arithmetic) -> argmax keys
__device__ __forceinline__ void head_exact_strip(const Ctx& c, const Hdr& hd, Smem& sm, int it, unsigned long long* best) {
  const int B = HDB, lane = lane_id(), g = lane >> 2, t = lane & 3;
  BSm bl{&sm.u.xs[0][0][0], HP, B};
  float acc[4] = {0.f, 0.f, 0.f, 0.f};
#if W12U
  piece_w12(c.unembed + (long)it * W12_STRIP, c.u12base + (long)it * 16, bl, acc);
#else
  piece_bf16(c.unembed + (long)it * 36 * 2048, 0, 36, bl, acc);
#endif
  for (int h = 0; h < 2; h++) {
    const int row = it * 16 + g + 8 * h;
    for (int cc = 0; cc < 2; cc++) {
      const int tok = 2 * t + cc;
      if (tok >= B || row >= VOCAB_REAL) continue;
      const float z = 30.0f * tanhf(acc[2 * h + cc] / 30.0f);
      if (hd.logits) hd.logits[(long)tok * VOCAB_REAL + row] = z;
      const unsigned long long key = ((unsigned long long)fsort(z) << 32) | (unsigned)(0xFFFFFFFFu - row);
      if (key > best[cc]) best[cc] = key;
    }
  }
}

// final: output mix -> norm -> unembed -> logits, argmax
__device__ NI_FINAL void ph_final(PH_ARGS, int part) {
  const int B = HDB;
#if SKH
  if (part == 1) {   // ---- sketch, part 2 (after a grid barrier): exact recompute of the candidate strips
    const int w = threadIdx.x >> 5, lane = lane_id(), t = lane & 3;
    unsigned long long best[2] = {0ull, 0ull};
    float L[2];
    for (int cc = 0; cc < 2; cc++) {
      const int tok = 2 * t + cc;
      L[cc] = (tok < B) ? funsort(ld_relaxed_gpu(c.skl + tok)) : INFINITY;
      if (blockIdx.x == 0 && w == 0 && (lane >> 2) == 0 && tok < B && c.skl) c.skl[16 + tok] = __float_as_uint(L[cc]);
    }
    if (threadIdx.x == 0) sm.nskc = 0;
    __syncthreads();
    int ns = 0;
    for (int it = blockIdx.x + gridDim.x * w; it < UN_STRIPS; it += gridDim.x * NWARP, ns++) {
      bool cand = false;
      for (int cc = 0; cc < 2; cc++) {
        const int tok = 2 * t + cc;
        if (tok >= B) continue;
        const float u = ns < 4 ? sm.sku[w * 4 + ns][tok] : INFINITY;
        // a row can win (or tie and win on its index) only if 30 tanh(z / 30) of its exact value reaches that of the
        // best lower bound L; z <= u and tanh is monotone: compare the capped bounds, 8e-6 (4 ulp at 30) of slack
        const float tl = 30.0f * tanhf(L[cc] / 30.0f) - 8e-6f;
        if (!(30.0f * tanhf(u / 30.0f) < tl)) cand = true;   // (NaN: exact)
      }
      if (__any_sync(0xffffffff, cand) && lane == 0) { const int q = atomicAdd(&sm.nskc, 1); sm.skc[q] = it; }
    }
    __syncthreads();
    // exact recompute of each candidate strip: staged into shared memory by all threads in one round of loads, then the
    // track-A MMA chain (same operands, same order) by warp 0 -> bit-identical keys
    const int ncand = sm.nskc;
    uint8_t* stg = reinterpret_cast<uint8_t*>(&sm.u.xs[1][0][0]);   // 73984 B >= 73728
    for (int q = 0; q < ncand; q++) {
      const int it = sm.skc[q];
      if (c.skl && threadIdx.x == 0) atomicAdd(c.skl + 15, 1u);   // statistics: exact strips
      const uint8_t* src = c.unembed + (long)it * 36 * 2048;
      for (int k = threadIdx.x; k < 36 * 2048 / 16; k += NTH)
        *reinterpret_cast<uint4*>(stg + k * 16) = ldg_nc(src + (long)k * 16);
      __syncthreads();
      if (w == 0) {
        BSm bl{&sm.u.xs[0][0][0], HP, B};
        float acc[4] = {0.f, 0.f, 0.f, 0.f};
        const uint32_t sb = (uint32_t)__cvta_generic_to_shared(stg) + lane * 16;
#pragma unroll 4
        for (int u = 0; u < 36; u++) {
#pragma unroll
          for (int qq = 0; qq < 4; qq++) {
            uint4 wv;
            asm volatile("ld.shared.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(wv.x), "=r"(wv.y), "=r"(wv.z), "=r"(wv.w) : "r"(sb + (u * 4 + qq) * 512));
            const uint2 bb = bl.get(u * 64 + qq * 16);
            mma_bf16(acc, wv.x, wv.y, wv.z, wv.w, bb.x, bb.y);
          }
        }
        const int g = lane >> 2;
        for (int h = 0; h < 2; h++) {
          const int row = it * 16 + g + 8 * h;
          for (int cc = 0; cc < 2; cc++) {
            const int tok = 2 * t + cc;
            if (tok >= B || row >= VOCAB_REAL) continue;
            const float z = 30.0f * tanhf(acc[2 * h + cc] / 30.0f);
            const unsigned long long key = ((unsigned long long)fsort(z) << 32) | (unsigned)(0xFFFFFFFFu - row);
            if (key > best[cc]) best[cc] = key;
          }
        }
      }
      __syncthreads();
    }
    for (int cc = 0; cc < 2; cc++) {
      unsigned long long k = best[cc];
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) { const unsigned long long ok = __shfl_xor_sync(0xffffffff, k, o); if (ok > k) k = ok; }
      const int tok = 2 * t + cc;
      if ((lane >> 2) == 0 && tok < B && k) atomicMax(c.amax + tok, k);
    }
    return;
  }
#endif
  for (int b = 0; b < B; b++) {
    float v[5][EPT], x[1][EPT];
    const int idx[5] = {c.fin[0], c.fin[1], c.fin[2], c.fin[3], c.fin_pin};
    const unsigned msk = ((1u << c.nfin) - 1u) | 16u;
    load_srcs<5>(c, hd, idx, msk, b, v);
    const float* qs[1] = {c.oq};
    depth_mix<5, 1>(v, msk, qs, 1, x, sm);
    rmsnorm_store(x[0], c.fnorm, &sm.u.xs[0][b][0], sm);
  }
  __syncthreads();
  const int w = threadIdx.x >> 5, lane = lane_id(), g = lane >> 2, t = lane & 3;
  unsigned long long best[2] = {0ull, 0ull};
#if SKH
  if (!hd.logits) {
    // ---- track B: certified int8 sketch. x = sigma (d1 + d2 / 254) with int8 digits; s_i q_i ~ w_i (int8 per row).
    // |z_i - s_i sigma (q.d1 + q.d2 / 254)| <= e_i |x^| + n_i |x - x^|; the track-A fp32 sum adds <= 2.75e-4 n_i |x|.
    int8_t* dig = reinterpret_cast<int8_t*>(&sm.u.xs[1][0][0]);   // [MAXB][2][HP2]
    constexpr int HP2 = 2 * HP;
    for (int b = 0; b < B; b++) {
      float mx = 0.f, ss = 0.f;
      for (int k = threadIdx.x; k < H; k += NTH) { const float v = bf(sm.u.xs[0][b][k]); mx = fmaxf(mx, fabsf(v)); ss = fmaf(v, v, ss); }
      mx = wmaxf(mx);
      __syncthreads();
      if (lane == 0) sm.skwm[w] = mx;
      float v2[1] = {ss};
      block_sum<1>(v2, sm);   // (syncs; sm.bcast[32..] untouched)
      float m2 = 0.f;
      for (int q = 0; q < NWARP; q++) m2 = fmaxf(m2, sm.skwm[q]);
      // sigma = max|x| / 127 rounded up so that |x / sigma| <= 127 and no digit clamps
      const float sig = m2 > 0.f ? __uint_as_float(__float_as_uint(m2 / 127.0f) + 2u) : 1.0f;
      if (threadIdx.x == 0) { sm.sksig[b] = sig; sm.skxn[b] = sqrtf(v2[0]) * 1.00001f + 1e-30f; }
      for (int k = threadIdx.x; k < H; k += NTH) {
        const float y = bf(sm.u.xs[0][b][k]) / sig;
        const float d1 = fminf(fmaxf(rintf(y), -127.f), 127.f);
        const float d2 = fminf(fmaxf(rintf((y - d1) * 254.0f), -127.f), 127.f);
        dig[(b * 2 + 0) * HP2 + k] = (int8_t)d1; dig[(b * 2 + 1) * HP2 + k] = (int8_t)d2;
      }
      __syncthreads();
    }
    for (int b = B; b < MAXB && threadIdx.x == 0; b++) { sm.sksig[b] = 0.f; sm.skxn[b] = 0.f; }
    __syncthreads();
    float lmax[2] = {-INFINITY, -INFINITY};
    int ns = 0;
    for (int it = blockIdx.x + gridDim.x * w; it < UN_STRIPS; it += gridDim.x * NWARP, ns++) {
      int a1[4] = {0, 0, 0, 0}, a2[4] = {0, 0, 0, 0};
      const uint8_t* qp = c.skq + (long)it * 72 * 512 + lane * 16;
      const int8_t* d1p = dig + (g * 2 + 0) * HP2 + 4 * t;
      const int8_t* d2p = dig + (g * 2 + 1) * HP2 + 4 * t;
      const bool gok = g < B;
#pragma unroll 1
      for (int kk = 0; kk < 72; kk += SK_UNR) {
        uint4 q[SK_UNR];
#pragma unroll
        for (int j = 0; j < SK_UNR; j++) q[j] = ldg_nc(qp + (long)(kk + j) * 512);
#pragma unroll
        for (int j = 0; j < SK_UNR; j++) {
          const int k0 = (kk + j) * 32;
          const uint32_t b10 = gok ? *reinterpret_cast<const uint32_t*>(d1p + k0) : 0u, b11 = gok ? *reinterpret_cast<const uint32_t*>(d1p + k0 + 16) : 0u;
          const uint32_t b20 = gok ? *reinterpret_cast<const uint32_t*>(d2p + k0) : 0u, b21 = gok ? *reinterpret_cast<const uint32_t*>(d2p + k0 + 16) : 0u;
          mma_s8(a1, q[j], b10, b11); mma_s8(a2, q[j], b20, b21);
        }
      }
      float up[2] = {-INFINITY, -INFINITY};
      for (int h = 0; h < 2; h++) {
        const int row = it * 16 + g + 8 * h;
        const float sr = __ldg(c.sks + row), er = __ldg(c.ske + row), nr = __ldg(c.skn + row);
        for (int cc = 0; cc < 2; cc++) {
          const int tok = 2 * t + cc;
          if (tok >= B || row >= VOCAB_REAL) continue;
          const float sig = sm.sksig[tok], xn = sm.skxn[tok];
          const float dx = 48.0f * sig * (1.0f / 508.0f + 1e-5f);
          const float S = (float)a1[2 * h + cc] + (float)a2[2 * h + cc] * (1.0f / 254.0f);
          const float av = sr * sig * S;
          const float E = (er * (xn + dx) + nr * dx + 2.75e-4f * nr * xn + 1e-6f * fabsf(av) + 1e-6f) * 1.01f;
          up[cc] = fmaxf(up[cc], av + E);
          lmax[cc] = fmaxf(lmax[cc], av - E);
        }
      }
#pragma unroll
      for (int cc = 0; cc < 2; cc++) {
#pragma unroll
        for (int o = 4; o < 32; o <<= 1) up[cc] = fmaxf(up[cc], __shfl_xor_sync(0xffffffff, up[cc], o));
        if (g == 0 && 2 * t + cc < MAXB && ns < 4) sm.sku[w * 4 + ns][2 * t + cc] = up[cc];
      }
    }
#pragma unroll
    for (int cc = 0; cc < 2; cc++) {
      float l = lmax[cc];
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) l = fmaxf(l, __shfl_xor_sync(0xffffffff, l, o));
      const int tok = 2 * t + cc;
      if (g == 0 && tok < B && l > -INFINITY) atomicMax(c.skl + tok, fsort(l));
    }
    return;   // part 2 after the grid barrier
  } else
#endif
  {
  for (int it = blockIdx.x + gridDim.x * w; it < UN_STRIPS; it += gridDim.x * NWARP) {
    BSm bl{&sm.u.xs[0][0][0], HP, B};
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
#if W12U
    piece_w12(c.unembed + (long)it * W12_STRIP, c.u12base + (long)it * 16, bl, acc);
#else
    piece_bf16(c.unembed + (long)it * 36 * 2048, 0, 36, bl, acc);
#endif
    for (int h = 0; h < 2; h++) {
      const int row = it * 16 + g + 8 * h;
      for (int cc = 0; cc < 2; cc++) {
        const int tok = 2 * t + cc;
        if (tok >= B || row >= VOCAB_REAL) continue;
        const float z = 30.0f * tanhf(acc[2 * h + cc] / 30.0f);
        if (hd.logits) hd.logits[(long)tok * VOCAB_REAL + row] = z;
        unsigned u = __float_as_uint(z);
        u = (u & 0x80000000u) ? ~u : (u | 0x80000000u);
        const unsigned long long key = ((unsigned long long)u << 32) | (unsigned)(0xFFFFFFFFu - row);
        if (key > best[cc]) best[cc] = key;
      }
    }
  }
  }
  for (int cc = 0; cc < 2; cc++) {
    unsigned long long k = best[cc];
#pragma unroll
    for (int o = 4; o < 32; o <<= 1) { const unsigned long long ok = __shfl_xor_sync(0xffffffff, k, o); if (ok > k) k = ok; }
    const int tok = 2 * t + cc;
    if (g == 0 && tok < B && k) atomicMax(c.amax + tok, k);
  }
}

// ------------------------------------------------------------------------------------------------ kernel
// track B (L0T) table build: application 0's attention input and qkv GEMV for HDB token ids, rows into c.l0t
extern "C" __global__ void __launch_bounds__(NTH, 1) mk_l0b(const Ctx* __restrict__ cp, Hdr hd) {
  extern __shared__ __align__(16) unsigned char smraw[];
  Smem& sm = *reinterpret_cast<Smem*>(smraw);
  const Ctx& c = *cp;
  const int ns = ph_attn_in(c, hd, sm, 0);
  ph_qkv<true>(c, hd, sm, 0, ns);
}
extern "C" __global__ void __launch_bounds__(NTH, 1) mk_step(const Ctx* __restrict__ cp, Hdr hd0) {
  extern __shared__ __align__(16) unsigned char smraw[];
  Smem& sm = *reinterpret_cast<Smem*>(smraw);
  const Ctx& c = *cp;
  unsigned nbar = 0;
  const unsigned base = c.bar[1];
#if S6
  for (int i = threadIdx.x; i < 4096; i += NTH) sm.s6tab[i] = cvt_e4m3x2((uint32_t)(((S6_BASE + (i >> 6)) << 8) | (S6_BASE + (i & 63))));
  __syncthreads();
#endif
#if GDPF
  if (threadIdx.x == 0) { mbar_init(smaddr(&sm.gdbar), 1); sm.gdph = 0; asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory"); }
  __syncthreads();
#endif
  MKPROF_DECL(pn);
  MkProf P{(unsigned long long*)c.prof, 4096};
#define MARK(tag) do { if (c.prof && threadIdx.x == 0) MKPROF_MARK(P, pn, tag); } while (0)
#ifdef USE_BAR
#define GBAR() do { MARK(MKPROF_WAIT); grid_bar(c, nbar, base); } while (0)
#else
#define GBAR() do { __syncthreads(); } while (0)
#endif
  const int nst = hd0.nsteps > 0 ? hd0.nsteps : 1;
  for (int st = 0; st < nst; st++) {
  Hdr hd = hd0;
  if (hd0.nsteps > 0) {   // device loop: step st at position pos + st, its own tag range, token from the prompt or fed back
    hd.pos = hd0.pos + st;
    hd.tag0 = (hd0.tag0 + 64u * st) & 0x7fffffffu;
    hd.tokens = st < hd0.plen ? hd0.prompt + st * hd0.B : nullptr;
    hd.tok_tag = (hd0.tag0 + 64u * (st - 1) + 60u) & 0x7fffffffu;
    hd.out_tok = (hd0.out_tok && st >= hd0.plen - 1) ? hd0.out_tok + (long)(st - (hd0.plen - 1)) * MAXB : nullptr;
    hd.logits = nullptr;
  }
  MARK(MKPROF_STEP);
#ifdef MKPROF
  if (threadIdx.x == 0) sm.subn = 0;
#endif
  for (int a = 0; a < NAPP; a++) {
    const App& ap = c.A[a];
    MARK(1);
#if ATL2 == 2
    attn_pf(c, hd, a);   // at the start of the application (the input mix is latency-bound)
#endif
#if L0T
    if (a == 0 && c.l0t) {
#if ATL2 == 1
      attn_pf(c, hd, a);
#endif
      l0t_app0(c, hd, sm); GBAR(); MARK(2); goto attn; }
#endif
    {
    int ns = ph_attn_in(c, hd, sm, a);
    if (ns < 0) {
#if MSGZ
#if MSGZ_PIPE
      // pass start: layers 0 and 1; application l: layer l + 1 (one item per block on the highest blocks)
      { GBAR(); MARK(18); const int a0 = a - ap.loopl; if (ap.loopl == 0) ph_msgz(c, hd, sm, a0, 0, 2); else if (ap.loopl < 11) ph_msgz(c, hd, sm, a0, ap.loopl + 1, ap.loopl + 2); }
#else
      if (ap.loopl == 0) { GBAR(); MARK(18); ph_msgz(c, hd, sm, a, 0, 12); }
#endif
#endif
      GBAR(); MARK(7);
#if GLIN && !MSGZ
      ph_gate_lin(c, hd, sm, a);
#else
      ph_gate_d(c, hd, sm, a, 0, 3);
#endif
      GBAR(); MARK(8);
      ph_gate_fg(c, hd, sm, a, 0, 3);
      GBAR(); MARK(9);
      const LayerW& L = c.L[ap.layer];
      float wv[3][EPT];
      for (int q = 0; q < 3; q++) load_w(L.norm[L.glob ? q : 0], wv[q]);
      const bool bc = HDB >= 2;
      for (int b = bc ? (int)blockIdx.x : 0; b < HDB; b += bc ? (int)gridDim.x : 1) {
        float x[3][EPT];
        uint2 r[3][EPT];
        const uint2* p0 = c.xpt + ((long)((a & 1) * MAXB + b) * 4) * H;
#pragma unroll
        for (int q = 0; q < 3; q++)
#pragma unroll
          for (int k = 0; k < EPT; k++) r[q][k] = ld_tag(p0 + q * H + (EV(k) ? EL(k) : EL(k & 1)));
#if BPG
        // track A (BPG): the block arrives before the F/G results; waiting word by word costs one load round trip per
        // word after they are there. Reload the whole set together until every valid word carries the tag
        // (unconditional loads at clamped addresses: the words stay in registers)
        for (;;) {
          bool ok = true;
#pragma unroll
          for (int q = 0; q < 3; q++)
#pragma unroll
            for (int k = 0; k < EPT; k++) ok &= !EV(k) || r[q][k].y == TAGA(a);
          if (ok) break;
#pragma unroll
          for (int q = 0; q < 3; q++)
#pragma unroll
            for (int k = 0; k < EPT; k++) r[q][k] = ld_tag_r(p0 + q * H + (EV(k) ? EL(k) : EL(k & 1)));
        }
#pragma unroll
        for (int q = 0; q < 3; q++)
#pragma unroll
          for (int k = 0; k < EPT; k++) x[q][k] = EV(k) ? __uint_as_float(r[q][k].x) : 0.f;
#else
#pragma unroll
        for (int q = 0; q < 3; q++)
#pragma unroll
          for (int k = 0; k < EPT; k++) x[q][k] = EV(k) ? __uint_as_float(wait_tag(p0 + q * H + EL(k), r[q][k], TAGA(a))) : 0.f;
#endif
        if (bc) {
          uint2* xs_pub = c.xst + (long)(a & 1) * 3 * MAXB * NPAIR;
          uint2* dst[3] = {xs_pub + (long)b * NPAIR, xs_pub + (long)(MAXB + b) * NPAIR, xs_pub + (long)(2 * MAXB + b) * NPAIR};
          norm_publish<3>(x, wv, 3, dst, TAGA(a), sm);
        } else {
          bf16* dst[3] = {&sm.u.xs[0][b][0], &sm.u.xs[1][b][0], &sm.u.xs[2][b][0]};
          rmsnorm_store_n<3>(x, wv, 3, dst, sm);
        }
      }
      if (bc) {
        const uint2* xs_pub = c.xst + (long)(a & 1) * 3 * MAXB * NPAIR;
        for (int q = 0; q < 3; q++)
          poll_rows(xs_pub + (long)q * MAXB * NPAIR, HDB, [&](int r) { return &sm.u.xs[q][r][0]; }, TAGA(a));
      }
      __syncthreads();
      ns = 3;
    }
    MARK(10);
#if ATL2 == 1
    attn_pf(c, hd, a);
#endif
    ph_qkv(c, hd, sm, a, ns);
    GBAR(); MARK(2);
    }
#if L0T
    attn:
#endif
#if ATT2
    ph_attn2(c, hd, sm, a);
#else
    ph_attn(c, hd, sm, a);
#endif
    GBAR(); MARK(3);
    ph_oproj(c, hd, sm, a);
    GBAR(); MARK(4);
    int r = ph_mlp_in(c, hd, sm, a);
    if (r < 0) {
      GBAR(); MARK(14);
#if GLIN >= 2 && !MSGZ
      ph_mgate_lin(c, hd, sm, a);
#else
      ph_gate_d(c, hd, sm, a, 3, 1);
#endif
      GBAR(); MARK(15);
      ph_gate_fg(c, hd, sm, a, 3, 1);
      GBAR(); MARK(16);
      if (HDB >= 2) {
        for (int b = blockIdx.x; b < HDB; b += gridDim.x) {
          float x[1][EPT];
          load_vec_f(c.xpt + ((long)((a & 1) * MAXB + b) * 4 + 3) * H, TAGA(a), x[0]);
          mlp_publish(c, hd, sm, a, x, b);
        }
        mlp_poll(c, hd, sm, a);
      } else {
        for (int b = 0; b < HDB; b++) {
          float x[1][EPT];
          load_vec_f(c.xpt + ((long)((a & 1) * MAXB + b) * 4 + 3) * H, TAGA(a), x[0]);
          mlp_in_x(c, hd, sm, a, x, b);
        }
      }
      __syncthreads();
    }
    MARK(11);
    ph_router(c, hd, sm, a);
    GBAR(); MARK(5);
    routing(c, hd, sm, a);
    MARK(12);
    ph_w13(c, hd, sm, a);
    GBAR(); MARK(6);
    ph_w2a(c, hd, sm, a);
    GBAR(); MARK(17);
    ph_w2b(c, hd, sm, a);
    GBAR();
  }
  MARK(13);
  ph_final(c, hd, sm, 0);
#if SKH
  if (!hd.logits) { MARK(19); grid_bar(c, nbar, base); MARK(20); ph_final(c, hd, sm, 1); }
#endif
  MARK(MKPROF_WAIT);
  grid_bar(c, nbar, base);
  if (blockIdx.x == 0) {
    if (threadIdx.x < HDB) {
      const unsigned long long k = c.amax[threadIdx.x];
      const int tok = (int)(0xFFFFFFFFu - (unsigned)(k & 0xFFFFFFFFu));
      c.next_tok[threadIdx.x] = tok;
      c.amax[threadIdx.x] = 0ull;
#if SKH
      if (c.skl) { c.skl[threadIdx.x] = 0u; }
#endif
      st_tag(c.ntt + threadIdx.x, (uint32_t)tok, (hd.tag0 + 60u) & 0x7fffffffu);
      if (hd.out_tok) hd.out_tok[threadIdx.x] = tok + 1;   // 0 = not yet written (host polls)
    }
  }
  }   // steps
  if (blockIdx.x == 0 && threadIdx.x == 0) c.bar[1] = base + nbar * gridDim.x;

}

// ------------------------------------------------------------------------------------------------ host API
extern "C" {
int mk_ctx_bytes() { return (int)sizeof(Ctx); }
int mk_layer_bytes() { return (int)sizeof(LayerW); }
int mk_app_bytes() { return (int)sizeof(App); }
int mk_hdr_bytes() { return (int)sizeof(Hdr); }
int mk_smem_bytes() { return (int)sizeof(Smem); }
int mk_maxctx() { return MAXCH * 64; }   // B <= 2: 64-key attention records, MAXCH of them per (token, head)
int mk_kb1() { return KBF; }
int mk_fp4_ub() { return FP4_UB; }
int mk_nth() { return NTH; }
int mk_cn_total() { return CN_TOTAL; }
int mk_setup() {
  cudaError_t e = cudaFuncSetAttribute(mk_step, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)sizeof(Smem));
  if (e != cudaSuccess) { fprintf(stderr, "mk_setup: %s\n", cudaGetErrorString(e)); return 1; }
  int nb = 0;
  cudaOccupancyMaxActiveBlocksPerMultiprocessor(&nb, mk_step, NTH, sizeof(Smem));
  if (nb < 1) { fprintf(stderr, "mk_setup: occupancy %d\n", nb); return 2; }
  return 0;
}
// track A (L2P): an L2 access-policy window (persisting) over the arena of small latency-critical weights
static cudaAccessPolicyWindow g_win;
static int g_win_on = 0;
long long mk_l2_window(void* p, long long n) {
  int dev = 0, maxp = 0, maxw = 0;
  cudaGetDevice(&dev);
  cudaDeviceGetAttribute(&maxp, cudaDevAttrMaxPersistingL2CacheSize, dev);
  cudaDeviceGetAttribute(&maxw, cudaDevAttrMaxAccessPolicyWindowSize, dev);
  if (maxp <= 0 || maxw <= 0 || n <= 0) return -1;
  const size_t nb = (size_t)n < (size_t)maxw ? (size_t)n : (size_t)maxw;
  const size_t aside = nb < (size_t)maxp ? nb : (size_t)maxp;
  if (cudaDeviceSetLimit(cudaLimitPersistingL2CacheSize, aside) != cudaSuccess) return -2;
  g_win.base_ptr = p; g_win.num_bytes = nb;
  g_win.hitRatio = (float)aside / (float)nb;
  g_win.hitProp = cudaAccessPropertyPersisting; g_win.missProp = cudaAccessPropertyStreaming;
  g_win_on = 1;
  return ((long long)maxp << 32) | (unsigned)(aside >> 10);   // max persisting bytes | set-aside KB
}
int mk_l2_reset() { return (int)cudaCtxResetPersistingL2Cache(); }
int mk_launch(const void* ctx_dev, const Hdr* hd, int nblk, void* stream) {
  Hdr h = *hd;
  if (KBN && h.B < 2) { fprintf(stderr, "mk_launch: B >= 2 kernel launched with B = %d\n", h.B); return 2; }
  if (KBF && h.B != KBF) { fprintf(stderr, "mk_launch: batch-%d kernel launched with B = %d\n", KBF, h.B); return 2; }
  void* args[] = {(void*)&ctx_dev, (void*)&h};
  cudaError_t e;
  if (g_win_on) {
    cudaLaunchAttribute at[2];
    at[0].id = cudaLaunchAttributeCooperative; at[0].val.cooperative = 1;
    at[1].id = cudaLaunchAttributeAccessPolicyWindow; at[1].val.accessPolicyWindow = g_win;
    cudaLaunchConfig_t cfg = {};
    cfg.gridDim = dim3(nblk); cfg.blockDim = dim3(NTH); cfg.dynamicSmemBytes = sizeof(Smem); cfg.stream = (cudaStream_t)stream;
    cfg.attrs = at; cfg.numAttrs = 2;
    e = cudaLaunchKernelExC(&cfg, (const void*)mk_step, args);
  } else
    e = cudaLaunchCooperativeKernel((const void*)mk_step, dim3(nblk), dim3(NTH), args, sizeof(Smem), (cudaStream_t)stream);
  if (e != cudaSuccess) { fprintf(stderr, "mk_launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}
int mk_l0b_launch(const void* ctx_dev, const Hdr* hd, int nblk, void* stream) {
  Hdr h = *hd;
  void* args[] = {(void*)&ctx_dev, (void*)&h};
  static bool init = false;
  if (!init) { cudaFuncSetAttribute((const void*)mk_l0b, cudaFuncAttributeMaxDynamicSharedMemorySize, sizeof(Smem)); init = true; }
  cudaError_t e = cudaLaunchCooperativeKernel((const void*)mk_l0b, dim3(nblk), dim3(NTH), args, sizeof(Smem), (cudaStream_t)stream);
  if (e != cudaSuccess) { fprintf(stderr, "mk_l0b_launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}
void* mk_host_alloc(size_t n) { void* p = nullptr; if (cudaHostAlloc(&p, n, cudaHostAllocMapped) != cudaSuccess) return nullptr; memset(p, 0, n); return p; }
}
