"""Inkling-2-Mini decode engine: one persistent CUDA kernel per call (engine/mk.cu), weights re-laid at load time.

    Engine(model_dir, max_batch, max_context)
    reset()                      forget every sequence
    step(tokens[B] int64 cuda)   append one token per sequence, return next-token logits [B, 200058] float32
    generate(tokens, n_steps)    greedy decode on the device
    close(), stats()
"""

import ctypes
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pack import tile_bf16, tile_mxfp8, tile_nvfp4  # noqa: E402

H, NL, MAXB, QKVW, VOCAB = 2304, 24, 8, 542 * 16, 200058
NAPP, NSLOT, MAXCH, CH = 48, 48, 64, 64
PREFIX = "model.llm."
LAYER_FIELDS = ["wqkv", "wo", "wr", "rbias", "w13c", "w13s", "w2c", "w2s", "f13", "f2", "mx", "glob", "loop",
                "nq", "nk", "nv", "nm", "ksc", "vsc", "asc", "msc", "qscale", "rscale", "relp", "aq", "mq",
                "cD", "cF", "cG", "nrt", "pad0", "pad1"]
GLOBAL_FIELDS = ["embed", "embed_norm", "oq", "fnorm", "unembed", "lq", "vecs", "qkvo", "attn_out", "attn_s", "act",
                 "rlog", "zb", "xg", "msg", "msgir", "apart", "acnt", "kc", "vc", "rk", "rv", "ro", "rm", "bar",
                 "amv", "ami", "maxctx", "pad0", "pad1", "pad2", "pad3", "pad4"]


def _lib_path():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.environ.get("MK_LIB", os.path.join(here, "build", "libmk.so"))


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        assert 1 <= max_batch <= MAXB, "max_batch must be 1..8"
        self.max_batch = max_batch
        self.max_context = int(max_context)
        if self.max_context > MAXCH * CH:
            raise ValueError(f"max_context {max_context} > {MAXCH * CH}")
        self.dev = torch.device("cuda")
        self.lib = ctypes.CDLL(_lib_path())
        self.lib.mk_create.restype = ctypes.c_void_p
        self.lib.mk_run.argtypes = [ctypes.c_void_p] * 4 + [ctypes.c_int] * 5 + [ctypes.c_void_p]
        assert self.lib.mk_layer_size() == 8 * len(LAYER_FIELDS)
        assert self.lib.mk_params_size() == 8 * (NL * len(LAYER_FIELDS) + len(GLOBAL_FIELDS))
        self.keep = []
        cfg = json.load(open(os.path.join(model_dir, "config.json")))["text_config"]
        self.local = set(cfg["local_layer_ids"])
        self._load(model_dir)
        self._alloc()
        blob = np.array(self.fields, dtype=np.uint64)
        self.blob = blob
        self.h = self.lib.mk_create(blob.ctypes.data_as(ctypes.c_void_p))
        assert self.h, "mk_create failed"
        self.stream = torch.cuda.current_stream().cuda_stream
        self.reset()

    # ------------------------------------------------------------------------------------------ loading
    def _ptr(self, t):
        if t is None:
            return 0
        t = t.contiguous()
        self.keep.append(t)
        return t.data_ptr()

    def _load(self, model_dir):
        from safetensors import safe_open
        index = json.load(open(os.path.join(model_dir, "model.safetensors.index.json")))["weight_map"]
        files = sorted(set(v for k, v in index.items() if k.startswith(PREFIX)))
        handles = [safe_open(os.path.join(model_dir, fn), framework="pt", device="cuda") for fn in files]
        where = {}
        for hd in handles:
            for k in hd.keys():
                if k.startswith(PREFIX):
                    where[k[len(PREFIX):]] = hd

        def get(name):
            return where[name].get_tensor(PREFIX + name)

        bf = torch.bfloat16
        layer_vals = []
        for i in range(NL):
            p = f"layers.{i}."
            glob = i not in self.local
            loop = 6 <= i < 18
            a = p + "attn."
            sink = torch.zeros(32, H, dtype=bf, device=self.dev)
            sink[:24] = get(a + "attn_sink_proj.weight")
            rows = [get(a + "wq_du.weight"), get(a + "wr_du.weight"), get(a + "gate_attn.weight"), sink, get(a + "wk_dv.weight")]
            if glob:
                kp = torch.zeros(32, H, dtype=bf, device=self.dev); kp[:32] = get(a + "k_sconv.weight_proj")
                vp = torch.zeros(32, H, dtype=bf, device=self.dev); vp[:32] = get(a + "v_sconv.weight_proj")
                rows += [kp, get(a + "wv_dv.weight"), vp]
            else:
                rows += [get(a + "wv_dv.weight")]
            wqkv = torch.cat(rows, 0)
            nrt = wqkv.shape[0] // 16
            assert nrt == (542 if glob else 538)
            v = {"wqkv": tile_bf16(wqkv), "nrt": nrt}
            del wqkv, rows
            v["wo"] = tile_bf16(get(a + "wo_ud.weight"))
            v["wr"] = tile_bf16(get(p + "mlp.gate.weight"))
            v["rbias"] = get(p + "mlp.gate.bias").float()
            e = p + "mlp.experts."
            w13, w2 = get(e + "w13_weight"), get(e + "w2_weight")
            if w13.dtype == torch.uint8:
                v["mx"] = 0
                v["w13c"], v["w13s"] = tile_nvfp4(w13, get(e + "w13_weight_scale"))
                v["w2c"], v["w2s"] = tile_nvfp4(w2, get(e + "w2_weight_scale"))
                v["f13"] = (get(e + "w13_weight_amax").float() / get(e + "w13_weight_outer_scale_denominator").float()).contiguous()
                v["f2"] = (get(e + "w2_weight_amax").float() / get(e + "w2_weight_outer_scale_denominator").float()).contiguous()
            else:
                v["mx"] = 1
                s13, s2 = get(e + "w13_weight_scale"), get(e + "w2_weight_scale")
                assert int(s13.view(torch.uint8).max()) <= 142 and int(s2.view(torch.uint8).max()) <= 142
                v["w13c"], v["w13s"] = tile_mxfp8(w13, s13)
                v["w2c"], v["w2s"] = tile_mxfp8(w2, s2)
                v["f13"] = v["f2"] = None
            del w13, w2
            v["glob"] = int(glob)
            v["loop"] = int(loop)
            if glob:
                v["nq"], v["nk"], v["nv"] = get(p + "q_input_norm.weight"), get(p + "k_input_norm.weight"), get(p + "v_input_norm.weight")
                v["ksc"], v["vsc"] = get(a + "k_sconv.static_w"), get(a + "v_sconv.static_w")
            else:
                n = get(p + "attn_norm.weight")
                v["nq"] = v["nk"] = v["nv"] = n
                v["ksc"], v["vsc"] = get(a + "k_sconv.weight").reshape(-1, 4), get(a + "v_sconv.weight").reshape(-1, 4)
            v["nm"] = get(p + "mlp_norm.weight")
            v["asc"] = get(p + "attn_sconv.weight").reshape(-1, 4)
            v["msc"] = get(p + "mlp_sconv.weight").reshape(-1, 4)
            v["qscale"] = get(a + "q_l2_clip.scale")
            v["rscale"] = get(a + "rel_l2_clip.scale")
            v["relp"] = get(a + "rel_logits_proj.proj")
            v["aq"] = get(f"attn_res.attn_queries.{i - 1}").float().reshape(-1) if i > 0 else torch.zeros(3 * H, device=self.dev)
            v["mq"] = get(f"attn_res.mlp_queries.{i}").float()
            if loop:
                c = p + "controllers."
                v["cD"] = torch.stack([get(c + w + ".down_weight") for w in ("attn", "k", "v", "mlp")])
                v["cF"] = torch.stack([get(c + w + ".forget_weight") for w in ("attn", "k", "v", "mlp")])
                v["cG"] = torch.stack([get(c + w + ".gain_weight") for w in ("attn", "k", "v", "mlp")])
            else:
                v["cD"] = v["cF"] = v["cG"] = None
            layer_vals.append(v)
            torch.cuda.empty_cache()
        self.layer_vals = layer_vals
        g = {}
        g["embed"] = get("embed.weight")
        g["embed_norm"] = get("embed_norm.weight")
        g["oq"] = get("attn_res.output_query").float()
        g["fnorm"] = get("norm.weight")
        un = get("unembed.weight")
        g["unembed"] = tile_bf16(un[:12504 * 16])
        del un
        qm = get("middle_cycle_cross_pass_queries").float().unflatten(0, (-1, 2))
        kv = get("middle_cycle_cross_pass_kv_queries").float().unflatten(0, (-1, 2))
        g["lq"] = torch.stack([qm[:, 0], kv[:, 0], kv[:, 1], qm[:, 1]], dim=1).contiguous()
        self.gvals = g

    def _alloc(self):
        dev, bf, f32 = self.dev, torch.bfloat16, torch.float32
        C = self.max_context
        z = lambda *s, dt=bf: torch.zeros(*s, dtype=dt, device=dev)  # noqa: E731
        b = {}
        b["vecs"] = z(MAXB, 9, H)
        b["qkvo"] = z(MAXB, QKVW)
        b["attn_out"] = z(MAXB, 3072)
        b["attn_s"] = z(MAXB, H)
        b["act"] = z(64, MAXB, 1152)
        b["rlog"] = z(MAXB, 128, dt=f32)
        b["zb"] = z(MAXB, 4, 64, dt=f32)
        b["xg"] = z(MAXB, 4, H, dt=f32)
        b["msg"] = z(48, MAXB, H, dt=f32)
        b["msgir"] = z(48, MAXB, dt=f32)
        b["apart"] = z(MAXB, 8, MAXCH, 3, 136, dt=f32)
        b["acnt"] = z(MAXB * 8 + 8, dt=torch.int32)
        b["kc"] = z(NSLOT, MAXB, 8, C, 128)
        b["vc"] = z(NSLOT, MAXB, 8, C, 128)
        b["rk"] = z(NSLOT, MAXB, 4, 1024)
        b["rv"] = z(NSLOT, MAXB, 4, 1024)
        b["ro"] = z(NSLOT, MAXB, 4, H)
        b["rm"] = z(NSLOT, MAXB, 4, H)
        b["bar"] = z(64, dt=torch.int32)
        b["amv"] = z(152, MAXB, dt=f32)
        b["ami"] = z(152, MAXB, dt=torch.int32)
        self.bufs = b
        self.logits = torch.zeros(MAXB, VOCAB, dtype=f32, device=dev)
        fields = []
        for v in self.layer_vals:
            for name in LAYER_FIELDS:
                x = v.get(name, 0)
                fields.append(self._ptr(x) if isinstance(x, torch.Tensor) else int(x or 0))
        for name in GLOBAL_FIELDS:
            if name == "maxctx":
                fields.append(C)
            elif name.startswith("pad"):
                fields.append(0)
            elif name in self.gvals:
                fields.append(self._ptr(self.gvals[name]))
            else:
                fields.append(self._ptr(b[name]))
        self.fields = fields

    # ------------------------------------------------------------------------------------------ contract
    def reset(self) -> None:
        for k in ("rk", "rv", "ro", "rm", "acnt"):
            self.bufs[k].zero_()
        self.pos = 0
        self.B = None

    def _run(self, tokens, nsteps, mode, out=None, stop_app=NAPP):
        B = tokens.shape[0]
        if self.B is None:
            self.B = B
        assert B == self.B and 1 <= B <= self.max_batch
        if self.pos + nsteps > self.max_context:
            raise ValueError("context full")
        tok = tokens.to(device=self.dev, dtype=torch.int64).contiguous()
        rc = self.lib.mk_run(self.h, tok.data_ptr(), self.logits.data_ptr(), 0 if out is None else out.data_ptr(),
                             B, self.pos, nsteps, mode, stop_app, torch.cuda.current_stream().cuda_stream)
        assert rc == 0, rc
        self.pos += nsteps

    @torch.no_grad()
    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        self._run(tokens, 1, 0)
        return self.logits[: tokens.shape[0]].clone()

    def close(self) -> None:
        torch.cuda.synchronize()
        self.keep = []
        self.bufs = {}

    def stats(self) -> dict:
        return {"implementation": "mk persistent kernel", "track": "A"}
