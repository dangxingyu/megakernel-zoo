#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
OUT=${MK_BUILD_DIR:-build}
mkdir -p "$OUT"
rm -f "$OUT/libmk.so"
nvcc -O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xptxas -v --shared -Xcompiler -fPIC ${MK_DEFS:-} -o "$OUT/libmk.so" mk.cu 2> "$OUT/ptxas.log" || { cat "$OUT/ptxas.log"; exit 1; }
grep -E "registers|spill|smem" "$OUT/ptxas.log" | grep -A2 mk_kernel | head -5 || true
