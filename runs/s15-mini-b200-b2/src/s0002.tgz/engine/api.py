"""Inkling-2-Mini decode engine for one B200: one persistent CUDA kernel per decode step (engine/mini.cu).

Weights keep the checkpoint's formats (BF16; NVFP4 E2M1 codes + E4M3 block scales + per-expert amax/denominator;
MXFP8 E4M3 codes + UE8M0 block scales; FP32 queries and router bias); only their layout changes (MMA fragment order,
gate/up rows of w13 regrouped per 16-row strip). Expert inputs are BF16, not quantized (transformers#51050).
"""

from __future__ import annotations

import ctypes
import json
import os
import re
import subprocess
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
H, NL, NE, IM, MAXB, VOCAB = 2304, 24, 128, 1152, 8, 201024
PREFIX = "model.llm."
NSLOT, NAPP = 48, 48
TRACK = [x for x in re.split(r"[\s_,+]+", os.environ.get("MK_TRACK") or ((HERE / "TRACK").read_text() if (HERE / "TRACK").exists() else "A")) if x]

P = ctypes.c_void_p


class LayerW(ctypes.Structure):
    _fields_ = [("wqkv", P), ("wo", P), ("wr", P), ("rbias", P), ("w13", P), ("w2", P), ("f13", P), ("f2", P),
                ("norm", P * 3), ("mlp_norm", P), ("ksc", P), ("vsc", P), ("asc", P), ("msc", P), ("qscale", P),
                ("rscale", P), ("relp", P), ("aq", P), ("mq", P), ("dx", P), ("fg", P * 8),
                ("glob", ctypes.c_int), ("mx", ctypes.c_int), ("nqkv_strips", ctypes.c_int), ("s_k", ctypes.c_int),
                ("s_v", ctypes.c_int)]


class App(ctypes.Structure):
    _fields_ = [("layer", ctypes.c_int), ("slot", ctypes.c_int), ("pass_", ctypes.c_int), ("lloop", ctypes.c_int),
                ("nA", ctypes.c_int), ("srcA", ctypes.c_int * 6), ("nM", ctypes.c_int), ("srcM", ctypes.c_int * 6),
                ("addpin", ctypes.c_int), ("pin", ctypes.c_int), ("pout", ctypes.c_int), ("boundary", ctypes.c_int),
                ("gate", ctypes.c_int), ("msg_prev_a", ctypes.c_int), ("msg_prev_b", ctypes.c_int)]


_CTX_PTRS = ["embed", "embed_norm", "oq", "fnorm", "unembed", "lq", "dm", "blk", "attn_s", "xin", "xs", "xp", "ssq",
             "ufrag", "zb", "msg", "mfrag", "zm", "qkv", "apart", "acnt", "attn_o", "rlog", "actf", "gpart", "gcnt",
             "kc", "vc", "hk", "hv", "ha", "hm", "bar"]


class Ctx(ctypes.Structure):
    _fields_ = [("L", LayerW * NL), ("A", App * NAPP)] + [(n, P) for n in _CTX_PTRS] + \
               [("maxctx", ctypes.c_int), ("maxch", ctypes.c_int), ("nb", ctypes.c_int)]


# ------------------------------------------------------------------------------------------------ layouts
def frag_bf16(w: torch.Tensor) -> torch.Tensor:
    """[N, K] bf16 -> [N/16][K/64][4 ksteps][32 lanes][a0 a1 a2 a3] (m16n8k16 A fragments)."""
    n, k = w.shape
    assert n % 16 == 0 and k % 64 == 0, (n, k)
    x = w.contiguous().view(n // 16, 2, 8, k // 64, 4, 2, 4, 2)  # S, rh, g, U, s, kh, t, pair
    return x.permute(0, 3, 4, 2, 6, 5, 1, 7).contiguous().view(-1)


def frag_nvfp4(codes: torch.Tensor, scales: torch.Tensor) -> torch.Tensor:
    """codes [E, N, K/2] u8 (low nibble = even k), scales [E, N, K/16] u8 -> [E][N/16][K/64][512 codes + 64 scales]."""
    e, n, kb = codes.shape
    k = kb * 2
    S, U = n // 16, k // 64
    c = codes.view(e, S, 2, 8, U, 4, 2, 4).permute(0, 1, 4, 3, 7, 5, 6, 2).reshape(e, S, U, 512)
    sc = scales.view(torch.uint8).view(e, S, 2, 8, U, 4).permute(0, 1, 4, 3, 5, 2).reshape(e, S, U, 64)
    return torch.cat([c, sc], dim=-1).contiguous().view(-1)


def frag_mxfp8(codes: torch.Tensor, scales: torch.Tensor) -> torch.Tensor:
    """codes [E, N, K] e4m3 (u8), scales [E, N, K/32] u8 -> [E][N/16][K/64][1024 codes + 32 scales]."""
    e, n, k = codes.shape
    S, U = n // 16, k // 64
    c = codes.view(torch.uint8).view(e, S, 2, 8, U, 4, 2, 4, 2).permute(0, 1, 4, 3, 7, 5, 6, 2, 8).reshape(e, S, U, 1024)
    sc = scales.view(torch.uint8).view(e, S, 2, 8, U, 2).permute(0, 1, 4, 3, 5, 2).reshape(e, S, U, 32)
    return torch.cat([c, sc], dim=-1).contiguous().view(-1)


def w13_perm(dev) -> torch.Tensor:
    """New row r = s*16 + half*8 + i holds original row 2*(8s+i) + half (gate rows then up rows of 8 intermediates)."""
    s = torch.arange(144, device=dev).view(144, 1, 1)
    half = torch.arange(2, device=dev).view(1, 2, 1)
    i = torch.arange(8, device=dev).view(1, 1, 8)
    return (2 * (8 * s + i) + half).reshape(-1)


def pad_rows(w: torch.Tensor, rows: int) -> torch.Tensor:
    return w if w.shape[0] == rows else torch.cat([w, w.new_zeros(rows - w.shape[0], *w.shape[1:])])


def applications():
    out = [(i, 0, i) for i in range(6)]
    for p in range(3):
        out += [(i, p, i if p == 0 else NL + (p - 1) * 12 + (i - 6)) for i in range(6, 18)]
    return out + [(i, 0, i) for i in range(18, 24)]


def app_table():
    """Per application: attention/mlp mix sources (slots of the block buffer), partial in/out, loop flags.
    Slots: 0 h0, 1 prelude partial, 2+p P6-11 of pass p, 5+p P12-17 of pass p, 8 coda partial."""
    apps = []
    blocks, partial = [], 0
    pre = None
    prev_pass = -1
    for (i, p, slot) in applications():
        a = {"layer": i, "slot": slot, "pass": p, "lloop": i - 6 if 6 <= i < 18 else -1, "msg": None}
        if i == 6 and p == 0:
            pre = (list(blocks), partial)
        if i == 6 and p >= 1:
            a["msg"] = (2 + p - 1, 5 + p - 1)
            blocks, partial = list(pre[0]), pre[1]
        boundary = i % 6 == 0
        a["srcA"] = (blocks + [partial]) if blocks else []
        if boundary:
            a["srcM"], a["addpin"] = blocks + [partial], 0
            pout = {0: 1, 6: 2 + p, 12: 5 + p, 18: 8}[i]
        else:
            a["srcM"], a["addpin"] = list(blocks), 1
            pout = partial
        a["pin"], a["pout"], a["boundary"] = partial, pout, int(boundary)
        a["gate"] = int(6 <= i < 18 and p >= 1)
        if boundary:
            blocks = blocks + [partial]
            partial = pout
        apps.append(a)
        prev_pass = p
    assert blocks == [0, 1, 4, 7] and partial == 8, (blocks, partial)
    return apps


# ------------------------------------------------------------------------------------------------ engine
class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        assert 1 <= max_batch <= MAXB, max_batch
        self.max_batch, self.max_context = max_batch, max_context
        self.dev = torch.device("cuda")
        lib_path = Path(os.environ.get("MK_LIB") or (HERE / "build" / "libmini.so"))
        if not lib_path.exists():
            subprocess.check_call(["bash", str(HERE / "build.sh")])
        self.lib = ctypes.CDLL(str(lib_path))
        self.lib.mini_launch.argtypes = [ctypes.c_int, ctypes.c_int, P, P, P]
        self.lib.mini_err.restype = ctypes.c_char_p
        sizes = (ctypes.c_int * 4)()
        self.lib.mini_sizes(sizes)
        assert sizes[0] == ctypes.sizeof(Ctx) and sizes[1] == ctypes.sizeof(LayerW) and sizes[2] == ctypes.sizeof(App), \
            (list(sizes), ctypes.sizeof(Ctx), ctypes.sizeof(LayerW), ctypes.sizeof(App))
        self.keep = []
        self.cfg = json.loads((Path(model_dir) / "config.json").read_text())["text_config"]
        self._load(model_dir)
        self._alloc()
        self.ctx_ptr = None
        nb = self.lib.mini_init(ctypes.byref(self.ctx))
        assert nb > 0, nb
        self.nb = nb
        self.B = None
        self.pos = 0
        self.reset()

    # -------------------------------------------------------------------------------------------- loading
    def _keep(self, t: torch.Tensor) -> int:
        t = t.contiguous()
        self.keep.append(t)
        return t.data_ptr()

    def _load(self, model_dir):
        from safetensors import safe_open
        d = Path(model_dir)
        idx = json.loads((d / "model.safetensors.index.json").read_text())["weight_map"]
        files = sorted({v for k, v in idx.items() if k.startswith(PREFIX)})
        handles = {f: safe_open(str(d / f), framework="pt", device="cuda") for f in files}
        g = lambda n: handles[idx[PREFIX + n]].get_tensor(PREFIX + n)  # noqa: E731
        ctx = Ctx()
        local = set(self.cfg["local_layer_ids"])
        perm = w13_perm(self.dev)
        self.stats_ = {"mx_scale_exp": set()}
        for i in range(NL):
            L = ctx.L[i]
            p = f"layers.{i}."
            glob = i not in local
            L.glob = int(glob)
            wq, wg, wr, ws = g(p + "attn.wq_du.weight"), g(p + "attn.gate_attn.weight"), g(p + "attn.wr_du.weight"), g(p + "attn.attn_sink_proj.weight")
            wk, wv = g(p + "attn.wk_dv.weight"), g(p + "attn.wv_dv.weight")
            grpA = torch.cat([wq, wg, wr, pad_rows(ws, 32)])
            assert grpA.shape[0] == 6560
            if glob:
                grpB = torch.cat([wk, g(p + "attn.k_sconv.weight_proj")])
                grpC = torch.cat([wv, g(p + "attn.v_sconv.weight_proj")])
            else:
                grpB, grpC = wk, wv
            wqkv = torch.cat([grpA, grpB, grpC])
            L.nqkv_strips = wqkv.shape[0] // 16
            L.s_k = 6560 // 16
            L.s_v = (6560 + grpB.shape[0]) // 16
            L.wqkv = self._keep(frag_bf16(wqkv))
            L.wo = self._keep(frag_bf16(g(p + "attn.wo_ud.weight")))
            L.wr = self._keep(frag_bf16(g(p + "mlp.gate.weight")))
            L.rbias = self._keep(g(p + "mlp.gate.bias").float())
            if glob:
                n3 = [g(p + "q_input_norm.weight"), g(p + "k_input_norm.weight"), g(p + "v_input_norm.weight")]
                L.ksc = self._keep(g(p + "attn.k_sconv.static_w"))
                L.vsc = self._keep(g(p + "attn.v_sconv.static_w"))
            else:
                n3 = [g(p + "attn_norm.weight")] * 3
                L.ksc = self._keep(g(p + "attn.k_sconv.weight").view(1024, 4))
                L.vsc = self._keep(g(p + "attn.v_sconv.weight").view(1024, 4))
            for j in range(3):
                L.norm[j] = self._keep(n3[j])
            L.mlp_norm = self._keep(g(p + "mlp_norm.weight"))
            L.asc = self._keep(g(p + "attn_sconv.weight").view(H, 4))
            L.msc = self._keep(g(p + "mlp_sconv.weight").view(H, 4))
            L.qscale = self._keep(g(p + "attn.q_l2_clip.scale"))
            L.rscale = self._keep(g(p + "attn.rel_l2_clip.scale"))
            L.relp = self._keep(g(p + "attn.rel_logits_proj.proj"))
            L.aq = self._keep(g(f"attn_res.attn_queries.{i - 1}").float().reshape(-1, H)) if i > 0 else None
            L.mq = self._keep(g(f"attn_res.mlp_queries.{i}").float())
            ex = p + "mlp.experts."
            w13, w2 = g(ex + "w13_weight"), g(ex + "w2_weight")
            if w13.dtype == torch.uint8:
                L.mx = 0
                L.w13 = self._keep(frag_nvfp4(w13[:, perm], g(ex + "w13_weight_scale")[:, perm]))
                L.w2 = self._keep(frag_nvfp4(w2, g(ex + "w2_weight_scale")))
                L.f13 = self._keep((g(ex + "w13_weight_amax").double() / g(ex + "w13_weight_outer_scale_denominator").double()).float())
                L.f2 = self._keep((g(ex + "w2_weight_amax").double() / g(ex + "w2_weight_outer_scale_denominator").double()).float())
            else:
                L.mx = 1
                s13, s2 = g(ex + "w13_weight_scale"), g(ex + "w2_weight_scale")
                for s in (s13, s2):
                    u = torch.unique(s)
                    self.stats_["mx_scale_exp"] |= set(int(v) for v in u.tolist())
                L.w13 = self._keep(frag_mxfp8(w13[:, perm], s13[:, perm]))
                L.w2 = self._keep(frag_mxfp8(w2, s2))
            del w13, w2
            if 6 <= i < 18:
                dx = []
                for j, which in enumerate(("attn", "k", "v", "mlp")):
                    D = g(p + f"controllers.{which}.down_weight")
                    assert D.shape == (64, 2 * H)
                    dx.append(D[:, :H])
                    L.fg[2 * j] = self._keep(g(p + f"controllers.{which}.forget_weight"))
                    L.fg[2 * j + 1] = self._keep(g(p + f"controllers.{which}.gain_weight"))
                L.dx = self._keep(frag_bf16(torch.cat(dx)))
        # check the MXFP8 scale exponents: every code x scale product must be an exact BF16
        ex = self.stats_["mx_scale_exp"]
        assert min(ex) >= 3 and max(ex) <= 127 + 118, sorted(ex)
        dm = []
        for i in range(6, 18):
            for which in ("attn", "k", "v", "mlp"):
                dm.append(g(f"layers.{i}.controllers.{which}.down_weight")[:, H:])
        ctx.dm = self._keep(frag_bf16(torch.cat(dm)))
        qm = g("middle_cycle_cross_pass_queries").float().unflatten(0, (-1, 2))
        kv = g("middle_cycle_cross_pass_kv_queries").float().unflatten(0, (-1, 2))
        ctx.lq = self._keep(torch.stack([qm[:, 0], kv[:, 0], kv[:, 1], qm[:, 1]], dim=1))
        ctx.embed = self._keep(g("embed.weight"))
        ctx.embed_norm = self._keep(g("embed_norm.weight"))
        ctx.oq = self._keep(g("attn_res.output_query").float())
        ctx.fnorm = self._keep(g("norm.weight"))
        ctx.unembed = self._keep(frag_bf16(g("unembed.weight")))
        apps = app_table()
        for k, a in enumerate(apps):
            A = ctx.A[k]
            A.layer, A.slot, A.pass_, A.lloop = a["layer"], a["slot"], a["pass"], a["lloop"]
            A.nA = len(a["srcA"])
            for j, s in enumerate(a["srcA"]):
                A.srcA[j] = s
            A.nM = len(a["srcM"])
            for j, s in enumerate(a["srcM"]):
                A.srcM[j] = s
            A.addpin, A.pin, A.pout, A.boundary, A.gate = a["addpin"], a["pin"], a["pout"], a["boundary"], a["gate"]
            A.msg_prev_a, A.msg_prev_b = a["msg"] if a["msg"] else (-1, -1)
        self.ctx = ctx
        torch.cuda.synchronize()

    def _alloc(self):
        c = self.ctx
        z = lambda *shape, dtype=torch.bfloat16: self._keep(torch.zeros(*shape, dtype=dtype, device=self.dev))  # noqa: E731
        f32 = torch.float32
        self.maxch = (self.max_context + 63) // 64 + 1
        c.maxctx, c.maxch = self.max_context, self.maxch
        c.blk = z(9, MAXB, H)
        c.attn_s = z(MAXB, H)
        c.xin = z(4, MAXB, H)
        c.xs = z(4, MAXB, H, dtype=f32)
        c.xp = z(4, MAXB, H, dtype=f32)
        c.ssq = z(4, MAXB, 36, dtype=f32)
        c.ufrag = z(4, 144 * 32 * 2, dtype=torch.int32)
        c.zb = z(4, MAXB, 64, dtype=f32)
        c.msg = z(12, 4, MAXB, H, dtype=f32)
        c.mfrag = z(48, 144 * 32 * 2, dtype=torch.int32)
        c.zm = z(12, 4, MAXB, 64, dtype=f32)
        c.qkv = z(MAXB, 8704)
        c.apart = z(MAXB, 8, self.maxch, 3, 132, dtype=f32)
        c.acnt = z(MAXB * 8, dtype=torch.int32)
        c.attn_o = z(MAXB, 3072)
        c.rlog = z(MAXB, 128, dtype=f32)
        c.actf = z(64, 72 * 32 * 2, dtype=torch.int32)
        c.gpart = z(12564, 48, 128, dtype=f32)
        c.gcnt = z(12564, dtype=torch.int32)
        kvshape = (NSLOT, MAXB, 8, self.max_context, 128)
        self.kc = torch.zeros(kvshape, dtype=torch.bfloat16, device=self.dev)
        self.vc = torch.zeros(kvshape, dtype=torch.bfloat16, device=self.dev)
        c.kc, c.vc = self._keep(self.kc), self._keep(self.vc)
        self.hist = [torch.zeros(NSLOT, MAXB, 4, n, dtype=torch.bfloat16, device=self.dev) for n in (1024, 1024, H, H)]
        c.hk, c.hv, c.ha, c.hm = [self._keep(t) for t in self.hist]
        c.bar = z(64, dtype=torch.int32)

    # -------------------------------------------------------------------------------------------- contract
    def reset(self) -> None:
        for t in self.hist:
            t.zero_()
        self.pos = 0
        self.B = None

    @torch.no_grad()
    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        B = int(tokens.shape[0])
        if self.B is None:
            if not 1 <= B <= self.max_batch:
                raise ValueError(f"batch {B} outside 1..{self.max_batch}")
            self.B = B
        elif B != self.B:
            raise ValueError("batch size changed without reset()")
        if self.pos >= self.max_context:
            raise ValueError(f"context full ({self.max_context})")
        tok = tokens.to(device=self.dev, dtype=torch.int64).contiguous()
        out = torch.empty(B, VOCAB, dtype=torch.float32, device=self.dev)
        stream = torch.cuda.current_stream().cuda_stream
        e = self.lib.mini_launch(B, self.pos, tok.data_ptr(), out.data_ptr(), stream)
        if e != 0:
            raise RuntimeError(self.lib.mini_err(e).decode())
        self.pos += 1
        return out

    @torch.no_grad()
    def generate(self, tokens: torch.Tensor, n_steps: int) -> torch.Tensor:
        out = torch.empty(tokens.shape[0], n_steps, dtype=torch.int64, device=self.dev)
        t = tokens.to(self.dev, torch.int64)
        for k in range(n_steps):
            t = self.step(t).argmax(-1)
            out[:, k] = t
        return out

    def close(self) -> None:
        self.keep = []

    def stats(self) -> dict:
        return {"implementation": "mini persistent kernel", "track": "+".join(TRACK), "blocks": self.nb}
