#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
rm -f build/libmini.so
nvcc -O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xcompiler -fPIC -shared ${MK_CFLAGS:-} -Xptxas -v \
  -o build/libmini.so mini.cu 2> build/ptxas.log || { cat build/ptxas.log; exit 1; }
grep -A2 "mini_step" build/ptxas.log | grep -E "registers|spill" || true
