// Inkling-2-Mini decode engine for one B200: one persistent kernel per decode step.
// Phases separated by grid barriers; every GEMV is a deterministic split-K over contiguous warp ranges of
// (strip of 16 rows, unit of 64 K) items with mma.sync m16n8k16 (tokens are the n=8 columns).
// Weights keep the checkpoint's formats (BF16; NVFP4 E2M1 codes + E4M3 scales + per-expert factor; MXFP8 E4M3 codes +
// UE8M0 scales); only their layout changes (MMA fragment order). Expert inputs are BF16 (not quantized): the stored
// codes are converted exactly to BF16 (cvt.rn.bf16x2.e2m1x2 / e4m3x2) and multiplied exactly by their block scale.
#include <cuda_bf16.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include "mkprof.cuh"
__device__ MkProf g_prof;

typedef __nv_bfloat16 bf16;

#define H 2304
#define NQH 24
#define NKV 8
#define HD 128
#define QW 3072
#define KVW 1024
#define NE 128
#define TOPK 8
#define IM 1152
#define MAXB 8
#define NT 512
#define NWB 16
#define CH 64
#define VOCAB 201024
#define KS_H 144     // ksteps of 16 over H
#define U_H 36       // units of 64 over H
#define NAPP 48
#define NSLOT 48
#define R_Q 0
#define R_G 3072
#define R_R 6144
#define R_S 6528
#define R_K 6560
#define QKVLD 8704
#define MAXSLOT 48
#define MAXSTRIP 12564
#define MAXU 64
#define NGX 36       // gate chunks of 64 elements
#ifndef SPIN_NS
#define SPIN_NS 20
#endif

// ------------------------------------------------------------------------------------------------ parameters
struct LayerW {
  const uint4* wqkv;   // bf16 frag [strips][36][4][32] uint4
  const uint4* wo;     // [144][48][4][32]
  const uint4* wr;     // router [8][36][4][32]
  const float* rbias;  // [128]
  const uint8_t* w13;  // nvfp4 [128][144][36][576] or mxfp8 [128][144][36][1056]
  const uint8_t* w2;   // nvfp4 [128][144][18][576] or mxfp8 [128][144][18][1056]
  const float* f13;    // [128] amax/denominator (nvfp4)
  const float* f2;
  const bf16* norm[3]; // attn_norm x3 (local) or q/k/v_input_norm
  const bf16* mlp_norm;
  const bf16* ksc;     // local: [1024][4]; global: static_w [4][1024]
  const bf16* vsc;
  const bf16* asc;     // attn_sconv [2304][4]
  const bf16* msc;     // mlp_sconv [2304][4]
  const bf16* qscale;  // [24][128]
  const bf16* rscale;  // [24][16]
  const bf16* relp;    // [16][1024]
  const float* aq;     // attn_res query for this layer's attention input: [nq][2304] (layer 0: null)
  const float* mq;     // [2304]
  // loop controllers (layers 6..17): order attn, k, v, mlp
  const uint4* dx;     // D[:, :2304] frag, rows [4 ctrl x 64] -> 16 strips (strips 0..11 attn/k/v, 12..15 mlp)
  const bf16* fg[4][2]; // forget / gain [2304][64] row-major
  int glob, mx, nqkv_strips, s_k, s_v; // strip thresholds of the k and v groups
};

struct App {
  int layer, slot, pass, lloop;     // lloop: index in the loop (0..11) for loop layers, else -1
  int nA, srcA[6];                  // attention-input sources: blocks then partial (layer 0: nA = 0)
  int nM, srcM[6], addpin;          // mlp-input sources (blocks); last value = attn_s (+ pin if addpin)
  int pin, pout, boundary;
  int gate;                         // passes >= 2 of loop layers
  int msg_prev_a, msg_prev_b;       // first app of passes 2/3: the previous pass's sources for the messages
};

struct Ctx {
  LayerW L[24];
  App A[NAPP];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm; const uint4* unembed;
  const float* lq;      // loop queries [12][4][2304]
  const uint4* dm;      // D[:, 2304:] frags of all loop layers [12 layers][4 ctrl][64 rows] -> 192 strips
  bf16* blk;            // [9][MAXB][H]
  bf16* attn_s;         // [MAXB][H]
  bf16* xin;            // [4][MAXB][H] normalized GEMV inputs (bf16)
  float* xs;            // [4][MAXB][H] pre-gate inputs
  float* xp;            // [4][MAXB][H] post-gate inputs
  float* ssq;           // [4][MAXB][NGX]
  uint2* ufrag;         // [4][144*32] unit(x) frags for the gate GEMV
  float* zb;            // [4][MAXB][64]
  float* msg;           // [12][4][MAXB][H]
  uint2* mfrag;         // [48][144*32]
  float* zm;            // [12][4][MAXB][64]
  bf16* qkv;            // [MAXB][QKVLD]
  float* apart;         // [MAXB][8][maxch][3][132]
  unsigned* acnt;       // [MAXB][8]
  bf16* attn_o;         // [MAXB][3072]
  float* rlog;          // [MAXB][128]
  uint2* actf;          // [MAXU][72*32] w2 B frags
  float* gpart;         // [MAXSTRIP][MAXSLOT][128]
  unsigned* gcnt;       // [MAXSTRIP]
  bf16* kc; bf16* vc;   // [NSLOT][MAXB][8][maxctx][128]
  bf16* hk; bf16* hv;   // [NSLOT][MAXB][4][1024]
  bf16* ha; bf16* hm;   // [NSLOT][MAXB][4][H]
  unsigned* bar;        // [0] count, [32] generation
  int maxctx, maxch, nb;
};

struct Smem {
  uint2 xf[3 * KS_H * 32];   // 110592 B: B fragments (o-proj uses the first 192*32)
  float red[NWB][32];
  float misc[2048];
  float att[3 * 64 * 4];
  int ids[MAXB][TOPK]; float wts[MAXB][TOPK];
  int uni[MAXU]; float wsel[MAXU][MAXB]; int nu;
};

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ uint4 ldw(const void* p) {
  uint4 r;
  asm("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldw2(const void* p) {
  uint2 r;
  asm("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldw1(const void* p) {
  uint32_t r;
  asm("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ void mma(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
      : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void fp4x8(uint32_t w, uint32_t* o) {
  asm("{.reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      "cvt.rn.bf16x2.e2m1x2 %0, b0; cvt.rn.bf16x2.e2m1x2 %1, b1; cvt.rn.bf16x2.e2m1x2 %2, b2; cvt.rn.bf16x2.e2m1x2 %3, b3;}"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
__device__ __forceinline__ uint32_t e4m3x2(uint32_t w16) {
  uint32_t r;
  asm("{.reg .b16 h; cvt.u16.u32 h, %1; cvt.rn.bf16x2.e4m3x2 %0, h;}" : "=r"(r) : "r"(w16));
  return r;
}
__device__ __forceinline__ uint32_t bmul2(uint32_t a, uint32_t b) {
  uint32_t r;
  asm("mul.rn.bf16x2 %0, %1, %2;" : "=r"(r) : "r"(a), "r"(b));
  return r;
}
__device__ __forceinline__ uint32_t prmt(uint32_t a, uint32_t b, uint32_t s) {
  uint32_t r;
  asm("prmt.b32 %0,%1,%2,%3;" : "=r"(r) : "r"(a), "r"(b), "r"(s));
  return r;
}
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }
__device__ __forceinline__ float ldbf_cg(const bf16* p) {
  unsigned short v = __ldcg(reinterpret_cast<const unsigned short*>(p));
  return __uint_as_float(((unsigned)v) << 16);
}
__device__ __forceinline__ void unpack8(uint4 v, float* f) {
  const uint32_t* u = &v.x;
#pragma unroll
  for (int i = 0; i < 4; i++) { f[2 * i] = __uint_as_float(u[i] << 16); f[2 * i + 1] = __uint_as_float(u[i] & 0xffff0000u); }
}
__device__ __forceinline__ uint32_t pack2(float a, float b) {
  return (uint32_t)__bfloat16_as_ushort(tobf(a)) | ((uint32_t)__bfloat16_as_ushort(tobf(b)) << 16);
}
__device__ __forceinline__ unsigned ld_acquire(const unsigned* p) {
  unsigned v;
  asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory");
  return v;
}
__device__ __forceinline__ float warp_sum(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v += __shfl_xor_sync(~0u, v, o);
  return v;
}
__device__ __forceinline__ float warp_max(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v = fmaxf(v, __shfl_xor_sync(~0u, v, o));
  return v;
}

// grid barrier: arrival counter reset by the last arriver, which bumps the generation
#ifdef MKPROF
__device__ unsigned g_pn;
__shared__ unsigned g_pn_s;
#define PMARK(tag) do { if (threadIdx.x == 0) { unsigned n_ = g_pn_s; MKPROF_MARK(g_prof, n_, tag); g_pn_s = n_; } } while (0)
#else
#define PMARK(tag) do {} while (0)
#endif
__device__ __forceinline__ void grid_bar(const Ctx& c) {
  __syncthreads();
  if (threadIdx.x == 0) {
    unsigned* cnt = c.bar;
    unsigned* gen = c.bar + 32;
    unsigned g = ld_acquire(gen);
    __threadfence();
    unsigned old = atomicAdd(cnt, 1);
    if (old == (unsigned)c.nb - 1) {
      *cnt = 0;
      __threadfence();
      atomicAdd(gen, 1);
    } else {
      while (ld_acquire(gen) == g) { __nanosleep(SPIN_NS); }
    }
    __threadfence();
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ GEMV skeleton
// Items (strip, unit) in strip-major order, split into contiguous ranges over `nwarps` warps of the grid. A strip
// entirely inside one warp is finished there; otherwise each warp writes its partial to slot (warp - first warp of
// the strip) and the last arriving warp sums the slots in slot order (deterministic) and runs the epilogue.
template <class LD, class EPI>
__device__ __forceinline__ void gemv(const Ctx& c, int nstrip, int U, int nwarps, const LD& ld, const EPI& epi) {
  const int lane = threadIdx.x & 31;
  const int gw = blockIdx.x * NWB + (threadIdx.x >> 5);
  if (nwarps > c.nb * NWB) nwarps = c.nb * NWB;
  if (gw >= nwarps) return;
  const long I = (long)nstrip * U;
  long i0 = I * gw / nwarps;
  const long i1 = I * (gw + 1) / nwarps;
  while (i0 < i1) {
    const int s = (int)(i0 / U);
    const long sb = (long)s * U;
    const int u0 = (int)(i0 - sb);
    const long se = sb + U;
    const int u1 = (int)((i1 < se ? i1 : se) - sb);
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    ld.run(s, u0, u1, acc);
    if (u0 == 0 && u1 == U) {
      epi(s, lane, acc);
    } else {
      const int first = (int)(((sb + 1) * nwarps - 1) / I);
      const int last = (int)(((sb + U) * nwarps - 1) / I);
      const int n = last - first + 1;
      float4* P = reinterpret_cast<float4*>(c.gpart) + ((size_t)s * MAXSLOT) * 32 + lane;
      __stcg(P + (gw - first) * 32, make_float4(acc[0], acc[1], acc[2], acc[3]));
      __threadfence();
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) old = atomicAdd(&c.gcnt[s], 1u);
      old = __shfl_sync(~0u, old, 0);
      if (old == (unsigned)n - 1) {
        __threadfence();
        float t[4] = {0.f, 0.f, 0.f, 0.f};
        for (int j = 0; j < n; j++) {
          float4 v = __ldcg(P + j * 32);
          t[0] += v.x; t[1] += v.y; t[2] += v.z; t[3] += v.w;
        }
        if (lane == 0) c.gcnt[s] = 0;
        epi(s, lane, t);
      }
    }
    i0 = se < i1 ? se : i1;
  }
}

// BF16 weights, B fragments in shared memory (stream chosen by strip thresholds) or in global memory (per strip group)
struct LdBF {
  const uint4* W; int U; const uint2* xs; int t1, t2; int kstride;
  __device__ __forceinline__ void run(int s, int u0, int u1, float* acc) const {
    const int lane = threadIdx.x & 31;
    const int st = (s >= t1) + (s >= t2);
    const uint2* x = xs + st * kstride + lane;
    const uint4* w = W + ((size_t)s * U) * 128 + lane;
    int u = u0;
    for (; u + 2 <= u1; u += 2) {
      uint4 a[8];
#pragma unroll
      for (int j = 0; j < 8; j++) a[j] = ldw(w + (u * 4 + j) * 32);
#pragma unroll
      for (int j = 0; j < 8; j++) { uint2 b = x[(u * 4 + j) * 32]; mma(acc, a[j].x, a[j].y, a[j].z, a[j].w, b.x, b.y); }
    }
    if (u < u1) {
      uint4 a[4];
#pragma unroll
      for (int j = 0; j < 4; j++) a[j] = ldw(w + (u * 4 + j) * 32);
#pragma unroll
      for (int j = 0; j < 4; j++) { uint2 b = x[(u * 4 + j) * 32]; mma(acc, a[j].x, a[j].y, a[j].z, a[j].w, b.x, b.y); }
    }
  }
};
// B fragments in global memory: strip s uses frag block s / spg
struct LdBFg {
  const uint4* W; int U; const uint2* xg; int spg;
  __device__ __forceinline__ void run(int s, int u0, int u1, float* acc) const {
    const int lane = threadIdx.x & 31;
    const uint2* x = xg + (size_t)(s / spg) * (U * 4 * 32) + lane;
    const uint4* w = W + ((size_t)s * U) * 128 + lane;
    for (int u = u0; u < u1; u++) {
      uint4 a[4]; uint2 b[4];
#pragma unroll
      for (int j = 0; j < 4; j++) { a[j] = ldw(w + (u * 4 + j) * 32); b[j] = __ldcg(x + (u * 4 + j) * 32); }
#pragma unroll
      for (int j = 0; j < 4; j++) mma(acc, a[j].x, a[j].y, a[j].z, a[j].w, b[j].x, b[j].y);
    }
  }
};

// one NVFP4 unit (16 rows x 64 K): codes uint4 (4 ksteps x [a0 a1 a2 a3] bytes), scales uint2 ([kstep][row g, g+8])
__device__ __forceinline__ void fp4_unit(const uint4& cw, const uint2& sw, const uint2* b, float* acc) {
  const uint32_t* cwp = &cw.x;
#pragma unroll
  for (int s = 0; s < 4; s++) {
    const uint32_t sc = ((s < 2 ? sw.x : sw.y) >> (16 * (s & 1))) & 0xffffu;
    const uint32_t S = e4m3x2(sc);
    const uint32_t S0 = prmt(S, S, 0x1010), S1 = prmt(S, S, 0x3232);
    uint32_t a[4];
    fp4x8(cwp[s], a);
    mma(acc, bmul2(a[0], S0), bmul2(a[1], S1), bmul2(a[2], S0), bmul2(a[3], S1), b[s].x, b[s].y);
  }
}
// one MXFP8 unit: codes 2 x uint4 (4 ksteps x 8 bytes), scales uint32 ([blk][row g, g+8] UE8M0)
__device__ __forceinline__ void fp8_unit(const uint4& c0, const uint4& c1, uint32_t sw, const uint2* b, float* acc) {
  const uint32_t* cp0 = &c0.x;
  const uint32_t* cp1 = &c1.x;
#pragma unroll
  for (int s = 0; s < 4; s++) {
    const uint32_t e0 = (sw >> (16 * (s >> 1))) & 0xff, e1 = (sw >> (16 * (s >> 1) + 8)) & 0xff;
    const uint32_t S0 = (e0 << 7) | (e0 << 23), S1 = (e1 << 7) | (e1 << 23);
    const uint32_t w0 = s < 2 ? cp0[2 * s] : cp1[2 * (s - 2)];
    const uint32_t w1 = s < 2 ? cp0[2 * s + 1] : cp1[2 * (s - 2) + 1];
    mma(acc, bmul2(e4m3x2(w0 & 0xffff), S0), bmul2(e4m3x2(w0 >> 16), S1), bmul2(e4m3x2(w1 & 0xffff), S0),
        bmul2(e4m3x2(w1 >> 16), S1), b[s].x, b[s].y);
  }
}

// w13: strip index = u * 144 + s (union slot u), B fragments of the mlp input in shared memory
struct LdW13 {
  const uint8_t* W; int mx; const int* uni; const uint2* xs;
  __device__ __forceinline__ void run(int S, int u0, int u1, float* acc) const {
    const int lane = threadIdx.x & 31;
    const int us = S / 144, s = S - us * 144;
    const int e = uni[us];
    const uint2* x = xs + lane;
    if (!mx) {
      const uint8_t* w = W + (((size_t)e * 144 + s) * U_H) * 576;
      int u = u0;
      for (; u + 2 <= u1; u += 2) {
        uint4 c0 = ldw(w + u * 576 + lane * 16), c1 = ldw(w + (u + 1) * 576 + lane * 16);
        uint2 s0 = ldw2(w + u * 576 + 512 + (lane >> 2) * 8), s1 = ldw2(w + (u + 1) * 576 + 512 + (lane >> 2) * 8);
        uint2 b[4];
#pragma unroll
        for (int j = 0; j < 4; j++) b[j] = x[(u * 4 + j) * 32];
        fp4_unit(c0, s0, b, acc);
#pragma unroll
        for (int j = 0; j < 4; j++) b[j] = x[(u * 4 + 4 + j) * 32];
        fp4_unit(c1, s1, b, acc);
      }
      if (u < u1) {
        uint4 c0 = ldw(w + u * 576 + lane * 16);
        uint2 s0 = ldw2(w + u * 576 + 512 + (lane >> 2) * 8);
        uint2 b[4];
#pragma unroll
        for (int j = 0; j < 4; j++) b[j] = x[(u * 4 + j) * 32];
        fp4_unit(c0, s0, b, acc);
      }
    } else {
      const uint8_t* w = W + (((size_t)e * 144 + s) * U_H) * 1056;
      for (int u = u0; u < u1; u++) {
        uint4 c0 = ldw(w + u * 1056 + lane * 32), c1 = ldw(w + u * 1056 + lane * 32 + 16);
        uint32_t sw = ldw1(w + u * 1056 + 1024 + (lane >> 2) * 4);
        uint2 b[4];
#pragma unroll
        for (int j = 0; j < 4; j++) b[j] = x[(u * 4 + j) * 32];
        fp8_unit(c0, c1, sw, b, acc);
      }
    }
  }
};
// w2: strip s (144), unit j = u * 18 + k over the union; B fragments (act) in global memory; factor per expert
struct LdW2 {
  const uint8_t* W; int mx; const int* uni; const uint2* act; const float* f2;
  __device__ __forceinline__ void run(int s, int j0, int j1, float* acc) const {
    const int lane = threadIdx.x & 31;
    int j = j0;
    while (j < j1) {
      const int us = j / 18;
      const int e = uni[us];
      const int je = (us + 1) * 18 < j1 ? (us + 1) * 18 : j1;
      float t[4] = {0.f, 0.f, 0.f, 0.f};
      const uint2* x = act + (size_t)us * (72 * 32) + lane;
      if (!mx) {
        const uint8_t* w = W + (((size_t)e * 144 + s) * 18) * 576;
        for (; j < je; j++) {
          const int k = j - us * 18;
          uint4 c0 = ldw(w + k * 576 + lane * 16);
          uint2 s0 = ldw2(w + k * 576 + 512 + (lane >> 2) * 8);
          uint2 b[4];
#pragma unroll
          for (int q = 0; q < 4; q++) b[q] = __ldcg(x + (k * 4 + q) * 32);
          fp4_unit(c0, s0, b, t);
        }
        const float f = f2[e];
        acc[0] = fmaf(f, t[0], acc[0]); acc[1] = fmaf(f, t[1], acc[1]); acc[2] = fmaf(f, t[2], acc[2]); acc[3] = fmaf(f, t[3], acc[3]);
      } else {
        const uint8_t* w = W + (((size_t)e * 144 + s) * 18) * 1056;
        for (; j < je; j++) {
          const int k = j - us * 18;
          uint4 c0 = ldw(w + k * 1056 + lane * 32), c1 = ldw(w + k * 1056 + lane * 32 + 16);
          uint32_t sw = ldw1(w + k * 1056 + 1024 + (lane >> 2) * 4);
          uint2 b[4];
#pragma unroll
          for (int q = 0; q < 4; q++) b[q] = __ldcg(x + (k * 4 + q) * 32);
          fp8_unit(c0, c1, sw, b, t);
        }
        acc[0] += t[0]; acc[1] += t[1]; acc[2] += t[2]; acc[3] += t[3];
      }
    }
  }
};

// ------------------------------------------------------------------------------------------------ fragments
// B fragment of x[b][k] (k < 16*nks): word ((kstep*32 + lane)*2 + reg), lane = b*4 + (kk%8)/2, reg = kk/8
// fill shared fragments from bf16 vectors in global memory: src(st, b) -> bf16[K]
__device__ __forceinline__ void frag_from_bf16(uint2* xf, const bf16* base, int st_stride_tok, int nst, int nks, int B, int kstride) {
  // base: [st][MAXB][st_stride_tok]
  for (int i = threadIdx.x; i < nst * nks * 32; i += NT) {
    const int st = i / (nks * 32), r = i - st * nks * 32, ks = r >> 5, lane = r & 31;
    const int b = lane >> 2, t = lane & 3;
    uint2 v = make_uint2(0, 0);
    if (b < B) {
      const bf16* p = base + ((size_t)st * MAXB + b) * st_stride_tok + ks * 16 + 2 * t;
      v.x = __ldcg(reinterpret_cast<const unsigned*>(p));
      v.y = __ldcg(reinterpret_cast<const unsigned*>(p + 8));
    }
    xf[st * kstride + r] = v;
  }
}
__device__ __forceinline__ int frag_word(int k, int b) {  // index in uint32 units of an element pair start
  const int ks = k >> 4, kk = k & 15;
  return ((ks * 32 + b * 4 + ((kk & 7) >> 1)) * 2 + (kk >> 3));
}

// ------------------------------------------------------------------------------------------------ mixes
// One (query, token) attention-residual mix by one block: values src[0..n-1] (bf16 [H]); if add0/add1 the last value is
// add0 + add1 (fp32). Returns the mix of this thread's 8 elements (threads < 288) in out[8]; all threads get nothing else.
__device__ __forceinline__ float block_sum288(float v, Smem& sm, int slot) {
  // threads 0..287 (9 warps) contribute; returns the sum to every thread (deterministic)
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  v = warp_sum(v);
  __syncthreads();
  if (lane == 0 && w < 9) sm.red[w][slot] = v;
  __syncthreads();
  float s = 0.f;
#pragma unroll
  for (int i = 0; i < 9; i++) s += sm.red[i][slot];
  return s;
}

__device__ __forceinline__ void mix_unit(Smem& sm, const bf16* const* src, int n, const bf16* add0, const bf16* add1,
                                          const float* query, float* out) {
  // sources packed as bf16 (4 registers each); the last one in fp32 when it is an fp32 sum (add0 + add1)
  const int tid = threadIdx.x;
  const int w = tid >> 5, lane = tid & 31;
  const bool act = tid < 288;
  uint4 pk[6];
  float last[8];
  const bool addl = add0 != nullptr;
#pragma unroll
  for (int s = 0; s < 6; s++) pk[s] = make_uint4(0, 0, 0, 0);
  if (act) {
#pragma unroll
    for (int s = 0; s < 6; s++)
      if (s < n && !(addl && s == n - 1)) pk[s] = __ldcg(reinterpret_cast<const uint4*>(src[s] + tid * 8));
  }
#pragma unroll
  for (int e = 0; e < 8; e++) last[e] = 0.f;
  if (addl && act) {
    float a[8], b2[8];
    unpack8(__ldcg(reinterpret_cast<const uint4*>(add0 + tid * 8)), a);
    unpack8(__ldcg(reinterpret_cast<const uint4*>(add1 + tid * 8)), b2);
#pragma unroll
    for (int e = 0; e < 8; e++) last[e] = a[e] + b2[e];
  }
  float q[8];
#pragma unroll
  for (int e = 0; e < 8; e++) q[e] = 0.f;
  if (act) {
    const float4 q0 = __ldg(reinterpret_cast<const float4*>(query + tid * 8)), q1 = __ldg(reinterpret_cast<const float4*>(query + tid * 8 + 4));
    const float qs = 1.0f / 48.0f;
    q[0] = q0.x * qs; q[1] = q0.y * qs; q[2] = q0.z * qs; q[3] = q0.w * qs; q[4] = q1.x * qs; q[5] = q1.y * qs; q[6] = q1.z * qs; q[7] = q1.w * qs;
  }
  float part[12];
#pragma unroll
  for (int s = 0; s < 6; s++) {
    float v[8];
    if (addl && s == n - 1) {
#pragma unroll
      for (int e = 0; e < 8; e++) v[e] = last[e];
    } else unpack8(pk[s], v);
    float a = 0.f, d = 0.f;
#pragma unroll
    for (int e = 0; e < 8; e++) { a = fmaf(v[e], v[e], a); d = fmaf(v[e], q[e], d); }
    part[2 * s] = a; part[2 * s + 1] = d;
  }
#pragma unroll
  for (int i = 0; i < 12; i++) part[i] = warp_sum(part[i]);
  __syncthreads();
  if (lane == 0 && w < 9) {
#pragma unroll
    for (int i = 0; i < 12; i++) sm.red[w][i] = part[i];
  }
  __syncthreads();
  float ir[6], lg[6], mx = -INFINITY;
#pragma unroll
  for (int s = 0; s < 6; s++) {
    float a = 0.f, d = 0.f;
#pragma unroll
    for (int i = 0; i < 9; i++) { a += sm.red[i][2 * s]; d += sm.red[i][2 * s + 1]; }
    ir[s] = rsqrtf(a / (float)H + 1e-6f);
    lg[s] = d * ir[s];
    if (s < n) mx = fmaxf(mx, lg[s]);
  }
  float den = 0.f, p[6];
#pragma unroll
  for (int s = 0; s < 6; s++) { p[s] = s < n ? expf(lg[s] - mx) : 0.f; den += p[s]; }
  const float inv = 1.0f / den;
#pragma unroll
  for (int e = 0; e < 8; e++) out[e] = 0.f;
#pragma unroll
  for (int s = 0; s < 6; s++) {
    if (s < n) {
      const float ps = p[s] * inv;
      float v[8];
      if (addl && s == n - 1) {
#pragma unroll
        for (int e = 0; e < 8; e++) v[e] = last[e];
      } else unpack8(pk[s], v);
#pragma unroll
      for (int e = 0; e < 8; e++) out[e] = fmaf(ps, v[e] * ir[s], out[e]);
    }
  }
}

// rms over the block's 2304 values held by threads < 288 (8 each): returns rsqrt(mean(x^2) + eps)
__device__ __forceinline__ float block_rms(Smem& sm, const float* x, int slot) {
  float a = 0.f;
  if (threadIdx.x < 288) {
#pragma unroll
    for (int e = 0; e < 8; e++) a = fmaf(x[e], x[e], a);
  }
  const float s = block_sum288(a, sm, slot);
  return rsqrtf(s / (float)H + 1e-6f);
}
__device__ __forceinline__ void store_norm_bf16(bf16* dst, const float* x, float r, const bf16* w) {
  if (threadIdx.x < 288) {
    const int k = threadIdx.x * 8;
    float wf[8];
    unpack8(*reinterpret_cast<const uint4*>(w + k), wf);
    uint4 o;
    o.x = pack2(x[0] * r * wf[0], x[1] * r * wf[1]);
    o.y = pack2(x[2] * r * wf[2], x[3] * r * wf[3]);
    o.z = pack2(x[4] * r * wf[4], x[5] * r * wf[5]);
    o.w = pack2(x[6] * r * wf[6], x[7] * r * wf[7]);
    __stcg(reinterpret_cast<uint4*>(dst + k), o);
  }
}
// unit-RMS-normalised bf16 written as B fragments (token b) into a global fragment buffer
__device__ __forceinline__ void store_unit_frag(uint2* fr, int b, const float* x, float r) {
  if (threadIdx.x < 288) {
    const int k = threadIdx.x * 8;   // 8 elements: kk = k%16 in {0, 8}: pairs at 2t for t=0..3
    uint32_t* f = reinterpret_cast<uint32_t*>(fr);
#pragma unroll
    for (int p = 0; p < 4; p++) __stcg(f + frag_word(k + 2 * p, b), pack2(x[2 * p] * r, x[2 * p + 1] * r));
  }
}

// ------------------------------------------------------------------------------------------------ phases
__device__ __forceinline__ const bf16* blkp(const Ctx& c, int slot, int b) { return c.blk + ((size_t)slot * MAXB + b) * H; }

// MIXA: attention inputs. gate == 0: xin[q][b] = rmsnorm(mix_q, norm_q) (layer 0: from the embedding).
// gate: x_w = mix (local: one mix for w = 0..2), xs[w][b] = x_w, ufrag[w] = unit(x_w)
__device__ void phase_mixa(const Ctx& c, Smem& sm, const App& a, int B, const long long* tokens) {
  const LayerW& L = c.L[a.layer];
  const int nq = L.glob ? 3 : 1;
  float x[8];
  if (a.nA == 0) {  // layer 0: h0 = rmsnorm(embed[tok]) * embed_norm, then the attention input
    for (int b = blockIdx.x; b < B; b += c.nb) {
      long long tok = tokens[b];
      if (threadIdx.x < 288) unpack8(*reinterpret_cast<const uint4*>(c.embed + (size_t)tok * H + threadIdx.x * 8), x);
      float r = block_rms(sm, x, 0);
      float h[8];
      if (threadIdx.x < 288) {
        float wf[8];
        unpack8(*reinterpret_cast<const uint4*>(c.embed_norm + threadIdx.x * 8), wf);
#pragma unroll
        for (int e = 0; e < 8; e++) h[e] = rbf(x[e] * r * wf[e]);
      }
      if (threadIdx.x < 288) {
        uint4 o;
        o.x = pack2(h[0], h[1]); o.y = pack2(h[2], h[3]); o.z = pack2(h[4], h[5]); o.w = pack2(h[6], h[7]);
        __stcg(reinterpret_cast<uint4*>(c.blk + ((size_t)0 * MAXB + b) * H + threadIdx.x * 8), o);
      }
      float r2 = block_rms(sm, h, 1);
      store_norm_bf16(c.xin + ((size_t)0 * MAXB + b) * H, h, r2, L.norm[0]);
    }
    return;
  }
  const int nunits = nq * B;
  for (int u = blockIdx.x; u < nunits; u += c.nb) {
    const int q = u / B, b = u - q * B;
    const bf16* src[6];
    for (int s = 0; s < a.nA; s++) src[s] = blkp(c, a.srcA[s], b);
    mix_unit(sm, src, a.nA, nullptr, nullptr, L.aq + q * H, x);
    if (!a.gate) {
      float r = block_rms(sm, x, 0);
      store_norm_bf16(c.xin + ((size_t)q * MAXB + b) * H, x, r, L.norm[q]);
    } else {
      float r = block_rms(sm, x, 0);
      const int nw = L.glob ? 1 : 3;   // local: the one mix feeds the attn, k and v gates
      for (int w = 0; w < nw; w++) {
        const int ww = L.glob ? q : w;
        if (threadIdx.x < 288) {
          float* d = c.xs + ((size_t)ww * MAXB + b) * H + threadIdx.x * 8;
          __stcg(reinterpret_cast<float4*>(d), make_float4(x[0], x[1], x[2], x[3]));
          __stcg(reinterpret_cast<float4*>(d + 4), make_float4(x[4], x[5], x[6], x[7]));
        }
        store_unit_frag(c.ufrag + (size_t)ww * KS_H * 32, b, x, r);
      }
    }
  }
}

// MIXM: mlp input mix. gate == 0: xin[0][b] = rmsnorm(mix, mlp_norm); gate: xs[3][b], ufrag[3]
__device__ void phase_mixm(const Ctx& c, Smem& sm, const App& a, int B) {
  const LayerW& L = c.L[a.layer];
  float x[8];
  for (int b = blockIdx.x; b < B; b += c.nb) {
    const bf16* src[6];
    for (int s = 0; s < a.nM; s++) src[s] = blkp(c, a.srcM[s], b);
    src[a.nM] = c.attn_s + (size_t)b * H;
    const bf16* add0 = a.addpin ? blkp(c, a.pin, b) : nullptr;
    __syncthreads(); PMARK(20);
    mix_unit(sm, src, a.nM + 1, add0, add0 ? c.attn_s + (size_t)b * H : nullptr, L.mq, x);
    __syncthreads(); PMARK(21);
    float r = block_rms(sm, x, 0);
    __syncthreads(); PMARK(22);
    if (!a.gate) {
      store_norm_bf16(c.xin + ((size_t)0 * MAXB + b) * H, x, r, L.mlp_norm);
    } else {
      if (threadIdx.x < 288) {
        float* d = c.xs + ((size_t)3 * MAXB + b) * H + threadIdx.x * 8;
        __stcg(reinterpret_cast<float4*>(d), make_float4(x[0], x[1], x[2], x[3]));
        __stcg(reinterpret_cast<float4*>(d + 4), make_float4(x[4], x[5], x[6], x[7]));
      }
      store_unit_frag(c.ufrag + (size_t)3 * KS_H * 32, b, x, r);
    }
  }
}

// MSG: the 48 messages of a pass (12 loop layers x 4) from the previous pass's two sources
__device__ void phase_msg(const Ctx& c, Smem& sm, const App& a, int B) {
  float x[8];
  const int nunits = 48 * B;
  for (int u = blockIdx.x; u < nunits; u += c.nb) {
    const int lw = u / B, b = u - lw * B;
    const bf16* src[6] = {blkp(c, a.msg_prev_a, b), blkp(c, a.msg_prev_b, b)};
    mix_unit(sm, src, 2, nullptr, nullptr, c.lq + (size_t)lw * H, x);
    float r = block_rms(sm, x, 0);
    if (threadIdx.x < 288) {
      float* d = c.msg + ((size_t)lw * MAXB + b) * H + threadIdx.x * 8;
      __stcg(reinterpret_cast<float4*>(d), make_float4(x[0], x[1], x[2], x[3]));
      __stcg(reinterpret_cast<float4*>(d + 4), make_float4(x[4], x[5], x[6], x[7]));
    }
    store_unit_frag(c.mfrag + (size_t)lw * KS_H * 32, b, x, r);
  }
}

// MIXF: final output mix + norm
__device__ void phase_mixf(const Ctx& c, Smem& sm, int B) {
  float x[8];
  for (int b = blockIdx.x; b < B; b += c.nb) {
    const bf16* src[6] = {blkp(c, 0, b), blkp(c, 1, b), blkp(c, 4, b), blkp(c, 7, b), blkp(c, 8, b)};
    mix_unit(sm, src, 5, nullptr, nullptr, c.oq, x);
    float r = block_rms(sm, x, 0);
    store_norm_bf16(c.xin + (size_t)b * H, x, r, c.fnorm);
  }
}

// GX: x'_w = (1 - tanh(F_w z_w)) x_w + tanh(G_w z_w) m_w for w in [w0, w0 + nw); also partial sums of squares
__device__ void phase_gx(const Ctx& c, Smem& sm, const App& a, int B, int w0, int nw) {
  const LayerW& L = c.L[a.layer];
  // z of the gates into shared memory
  for (int i = threadIdx.x; i < nw * MAXB * 64; i += NT) sm.misc[i] = __ldcg(c.zb + (size_t)w0 * MAXB * 64 + i);
  __syncthreads();
  const int nunits = nw * NGX;
  const int e_l = threadIdx.x & 63, b = threadIdx.x >> 6;
  for (int u = blockIdx.x; u < nunits; u += c.nb) {
    const int wl = u / NGX, ch = u - wl * NGX, w = w0 + wl;
    const int e = ch * 64 + e_l;
    float sq = 0.f;
    if (b < B) {
      const bf16* F = L.fg[w][0] + (size_t)e * 64;
      const bf16* G = L.fg[w][1] + (size_t)e * 64;
      const float* z = sm.misc + (wl * MAXB + b) * 64;
      float f = 0.f, g = 0.f;
#pragma unroll
      for (int j = 0; j < 8; j++) {
        float fv[8], gv[8];
        unpack8(*reinterpret_cast<const uint4*>(F + j * 8), fv);
        unpack8(*reinterpret_cast<const uint4*>(G + j * 8), gv);
#pragma unroll
        for (int q = 0; q < 8; q++) { f = fmaf(fv[q], z[j * 8 + q], f); g = fmaf(gv[q], z[j * 8 + q], g); }
      }
      const float xv = __ldcg(c.xs + ((size_t)w * MAXB + b) * H + e);
      const float mv = __ldcg(c.msg + (((size_t)a.lloop * 4 + w) * MAXB + b) * H + e);
      const float xn = (1.0f - tanhf(f)) * xv + tanhf(g) * mv;
      __stcg(c.xp + ((size_t)w * MAXB + b) * H + e, xn);
      sq = xn * xn;
    }
    sq = warp_sum(sq);
    __syncthreads();
    if ((threadIdx.x & 31) == 0) sm.red[threadIdx.x >> 5][0] = sq;
    __syncthreads();
    if (threadIdx.x < MAXB && threadIdx.x < B)
      __stcg(c.ssq + ((size_t)w * MAXB + threadIdx.x) * NGX + ch, sm.red[2 * threadIdx.x][0] + sm.red[2 * threadIdx.x + 1][0]);
  }
}

// gated stream st -> normalized bf16 fragments in shared memory (slot dst)
__device__ void frag_from_gated(const Ctx& c, Smem& sm, int st, int dst, const bf16* wn, int B) {
  __syncthreads();
  if (threadIdx.x < MAXB) {
    float s = 0.f;
    if ((int)threadIdx.x < B)
      for (int i = 0; i < NGX; i++) s += __ldcg(c.ssq + ((size_t)st * MAXB + threadIdx.x) * NGX + i);
    sm.misc[1536 + st * 8 + threadIdx.x] = rsqrtf(s / (float)H + 1e-6f);
  }
  __syncthreads();
  uint2* xf = sm.xf + dst * KS_H * 32;
  for (int i = threadIdx.x; i < KS_H * 32; i += NT) {
    const int ks = i >> 5, lane = i & 31, b = lane >> 2, t = lane & 3;
    uint2 v = make_uint2(0, 0);
    if (b < B) {
      const float r = sm.misc[1536 + st * 8 + b];
      const float* p = c.xp + ((size_t)st * MAXB + b) * H + ks * 16 + 2 * t;
      const int k = ks * 16 + 2 * t;
      float2 x0 = __ldcg(reinterpret_cast<const float2*>(p)), x1 = __ldcg(reinterpret_cast<const float2*>(p + 8));
      v.x = pack2(x0.x * r * bf(wn[k]), x0.y * r * bf(wn[k + 1]));
      v.y = pack2(x1.x * r * bf(wn[k + 8]), x1.y * r * bf(wn[k + 9]));
    }
    xf[i] = v;
  }
}

// ATT: attention units (b, kv head, chunk of CH keys); the last chunk computes and appends this position's K/V
__device__ void phase_att(const Ctx& c, Smem& sm, const App& a, int B, int pos) {
  const LayerW& L = c.L[a.layer];
  const int nkeys = L.glob ? pos + 1 : (pos + 1 < 1024 ? pos + 1 : 1024);
  const int kstart = pos + 1 - nkeys;
  const int nch = (nkeys + CH - 1) / CH;
  const int nunits = B * NKV * nch;
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31;
  float* qs = sm.misc;            // [3][128]
  float* rs = sm.misc + 384;      // [3][16]
  float* knew = sm.misc + 448;    // [128]
  float* vnew = sm.misc + 576;    // [128]
  float* bias = sm.misc + 704;    // [3][64]
  float* sc = sm.att;             // [3][64] scores -> probs
  float* ml = sm.att + 192;       // [3][2] max, sum
  float* opart = reinterpret_cast<float*>(sm.xf);  // [4][3][128]
  const float tau = 1.0f + 0.1f * logf(fmaxf(1.0f, (float)(pos + 1) / 8192.0f));
  const size_t ctxs = (size_t)c.maxctx * HD;
  for (int u = blockIdx.x; u < nunits; u += c.nb) {
    const int ch = u % nch, kvh = (u / nch) % NKV, b = u / (nch * NKV);
    const bf16* qr = c.qkv + (size_t)b * QKVLD;
    const int j0 = kstart + ch * CH, j1 = (j0 + CH < pos + 1) ? j0 + CH : pos + 1;
    const bool cur = (j1 == pos + 1);
    if (w < 3) {
      const int h = kvh * 3 + w;
      float v[4], ss = 0.f;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int d = lane * 4 + i;
        v[i] = ldbf_cg(qr + R_Q + h * HD + d) * bf(L.qscale[h * HD + d]);
        ss = fmaf(v[i], v[i], ss);
      }
      ss = warp_sum(ss);
      const float f = fminf(1.0f, 22.627416997969522f / (sqrtf(ss) + 1e-6f));
#pragma unroll
      for (int i = 0; i < 4; i++) {
        float y = rbf(v[i] * f);
        if (tau != 1.0f) y = rbf(y * tau);
        qs[w * HD + lane * 4 + i] = y;
      }
    } else if (w < 6) {
      const int hh = w - 3, h = kvh * 3 + hh;
      float v = 0.f;
      if (lane < 16) v = ldbf_cg(qr + R_R + h * 16 + lane) * bf(L.rscale[h * 16 + lane]);
      float ss = warp_sum(v * v);
      const float f = fminf(1.0f, 8.0f / (sqrtf(ss) + 1e-6f));
      float y = rbf(v * f);
      if (tau != 1.0f) y = rbf(y * tau);
      if (lane < 16) rs[hh * 16 + lane] = y;
    } else if (cur && w < 8) {
      const bool isv = (w == 7);
      const int roff = isv ? (L.glob ? R_K + 1056 : R_K + 1024) : R_K;
      bf16* hist = (isv ? c.hv : c.hk) + ((size_t)a.slot * MAXB + b) * 4 * KVW;
      const bf16* scw = isv ? L.vsc : L.ksc;
      float y[4], ss = 0.f;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int d = lane * 4 + i, chn = kvh * HD + d;
        const float xt = ldbf_cg(qr + roff + chn);
        const float x1 = ldbf_cg(hist + ((pos + 3) & 3) * KVW + chn);
        const float x2 = ldbf_cg(hist + ((pos + 2) & 3) * KVW + chn);
        const float x3 = ldbf_cg(hist + ((pos + 1) & 3) * KVW + chn);
        float acc;
        if (!L.glob) {
          acc = 0.f;
          acc = acc + x3 * bf(scw[chn * 4 + 0]);
          acc = acc + x2 * bf(scw[chn * 4 + 1]);
          acc = acc + x1 * bf(scw[chn * 4 + 2]);
          acc = acc + xt * bf(scw[chn * 4 + 3]);
          y[i] = rbf((acc + xt) * 0.44721359549995793f);
        } else {
          const bf16* dyn = qr + roff + 1024 + kvh * 4;
          acc = 0.f;
          acc = acc + xt * (bf(scw[0 * KVW + chn]) + ldbf_cg(dyn + 0));
          acc = acc + x1 * (bf(scw[1 * KVW + chn]) + ldbf_cg(dyn + 1));
          acc = acc + x2 * (bf(scw[2 * KVW + chn]) + ldbf_cg(dyn + 2));
          acc = acc + x3 * (bf(scw[3 * KVW + chn]) + ldbf_cg(dyn + 3));
          y[i] = rbf((acc + xt) * (1.0f / 3.0f));
        }
        hist[(pos & 3) * KVW + chn] = tobf(xt);
        ss = fmaf(y[i], y[i], ss);
      }
      ss = warp_sum(ss);
      float f;
      if (!isv) f = fminf(1.0f, 22.627416997969522f / (sqrtf(ss) + 1e-6f));
      else f = rsqrtf(ss / 128.0f + 1e-6f);
      bf16* dst = (isv ? c.vc : c.kc) + (((size_t)a.slot * MAXB + b) * NKV + kvh) * ctxs + (size_t)pos * HD;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const bf16 o = tobf(y[i] * f);
        dst[lane * 4 + i] = o;
        (isv ? vnew : knew)[lane * 4 + i] = bf(o);
      }
    }
    __syncthreads();
    // relative bias for this chunk
    if (tid < 3 * CH) {
      const int hh = tid / CH, jj = tid - hh * CH, j = j0 + jj;
      float bv = 0.f;
      if (j < j1) {
        const int dist = pos - j;
        if (dist < 1024) {
#pragma unroll
          for (int d = 0; d < 16; d++) bv = fmaf(rs[hh * 16 + d], bf(L.relp[d * 1024 + dist]), bv);
        }
      }
      bias[tid] = bv;
    }
    __syncthreads();
    // scores: 4 keys per warp
    const bf16* kb = c.kc + (((size_t)a.slot * MAXB + b) * NKV + kvh) * ctxs;
    const bf16* vb = c.vc + (((size_t)a.slot * MAXB + b) * NKV + kvh) * ctxs;
    for (int jj = w; jj < CH; jj += NWB) {
      const int j = j0 + jj;
      float s0 = 0.f, s1 = 0.f, s2 = 0.f;
      if (j < j1) {
        float k4[4];
        if (j == pos) {
#pragma unroll
          for (int i = 0; i < 4; i++) k4[i] = knew[lane * 4 + i];
        } else {
          uint2 r = __ldcg(reinterpret_cast<const uint2*>(kb + (size_t)j * HD + lane * 4));
          k4[0] = __uint_as_float(r.x << 16); k4[1] = __uint_as_float(r.x & 0xffff0000u);
          k4[2] = __uint_as_float(r.y << 16); k4[3] = __uint_as_float(r.y & 0xffff0000u);
        }
#pragma unroll
        for (int i = 0; i < 4; i++) {
          s0 = fmaf(qs[0 * HD + lane * 4 + i], k4[i], s0);
          s1 = fmaf(qs[1 * HD + lane * 4 + i], k4[i], s1);
          s2 = fmaf(qs[2 * HD + lane * 4 + i], k4[i], s2);
        }
      }
      s0 = warp_sum(s0); s1 = warp_sum(s1); s2 = warp_sum(s2);
      if (lane == 0) {
        const float scl = 0.08838834764831845f;
        const bool ok = j < j1;
        sc[0 * CH + jj] = ok ? s0 * scl + bias[0 * CH + jj] : -INFINITY;
        sc[1 * CH + jj] = ok ? s1 * scl + bias[1 * CH + jj] : -INFINITY;
        sc[2 * CH + jj] = ok ? s2 * scl + bias[2 * CH + jj] : -INFINITY;
      }
    }
    __syncthreads();
    if (w < 3) {
      float a0 = sc[w * CH + lane], a1 = sc[w * CH + 32 + lane];
      float m = warp_max(fmaxf(a0, a1));
      float p0 = expf(a0 - m), p1 = expf(a1 - m);
      float l = warp_sum(p0 + p1);
      sc[w * CH + lane] = p0; sc[w * CH + 32 + lane] = p1;
      if (lane == 0) { ml[w * 2] = m; ml[w * 2 + 1] = l; }
    }
    __syncthreads();
    {
      const int d = tid & 127, kg = tid >> 7;  // 4 groups of 16 keys
      float o0 = 0.f, o1 = 0.f, o2 = 0.f;
      for (int jj = kg * 16; jj < kg * 16 + 16; jj++) {
        const int j = j0 + jj;
        if (j < j1) {
          const float vv = (j == pos) ? vnew[d] : ldbf_cg(vb + (size_t)j * HD + d);
          o0 = fmaf(sc[0 * CH + jj], vv, o0);
          o1 = fmaf(sc[1 * CH + jj], vv, o1);
          o2 = fmaf(sc[2 * CH + jj], vv, o2);
        }
      }
      opart[(kg * 3 + 0) * HD + d] = o0;
      opart[(kg * 3 + 1) * HD + d] = o1;
      opart[(kg * 3 + 2) * HD + d] = o2;
    }
    __syncthreads();
    float* ap = c.apart + (((size_t)b * NKV + kvh) * c.maxch + ch) * (3 * 132);
    if (tid < 384) {
      const int hh = tid >> 7, d = tid & 127;
      const float o = ((opart[(0 * 3 + hh) * HD + d] + opart[(1 * 3 + hh) * HD + d]) + opart[(2 * 3 + hh) * HD + d]) +
                      opart[(3 * 3 + hh) * HD + d];
      __stcg(ap + hh * 132 + d, o);
      if (d == 0) { __stcg(ap + hh * 132 + 128, ml[hh * 2]); __stcg(ap + hh * 132 + 129, ml[hh * 2 + 1]); }
    }
    __threadfence();
    __syncthreads();
    if (tid == 0) {
      unsigned old = atomicAdd(&c.acnt[b * NKV + kvh], 1u);
      sm.nu = (old == (unsigned)nch - 1);
      if (old == (unsigned)nch - 1) c.acnt[b * NKV + kvh] = 0;
    }
    __syncthreads();
    if (sm.nu) {
      __threadfence();
      if (tid < 384) {
        const int hh = tid >> 7, d = tid & 127, h = kvh * 3 + hh;
        const float* a0 = c.apart + (((size_t)b * NKV + kvh) * c.maxch) * (3 * 132) + hh * 132;
        float M = -INFINITY;
        for (int q = 0; q < nch; q++) M = fmaxf(M, __ldcg(a0 + q * 396 + 128));
        float Ls = 0.f, O = 0.f;
        for (int q = 0; q < nch; q++) {
          const float e = expf(__ldcg(a0 + q * 396 + 128) - M);
          Ls = fmaf(__ldcg(a0 + q * 396 + 129), e, Ls);
          O = fmaf(__ldcg(a0 + q * 396 + d), e, O);
        }
        float out = O / Ls;
        const float lse = M + logf(Ls);
        out = out * sigm(ldbf_cg(qr + R_G + h * HD + d));
        out = out * sigm(lse - ldbf_cg(qr + R_S + h));
        __stcg(reinterpret_cast<unsigned short*>(c.attn_o + (size_t)b * QW + h * HD + d), __bfloat16_as_ushort(tobf(out)));
      }
    }
    __syncthreads();
  }
}

// ------------------------------------------------------------------------------------------------ epilogues
struct EpiQKV {
  bf16* out; int B;
  __device__ __forceinline__ void operator()(int s, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3, r0 = s * 16 + g;
    const int b0 = 2 * t, b1 = 2 * t + 1;
    if (b0 < B) { out[(size_t)b0 * QKVLD + r0] = tobf(d[0]); out[(size_t)b0 * QKVLD + r0 + 8] = tobf(d[2]); }
    if (b1 < B) { out[(size_t)b1 * QKVLD + r0] = tobf(d[1]); out[(size_t)b1 * QKVLD + r0 + 8] = tobf(d[3]); }
  }
};
__device__ __forceinline__ float sconv_static(float xt, float x1, float x2, float x3, const bf16* w4) {
  float acc = 0.f;
  acc = acc + x3 * bf(w4[0]);
  acc = acc + x2 * bf(w4[1]);
  acc = acc + x1 * bf(w4[2]);
  acc = acc + xt * bf(w4[3]);
  return rbf((acc + xt) * 0.44721359549995793f);
}
struct EpiO {   // o-proj -> bf16 -> attn sconv -> attn_s
  const Ctx* c; const bf16* w; int slot, pos, B;
  __device__ __forceinline__ void operator()(int s, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      const int b = 2 * t + (i & 1), r = s * 16 + g + 8 * (i >> 1);
      if (b >= B) continue;
      bf16* hist = c->ha + ((size_t)slot * MAXB + b) * 4 * H;
      const float xt = rbf(d[i]);
      const float x1 = ldbf_cg(hist + ((pos + 3) & 3) * H + r), x2 = ldbf_cg(hist + ((pos + 2) & 3) * H + r),
                  x3 = ldbf_cg(hist + ((pos + 1) & 3) * H + r);
      hist[(pos & 3) * H + r] = tobf(xt);
      c->attn_s[(size_t)b * H + r] = tobf(sconv_static(xt, x1, x2, x3, w + r * 4));
    }
  }
};
struct EpiF32 {   // fp32 out[b][ld], row offset
  float* out; int ld, B;
  __device__ __forceinline__ void operator()(int s, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3, r0 = s * 16 + g;
    if (2 * t < B) { __stcg(out + (size_t)(2 * t) * ld + r0, d[0]); __stcg(out + (size_t)(2 * t) * ld + r0 + 8, d[2]); }
    if (2 * t + 1 < B) { __stcg(out + (size_t)(2 * t + 1) * ld + r0, d[1]); __stcg(out + (size_t)(2 * t + 1) * ld + r0 + 8, d[3]); }
  }
};
struct EpiZ {    // gate down projection: rows [ctrl][64]; z = acc + zm
  float* zb; const float* zm; int B; int w0;
  __device__ __forceinline__ void operator()(int s, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3;
    const int w = w0 + (s >> 2), r = (s & 3) * 16 + g;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      const int b = 2 * t + (i & 1), rr = r + 8 * (i >> 1);
      if (b < B) __stcg(zb + ((size_t)w * MAXB + b) * 64 + rr, d[i] + __ldcg(zm + ((size_t)w * MAXB + b) * 64 + rr));
    }
  }
};
struct EpiZM {   // message part of the gates: rows [12][4][64]
  float* zm; int B;
  __device__ __forceinline__ void operator()(int s, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3;
    const int lw = s >> 2, r = (s & 3) * 16 + g;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      const int b = 2 * t + (i & 1), rr = r + 8 * (i >> 1);
      if (b < B) __stcg(zm + ((size_t)lw * MAXB + b) * 64 + rr, d[i]);
    }
  }
};
struct EpiW13 {
  uint2* act; const Smem* sm; const float* f13; int mx, B;
  __device__ __forceinline__ void operator()(int S, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3;
    const int us = S / 144, s = S - us * 144;
    const int e = sm->uni[us];
    const float f = mx ? 1.0f : f13[e];
    const int k = s * 8 + g;
    uint16_t* a16 = reinterpret_cast<uint16_t*>(act + (size_t)us * 72 * 32);
#pragma unroll
    for (int i = 0; i < 2; i++) {
      const int b = 2 * t + i;
      if (b >= B) continue;
      const float wt = sm->wsel[us][b];
      float v = 0.f;
      if (wt != 0.f) {
        const float gg = d[i] * f, uu = d[2 + i] * f;
        v = 4.0f * tanhf(gg * 0.25f) * sigm(gg);
        v = v * (25.0f * tanhf(uu * 0.04f));
        v = v * wt;
      }
      a16[frag_word(k & ~1, b) * 2 + (k & 1)] = __bfloat16_as_ushort(tobf(v));
    }
  }
};
struct EpiW2 {   // mlp_raw -> bf16 -> mlp sconv -> finalize partial
  const Ctx* c; const bf16* w; int slot, pos, B, pin, pout, boundary;
  __device__ __forceinline__ void operator()(int s, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      const int b = 2 * t + (i & 1), r = s * 16 + g + 8 * (i >> 1);
      if (b >= B) continue;
      bf16* hist = c->hm + ((size_t)slot * MAXB + b) * 4 * H;
      const float xt = rbf(d[i]);
      const float x1 = ldbf_cg(hist + ((pos + 3) & 3) * H + r), x2 = ldbf_cg(hist + ((pos + 2) & 3) * H + r),
                  x3 = ldbf_cg(hist + ((pos + 1) & 3) * H + r);
      hist[(pos & 3) * H + r] = tobf(xt);
      const float mo = sconv_static(xt, x1, x2, x3, w + r * 4);
      const float at = ldbf_cg(c->attn_s + (size_t)b * H + r);
      float v;
      if (boundary) v = at + mo;
      else v = (ldbf_cg(c->blk + ((size_t)pin * MAXB + b) * H + r) + at) + mo;
      c->blk[((size_t)pout * MAXB + b) * H + r] = tobf(v);
    }
  }
};
struct EpiLogit {
  float* out; int B;
  __device__ __forceinline__ void operator()(int s, int lane, const float* d) const {
    const int g = lane >> 2, t = lane & 3, r0 = s * 16 + g;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      const int b = 2 * t + (i & 1), r = r0 + 8 * (i >> 1);
      if (b < B) out[(size_t)b * VOCAB + r] = 30.0f * tanhf(d[i] * (1.0f / 30.0f));
    }
  }
};

// ------------------------------------------------------------------------------------------------ routing
__device__ void topk_union(const Ctx& c, Smem& sm, const LayerW& L, int B) {
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  if (w < B) {
    float lg[4], sel[4];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      lg[j] = __ldcg(c.rlog + (size_t)w * NE + lane + 32 * j);
      sel[j] = sigm(lg[j]) + L.rbias[lane + 32 * j];
    }
    float tot = 0.f;
    float chosen[TOPK]; int cid[TOPK];
    for (int k = 0; k < TOPK; k++) {
      float bv = -INFINITY; int bi = 1 << 30;
#pragma unroll
      for (int j = 0; j < 4; j++) if (sel[j] > bv) { bv = sel[j]; bi = lane + 32 * j; }
#pragma unroll
      for (int o = 16; o; o >>= 1) {
        float ov = __shfl_xor_sync(~0u, bv, o); int oi = __shfl_xor_sync(~0u, bi, o);
        if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
      }
      cid[k] = bi;
      float lv = 0.f;
#pragma unroll
      for (int j = 0; j < 4; j++) if (lane + 32 * j == bi) { lv = lg[j]; sel[j] = -INFINITY; }
      lv = __shfl_sync(~0u, lv, bi & 31);
      chosen[k] = sigm(lv);
      tot += chosen[k];
    }
    if (lane == 0) {
      for (int k = 0; k < TOPK; k++) { sm.ids[w][k] = cid[k]; sm.wts[w][k] = chosen[k] / tot * 8.0f; }
    }
  }
  __syncthreads();
  if (threadIdx.x < 32) {
    // union bitmask over 128 experts: lane owns experts 4*lane..4*lane+3
    unsigned m = 0;
    for (int b = 0; b < B; b++)
      for (int k = 0; k < TOPK; k++) { const int e = sm.ids[b][k]; if ((e >> 2) == lane) m |= 1u << (e & 3); }
    const int cnt = __popc(m);
    int pre = cnt;
#pragma unroll
    for (int o = 1; o < 32; o <<= 1) { int v = __shfl_up_sync(~0u, pre, o); if (lane >= o) pre += v; }
    pre -= cnt;
    for (int j = 0; j < 4; j++) if (m & (1u << j)) { sm.uni[pre] = lane * 4 + j; pre++; }
    if (lane == 31) sm.nu = pre;
  }
  __syncthreads();
  for (int i = threadIdx.x; i < MAXU * MAXB; i += NT) {
    const int us = i / MAXB, b = i - us * MAXB;
    float wt = 0.f;
    if (us < sm.nu && b < B) {
      const int e = sm.uni[us];
      for (int k = 0; k < TOPK; k++) if (sm.ids[b][k] == e) wt = sm.wts[b][k];
    }
    sm.wsel[us][b] = wt;
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ the step
__global__ void __launch_bounds__(NT, 1) mini_step(const Ctx* __restrict__ cp, int B, int pos, const long long* tokens, float* logits) {
  extern __shared__ __align__(16) unsigned char smraw[];
  Smem& sm = *reinterpret_cast<Smem*>(smraw);
  const Ctx& c = *cp;
#ifdef MKPROF
  if (threadIdx.x == 0) g_pn_s = 0;
#endif
  PMARK(MKPROF_STEP);
  for (int ai = 0; ai < NAPP; ai++) {
    const App& a = c.A[ai];
    const LayerW& L = c.L[a.layer];
    if (a.msg_prev_a >= 0) {
      PMARK(1); phase_msg(c, sm, a, B);
      PMARK(MKPROF_WAIT); grid_bar(c);
      PMARK(2); LdBFg ld{c.dm, U_H, c.mfrag, 4};
      gemv(c, 192, U_H, 1 << 30, ld, EpiZM{c.zm, B});
      PMARK(MKPROF_WAIT); grid_bar(c);
    }
    // ---- attention input
    PMARK(3); phase_mixa(c, sm, a, B, tokens);
    PMARK(MKPROF_WAIT); grid_bar(c);
    if (a.gate) {
      PMARK(4); LdBFg ld{L.dx, U_H, c.ufrag, 4};
      gemv(c, 12, U_H, 108, ld, EpiZ{c.zb, c.zm + (size_t)a.lloop * 4 * MAXB * 64, B, 0});
      PMARK(MKPROF_WAIT); grid_bar(c);
      PMARK(5); phase_gx(c, sm, a, B, 0, 3);
      PMARK(MKPROF_WAIT); grid_bar(c);
      for (int st = 0; st < 3; st++) frag_from_gated(c, sm, st, st, L.norm[st], B);
    } else {
      frag_from_bf16(sm.xf, c.xin, H, L.glob ? 3 : 1, KS_H, B, KS_H * 32);
    }
    __syncthreads();
    {
      PMARK(6); const int nst = (a.gate || L.glob) ? 3 : 1;
      LdBF ld{L.wqkv, U_H, sm.xf, nst > 1 ? L.s_k : 1 << 30, nst > 1 ? L.s_v : 1 << 30, KS_H * 32};
      gemv(c, L.nqkv_strips, U_H, 1 << 30, ld, EpiQKV{c.qkv, B});
    }
    PMARK(MKPROF_WAIT); grid_bar(c);
    PMARK(7); phase_att(c, sm, a, B, pos);
    PMARK(MKPROF_WAIT); grid_bar(c);
    PMARK(8); frag_from_bf16(sm.xf, c.attn_o, QW, 1, QW / 16, B, 0);
    __syncthreads();
    {
      LdBF ld{L.wo, QW / 64, sm.xf, 1 << 30, 1 << 30, 0};
      gemv(c, H / 16, QW / 64, 1 << 30, ld, EpiO{&c, L.asc, a.slot, pos, B});
    }
    PMARK(MKPROF_WAIT); grid_bar(c);
    // ---- mlp input
    PMARK(9); phase_mixm(c, sm, a, B);
    PMARK(MKPROF_WAIT); grid_bar(c);
    if (a.gate) {
      const LayerW& LL = L;
      PMARK(10); LdBFg ld{LL.dx + (size_t)12 * U_H * 128, U_H, c.ufrag + (size_t)3 * KS_H * 32, 4};
      gemv(c, 4, U_H, 36, ld, EpiZ{c.zb, c.zm + (size_t)a.lloop * 4 * MAXB * 64, B, 3});
      PMARK(MKPROF_WAIT); grid_bar(c);
      PMARK(11); phase_gx(c, sm, a, B, 3, 1);
      PMARK(MKPROF_WAIT); grid_bar(c);
      frag_from_gated(c, sm, 3, 0, L.mlp_norm, B);
      __syncthreads();
      if (blockIdx.x == 0) {  // normalized mlp input for the experts
        for (int i = threadIdx.x; i < KS_H * 32; i += NT) {
          const int ks = i >> 5, lane = i & 31, b = lane >> 2, t = lane & 3;
          if (b < B) {
            uint2 v = sm.xf[i];
            unsigned* d = reinterpret_cast<unsigned*>(c.xin + (size_t)b * H + ks * 16 + 2 * t);
            __stcg(d, v.x); __stcg(d + 4, v.y);
          }
        }
      }
    } else {
      frag_from_bf16(sm.xf, c.xin, H, 1, KS_H, B, KS_H * 32);
    }
    __syncthreads();
    {
      PMARK(12); LdBF ld{L.wr, U_H, sm.xf, 1 << 30, 1 << 30, 0};
      gemv(c, 8, U_H, 72, ld, EpiF32{c.rlog, NE, B});
    }
    PMARK(MKPROF_WAIT); grid_bar(c);
    PMARK(13); topk_union(c, sm, L, B);
    frag_from_bf16(sm.xf, c.xin, H, 1, KS_H, B, KS_H * 32);
    __syncthreads();
    {
      LdW13 ld{L.w13, L.mx, sm.uni, sm.xf};
      gemv(c, sm.nu * 144, U_H, 1 << 30, ld, EpiW13{c.actf, &sm, L.f13, L.mx, B});
    }
    PMARK(MKPROF_WAIT); grid_bar(c);
    {
      PMARK(14); LdW2 ld{L.w2, L.mx, sm.uni, c.actf, L.f2};
      gemv(c, 144, sm.nu * 18, 1 << 30, ld, EpiW2{&c, L.msc, a.slot, pos, B, a.pin, a.pout, a.boundary});
    }
    PMARK(MKPROF_WAIT); grid_bar(c);
  }
  PMARK(15); phase_mixf(c, sm, B);
  PMARK(MKPROF_WAIT); grid_bar(c);
  frag_from_bf16(sm.xf, c.xin, H, 1, KS_H, B, KS_H * 32);
  __syncthreads();
  {
    PMARK(16); LdBF ld{c.unembed, U_H, sm.xf, 1 << 30, 1 << 30, 0};
    gemv(c, VOCAB / 16, U_H, 1 << 30, ld, EpiLogit{logits, B});
  }
  __syncthreads();
  PMARK(MKPROF_WAIT);
}

// ------------------------------------------------------------------------------------------------ host API
static Ctx* g_dctx = nullptr;
static int g_nb = 0;

extern "C" int mini_init(const Ctx* host_ctx) {
  if (!g_dctx) { if (cudaMalloc(&g_dctx, sizeof(Ctx)) != cudaSuccess) return -1; }
  int dev = 0, nsm = 0;
  cudaGetDevice(&dev);
  cudaDeviceGetAttribute(&nsm, cudaDevAttrMultiProcessorCount, dev);
  cudaFuncSetAttribute(mini_step, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)sizeof(Smem));
  int per = 0;
  cudaOccupancyMaxActiveBlocksPerMultiprocessor(&per, mini_step, NT, sizeof(Smem));
  if (per < 1) return -2;
  g_nb = nsm;
  Ctx h = *host_ctx;
  h.nb = g_nb;
  if (cudaMemcpy(g_dctx, &h, sizeof(Ctx), cudaMemcpyHostToDevice) != cudaSuccess) return -3;
  return g_nb;
}
extern "C" int mini_sizes(int* out) {
  out[0] = sizeof(Ctx); out[1] = sizeof(LayerW); out[2] = sizeof(App); out[3] = sizeof(Smem);
  return 0;
}
extern "C" int mini_launch(int B, int pos, const long long* tokens, float* logits, cudaStream_t stream) {
  void* args[] = {(void*)&g_dctx, (void*)&B, (void*)&pos, (void*)&tokens, (void*)&logits};
  cudaError_t e = cudaLaunchCooperativeKernel((void*)mini_step, dim3(g_nb), dim3(NT), args, sizeof(Smem), stream);
  return (int)e;
}
extern "C" int mini_set_prof(void* buf, unsigned cap) {
  MkProf p{(unsigned long long*)buf, cap};
  return (int)cudaMemcpyToSymbol(g_prof, &p, sizeof(p));
}
extern "C" const char* mini_err(int e) { return cudaGetErrorString((cudaError_t)e); }
