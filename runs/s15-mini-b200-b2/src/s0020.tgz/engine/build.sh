#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
rm -f build/${MK_LIBNAME:-libmk.so}
# build switch: engine/TRACK (or $MK_TRACK): "A" = the checkpoint's formats and data flow; "B <items>" adds track-B items
TRACKV=${MK_TRACK:-$(cat TRACK 2>/dev/null || echo A)}
DEFS="${MK_DEFS:-}"
case " $TRACKV " in *" W12U "*|*" W12 "*) DEFS="$DEFS -DW12U=1";; esac
case " $TRACKV " in *" MSGZ "*) DEFS="$DEFS -DMSGZ=1";; esac
case " $TRACKV " in *" MSGZP "*) DEFS="$DEFS -DMSGZ=1 -DMSGZ_PIPE=1";; esac
case " $TRACKV " in *" SKH "*) DEFS="$DEFS -DSKH=1";; esac
case " $TRACKV " in *" L0T "*) DEFS="$DEFS -DL0T=1";; esac
case " $TRACKV " in *" W12Q "*) DEFS="$DEFS -DW12Q=1";; esac
case " $TRACKV " in *" S6 "*) DEFS="$DEFS -DS6=1";; esac
case " $TRACKV " in *" XPF "*) DEFS="$DEFS -DXPF=1";; esac
case " $TRACKV " in *" XPF1 "*) DEFS="$DEFS -DXPF=1 -DXPF_MINB=1";; esac
LIB=${MK_LIBNAME:-libmk.so}
B1=0
# track A (K1): a second library with the kernel compiled for batch 1 only (same source, -DKB1=1); B1DEFS are the
# settings of that kernel alone (${MK_DEFS_B1} overrides them)
case " $TRACKV " in *" K1 "*) B1=1;; esac
B1DEFS="${MK_DEFS_B1-}"
rm -f build/${LIB%.so}_b1.so
if [ "$B1" = 1 ]; then
  nvcc -O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xcompiler -fPIC -shared -Xptxas -v ${MK_CFLAGS:-} $DEFS -DKB1=1 $B1DEFS \
    -o build/${LIB%.so}_b1.so mk.cu 2> build/ptxas_b1.log &
  PB1=$!
fi
nvcc -O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xcompiler -fPIC -shared -Xptxas -v ${MK_CFLAGS:-} $DEFS \
  -o build/$LIB mk.cu 2> build/ptxas.log || { cat build/ptxas.log; exit 1; }
if [ "$B1" = 1 ]; then wait $PB1 || { cat build/ptxas_b1.log; exit 1; }; fi
grep -E "mk_step|registers|spill" build/ptxas.log | head -8 || true
