// Inkling-2-Mini decode megakernel for one B200 (sm_100a). One persistent cooperative kernel per call
// (152 blocks x 256 threads, one block per SM); a call runs one or more decode steps of B <= 8 sequences.
//
// Track A: weights as stored (BF16; NVFP4 experts = E2M1 codes x E4M3 scale per 16 x per-expert fp32 factor;
// MXFP8 experts = E4M3 x UE8M0 per 32), re-laid at load time (a permutation of the stored bytes). Expert inputs are
// NOT quantized: the weights are decoded exactly to BF16 in registers (code x block scale is exact in BF16) and
// multiplied with the BF16 activations on the tensor cores (fp32 accumulation); the NVFP4 per-expert factor is
// applied in fp32 to the sum. Tensors that the specification materialises in BF16 are BF16 here as well.
//
// Every matrix-vector product is a chain of mma.m16n8k16 (bf16 x bf16 -> f32); the 8 columns of the B operand are the
// sequences. Weights stream through per-warp rings in shared memory filled by bulk copies (cp.async.bulk + mbarrier).
//
// Per layer application (grid barrier between phases):
//   [M]  start of loop passes 2, 3: the 48 messages of the pass (attention over depth of the previous pass)
//   [A0] loop passes 2,3: attention-input mixes; rank-64 gate inputs z of the q/k/v message gates
//   [A1] loop passes 2,3: gated inputs x' = (1 - tanh(F z)) x + tanh(G z) m, a slice per block
//   A    q/k/v input norms (every block, into smem) + one GEMV for q|r|gate|sink|k|(dk)|v|(dv)
//   B    attention: (sequence, kv head, 64-key chunk) items; K/V conv + clip/norm of the new position; partials
//        merged by the last-arriving chunk; output gate, sink
//   C    o_proj + attention short conv -> attn_s
//   [D0, D1] loop passes 2,3: the MLP-input message gate as A0/A1
//   D    MLP-input mix + norm (every block, smem) ; router GEMV on blocks 0..7
//   E    top-8 (every block), union of experts, w13 of the union (exact NVFP4/MXFP8 decode), activation
//   F    w2 per owned rowtile over all chosen experts, weighted sum, MLP short conv, new partial sum
// Head: final mix + norm, unembedding GEMV, 30 tanh(z / 30) -> logits (or the device argmax).
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef unsigned u32;
typedef unsigned short u16;
typedef unsigned long long u64;
typedef __nv_bfloat16 bf16;

#define H 2304
#define NL 24
#define NAPP 48
#define NQH 24
#define NKV 8
#define HD 128
#define QW 3072
#define KVW 1024
#define DREL 16
#define RELEXT 1024
#define WIN 1024
#define NE 128
#define TOPK 8
#define IM 1152
#define VOCAB 200058
#define RT_HEAD 12504
#define NB 152
#ifndef XPF
#define XPF 0
#endif
#ifndef W12U
#define W12U 0
#endif
#define NT 256
#define NW (NT / 32)
#define MAXB 8
#define MAXU 64
#define KS_H 144
#define KS_A 192
#define XSH (H + 8)
#define XSA (QW + 8)
#define XSI (IM + 8)
#define CH 64
#define MAXCH 64
#define NVEC 9
#define V_H0 0
#define V_P0 1
#define V_P1 2
#define V_P2 5
#define V_P3 8
#define SRC_AS 16
#define SRC_SUM 32
// qkv rowtiles: q 0..191, r 192..215, gate 216..407, sink 408..409 (24 rows + 8 zero), k 410..473, then
// local: v 474..537 (538) ; global: dk 474..475, v 476..539, dv 540..541 (542)
#define RT_K 410
#define OFF_R (192 * 16)
#define OFF_G (216 * 16)
#define OFF_S (408 * 16)
#define OFF_K (410 * 16)
#define OFF_DK (474 * 16)
#define QKVW (542 * 16)
#define ACC_STRIDE 136

struct LayerP {
  const uint4* wqkv; const uint4* wo; const uint4* wr; const float* rbias;
  const uint4* w13c; const unsigned char* w13s; const uint4* w2c; const unsigned char* w2s;
  const float* f13; const float* f2;
  long long mx, glob, loop;
  const bf16* nq; const bf16* nk; const bf16* nv; const bf16* nm;
  const bf16* ksc; const bf16* vsc; const bf16* asc; const bf16* msc;
  const bf16* qscale; const bf16* rscale; const bf16* relp;
  const float* aq; const float* mq;
  const bf16* cD; const bf16* cF; const bf16* cG;
  long long nrt;
  long long pad0, pad1;
};

struct Params {
  LayerP L[NL];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm; const uint4* unembed; const float* lq;
  bf16* vecs; bf16* qkvo; bf16* attn_out; bf16* attn_s; bf16* act; float* rlog; float* zb; float* xg; float* msg;
  float* msgir; float* apart; u32* acnt; bf16* kc; bf16* vc; bf16* rk; bf16* rv; bf16* ro; bf16* rm; u32* bar;
  float* amv; int* ami;
  long long maxctx;
  int* rhist;             // track B (XPF): expert union of every application of the last step [NAPP][MAXU + 1]
  const unsigned char* u12base;   // track B (W12): unembedding row bases [VOCAB rows padded]
  const int* u12off;              // [RT_HEAD + 1] escape offsets per rowtile
  const uint2* u12esc;            // (key = kstep << 8 | lane << 3 | reg << 1 | half, exact bf16 bits)
  long long pad[1];
};

struct RunArgs {
  const long long* tok;   // [B] input tokens of the first step
  float* logits;          // mode 0: [B][VOCAB]
  long long* out_tok;     // mode 1: [B][nsteps]
  int* host_tok; volatile int* host_prog;
  int B, pos0, nsteps, mode;
  int stop_app;           // debug: stop after this many applications (NAPP = full)
  int pad;
};

// ------------------------------------------------------------------------------------------------ primitives
__device__ __forceinline__ void mma16816(float* c, u32 a0, u32 a1, u32 a2, u32 a3, u32 b0, u32 b1) {
  asm("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3},{%4,%5,%6,%7},{%8,%9},{%0,%1,%2,%3};"
      : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ uint4 ldcg128(const void* p) {
  uint4 r; asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3},[%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p)); return r;
}
__device__ __forceinline__ uint2 ldcg64(const void* p) {
  uint2 r; asm volatile("ld.global.cg.v2.u32 {%0,%1},[%2];" : "=r"(r.x), "=r"(r.y) : "l"(p)); return r;
}
__device__ __forceinline__ u32 ldcg32(const void* p) { u32 r; asm volatile("ld.global.cg.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ float ldcgf(const float* p) { float r; asm volatile("ld.global.cg.f32 %0,[%1];" : "=f"(r) : "l"(p)); return r; }
__device__ __forceinline__ int ldcgi(const int* p) { int r; asm volatile("ld.global.cg.s32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ u16 ldcg16(const void* p) { u16 r; asm volatile("ld.global.cg.u16 %0,[%1];" : "=h"(r) : "l"(p)); return r; }
__device__ __forceinline__ u32 ld_acquire(const u32* p) { u32 r; asm volatile("ld.acquire.gpu.global.u32 %0,[%1];" : "=r"(r) : "l"(p)); return r; }
__device__ __forceinline__ void cvt4(u32 x, u32& r0, u32& r1, u32& r2, u32& r3) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4; cvt.rn.bf16x2.e2m1x2 %0, b0; cvt.rn.bf16x2.e2m1x2 %1, b1;"
      " cvt.rn.bf16x2.e2m1x2 %2, b2; cvt.rn.bf16x2.e2m1x2 %3, b3; }"
      : "=r"(r0), "=r"(r1), "=r"(r2), "=r"(r3) : "r"(x));
}
// two E4M3 (low byte -> low half) to f16x2, exact
__device__ __forceinline__ u32 e4m3x2_f16x2(u32 v16) {
  u32 r; asm("{ .reg .b16 t; cvt.u16.u32 t, %1; cvt.rn.f16x2.e4m3x2 %0, t; }" : "=r"(r) : "r"(v16)); return r;
}
// f16x2 holding E4M3 values -> bf16x2 bits of value * 2^-112 (normal, exact)
__device__ __forceinline__ u32 f16e4_to_bf(u32 h) { return ((h >> 3) & 0x0FFF0FFFu) | (h & 0x80008000u); }
__device__ __forceinline__ u32 hmul2u(u32 a, u32 b) {
  u32 r; asm("mul.rn.bf16x2 %0, %1, %2;" : "=r"(r) : "r"(a), "r"(b)); return r;
}
__device__ __forceinline__ u32 prmt(u32 a, u32 b, u32 s) { u32 r; asm("prmt.b32 %0, %1, %2, %3;" : "=r"(r) : "r"(a), "r"(b), "r"(s)); return r; }
__device__ __forceinline__ float bfr(float v) { return __bfloat162float(__float2bfloat16_rn(v)); }
__device__ __forceinline__ float u16f(u16 v) { return __uint_as_float(((u32)v) << 16); }
__device__ __forceinline__ u16 f2u16(float v) { bf16 h = __float2bfloat16_rn(v); return *reinterpret_cast<u16*>(&h); }
__device__ __forceinline__ float bf2f(bf16 v) { return __bfloat162float(v); }
__device__ __forceinline__ float ldgbf(const bf16* p) { return __bfloat162float(__ldg(p)); }
__device__ __forceinline__ float warp_sum(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v += __shfl_xor_sync(0xffffffffu, v, o);
  return v;
}
__device__ __forceinline__ float warp_max(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, o));
  return v;
}
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }

__device__ __forceinline__ void grid_bar(u32* ctr, u32& target) {
  __syncthreads();
  target += NB;
  if (threadIdx.x == 0) {
    __threadfence();
    atomicAdd(ctr, 1u);
    while (ld_acquire(ctr) < target) { }
  }
  __syncthreads();
}

// block-wide sum, same order in every thread (all threads must call)
__device__ __forceinline__ float block_sum(float v, float* scr) {
  v = warp_sum(v);
  __syncthreads();
  if ((threadIdx.x & 31) == 0) scr[threadIdx.x >> 5] = v;
  __syncthreads();
  float r = 0.f;
#pragma unroll
  for (int w = 0; w < NW; w++) r += scr[w];
  return r;
}

// ------------------------------------------------------------------------------------------------ TMA task runner
// (after the gpt-oss-120b engine of run s12) Every warp streams its weights through its own ring of RS stages in shared
// memory, filled by bulk copies issued by lane 0. A task = n consecutive items of one rowtile:
//   KIND 0  bf16: item = one kstep (16 columns) = 512 B tile in A-fragment order
//   KIND 1  nvfp4: item = 64 columns: 512 B codes [32 lanes][4 ksteps][4 regs] + 64 B E4M3 scales [8 g][4 ksteps][2]
//   KIND 2  mxfp8: item = 32 columns: 512 B codes [32 lanes][2 ksteps][4 regs][2] + 16 B UE8M0 scales [8 g][2]
#define RS 3
#ifndef RI
#define RI 6
#endif
#define IBYTES 512
#define ITEM 576
#define RING_WARP (RS * RI * ITEM)
static_assert(9 * 384 <= RI * ITEM, "w12 stage");
struct TD { const uint4* w; const unsigned char* s; const u16* x; int n; int slot; u32 bm; u64 rows8; int k0; };
struct TT { const uint4* w; const unsigned char* s; const u16* x; u64 rows8; int n; int slot; u32 bm; int k0; };
#define ROWS_ID 0x0706050403020100ull

__device__ __forceinline__ u32 smaddr(const void* p) { return (u32)__cvta_generic_to_shared(p); }
__device__ __forceinline__ void mbar_init(u32 b, u32 n) { asm volatile("mbarrier.init.shared::cta.b64 [%0], %1;" :: "r"(b), "r"(n)); }
__device__ __forceinline__ void mbar_expect(u32 b, u32 bytes) {
  asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%0], %1;" :: "r"(b), "r"(bytes) : "memory");
}
__device__ __forceinline__ void mbar_wait(u32 b, u32 ph) {
  asm volatile("{ .reg .pred p; W%=: mbarrier.try_wait.parity.shared::cta.b64 p, [%0], %1; @!p bra W%=; }" :: "r"(b), "r"(ph) : "memory");
}
__device__ __forceinline__ void tma_load(u32 dst, const void* src, u32 bytes, u32 bar) {
  asm volatile("cp.async.bulk.shared::cta.global.mbarrier::complete_tx::bytes.L2::cache_hint [%0], [%1], %2, [%3], %4;"
               :: "r"(dst), "l"(src), "r"(bytes), "r"(bar), "l"(0x12F0000000000000ull) : "memory");
}
struct Ring { u32 data; u32 bars; u32 pos; };
struct PState { int nt, pt, pi, kind; u32 issued; int pad[3]; };

template <int KIND> struct KindInfo;
template <> struct KindInfo<0> { static constexpr int SB = 0; };
template <> struct KindInfo<1> { static constexpr int SB = 64; };
template <> struct KindInfo<2> { static constexpr int SB = 16; };
template <> struct KindInfo<3> { static constexpr int SB = 0; };   // W12 (track B): 384 B items, no scale stream
template <int KIND> struct KindIB { static constexpr int IB = 512; static constexpr int NI = RI; };
#ifndef RI3
#define RI3 9
#endif
template <> struct KindIB<3> { static constexpr int IB = 384; static constexpr int NI = RI3; };   // 9 x 384 = one stage

template <int KIND>
__device__ __forceinline__ void issue_stage(const TT* tt, PState& ps, const Ring& rg, int lane) {
  constexpr int SB = KindInfo<KIND>::SB;
  const u32 sidx = ps.issued % RS;
  const u32 bar = rg.bars + sidx * 8, dst = rg.data + sidx * (RI * ITEM);
  const TT& q = tt[ps.pt];
  const int m = min(KindIB<KIND>::NI, q.n - ps.pi);
  if (lane == 0) {
    constexpr int IB = KindIB<KIND>::IB;
    mbar_expect(bar, m * (IB + SB));
    tma_load(dst, q.w + (size_t)ps.pi * (IB / 16), m * IB, bar);
    if (SB) tma_load(dst + RI * IBYTES, q.s + (size_t)ps.pi * SB, m * SB, bar);
  }
  ps.pi += m;
  if (ps.pi == q.n) { ps.pt++; ps.pi = 0; }
  ps.issued++;
}

template <int KIND, class Desc>
__device__ __forceinline__ void prefetch_tasks(int ntask, TT* table, const Ring& rg, PState& ps, Desc desc) {
  const int warp = threadIdx.x >> 5, lane = threadIdx.x & 31;
  const int nt = (ntask > warp) ? (ntask - warp + NW - 1) / NW : 0;
  TT* tt = table + warp * 32;
  if (lane < nt) {
    TD d; d.s = nullptr; d.rows8 = ROWS_ID; d.k0 = 0; desc(warp + NW * lane, d);
    tt[lane] = TT{d.w, d.s, d.x, d.rows8, d.n, d.slot, d.bm, d.k0};
  }
  __syncwarp();
  PState q; q.nt = nt; q.pt = 0; q.pi = 0; q.kind = KIND; q.issued = rg.pos;
  for (int k = 0; k < RS && q.pt < nt; k++) issue_stage<KIND>(tt, q, rg, lane);
  if (lane == 0) ps = q;
  __syncwarp();
}

__device__ __forceinline__ u32 lds32(u32 a) { u32 r; asm volatile("ld.shared.u32 %0, [%1];" : "=r"(r) : "r"(a)); return r; }
__device__ __forceinline__ u32 lds16(u32 a) { u16 r; asm volatile("ld.shared.u16 %0, [%1];" : "=h"(r) : "r"(a)); return r; }
__device__ __forceinline__ uint2 lds64(u32 a) { uint2 r; asm volatile("ld.shared.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "r"(a)); return r; }
__device__ __forceinline__ uint4 lds128(u32 a) {
  uint4 r; asm volatile("ld.shared.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "r"(a)); return r;
}

#define BF_2P112 0x77807780u   // bf16x2 (2^112, 2^112)

template <int KIND>
__device__ __forceinline__ void item(float* c, u32 st, u32 xb, int kb, int i, int lane, int g, bool cb) {
  const uint4 q = lds128(st + i * IBYTES + lane * 16);
  if (KIND == 0) {
    const int k = kb + i;
    uint2 bb = lds64(xb + (k >> 2) * 128 + (k & 3) * 8);
    u32 b0 = cb ? bb.x : 0u, b1 = cb ? bb.y : 0u;
    mma16816(c, q.x, q.y, q.z, q.w, b0, b1);
  } else if (KIND == 1) {
    const uint2 sc = lds64(st + RI * IBYTES + i * 64 + g * 8);
    const uint4 x0 = lds128(xb + (kb + i) * 128), x1 = lds128(xb + (kb + i) * 128 + 16);
    u32 b[8] = {x0.x, x0.y, x0.z, x0.w, x1.x, x1.y, x1.z, x1.w};
#pragma unroll
    for (int j = 0; j < 8; j++) b[j] = cb ? b[j] : 0u;
    const u32 cw[4] = {q.x, q.y, q.z, q.w};
#pragma unroll
    for (int j = 0; j < 4; j++) {
      const u32 sp = (j < 2) ? (sc.x >> (16 * j)) : (sc.y >> (16 * (j - 2)));
      const u32 S = hmul2u(f16e4_to_bf(e4m3x2_f16x2(sp & 0xffffu)), BF_2P112);   // lo: row g, hi: row g+8
      const u32 sg = prmt(S, 0, 0x1010), sh = prmt(S, 0, 0x3232);
      u32 a0, a1, a2, a3;
      cvt4(cw[j], a0, a1, a2, a3);
      a0 = hmul2u(a0, sg); a1 = hmul2u(a1, sh); a2 = hmul2u(a2, sg); a3 = hmul2u(a3, sh);
      mma16816(c, a0, a1, a2, a3, b[2 * j], b[2 * j + 1]);
    }
  } else {
    const u32 sw = lds16(st + RI * IBYTES + i * 16 + g * 2);
    const u32 S = (prmt(sw, 0, 0x4140) << 7) + 0x38003800u;    // bf16 2^(e-15): lo row g, hi row g+8
    const u32 sg = prmt(S, 0, 0x1010), sh = prmt(S, 0, 0x3232);
    const int k = kb + i;
    const uint4 x = lds128(xb + (k >> 1) * 128 + (k & 1) * 16);
    u32 b[4] = {x.x, x.y, x.z, x.w};
#pragma unroll
    for (int j = 0; j < 4; j++) b[j] = cb ? b[j] : 0u;
#pragma unroll
    for (int j = 0; j < 2; j++) {
      const u32 wa = j ? q.z : q.x, wb = j ? q.w : q.y;
      u32 a0 = hmul2u(f16e4_to_bf(e4m3x2_f16x2(wa & 0xffffu)), sg);
      u32 a1 = hmul2u(f16e4_to_bf(e4m3x2_f16x2(wa >> 16)), sh);
      u32 a2 = hmul2u(f16e4_to_bf(e4m3x2_f16x2(wb & 0xffffu)), sg);
      u32 a3 = hmul2u(f16e4_to_bf(e4m3x2_f16x2(wb >> 16)), sh);
      mma16816(c, a0, a1, a2, a3, b[2 * j], b[2 * j + 1]);
    }
  }
}

template <int KIND, class Fin>
__device__ __forceinline__ void consume_tasks(TT* table, int xst, Ring& rg, PState& psm, Fin fin) {
  const int warp = threadIdx.x >> 5, lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  PState ps = psm;
  const int nt = ps.nt;
  if (nt == 0) return;
  const TT* tt = table + warp * 32;
  int ct = 0, ci = 0;
  TT cq = tt[0];
  u32 cx; bool cb;
  auto setx = [&]() {
    int row = (int)((cq.rows8 >> (8 * g)) & 0xff);
    cb = (cq.bm >> g) & 1;
    cx = smaddr(cq.x + row * xst) + t * 32;
  };
  setx();
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  while (ct < nt) {
    const u32 sidx = rg.pos % RS;
    const int n = min(RI, cq.n - ci);
    mbar_wait(rg.bars + sidx * 8, (rg.pos / RS) & 1);
    const u32 st = rg.data + sidx * (RI * ITEM);
    const int kb = cq.k0 + ci;
    if (n == RI) {
#pragma unroll
      for (int i = 0; i < RI; i++) item<KIND>(c, st, cx, kb, i, lane, g, cb);
    } else {
#pragma unroll 1
      for (int i = 0; i < n; i++) item<KIND>(c, st, cx, kb, i, lane, g, cb);
    }
    __syncwarp();
    rg.pos++;
    if (ps.pt < nt) {
      if (lane == 0) asm volatile("fence.proxy.async.shared::cta;" ::: "memory");
      issue_stage<KIND>(tt, ps, rg, lane);
    }
    ci += n;
    if (ci == cq.n) {
      fin(cq.slot, c);
      c[0] = c[1] = c[2] = c[3] = 0.f;
      ci = 0;
      if (++ct < nt) { cq = tt[ct]; setx(); }
    }
  }
  if (lane == 0) psm = ps;
  __syncwarp();
}

// ---- track B (W12): exact 12-bit BF16 code (engine/pack.py w12_encode): register r of a lane = prmt of its two low
// bytes with the constant exponent bits 0x38 | (plane 2 rotated left by 4r, masked to the high 3 bits + sign)
__device__ __forceinline__ u32 w12reg(u32 p01, u32 p2, int r) {
  const u32 lo = prmt(p01, 0x38383838u, (r & 1) ? 0x4342u : 0x4140u);
  u32 hb = p2;
  if (r) asm("shf.l.wrap.b32 %0, %1, %1, %2;" : "=r"(hb) : "r"(p2), "r"(4 * r));
  return lo | (hb & 0x87008700u);
}
// escapes of the block's rowtiles staged in shared memory: esh[] (key, value), eoff[local rowtile] .. eoff[+1]
template <class Fin>
__device__ __forceinline__ void consume_w12(TT* table, int xst, Ring& rg, PState& psm, const uint2* esh, const int* eoff,
                                            int rt0, Fin fin) {
  const int warp = threadIdx.x >> 5, lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  PState ps = psm;
  const int nt = ps.nt;
  if (nt == 0) return;
  const TT* tt = table + warp * 32;
  int ct = 0, ci = 0;
  TT cq = tt[0];
  u32 cx; bool cb; float sc0, sc1; u32 ek0, ev0, ek1, ev1; u32 nk;
  auto nextk = [&](u32 k) {   // smallest escape kstep >= k of the task (warp-uniform), 0xffffff if none
    const u32 a0 = (ek0 >> 8) >= k ? (ek0 >> 8) : 0xffffffu, a1 = (ek1 >> 8) >= k ? (ek1 >> 8) : 0xffffffu;
    return __reduce_min_sync(0xffffffffu, min(a0, a1));
  };
  auto setx = [&]() {
    int row = (int)((cq.rows8 >> (8 * g)) & 0xff);
    cb = (cq.bm >> g) & 1;
    cx = smaddr(cq.x + row * xst) + t * 32;
    const int rt = cq.slot;
    const int b0 = __ldg(cq.s + g), b1 = __ldg(cq.s + g + 8);
    sc0 = __int_as_float((b0 + 15) << 23); sc1 = __int_as_float((b1 + 15) << 23);   // 2^(b - 112)
    const int e0 = eoff[rt - rt0], n = eoff[rt - rt0 + 1] - e0;
    ek0 = lane < n ? esh[e0 + lane].x : 0xffffffffu; ev0 = lane < n ? esh[e0 + lane].y : 0u;
    ek1 = lane + 32 < n ? esh[e0 + lane + 32].x : 0xffffffffu; ev1 = lane + 32 < n ? esh[e0 + lane + 32].y : 0u;
    nk = nextk((u32)cq.k0);
  };
  setx();
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  auto one = [&](u32 st, int i, int k) {
    const u32 a = st + i * 384 + lane * 4;
    const u32 p0 = lds32(a), p1 = lds32(a + 128), p2 = lds32(a + 256);
    u32 r0 = w12reg(p0, p2, 0), r1 = w12reg(p0, p2, 1), r2 = w12reg(p1, p2, 2), r3 = w12reg(p1, p2, 3);
    if ((u32)k == nk) {   // rare (warp-uniform): patch the exact values of this kstep
#pragma unroll 1
      for (int set = 0; set < 2; set++) {
        const u32 ek = set ? ek1 : ek0, ev = set ? ev1 : ev0;
        u32 mm = __ballot_sync(0xffffffffu, (ek >> 8) == (u32)k);
        while (mm) {
          const int j = __ffs(mm) - 1; mm &= mm - 1;
          const u32 key = __shfl_sync(0xffffffffu, ek, j), val = __shfl_sync(0xffffffffu, ev, j);
          if ((int)((key >> 3) & 31) == lane) {
            const int q = (key >> 1) & 3, hf = key & 1;
            const u32 msk = hf ? 0xffff0000u : 0x0000ffffu, v = hf ? (val << 16) : (val & 0xffffu);
            if (q == 0) r0 = (r0 & ~msk) | v; else if (q == 1) r1 = (r1 & ~msk) | v;
            else if (q == 2) r2 = (r2 & ~msk) | v; else r3 = (r3 & ~msk) | v;
          }
        }
      }
      nk = nextk((u32)k + 1);
    }
    const uint2 bb = lds64(cx + (k >> 2) * 128 + (k & 3) * 8);
    mma16816(c, r0, r1, r2, r3, cb ? bb.x : 0u, cb ? bb.y : 0u);
  };
  while (ct < nt) {
    const u32 sidx = rg.pos % RS;
    const int n = min(RI3, cq.n - ci);
    mbar_wait(rg.bars + sidx * 8, (rg.pos / RS) & 1);
    const u32 st = rg.data + sidx * (RI * ITEM);
    const int kb = cq.k0 + ci;
    if (n == RI3) {
#pragma unroll
      for (int i = 0; i < RI3; i++) one(st, i, kb + i);
    } else {
#pragma unroll 1
      for (int i = 0; i < n; i++) one(st, i, kb + i);
    }
    __syncwarp();
    rg.pos++;
    if (ps.pt < nt) {
      if (lane == 0) asm volatile("fence.proxy.async.shared::cta;" ::: "memory");
      issue_stage<3>(tt, ps, rg, lane);
    }
    ci += n;
    if (ci == cq.n) {
      c[0] *= sc0; c[1] *= sc0; c[2] *= sc1; c[3] *= sc1;   // exact: powers of two
      fin(cq.slot, c);
      c[0] = c[1] = c[2] = c[3] = 0.f;
      ci = 0;
      if (++ct < nt) { cq = tt[ct]; setx(); }
    }
  }
  if (lane == 0) psm = ps;
  __syncwarp();
}

template <int KIND, class Desc, class Fin>
__device__ __forceinline__ void run_tasks(int ntask, TT* table, int xst, Ring& rg, PState& ps, Desc desc, Fin fin) {
  prefetch_tasks<KIND>(ntask, table, rg, ps, desc);
  consume_tasks<KIND>(table, xst, rg, ps, fin);
}

__device__ __forceinline__ void store_task(float* red, int slot, const float* c) {
  const int lane = threadIdx.x & 31;
  *reinterpret_cast<float4*>(red + slot * 128 + lane * 4) = make_float4(c[0], c[1], c[2], c[3]);
}
__device__ __forceinline__ float red_at(const float* red, int slot, int i, int b) {
  return red[slot * 128 + ((i & 7) * 4 + (b >> 1)) * 4 + (i >> 3) * 2 + (b & 1)];
}

// B operand rows in shared memory, fragment order inside every 64-column chunk
__device__ __forceinline__ int xfo(int k) {
  const int c = k >> 6, r = k & 63, j = r >> 4, rr = r & 15;
  return c * 64 + (((rr & 7) >> 1) * 8 + j * 2 + (rr >> 3)) * 2 + (rr & 1);
}

// ------------------------------------------------------------------------------------------------ shared memory
#define XS_BYTES 74240
#define SM_XS 0
#define SM_RED XS_BYTES
#define RED_SLOTS 48
#define SM_MISC (SM_RED + RED_SLOTS * 512)
#define MISC_BYTES 12288
#define SM_TT (SM_MISC + MISC_BYTES)
#define SM_BARS (SM_TT + NW * 32 * (int)sizeof(TT))
#define SM_PS (SM_BARS + 256)
#define SM_RING (SM_PS + 256)
#define SM_ESC (SM_RING + NW * RING_WARP)
#define ESC_MAX 1024
#define SM_TOTAL (SM_ESC + ESC_MAX * 8 + 128 * 4)

struct Misc {
  int tok[MAXB];
  float scr[32];
  float irms[MAXB][8];
  float dots[MAXB][3][8];
  float coef[MAXB][4][8];
  float rr[MAXB][4];
  int U;
  int fr_s0, fr_s1, fr_np;
  int last;
  int pad3[3];
  int sexp[MAXU];
  u32 smask[MAXU];
  float rw[MAXB][MAXU];
  int sel[MAXB][TOPK];
  float selw[MAXB][TOPK];
  u64 srows[MAXU];
  float sl[MAXB][4][16];
  float tmpf[64];
  int tmpi[64];
  int zp[4][2];
  int nzp;
};
static_assert(sizeof(Misc) <= MISC_BYTES, "misc");
static_assert(SM_TOTAL <= 232448, "smem");

// attention scratch (in the xs region, free during phase B)
struct AttS {
  float q[3][HD];
  float r[3][DREL];
  float kn[HD];
  float vn[HD];
  float sc[3][CH];
  float ml[3][2];
  float acc[4][3][HD];
  float red[16];
  float sink[3];
};

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ int app_layer(int a) { return a < 6 ? a : (a < 42 ? 6 + (a - 6) % 12 : a - 24); }
__device__ __forceinline__ int app_pass(int a) { return (a >= 6 && a < 42) ? (a - 6) / 12 : 0; }
__device__ __forceinline__ int cache_slot(int i, int pas) { return (pas == 0) ? i : NL + (pas - 1) * 12 + (i - 6); }

// eight consecutive elements of a mix source (fp32): code < 16: vector; SRC_AS: attn_s; SRC_SUM + v: vector v + attn_s
__device__ __forceinline__ void unpack8(uint4 v, float* o) {
  o[0] = __uint_as_float(v.x << 16); o[1] = __uint_as_float(v.x & 0xffff0000u);
  o[2] = __uint_as_float(v.y << 16); o[3] = __uint_as_float(v.y & 0xffff0000u);
  o[4] = __uint_as_float(v.z << 16); o[5] = __uint_as_float(v.z & 0xffff0000u);
  o[6] = __uint_as_float(v.w << 16); o[7] = __uint_as_float(v.w & 0xffff0000u);
}
__device__ __forceinline__ void src_load8(const Params& p, int code, int b, int k, float* v) {
  if (code < SRC_AS) {
    unpack8(ldcg128(p.vecs + ((size_t)b * NVEC + code) * H + k), v);
  } else if (code == SRC_AS) {
    unpack8(ldcg128(p.attn_s + (size_t)b * H + k), v);
  } else {
    float w[8];
    unpack8(ldcg128(p.vecs + ((size_t)b * NVEC + (code - SRC_SUM)) * H + k), v);
    unpack8(ldcg128(p.attn_s + (size_t)b * H + k), w);
#pragma unroll
    for (int j = 0; j < 8; j++) v[j] += w[j];
  }
}

// mixing coefficients of a block attention residual: coef[b][s][n] = softmax_n(q_s . v_n / (48 rms(v_n))) / rms(v_n)
__device__ void mix_coef(const Params& p, int B, const int* codes, int nsrc, const float* const* qs, int nq, Misc* ms) {
  const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31;
  for (int pr = warp; pr < B * nsrc; pr += NW) {
    const int b = pr / nsrc, n = pr % nsrc;
    float ss = 0.f, d[3] = {0.f, 0.f, 0.f};
    for (int c = lane; c < H / 8; c += 32) {
      float v[8];
      src_load8(p, codes[n], b, c * 8, v);
#pragma unroll
      for (int j = 0; j < 8; j++) ss = fmaf(v[j], v[j], ss);
      for (int s = 0; s < nq; s++) {
        const float4 q0 = __ldg(reinterpret_cast<const float4*>(qs[s] + c * 8));
        const float4 q1 = __ldg(reinterpret_cast<const float4*>(qs[s] + c * 8 + 4));
        float a = d[s];
        a = fmaf(q0.x, v[0], a); a = fmaf(q0.y, v[1], a); a = fmaf(q0.z, v[2], a); a = fmaf(q0.w, v[3], a);
        a = fmaf(q1.x, v[4], a); a = fmaf(q1.y, v[5], a); a = fmaf(q1.z, v[6], a); a = fmaf(q1.w, v[7], a);
        d[s] = a;
      }
    }
    ss = warp_sum(ss);
    for (int s = 0; s < nq; s++) d[s] = warp_sum(d[s]);
    if (lane == 0) {
      ms->irms[b][n] = rsqrtf(ss * (1.0f / H) + 1e-6f);
      for (int s = 0; s < nq; s++) ms->dots[b][s][n] = d[s];
    }
  }
  __syncthreads();
  if (tid < B * nq) {
    const int b = tid / nq, s = tid % nq;
    float lg[8], m = -INFINITY;
    for (int n = 0; n < nsrc; n++) { lg[n] = ms->dots[b][s][n] * ms->irms[b][n] * (1.0f / 48.0f); m = fmaxf(m, lg[n]); }
    float sum = 0.f;
    for (int n = 0; n < nsrc; n++) { lg[n] = expf(lg[n] - m); sum += lg[n]; }
    const float inv = 1.0f / sum;
    for (int n = 0; n < nsrc; n++) ms->coef[b][s][n] = lg[n] * inv * ms->irms[b][n];
  }
  __syncthreads();
}

// x[k..k+7] of mix stream s for sequence b
__device__ __forceinline__ void mix_val8(const Params& p, const Misc* ms, const int* codes, int nsrc, int b, int s, int k, float* x) {
#pragma unroll
  for (int j = 0; j < 8; j++) x[j] = 0.f;
  for (int n = 0; n < nsrc; n++) {
    float v[8];
    src_load8(p, codes[n], b, k, v);
    const float cf = ms->coef[b][s][n];
#pragma unroll
    for (int j = 0; j < 8; j++) x[j] = fmaf(cf, v[j], x[j]);
  }
}

// RMSNorm with weight of the fp32 vector xf (smem) into a bf16 B-operand row (fragment order)
__device__ __forceinline__ void norm_row(const float* xf, const bf16* w, u16* row, float* scr) {
  const int tid = threadIdx.x;
  float ss = 0.f;
  for (int k = tid; k < H; k += NT) ss = fmaf(xf[k], xf[k], ss);
  ss = block_sum(ss, scr);
  const float r = rsqrtf(ss * (1.0f / H) + 1e-6f);
  for (int k = tid * 2; k < H; k += NT * 2) {
    const float w0 = ldgbf(w + k), w1 = ldgbf(w + k + 1);
    const u32 o = (u32)f2u16(w0 * (xf[k] * r)) | ((u32)f2u16(w1 * (xf[k + 1] * r)) << 16);
    *reinterpret_cast<u32*>(row + xfo(k)) = o;
  }
}

// ------------------------------------------------------------------------------------------------ the kernel
extern "C" __global__ void __launch_bounds__(NT, 1) mk_kernel(const __grid_constant__ Params p, const __grid_constant__ RunArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  u16* xs = reinterpret_cast<u16*>(smem + SM_XS);
  float* red = reinterpret_cast<float*>(smem + SM_RED);
  float* xf = reinterpret_cast<float*>(smem + SM_RED);      // fp32 vector scratch (red is free outside epilogues)
  Misc* ms = reinterpret_cast<Misc*>(smem + SM_MISC);
  TT* ttab = reinterpret_cast<TT*>(smem + SM_TT);
  PState* pst = reinterpret_cast<PState*>(smem + SM_PS);
  AttS* at = reinterpret_cast<AttS*>(smem + SM_XS);

  const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31;
  Ring rg;
  rg.data = smaddr(smem + SM_RING) + warp * RING_WARP;
  rg.bars = smaddr(smem + SM_BARS) + warp * RS * 8;
  rg.pos = 0;
  if (lane == 0) for (int k = 0; k < RS; k++) mbar_init(rg.bars + k * 8, 1);
  asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  __syncthreads();
  const int bid = blockIdx.x;
  const int B = a.B;
  const u32 bmask = (1u << B) - 1;
  u32 bar_target = 0;
  u32* bar = p.bar;

  // ---- prefetch helpers (weights only)
  auto qkv_range = [&](const LayerP& L, int& r0, int& r1) {
    r0 = bid * (int)L.nrt / NB; r1 = (bid + 1) * (int)L.nrt / NB;
  };
  auto stream_of = [&](const LayerP& L, int rt) { return rt < RT_K ? 0 : (rt < (L.glob ? 476 : 474) ? 1 : 2); };
  auto pf_qkv = [&](int i) {
    const LayerP& L = p.L[i];
    int r0, r1; qkv_range(L, r0, r1);
    const int s0 = stream_of(L, r0);
    prefetch_tasks<0>((r1 - r0) * 8, ttab, rg, pst[warp], [&](int task, TD& d) {
      const int r = task >> 3, sg = task & 7;
      const int grp = stream_of(L, r0 + r) - s0;
      d.w = L.wqkv + ((size_t)(r0 + r) * KS_H + sg * 18) * 32; d.x = xs + grp * B * XSH; d.k0 = sg * 18; d.n = 18;
      d.slot = task; d.bm = bmask;
    });
  };
  auto pf_o = [&](int i) {
    const LayerP& L = p.L[i];
    const int R = bid < 144 ? 1 : 0;
    prefetch_tasks<0>(R * 8, ttab, rg, pst[warp], [&](int task, TD& d) {
      d.w = L.wo + ((size_t)bid * KS_A + task * 24) * 32; d.x = xs; d.k0 = task * 24; d.n = 24; d.slot = task; d.bm = bmask;
    });
  };
  auto pf_router = [&](int i) {
    const LayerP& L = p.L[i];
    prefetch_tasks<0>(bid < 8 ? 8 : 0, ttab, rg, pst[warp], [&](int task, TD& d) {
      d.w = L.wr + ((size_t)bid * KS_H + task * 18) * 32; d.x = xs; d.k0 = task * 18; d.n = 18; d.slot = task; d.bm = bmask;
    });
  };
  auto pf_head = [&]() {
    const int r0 = (int)((long)bid * RT_HEAD / NB), r1 = (int)((long)(bid + 1) * RT_HEAD / NB);
#if W12U
    prefetch_tasks<3>(r1 - r0, ttab, rg, pst[warp], [&](int task, TD& d) {
      d.w = p.unembed + (size_t)(r0 + task) * KS_H * 24; d.s = p.u12base + (size_t)(r0 + task) * 16; d.x = xs; d.n = KS_H;
      d.slot = r0 + task; d.bm = bmask;
    });
#else
    prefetch_tasks<0>(r1 - r0, ttab, rg, pst[warp], [&](int task, TD& d) {
      d.w = p.unembed + (size_t)(r0 + task) * KS_H * 32; d.x = xs; d.n = KS_H; d.slot = r0 + task; d.bm = bmask;
    });
#endif
  };
  // down-projection rounds: slots [s0, s1) whose (slot, token) activation rows fit in xs (32 rows)
  auto fround = [&](int s0) {
    if (tid == 0) {
      const int U = ms->U;
      int s1 = s0, np = 0;
      while (s1 < U && np + __popc(ms->smask[s1]) <= 32 && (s1 + 1 - s0) * 2 <= RED_SLOTS) { np += __popc(ms->smask[s1]); s1++; }
      ms->fr_s0 = s0; ms->fr_s1 = s1; ms->fr_np = np;
      int base = 0;
      for (int k = s0; k < s1; k++) {
        const u32 m = ms->smask[k];
        u64 r8 = 0;
        for (int b = 0; b < 8; b++) if (m >> b & 1) r8 |= (u64)(base++) << (8 * b);
        ms->srows[k - s0] = r8;
      }
    }
  };
  auto pf_down = [&](int i, int s0, int s1) {
    const LayerP& L = p.L[i];
    const int ntask = bid < 144 ? (s1 - s0) * 2 : 0;
    if (L.mx) {
      prefetch_tasks<2>(ntask, ttab, rg, pst[warp], [&](int task, TD& d) {
        const int sl = s0 + (task >> 1), sg = task & 1, e = ms->sexp[sl];
        const size_t it = ((size_t)e * 144 + bid) * 36 + sg * 18;
        d.w = L.w2c + it * 32; d.s = L.w2s + it * 16; d.x = xs; d.k0 = sg * 18; d.n = 18; d.slot = task;
        d.rows8 = ms->srows[sl - s0]; d.bm = ms->smask[sl];
      });
    } else {
      prefetch_tasks<1>(ntask, ttab, rg, pst[warp], [&](int task, TD& d) {
        const int sl = s0 + (task >> 1), sg = task & 1, e = ms->sexp[sl];
        const size_t it = ((size_t)e * 144 + bid) * 18 + sg * 9;
        d.w = L.w2c + it * 32; d.s = L.w2s + it * 64; d.x = xs; d.k0 = sg * 9; d.n = 9; d.slot = task;
        d.rows8 = ms->srows[sl - s0]; d.bm = ms->smask[sl];
      });
    }
  };

  if (tid < B) ms->tok[tid] = (int)a.tok[tid];
  __syncthreads();
  pf_qkv(0);

  for (int st = 0; st < a.nsteps; st++) {
    const int pos = a.pos0 + st;
    const int nstop = (st == a.nsteps - 1) ? a.stop_app : NAPP;
    for (int ap = 0; ap < nstop; ap++) {
      const int i = app_layer(ap), pas = app_pass(ap), slot = cache_slot(i, pas);
      const LayerP& L = p.L[i];
      const bool loopg = L.loop && pas > 0;
      const bool bnd = (i % 6) == 0;
      const int seg = i / 6;
      const int pp = (seg == 3) ? 2 : pas;            // pass whose P1/P2 the layer sees
#if XPF
      // track B: the experts of this layer's previous pass (loop passes 2, 3; ~5 of 8 recur) or, with XPF=2, of this
      // application at the previous token, prefetched into L2 while the attention half of the layer runs
      if (tid == 0 && (pas > 0 || XPF >= 2)) {
        const int src = pas > 0 ? ap - 12 : ap;
        const int* rh = p.rhist + src * (MAXU + 1);
        const int nu = min(ldcgi(rh + MAXU), MAXU);
        const size_t q13 = (size_t)144 * (L.mx ? 72 : 36), q2 = (size_t)144 * (L.mx ? 36 : 18);   // items per expert
        const int sb13 = L.mx ? 16 : 64, sb2 = sb13;
        auto pfr = [&](const void* base, size_t bytes) {   // this block's share of [base, base + bytes)
          const size_t lo = (bytes * bid / NB) & ~(size_t)15, hi = (bid + 1 == NB) ? bytes : ((bytes * (bid + 1) / NB) & ~(size_t)15);
          if (hi > lo + 15) asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"((const char*)base + lo), "r"((u32)((hi - lo) & ~(size_t)15)) : "memory");
        };
        for (int u = 0; u < nu; u++) {
          const int e = ldcgi(rh + u);
          pfr(L.w13c + (size_t)e * q13 * 32, q13 * 512);
          pfr(L.w13s + (size_t)e * q13 * sb13, q13 * sb13);
          pfr(L.w2c + (size_t)e * q2 * 32, q2 * 512);
          pfr(L.w2s + (size_t)e * q2 * sb2, q2 * sb2);
        }
      }
#endif
      int blk[5]; int nblk = 0;
      blk[nblk++] = V_H0;
      if (seg >= 1) blk[nblk++] = V_P0;
      if (seg >= 2) blk[nblk++] = V_P1 + pp;
      if (seg >= 3) blk[nblk++] = V_P2 + pp;
      const int cur = seg == 0 ? V_P0 : seg == 1 ? V_P1 + pas : seg == 2 ? V_P2 + pas : V_P3;
      // attention-input sources
      int asrc[6]; int nas = 0;
      for (int k = 0; k < nblk; k++) asrc[nas++] = blk[k];
      if (!bnd) asrc[nas++] = cur;
      const int naq = L.glob ? 3 : 1;
      const float* aqs[3] = {L.aq, L.aq + H, L.aq + 2 * H};
      const bf16* nws[3] = {L.nq, L.nk, L.nv};

      // ================= [M] messages of the pass
      if (L.loop && pas > 0 && i == 6) {
        const int msrc[2] = {V_P1 + pas - 1, V_P2 + pas - 1};
        for (int itm = bid; itm < 48 * B; itm += NB) {
          const int b = itm / 48, ls = itm % 48;
          const float* qp = p.lq + (size_t)ls * H;
          // coefficients for this one (b): reuse mix_coef with B = 1 on shifted sequence
          {
            float ssv[2], dv[2];
            for (int n = 0; n < 2; n++) {
              float ss = 0.f, d = 0.f;
              for (int c = tid; c < H / 8; c += NT) {
                float v[8]; src_load8(p, msrc[n], b, c * 8, v);
                const float4 q0 = __ldg(reinterpret_cast<const float4*>(qp + c * 8));
                const float4 q1 = __ldg(reinterpret_cast<const float4*>(qp + c * 8 + 4));
#pragma unroll
                for (int j = 0; j < 8; j++) ss = fmaf(v[j], v[j], ss);
                d = fmaf(q0.x, v[0], d); d = fmaf(q0.y, v[1], d); d = fmaf(q0.z, v[2], d); d = fmaf(q0.w, v[3], d);
                d = fmaf(q1.x, v[4], d); d = fmaf(q1.y, v[5], d); d = fmaf(q1.z, v[6], d); d = fmaf(q1.w, v[7], d);
              }
              ssv[n] = block_sum(ss, ms->scr);
              dv[n] = block_sum(d, ms->scr);
            }
            const float ir0 = rsqrtf(ssv[0] * (1.0f / H) + 1e-6f), ir1 = rsqrtf(ssv[1] * (1.0f / H) + 1e-6f);
            float l0 = dv[0] * ir0 * (1.0f / 48.0f), l1 = dv[1] * ir1 * (1.0f / 48.0f);
            const float m = fmaxf(l0, l1);
            l0 = expf(l0 - m); l1 = expf(l1 - m);
            const float inv = 1.0f / (l0 + l1);
            const float c0 = l0 * inv * ir0, c1 = l1 * inv * ir1;
            float ss = 0.f;
            float* mo = p.msg + ((size_t)ls * MAXB + b) * H;
            for (int c = tid; c < H / 8; c += NT) {
              float v0[8], v1[8];
              src_load8(p, msrc[0], b, c * 8, v0);
              src_load8(p, msrc[1], b, c * 8, v1);
              float o[8];
#pragma unroll
              for (int j = 0; j < 8; j++) { o[j] = fmaf(c1, v1[j], c0 * v0[j]); ss = fmaf(o[j], o[j], ss); }
              *reinterpret_cast<float4*>(mo + c * 8) = make_float4(o[0], o[1], o[2], o[3]);
              *reinterpret_cast<float4*>(mo + c * 8 + 4) = make_float4(o[4], o[5], o[6], o[7]);
            }
            ss = block_sum(ss, ms->scr);
            if (tid == 0) p.msgir[ls * MAXB + b] = rsqrtf(ss * (1.0f / H) + 1e-6f);
          }
        }
        grid_bar(bar, bar_target);
      }

      // ================= [A0], [A1] loop message gates for q, k, v ; [D0], [D1] for the MLP input
      // gate g of loop layer l: controllers D [64][4608], F, G [2304][64]; message (l, g) of msg
      // gated output -> xg[b][g]
      auto gate_phases = [&](int g0, int ng, const int* srcs, int nsrc, const float* const* qs, int nq, bool sidx_by_gate) {
        // ---- phase 0: coefficients, z rows, slices
        mix_coef(p, B, srcs, nsrc, qs, nq, ms);
        const int l = i - 6;
        const int nz = B * ng * 64;
        // the z rows of this block: W = bid * NW + warp (+ k * NB * NW)
        // distinct (b, g) pairs among this block's rows -> materialise ux, um (bf16) in xs
        if (tid == 0) {
          int np = 0;
          for (int w = 0; w < NW; w++)
            for (int r = bid * NW + w; r < nz; r += NB * NW) {
              const int b = r / (ng * 64), gg = (r / 64) % ng;
              bool f = false;
              for (int k = 0; k < np; k++) if (ms->zp[k][0] == b && ms->zp[k][1] == gg) f = true;
              if (!f && np < 4) { ms->zp[np][0] = b; ms->zp[np][1] = gg; np++; }
            }
          ms->nzp = np;
        }
        __syncthreads();
        const int nzp = ms->nzp;
        u16* ub = xs;   // [nzp][2][H] bf16 (plain order)
        for (int k = 0; k < nzp; k++) {
          const int b = ms->zp[k][0], gg = ms->zp[k][1], gl = g0 + gg;
          const int s = sidx_by_gate ? gg : 0;
          float ss = 0.f;
          for (int c = tid; c < H / 8; c += NT) {
            float x[8]; mix_val8(p, ms, srcs, nsrc, b, s, c * 8, x);
#pragma unroll
            for (int j = 0; j < 8; j++) { xf[c * 8 + j] = x[j]; ss = fmaf(x[j], x[j], ss); }
          }
          ss = block_sum(ss, ms->scr);
          const float rx = rsqrtf(ss * (1.0f / H) + 1e-6f);
          const float* mp = p.msg + ((size_t)(l * 4 + gl) * MAXB + b) * H;
          const float rm = ldcgf(p.msgir + (l * 4 + gl) * MAXB + b);
          for (int kk = tid; kk < H; kk += NT) {
            ub[(k * 2) * H + kk] = f2u16(xf[kk] * rx);
            ub[(k * 2 + 1) * H + kk] = f2u16(ldcgf(mp + kk) * rm);
          }
          __syncthreads();
        }
        for (int r = bid * NW + warp; r < nz; r += NB * NW) {
          const int b = r / (ng * 64), gg = (r / 64) % ng, j = r % 64, gl = g0 + gg;
          int k = 0;
          for (int q = 0; q < nzp; q++) if (ms->zp[q][0] == b && ms->zp[q][1] == gg) k = q;
          const bf16* drow = L.cD + ((size_t)gl * 64 + j) * (2 * H);
          float acc = 0.f;
          for (int c = lane; c < 2 * H / 8; c += 32) {
            const uint4 wv = __ldg(reinterpret_cast<const uint4*>(drow + c * 8));
            const uint4 xv = *reinterpret_cast<const uint4*>(ub + (size_t)k * 2 * H + c * 8);
            float w8[8], x8[8]; unpack8(wv, w8); unpack8(xv, x8);
#pragma unroll
            for (int q = 0; q < 8; q++) acc = fmaf(w8[q], x8[q], acc);
          }
          acc = warp_sum(acc);
          if (lane == 0) p.zb[(b * 4 + gl) * 64 + j] = bfr(acc);
        }
        // slices of x for phase 1
        const int j0 = bid * H / NB, j1 = (bid + 1) * H / NB;
        for (int it = tid; it < B * ng * (j1 - j0); it += NT) {
          const int b = it / (ng * (j1 - j0)), gg = (it / (j1 - j0)) % ng, k = j0 + it % (j1 - j0);
          const int s = sidx_by_gate ? gg : 0;
          float x = 0.f;
          for (int n = 0; n < nsrc; n++) {
            const int code = srcs[n];
            float v;
            if (code < SRC_AS) v = u16f(ldcg16(p.vecs + ((size_t)b * NVEC + code) * H + k));
            else if (code == SRC_AS) v = u16f(ldcg16(p.attn_s + (size_t)b * H + k));
            else v = u16f(ldcg16(p.vecs + ((size_t)b * NVEC + code - SRC_SUM) * H + k)) + u16f(ldcg16(p.attn_s + (size_t)b * H + k));
            x = fmaf(ms->coef[b][s][n], v, x);
          }
          ms->sl[b][gg][k - j0] = x;
        }
        grid_bar(bar, bar_target);
        // ---- phase 1: gated slices
        for (int it = tid; it < B * ng * (j1 - j0); it += NT) {
          const int b = it / (ng * (j1 - j0)), gg = (it / (j1 - j0)) % ng, k = j0 + it % (j1 - j0), gl = g0 + gg;
          const float* z = p.zb + (b * 4 + gl) * 64;
          const bf16* fr = L.cF + ((size_t)gl * H + k) * 64;
          const bf16* gr = L.cG + ((size_t)gl * H + k) * 64;
          float fa = 0.f, ga = 0.f;
          for (int j = 0; j < 64; j += 8) {
            float f8[8], g8[8];
            unpack8(__ldg(reinterpret_cast<const uint4*>(fr + j)), f8);
            unpack8(__ldg(reinterpret_cast<const uint4*>(gr + j)), g8);
#pragma unroll
            for (int q = 0; q < 8; q++) { const float zz = ldcgf(z + j + q); fa = fmaf(f8[q], zz, fa); ga = fmaf(g8[q], zz, ga); }
          }
          const float m = ldcgf(p.msg + ((size_t)(l * 4 + gl) * MAXB + b) * H + k);
          const float x = ms->sl[b][gg][k - j0];
          p.xg[((size_t)b * 4 + gl) * H + k] = (1.0f - tanhf(fa)) * x + tanhf(ga) * m;
        }
        grid_bar(bar, bar_target);
      };

      // ================= phase A: attention inputs + qkv GEMV
      if (loopg) {
        gate_phases(0, 3, asrc, nas, aqs, naq, L.glob != 0);
      }
      {
        int r0, r1; qkv_range(L, r0, r1);
        const int s0 = stream_of(L, r0), s1 = stream_of(L, r1 - 1);
        if (i == 0) {
          // h0 = bf16(rmsnorm(embed[tok]) * embed_norm), then the layer-0 norm
          for (int b = 0; b < B; b++) {
            const bf16* er = p.embed + (size_t)ms->tok[b] * H;
            float ss = 0.f;
            for (int k = tid; k < H; k += NT) { const float v = ldgbf(er + k); ss = fmaf(v, v, ss); }
            ss = block_sum(ss, ms->scr);
            const float r = rsqrtf(ss * (1.0f / H) + 1e-6f);
            for (int k = tid; k < H; k += NT) {
              const float h = bfr(ldgbf(p.embed_norm + k) * (ldgbf(er + k) * r));
              xf[k] = h;
              if (bid == 0) p.vecs[((size_t)b * NVEC + V_H0) * H + k] = __float2bfloat16_rn(h);
            }
            __syncthreads();
            for (int s = s0; s <= s1; s++) { norm_row(xf, nws[s], xs + ((s - s0) * B + b) * XSH, ms->scr); __syncthreads(); }
          }
        } else if (loopg) {
          for (int s = s0; s <= s1; s++)
            for (int b = 0; b < B; b++) {
              const float* xp = p.xg + ((size_t)b * 4 + s) * H;
              for (int k = tid; k < H; k += NT) xf[k] = ldcgf(xp + k);
              __syncthreads();
              norm_row(xf, nws[s], xs + ((s - s0) * B + b) * XSH, ms->scr);
              __syncthreads();
            }
        } else {
          mix_coef(p, B, asrc, nas, aqs, naq, ms);
          for (int s = s0; s <= s1; s++)
            for (int b = 0; b < B; b++) {
              const int ms_ = L.glob ? s : 0;
              for (int c = tid; c < H / 8; c += NT) {
                float x[8]; mix_val8(p, ms, asrc, nas, b, ms_, c * 8, x);
#pragma unroll
                for (int j = 0; j < 8; j++) xf[c * 8 + j] = x[j];
              }
              __syncthreads();
              norm_row(xf, nws[s], xs + ((s - s0) * B + b) * XSH, ms->scr);
              __syncthreads();
            }
        }
        __syncthreads();
        consume_tasks<0>(ttab, XSH, rg, pst[warp], [&](int sl, const float* c) { store_task(red, sl, c); });
        __syncthreads();
        const int R = r1 - r0;
        for (int it = tid; it < R * 16 * B; it += NT) {
          const int r = it / (16 * B), ii = (it / B) % 16, b = it % B;
          float v = 0.f;
#pragma unroll
          for (int s = 0; s < 8; s++) v += red_at(red, r * 8 + s, ii, b);
          p.qkvo[(size_t)b * QKVW + (r0 + r) * 16 + ii] = __float2bfloat16_rn(v);
        }
      }
      grid_bar(bar, bar_target);

      // ================= phase B: attention
      {
        const int OFF_V = L.glob ? 476 * 16 : 474 * 16;
        const int kstart = L.glob ? 0 : max(0, pos - (WIN - 1));
        const int c0 = kstart / CH, c1 = pos / CH, nch = c1 - c0 + 1;
        const int nitems = B * NKV * nch;
        const float tau = 1.0f + 0.1f * logf(fmaxf((float)(pos + 1) / 8192.0f, 1.0f));
        for (int itm = bid; itm < nitems; itm += NB) {
          const int b = itm / (NKV * nch), kvh = (itm / nch) % NKV, c = c0 + itm % nch;
          const bf16* qk = p.qkvo + (size_t)b * QKVW;
          const int klo = max(kstart, c * CH), khi = min(pos, c * CH + CH - 1);
          const int nk = khi - klo + 1;
          const bool hascur = (khi == pos);
          // q (3 heads): scale, L2 clip 22.627, (tau)
          if (tid < 3 * 32) {
            const int j = tid >> 5, h = kvh * 3 + j;
            float v[4]; float ss = 0.f;
#pragma unroll
            for (int q = 0; q < 4; q++) {
              const int d = lane * 4 + q;
              v[q] = u16f(ldcg16(qk + h * HD + d)) * ldgbf(L.qscale + h * HD + d);
              ss = fmaf(v[q], v[q], ss);
            }
            ss = warp_sum(ss);
            const float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
#pragma unroll
            for (int q = 0; q < 4; q++) {
              float o = bfr(v[q] * f);
              if (L.glob) o = bfr(o * tau);
              at->q[j][lane * 4 + q] = o;
            }
          }
          if (tid >= 96 && tid < 96 + 48) {
            const int j = (tid - 96) / 16, e = (tid - 96) % 16, h = kvh * 3 + j;
            at->r[j][e] = u16f(ldcg16(qk + OFF_R + h * DREL + e)) * ldgbf(L.rscale + h * DREL + e);
          }
          if (tid < 3) at->sink[tid] = u16f(ldcg16(qk + OFF_S + kvh * 3 + tid));
          // current position: K/V conv + clip / norm
          if (hascur) {
            const int isv = tid >> 7, d = tid & 127, ch = kvh * HD + d;
            const bf16* rb = isv ? p.rv : p.rk;
            const int off = isv ? OFF_V : OFF_K;
            const float xt = u16f(ldcg16(qk + off + ch));
            float xh[3];
#pragma unroll
            for (int j = 1; j <= 3; j++) xh[j - 1] = u16f(ldcg16(rb + (((size_t)slot * MAXB + b) * 4 + ((pos - j) & 3)) * KVW + ch));
            float o;
            if (!L.glob) {
              const bf16* w = (isv ? L.vsc : L.ksc) + ch * 4;   // taps: 3 = current
              float acc = ldgbf(w + 0) * xh[2];
              acc = fmaf(ldgbf(w + 1), xh[1], acc);
              acc = fmaf(ldgbf(w + 2), xh[0], acc);
              acc = fmaf(ldgbf(w + 3), xt, acc);
              o = bfr((acc + xt) / 2.23606797749979f);
            } else {
              const bf16* sw = isv ? L.vsc : L.ksc;              // static_w [4 lags][1024]
              const int doff = isv ? (OFF_V + 64 * 16) : OFF_DK; // dv rows follow v (rowtiles 540, 541)
              float wl[4];
#pragma unroll
              for (int lg = 0; lg < 4; lg++) wl[lg] = ldgbf(sw + lg * KVW + ch) + u16f(ldcg16(qk + doff + kvh * 4 + lg));
              float acc = xt * wl[0];
              acc = fmaf(xh[0], wl[1], acc);
              acc = fmaf(xh[1], wl[2], acc);
              acc = fmaf(xh[2], wl[3], acc);
              o = bfr((acc + xt) / 3.0f);
            }
            // reduce over the 128 channels of this head (4 warps)
            float ss = warp_sum(o * o);
            if (lane == 0) at->red[warp] = ss;
            __syncthreads();
            const float tot = at->red[isv * 4 + 0] + at->red[isv * 4 + 1] + at->red[isv * 4 + 2] + at->red[isv * 4 + 3];
            float fin;
            if (!isv) fin = bfr(o * fminf(22.627416997969522f / (sqrtf(tot) + 1e-6f), 1.0f));
            else fin = bfr(o * rsqrtf(tot * (1.0f / HD) + 1e-6f));
            bf16* cp = (isv ? p.vc : p.kc) + ((((size_t)slot * MAXB + b) * NKV + kvh) * p.maxctx + pos) * HD + d;
            *cp = __float2bfloat16_rn(fin);
            (isv ? at->vn : at->kn)[d] = fin;
            bf16* rw = (bf16*)rb + (((size_t)slot * MAXB + b) * 4 + (pos & 3)) * KVW + ch;
            *rw = __float2bfloat16_rn(xt);
          }
          __syncthreads();
          // r clip (16 per head) by one thread per head
          if (tid < 3) {
            float ss = 0.f;
            for (int e = 0; e < DREL; e++) ss = fmaf(at->r[tid][e], at->r[tid][e], ss);
            const float f = fminf(8.0f / (sqrtf(ss) + 1e-6f), 1.0f);
            for (int e = 0; e < DREL; e++) {
              float o = bfr(at->r[tid][e] * f);
              if (L.glob) o = bfr(o * tau);
              at->r[tid][e] = o;
            }
          }
          __syncthreads();
          // relative bias of the chunk's distances
          for (int it = tid; it < 3 * nk; it += NT) {
            const int h = it / nk, jj = it % nk, dist = pos - (klo + jj);
            float bs = 0.f;
            if (dist < RELEXT) {
#pragma unroll
              for (int e = 0; e < DREL; e++) bs = fmaf(at->r[h][e], ldgbf(L.relp + e * RELEXT + dist), bs);
            }
            at->sc[h][jj] = bs;
          }
          __syncthreads();
          // scores: warp w handles keys klo + w + 8k ; lane holds 4 dims
          {
            const bf16* kbase = p.kc + (((size_t)slot * MAXB + b) * NKV + kvh) * p.maxctx * HD;
            float q0[4], q1[4], q2[4];
#pragma unroll
            for (int q = 0; q < 4; q++) { q0[q] = at->q[0][lane * 4 + q]; q1[q] = at->q[1][lane * 4 + q]; q2[q] = at->q[2][lane * 4 + q]; }
            for (int jj = warp; jj < nk; jj += NW) {
              const int key = klo + jj;
              float kv[4];
              if (key == pos) {
#pragma unroll
                for (int q = 0; q < 4; q++) kv[q] = at->kn[lane * 4 + q];
              } else {
                const uint2 u = ldcg64(kbase + (size_t)key * HD + lane * 4);
                kv[0] = __uint_as_float(u.x << 16); kv[1] = __uint_as_float(u.x & 0xffff0000u);
                kv[2] = __uint_as_float(u.y << 16); kv[3] = __uint_as_float(u.y & 0xffff0000u);
              }
              float s0 = 0.f, s1 = 0.f, s2 = 0.f;
#pragma unroll
              for (int q = 0; q < 4; q++) { s0 = fmaf(q0[q], kv[q], s0); s1 = fmaf(q1[q], kv[q], s1); s2 = fmaf(q2[q], kv[q], s2); }
              s0 = warp_sum(s0); s1 = warp_sum(s1); s2 = warp_sum(s2);
              if (lane == 0) {
                const float sc = 0.08838834764831845f;
                at->sc[0][jj] = fmaf(s0, sc, at->sc[0][jj]); at->sc[1][jj] = fmaf(s1, sc, at->sc[1][jj]); at->sc[2][jj] = fmaf(s2, sc, at->sc[2][jj]);
              }
            }
          }
          __syncthreads();
          // softmax partial per head (warps 0..2)
          if (warp < 3) {
            float m = -INFINITY;
            for (int jj = lane; jj < nk; jj += 32) m = fmaxf(m, at->sc[warp][jj]);
            m = warp_max(m);
            float l = 0.f;
            for (int jj = lane; jj < nk; jj += 32) { const float e = expf(at->sc[warp][jj] - m); at->sc[warp][jj] = e; l += e; }
            l = warp_sum(l);
            if (lane == 0) { at->ml[warp][0] = m; at->ml[warp][1] = l; }
          }
          __syncthreads();
          // P V: thread = (dim pair d2 = tid & 63, key quarter qq = tid >> 6)
          {
            const bf16* vbase = p.vc + (((size_t)slot * MAXB + b) * NKV + kvh) * p.maxctx * HD;
            const int d2 = tid & 63, qq = tid >> 6;
            float a0[3] = {0.f, 0.f, 0.f}, a1[3] = {0.f, 0.f, 0.f};
            for (int jj = qq; jj < nk; jj += 4) {
              const int key = klo + jj;
              float v0, v1;
              if (key == pos) { v0 = at->vn[2 * d2]; v1 = at->vn[2 * d2 + 1]; }
              else {
                const u32 u = ldcg32(vbase + (size_t)key * HD + 2 * d2);
                v0 = __uint_as_float(u << 16); v1 = __uint_as_float(u & 0xffff0000u);
              }
#pragma unroll
              for (int h = 0; h < 3; h++) { const float pw = at->sc[h][jj]; a0[h] = fmaf(pw, v0, a0[h]); a1[h] = fmaf(pw, v1, a1[h]); }
            }
#pragma unroll
            for (int h = 0; h < 3; h++) { at->acc[qq][h][2 * d2] = a0[h]; at->acc[qq][h][2 * d2 + 1] = a1[h]; }
          }
          __syncthreads();
          // partial to global: [b][kvh][chunk][head][ACC_STRIDE]: m, l, acc[128]
          float* pa = p.apart + (((size_t)(b * NKV + kvh) * MAXCH + (c - c0)) * 3) * ACC_STRIDE;
          for (int it = tid; it < 3 * HD; it += NT) {
            const int h = it / HD, d = it % HD;
            pa[h * ACC_STRIDE + 8 + d] = at->acc[0][h][d] + at->acc[1][h][d] + at->acc[2][h][d] + at->acc[3][h][d];
          }
          if (tid < 3) { pa[tid * ACC_STRIDE + 0] = at->ml[tid][0]; pa[tid * ACC_STRIDE + 1] = at->ml[tid][1]; }
          __syncthreads();
          if (tid == 0) {
            int last = 1;
            if (nch > 1) {
              __threadfence();
              const u32 old = atomicAdd(p.acnt + b * NKV + kvh, 1u);
              last = (old == (u32)(nch - 1));
              if (last) { __threadfence(); p.acnt[b * NKV + kvh] = 0; }
            }
            ms->last = last;
          }
          __syncthreads();
          if (ms->last) {
            // merge the chunks in order; gate and sink
            const float* pb = p.apart + ((size_t)(b * NKV + kvh) * MAXCH * 3) * ACC_STRIDE;
            for (int it = tid; it < 3 * HD; it += NT) {
              const int h = it / HD, d = it % HD;
              float M = -INFINITY;
              for (int cc = 0; cc < nch; cc++) M = fmaxf(M, ldcgf(pb + ((size_t)cc * 3 + h) * ACC_STRIDE));
              float Ls = 0.f, A = 0.f;
              for (int cc = 0; cc < nch; cc++) {
                const float* q = pb + ((size_t)cc * 3 + h) * ACC_STRIDE;
                const float f = expf(ldcgf(q) - M);
                Ls = fmaf(ldcgf(q + 1), f, Ls);
                A = fmaf(ldcgf(q + 8 + d), f, A);
              }
              const int hh = kvh * 3 + h;
              const float denom = Ls + expf(at->sink[h] - M);
              const float gt = sigm(u16f(ldcg16(qk + OFF_G + hh * HD + d)));
              p.attn_out[(size_t)b * QW + hh * HD + d] = __float2bfloat16_rn(A / denom * gt);
            }
          }
          __syncthreads();
        }
        pf_o(i);
      }
      grid_bar(bar, bar_target);

      // ================= phase C: o_proj + attention short conv
      {
        if (bid < 144) {
          for (int it = tid; it < B * (QW / 8); it += NT) {
            const int b = it / (QW / 8), k = (it % (QW / 8)) * 8;
            const uint4 v = ldcg128(p.attn_out + (size_t)b * QW + k);
            u16* row = xs + b * XSA;
            *reinterpret_cast<u32*>(row + xfo(k)) = v.x; *reinterpret_cast<u32*>(row + xfo(k + 2)) = v.y;
            *reinterpret_cast<u32*>(row + xfo(k + 4)) = v.z; *reinterpret_cast<u32*>(row + xfo(k + 6)) = v.w;
          }
          __syncthreads();
          consume_tasks<0>(ttab, XSA, rg, pst[warp], [&](int sl, const float* c) { store_task(red, sl, c); });
          __syncthreads();
          for (int it = tid; it < 16 * B; it += NT) {
            const int ii = it / B, b = it % B, row = bid * 16 + ii;
            float v = 0.f;
#pragma unroll
            for (int s = 0; s < 8; s++) v += red_at(red, s, ii, b);
            const float o = bfr(v);
            const bf16* w = L.asc + row * 4;
            bf16* rb = p.ro + ((size_t)slot * MAXB + b) * 4 * H;
            float acc = ldgbf(w + 0) * u16f(ldcg16(rb + ((pos - 3) & 3) * H + row));
            acc = fmaf(ldgbf(w + 1), u16f(ldcg16(rb + ((pos - 2) & 3) * H + row)), acc);
            acc = fmaf(ldgbf(w + 2), u16f(ldcg16(rb + ((pos - 1) & 3) * H + row)), acc);
            acc = fmaf(ldgbf(w + 3), o, acc);
            rb[(pos & 3) * H + row] = __float2bfloat16_rn(o);
            p.attn_s[(size_t)b * H + row] = __float2bfloat16_rn((acc + o) / 2.23606797749979f);
          }
        }
        if (bid < 8) pf_router(i);
      }
      grid_bar(bar, bar_target);

      // ================= phase D: MLP input + router
      int msrc[6]; int nms = 0;
      for (int k = 0; k < nblk; k++) msrc[nms++] = blk[k];
      if (bnd) msrc[nms++] = SRC_AS; else msrc[nms++] = SRC_SUM + cur;
      {
        const float* mqs[1] = {L.mq};
        if (loopg) {
          gate_phases(3, 1, msrc, nms, mqs, 1, false);
          for (int b = 0; b < B; b++) {
            const float* xp = p.xg + ((size_t)b * 4 + 3) * H;
            for (int k = tid; k < H; k += NT) xf[k] = ldcgf(xp + k);
            __syncthreads();
            norm_row(xf, L.nm, xs + b * XSH, ms->scr);
            __syncthreads();
          }
        } else {
          mix_coef(p, B, msrc, nms, mqs, 1, ms);
          for (int b = 0; b < B; b++) {
            for (int c = tid; c < H / 8; c += NT) {
              float x[8]; mix_val8(p, ms, msrc, nms, b, 0, c * 8, x);
#pragma unroll
              for (int j = 0; j < 8; j++) xf[c * 8 + j] = x[j];
            }
            __syncthreads();
            norm_row(xf, L.nm, xs + b * XSH, ms->scr);
            __syncthreads();
          }
        }
        if (bid < 8) {
          consume_tasks<0>(ttab, XSH, rg, pst[warp], [&](int sl, const float* c) { store_task(red, sl, c); });
          __syncthreads();
          if (tid < 16 * B) {
            const int ii = tid / B, b = tid % B;
            float v = 0.f;
#pragma unroll
            for (int s = 0; s < 8; s++) v += red_at(red, s, ii, b);
            p.rlog[b * NE + bid * 16 + ii] = v;
          }
        }
      }
      grid_bar(bar, bar_target);

      // ================= phase E: top-8, union, w13 + activation
      {
        if (warp < B) {
          const int b = warp;
          float lg[4], v[4]; int ix[4];
#pragma unroll
          for (int k = 0; k < 4; k++) {
            ix[k] = lane + 32 * k;
            lg[k] = ldcgf(p.rlog + b * NE + ix[k]);
            v[k] = sigm(lg[k]) + __ldg(L.rbias + ix[k]);
          }
          float sw[TOPK]; int si[TOPK];
#pragma unroll
          for (int r = 0; r < TOPK; r++) {
            float bv = -INFINITY; int bi = 1 << 30;
#pragma unroll
            for (int k = 0; k < 4; k++) if (v[k] > bv || (v[k] == bv && ix[k] < bi)) { bv = v[k]; bi = ix[k]; }
#pragma unroll
            for (int o = 16; o; o >>= 1) {
              const float ov = __shfl_xor_sync(0xffffffffu, bv, o); const int oi = __shfl_xor_sync(0xffffffffu, bi, o);
              if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
            }
            si[r] = bi;
            float l = 0.f;
#pragma unroll
            for (int k = 0; k < 4; k++) if (ix[k] == bi) { l = lg[k]; v[k] = -INFINITY; }
            sw[r] = sigm(__shfl_sync(0xffffffffu, l, bi & 31));
          }
          if (lane == 0) {
            float s = 0.f;
#pragma unroll
            for (int r = 0; r < TOPK; r++) s += sw[r];
            const float inv = 8.0f / (s + 1e-20f);
#pragma unroll
            for (int r = 0; r < TOPK; r++) { ms->sel[b][r] = si[r]; ms->selw[b][r] = sw[r] / (s + 1e-20f) * 8.0f; }
            (void)inv;
          }
        }
        __syncthreads();
        {
          __shared__ u32 wcnt[4];
          u32 m = 0, bal = 0;
          if (tid < NE) {
            for (int b = 0; b < B; b++)
#pragma unroll
              for (int r = 0; r < TOPK; r++) if (ms->sel[b][r] == tid) m |= 1u << b;
            bal = __ballot_sync(0xffffffffu, m != 0);
            if (lane == 0) wcnt[warp] = __popc(bal);
          }
          __syncthreads();
          if (tid < NE && m) {
            int sl = __popc(bal & ((1u << lane) - 1));
            for (int w = 0; w < warp; w++) sl += wcnt[w];
            ms->sexp[sl] = tid; ms->smask[sl] = m;
            for (int b = 0; b < MAXB; b++) {
              float wv = 0.f;
              if (m >> b & 1) {
#pragma unroll
                for (int r = 0; r < TOPK; r++) if (ms->sel[b][r] == tid) wv = ms->selw[b][r];
              }
              ms->rw[b][sl] = wv;
            }
          }
          if (tid == 0) ms->U = wcnt[0] + wcnt[1] + wcnt[2] + wcnt[3];
        }
        __syncthreads();
#if XPF
        if (bid == NB - 1) {   // record the union for the next pass / token (read after a grid barrier)
          for (int u = tid; u < ms->U; u += NT) p.rhist[ap * (MAXU + 1) + u] = ms->sexp[u];
          if (tid == 0) p.rhist[ap * (MAXU + 1) + MAXU] = ms->U;
        }
#endif
        const int U = ms->U;
        const int N = U * 144;
        const int u0 = (int)((long)bid * N / NB), u1 = (int)((long)(bid + 1) * N / NB);
        for (int ub = u0; ub < u1; ub += RED_SLOTS / 2) {
          const int nu = min(RED_SLOTS / 2, u1 - ub);
          if (L.mx) {
            run_tasks<2>(nu * 2, ttab, XSH, rg, pst[warp], [&](int task, TD& d) {
              const int uu = ub + (task >> 1), sg = task & 1, sl = uu / 144, rt = uu % 144, e = ms->sexp[sl];
              const size_t it = ((size_t)e * 144 + rt) * 72 + sg * 36;
              d.w = L.w13c + it * 32; d.s = L.w13s + it * 16; d.x = xs; d.k0 = sg * 36; d.n = 36; d.slot = task; d.bm = bmask;
            }, [&](int sl, const float* c) { store_task(red, sl, c); });
          } else {
            run_tasks<1>(nu * 2, ttab, XSH, rg, pst[warp], [&](int task, TD& d) {
              const int uu = ub + (task >> 1), sg = task & 1, sl = uu / 144, rt = uu % 144, e = ms->sexp[sl];
              const size_t it = ((size_t)e * 144 + rt) * 36 + sg * 18;
              d.w = L.w13c + it * 32; d.s = L.w13s + it * 64; d.x = xs; d.k0 = sg * 18; d.n = 18; d.slot = task; d.bm = bmask;
            }, [&](int sl, const float* c) { store_task(red, sl, c); });
          }
          __syncthreads();
          for (int it = tid; it < nu * 8 * B; it += NT) {
            const int ul = it / (8 * B), ii = (it / B) % 8, b = it % B;
            const int uu = ub + ul, sl = uu / 144, rt = uu % 144, e = ms->sexp[sl];
            if (!(ms->smask[sl] >> b & 1)) continue;
            const float f = L.mx ? 1.0f : __ldg(L.f13 + e);
            const float gt = bfr((red_at(red, ul * 2, 2 * ii, b) + red_at(red, ul * 2 + 1, 2 * ii, b)) * f);
            const float up = bfr((red_at(red, ul * 2, 2 * ii + 1, b) + red_at(red, ul * 2 + 1, 2 * ii + 1, b)) * f);
            const float o = (4.0f * tanhf(gt * 0.25f)) * sigm(gt) * (25.0f * tanhf(up * 0.04f));
            p.act[((size_t)sl * MAXB + b) * IM + rt * 8 + ii] = __float2bfloat16_rn(o);
          }
          __syncthreads();
        }
        fround(0);
        __syncthreads();
        pf_down(i, ms->fr_s0, ms->fr_s1);
      }
      grid_bar(bar, bar_target);

      // ================= phase F: w2, weighted sum, MLP conv, new partial
      {
        const int U = ms->U;
        float* oacc = reinterpret_cast<float*>(smem + SM_MISC) + 0;   // placeholder (not used)
        (void)oacc;
        float acc_r = 0.f;   // thread (ii, b) = tid < 16 * B accumulates its row
        if (bid < 144) {
          bool first = true;
          while (true) {
            if (!first) { __syncthreads(); fround(ms->fr_s1); __syncthreads(); }
            const int s0 = ms->fr_s0, s1 = ms->fr_s1, np = ms->fr_np;
            if (s0 >= U) break;
            for (int it = tid; it < np * (IM / 8); it += NT) {
              const int pr = it / (IM / 8), k = (it % (IM / 8)) * 8;
              int q = pr, sl = s0;
              for (; sl < s1; sl++) { const int cnt = __popc(ms->smask[sl]); if (q < cnt) break; q -= cnt; }
              const u32 m = ms->smask[sl];
              int b = 0;
              for (b = 0; b < 8; b++) if (m >> b & 1) { if (q == 0) break; q--; }
              const uint4 v = ldcg128(p.act + ((size_t)sl * MAXB + b) * IM + k);
              u16* row = xs + pr * XSI;
              *reinterpret_cast<u32*>(row + xfo(k)) = v.x; *reinterpret_cast<u32*>(row + xfo(k + 2)) = v.y;
              *reinterpret_cast<u32*>(row + xfo(k + 4)) = v.z; *reinterpret_cast<u32*>(row + xfo(k + 6)) = v.w;
            }
            __syncthreads();
            if (!first) pf_down(i, s0, s1);
            first = false;
            if (L.mx) consume_tasks<2>(ttab, XSI, rg, pst[warp], [&](int sl, const float* c) { store_task(red, sl, c); });
            else consume_tasks<1>(ttab, XSI, rg, pst[warp], [&](int sl, const float* c) { store_task(red, sl, c); });
            __syncthreads();
            if (tid < 16 * B) {
              const int ii = tid / B, b = tid % B;
              for (int sl = s0; sl < s1; sl++) {
                if (!(ms->smask[sl] >> b & 1)) continue;
                const int e = ms->sexp[sl];
                const float f = L.mx ? 1.0f : __ldg(L.f2 + e);
                const int ul = sl - s0;
                const float y = bfr((red_at(red, ul * 2, ii, b) + red_at(red, ul * 2 + 1, ii, b)) * f);
                acc_r = fmaf(ms->rw[b][sl], y, acc_r);
              }
            }
            if (s1 >= U) break;
          }
          if (tid < 16 * B) {
            const int ii = tid / B, b = tid % B, row = bid * 16 + ii;
            const float o = bfr(acc_r);
            const bf16* w = L.msc + row * 4;
            bf16* rb = p.rm + ((size_t)slot * MAXB + b) * 4 * H;
            float acc = ldgbf(w + 0) * u16f(ldcg16(rb + ((pos - 3) & 3) * H + row));
            acc = fmaf(ldgbf(w + 1), u16f(ldcg16(rb + ((pos - 2) & 3) * H + row)), acc);
            acc = fmaf(ldgbf(w + 2), u16f(ldcg16(rb + ((pos - 1) & 3) * H + row)), acc);
            acc = fmaf(ldgbf(w + 3), o, acc);
            rb[(pos & 3) * H + row] = __float2bfloat16_rn(o);
            const float msv = bfr((acc + o) / 2.23606797749979f);
            const float as = u16f(ldcg16(p.attn_s + (size_t)b * H + row));
            bf16* cp = p.vecs + ((size_t)b * NVEC + cur) * H + row;
            const float res = bnd ? as : (u16f(ldcg16(cp)) + as);
            *cp = __float2bfloat16_rn(res + msv);
          }
        }
        if (ap + 1 < NAPP) pf_qkv(app_layer(ap + 1));
        else pf_head();
      }
      grid_bar(bar, bar_target);
    }  // applications
    if (nstop < NAPP) break;

    // ================= head
    {
      const int fsrc[5] = {V_H0, V_P0, V_P1 + 2, V_P2 + 2, V_P3};
      const float* oqs[1] = {p.oq};
      mix_coef(p, B, fsrc, 5, oqs, 1, ms);
      for (int b = 0; b < B; b++) {
        for (int c = tid; c < H / 8; c += NT) {
          float x[8]; mix_val8(p, ms, fsrc, 5, b, 0, c * 8, x);
#pragma unroll
          for (int j = 0; j < 8; j++) xf[c * 8 + j] = x[j];
        }
        __syncthreads();
        norm_row(xf, p.fnorm, xs + b * XSH, ms->scr);
        __syncthreads();
      }
      auto head_fin = [&](int rt, const float* c) {
        const int g = lane >> 2, t = lane & 3;
        const int row0 = rt * 16 + g, row1 = row0 + 8;
        const int b0 = 2 * t, b1 = 2 * t + 1;
        if (a.mode == 0) {
          if (b0 < B && row0 < VOCAB) a.logits[(size_t)b0 * VOCAB + row0] = 30.0f * tanhf(c[0] * (1.0f / 30.0f));
          if (b1 < B && row0 < VOCAB) a.logits[(size_t)b1 * VOCAB + row0] = 30.0f * tanhf(c[1] * (1.0f / 30.0f));
          if (b0 < B && row1 < VOCAB) a.logits[(size_t)b0 * VOCAB + row1] = 30.0f * tanhf(c[2] * (1.0f / 30.0f));
          if (b1 < B && row1 < VOCAB) a.logits[(size_t)b1 * VOCAB + row1] = 30.0f * tanhf(c[3] * (1.0f / 30.0f));
        }
      };
#if W12U
      {
        uint2* esh = reinterpret_cast<uint2*>(smem + SM_ESC);
        int* eoff = reinterpret_cast<int*>(smem + SM_ESC + ESC_MAX * 8);
        const int r0 = (int)((long)bid * RT_HEAD / NB), r1 = (int)((long)(bid + 1) * RT_HEAD / NB);
        const int base = __ldg(p.u12off + r0), nesc = __ldg(p.u12off + r1) - base;
        for (int k = tid; k <= r1 - r0; k += NT) eoff[k] = __ldg(p.u12off + r0 + k) - base;
        for (int k = tid; k < nesc && k < ESC_MAX; k += NT) esh[k] = __ldg(p.u12esc + base + k);
        __syncthreads();
        consume_w12(ttab, XSH, rg, pst[warp], esh, eoff, r0, head_fin);
      }
#else
      consume_tasks<0>(ttab, XSH, rg, pst[warp], head_fin);
#endif
      if (st + 1 < a.nsteps) pf_qkv(0);
      grid_bar(bar, bar_target);
    }
  }  // steps
  // reset the barrier counter for the next launch: the last block out
  if (tid == 0) {
    __threadfence();
    const u32 v = atomicAdd(bar + 1, 1u);
    if (v == NB - 1) { bar[0] = 0; bar[1] = 0; __threadfence(); }
  }
}

// ------------------------------------------------------------------------------------------------ host side
struct Engine { Params p; };

extern "C" void* mk_create(const void* params) {
  Engine* e = new Engine;
  memcpy(&e->p, params, sizeof(Params));
  if (cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, SM_TOTAL) != cudaSuccess) return nullptr;
  return e;
}
extern "C" int mk_params_size() { return (int)sizeof(Params); }
extern "C" int mk_layer_size() { return (int)sizeof(LayerP); }
extern "C" int mk_misc_size() { return (int)sizeof(Misc); }

extern "C" int mk_run(void* h, const void* tok, void* logits, void* out_tok, int B, int pos0, int nsteps, int mode, int stop_app, void* stream) {
  Engine* e = (Engine*)h;
  RunArgs a;
  memset(&a, 0, sizeof(a));
  a.tok = (const long long*)tok; a.logits = (float*)logits; a.out_tok = (long long*)out_tok;
  a.B = B; a.pos0 = pos0; a.nsteps = nsteps; a.mode = mode; a.stop_app = stop_app;
  void* args[] = {(void*)&e->p, (void*)&a};
  cudaError_t err = cudaLaunchCooperativeKernel((void*)mk_kernel, dim3(NB), dim3(NT), args, SM_TOTAL, (cudaStream_t)stream);
  if (err != cudaSuccess) { fprintf(stderr, "mk_run: %s\n", cudaGetErrorString(err)); return -1; }
  return 0;
}

// ------------------------------------------------------------------------------------------------ test kernel
// y[r][b] for rowtiles 0..nrt-1 of a tiled matrix (KIND 0/1/2), K columns, B operand x [8][K] bf16 (plain order);
// one block, one task per rowtile (all items), results [nrt*16][8] fp32
template <int KIND>
__global__ void __launch_bounds__(NT, 1) gemv_test(const uint4* w, const unsigned char* s, const bf16* x, int K, int nrt, float* y) {
  extern __shared__ __align__(128) unsigned char smem[];
  u16* xs = reinterpret_cast<u16*>(smem + SM_XS);
  TT* ttab = reinterpret_cast<TT*>(smem + SM_TT);
  PState* pst = reinterpret_cast<PState*>(smem + SM_PS);
  const int tid = threadIdx.x, warp = tid >> 5, lane = tid & 31;
  Ring rg;
  rg.data = smaddr(smem + SM_RING) + warp * RING_WARP;
  rg.bars = smaddr(smem + SM_BARS) + warp * RS * 8;
  rg.pos = 0;
  if (lane == 0) for (int k = 0; k < RS; k++) mbar_init(rg.bars + k * 8, 1);
  asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  const int xst = K + 8;
  for (int it = tid; it < 8 * K; it += NT) {
    const int b = it / K, k = it % K;
    xs[b * xst + xfo(k)] = *reinterpret_cast<const u16*>(x + it);
  }
  __syncthreads();
  const int nit = KIND == 0 ? K / 16 : KIND == 1 ? K / 64 : K / 32;
  const int SB = KindInfo<KIND>::SB;
  run_tasks<KIND>(nrt, ttab, xst, rg, pst[warp], [&](int task, TD& d) {
    d.w = w + (size_t)task * nit * 32; d.s = s + (size_t)task * nit * SB; d.x = xs; d.n = nit; d.slot = task; d.bm = 0xff;
  }, [&](int rt, const float* c) {
    const int g = lane >> 2, t = lane & 3;
    y[(rt * 16 + g) * 8 + 2 * t] = c[0]; y[(rt * 16 + g) * 8 + 2 * t + 1] = c[1];
    y[(rt * 16 + g + 8) * 8 + 2 * t] = c[2]; y[(rt * 16 + g + 8) * 8 + 2 * t + 1] = c[3];
  });
}
extern "C" int mk_gemv_test(int kind, const void* w, const void* s, const void* x, int K, int nrt, void* y) {
  void* args[] = {(void*)&w, (void*)&s, (void*)&x, (void*)&K, (void*)&nrt, (void*)&y};
  const void* f = kind == 0 ? (const void*)gemv_test<0> : kind == 1 ? (const void*)gemv_test<1> : (const void*)gemv_test<2>;
  cudaFuncSetAttribute(f, cudaFuncAttributeMaxDynamicSharedMemorySize, SM_TOTAL);
  cudaError_t err = cudaLaunchKernel(f, dim3(1), dim3(NT), args, SM_TOTAL, 0);
  if (err != cudaSuccess) { fprintf(stderr, "gemv_test: %s\n", cudaGetErrorString(err)); return -1; }
  return 0;
}
