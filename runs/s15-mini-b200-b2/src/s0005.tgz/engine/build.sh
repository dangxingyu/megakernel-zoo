#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
OUT=${MK_BUILD_DIR:-build}
mkdir -p "$OUT"
rm -f "$OUT/libmk.so"
# build switch: engine/TRACK (or $MK_TRACK) = "A" (the checkpoint's formats and data flow) or "B <items>"
TRACKV=${MK_TRACK:-$(cat TRACK 2>/dev/null || echo A)}
DEFS="${MK_DEFS:-}"
case " $TRACKV " in *" XPF2 "*) DEFS="$DEFS -DXPF=2";; *" XPF "*) DEFS="$DEFS -DXPF=1";; esac
case " $TRACKV " in *" W12U "*|*" W12 "*) DEFS="$DEFS -DW12U=1";; esac
nvcc -O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xptxas -v --shared -Xcompiler -fPIC $DEFS -o "$OUT/libmk.so" mk.cu 2> "$OUT/ptxas.log" || { cat "$OUT/ptxas.log"; exit 1; }
grep -E "registers|spill|smem" "$OUT/ptxas.log" | grep -A2 mk_kernel | head -5 || true
