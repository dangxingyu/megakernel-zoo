"""Weight re-layout for the megakernel: permutations of the stored bytes into MMA fragment order (no value changes).

BF16 [N, K]           -> [N/16 rowtiles][K/16 ksteps][32 lanes][4 regs][2]           (512 B per kstep tile)
NVFP4 codes [E,N,K/2] -> [E][N/16][K/64 chunks][32 lanes][4 ksteps][4 regs] bytes    (512 B per item)
      scales [E,N,K/16] (E4M3) -> [E][N/16][K/64][8 g][4 ksteps][2 halves]           (64 B per item)
MXFP8 codes [E,N,K]   -> [E][N/16][K/32][32 lanes][2 ksteps][4 regs][2]               (512 B per item)
      scales [E,N,K/32] (UE8M0) -> [E][N/16][K/32][8 g][2 halves]                     (16 B per item)
Lane = 4 g + t; reg 0: (row g, cols 2t, 2t+1), 1: (row g+8, same), 2: (row g, cols 2t+8, +9), 3: (row g+8, ...).
"""

import torch


def tile_bf16(w: torch.Tensor) -> torch.Tensor:
    n, k = w.shape
    assert n % 16 == 0 and k % 16 == 0, w.shape
    return w.contiguous().view(n // 16, 2, 8, k // 16, 2, 4, 2).permute(0, 3, 2, 5, 4, 1, 6).contiguous()


def untile_bf16(t: torch.Tensor, n: int, k: int) -> torch.Tensor:
    return t.view(n // 16, k // 16, 8, 4, 2, 2, 2).permute(0, 5, 2, 1, 4, 3, 6).reshape(n, k)


def tile_nvfp4(codes: torch.Tensor, scales: torch.Tensor):
    e, n, kb = codes.shape
    k = kb * 2
    r, kc = n // 16, k // 64
    c = codes.contiguous().view(e, r, 2, 8, kc, 4, 2, 4).permute(0, 1, 4, 3, 7, 5, 6, 2).contiguous()
    s = scales.contiguous().view(torch.uint8).view(e, r, 2, 8, kc, 4).permute(0, 1, 4, 3, 5, 2).contiguous()
    return c, s


def untile_nvfp4(c, s, e, n, k):
    r, kc = n // 16, k // 64
    codes = c.view(e, r, kc, 8, 4, 4, 2, 2).permute(0, 1, 7, 3, 2, 5, 6, 4).reshape(e, n, k // 2)
    scales = s.view(e, r, kc, 8, 4, 2).permute(0, 1, 5, 3, 2, 4).reshape(e, n, k // 16)
    return codes, scales


def tile_mxfp8(codes: torch.Tensor, scales: torch.Tensor):
    e, n, k = codes.shape
    r, kc = n // 16, k // 32
    c = codes.contiguous().view(torch.uint8).view(e, r, 2, 8, kc, 2, 2, 4, 2).permute(0, 1, 4, 3, 7, 5, 6, 2, 8).contiguous()
    s = scales.contiguous().view(torch.uint8).view(e, r, 2, 8, kc).permute(0, 1, 4, 3, 2).contiguous()
    return c, s


def untile_mxfp8(c, s, e, n, k):
    r, kc = n // 16, k // 32
    codes = c.view(e, r, kc, 8, 4, 2, 2, 2, 2).permute(0, 1, 7, 3, 2, 5, 6, 4, 8).reshape(e, n, k)
    scales = s.view(e, r, kc, 8, 2).permute(0, 1, 4, 3, 2).reshape(e, n, k // 32)
    return codes, scales


E2M1 = (0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, -0.0, -0.5, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0)


def dequant_nvfp4(codes, scales, dtype=torch.float32):
    """[E, N, K/2] u8 codes, [E, N, K/16] e4m3 scales -> [E, N, K] of code x block scale (no per-expert factor)."""
    tab = torch.tensor(E2M1, dtype=dtype, device=codes.device)
    v = tab[torch.stack([codes & 0xF, codes >> 4], -1).flatten(-2).long()]
    sc = scales.view(torch.float8_e4m3fn).to(dtype)
    return (v.unflatten(-1, (-1, 16)) * sc.unsqueeze(-1)).flatten(-2)


def dequant_mxfp8(codes, scales, dtype=torch.float32):
    v = codes.view(torch.float8_e4m3fn).to(dtype)
    ex = torch.exp2(scales.view(torch.uint8).to(dtype) - 127.0)
    return (v.unflatten(-1, (-1, 32)) * ex.unsqueeze(-1)).flatten(-2)


# ------------------------------------------------------------------------------------------------ track B: W12
# Exact 12-bit code of a BF16 matrix in the BF16 tile order. Per row a base exponent b (the 16-binade window holding
# most of the row's weights); weight = sign | exponent | mantissa with exponent in [b, b + 15] is stored as the code
# c = sign << 11 | (exponent - b) << 7 | mantissa. The kernel rebuilds bf16' = sign | (112 + exponent - b) | mantissa,
# i.e. weight * 2^(112 - b) (a power of two per row, exact), runs the MMA on bf16' and multiplies the row's fp32
# result by 2^(b - 112): bit-identical to the MMA on the stored weights while no product is subnormal. Weights outside
# the window are escapes: code 0 in the tile and weight * 2^(112 - b) (exact BF16) in a per-rowtile list, patched into
# the operand registers before the MMA.
# Item (one kstep of a rowtile, 256 weights) = 3 planes x 32 lanes x 4 B = 384 B: plane 0 the low bytes of the lane's
# values 0..3, plane 1 of values 4..7, plane 2 the high 3 bits and sign of all 8: value 2r at bits (8 - 4r) .. (10 - 4r)
# and sign at (15 - 4r) (mod 32), value 2r + 1 at (24 - 4r) .. (26 - 4r) and (31 - 4r): rotating plane 2 left by 4r
# puts register r's fields where the BF16 bits go.
def _w12_pos(r, half):
    t = [8, 9, 10, 15] if half == 0 else [24, 25, 26, 31]
    return [(x - 4 * r) % 32 for x in t]


def w12_encode(w: torch.Tensor):
    """w [N, K] bf16 -> (codes uint8 [R][KS][384], bases uint8 [N], esc_off int32 [R+1], esc int32 [n_esc][2])."""
    n, k = w.shape
    bits = w.contiguous().view(torch.int16).to(torch.int32) & 0xFFFF
    ex = (bits >> 7) & 0xFF
    hist = torch.zeros(n, 256 + 16, dtype=torch.int32, device=w.device)
    hist.scatter_add_(1, ex.long(), torch.ones_like(ex))
    cs = torch.cumsum(hist, 1)
    win = cs[:, 15:256] - torch.cat([torch.zeros(n, 1, dtype=cs.dtype, device=cs.device), cs[:, :240]], 1)
    base = win.argmax(1).to(torch.int32)
    zrow = (bits & 0x7FFF).amax(1) == 0                                # all-zero rows (padding): base 255 = row scale 0
    base = torch.where(zrow, torch.full_like(base, 255), base)
    assert int(torch.where(zrow, torch.zeros_like(base), base).max()) <= 239, "row scale 2^(b - 112) must be a normal float"
    assert not bool(((ex == 0) & ((bits & 0x7F) != 0)).any()), "denormal weights are not supported"
    off = ex - base[:, None]
    ok = ((off >= 0) & (off <= 15) & (ex > 0)) | zrow[:, None]    # zeros inside real rows are escapes
    code = torch.where(ok, ((bits >> 15) << 11) | (off << 7) | (bits & 0x7F), torch.zeros_like(bits))
    # escapes stored as weight * 2^(112 - b): exponent field e - b + 112 must stay in [1, 254] (or the weight be 0)
    ee = ex - base[:, None] + 112
    zero = (bits & 0x7FFF) == 0
    eok = zero | ((ee >= 1) & (ee <= 254))
    assert bool((ok | eok).all()), "escape not representable after the row rescale"
    escbits = torch.where(zero, bits, (bits & 0x807F) | (ee.clamp(0, 255) << 7))

    def tile(x):
        return x.view(n // 16, 2, 8, k // 16, 2, 4, 2).permute(0, 3, 2, 5, 4, 1, 6).reshape(n // 16, k // 16, 32, 8)
    ct = tile(code).to(torch.int64)
    lo = ct & 0xFF
    hi3 = (ct >> 8) & 7
    sg = (ct >> 11) & 1
    p0 = lo[..., 0] | lo[..., 1] << 8 | lo[..., 2] << 16 | lo[..., 3] << 24
    p1 = lo[..., 4] | lo[..., 5] << 8 | lo[..., 6] << 16 | lo[..., 7] << 24
    p2 = torch.zeros_like(p0)
    for r in range(4):
        for half in range(2):
            v = 2 * r + half
            pos = _w12_pos(r, half)
            for b in range(3):
                p2 |= ((hi3[..., v] >> b) & 1) << pos[b]
            p2 |= sg[..., v] << pos[3]
    planes = torch.stack([p0, p1, p2], dim=2)
    planes = torch.where(planes >= 2 ** 31, planes - 2 ** 32, planes).to(torch.int32)
    codes = planes.contiguous().view(torch.uint8).view(n // 16, k // 16, 384)
    et = tile((~ok).to(torch.int32))
    idx = et.nonzero()
    vals = tile(escbits)[idx[:, 0], idx[:, 1], idx[:, 2], idx[:, 3]]
    reg, half = idx[:, 3] // 2, idx[:, 3] % 2
    key = (idx[:, 1] << 8) | (idx[:, 2] << 3) | (reg << 1) | half
    order = torch.argsort(idx[:, 0] * (1 << 20) + key)
    rt_s = idx[order, 0]
    esc = torch.stack([key[order], vals[order].to(torch.int64)], 1).to(torch.int32).contiguous()
    cnt = torch.bincount(rt_s, minlength=n // 16)
    esc_off = torch.cat([torch.zeros(1, dtype=torch.int64, device=w.device), torch.cumsum(cnt, 0)]).to(torch.int32)
    return codes, base.to(torch.uint8), esc_off, esc


def w12_decode(codes, base, esc_off, esc, n, k):
    """Inverse of w12_encode with the kernel's arithmetic (rebuild bf16', patch, rescale by 2^(b - 112)) -> bf16 [N, K]."""
    pl = codes.view(torch.int32).view(n // 16, k // 16, 3, 32).to(torch.int64) & 0xFFFFFFFF
    vals = []
    for v in range(8):
        r, half = v // 2, v % 2
        lo = (pl[:, :, v // 4] >> (8 * (v % 4))) & 0xFF
        pos = _w12_pos(r, half)
        hi3 = sum(((pl[:, :, 2] >> pos[b]) & 1) << b for b in range(3))
        sgn = (pl[:, :, 2] >> pos[3]) & 1
        vals.append(sgn << 15 | 0x3800 | hi3 << 8 | lo)        # bf16' bits
    c = torch.stack(vals, -1)
    rt = torch.repeat_interleave(torch.arange(n // 16, device=codes.device), (esc_off[1:] - esc_off[:-1]).long())
    key = esc[:, 0].to(torch.int64); val = esc[:, 1].to(torch.int64) & 0xFFFF
    ks, lane, rg, hf = key >> 8, (key >> 3) & 31, (key >> 1) & 3, key & 1
    c[rt, ks, lane, rg * 2 + hf] = val
    t = c.view(n // 16, k // 16, 8, 4, 2, 2, 2).permute(0, 5, 2, 1, 4, 3, 6).reshape(n, k)
    t = torch.where(t >= 2 ** 15, t - 2 ** 16, t).to(torch.int16).view(torch.bfloat16).double()
    sc = torch.where(base == 255, torch.zeros_like(base, dtype=torch.float64), torch.exp2(base.double() - 112))
    return (t * sc[:, None]).to(torch.bfloat16)
