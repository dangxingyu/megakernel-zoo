// Decode megakernel for Qwen3-32B (BF16) on one B200 (GB200 card, 152 SMs).
// One persistent cooperative kernel runs whole decode steps: an op list (embed, per layer: qkv GEMM, attention,
// o GEMM + residual, gate|up GEMM + SiLU*up, down GEMM + residual; lm_head + argmax) with a grid barrier after
// every op. Track A data flow: BF16 weights as stored (re-laid out in MMA fragment order), BF16 activations
// wherever the Hugging Face BF16 model has BF16 tensors, float32 inside operators (RMSNorm statistics, GEMM
// accumulators, attention scores / softmax).
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>

typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#define NTHR 1024
#define NWARP 32
#define HID 5120
#define HD 128
#define QKV_M 10240
#define QDIM 8192
#define FF 25600
#define VOCAB 151936
#define MAXB 8
#define MAXSEG 4
#define RMS_EPS 1e-6f

enum { OP_GEMM = 1, OP_ATTN = 2 };
enum { EP_QKV = 1, EP_RESID = 2, EP_GATEUP = 3, EP_LOGITS = 4 };
enum { IN_NORM = 1, IN_ATTN = 2, IN_ACT = 3 };

// op words (int64): 0 type, 1 ep, 2 NT, 3 KS, 4 W, 5 norm weight / q_norm, 6 k_norm, 7 in_mode, 8 layer,
// 9 next GEMM's W (prefetch), 10 next NT, 11 next KS; 16 words per op
#define OPW 16

struct Params {
  const long long* ops; int nops;
  int B, nsteps, flags, nblk;
  int pos0[MAXB];
  int nforced[MAXB];
  const long long* forced; int fstride;     // forced tokens [b][fstride] (prompt / given)
  const u16* embed;                         // [VOCAB][HID]
  const u16* final_norm;                    // [HID]
  u16* x;                                   // residual stream bf16 [MAXB][HID]
  u16* qkv;                                 // [MAXB][QKV_M]
  u16* attn;                                // fragment layout [QDIM/16][8][16]
  u16* act;                                 // fragment layout [FF/16][8][16]
  float* logits;                            // [MAXB][VOCAB]
  float4* gpart;                            // cut-tile partials [tiles][2][32]
  u32* tcnt;                                // [tiles]
  u64* gkey;                                // [nblk][MAXB] argmax keys
  long long* tok_out; int tok_ld;           // [b][tok_ld] tokens chosen at each step
  int* host_tok; int* host_prog;            // host-mapped: tokens [b][tok_ld], steps done (or null)
  u32* bar; u32 bar_base;
  const u16* rope;                          // [max_ctx][2][128] bf16: cos, sin
  int max_ctx;
  u16* kc; u16* vc;                         // [layer][b][kvh][max_ctx][128] in fragment layouts
  int pf_bytes;                             // L2 prefetch of the next GEMM's first bytes at each op end
  int pf_idle_bytes;                        // ... by blocks without attention work during attention
  u64* prof;                                // debug: [step][op] global timer after each barrier (block 0)
  u64* prof2;                               // debug: [block][op][4] phase stamps of the last step
};
__device__ __forceinline__ u64 gtimer() { u64 t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); return t; }
#define MKP(k) do { if (P.prof2 && threadIdx.x == 0) P.prof2[((size_t)blockIdx.x * 400 + opi) * 4 + (k)] = gtimer(); } while (0)

#define F_LOGITS 1
#define F_ARGMAX 2

__device__ __forceinline__ float bf2f(u16 b) { return __uint_as_float(((u32)b) << 16); }
__device__ __forceinline__ u16 f2bf(float f) { u16 r; asm("cvt.rn.bf16.f32 %0, %1;" : "=h"(r) : "f"(f)); return r; }
__device__ __forceinline__ u32 f2bf2(float lo, float hi) { u32 r; asm("cvt.rn.bf16x2.f32 %0, %1, %2;" : "=r"(r) : "f"(hi), "f"(lo)); return r; }
__device__ __forceinline__ float rbf(float f) { return bf2f(f2bf(f)); }
__device__ __forceinline__ u32 pack2(u16 lo, u16 hi) { return (u32)lo | ((u32)hi << 16); }

__device__ __forceinline__ uint4 ldw(const uint4* p) { uint4 v; asm volatile("ld.global.cs.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(v.x), "=r"(v.y), "=r"(v.z), "=r"(v.w) : "l"(p)); return v; }
__device__ __forceinline__ uint2 ldcg2(const uint2* p) { uint2 v; asm volatile("ld.global.cg.v2.u32 {%0,%1}, [%2];" : "=r"(v.x), "=r"(v.y) : "l"(p)); return v; }
__device__ __forceinline__ uint4 ldcg4(const uint4* p) { uint4 v; asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(v.x), "=r"(v.y), "=r"(v.z), "=r"(v.w) : "l"(p)); return v; }
__device__ __forceinline__ float4 ldcgf4(const float4* p) { float4 v; asm volatile("ld.global.cg.v4.f32 {%0,%1,%2,%3}, [%4];" : "=f"(v.x), "=f"(v.y), "=f"(v.z), "=f"(v.w) : "l"(p)); return v; }
__device__ __forceinline__ u16 ldcg_u16(const u16* p) { unsigned short v; asm volatile("ld.global.cg.u16 %0, [%1];" : "=h"(v) : "l"(p)); return v; }
__device__ __forceinline__ u64 ldcg_u64(const u64* p) { u64 v; asm volatile("ld.global.cg.u64 %0, [%1];" : "=l"(v) : "l"(p)); return v; }
__device__ __forceinline__ void prefetch_l2(const void* p, u32 bytes) {
  asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(p), "r"(bytes) : "memory");
}

__device__ __forceinline__ void mma(float* c, const uint4& a, const uint2& b) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
    : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y));
}
__device__ __forceinline__ void mma4(float* c, u32 a0, u32 a1, u32 a2, u32 a3, u32 b0, u32 b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
    : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}

__device__ __forceinline__ int tid_v() { int v; asm volatile("mov.u32 %0, %%tid.x;" : "=r"(v)); return v; }

// slot of k (0..15) inside a k-step's 16 values of one column in B-fragment order: lane t holds k = 2t, 2t+1, 2t+8, 2t+9
__device__ __forceinline__ int fslot(int kk) { return ((kk & 7) >> 1) * 4 + (kk & 1) + ((kk >> 3) << 1); }
__device__ __forceinline__ size_t fidx(int n, int k) { return ((size_t)(k >> 4) * 8 + n) * 16 + fslot(k & 15); }

__device__ __forceinline__ u32 fkey(float f) { const u32 b = __float_as_uint(f); return (b & 0x80000000u) ? ~b : (b | 0x80000000u); }

__device__ __forceinline__ void red_release(u32* p, u32 v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ u32 atom_acqrel(u32* p, u32 v) { u32 r; asm volatile("atom.acq_rel.gpu.global.add.u32 %0, [%1], %2;" : "=r"(r) : "l"(p), "r"(v) : "memory"); return r; }
// ------------------------------------------------------------------------------------------------ grid barrier
__device__ __forceinline__ void grid_barrier(const Params& P, u32& nbar) {
  __syncthreads();
  nbar++;
  if (threadIdx.x == 0) {
    const u32 target = P.bar_base + nbar * (u32)P.nblk;
    red_release(P.bar, 1u);
    u32 v;
    while (true) {
      asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(P.bar) : "memory");
      if ((int)(v - target) >= 0) break;
      __nanosleep(20);
    }
  }
  if (P.prof && blockIdx.x == 0 && threadIdx.x == 0) {
    u64 t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); P.prof[nbar] = t;
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ shared memory
// GEMM: [xs: 320 k-steps x 8 columns x 16 bf16 = 80 KB][red: 32 warps x MAXSEG x 32 lanes x float4 = 64 KB][misc]
// attention: [S: 8 heads x (max_ctx + 8) floats][Q frag 8 KB][O partial 2 x 8 x 128 floats][misc]
#define XROW 5136   // bf16 per column of the input (5120 + 16 pad: conflict-free reads and writes)
#define XS_BYTES (8 * XROW * 2)
#define RED_OFF XS_BYTES
#define RED_BYTES (NWARP * MAXSEG * 32 * 16)
#define MISC_OFF (RED_OFF + RED_BYTES)
#define MISC_BYTES 2048
// misc: [0, 768) norm partials and 1/rms; [768, 832) argmax keys; [832, 1088) warp tile bounds; [1088, 1104) token
#define SMEM_GEMM (MISC_OFF + MISC_BYTES)

// ------------------------------------------------------------------------------------------------ GEMM
__device__ __forceinline__ void prefetch_range(const Params& P, const uint4* W, long long NT, long long KS, int bytes) {
  if (!W || bytes <= 0) return;
  if (threadIdx.x != 0) return;
  const long long U = NT * KS;
  const long long b0 = U * blockIdx.x / P.nblk, b1 = U * (blockIdx.x + 1) / P.nblk;
  long long nb = (b1 - b0) * 512;
  if (nb > bytes) nb = bytes;
  const char* p = (const char*)(W + b0 * 32);
  for (long long o = 0; o < nb; o += 65536) prefetch_l2(p + o, (u32)min((long long)65536, nb - o));
}
__device__ __forceinline__ void prefetch_next(const Params& P, const long long* op, int bytes) {
  prefetch_range(P, (const uint4*)op[9], op[10], op[11], bytes);
}

__device__ __forceinline__ void epilogue(const Params& P, int ep, int T, const float* c, u64* bkey) {
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const int n0 = 2 * t, n1 = 2 * t + 1;
  const int B = P.B;
  if (ep == EP_QKV) {
    const int r0 = T * 16 + g, r1 = r0 + 8;
    if (n0 < B) { P.qkv[n0 * QKV_M + r0] = f2bf(c[0]); P.qkv[n0 * QKV_M + r1] = f2bf(c[2]); }
    if (n1 < B) { P.qkv[n1 * QKV_M + r0] = f2bf(c[1]); P.qkv[n1 * QKV_M + r1] = f2bf(c[3]); }
  } else if (ep == EP_RESID) {
    const int r0 = T * 16 + g, r1 = r0 + 8;
    if (n0 < B) {
      u16* x = P.x + n0 * HID;
      x[r0] = f2bf(bf2f(ldcg_u16(x + r0)) + rbf(c[0]));
      x[r1] = f2bf(bf2f(ldcg_u16(x + r1)) + rbf(c[2]));
    }
    if (n1 < B) {
      u16* x = P.x + n1 * HID;
      x[r0] = f2bf(bf2f(ldcg_u16(x + r0)) + rbf(c[1]));
      x[r1] = f2bf(bf2f(ldcg_u16(x + r1)) + rbf(c[3]));
    }
  } else if (ep == EP_GATEUP) {   // tile T: rows g = gate row T*8+g, rows g+8 = up row T*8+g
    const int i = T * 8 + g;
    if (n0 < B) {
      const float gt = rbf(c[0]); const float s = rbf(gt / (1.0f + expf(-gt)));
      P.act[fidx(n0, i)] = f2bf(s * rbf(c[2]));
    }
    if (n1 < B) {
      const float gt = rbf(c[1]); const float s = rbf(gt / (1.0f + expf(-gt)));
      P.act[fidx(n1, i)] = f2bf(s * rbf(c[3]));
    }
  } else {   // EP_LOGITS
    const int r0 = T * 16 + g, r1 = r0 + 8;
    const float v0 = rbf(c[0]), v1 = rbf(c[1]), v2 = rbf(c[2]), v3 = rbf(c[3]);
    if (P.flags & F_LOGITS) {
      if (n0 < B) { P.logits[(size_t)n0 * VOCAB + r0] = v0; P.logits[(size_t)n0 * VOCAB + r1] = v2; }
      if (n1 < B) { P.logits[(size_t)n1 * VOCAB + r0] = v1; P.logits[(size_t)n1 * VOCAB + r1] = v3; }
    }
    // best per column: larger key wins; ties -> lower row (key low word = ~row)
    u64 k0 = ((u64)fkey(v0) << 32) | (u32)~r0, k2 = ((u64)fkey(v2) << 32) | (u32)~r1;
    u64 k1 = ((u64)fkey(v1) << 32) | (u32)~r0, k3 = ((u64)fkey(v3) << 32) | (u32)~r1;
    u64 a = k0 > k2 ? k0 : k2, b = k1 > k3 ? k1 : k3;
#pragma unroll
    for (int o = 4; o < 32; o <<= 1) {
      const u64 ao = __shfl_xor_sync(0xffffffffu, a, o), bo = __shfl_xor_sync(0xffffffffu, b, o);
      a = ao > a ? ao : a; b = bo > b ? bo : b;
    }
    if (g == 0) {
      if (n0 < B) atomicMax((unsigned long long*)&bkey[n0], (unsigned long long)a);
      if (n1 < B) atomicMax((unsigned long long*)&bkey[n1], (unsigned long long)b);
    }
  }
}

// RMSNorm of the residual stream into the block's B-fragment input: threads 0..639 hold 8 values of every column
__device__ void norm_input(const Params& P, const u16* w, unsigned char* sm) {
  u16* xs = (u16*)sm;
  float* red = (float*)(sm + MISC_OFF);   // [20 warps][8 columns]
  const int tid = tid_v(), wid = tid >> 5, lane = tid & 31;
  const int B = P.B;
  const bool act = tid < HID / 8;
  uint4 xr[MAXB];
  uint4 wv4 = make_uint4(0u, 0u, 0u, 0u);
  if (act) {
    wv4 = __ldg((const uint4*)w + tid);
#pragma unroll
    for (int b = 0; b < MAXB; b++) xr[b] = ldcg4((const uint4*)(P.x + (b < B ? b : 0) * HID) + tid);
  } else {
#pragma unroll
    for (int b = 0; b < MAXB; b++) xr[b] = make_uint4(0u, 0u, 0u, 0u);
  }
#pragma unroll
  for (int b = 0; b < MAXB; b++) {
    if (b < B) {
      const u32 v[4] = {xr[b].x, xr[b].y, xr[b].z, xr[b].w};
      float ss = 0.f;
#pragma unroll
      for (int j = 0; j < 4; j++) {
        const float lo = bf2f((u16)(v[j] & 0xffff)), hi = bf2f((u16)(v[j] >> 16));
        ss = fmaf(lo, lo, ss); ss = fmaf(hi, hi, ss);
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
      if (lane == 0 && wid < 20) red[wid * 8 + b] = ss;
    }
  }
  __syncthreads();
  if (wid < B) {   // warp b: 1/rms of column b from the 20 warp partials
    float v = lane < 20 ? red[lane * 8 + wid] : 0.f;
#pragma unroll
    for (int o = 16; o; o >>= 1) v += __shfl_xor_sync(0xffffffffu, v, o);
    if (lane == 0) red[160 + wid] = rsqrtf(v * (1.0f / HID) + RMS_EPS);
  }
  __syncthreads();
  if (act) {
    const u32 wv[4] = {wv4.x, wv4.y, wv4.z, wv4.w};
    const int k0 = tid * 8, ks = k0 >> 4, hh = (k0 >> 3) & 1;
#pragma unroll
    for (int b = 0; b < MAXB; b++) {
      if (b < B) {
        const float r = red[160 + b];
        const u32 v[4] = {xr[b].x, xr[b].y, xr[b].z, xr[b].w};
        u32 o[4];
#pragma unroll
        for (int j = 0; j < 4; j++) {
          const float a0 = rbf(bf2f((u16)(v[j] & 0xffff)) * r), a1 = rbf(bf2f((u16)(v[j] >> 16)) * r);
          o[j] = f2bf2(bf2f((u16)(wv[j] & 0xffff)) * a0, bf2f((u16)(wv[j] >> 16)) * a1);
        }
        // u32 slot 2j + hh of the k-step holds pair j of half hh: exchange with the partner thread (other half)
        // so that each writes 4 consecutive slots (hh 0: slots 0-3 = pairs 0, 1; hh 1: slots 4-7 = pairs 2, 3)
        const u32 s0 = hh ? o[0] : o[2], s1 = hh ? o[1] : o[3];
        const u32 r0 = __shfl_xor_sync(0xffffffffu, s0, 1), r1 = __shfl_xor_sync(0xffffffffu, s1, 1);
        const uint4 q = hh ? make_uint4(r0, o[2], r1, o[3]) : make_uint4(o[0], r0, o[1], r1);
        *(uint4*)(xs + (size_t)b * XROW + ks * 16 + hh * 8) = q;
      }
    }
  }
  __syncthreads();
}

// one GEMM op: this block's contiguous range of (tile, k-step) units, split over its warps
template <int IN>
__device__ void gemm_op(const Params& P, const long long* op, unsigned char* sm, int opi) {
  MKP(0);
  const int ep = (int)op[1];
  const int NT = (int)op[2], KS = (int)op[3];
  const uint4* W = (const uint4*)op[4];
  const int tid = tid_v(), wid = tid >> 5, lane = tid & 31;
  const long long U = (long long)NT * KS;
  const int b0 = (int)(U * blockIdx.x / P.nblk), b1 = (int)(U * (blockIdx.x + 1) / P.nblk);
  const int w0 = b0 + (int)((long long)(b1 - b0) * wid / NWARP), w1 = b0 + (int)((long long)(b1 - b0) * (wid + 1) / NWARP);
  u64* bkey = (u64*)(sm + MISC_OFF + 768);
  if (ep == EP_LOGITS && tid < MAXB) bkey[tid] = 0ull;
  if (IN == IN_NORM) norm_input(P, (const u16*)op[5], sm);
  MKP(1);
  const uint2* xg = (const uint2*)(IN == IN_ATTN ? P.attn : P.act);
  const uint2* xsm = (const uint2*)sm;
  const int xoff = (lane >> 2) * (XROW / 4) + (lane & 3);
  const bool xact = (lane >> 2) < P.B;
  float4* red = (float4*)(sm + RED_OFF) + wid * MAXSEG * 32;
  // stream: one segment per tile the warp's range touches
  if (lane == 0) {   // the warp's first and last tile (empty range: none)
    int* wft = (int*)(sm + MISC_OFF + 832);
    wft[2 * wid] = w1 > w0 ? w0 / KS : 1 << 30;
    wft[2 * wid + 1] = w1 > w0 ? (w1 - 1) / KS : -1;
  }
  int seg = 0;
  for (int u = w0; u < w1;) {
    const int T = u / KS;
    const int ue = min((T + 1) * KS, w1);
    const int cnt = ue - u;
    const uint4* wp = W + (size_t)u * 32 + lane;
    const int kk0 = u - T * KS;
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    int i = 0;
    for (; i + 4 <= cnt; i += 4) {
      uint4 a[4]; uint2 xb[4];
#pragma unroll
      for (int j = 0; j < 4; j++) a[j] = ldw(wp + (size_t)(i + j) * 32);
#pragma unroll
      for (int j = 0; j < 4; j++) {
        const int kk = kk0 + i + j;
        if (IN == IN_NORM) xb[j] = xsm[xoff + kk * 4];
        else xb[j] = xact ? ldcg2(xg + (size_t)kk * 32 + lane) : make_uint2(0u, 0u);
      }
#pragma unroll
      for (int j = 0; j < 4; j++) mma(c, a[j], xb[j]);
    }
    if (i < cnt) {   // 1-3 left: every load issued (clamped address), the extra ones not used
      const int n = cnt - i;
      uint4 a[3]; uint2 xb[3];
#pragma unroll
      for (int j = 0; j < 3; j++) a[j] = ldw(wp + (size_t)(i + min(j, n - 1)) * 32);
#pragma unroll
      for (int j = 0; j < 3; j++) {
        const int kk = kk0 + i + min(j, n - 1);
        if (IN == IN_NORM) xb[j] = xsm[xoff + kk * 4];
        else xb[j] = xact ? ldcg2(xg + (size_t)kk * 32 + lane) : make_uint2(0u, 0u);
      }
      mma(c, a[0], xb[0]);
      if (n > 1) mma(c, a[1], xb[1]);
      if (n > 2) mma(c, a[2], xb[2]);
    }
    red[seg * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
    seg++;
    u = ue;
  }
  __syncthreads();
  MKP(2);
  // block reduction: tile T gets the warps whose ranges overlap it, in warp order
  const int tb0 = b0 / KS, tb1 = (b1 - 1) / KS;
  const float4* redall = (const float4*)(sm + RED_OFF);
  const int* wft = (const int*)(sm + MISC_OFF + 832);
  for (int T = tb0 + wid; T <= tb1; T += NWARP) {
    float s[4] = {0.f, 0.f, 0.f, 0.f};
    for (int w = 0; w < NWARP; w++) {
      const int f = wft[2 * w], l = wft[2 * w + 1];
      if (T < f || T > l) continue;
      const float4 v = redall[(w * MAXSEG + (T - f)) * 32 + lane];
      s[0] += v.x; s[1] += v.y; s[2] += v.z; s[3] += v.w;
    }
    const bool full = (T * KS >= b0) && ((T + 1) * KS <= b1);
    if (full) {
      epilogue(P, ep, T, s, bkey);
    } else {
      const int side = (T * KS < b0) ? 1 : 0;
      P.gpart[((size_t)T * 2 + side) * 32 + lane] = make_float4(s[0], s[1], s[2], s[3]);
      __syncwarp();
      u32 old = 0;
      if (lane == 0) old = atom_acqrel(&P.tcnt[T], 1u);
      old = __shfl_sync(0xffffffffu, old, 0);
      if (old & 1u) {
        const float4 o = ldcgf4(&P.gpart[((size_t)T * 2 + (1 - side)) * 32 + lane]);
        float r[4];
        if (side == 0) { r[0] = s[0] + o.x; r[1] = s[1] + o.y; r[2] = s[2] + o.z; r[3] = s[3] + o.w; }
        else { r[0] = o.x + s[0]; r[1] = o.y + s[1]; r[2] = o.z + s[2]; r[3] = o.w + s[3]; }
        epilogue(P, ep, T, r, bkey);
      }
    }
  }
  if (ep == EP_LOGITS) {
    __syncthreads();
    if (tid < P.B) P.gkey[blockIdx.x * MAXB + tid] = bkey[tid];
  }
}

// ------------------------------------------------------------------------------------------------ attention
// One block per (sequence, kv head) unit: q/k norm + RoPE, K/V append, scores (tensor cores: Q as A with the 8
// heads of the group as rows 0-7, K as B with 8 positions as columns), softmax in float32, P (bf16) x V.
// K cache per unit: 8-position blocks of [lane][8 k-steps][2 u32] (B fragments); V cache: 16-position tiles of
// [16 dim blocks][lane][2 u32].
__device__ void attn_op(const Params& P, const long long* op, int step, unsigned char* sm) {
  const int tid = tid_v(), wid = tid >> 5, lane = tid & 31, g = lane >> 2, t = lane & 3;
  const int layer = (int)op[8];
  const int u = blockIdx.x;
  if (u >= P.B * 8) {   // no attention work: pull the o projection's weights into L2
    prefetch_next(P, op, P.pf_idle_bytes);
    return;
  }
  const int b = u >> 3, h = u & 7;
  const int pos = P.pos0[b] + step;
  const int n = pos + 1;
  const int mc = P.max_ctx;
  const int SST = mc + 8;   // S row stride in floats
  float* S = (float*)sm;                                  // [8][SST]
  u16* Qs = (u16*)(sm + 8 * SST * 4);                     // [8 heads][128] bf16 after norm + rope
  float* O = (float*)(sm + 8 * SST * 4 + 2048);           // [2][8][128]
  float* L = O + 2 * 8 * 128;                             // [8] row sums
  float* tmp = L + 8;                                     // [10][128] fp32 pre-rope values
  const size_t unit = ((size_t)layer * MAXB + b) * 8 + h;
  u16* Kc = P.kc + unit * (size_t)mc * HD;
  u16* Vc = P.vc + unit * (size_t)mc * HD;
  const u16* qkv = P.qkv + b * QKV_M;
  const u16* rope = P.rope + (size_t)pos * 256;
  // 1. q (8 heads, warps 0-7) and k (warp 8): RMSNorm over 128 dims, then RoPE; v (warp 9)
  if (wid < 10) {
    const u16* src = wid < 8 ? qkv + (h * 8 + wid) * HD : (wid == 8 ? qkv + QDIM + h * HD : qkv + QDIM + 1024 + h * HD);
    float v[4];
    const uint2 raw = ldcg2((const uint2*)(src + lane * 4));
    v[0] = bf2f(raw.x & 0xffff); v[1] = bf2f(raw.x >> 16); v[2] = bf2f(raw.y & 0xffff); v[3] = bf2f(raw.y >> 16);
    if (wid < 9) {
      float ss = v[0] * v[0] + v[1] * v[1] + v[2] * v[2] + v[3] * v[3];
#pragma unroll
      for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffffu, ss, o);
      const float r = rsqrtf(ss * (1.0f / HD) + RMS_EPS);
      const u16* nw = (const u16*)(wid < 8 ? op[5] : op[6]);
#pragma unroll
      for (int j = 0; j < 4; j++) v[j] = rbf(bf2f(nw[lane * 4 + j]) * rbf(v[j] * r));
    }
#pragma unroll
    for (int j = 0; j < 4; j++) tmp[wid * 128 + lane * 4 + j] = v[j];
    __syncwarp();
    if (wid < 9) {
      float o[4];
#pragma unroll
      for (int j = 0; j < 4; j++) {
        const int d = lane * 4 + j;
        const float rh = d < 64 ? -tmp[wid * 128 + d + 64] : tmp[wid * 128 + d - 64];
        o[j] = rbf(rbf(v[j] * bf2f(rope[d])) + rbf(rh * bf2f(rope[128 + d])));
      }
      if (wid < 8) {
#pragma unroll
        for (int j = 0; j < 4; j++) Qs[wid * 128 + lane * 4 + j] = f2bf(o[j]);
      } else {   // k -> cache position pos: block pos/8, column pos%8 (lanes 4c..4c+3), k-step d/16
        const int blk = pos >> 3, cn = pos & 7;
#pragma unroll
        for (int j = 0; j < 4; j++) {
          const int d = lane * 4 + j, ks = d >> 4, kk = d & 15;
          const int tt = (kk & 7) >> 1, reg = kk >> 3, half = kk & 1;
          Kc[((((size_t)blk * 32 + cn * 4 + tt) * 8 + ks) * 2 + reg) * 2 + half] = f2bf(o[j]);
        }
      }
    } else {   // v -> cache: tile pos/16, position pp: t = (pp & 7) / 2, reg = pp / 8, half = pp & 1; dim d: block d/8, g = d%8
      const int tile = pos >> 4, pp = pos & 15;
      const int tt = (pp & 7) >> 1, reg = pp >> 3, half = pp & 1;
#pragma unroll
      for (int j = 0; j < 4; j++) {
        const int d = lane * 4 + j, db = d >> 3, gg = d & 7;
        Vc[((((size_t)tile * 16 + db) * 32 + gg * 4 + tt) * 2 + reg) * 2 + half] = f2bf(v[j]);
      }
    }
  }
  __syncthreads();
  // 2. scores: warp w takes 8-position blocks w, w + 32, ...
  {
    u32 qa[8][2];
#pragma unroll
    for (int ks = 0; ks < 8; ks++) {
      qa[ks][0] = *(const u32*)(Qs + g * 128 + ks * 16 + 2 * t);
      qa[ks][1] = *(const u32*)(Qs + g * 128 + ks * 16 + 8 + 2 * t);
    }
    const float scale = 0.08838834764831845f;   // 128^-0.5
    const int nblk = (n + 7) >> 3;
    for (int j = wid; j < nblk; j += NWARP) {
      const uint4* kp = (const uint4*)(Kc + ((size_t)j * 32 + lane) * 32);
      uint4 k4[4];
#pragma unroll
      for (int i = 0; i < 4; i++) k4[i] = ldcg4(kp + i);
      float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        mma4(c, qa[2 * i][0], 0u, qa[2 * i][1], 0u, k4[i].x, k4[i].y);
        mma4(c, qa[2 * i + 1][0], 0u, qa[2 * i + 1][1], 0u, k4[i].z, k4[i].w);
      }
      const int p0 = j * 8 + 2 * t;
      S[g * SST + p0] = p0 < n ? c[0] * scale : -INFINITY;
      S[g * SST + p0 + 1] = p0 + 1 < n ? c[1] * scale : -INFINITY;
    }
  }
  __syncthreads();
  // 3. softmax per head (warp hh): max, exp, sum; positions up to the next multiple of 16 get 0
  const int n16 = (n + 15) & ~15;
  if (wid < 8) {
    float* Sh = S + wid * SST;
    float m = -INFINITY;
    for (int j = lane; j < n; j += 32) m = fmaxf(m, Sh[j]);
#pragma unroll
    for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, o));
    float l = 0.f;
    for (int j = lane; j < n16; j += 32) {
      const float e = j < n ? __expf(Sh[j] - m) : 0.f;
      Sh[j] = e; l += e;
    }
#pragma unroll
    for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffffu, l, o);
    if (lane == 0) L[wid] = l;
  }
  __syncthreads();
  // 4. P x V: warp w: dim block w & 15, half w >> 4 of the 16-position tiles
  {
    const int db = wid & 15, half = wid >> 4;
    const int nt = n16 >> 4, mid = (nt + 1) >> 1;
    const int i0 = half ? mid : 0, i1 = half ? nt : mid;
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    for (int i = i0; i < i1; i++) {
      const uint2 vb = ldcg2((const uint2*)(Vc + (((size_t)i * 16 + db) * 32 + lane) * 4));
      const float2 p0 = *(const float2*)(S + g * SST + i * 16 + 2 * t);
      const float2 p1 = *(const float2*)(S + g * SST + i * 16 + 8 + 2 * t);
      mma4(c, pack2(f2bf(p0.x), f2bf(p0.y)), 0u, pack2(f2bf(p1.x), f2bf(p1.y)), 0u, vb.x, vb.y);
    }
    O[(half * 8 + g) * 128 + db * 8 + 2 * t] = c[0];
    O[(half * 8 + g) * 128 + db * 8 + 2 * t + 1] = c[1];
  }
  __syncthreads();
  {
    const int hh = tid >> 7, d = tid & 127;   // 1024 threads = 8 heads x 128 dims
    const float o = (O[hh * 128 + d] + O[(8 + hh) * 128 + d]) / L[hh];
    P.attn[fidx(b, (h * 8 + hh) * HD + d)] = f2bf(o);
  }
}

// ------------------------------------------------------------------------------------------------ embed / argmax
__device__ __forceinline__ int resolve(const Params& P, int b) {   // argmax over the blocks' best keys (one warp)
  const int lane = threadIdx.x & 31;
  u64 best = 0;
  for (int i = lane; i < P.nblk; i += 32) { const u64 k = ldcg_u64(&P.gkey[i * MAXB + b]); best = k > best ? k : best; }
#pragma unroll
  for (int o = 16; o; o >>= 1) { const u64 k = __shfl_xor_sync(0xffffffffu, best, o); best = k > best ? k : best; }
  return (int)(~(u32)(best & 0xffffffffu));
}

__device__ void embed_op(const Params& P, int s, unsigned char* sm) {
  int* tok = (int*)(sm + MISC_OFF + 1088);
  const int tid = tid_v(), wid = tid >> 5, lane = tid & 31;
  const bool have_prev = (s > 0) && (P.flags & F_ARGMAX);
  if (blockIdx.x == 0 && have_prev) {
    if (wid < P.B) {
      const int tk = resolve(P, wid);
      if (lane == 0) {
        P.tok_out[wid * P.tok_ld + s - 1] = tk;
        if (P.host_tok) P.host_tok[wid * P.tok_ld + s - 1] = tk;
      }
    }
    __syncthreads();
    if (tid == 0 && P.host_prog) { __threadfence_system(); *(volatile int*)P.host_prog = s; }
  }
  if (s >= P.nsteps) return;
  const int b = blockIdx.x;
  if (b >= P.B) return;
  if (wid == 0) {
    int tk;
    if (s < P.nforced[b]) tk = (int)P.forced[b * P.fstride + s];
    else tk = resolve(P, b);
    if (lane == 0) tok[0] = tk;
  }
  __syncthreads();
  const uint4* src = (const uint4*)(P.embed + (size_t)tok[0] * HID);
  uint4* dst = (uint4*)(P.x + b * HID);
  for (int i = tid; i < HID / 8; i += NTHR) dst[i] = __ldg(src + i);
}

// ------------------------------------------------------------------------------------------------ kernel
__global__ void __launch_bounds__(NTHR, 1) mk_kernel(Params P) {
  extern __shared__ __align__(16) unsigned char sm[];
  u32 nbar = 0;
  for (int s = 0; s <= P.nsteps; s++) {
    embed_op(P, s, sm);
    if (s == P.nsteps) break;
    prefetch_range(P, (const uint4*)P.ops[4], P.ops[2], P.ops[3], P.pf_bytes);   // the first GEMM (layer 0 qkv)
    grid_barrier(P, nbar);
    for (int o = 0; o < P.nops; o++) {
      const long long* op = P.ops + (size_t)o * OPW;
      const int type = (int)op[0];
      if (type == OP_GEMM) {
        const int in = (int)op[7];
        if (in == IN_NORM) gemm_op<IN_NORM>(P, op, sm, o);
        else if (in == IN_ATTN) gemm_op<IN_ATTN>(P, op, sm, o);
        else gemm_op<IN_ACT>(P, op, sm, o);
        { const int opi = o; __syncthreads(); MKP(3); }
        prefetch_next(P, op, P.pf_bytes);
      } else {
        attn_op(P, op, s, sm);
      }
      grid_barrier(P, nbar);
    }
  }
}

extern "C" {
int mk_smem_bytes(int max_ctx) {
  const int att = 8 * (max_ctx + 8) * 4 + 2048 + 2 * 8 * 128 * 4 + 32 + 10 * 128 * 4;
  return att > SMEM_GEMM ? att : SMEM_GEMM;
}
int mk_launch(const Params* p, void* stream) {
  static int configured = -1;
  const int smem = mk_smem_bytes(p->max_ctx);
  if (configured != smem) {
    cudaError_t e = cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem);
    if (e != cudaSuccess) return (int)e;
    configured = smem;
  }
  Params P = *p;
  void* args[] = {&P};
  cudaError_t e = cudaLaunchCooperativeKernel((void*)mk_kernel, dim3(p->nblk), dim3(NTHR), args, smem, (cudaStream_t)stream);
  return (int)e;
}
int mk_params_size() { return (int)sizeof(Params); }
int mk_host_alloc(size_t bytes, void** host, void** dev) {
  cudaError_t e = cudaHostAlloc(host, bytes, cudaHostAllocMapped);
  if (e != cudaSuccess) return (int)e;
  return (int)cudaHostGetDevicePointer(dev, *host, 0);
}
}
