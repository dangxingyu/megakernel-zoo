// Inkling-2-Small decode engine: one persistent kernel per card per step, four cards.
// Attention TP4 by heads, experts TP4 inside every expert (intermediate 576 per card), everything else replicated.
// See notes/plan.md for the design and the layouts.
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef __nv_bfloat16 bf16;

#define H 4608
#define NL 48
#define NE 384
#define TOPK 8
#define ILOC 576
#define HD 128
#define NQL 12          // local q heads
#define NKVL 2          // local kv heads
#define DREL 16
#define RELEXT 1024
#define WIN 1024
#define NCARD 4
#define MAXB 8
#ifndef NTH
#define NTH 768   // 85 registers per thread (1024 threads: 64 and heavy spills; measured 5.95 -> 5.40 ms at B=1, e0056)
#endif
#define NWARP (NTH / 32)
#define CHUNK 128       // attention positions per block
#define MAXCHUNK 17     // up to 2176 positions
#define MAXU 64         // max union experts per layer (B<=8)
#define VOCAB_REAL 200058
#ifndef MAXSLOT
#define MAXSLOT 24
#endif
#define NSL 18           // team slices per token: 256 elements (one warp, 8 per lane) each
#define NRID 10

// ------------------------------------------------------------------------------------------------ parameters
struct W12M {               // exact 12-bit code of a BF16 matrix (engine/w12.py)
  const uint8_t* data;      // [strips][units][3][32][16]
  const uint8_t* base;      // [rows] window base exponent
  const int* hdr;           // [strips*units] escape count | offset << 8
  const int* esc;           // entries: lane<<27 | reg<<23 | half<<22 | bf16 bits
};
struct LayerW {
  const uint8_t* wqkv;      // bf16 frag [strips][U=72][4 j][32 lanes][16 B]
  const uint8_t* wo;        // bf16 frag [288][24]...
  const uint8_t* wr;        // router bf16 frag [24][72]
  const float* rbias;       // [384]
  const uint8_t* w13;       // [384][72 strips][72 units][UB]
  const uint8_t* w2;        // [384][288 strips][9 units][UB]
  const float* f13;         // [384] weight outer factor (nvfp4), unused for mxfp8
  const float* f2;
  const bf16* norm[3];      // attn_norm (local layers: all three the same) or q/k/v_input_norm
  const bf16* mlp_norm;
  const bf16* ksc;          // local: [256][4] (local channels); global: static_w [4][256]
  const bf16* vsc;
  const bf16* attn_sc;      // [4608][4]
  const bf16* mlp_sc;
  const bf16* qscale;       // [12][128]
  const bf16* rscale;       // [12][16]
  const bf16* relp;         // [16][1024]
  const float* aq;          // attention residual queries [nq][4608] (layer 0: null)
  const float* mq;          // [4608]
  W12M qkv12, wo12, wr12;
  int glob;                 // global layer
  int mx;                   // experts are mxfp8
  int qkv_strips;           // 237 or 239
  int pad;
};

struct Comm {                       // lives on each card, written by all cards
  // low-latency exchange: every value travels with its tag in one 8-byte store; buffers alternate by layer parity
  uint2 lla[2][NCARD][MAXB][H];       // o_proj partial per source card, token-major: (float bits, tag)
  uint2 llm[2][NCARD][MAXB][H];       // w2 partial
  uint2 llx[NL][NCARD][MAXU][MAXB];   // per source card: max |act| of its 576-slice per (union expert, token)
  float cand_v[NCARD][MAXB][256];   // argmax candidates per source card per block
  int cand_i[NCARD][MAXB][256];
  unsigned cnt[8];                  // 0 attn, 1 mlp, 2 amax, 3 final
};

struct Hdr {
  int card, B, nblk, pos, parity, want_logits, gen_idx, gen_n;
  unsigned xbase[4];
  unsigned tag0, pad1;                // tags of this step: tag0 + layer + 1
  float* logits; int* tokens; int* gen_out;
};
struct Ctx {
  Hdr h;
  LayerW L[NL];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm;
  const uint8_t* unembed; int un_strips; int un_row0;
  W12M un12;
  bf16* blocks;     // [9][MAXB][H] finished blocks (block 0 = h0)
  bf16* partial;    // [MAXB][H]
  bf16* attn_s;     // [MAXB][H]  attention output after its sconv (current layer)
  bf16* hist_attn;  // [NL][MAXB][3][H]
  bf16* hist_mlp;   // [NL][MAXB][3][H]
  bf16* hist_k;     // [NL][MAXB][3][256]
  bf16* hist_v;
  bf16* kc; bf16* vc; int maxctx; int pad0;  // [NL][MAXB][2][maxctx][128]
  bf16* xfrag;      // [3][72 units][32][4][2][2] bf16 frags of xq/xk/xv
  bf16* x2frag;     // router frag of the mlp input (bf16)
  uint8_t* w13frag; // quantized mlp input: f16 frag (nvfp4) or e4m3 frag (mxfp8)
  float* w13sc;     // [MAXB] outer (nvfp4) or [144][MAXB] block scales (mxfp8)
  bf16* qkvo;       // [MAXB][3840]
  float* rlog;      // [MAXB][384]
  int* ids; float* wts;   // [MAXB][8]
  int* uni; int* nuni;
  bf16* act;        // [MAXU][MAXB][576]
  uint8_t* w2frag;  // [MAXU][9 units] frags
  float* w2sc;      // [MAXU][MAXB] / [MAXU][18][MAXB]
  float* achunk;    // [MAXB][2][MAXCHUNK][6][2+128]
  unsigned* acnt;   // [MAXB][2]
  bf16* ofrag;      // o_proj B frag
  bf16* hfrag;      // final hidden frag
  float* part;      // gemv partial slots
  unsigned* scnt;   // per-strip arrival counters
  int* next_tok;    // [MAXB]
  unsigned* bar;    // [0] counter, [1] base
  Comm* comm[NCARD];
  unsigned long long* tprof;  // optional [NL+1][16] globaltimer stamps of block 0
  bf16* dbg;        // optional [NL][2][MAXB][H]: attention and mlp outputs after their sconv
  int* dbg_ids;     // optional [NL][MAXB][8]
  unsigned* amax_loc;  // [MAXU][MAXB] local running max (float bits), reset by the last strip of each expert
  unsigned* ucnt;      // [MAXU] strips finished per union expert
  uint2* rll;          // [MAXB][384] router logits as (float bits, tag): routing polls them (no grid barrier)
  uint2* tred;         // [NRID][MAXB][32][NSL] team reductions: (float bits, tag) per (value, slice)
};

// ------------------------------------------------------------------------------------------------ small helpers
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint4 ld4(const void* p) { return *reinterpret_cast<const uint4*>(p); }
__device__ __forceinline__ uint32_t cvt_fp4x2(uint32_t b) {
  uint32_t r; unsigned short bs = (unsigned short)b;
  asm("{ .reg .b8 t; cvt.u8.u16 t, %1; cvt.rn.f16x2.e2m1x2 %0, t; }" : "=r"(r) : "h"(bs));
  return r;
}
__device__ __forceinline__ uint32_t cvt_e4m3x2_f16x2(uint32_t w16) {
  uint32_t r; unsigned short h = (unsigned short)w16;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(h));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ uint32_t prmt(uint32_t a, uint32_t b, uint32_t s) { uint32_t r; asm("prmt.b32 %0,%1,%2,%3;" : "=r"(r) : "r"(a), "r"(b), "r"(s)); return r; }
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_e4m3(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float ue8m0(uint32_t e) { return e == 0 ? __int_as_float(0x00400000) : __int_as_float(e << 23); }
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }

__device__ __forceinline__ unsigned ld_relaxed_gpu(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ unsigned ld_relaxed_sys(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.sys.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void fence_acqrel_gpu() { asm volatile("fence.acq_rel.gpu;" ::: "memory"); }
__device__ __forceinline__ void fence_acqrel_sys() { asm volatile("fence.acq_rel.sys;" ::: "memory"); }
__device__ __forceinline__ unsigned ld_acquire_gpu(const unsigned* p) { unsigned v; asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ unsigned ld_acquire_sys(const unsigned* p) { unsigned v; asm volatile("ld.acquire.sys.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void red_release_gpu(unsigned* p, unsigned v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void red_relaxed_sys(unsigned* p, unsigned v) { asm volatile("red.relaxed.sys.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void red_release_sys(unsigned* p, unsigned v) { asm volatile("red.release.sys.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }

// bf16/f16 B-fragment index (m16n8k16), unit-major: element (token g, k) -> index in 16-bit elements
__device__ __forceinline__ int fidx16(int g, int k) {
  int u = k >> 6, j = (k >> 4) & 3, kk = k & 15, r = kk >> 3, t = (kk & 7) >> 1, h = kk & 1;
  return ((((u * 32 + g * 4 + t) * 4 + j) * 2 + r) * 2 + h);
}
// e4m3 B-fragment index (m16n8k32), unit = 64 k: element (g, k) -> byte index
__device__ __forceinline__ int fidx8(int g, int k) {
  int u = k >> 6, s = (k >> 5) & 1, kk = k & 31, r = kk >> 4, t = (kk & 15) >> 2, e = kk & 3;
  return ((((u * 32 + g * 4 + t) * 2 + s) * 2 + r) * 4 + e);
}

// compact layouts for B == 1 (column 0 only): lanes t = 0..3 of g = 0
__device__ __forceinline__ int fidx16c(int k) {
  int u = k >> 6, j = (k >> 4) & 3, kk = k & 15, r = kk >> 3, t = (kk & 7) >> 1, h = kk & 1;
  return ((((u * 4 + t) * 4 + j) * 2 + r) * 2 + h);
}
__device__ __forceinline__ int fidx8c(int k) {
  int u = k >> 6, s = (k >> 5) & 1, kk = k & 31, r = kk >> 4, t = (kk & 15) >> 2, e = kk & 3;
  return ((((u * 4 + t) * 2 + s) * 2 + r) * 4 + e);
}
template <bool CPT> __device__ __forceinline__ int fi16(int g, int k) { return CPT ? fidx16c(k) : fidx16(g, k); }
template <bool CPT> __device__ __forceinline__ int fi8(int g, int k) { return CPT ? fidx8c(k) : fidx8(g, k); }
#define LSZ (CPT ? 4 : 32)
#define LSL (CPT ? (lane & 3) : lane)
// ------------------------------------------------------------------------------------------------ barriers
__device__ unsigned g_barbase_dummy;
__device__ __forceinline__ void grid_bar(const Ctx& c, unsigned& nbar, unsigned base) {
  __syncthreads();
  nbar += 1;
  if (threadIdx.x == 0) {
    unsigned target = base + nbar * gridDim.x;
    red_release_gpu(&c.bar[0], 1);
#ifndef GB_BACKOFF
#define GB_BACKOFF 0
#endif
    while ((int)(ld_relaxed_gpu(&c.bar[0]) - target) < 0) { if (GB_BACKOFF) __nanosleep(GB_BACKOFF); }
    fence_acqrel_gpu();
  }
  __syncthreads();
}
// cross-card events. Host keeps xbase[k] = events of kind k before this launch.
#ifndef XSIG_FLAT
#define XSIG_HIER
#endif
#ifdef XSIG_HIER
// local grid barrier, then block 0 signals every card once (measured: 152 per-block system fences cost 5-10 us)
#define XPER 1u
#else
// every block of every card signals counter k on every card
#define XPER gridDim.x
#endif
__device__ __forceinline__ void xsignal(const Ctx& c, int k, unsigned& nbar, unsigned base);
__device__ __forceinline__ void xwait(const Ctx& c, int k, unsigned events) {
  if (threadIdx.x == 0) {
    unsigned target = (c.h.xbase[k] + events) * NCARD * XPER;
    const unsigned* p = &c.comm[c.h.card]->cnt[k];
    while ((int)(ld_relaxed_sys(p) - target) < 0) { }
    fence_acqrel_sys();
  }
  __syncthreads();
}

__device__ __forceinline__ void xsignal(const Ctx& c, int k, unsigned& nbar, unsigned base) {
#ifdef XSIG_HIER
  grid_bar(c, nbar, base);
  if (blockIdx.x == 0 && threadIdx.x == 0) {
    __threadfence_system();
    for (int d = 0; d < NCARD; d++) red_relaxed_sys(&c.comm[d]->cnt[k], 1);   // ordered by the fence above
  }
#else
  __syncthreads();
  if (threadIdx.x == 0) {
    __threadfence_system();
    for (int d = 0; d < NCARD; d++) red_relaxed_sys(&c.comm[d]->cnt[k], 1);   // ordered by the fence above
  }
#endif
}
// LL protocol: producer stores (value, tag) as one 8-byte store; consumer re-reads until the tag matches
__device__ __forceinline__ void ll_put(uint2* p, float v, unsigned tag) {
  asm volatile("st.relaxed.sys.global.v2.u32 [%0], {%1, %2};" :: "l"(p), "r"(__float_as_uint(v)), "r"(tag) : "memory");
}
__device__ __forceinline__ uint4 ld_relaxed_sys_v4(const void* p) {
  uint4 r;
  asm volatile("ld.relaxed.sys.global.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p) : "memory");
  return r;
}
__device__ __forceinline__ uint2 ld_relaxed_sys_v2(const void* p) {
  uint2 r;
  asm volatile("ld.relaxed.sys.global.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p) : "memory");
  return r;
}
// two (value, tag) pairs; spins until both tags are current
#ifndef LL_BACKOFF
#define LL_BACKOFF 32
#endif
__device__ __forceinline__ float2 ll_get2(const uint2* p, unsigned tag) {
  uint4 r = ld_relaxed_sys_v4(p);
  while (r.y != tag || r.w != tag) { __nanosleep(LL_BACKOFF); r = ld_relaxed_sys_v4(p); }
  return make_float2(__uint_as_float(r.x), __uint_as_float(r.z));
}
__device__ __forceinline__ float ll_get1(const uint2* p, unsigned tag) {
  uint2 r = ld_relaxed_sys_v2(p);
  while (r.y != tag) { __nanosleep(LL_BACKOFF); r = ld_relaxed_sys_v2(p); }
  return __uint_as_float(r.x);
}
// ------------------------------------------------------------------------------------------------ L2 prefetch
// part `part` of `nparts` of [base, base+bytes): warp 0's lanes issue bulk L2 prefetches of 32 KB.
// 32-bit arithmetic only: a 64-bit division costs ~0.1 us and this runs on critical paths (measured: 0.2 us per call
// with the 64-bit version, 59 calls per layer per block for the w2 slabs at B=8).
__device__ __forceinline__ void pf_l2(const void* p, unsigned n) {
  asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(p), "r"(n) : "memory");
}
__device__ __forceinline__ unsigned share16(unsigned n16, unsigned part, unsigned nparts) {   // floor(n16 * part / nparts)
  return (n16 / nparts) * part + ((n16 % nparts) * part) / nparts;
}
__device__ __forceinline__ void prefetch_l2(const void* base, long bytes, int part, int nparts, int pw = 0) {
#ifndef NO_PREFETCH
  if ((int)(threadIdx.x >> 5) != pw || nparts <= 0) return;
  const unsigned n16 = (unsigned)(bytes >> 4);
  const unsigned a = share16(n16, part, nparts), b = (part == nparts - 1) ? n16 : share16(n16, part + 1, nparts);
  const char* p = (const char*)base + (long)a * 16;
  const unsigned len = (b - a) * 16;
  for (unsigned o = (threadIdx.x & 31) * 32768u; o < len; o += 32u * 32768u) pf_l2(p + o, min(32768u, len - o));
#endif
}
// thread `item` (< nitems) prefetches this block's share of item's region [base + item * stride, +bytes); bytes/nparts <= 32 KB
__device__ __forceinline__ void prefetch_items(const void* p, unsigned bytes, int part, int nparts) {
#ifndef NO_PREFETCH
  const unsigned n16 = bytes >> 4;
  const unsigned a = share16(n16, part, nparts), b = (part == nparts - 1) ? n16 : share16(n16, part + 1, nparts);
  if (b > a) pf_l2((const char*)p + (long)a * 16, min(32768u, (b - a) * 16));
#endif
}
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %globaltimer;" : "=l"(t)); return t; }
#define TMB(id) do { if (c.tprof && (threadIdx.x & 31) == 0 && threadIdx.x < 32) c.tprof[49 * 64 + 1184 + blockIdx.x * 16 + (id)] = gtime(); } while (0)
#define TM(li, id) do { if (c.tprof && blockIdx.x == 0 && threadIdx.x == 0) c.tprof[(li) * 64 + (id)] = gtime(); } while (0)
// ------------------------------------------------------------------------------------------------ block reductions
template <int N>
__device__ __forceinline__ void block_sum(float* v, float* red) {  // red: smem [NWARP][N]
  int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
#pragma unroll
  for (int i = 0; i < N; i++) {
    float x = v[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x += __shfl_xor_sync(0xffffffff, x, o);
    v[i] = x;
  }
  __syncthreads();
  if (lane == 0)
#pragma unroll
    for (int i = 0; i < N; i++) red[w * N + i] = v[i];
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) {
    float s = 0.f;
    for (int j = 0; j < NWARP; j++) s += red[j * N + i];
    v[i] = s;
  }
  __syncthreads();
}
__device__ __forceinline__ float block_max1(float x, float* red) {
  int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffff, x, o));
  __syncthreads();
  if (lane == 0) red[w] = x;
  __syncthreads();
  float m = red[0];
  for (int j = 1; j < NWARP; j++) m = fmaxf(m, red[j]);
  __syncthreads();
  return m;
}

#define PER ((H + NTH - 1) / NTH)   // 5 elements per thread (the last one only for tid < 512)
#define VALID(e) (threadIdx.x + (e) * NTH < H)
// element e of thread: idx = threadIdx.x + e * NTH

// rms_norm of fp32 vector (per-thread regs) with bf16 weight -> bf16 values (as float)
__device__ __forceinline__ void rmsnorm_regs(const float* u, const bf16* w, float* y, float* red) {
  float s[1] = {0.f};
#pragma unroll
  for (int e = 0; e < PER; e++) if (VALID(e)) s[0] += u[e] * u[e];
  block_sum<1>(s, red);
  float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) { y[e] = 0.f; continue; }
    float v = u[e] * r;
    if (w) v = v * bf(w[threadIdx.x + e * NTH]);
    y[e] = rbf(v);
  }
}

__device__ __forceinline__ float sconv4f(float h0, float h1, float h2, float cur, const float* w4) {
  float acc = 0.f;
  acc = acc + h0 * w4[0];
  acc = acc + h1 * w4[1];
  acc = acc + h2 * w4[2];
  acc = acc + cur * w4[3];
  return rbf((acc + cur) * 0.4472135954999579f);
}
// static short conv over [hist0, hist1, hist2, cur]; weight [C][4]; returns bf16-rounded float
__device__ __forceinline__ float sconv4(float h0, float h1, float h2, float cur, const bf16* w4) {
  float acc = 0.f;
  acc = acc + h0 * bf(w4[0]);
  acc = acc + h1 * bf(w4[1]);
  acc = acc + h2 * bf(w4[2]);
  acc = acc + cur * bf(w4[3]);
  return rbf((acc + cur) * 0.4472135954999579f);
}

// ------------------------------------------------------------------------------------------------ GEMV skeleton
// Flattened (strip, unit) space split evenly over all warps of the grid. A strip covered by several warps is
// summed in slot order by the last warp to arrive (per-strip counter). Epilogue gets per-lane d0..d3
// (row g, col 2t), (g, 2t+1), (g+8, 2t), (g+8, 2t+1).
__device__ __forceinline__ long wstart(long T, long w, long NW) { return T * w / NW; }
__device__ __forceinline__ long warp_of(long x, long T, long NW) { return ((x + 1) * NW - 1) / T; }

#ifndef MINU
#define MINU 4
#endif
template <class OP>
__device__ void gemv(const Ctx& c, OP& op, long strips, int U) {
  const long T = strips * U;
  const long NWALL = (long)gridDim.x * NWARP;
  const long NW = max(1L, min(NWALL, T / MINU));
  // logical warp index. Ops that use every warp: block-contiguous ranges (a block streams one contiguous region;
  // the strided mapping put a block's 32 streams 729 KB apart in lockstep and some blocks ran 2x slower).
  // Small ops: consecutive logical warps on different SMs.
#ifndef GW_SPREAD_ALL
  const long gw = (NW == NWALL) ? (long)blockIdx.x * NWARP + (threadIdx.x >> 5) : (long)(threadIdx.x >> 5) * gridDim.x + blockIdx.x;
#else
  const long gw = (long)(threadIdx.x >> 5) * gridDim.x + blockIdx.x;
#endif
  if (gw >= NW) return;
  const int lane = threadIdx.x & 31;
  long beg = wstart(T, gw, NW), end = wstart(T, gw + 1, NW);
  long x = beg;
  const bool tmw = c.tprof && op.tm && gw == 0;   // block 0 warp 0 stamps its first strip
  if (tmw && lane == 0) c.tprof[op.layer * 64 + op.tm] = gtime();
  while (x < end) {
    long s = x / U;
    int u0 = (int)(x - s * U);
    int u1 = (int)min((long)U, end - s * U);
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    op.run(c, s, u0, u1, acc);
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 64 + op.tm + 1] = gtime();
    long fw = warp_of(s * U, T, NW), lw = warp_of(s * U + U - 1, T, NW);
    if (fw == lw) {
      op.epi(c, s, acc);
    } else {
      float* slot = c.part + ((s * MAXSLOT + (gw - fw)) * 32 + lane) * 4;
      *reinterpret_cast<float4*>(slot) = make_float4(acc[0], acc[1], acc[2], acc[3]);
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) { __threadfence(); old = atomicAdd(&c.scnt[s], 1u); }
      old = __shfl_sync(0xffffffff, old, 0);
      if (old == (unsigned)(lw - fw)) {
        __threadfence();
        float a[4] = {0.f, 0.f, 0.f, 0.f};
        const int ns = (int)(lw - fw) + 1;
        for (int k0 = 0; k0 < ns; k0 += 8) {
          float4 p[8];
#pragma unroll
          for (int q = 0; q < 8; q++)
            p[q] = (k0 + q < ns) ? __ldcg(reinterpret_cast<const float4*>(c.part + ((s * MAXSLOT + k0 + q) * 32 + lane) * 4))
                                 : make_float4(0.f, 0.f, 0.f, 0.f);
#pragma unroll
          for (int q = 0; q < 8; q++)
            if (k0 + q < ns) { a[0] += p[q].x; a[1] += p[q].y; a[2] += p[q].z; a[3] += p[q].w; }
        }
        if (lane == 0) c.scnt[s] = 0;
        __syncwarp();
        __threadfence();
        op.epi(c, s, a);
      }
    }
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 64 + op.tm + 2] = gtime();
    x = s * U + u1;
  }
}

// Alternative schedule: block b owns strips b, b+nblk, ...; its 32 warps split the strip's units; partials reduced in
// shared memory in warp order (deterministic, no global hand-off). red: 32 warps x 32 lanes x float4 (16 KB).
template <class OP>
__device__ void gemv_blk(const Ctx& c, OP& op, int strips, int U, float* red) {
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  const int u0 = U * w / NWARP, u1 = U * (w + 1) / NWARP;
  for (int s = blockIdx.x; s < strips; s += gridDim.x) {
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    if (u1 > u0) op.run(c, s, u0, u1, acc);
    *reinterpret_cast<float4*>(red + (w * 32 + lane) * 4) = make_float4(acc[0], acc[1], acc[2], acc[3]);
    __syncthreads();
    if (w == (s / gridDim.x) % NWARP) {
      float a[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll 8
      for (int k = 0; k < NWARP; k++) {
        float4 p = *reinterpret_cast<const float4*>(red + (k * 32 + lane) * 4);
        a[0] += p.x; a[1] += p.y; a[2] += p.z; a[3] += p.w;
      }
      op.epi(c, s, a);
    }
    __syncthreads();
  }
}
#ifndef GEMV_BLK
#define GEMV_BLK 23   // qkv, o_proj, router, w2 by block-per-strip (measured best, e0053, e0062)
#endif
template <class OP>
__device__ __forceinline__ void gemv_sel(const Ctx& c, OP& op, long strips, int U, int bit, float* red) {
  if (GEMV_BLK & bit) gemv_blk(c, op, (int)strips, U, red);
  else gemv(c, op, strips, U);
}

// BF16 dense: weights [strip][unit][j][lane][16B]; B frags (bf16) [unit][lane][j][2 u32]
template <bool CPT>
__device__ __forceinline__ void run_bf16(const uint8_t* wstrip, const uint32_t* xf, int u0, int u1, float* acc, int B) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  int u = u0;
  for (; u + 2 <= u1; u += 2) {
    uint4 w[8];
#pragma unroll
    for (int q = 0; q < 8; q++) w[q] = ldg_nc(wstrip + ((long)(u + (q >> 2)) * 4 + (q & 3)) * 512 + lane * 16);
    uint4 b[4];
#pragma unroll
    for (int q = 0; q < 4; q++) b[q] = act ? ld4(xf + ((u + (q >> 1)) * LSZ + LSL) * 8 + (q & 1) * 4) : make_uint4(0, 0, 0, 0);
#pragma unroll
    for (int q = 0; q < 8; q++) {
      const uint4& bb = b[q >> 1];
      uint32_t b0 = (q & 1) ? bb.z : bb.x, b1 = (q & 1) ? bb.w : bb.y;
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b0, b1);
    }
  }
  for (; u < u1; u++) {
    uint4 w[4];
#pragma unroll
    for (int q = 0; q < 4; q++) w[q] = ldg_nc(wstrip + ((long)u * 4 + q) * 512 + lane * 16);
    uint4 b[2];
#pragma unroll
    for (int q = 0; q < 2; q++) b[q] = act ? ld4(xf + (u * LSZ + LSL) * 8 + q * 4) : make_uint4(0, 0, 0, 0);
#pragma unroll
    for (int q = 0; q < 4; q++) {
      const uint4& bb = b[q >> 1];
      uint32_t b0 = (q & 1) ? bb.z : bb.x, b1 = (q & 1) ? bb.w : bb.y;
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b0, b1);
    }
  }
}

// 12-bit exact BF16 code (track B): decode into bf16x2 registers, patch escapes, MMA.
__device__ __forceinline__ uint32_t prmt0(uint32_t a, uint32_t sel) { uint32_t r; asm("prmt.b32 %0,%1,0,%2;" : "=r"(r) : "r"(a), "r"(sel)); return r; }
__device__ __forceinline__ uint32_t w12dec(uint32_t bytes, int half, uint32_t nib, int a, uint32_t E128) {
  uint32_t y = prmt0(bytes, half ? 0xB3A2u : 0x9180u);
  uint32_t t = (nib >> (4 * a)) & 0x000F000Fu;
  return (y & 0x807F807Fu) | (t * 128u + E128);
}
template <bool CPT>
__device__ __forceinline__ void run_w12(const W12M& M, long strip, const uint32_t* xf, int u0, int u1, float* acc, int B, int U) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  uint32_t eg = M.base[strip * 16 + g], eg8 = M.base[strip * 16 + g + 8];
  const uint32_t E0 = (eg | (eg << 16)) << 7, E1 = (eg8 | (eg8 << 16)) << 7;
  const uint8_t* wbase = M.data + strip * (long)U * 1536;
  const int* hdr = M.hdr + strip * (long)U;
  for (int u = u0; u < u1; u++) {
    uint4 d0 = ldg_nc(wbase + (long)u * 1536 + lane * 16);
    uint4 d1 = ldg_nc(wbase + (long)u * 1536 + 512 + lane * 16);
    uint4 dn = ldg_nc(wbase + (long)u * 1536 + 1024 + lane * 16);
    int hd = __ldg(hdr + u);
    uint4 b0 = act ? ld4(xf + (u * LSZ + LSL) * 8) : make_uint4(0, 0, 0, 0);
    uint4 b1 = act ? ld4(xf + (u * LSZ + LSL) * 8 + 4) : make_uint4(0, 0, 0, 0);
    uint32_t by[8] = {d0.x, d0.y, d0.z, d0.w, d1.x, d1.y, d1.z, d1.w};
    uint32_t nb[4] = {dn.x, dn.y, dn.z, dn.w};
    uint32_t a[16];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      a[4 * j + 0] = w12dec(by[2 * j], 0, nb[j], 0, E0);
      a[4 * j + 1] = w12dec(by[2 * j], 1, nb[j], 1, E1);
      a[4 * j + 2] = w12dec(by[2 * j + 1], 0, nb[j], 2, E0);
      a[4 * j + 3] = w12dec(by[2 * j + 1], 1, nb[j], 3, E1);
    }
    int cnt = hd & 0xFF;
    if (cnt) {
      const int* e = M.esc + (hd >> 8);
      for (int q = 0; q < cnt; q++) {
        int en = __ldg(e + q);
        if ((en >> 27 & 31) == lane) {
          int r = (en >> 23) & 15, hf = (en >> 22) & 1;
          uint32_t val = en & 0xFFFF;
#pragma unroll
          for (int k = 0; k < 16; k++)
            if (k == r) a[k] = hf ? ((a[k] & 0x0000FFFFu) | (val << 16)) : ((a[k] & 0xFFFF0000u) | val);
        }
      }
    }
    uint32_t bb[8] = {b0.x, b0.y, b0.z, b0.w, b1.x, b1.y, b1.z, b1.w};
#pragma unroll
    for (int j = 0; j < 4; j++) mma_bf16(acc, a[4 * j], a[4 * j + 1], a[4 * j + 2], a[4 * j + 3], bb[2 * j], bb[2 * j + 1]);
  }
}

// NVFP4 unit (64 k): codes [lane][16B] (512 B) + scales [g][8B] (64 B). B frags f16 [unit][lane][j][2].
#define UB4 576
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {  // bytes (g,g8) j0, (g,g8) j1 -> {g,g},{g8,g8},{g,g},{g8,g8}
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
__device__ __forceinline__ void fp4_unit(const uint4& cw, const uint2& sw, const uint4& b01, const uint4& b23, float* acc) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t ss[2] = {sw.x, sw.y};
  uint32_t bb[8] = {b01.x, b01.y, b01.z, b01.w, b23.x, b23.y, b23.z, b23.w};
#pragma unroll
  for (int jj = 0; jj < 2; jj++) {
    uint32_t sc[4];
    scl4(ss[jj], sc);
#pragma unroll
    for (int h = 0; h < 2; h++) {
      int j = jj * 2 + h;
      uint32_t a[4];
      cvt4(cc[j], a);
      uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
      mma_f16(acc, hmul2(a[0], sg), hmul2(a[1], sg8), hmul2(a[2], sg), hmul2(a[3], sg8), bb[2 * j], bb[2 * j + 1]);
    }
  }
}
// MXFP8 unit (64 k = 2 k32 steps): codes [s][lane][16B] (1024 B) + scales [g][s][hi] (32 B).
// B frags e4m3 [unit][lane][s][2 u32] (16 B per lane); act block scales fp32 [kblock32][MAXB]
#define UB8 1056
__device__ __forceinline__ void fp8_unit(const uint4& c0, const uint4& c1, uint32_t sw, const uint4& b, const float* xs, int u, float* acc) {
  const int lane = threadIdx.x & 31, t = lane & 3;
#pragma unroll
  for (int s = 0; s < 2; s++) {
    const uint4& cc = s ? c1 : c0;
    float d[4] = {0.f, 0.f, 0.f, 0.f};
    mma_e4m3(d, cc.x, cc.y, cc.z, cc.w, s ? b.z : b.x, s ? b.w : b.y);
    float fg = ue8m0((sw >> (16 * s)) & 0xff), fg8 = ue8m0((sw >> (16 * s + 8)) & 0xff);
    float2 fa = *reinterpret_cast<const float2*>(xs + (u * 2 + s) * MAXB + 2 * t);
    acc[0] = __fmaf_rn(d[0], __fmul_rn(fg, fa.x), acc[0]);
    acc[1] = __fmaf_rn(d[1], __fmul_rn(fg, fa.y), acc[1]);
    acc[2] = __fmaf_rn(d[2], __fmul_rn(fg8, fa.x), acc[2]);
    acc[3] = __fmaf_rn(d[3], __fmul_rn(fg8, fa.y), acc[3]);
  }
}
template <bool CPT>
__device__ __forceinline__ void run_q(const uint8_t* wstrip, const uint8_t* xf, const float* xs, int u0, int u1, float* acc, int B, int mx) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  if (!mx) {
    int u = u0;
#ifndef FP4_UNROLL
#define FP4_UNROLL 2
#endif
    for (; u + FP4_UNROLL <= u1; u += FP4_UNROLL) {
      uint4 cw[FP4_UNROLL]; uint2 sw[FP4_UNROLL];
#pragma unroll
      for (int q = 0; q < FP4_UNROLL; q++) {
        cw[q] = ldg_nc(wstrip + (long)(u + q) * UB4 + lane * 16);
        sw[q] = ldg_nc2(wstrip + (long)(u + q) * UB4 + 512 + g * 8);
      }
#pragma unroll
      for (int q = 0; q < FP4_UNROLL; q++) {
        uint4 b0 = act ? ld4(xf + ((u + q) * LSZ + LSL) * 32) : make_uint4(0, 0, 0, 0);
        uint4 b1 = act ? ld4(xf + ((u + q) * LSZ + LSL) * 32 + 16) : make_uint4(0, 0, 0, 0);
        fp4_unit(cw[q], sw[q], b0, b1, acc);
      }
    }
    for (; u < u1; u++) {
      uint4 cw = ldg_nc(wstrip + (long)u * UB4 + lane * 16);
      uint2 sw = ldg_nc2(wstrip + (long)u * UB4 + 512 + g * 8);
      uint4 b0 = act ? ld4(xf + (u * LSZ + LSL) * 32) : make_uint4(0, 0, 0, 0);
      uint4 b1 = act ? ld4(xf + (u * LSZ + LSL) * 32 + 16) : make_uint4(0, 0, 0, 0);
      fp4_unit(cw, sw, b0, b1, acc);
    }
  } else {
    int u = u0;
#ifndef FP8_UNROLL
#define FP8_UNROLL 1
#endif
#if FP8_UNROLL > 1
    for (; u + FP8_UNROLL <= u1; u += FP8_UNROLL) {
      uint4 c0[FP8_UNROLL], c1[FP8_UNROLL]; uint32_t sw[FP8_UNROLL];
#pragma unroll
      for (int q = 0; q < FP8_UNROLL; q++) {
        c0[q] = ldg_nc(wstrip + (long)(u + q) * UB8 + lane * 16);
        c1[q] = ldg_nc(wstrip + (long)(u + q) * UB8 + 512 + lane * 16);
        sw[q] = ldg_nc1(wstrip + (long)(u + q) * UB8 + 1024 + g * 4);
      }
#pragma unroll
      for (int q = 0; q < FP8_UNROLL; q++) {
        uint4 b = act ? ld4(xf + ((u + q) * LSZ + LSL) * 16) : make_uint4(0, 0, 0, 0);
        fp8_unit(c0[q], c1[q], sw[q], b, xs, u + q, acc);
      }
    }
#endif
    for (; u < u1; u++) {
      uint4 c0 = ldg_nc(wstrip + (long)u * UB8 + lane * 16);
      uint4 c1 = ldg_nc(wstrip + (long)u * UB8 + 512 + lane * 16);
      uint32_t sw = ldg_nc1(wstrip + (long)u * UB8 + 1024 + g * 4);
      uint4 b = act ? ld4(xf + (u * LSZ + LSL) * 16) : make_uint4(0, 0, 0, 0);
      fp8_unit(c0, c1, sw, b, xs, u, acc);
    }
  }
}

// ------------------------------------------------------------------------------------------------ ops
struct Smem {
  float red[NWARP * 40 + 64];
  float bestv[NWARP * MAXB];
  int besti[NWARP * MAXB];
  float att[6 * CHUNK];
  float qv[6 * HD];
  float relb[6 * CHUNK];
  float misc[128];
  float opart[8][6 * HD];
  int ids[MAXB * TOPK];
  float wts[MAXB * TOPK];
  int uni[MAXU];
  int nuni;
  float minv[10];
  float mixp[30];
  float tt[40];
  float tdot[40];
  float fiv[10];
  float piv;
  // per-token state of token blockIdx.x (< B) for the whole step: finished blocks 0..7, partial (8), attention out
  __align__(16) bf16 blk[9][H];
  __align__(16) bf16 ats[H];
  union {
    struct {  // compact (B == 1) fragments, used by the red mode
      __align__(16) bf16 fx[3][H];        // xq, xk, xv
      __align__(16) bf16 fx2[H];          // router input
      __align__(16) uint8_t f13[2 * H];   // w13 input (f16 nvfp4 values or e4m3)
      __align__(16) uint8_t f2[8 * ILOC * 2];  // w2 inputs of up to 8 experts
      __align__(16) bf16 fh[H];           // final hidden
      float sc13[144 * MAXB];             // w13 input scales (mxfp8) / outer at [0]
      float sc2[8 * 18 * MAXB];           // w2 input scales / outer at [ui][0][0]
    };
    __align__(16) uint8_t stage[73728];   // std mode: the current GEMV's 8-column B fragments
  };
};
// std mode: copy a GEMV's B fragments (global, L2-resident) into shared memory once per block
__device__ __forceinline__ void stage_frags(Smem& sm, const void* src, int bytes, const void* src2 = nullptr, int bytes2 = 0) {
  const uint4* s4 = reinterpret_cast<const uint4*>(src);
  uint4* d4 = reinterpret_cast<uint4*>(sm.stage);
  for (int k = threadIdx.x; k < bytes / 16; k += NTH) d4[k] = __ldcg(s4 + k);
  if (src2) {
    const uint4* t4 = reinterpret_cast<const uint4*>(src2);
    for (int k = threadIdx.x; k < bytes2 / 16; k += NTH) d4[bytes / 16 + k] = __ldcg(t4 + k);
  }
  __syncthreads();
}

template <bool CPT>
struct OpQKV {
  int layer; const bf16* xf0; const bf16* xs0; int tm = 0;   // xs0: staged copy of group 0 (std mode) or null   // three frags (xq, xk, xv), each 72 units
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    const LayerW& L = c.L[layer];
    int grp = 0;
    if (L.glob) grp = s < 205 ? 0 : (s < 222 ? 1 : 2);
    const uint32_t* xf = reinterpret_cast<const uint32_t*>((grp == 0 && xs0) ? xs0 : xf0 + grp * (72 * LSZ * 16));
#ifdef W12
    run_w12<CPT>(L.qkv12, s, xf, u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(L.wqkv + s * 72L * 2048, xf, u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
    int r0 = (int)s * 16 + g;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = r0 + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) c.qkvo[col * 3840 + row] = tobf(a[i]);
    }
  }
};

template <bool CPT>
struct OpOproj {
  int layer; const bf16* xf; int tm = 25;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<CPT>(c.L[layer].wo12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 24);
    return;
#endif
    run_bf16<CPT>(c.L[layer].wo + s * 24L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) for (int d = 0; d < NCARD; d++) ll_put(&c.comm[d]->lla[layer & 1][c.h.card][col][row], a[i], c.h.tag0 + layer + 1);
    }
  }
};

template <bool CPT>
struct OpRouter {
  int layer; const bf16* xf; int tm = 0;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<CPT>(c.L[layer].wr12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(c.L[layer].wr + s * 72L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) ll_put(&c.rll[col * NE + row], a[i], c.h.tag0 + layer + 1);
    }
  }
};

__device__ __forceinline__ float act_fn(float g, float u) {
  float a = (4.0f * tanhf(g / 4.0f)) * sigm(g);
  return a * (25.0f * tanhf(u / 25.0f));
}

template <bool CPT>
struct OpW13 {
  int layer; int nu; const Smem* sm; const uint8_t* xf; const float* xs; const float* outer; int tm = 40;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    const LayerW& L = c.L[layer];
    int ui = (int)(s / 72), ls = (int)(s % 72);
    int e = sm->uni[ui];
    long ub = L.mx ? UB8 : UB4;
    const uint8_t* w = L.w13 + ((long)e * 72 + ls) * 72 * ub;
    run_q<CPT>(w, xf, xs, u0, u1, acc, c.h.B, L.mx);
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    const LayerW& L = c.L[layer];
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
    int ui = (int)(s / 72), ls = (int)(s % 72);
    int e = sm->uni[ui];
    // rows g (gate if g even... ) : local row r = ls*16 + g (+8). interleaved: even row gate, odd row up.
    // lane holds rows g and g+8 for cols 2t, 2t+1. Pair (gate,up) = rows (2p, 2p+1) -> lanes g=2p and g=2p+1.
    float v[4];
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int col = 2 * t + (i & 1);
      float sc = L.mx ? 1.0f : outer[col] * L.f13[e];
      v[i] = rbf(a[i] * sc);
    }
    // partner lane (g^1) holds the other member of the pair
    float o[4];
#pragma unroll
    for (int i = 0; i < 4; i++) o[i] = __shfl_xor_sync(0xffffffff, v[i], 4);
    float m0 = 0.f, m1 = 0.f;
    if ((g & 1) == 0) {
      // this lane: gate rows (g, g+8); partner: up rows (g+1, g+9). local intermediate j = (ls*16 + g)/2 (+4)
#pragma unroll
      for (int i = 0; i < 4; i++) {
        int col = 2 * t + (i & 1);
        if (col >= c.h.B) continue;
        int j = (ls * 16 + g + (i >> 1) * 8) >> 1;
        float wt = 0.f;
        for (int k = 0; k < TOPK; k++) if (sm->ids[col * TOPK + k] == e) wt = sm->wts[col * TOPK + k];
        float y = 0.f;
        if (wt != 0.f) y = rbf(act_fn(v[i], o[i]) * wt);
        c.act[(ui * MAXB + col) * ILOC + j] = tobf(y);
        if (i & 1) m1 = fmaxf(m1, fabsf(y)); else m0 = fmaxf(m0, fabsf(y));
      }
    }
    {
      // max over the warp per column, local atomic, and the last of the expert's 72 strips publishes to every card
      // (mxfp8 layers publish too: the tag tells quant2 that this card's act values of the expert are complete)
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) { m0 = fmaxf(m0, __shfl_xor_sync(0xffffffff, m0, o)); m1 = fmaxf(m1, __shfl_xor_sync(0xffffffff, m1, o)); }
      if (g == 0) {
        if (2 * t < c.h.B) atomicMax(&c.amax_loc[ui * MAXB + 2 * t], __float_as_uint(m0));
        if (2 * t + 1 < c.h.B) atomicMax(&c.amax_loc[ui * MAXB + 2 * t + 1], __float_as_uint(m1));
      }
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) { __threadfence(); old = atomicAdd(&c.ucnt[ui], 1u); }
      old = __shfl_sync(0xffffffff, old, 0);
      if (old == 71u) {
        __threadfence();
        if (lane < c.h.B) {
          float v = __uint_as_float(atomicExch(&c.amax_loc[ui * MAXB + lane], 0u));
          for (int d = 0; d < NCARD; d++) ll_put(&c.comm[d]->llx[layer][c.h.card][ui][lane], v, c.h.tag0 + layer + 1);
        }
        if (lane == 0) c.ucnt[ui] = 0;
      }
    }
  }
};

template <bool CPT>
struct OpW2 {
  int layer; int nu; const Smem* sm; const uint8_t* xf0; const float* sc0; int tm = 28;   // frags [ui][9 units], scales [ui][18][MAXB]
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    // units: (ui, k-unit) with 9 units per expert
    const LayerW& L = c.L[layer];
    int lane = threadIdx.x & 31, t = lane & 3;
    long ub = L.mx ? UB8 : UB4;
    int u = u0;
    while (u < u1) {
      int ui = u / 9, k0 = u % 9, k1 = min(9, u1 - ui * 9);
      int e = sm->uni[ui];
      const uint8_t* w = L.w2 + ((long)e * 288 + s) * 9 * ub;
      float a[4] = {0.f, 0.f, 0.f, 0.f};
      const uint8_t* xf = xf0 + (long)ui * 9 * LSZ * (L.mx ? 16 : 32);
      const float* xs = sc0 + (long)ui * 18 * MAXB;
      run_q<CPT>(w, xf, xs, k0, k1, a, c.h.B, L.mx);
      if (L.mx) {
#pragma unroll
        for (int i = 0; i < 4; i++) acc[i] += a[i];
      } else {
        float f = L.f2[e];
        float s0 = sc0[ui * 18 * MAXB + 2 * t] * f, s1 = sc0[ui * 18 * MAXB + 2 * t + 1] * f;   // outer at [ui][0][col]
        // explicit FMAs: the compiler may contract the four columns' multiply-adds differently, which made a
        // sequence's result depend on its batch slot (1 ulp, s0004 http_tokens)
        acc[0] = __fmaf_rn(a[0], s0, acc[0]); acc[1] = __fmaf_rn(a[1], s1, acc[1]);
        acc[2] = __fmaf_rn(a[2], s0, acc[2]); acc[3] = __fmaf_rn(a[3], s1, acc[3]);
      }
      u = ui * 9 + k1;
    }
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) for (int d = 0; d < NCARD; d++) ll_put(&c.comm[d]->llm[layer & 1][c.h.card][col][row], a[i], c.h.tag0 + layer + 1);
    }
  }
};

template <bool CPT>
struct OpUnembed {
  float* bestv; int* besti; const bf16* xf; int tm = 0; int layer = 0;   // per-warp running best per col (smem)
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<CPT>(c.un12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(c.unembed + s * 72L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3, w = threadIdx.x >> 5;
    float bv[2] = {-INFINITY, -INFINITY};
    int bi[2] = {1 << 30, 1 << 30};
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = c.un_row0 + (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B && row < VOCAB_REAL) {
        float z = 30.0f * tanhf(a[i] / 30.0f);
        if (c.h.want_logits) c.h.logits[(long)col * VOCAB_REAL + row] = z;
        int k = i & 1;
        if (z > bv[k] || (z == bv[k] && row < bi[k])) { bv[k] = z; bi[k] = row; }
      }
    }
#pragma unroll
    for (int k = 0; k < 2; k++) {
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) {
        float ov = __shfl_xor_sync(0xffffffff, bv[k], o);
        int oi = __shfl_xor_sync(0xffffffff, bi[k], o);
        if (ov > bv[k] || (ov == bv[k] && oi < bi[k])) { bv[k] = ov; bi[k] = oi; }
      }
      int col = 2 * t + k;
      if (g == 0 && col < c.h.B) {
        float cv = bestv[w * MAXB + col];
        int ci = besti[w * MAXB + col];
        if (bv[k] > cv || (bv[k] == cv && bi[k] < ci)) { bestv[w * MAXB + col] = bv[k]; besti[w * MAXB + col] = bi[k]; }
      }
    }
  }
};

// ------------------------------------------------------------------------------------------------ phases


template <bool CPT> __device__ __forceinline__ void put16(bf16* f, int b, int k, float v) { f[fi16<CPT>(b, k)] = tobf(v); }

// ------------------------------------------------------------------------------------------------ per-token vector code
// thread t < 576 owns the 8 consecutive elements [8t, 8t+8) of a 4608-vector: one 16-byte load per bf16 vector.
#define NV8 (H / 8)
#define W8 (NV8 / 32)          // 18 active warps
#define ACT8 (threadIdx.x < NV8)
__device__ __forceinline__ void ld8(const bf16* p, float* v) {
  uint4 u = *reinterpret_cast<const uint4*>(p);
  const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
#pragma unroll
  for (int i = 0; i < 4; i++) { float2 f = __bfloat1622float2(h[i]); v[2 * i] = f.x; v[2 * i + 1] = f.y; }
}
__device__ __forceinline__ void ld8g(const bf16* p, float* v) {   // global, L2 (data written in this launch)
  uint4 u = __ldcg(reinterpret_cast<const uint4*>(p));
  const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
#pragma unroll
  for (int i = 0; i < 4; i++) { float2 f = __bfloat1622float2(h[i]); v[2 * i] = f.x; v[2 * i + 1] = f.y; }
}
__device__ __forceinline__ void st8(bf16* p, const float* v) {
  uint4 u;
  __nv_bfloat162* h = reinterpret_cast<__nv_bfloat162*>(&u);
#pragma unroll
  for (int i = 0; i < 4; i++) h[i] = __floats2bfloat162_rn(v[2 * i], v[2 * i + 1]);
  *reinterpret_cast<uint4*>(p) = u;
}
// block-wide sums of N values held by the 576 active threads; result broadcast through sm.red
template <int N>
__device__ __forceinline__ void bsum8(float* v, float* red) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  if (w < W8) {
#pragma unroll
    for (int i = 0; i < N; i++) {
#pragma unroll
      for (int o = 16; o; o >>= 1) v[i] += __shfl_xor_sync(0xffffffff, v[i], o);
      if (lane == 0) red[w * N + i] = v[i];
    }
  }
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) {
    float t = 0.f;
#pragma unroll
    for (int j = 0; j < W8; j++) t += red[j * N + i];
    v[i] = t;
  }
  __syncthreads();
}
__device__ __forceinline__ float bmax8(float m, float* red) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  if (w < W8) {
#pragma unroll
    for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
    if (lane == 0) red[w] = m;
  }
  __syncthreads();
  float r = red[0];
#pragma unroll
  for (int j = 1; j < W8; j++) r = fmaxf(r, red[j]);
  __syncthreads();
  return r;
}
// rms_norm (fp32 in) with a bf16 weight -> bf16-rounded values
// in place: u (fp32) -> rms_norm(u) * w rounded to bf16
__device__ __forceinline__ void rmsnorm8(float* u, const bf16* w, float* red) {
  float s[1] = {0.f};
  if (ACT8) {
#pragma unroll
    for (int i = 0; i < 8; i++) s[0] += u[i] * u[i];
  }
  bsum8<1>(s, red);
  if (!ACT8) return;
  const float r = rsqrtf(s[0] / (float)H + 1e-6f);
  const __nv_bfloat162* w2 = reinterpret_cast<const __nv_bfloat162*>(w + threadIdx.x * 8);
#pragma unroll
  for (int i = 0; i < 4; i++) {
    float2 f = __bfloat1622float2(w2[i]);
    u[2 * i] = rbf((u[2 * i] * r) * f.x);
    u[2 * i + 1] = rbf((u[2 * i + 1] * r) * f.y);
  }
}
// 8 bf16 values at k0..k0+7 of token b into a 16-bit fragment: pairs (k, k+1) are one 32-bit word
template <bool CPT>
__device__ __forceinline__ void put8(bf16* f, int b, int k0, const float* y) {
#pragma unroll
  for (int i = 0; i < 4; i++) {
    int k = k0 + 2 * i;
    *reinterpret_cast<__nv_bfloat162*>(f + fi16<CPT>(b, k)) = __floats2bfloat162_rn(y[2 * i], y[2 * i + 1]);
  }
}
// NVFP4 input quantization of one token (four over six); a block of 16 = threads (2m, 2m+1). Writes f16 frags.
__device__ __forceinline__ float e2m1_rne(float mag) {
  float q;
  if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
  else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
  return q;
}
// core: per-thread max m, the token's amax, element offset k0; `on`: this thread holds 8 valid elements
template <bool CPT>
__device__ __forceinline__ float quant_nvfp4_core(const float* x, int b, __half* frag, float m, float amax, int k0, bool on) {
  const float FMAX = 3.4028234663852886e38f;
  const float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder, outer = amax * (1.0f / 1536.0f);
  if (on) {
    float bm = m;
    bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, 1));
    float sc[2], iv[2], er[2];
#pragma unroll
    for (int cand = 0; cand < 2; cand++) {
      float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
      sc[cand] = float(__nv_fp8_e4m3(fminf(bm * (encoder * inv_max), 448.0f)));
      iv[cand] = fminf(1.0f / (sc[cand] * decoder), FMAX);
      float err = 0.f;
#pragma unroll
      for (int i = 0; i < 8; i++) {
        float val = x[i] * iv[cand];
        float q = (val != val) ? 0.f : e2m1_rne(fabsf(val));
        err += fabsf(((signbit(val) ? -q : q) * sc[cand]) * outer - x[i]);
      }
      er[cand] = err + __shfl_xor_sync(0xffffffff, err, 1);
    }
    const int pick = (er[1] < er[0]) ? 1 : 0;   // a strictly better /4 wins
    const float scale = sc[pick], inverse = iv[pick];
#pragma unroll
    for (int i = 0; i < 4; i++) {
      float v2[2];
#pragma unroll
      for (int h = 0; h < 2; h++) {
        float val = x[2 * i + h] * inverse;
        float q = (val != val) ? 0.f : e2m1_rne(fabsf(val));
        v2[h] = (signbit(val) ? -q : q) * scale;
      }
      *reinterpret_cast<__half2*>(frag + fi16<CPT>(b, k0 + 2 * i)) = __floats2half2_rn(v2[0], v2[1]);
    }
  }
  return outer;
}
template <bool CPT>
__device__ float quant_nvfp4_8(const float* x, int b, __half* frag, float* red) {
  float m = 0.f;
  if (ACT8) {
#pragma unroll
    for (int i = 0; i < 8; i++) m = fmaxf(m, fabsf(x[i]));
  }
  const float amax = bmax8(m, red);
  return quant_nvfp4_core<CPT>(x, b, frag, m, amax, threadIdx.x * 8, ACT8);
}
// MXFP8 input quantization: a block of 32 = threads 4m..4m+3
template <bool CPT>
__device__ __forceinline__ void quant_mxfp8_8(const float* x, int b, uint8_t* frag, float* scales, int k0, bool on) {
  if (!on) return;
  float m = 0.f;
#pragma unroll
  for (int i = 0; i < 8; i++) m = fmaxf(m, fabsf(x[i]));
  m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, 1));
  m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, 2));
  float raw = m * (1.0f / 448.0f);
  unsigned bits = __float_as_uint(raw);
  int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
  if (raw <= 5.877471754111438e-39f) ex = 0;
  if (ex > 254) ex = 254;
  float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
  uint32_t w[2] = {0, 0};
#pragma unroll
  for (int i = 0; i < 8; i++) {
    float v = fminf(fmaxf(x[i] * inverse, -448.f), 448.f);
    w[i >> 2] |= (uint32_t)__nv_fp8_e4m3(v).__x << (8 * (i & 3));
  }
  *reinterpret_cast<uint32_t*>(frag + fi8<CPT>(b, k0)) = w[0];
  *reinterpret_cast<uint32_t*>(frag + fi8<CPT>(b, k0 + 4)) = w[1];
  if ((threadIdx.x & 3) == 0) scales[(k0 >> 5) * MAXB + b] = ue8m0((unsigned)ex);
}
// all-reduce sum of the cards' partials (LL mailbox of one layer parity), bf16-rounded; waits for the tags
__device__ __forceinline__ void raw8(const uint2 (*mb)[MAXB][H], int b, unsigned tag, float* raw, int k0) {
#pragma unroll
  for (int h = 0; h < 4; h++) {
    float2 v0 = ll_get2(&mb[0][b][k0 + 2 * h], tag), v1 = ll_get2(&mb[1][b][k0 + 2 * h], tag);
    float2 v2 = ll_get2(&mb[2][b][k0 + 2 * h], tag), v3 = ll_get2(&mb[3][b][k0 + 2 * h], tag);
    raw[2 * h] = rbf(((v0.x + v1.x) + v2.x) + v3.x);
    raw[2 * h + 1] = rbf(((v0.y + v1.y) + v2.y) + v3.y);
  }
}
// short conv: hist [3][H] (oldest first), taps w4 [H][4]; writes the shifted history (writer only)
__device__ __forceinline__ void conv8(const bf16* __restrict__ hist, const float* raw, const bf16* w4,
                                      bf16* __restrict__ hw, bool writer, float* out, int k0) {
  float h0[8], h1[8], h2[8];
  ld8g(hist + k0, h0); ld8g(hist + H + k0, h1); ld8g(hist + 2 * H + k0, h2);
#pragma unroll
  for (int q = 0; q < 4; q++) {
    float wt[8];
    ld8(w4 + (k0 * 4) + q * 8, wt);
    out[2 * q] = sconv4f(h0[2 * q], h1[2 * q], h2[2 * q], raw[2 * q], wt);
    out[2 * q + 1] = sconv4f(h0[2 * q + 1], h1[2 * q + 1], h2[2 * q + 1], raw[2 * q + 1], wt + 4);
  }
  if (writer) { st8(hw + k0, h1); st8(hw + H + k0, h2); st8(hw + 2 * H + k0, raw); }
}
// residual mix: sources s < nb: finished blocks, s == nb: the partial (+ fp32 addend), s == nb+1: attention out
__device__ __forceinline__ const bf16* msrc(Smem& sm, int nb, int s) { return s < nb ? sm.blk[s] : (s == nb ? sm.blk[8] : sm.ats); }
template <int NQ>
__device__ __forceinline__ void mix_part8(Smem& sm, int nb, int s0, int s1, const float* addend, const float* q) {
  if (!ACT8) return;
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5, k0 = threadIdx.x * 8;
  const float qs = 0.014731391274719739f;  // 4608 ** -0.5 rounded to fp32
  constexpr int G = (NQ == 1) ? 4 : 2;     // sources per batch: G * (NQ + 1) = 8 independent shuffle chains
  float qv[NQ][8];
#pragma unroll
  for (int qi = 0; qi < NQ; qi++) {
    float4 a = *reinterpret_cast<const float4*>(q + qi * H + k0), b = *reinterpret_cast<const float4*>(q + qi * H + k0 + 4);
    qv[qi][0] = a.x * qs; qv[qi][1] = a.y * qs; qv[qi][2] = a.z * qs; qv[qi][3] = a.w * qs;
    qv[qi][4] = b.x * qs; qv[qi][5] = b.y * qs; qv[qi][6] = b.z * qs; qv[qi][7] = b.w * qs;
  }
  for (int sb = s0; sb < s1; sb += G) {
    float a[G][1 + NQ];
#pragma unroll
    for (int g = 0; g < G; g++) {
#pragma unroll
      for (int k = 0; k <= NQ; k++) a[g][k] = 0.f;
      const int s = sb + g;
      if (s < s1) {
        uint4 u = *reinterpret_cast<const uint4*>(msrc(sm, nb, s) + k0);
        const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
        const bool add = (s == nb) && addend;
#pragma unroll
        for (int i = 0; i < 4; i++) {
          float2 f = __bfloat1622float2(h[i]);
          if (add) { f.x += addend[2 * i]; f.y += addend[2 * i + 1]; }
          a[g][0] += f.x * f.x;
          a[g][0] += f.y * f.y;
#pragma unroll
          for (int qi = 0; qi < NQ; qi++) { a[g][1 + qi] += f.x * qv[qi][2 * i]; a[g][1 + qi] += f.y * qv[qi][2 * i + 1]; }
        }
      }
    }
#pragma unroll
    for (int o = 16; o; o >>= 1)
#pragma unroll
      for (int g = 0; g < G; g++)
#pragma unroll
        for (int k = 0; k <= NQ; k++) a[g][k] += __shfl_xor_sync(0xffffffff, a[g][k], o);
    if (lane == 0) {
#pragma unroll
      for (int g = 0; g < G; g++)
        if (sb + g < s1)
#pragma unroll
          for (int k = 0; k <= NQ; k++) sm.red[w * 40 + (sb + g) * 4 + k] = a[g][k];
    }
  }
}
template <int NQ>
__device__ __forceinline__ void mix_finish8(Smem& sm, int n) {
  float* red = sm.red;
  __syncthreads();
  // warp 0, lane s < n: the source's sums over the 18 active warps, 1/rms, and the softmax over sources (shuffles)
  if (threadIdx.x < 32) {
    const int s = threadIdx.x;
    const bool on = s < n;
    float f[1 + NQ];
#pragma unroll
    for (int k = 0; k <= NQ; k++) {
      float t = 0.f;
      if (on) {
#pragma unroll
        for (int j = 0; j < W8; j++) t += red[j * 40 + s * 4 + k];
      }
      f[k] = t;
    }
    const float iv = on ? rsqrtf(f[0] / (float)H + 1e-6f) : 0.f;
    if (on) sm.minv[s] = iv;
#pragma unroll
    for (int qi = 0; qi < NQ; qi++) {
      float lg = on ? f[1 + qi] * iv : -INFINITY;
      float m = lg;
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float p = on ? expf(lg - m) : 0.f;
      // the sum in source order (as the serial loop did): prefix through shuffles from lane 0 upwards
      float z = 0.f;
      for (int q = 0; q < n; q++) z += __shfl_sync(0xffffffff, p, q);
      if (on) sm.mixp[qi * 10 + s] = p / z;
    }
  }
  __syncthreads();
}
__device__ __forceinline__ void mix_out8(Smem& sm, int nb, int n, const float* addend, int qi, float* out) {
  if (!ACT8) return;
  const int k0 = threadIdx.x * 8;
#pragma unroll
  for (int i = 0; i < 8; i++) out[i] = 0.f;
  for (int s = 0; s < n; s++) {
    uint4 u = *reinterpret_cast<const uint4*>(msrc(sm, nb, s) + k0);
    const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
    const float p = sm.mixp[qi * 10 + s], iv = sm.minv[s];
    const bool add = (s == nb) && addend;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      float2 f = __bfloat1622float2(h[i]);
      if (add) { f.x += addend[2 * i]; f.y += addend[2 * i + 1]; }
      out[2 * i] += p * (f.x * iv);
      out[2 * i + 1] += p * (f.y * iv);
    }
  }
}

// phase: (mlp all-reduce of layer i-1, sconv, finalize) + attention input of layer i. One block per token.
template <bool RED>
__device__ void phase_attn_in(const Ctx& c, int i, int b, Smem& sm, bool dowait, unsigned ev) {
  const LayerW& L = c.L[i];
  const bool writer = !RED || blockIdx.x == 0;
  bf16* xfd = RED ? &sm.fx[0][0] : c.xfrag;
  const int xstride = RED ? H : 72 * 32 * 16;
  float* red = sm.red;
  bf16* part = sm.blk[8];
  const int k0 = threadIdx.x * 8;
  if (i == 0) {
    float u[8];
    if (ACT8) ld8g(c.embed + (long)c.h.tokens[b] * H + k0, u);
    rmsnorm8(u, c.embed_norm, red);
    if (ACT8) st8(part + k0, u);
    rmsnorm8(u, L.norm[0], red);
    if (ACT8) put8<RED>(xfd, b, k0, u);
    return;
  }
  const int lp = i - 1;
  // ---- before the cross-card wait: the finished blocks' statistics
  const int nb_before = (lp == 0) ? 0 : ((lp - 1) / 6 + 1);
  const bool boundary = (lp % 6) == 0;
  const int nb = nb_before + (boundary ? 1 : 0);
  if (boundary) {
    if (ACT8) *reinterpret_cast<uint4*>(sm.blk[nb_before] + k0) = *reinterpret_cast<const uint4*>(part + k0);
    __syncthreads();
  }
  if (L.glob) mix_part8<3>(sm, nb, 0, nb, nullptr, L.aq);
  else mix_part8<1>(sm, nb, 0, nb, nullptr, L.aq);
  (void)dowait; (void)ev;   // the mlp values are polled by tag in raw8
  TM(i, 1);
  if (ACT8) {
    float rw[8], mlp[8], at[8], pv[8];
    raw8(c.comm[c.h.card]->llm[lp & 1], b, c.h.tag0 + lp + 1, rw, k0);
    conv8(c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H, rw, c.L[lp].mlp_sc,
          c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, writer, mlp, k0);
    ld8(sm.ats + k0, at);
    ld8(part + k0, pv);
    if (c.dbg && writer) st8(c.dbg + ((long)(lp * 2 + 1) * MAXB + b) * H + k0, mlp);
#pragma unroll
    for (int e = 0; e < 8; e++) pv[e] = boundary ? (at[e] + mlp[e]) : ((pv[e] + at[e]) + mlp[e]);
    st8(part + k0, pv);
  }
  TM(i, 16);
  __syncthreads();
  TM(i, 17);
  const int nq = L.glob ? 3 : 1;
  if (L.glob) { mix_part8<3>(sm, nb, nb, nb + 1, nullptr, L.aq); mix_finish8<3>(sm, nb + 1); }
  else { mix_part8<1>(sm, nb, nb, nb + 1, nullptr, L.aq); mix_finish8<1>(sm, nb + 1); }
  TM(i, 18);
  for (int k = 0; k < nq; k++) {
    float o[8];
    mix_out8(sm, nb, nb + 1, nullptr, k, o);
    rmsnorm8(o, L.norm[k], red);
    if (ACT8) put8<RED>(xfd + k * xstride, b, k0, o);
  }
}

// attention: block per (token b, local kv head kh, chunk ch)
__device__ void phase_attention(const Ctx& c, int i, int b, int kh, int ch, int nch, Smem& sm, bool combine) {
  const LayerW& L = c.L[i];
#define TMA(id) do { if (b == 0 && kh == 0 && ch == 0) TM(i, id); \
    } while (0)
  TMA(32);
  const int t = c.h.pos;
  const int lo = L.glob ? 0 : max(0, t + 1 - WIN);
  const int p0 = lo + ch * CHUNK, p1 = min(t + 1, p0 + CHUNK);
  const bf16* qkv = c.qkvo + b * 3840;
  // row offsets in the local qkv matrix
  const int OQ = 0, OG = 1536, OR = 3072, OS = 3264, OK = 3280, ODK = 3536, OV = L.glob ? 3552 : 3536, ODV = 3808;
  float tau = 1.0f;
  if (L.glob) tau = 1.0f + 0.1f * logf(fmaxf((float)(t + 1) / 128000.0f, 1.0f));
  bf16* kcache = c.kc + (((long)(i * MAXB + b) * NKVL + kh) * c.maxctx) * HD;
  bf16* vcache = c.vc + (((long)(i * MAXB + b) * NKVL + kh) * c.maxctx) * HD;
  int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  float* red = sm.red;
  // q of the 6 heads (l2 clip with scale) -> sm.qv; rel bias -> sm.relb (for positions of this chunk)
  // each warp w<6 handles head j=w
  if (w < 6) {
    int hl = kh * 6 + w;
    float v[4], ss = 0.f;
    // all loads of the warp first: q and its scale, r and its scale
    float rv = 0.f;
    if (lane < 16) rv = bf(qkv[OR + hl * 16 + lane]) * bf(L.rscale[hl * 16 + lane]);
    for (int k = 0; k < 4; k++) {
      int d = lane + 32 * k;
      v[k] = bf(qkv[OQ + hl * HD + d]) * bf(L.qscale[hl * HD + d]);
      ss += v[k] * v[k];
    }
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
    float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
    for (int k = 0; k < 4; k++) {
      float qq = rbf(v[k] * f);
      if (L.glob) qq = rbf(qq * tau);
      sm.qv[w * HD + lane + 32 * k] = qq;
    }
    // r: 16 values
    float rs = rv * rv;
    for (int o = 16; o; o >>= 1) rs += __shfl_xor_sync(0xffffffff, rs, o);
    float rf = fminf(8.0f / (sqrtf(rs) + 1e-6f), 1.0f);
    float rr = rbf(rv * rf);
    if (L.glob) rr = rbf(rr * tau);
    if (lane < 16) sm.misc[16 + w * 16 + lane] = rr;
  }
  // K and V rows of this chunk into shared memory (the B-fragment area is free during attention); row t later
#define KST (HD + 8)   // padded row stride (272 B): a warp reading 32 rows at one offset hits distinct banks
  bf16* ks = reinterpret_cast<bf16*>(sm.stage);
  bf16* vs = ks + CHUNK * KST;
  {
    const int np = p1 - p0;
    for (int k = tid; k < np * 16; k += NTH) {   // 16 x 16 B per row, asynchronous
      int r = k >> 4, q = k & 15;
      if (p0 + r == t) continue;
      unsigned dk = (unsigned)__cvta_generic_to_shared(ks + r * KST + q * 8), dv = (unsigned)__cvta_generic_to_shared(vs + r * KST + q * 8);
      asm volatile("cp.async.cg.shared.global [%0], [%1], 16;" :: "r"(dk), "l"(kcache + (long)(p0 + r) * HD + q * 8) : "memory");
      asm volatile("cp.async.cg.shared.global [%0], [%1], 16;" :: "r"(dv), "l"(vcache + (long)(p0 + r) * HD + q * 8) : "memory");
    }
    asm volatile("cp.async.commit_group;" ::: "memory");
  }
  // relative-bias projection values of this thread's (head, position) pair, loaded early
  const int sj = tid >> 7, sp = tid & 127;   // scores: thread -> (head sj < 6, position p0 + sp)
  const bool sact = sj < 6 && sp < p1 - p0;
  const int sdist = t - (p0 + sp);
  float pv[DREL];
#pragma unroll
  for (int d = 0; d < DREL; d++) pv[d] = (sact && sdist < RELEXT) ? bf(L.relp[d * RELEXT + sdist]) : 0.f;
  // new k, v at position t (by the chunk that holds t): warps 6-9 k, warps 10-13 v, one channel per lane;
  // the per-head norm over 128 channels through shared memory and a named barrier of these 8 warps
  if (p1 == t + 1 && w >= 6 && w < 14) {
    const int kv = (w - 6) >> 2, q4 = (w - 6) & 3;
    const int d = q4 * 32 + lane, ch_ = kh * HD + d;
    const int base = (kv == 0) ? OK : OV;
    const bf16* sc = (kv == 0) ? L.ksc : L.vsc;
    bf16* hist = (kv == 0 ? c.hist_k : c.hist_v) + ((long)(i * MAXB + b) * 3) * 256;
    const float raw = bf(qkv[base + ch_]);
    const float h0 = bf(hist[ch_]), h1 = bf(hist[256 + ch_]), h2 = bf(hist[512 + ch_]);
    float y;
    if (!L.glob) {
      y = sconv4(h0, h1, h2, raw, sc + ch_ * 4);
    } else {
      const int dbase = (kv == 0) ? ODK : ODV;
      float acc = 0.f;
      const float xs[4] = {raw, h2, h1, h0};
#pragma unroll
      for (int lag = 0; lag < 4; lag++) {
        float tap = bf(sc[lag * 256 + ch_]) + bf(qkv[dbase + kh * 4 + lag]);
        acc = acc + xs[lag] * tap;
      }
      y = rbf((acc + raw) * 0.3333333333333333f);
    }
    hist[ch_] = tobf(h1); hist[256 + ch_] = tobf(h2); hist[512 + ch_] = tobf(raw);
    float ss = y * y;
#pragma unroll
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
    if (lane == 0) sm.misc[112 + kv * 4 + q4] = ss;
    asm volatile("bar.sync 1, 256;" ::: "memory");
    float tot = sm.misc[112 + kv * 4 + 0] + sm.misc[112 + kv * 4 + 1] + sm.misc[112 + kv * 4 + 2] + sm.misc[112 + kv * 4 + 3];
    float yo = (kv == 0) ? rbf(y * fminf(22.627416997969522f / (sqrtf(tot) + 1e-6f), 1.0f)) : rbf(y * rsqrtf(tot / 128.0f + 1e-6f));
    (kv == 0 ? kcache : vcache)[(long)t * HD + d] = tobf(yo);
    (kv == 0 ? ks : vs)[(t - p0) * KST + d] = tobf(yo);
  }
  TMA(43);
  asm volatile("cp.async.wait_all;" ::: "memory");
  TMA(44);
  __syncthreads();
  TMA(33);
  TMA(34);
  // scores: one thread per (head, position): full 128-wide dot from shared memory, + relative bias
  if (sact) {
    const float* qj = sm.qv + sj * HD;
    const bf16* kr = ks + sp * KST;
    float dot = 0.f;
#pragma unroll 4
    for (int d0 = 0; d0 < HD; d0 += 8) {
      uint4 u = *reinterpret_cast<const uint4*>(kr + d0);
      const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
      float4 qa = *reinterpret_cast<const float4*>(qj + d0), qb = *reinterpret_cast<const float4*>(qj + d0 + 4);
      float2 f0 = __bfloat1622float2(h[0]), f1 = __bfloat1622float2(h[1]), f2 = __bfloat1622float2(h[2]), f3 = __bfloat1622float2(h[3]);
      dot += qa.x * f0.x; dot += qa.y * f0.y; dot += qa.z * f1.x; dot += qa.w * f1.y;
      dot += qb.x * f2.x; dot += qb.y * f2.y; dot += qb.z * f3.x; dot += qb.w * f3.y;
    }
    float bias = 0.f;
    if (sdist < RELEXT) {
      float pr = 0.f;
#pragma unroll
      for (int d = 0; d < DREL; d++) pr += sm.misc[16 + sj * 16 + d] * pv[d];
      bias = rbf(pr);
    }
    sm.att[sj * CHUNK + sp] = dot * 0.08838834764831845f + bias;
  }
  __syncthreads();
  TMA(35);
  // per head max and exp
  int np = p1 - p0;
  if (w < 6) {
    float m = -INFINITY;
    for (int p = lane; p < np; p += 32) m = fmaxf(m, sm.att[w * CHUNK + p]);
    for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
    float l = 0.f;
    for (int p = lane; p < np; p += 32) { float e = expf(sm.att[w * CHUNK + p] - m); sm.att[w * CHUNK + p] = e; l += e; }
    for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffff, l, o);
    if (lane == 0) { sm.misc[w * 2] = m; sm.misc[w * 2 + 1] = l; }
  }
  __syncthreads();
  TMA(36);
  // V: one thread per (head, dimension pair), all positions of the chunk; writes the chunk partial directly
  float* chunkp = c.achunk + ((long)((b * NKVL + kh) * MAXCHUNK + ch) * 6) * (2 + HD);
  // (all threads: (head, dimension pair, half of the positions); the two halves summed through shared memory)
  {
    const int half = tid / (6 * (HD / 2)), r6 = tid % (6 * (HD / 2));
    const int j = r6 / (HD / 2), d = (r6 % (HD / 2)) * 2;
    const int pm = (np + 1) / 2, pa = half ? pm : 0, pb = half ? np : pm;
    float o0 = 0.f, o1 = 0.f;
    const float* aj = sm.att + j * CHUNK;
    if (half < 2) {
#pragma unroll 4
      for (int p = pa; p < pb; p++) {
        float2 v = __bfloat1622float2(*reinterpret_cast<const __nv_bfloat162*>(vs + p * KST + d));
        const float e = aj[p];
        o0 += e * v.x; o1 += e * v.y;
      }
      if (half == 1) *reinterpret_cast<float2*>(&sm.opart[0][0] + r6 * 2) = make_float2(o0, o1);
    }
    __syncthreads();
    if (half == 0) {
      float2 hv = *reinterpret_cast<const float2*>(&sm.opart[0][0] + r6 * 2);
      *reinterpret_cast<float2*>(chunkp + j * (2 + HD) + 2 + d) = make_float2(o0 + hv.x, o1 + hv.y);
    }
  }
  if (tid < 6) { chunkp[tid * (2 + HD)] = sm.misc[tid * 2]; chunkp[tid * (2 + HD) + 1] = sm.misc[tid * 2 + 1]; }
  __syncthreads();
  TMA(36);
  TMA(37);
  if (!combine) return;   // B=1: every block combines the chunks itself in front of o_proj (phase_ocombine_red)
  // last chunk block combines
  __shared__ unsigned last;
  if (tid == 0) {
    __threadfence();
    unsigned old = atomicAdd(&c.acnt[b * NKVL + kh], 1u);
    last = (old == (unsigned)(nch - 1));
    if (last) c.acnt[b * NKVL + kh] = 0;
  }
  __syncthreads();
  TMA(38);
  if (!last) return;
  __threadfence();
  const float* base = c.achunk + ((long)((b * NKVL + kh) * MAXCHUNK) * 6) * (2 + HD);
  // per head: chunk scale factors exp(m_q - M) into shared memory (sm.att is free now), then 1/L and lse
  if (w < 6) {
    const int j = w;
    float mq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD)) : -INFINITY;
    float lq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD) + 1) : 0.f;
    float M = mq;
    for (int o = 16; o; o >>= 1) M = fmaxf(M, __shfl_xor_sync(0xffffffff, M, o));
    float f = (lane < nch) ? expf(mq - M) : 0.f;
    // L = sum over chunks in chunk order (lane order)
    float Ls = 0.f;
    for (int q = 0; q < nch; q++) Ls += __shfl_sync(0xffffffff, lq * f, q);
    if (lane < nch) sm.att[j * CHUNK + lane] = f;
    if (lane == 0) { sm.misc[j * 2] = M + logf(Ls); sm.misc[j * 2 + 1] = Ls; }
  }
  __syncthreads();
  for (int idx = tid; idx < 6 * HD; idx += NTH) {
    int j = idx / HD, d = idx % HD;
    float O = 0.f;
    for (int q = 0; q < nch; q++) O += __ldcg(base + (q * 6 + j) * (2 + HD) + 2 + d) * sm.att[j * CHUNK + q];
    const float Ls = sm.misc[j * 2 + 1];
    float lse = sm.misc[j * 2];
    float out = O / Ls;
    int hl = kh * 6 + j;
    float gate = bf(qkv[OG + hl * HD + d]);
    float sink = bf(qkv[OS + hl]);
    out = out * sigm(gate);
    out = out * sigm(lse - sink);
    put16<false>(c.ofrag, b, hl * HD + d, out);
  }
  TMA(39);
#undef TMA
}

// phase: attention all-reduce + sconv + mlp input mix + norm + quantization. One block per token.
template <bool RED>
__device__ void phase_post_attn(const Ctx& c, int i, int b, Smem& sm, bool dowait, unsigned ev) {
  const LayerW& L = c.L[i];
  const bool writer = !RED || blockIdx.x == 0;
  float* red = sm.red;
  const int k0 = threadIdx.x * 8;
  // ---- before the wait
  const int nb = (i == 0) ? 0 : ((i - 1) / 6 + 1);
  const bool boundary = (i % 6) == 0;
  mix_part8<1>(sm, nb, 0, boundary ? nb + 1 : nb, nullptr, L.mq);   // finished blocks (and the old partial at a boundary)
  (void)dowait; (void)ev;
  TM(i, 6);
  float at[8];
  if (ACT8) {
    float rw[8];
    raw8(c.comm[c.h.card]->lla[i & 1], b, c.h.tag0 + i + 1, rw, k0);
    conv8(c.hist_attn + ((((long)c.h.parity * NL + i) * MAXB + b) * 3) * H, rw, L.attn_sc,
          c.hist_attn + ((((long)(c.h.parity ^ 1) * NL + i) * MAXB + b) * 3) * H, writer, at, k0);
    st8(sm.ats + k0, at);
    if (c.dbg && writer) st8(c.dbg + ((long)(i * 2) * MAXB + b) * H + k0, at);
  }
  TM(i, 20);
  __syncthreads();
  float out[8];
  if (boundary) {
    mix_part8<1>(sm, nb, nb + 1, nb + 2, nullptr, L.mq);
    mix_finish8<1>(sm, nb + 2);
    mix_out8(sm, nb, nb + 2, nullptr, 0, out);
  } else {
    mix_part8<1>(sm, nb, nb, nb + 1, at, L.mq);
    mix_finish8<1>(sm, nb + 1);
    mix_out8(sm, nb, nb + 1, at, 0, out);
  }
  TM(i, 21);
  rmsnorm8(out, L.mlp_norm, red);
  float* x = out;
  TM(i, 22);
  if (ACT8) put8<RED>(RED ? sm.fx2 : c.x2frag, b, k0, x);
  uint8_t* f13 = RED ? sm.f13 : c.w13frag;
  float* sc13 = RED ? sm.sc13 : c.w13sc;
  if (!L.mx) {
    float outer = quant_nvfp4_8<RED>(x, b, reinterpret_cast<__half*>(f13), red);
    if (threadIdx.x == 0) sc13[b] = outer;
  } else {
    quant_mxfp8_8<RED>(x, b, f13, sc13, threadIdx.x * 8, ACT8);
  }
}

// routing, computed redundantly by every block: warp b < B does token b's top-8; thread 0 the sorted union.
__device__ void phase_route(const Ctx& c, int i, Smem& sm) {
  const LayerW& L = c.L[i];
  const int lane = threadIdx.x & 31, b = threadIdx.x >> 5;
  const int B = c.h.B;
  float* sel = &sm.opart[0][0];   // [B][384] selection scores (attention scratch, free here)
  const unsigned tag = c.h.tag0 + i + 1;
  for (int k = threadIdx.x; k < B * NE; k += NTH) sel[k] = sigm(ll_get1(&c.rll[k], tag)) + L.rbias[k % NE];
  __syncthreads();
  if (b < B) {
    float* sb = sel + b * NE;
    int cid = 0;
    for (int r = 0; r < TOPK; r++) {
      float bv = -INFINITY; int bi = 1 << 30;
#pragma unroll
      for (int k = 0; k < 12; k++) {
        int e = lane + 32 * k;
        float v = sb[e];
        if (v > bv) { bv = v; bi = e; }
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) {
        float ov = __shfl_xor_sync(0xffffffff, bv, o); int oi = __shfl_xor_sync(0xffffffff, bi, o);
        if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
      }
      if (lane == r) cid = bi;
      if (lane == 0) sb[bi] = -INFINITY;
      __syncwarp();
    }
    // lanes 0..7 hold the chosen experts in rank order
    float sg = 0.f;
    if (lane < TOPK) sg = sigm(ll_get1(&c.rll[b * NE + cid], tag));
    float z = sg;
#pragma unroll
    for (int o = 1; o < 8; o <<= 1) z += __shfl_xor_sync(0xffffffff, z, o);
    if (lane < TOPK) {
      sm.ids[b * TOPK + lane] = cid;
      sm.wts[b * TOPK + lane] = sg / z * 8.0f;
      if (c.dbg_ids && blockIdx.x == 0) c.dbg_ids[(i * MAXB + b) * TOPK + lane] = cid;
    }
  }
  __syncthreads();
  TM(i, 24);
  // sorted union: a 384-bit mask in shared memory (sm.red is free here), then warp 0 compacts it
  unsigned* msk = reinterpret_cast<unsigned*>(sm.red);
  if (threadIdx.x < 12) msk[threadIdx.x] = 0;
  __syncthreads();
  if (threadIdx.x < c.h.B * TOPK) { int e = sm.ids[threadIdx.x]; atomicOr(&msk[e >> 5], 1u << (e & 31)); }
  __syncthreads();
  if (threadIdx.x < 32) {
    unsigned m = (lane < 12) ? msk[lane] : 0u;
    int cnt = __popc(m), pre = cnt;
    for (int o = 1; o < 32; o <<= 1) { int v = __shfl_up_sync(0xffffffff, pre, o); if (lane >= o) pre += v; }
    int n = pre - cnt;   // exclusive prefix
    while (m) { int bit = __ffs(m) - 1; m &= m - 1; sm.uni[n++] = lane * 32 + bit; }
    if (lane == 31) sm.nuni = pre;
  }
  __syncthreads();
}

// quantize act (per (ui, token)) for w2 with the global amax. Block per (ui, token) pair.
__device__ void phase_quant2(const Ctx& c, int i, int ui, int b, Smem& sm) {
  const LayerW& L = c.L[i];
  // 576 values: thread t < 576? NTH=512 -> 2 passes; use per-thread 2 elements: k = tid, tid+512 (<576)
  if (threadIdx.x == 0) {   // wait for every card's tag of (expert ui, token b): this card's act is complete then
    float am = 0.f;
    for (int d = 0; d < NCARD; d++) am = fmaxf(am, ll_get1(&c.comm[c.h.card]->llx[i][d][ui][b], c.h.tag0 + i + 1));
    sm.misc[0] = am;
    __threadfence();
  }
  __syncthreads();
  if (threadIdx.x >= ILOC) return;   // 18 whole warps
  float x[1];
  const int n = 1;
  x[0] = bf(__ldcg(&c.act[(ui * MAXB + b) * ILOC + threadIdx.x]));
  uint8_t* frag = c.w2frag + (long)ui * 9 * 32 * (L.mx ? 16 : 32);
  if (!L.mx) {
    const float amax = sm.misc[0];
    // the block-of-16 shuffles need full warps: elements k >= 576 are padding in a separate warp range
    // k = tid + 512: tids 0..63 valid, rest padding -> whole warps 0,1 valid; padding warps compute garbage not stored
    __half* f = reinterpret_cast<__half*>(frag);
    // inline quantization (amax given); store only k < 576
    const float FMAX = 3.4028234663852886e38f;
    float outer = amax * (1.0f / 1536.0f);
    if (amax == 0.f) {
      for (int e = 0; e < n; e++) { int k = threadIdx.x + e * NTH; if (k < ILOC) f[fidx16(b, k)] = __float2half_rn(0.f); }
    } else {
      float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder;
      for (int e = 0; e < n; e++) {
        int k = threadIdx.x + e * NTH;
        float xv = x[e];
        float bm = fabsf(xv);
        for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));
        float best_val = 0.f, best_err = 0.f;
        for (int cand = 0; cand < 2; cand++) {
          float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
          float sraw = fminf(bm * (encoder * inv_max), 448.0f);
          float scale = float(__nv_fp8_e4m3(sraw));
          float inverse = fminf(1.0f / (scale * decoder), FMAX);
          float val = xv * inverse, mag = fabsf(val), q;
          if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
          else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
          if (val != val) q = 0.f;
          float vals = (signbit(val) ? -q : q) * scale;
          float err = fabsf(vals * outer - xv);
          for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
          if (cand == 0) { best_val = vals; best_err = err; } else if (err < best_err) best_val = vals;
        }
        if (k < ILOC) f[fidx16(b, k)] = __float2half_rn(best_val);
      }
    }
    if (threadIdx.x == 0) c.w2sc[ui * 18 * MAXB + b] = outer;
  } else {
    float* sc = c.w2sc + (long)ui * 18 * MAXB;
    for (int e = 0; e < n; e++) {
      int k = threadIdx.x + e * NTH;
      float xv = x[e];
      float m = fabsf(xv);
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float raw = m * (1.0f / 448.0f);
      unsigned bits = __float_as_uint(raw);
      int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
      if (raw <= 5.877471754111438e-39f) ex = 0;
      if (ex > 254) ex = 254;
      float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
      float v = fminf(fmaxf(xv * inverse, -448.f), 448.f);
      if (k < ILOC) {
        frag[fidx8(b, k)] = __nv_fp8_e4m3(v).__x;
        if ((threadIdx.x & 31) == 0) sc[(k >> 5) * MAXB + b] = ue8m0((unsigned)ex);
      }
    }
  }
}

// B == 1: every block quantizes the w2 inputs of all union experts into its shared memory (compact frags).
// Flat index over nu * 576 values: blocks of 16 (nvfp4) / 32 (mxfp8) never straddle experts.
__device__ void phase_quant2_red(const Ctx& c, int i, int nu, Smem& sm) {
  const LayerW& L = c.L[i];
  const int total = nu * ILOC;
  const float FMAX = 3.4028234663852886e38f;
  if (threadIdx.x < nu) {   // one poller per expert: every card's max for this expert (and this card's act is complete)
    float am = 0.f;
    for (int d = 0; d < NCARD; d++) am = fmaxf(am, ll_get1(&c.comm[c.h.card]->llx[i][d][threadIdx.x][0], c.h.tag0 + i + 1));
    sm.misc[threadIdx.x] = am;
    __threadfence();
  }
  __syncthreads();
  for (int base = 0; base < total; base += NTH) {
    int idx = base + threadIdx.x;
    if (base + (threadIdx.x & ~31) >= total) break;   // whole warps beyond the end
    int ui = idx / ILOC, kk = idx % ILOC;
    const float amax = sm.misc[ui];
    float xv = bf(__ldcg(&c.act[(ui * MAXB) * ILOC + kk]));
    if (!L.mx) {
      float outer = amax * (1.0f / 1536.0f);
      float best_val = 0.f;
      float bm = fabsf(xv);
      for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));
      if (amax != 0.f) {
        float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder;
        float best_err = 0.f;
        for (int cand = 0; cand < 2; cand++) {
          float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
          float sraw = fminf(bm * (encoder * inv_max), 448.0f);
          float scale = float(__nv_fp8_e4m3(sraw));
          float inverse = fminf(1.0f / (scale * decoder), FMAX);
          float val = xv * inverse, mag = fabsf(val), q;
          if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
          else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
          if (val != val) q = 0.f;
          float vals = (signbit(val) ? -q : q) * scale;
          float err = fabsf(vals * outer - xv);
          for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
          if (cand == 0) { best_val = vals; best_err = err; } else if (err < best_err) best_val = vals;
        }
      }
      __half* f = reinterpret_cast<__half*>(sm.f2 + ui * 9 * 4 * 32);
      f[fidx16c(kk)] = __float2half_rn(best_val);
      if (kk == 0) sm.sc2[ui * 18 * MAXB] = outer;
    } else {
      float m = fabsf(xv);
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float raw = m * (1.0f / 448.0f);
      unsigned bits = __float_as_uint(raw);
      int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
      if (raw <= 5.877471754111438e-39f) ex = 0;
      if (ex > 254) ex = 254;
      float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
      float v = fminf(fmaxf(xv * inverse, -448.f), 448.f);
      (sm.f2 + ui * 9 * 4 * 16)[fidx8c(kk)] = __nv_fp8_e4m3(v).__x;
      if ((kk & 31) == 0) sm.sc2[ui * 18 * MAXB + (kk >> 5) * MAXB] = ue8m0((unsigned)ex);
    }
  }
  __syncthreads();
}

// final: mlp all-reduce of layer 47 + finalize + output mix + norm -> hfrag
template <bool RED>
__device__ void phase_final(const Ctx& c, int b, Smem& sm) {
  const bool writer = !RED || blockIdx.x == 0;
  float* red = sm.red;
  bf16* part = sm.blk[8];
  const int lp = NL - 1, k0 = threadIdx.x * 8;
  if (ACT8) {
    float rw[8], mlp[8], at[8], pv[8];
    raw8(c.comm[c.h.card]->llm[lp & 1], b, c.h.tag0 + lp + 1, rw, k0);
    conv8(c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H, rw, c.L[lp].mlp_sc, c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, writer, mlp, k0);
    ld8(sm.ats + k0, at);
    ld8(part + k0, pv);
    if (c.dbg && writer) st8(c.dbg + ((long)(lp * 2 + 1) * MAXB + b) * H + k0, mlp);
#pragma unroll
    for (int e = 0; e < 8; e++) pv[e] = (pv[e] + at[e]) + mlp[e];   // layer 47 is not a boundary
    st8(part + k0, pv);
  }
  __syncthreads();
  mix_part8<1>(sm, 8, 0, 9, nullptr, c.oq);
  mix_finish8<1>(sm, 9);
  float out[8];
  mix_out8(sm, 8, 9, nullptr, 0, out);
  rmsnorm8(out, c.fnorm, red);
  if (ACT8) put8<RED>(RED ? sm.fh : c.hfrag, b, k0, out);
}

// ------------------------------------------------------------------------------------------------ team vector phases
// What costs time in the per-token vector phases (all-reduce, short conv, residual mix, norms, input quantization) is
// the instruction path of a thread (measured: ~5 ns per instruction of a lone warp, ~9 ns with 24 warps on the SM), not
// the SM's capacity: 8 elements per thread (576 threads of one block) are ~1800 instructions = 10-20 us per phase.
// So a token's 4608 elements go one per thread to TB = 6 whole blocks ("team"): block b * TB + tj owns elements
// [768 tj, 768 tj + 768). Reductions over the vector (sum of squares, query dots, amax) are done per warp (shuffles),
// per block (shared memory) and then exchanged between the 6 blocks as (value, tag) words in global memory; every
// block combines the 6 partials in block order, so all blocks (and all cards) hold bitwise the same totals.
#define TB 6
static_assert(TB * NTH == H, "team layout: 6 blocks of 768 threads");
__device__ __forceinline__ void put_gpu(uint2* p, float v, unsigned tag) {
  asm volatile("st.relaxed.gpu.global.v2.u32 [%0], {%1, %2};" :: "l"(p), "r"(__float_as_uint(v)), "r"(tag) : "memory");
}
__device__ __forceinline__ uint2 ld_gpu_v2(const void* p) {
  uint2 r;
  asm volatile("ld.relaxed.gpu.global.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p) : "memory");
  return r;
}
__device__ __forceinline__ uint2* trow(const Ctx& c, int rid, int b, int tj) { return c.tred + (long)((rid * MAXB + b) * TB + tj) * 32; }
// hardware conversions (tools/ptx/t5.cu, t6.cu: equal to the model's E2M1 rounding / to __nv_fp8_e4m3 on 2^22 / 2^24 values)
__device__ __forceinline__ float rt_e2m1(float v) {    // nearest E2M1 value (ties to the even code, saturating), signed
  uint32_t r;
  asm("{ .reg .b8 t; cvt.rn.satfinite.e2m1x2.f32 t, %1, %1; cvt.rn.f16x2.e2m1x2 %0, t; }" : "=r"(r) : "f"(v));
  return __half2float(__ushort_as_half((unsigned short)r));
}
__device__ __forceinline__ unsigned enc_e4m3(float v) {
  unsigned short r;
  asm("cvt.rn.satfinite.e4m3x2.f32 %0, %1, %1;" : "=h"(r) : "f"(v));
  return r & 0xffu;
}
__device__ __forceinline__ float rt_e4m3(float v) {
  uint32_t r;
  asm("{ .reg .b16 t; cvt.rn.satfinite.e4m3x2.f32 t, %1, %1; cvt.rn.f16x2.e4m3x2 %0, t; }" : "=r"(r) : "f"(v));
  return __half2float(__ushort_as_half((unsigned short)r));
}
__device__ __forceinline__ float bfbits(unsigned short b) { return __uint_as_float((unsigned)b << 16); }
// N (<= 4) per-thread values -> totals over the token's vector (sum, or max of non-negative values), in every thread
template <int N, bool MX>
__device__ __forceinline__ void tred(const Ctx& c, Smem& sm, int rid, int b, int tj, unsigned tag, float* v) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
#pragma unroll
  for (int i = 0; i < N; i++) {
#pragma unroll
    for (int o = 16; o; o >>= 1) { const float t = __shfl_xor_sync(0xffffffff, v[i], o); v[i] = MX ? fmaxf(v[i], t) : v[i] + t; }
  }
  if (lane == 0) {
#pragma unroll
    for (int i = 0; i < N; i++) sm.red[w * 4 + i] = v[i];
  }
  __syncthreads();
  if (w == 0) {
    float mine = 0.f;
#pragma unroll
    for (int i = 0; i < N; i++) {
      float x = (lane < NWARP) ? sm.red[lane * 4 + i] : 0.f;
#pragma unroll
      for (int o = 16; o; o >>= 1) { const float t = __shfl_xor_sync(0xffffffff, x, o); x = MX ? fmaxf(x, t) : x + t; }
      if (lane == i) mine = x;
    }
    if (lane < N) put_gpu(trow(c, rid, b, tj) + lane, mine, tag);
    const int ci = lane >> 3, cj = lane & 7;   // lane = value * 8 + team block
    float r = 0.f;
    if (ci < N && cj < TB) {
      const uint2* p = trow(c, rid, b, cj) + ci;
      uint2 q = ld_gpu_v2(p);
      while (q.y != tag) q = ld_gpu_v2(p);
      r = __uint_as_float(q.x);
    }
#pragma unroll
    for (int o = 1; o < 8; o <<= 1) { const float t = __shfl_xor_sync(0xffffffff, r, o); r = MX ? fmaxf(r, t) : r + t; }
    if (cj == 0 && ci < N) sm.tt[ci] = r;
  }
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) v[i] = sm.tt[i];
}
// dots of mix sources [s0, s1) with NQ queries over the token's vector: warp p = (s - s0) * NQ + qi takes one pair
// (at most 24 pairs). Totals to sm.tdot[s * 4 + qi]; visible to the other warps after the next __syncthreads.
template <int NQ>
__device__ __forceinline__ void tdots(const Ctx& c, Smem& sm, int rid, int b, int tj, unsigned tag, int nb, int s0, int s1, const float* q) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const int V = (s1 - s0) * NQ;
  const float qs = 0.014731391274719739f;  // 4608 ** -0.5 rounded to fp32
  if (w >= V) return;
  const int s = s0 + w / NQ, qi = w % NQ;
  const bf16* src = msrc(sm, nb, s);
  const float* qp = q + qi * H + tj * NTH;
  float a = 0.f;
#pragma unroll 4
  for (int e = lane; e < NTH; e += 32) a += bf(src[e]) * (qp[e] * qs);
#pragma unroll
  for (int o = 16; o; o >>= 1) a += __shfl_xor_sync(0xffffffff, a, o);
  if (lane == 0) put_gpu(trow(c, rid, b, tj) + w, a, tag);
  float r = 0.f;
  if (lane < TB) {
    const uint2* p = trow(c, rid, b, lane) + w;
    uint2 qq = ld_gpu_v2(p);
    while (qq.y != tag) qq = ld_gpu_v2(p);
    r = __uint_as_float(qq.x);
  }
#pragma unroll
  for (int o = 1; o < 8; o <<= 1) r += __shfl_xor_sync(0xffffffff, r, o);
  if (lane == 0) sm.tdot[s * 4 + qi] = r;
}
// softmax over the n mix sources (warp 0, lane = source). Source np is the one whose statistics v = (sum of squares,
// dots) were just reduced; finished blocks s < nb use their cached 1/rms (sm.fiv), the old partial at a boundary sm.piv.
template <int NQ>
__device__ __forceinline__ void tmixfinish(Smem& sm, int n, int nb, int np, const float* v, bool cache_piv) {
  if (threadIdx.x < 32) {
    const int s = threadIdx.x;
    const bool on = s < n;
    float iv = 0.f;
    if (on) iv = (s == np) ? rsqrtf(v[0] / (float)H + 1e-6f) : (s < nb ? sm.fiv[s] : sm.piv);
    if (on) sm.minv[s] = iv;
    if (cache_piv && s == np) sm.piv = iv;
#pragma unroll
    for (int qi = 0; qi < NQ; qi++) {
      float lg = on ? ((s == np) ? v[1 + qi] : sm.tdot[s * 4 + qi]) * iv : -INFINITY;
      float m = lg;
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      const float pr = on ? expf(lg - m) : 0.f;
      float z = 0.f;
      for (int q = 0; q < n; q++) z += __shfl_sync(0xffffffff, pr, q);
      if (on) sm.mixp[qi * 10 + s] = pr / z;
    }
  }
  __syncthreads();
}
// all-reduce of the four cards' partials of element k (bf16-rounded); spins until the four tags are current
__device__ __forceinline__ float t_raw(const uint2 (*mb)[MAXB][H], int b, unsigned tag, int k) {
  uint2 r0 = ld_relaxed_sys_v2(&mb[0][b][k]), r1 = ld_relaxed_sys_v2(&mb[1][b][k]);
  uint2 r2 = ld_relaxed_sys_v2(&mb[2][b][k]), r3 = ld_relaxed_sys_v2(&mb[3][b][k]);
  while (r0.y != tag || r1.y != tag || r2.y != tag || r3.y != tag) {
    __nanosleep(LL_BACKOFF);
    r0 = ld_relaxed_sys_v2(&mb[0][b][k]); r1 = ld_relaxed_sys_v2(&mb[1][b][k]);
    r2 = ld_relaxed_sys_v2(&mb[2][b][k]); r3 = ld_relaxed_sys_v2(&mb[3][b][k]);
  }
  return rbf(((__uint_as_float(r0.x) + __uint_as_float(r1.x)) + __uint_as_float(r2.x)) + __uint_as_float(r3.x));
}
// short conv of element k: hist [3][H] (oldest first), taps w4 [H][4]; writes the shifted history to hw
__device__ __forceinline__ float t_conv(const bf16* __restrict__ hist, float raw, const bf16* w4, bf16* __restrict__ hw, int k) {
  const unsigned short* hb = reinterpret_cast<const unsigned short*>(hist);
  const unsigned short b0 = __ldcg(hb + k), b1 = __ldcg(hb + H + k), b2 = __ldcg(hb + 2 * H + k);
  const uint2 u = *reinterpret_cast<const uint2*>(w4 + k * 4);
  const __nv_bfloat162* t2 = reinterpret_cast<const __nv_bfloat162*>(&u);
  const float2 ta = __bfloat1622float2(t2[0]), tb = __bfloat1622float2(t2[1]);
  const float wt[4] = {ta.x, ta.y, tb.x, tb.y};
  const float out = sconv4f(bfbits(b0), bfbits(b1), bfbits(b2), raw, wt);
  unsigned short* hwb = reinterpret_cast<unsigned short*>(hw);
  hwb[k] = b1; hwb[H + k] = b2; hw[2 * H + k] = tobf(raw);
  return out;
}
// NVFP4 input quantization of one element (four over six; a block of 16 = 16 consecutive lanes). Returns code x scale.
__device__ __forceinline__ float t_quant_nvfp4(float x, float amax, float* outer_out) {
  const float FMAX = 3.4028234663852886e38f;
  const float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder, outer = amax * (1.0f / 1536.0f);
  float bm = fabsf(x);
#pragma unroll
  for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));
  float vals[2], er[2];
#pragma unroll
  for (int cand = 0; cand < 2; cand++) {
    const float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
    const float sc = rt_e4m3(fminf(bm * (encoder * inv_max), 448.0f));
    const float iv = fminf(1.0f / (sc * decoder), FMAX);
    float val = x * iv;
    if (val != val) val = 0.f;
    vals[cand] = rt_e2m1(val) * sc;
    float err = fabsf(vals[cand] * outer - x);
#pragma unroll
    for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
    er[cand] = err;
  }
  *outer_out = outer;
  return (er[1] < er[0]) ? vals[1] : vals[0];   // a strictly better /4 wins
}
// MXFP8 input quantization of one element (a block of 32 = the warp): code byte and the block's UE8M0 scale
__device__ __forceinline__ unsigned t_quant_mxfp8(float x, float* scale_out) {
  float m = fabsf(x);
#pragma unroll
  for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
  const float raw = m * (1.0f / 448.0f);
  const unsigned bits = __float_as_uint(raw);
  int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
  if (raw <= 5.877471754111438e-39f) ex = 0;
  if (ex > 254) ex = 254;
  const float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
  *scale_out = ue8m0((unsigned)ex);
  return enc_e4m3(fminf(fmaxf(x * inverse, -448.f), 448.f));
}
#define TMT(id) do { if (c.tprof && i == 20 && threadIdx.x == 0) c.tprof[49 * 64 + 1184 + blockIdx.x * 16 + (id)] = gtime(); } while (0)
// mix of the sources with the fresh statistics v of source nb (value f of this thread), NQ rms norms, fragment writes
template <int NQ>
__device__ __forceinline__ void team_mix_norm(const Ctx& c, Smem& sm, int rid, int b, int tj, unsigned tag, int nb, float f,
                                              const float* v, const bf16* const* wn, bf16* frag, int fstride) {
  const int tid = threadIdx.x, k = tj * NTH + tid;
  tmixfinish<NQ>(sm, nb + 1, nb, nb, v, true);
  float o[NQ];
#pragma unroll
  for (int qi = 0; qi < NQ; qi++) o[qi] = 0.f;
  for (int s = 0; s < nb; s++) {
    const float fs = bf(sm.blk[s][tid]) * sm.minv[s];
#pragma unroll
    for (int qi = 0; qi < NQ; qi++) o[qi] += sm.mixp[qi * 10 + s] * fs;
  }
  {
    const float fs = f * sm.minv[nb];
#pragma unroll
    for (int qi = 0; qi < NQ; qi++) o[qi] += sm.mixp[qi * 10 + nb] * fs;
  }
  float ss[NQ];
#pragma unroll
  for (int qi = 0; qi < NQ; qi++) ss[qi] = o[qi] * o[qi];
  tred<NQ, false>(c, sm, rid, b, tj, tag, ss);
#pragma unroll
  for (int qi = 0; qi < NQ; qi++) {
    const float r = rsqrtf(ss[qi] / (float)H + 1e-6f);
    frag[qi * fstride + fidx16(b, k)] = tobf((o[qi] * r) * bf(wn[qi][k]));
  }
}
// attention input of layer i for token b; every thread of team block tj
__device__ void team_attn_in(const Ctx& c, int i, int b, int tj, Smem& sm) {
  const LayerW& L = c.L[i];
  const int tid = threadIdx.x, k = tj * NTH + tid;
  const unsigned tag = c.h.tag0 + i + 1;
  const float qs = 0.014731391274719739f;
  bf16* part = sm.blk[8];
  if (i == 0) {
    const float u = bf(c.embed[(long)c.h.tokens[b] * H + k]);
    float ss[1] = {u * u};
    tred<1, false>(c, sm, 0, b, tj, tag, ss);
    const float y = rbf((u * rsqrtf(ss[0] / (float)H + 1e-6f)) * bf(c.embed_norm[k]));
    part[tid] = tobf(y);
    ss[0] = y * y;
    tred<1, false>(c, sm, 1, b, tj, tag, ss);
    const float r = rsqrtf(ss[0] / (float)H + 1e-6f);
    if (tid == 0) sm.piv = r;
    c.xfrag[fidx16(b, k)] = tobf((y * r) * bf(L.norm[0][k]));
    return;
  }
  const int lp = i - 1;
  const int nb_before = (lp == 0) ? 0 : ((lp - 1) / 6 + 1);
  const bool boundary = (lp % 6) == 0;
  const int nb = nb_before + (boundary ? 1 : 0);
  if (boundary) {   // the partial becomes a finished block (its 1/rms is the one computed when it was last mixed)
    sm.blk[nb_before][tid] = part[tid];
    if (tid == 0) sm.fiv[nb_before] = sm.piv;
    __syncthreads();
  }
  // before the cross-card wait: the finished blocks' dots with this layer's queries
  if (L.glob) tdots<3>(c, sm, 0, b, tj, tag, nb, 0, nb, L.aq);
  else tdots<1>(c, sm, 0, b, tj, tag, nb, 0, nb, L.aq);
  TM(i, 1);
  const float rw = t_raw(c.comm[c.h.card]->llm[lp & 1], b, c.h.tag0 + lp + 1, k);
  const float mlp = t_conv(c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H, rw, c.L[lp].mlp_sc,
                           c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, k);
  if (c.dbg) c.dbg[((long)(lp * 2 + 1) * MAXB + b) * H + k] = tobf(mlp);
  const float at = bf(sm.ats[tid]), pv = bf(part[tid]);
  const float f = rbf(boundary ? (at + mlp) : ((pv + at) + mlp));
  part[tid] = tobf(f);
  TM(i, 16);
  TM(i, 17);
  if (L.glob) {
    float v[4] = {f * f, f * (L.aq[k] * qs), f * (L.aq[H + k] * qs), f * (L.aq[2 * H + k] * qs)};
    tred<4, false>(c, sm, 1, b, tj, tag, v);
    TM(i, 18);
    const bf16* wn[3] = {L.norm[0], L.norm[1], L.norm[2]};
    team_mix_norm<3>(c, sm, 2, b, tj, tag, nb, f, v, wn, c.xfrag, 72 * 32 * 16);
  } else {
    float v[2] = {f * f, f * (L.aq[k] * qs)};
    tred<2, false>(c, sm, 1, b, tj, tag, v);
    TM(i, 18);
    const bf16* wn[1] = {L.norm[0]};
    team_mix_norm<1>(c, sm, 2, b, tj, tag, nb, f, v, wn, c.xfrag, 0);
  }
}
// post-attention of layer i for token b: attention all-reduce + sconv, mlp input mix, norm, input quantization
__device__ void team_post(const Ctx& c, int i, int b, int tj, Smem& sm) {
  const LayerW& L = c.L[i];
  const int tid = threadIdx.x, lane = tid & 31, k = tj * NTH + tid;
  const unsigned tag = c.h.tag0 + i + 1;
  const float qs = 0.014731391274719739f;
  const bf16* part = sm.blk[8];
  const int nb = (i == 0) ? 0 : ((i - 1) / 6 + 1);
  const bool boundary = (i % 6) == 0;
  TMT(0);
  tdots<1>(c, sm, 3, b, tj, tag, nb, 0, boundary ? nb + 1 : nb, L.mq);   // finished blocks (and the old partial at a boundary)
  TMT(1);
  TM(i, 6);
  const float rw = t_raw(c.comm[c.h.card]->lla[i & 1], b, tag, k);
  TMT(2);
  const float at = t_conv(c.hist_attn + ((((long)c.h.parity * NL + i) * MAXB + b) * 3) * H, rw, L.attn_sc,
                          c.hist_attn + ((((long)(c.h.parity ^ 1) * NL + i) * MAXB + b) * 3) * H, k);
  sm.ats[tid] = tobf(at);
  if (c.dbg) c.dbg[((long)(i * 2) * MAXB + b) * H + k] = tobf(at);
  TMT(3);
  TM(i, 20);
  const float pvf = bf(part[tid]);
  const float f = boundary ? at : (pvf + at);     // the source whose statistics are new: attention out, or partial + attention out
  float v[2] = {f * f, f * (L.mq[k] * qs)};
  tred<2, false>(c, sm, 4, b, tj, tag, v);
  TMT(4);
  const int np = boundary ? nb + 1 : nb;
  tmixfinish<1>(sm, np + 1, nb, np, v, false);
  float o = 0.f;
  for (int s = 0; s < nb; s++) o += sm.mixp[s] * (bf(sm.blk[s][tid]) * sm.minv[s]);
  if (boundary) o += sm.mixp[nb] * (pvf * sm.minv[nb]);
  o += sm.mixp[np] * (f * sm.minv[np]);
  TMT(5);
  TM(i, 21);
  float ss[1] = {o * o};
  tred<1, false>(c, sm, 5, b, tj, tag, ss);
  const float x = rbf((o * rsqrtf(ss[0] / (float)H + 1e-6f)) * bf(L.mlp_norm[k]));
  TMT(6);
  TM(i, 22);
  c.x2frag[fidx16(b, k)] = tobf(x);
  if (!L.mx) {
    float am[1] = {fabsf(x)};
    tred<1, true>(c, sm, 6, b, tj, tag, am);
    float outer;
    const float qv = t_quant_nvfp4(x, am[0], &outer);
    reinterpret_cast<__half*>(c.w13frag)[fidx16(b, k)] = __float2half_rn(qv);
    if (tj == 0 && tid == 0) c.w13sc[b] = outer;
  } else {
    float sc;
    const unsigned code = t_quant_mxfp8(x, &sc);
    c.w13frag[fidx8(b, k)] = (uint8_t)code;
    if (lane == 0) c.w13sc[(k >> 5) * MAXB + b] = sc;
  }
  TMT(7);
}
// final: mlp all-reduce of layer 47 + finalize + output mix + norm -> hfrag
__device__ void team_final(const Ctx& c, int b, int tj, Smem& sm) {
  const int tid = threadIdx.x, k = tj * NTH + tid;
  const unsigned tag = c.h.tag0 + NL;   // rids 7-9 only
  const float qs = 0.014731391274719739f;
  bf16* part = sm.blk[8];
  const int lp = NL - 1;
  tdots<1>(c, sm, 7, b, tj, tag, 8, 0, 8, c.oq);
  const float rw = t_raw(c.comm[c.h.card]->llm[lp & 1], b, c.h.tag0 + lp + 1, k);
  const float mlp = t_conv(c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H, rw, c.L[lp].mlp_sc,
                           c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, k);
  if (c.dbg) c.dbg[((long)(lp * 2 + 1) * MAXB + b) * H + k] = tobf(mlp);
  const float f = rbf((bf(part[tid]) + bf(sm.ats[tid])) + mlp);   // layer 47 is not a boundary
  part[tid] = tobf(f);
  float v[2] = {f * f, f * (c.oq[k] * qs)};
  tred<2, false>(c, sm, 8, b, tj, tag, v);
  const bf16* wn[1] = {c.fnorm};
  team_mix_norm<1>(c, sm, 9, b, tj, tag, 8, f, v, wn, c.hfrag, 0);
}

// L2 prefetch of this layer's K and V rows (this card's 2 heads, every token, the positions attention will read):
// thread it < B * 4 takes (token, head, k|v); every block its share of the rows
__device__ __forceinline__ void prefetch_kv(const Ctx& c, int i, int part, int nparts, int pw = 0) {
  const int t = c.h.pos;
  const int lo = c.L[i].glob ? 0 : max(0, t + 1 - WIN);
  const int rows = t - lo;   // position t is written this step
  const int it = (int)threadIdx.x - pw * 32;
  if (rows <= 0 || it < 0 || it >= c.h.B * NKVL * 2) return;
  const int bh = it >> 1;
  const long off = (((long)(i * MAXB + bh / NKVL) * NKVL + bh % NKVL) * c.maxctx + lo) * HD;
  const unsigned bytes = (unsigned)rows * HD * 2;
  const bf16* base = ((it & 1) ? c.vc : c.kc) + off;
  if (bytes / nparts <= 32768u) prefetch_items(base, bytes, part, nparts);
}
// B=1: combine the attention chunks of all 12 local heads (every block redundantly) into the compact o_proj
// fragment in shared memory (sm.fx[0]; the q/k/v fragments are dead after the qkv GEMV)
__device__ void phase_ocombine_red(const Ctx& c, int i, int nch, Smem& sm) {
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const bf16* qkv = c.qkvo;   // token 0
  const int OG = 1536, OS = 3264;
  // per head (warp w < 12): chunk factors exp(m_q - M), the sum L and lse
  if (w < NQL) {
    const int kh = w / 6, j = w % 6;
    const float* base = c.achunk + ((long)(kh * MAXCHUNK) * 6) * (2 + HD);
    float mq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD)) : -INFINITY;
    float lq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD) + 1) : 0.f;
    float M = mq;
    for (int o = 16; o; o >>= 1) M = fmaxf(M, __shfl_xor_sync(0xffffffff, M, o));
    float f = (lane < nch) ? expf(mq - M) : 0.f;
    float Ls = 0.f;
    for (int q = 0; q < nch; q++) Ls += __shfl_sync(0xffffffff, lq * f, q);
    if (lane < nch) sm.att[w * 32 + lane] = f;      // 12 x 32 floats (sm.att holds 6 x 128)
    if (lane == 0) { sm.misc[w * 2] = M + logf(Ls); sm.misc[w * 2 + 1] = Ls; }
  }
  __syncthreads();
  for (int idx = tid; idx < NQL * HD; idx += NTH) {
    const int hl = idx / HD, d = idx % HD, kh = hl / 6, j = hl % 6;
    const float* base = c.achunk + ((long)(kh * MAXCHUNK) * 6) * (2 + HD);
    float O = 0.f;
    for (int q = 0; q < nch; q++) O += __ldcg(base + (q * 6 + j) * (2 + HD) + 2 + d) * sm.att[hl * 32 + q];
    float out = O / sm.misc[hl * 2 + 1];
    out = out * sigm(bf(qkv[OG + hl * HD + d]));
    out = out * sigm(sm.misc[hl * 2] - bf(qkv[OS + hl]));
    put16<true>(&sm.fx[0][0], 0, hl * HD + d, out);
  }
  __syncthreads();
}
// L2 prefetch of a layer's small weights (scales, taps, norms, queries, router bias), one region per block
__device__ __forceinline__ void prefetch_small(const Ctx& c, int i, int part, int pw = 0) {
  const LayerW& L = c.L[i];
  const void* p = nullptr; long n = 0;
  switch (part) {
    case 0: p = L.qscale; n = NQL * HD * 2; break;
    case 1: p = L.rscale; n = NQL * DREL * 2; break;
    case 2: p = L.relp; n = DREL * RELEXT * 2; break;
    case 3: p = L.ksc; n = 256 * 4 * 2; break;
    case 4: p = L.vsc; n = 256 * 4 * 2; break;
    case 5: p = L.attn_sc; n = H * 4 * 2; break;
    case 6: p = L.mlp_sc; n = H * 4 * 2; break;
    case 7: p = L.mq; n = H * 4; break;
    case 8: p = L.mlp_norm; n = H * 2; break;
    case 9: p = L.rbias; n = NE * 4; break;
    case 10: p = L.f13; n = NE * 4; break;
    case 11: p = L.f2; n = NE * 4; break;
    case 12: if (i + 1 < NL) { p = c.L[i + 1].aq; n = (c.L[i + 1].glob ? 3 : 1) * H * 4; } break;
    case 13: if (i + 1 < NL) { p = c.L[i + 1].norm[0]; n = H * 2; } break;
    case 14: if (i + 1 < NL && c.L[i + 1].glob) { p = c.L[i + 1].norm[1]; n = H * 2; } break;
    case 15: if (i + 1 < NL && c.L[i + 1].glob) { p = c.L[i + 1].norm[2]; n = H * 2; } break;
    default: break;
  }
  if (p && n >= 16) prefetch_l2(p, n, 0, 1, pw);
}
// ------------------------------------------------------------------------------------------------ the step kernel
template <bool RED>
__device__ __forceinline__ void step_body(const Ctx& c, Smem& sm, int layer_lo, int layer_hi) {
  if (RED) {
    for (int k = threadIdx.x; k < 144 * MAXB; k += NTH) sm.sc13[k] = 0.f;
    for (int k = threadIdx.x; k < 8 * 18 * MAXB; k += NTH) sm.sc2[k] = 0.f;
    __syncthreads();
  }
  unsigned nbar = 0;
  const unsigned barbase = *((volatile unsigned*)&c.bar[1]);
  const int B = c.h.B;
  const int nblk = gridDim.x;
  unsigned ev = 0;  // comm events of this launch (per counter kind)
  unsigned ev_attn = 0, ev_mlp = 0, ev_amax = 0;
  for (int i = layer_lo; i < layer_hi; i++) {
    const LayerW& L = c.L[i];
    // A: attention input
    TM(i, 0);
    if (RED) {
      prefetch_l2(L.wqkv, (long)L.qkv_strips * 72 * 2048, blockIdx.x, nblk);
      prefetch_kv(c, i, blockIdx.x, nblk);
      if (blockIdx.x >= nblk - 16) prefetch_small(c, i, nblk - 1 - blockIdx.x);
      phase_attn_in<true>(c, i, 0, sm, i > 0, ev_mlp);
      __syncthreads();   // the fragments of every warp are read by the next GEMV
    } else {
#ifdef NO_TEAM
      if (blockIdx.x < B) phase_attn_in<false>(c, i, blockIdx.x, sm, i > 0, ev_mlp);
      else {
        prefetch_l2(L.wqkv, (long)L.qkv_strips * 72 * 2048, blockIdx.x - B, nblk - B); prefetch_kv(c, i, blockIdx.x - B, nblk - B);
        if (blockIdx.x >= nblk - 16) prefetch_small(c, i, nblk - 1 - blockIdx.x);
      }
#else
      if (blockIdx.x < B * TB) team_attn_in(c, i, blockIdx.x / TB, blockIdx.x % TB, sm);
      else {
        prefetch_l2(L.wqkv, (long)L.qkv_strips * 72 * 2048, blockIdx.x - B * TB, nblk - B * TB); prefetch_kv(c, i, blockIdx.x - B * TB, nblk - B * TB);
        if (blockIdx.x >= nblk - 16) prefetch_small(c, i, nblk - 1 - blockIdx.x);
      }
#endif
      grid_bar(c, nbar, barbase);
    }
    TM(i, 2);
    // B: qkv
    if (!RED) stage_frags(sm, c.xfrag, 73728);
    { OpQKV<RED> op{i, RED ? &sm.fx[0][0] : c.xfrag, RED ? nullptr : reinterpret_cast<const bf16*>(sm.stage)};
      gemv_sel(c, op, L.qkv_strips, 72, 1, &sm.opart[0][0]); }
    __syncthreads();
    if (c.tprof && threadIdx.x == 0 && i == 20) {
      unsigned smid; asm volatile("mov.u32 %0, %%smid;" : "=r"(smid));
      c.tprof[49 * 64 + 0 * 152 + blockIdx.x] = gtime();
      c.tprof[49 * 64 + 3 * 152 + blockIdx.x] = smid;
    }
    grid_bar(c, nbar, barbase);
    TM(i, 3);
    // C: attention
    {
      int t = c.h.pos;
      int lo = L.glob ? 0 : max(0, t + 1 - WIN);
      int nch = (t + 1 - lo + CHUNK - 1) / CHUNK;
      int nitems = B * NKVL * nch;
      if (blockIdx.x >= nitems && nitems < nblk) prefetch_l2(L.wo, 288L * 24 * 2048, blockIdx.x - nitems, nblk - nitems);
      for (int it = blockIdx.x; it < nitems; it += nblk) {
        int b = it / (NKVL * nch), r = it % (NKVL * nch);
        phase_attention(c, i, b, r / nch, r % nch, nch, sm, !RED);
        __syncthreads();
      }
      if (c.tprof && threadIdx.x == 0 && i == 20) c.tprof[49 * 64 + 4 * 152 + blockIdx.x] = gtime();
    }
    grid_bar(c, nbar, barbase);
    TM(i, 4);
    // D: o_proj -> all cards
    if (RED) {
      const int t = c.h.pos, lo = L.glob ? 0 : max(0, t + 1 - WIN);
      phase_ocombine_red(c, i, (t + 1 - lo + CHUNK - 1) / CHUNK, sm);
    }
    { OpOproj<RED> op{i, RED ? &sm.fx[0][0] : c.ofrag}; gemv_sel(c, op, 288, 24, 2, &sm.opart[0][0]); }
    ev_attn++;
    TM(i, 5);
    // E: post-attention (token blocks)
    if (RED) {
      prefetch_l2(L.wr, 24L * 72 * 2048, blockIdx.x, nblk);
      phase_post_attn<true>(c, i, 0, sm, true, ev_attn);
      __syncthreads();
    } else {
#ifdef NO_TEAM
      if (blockIdx.x < B) phase_post_attn<false>(c, i, blockIdx.x, sm, true, ev_attn);
      else prefetch_l2(L.wr, 24L * 72 * 2048, blockIdx.x - B, nblk - B);
#else
      if (blockIdx.x < B * TB) team_post(c, i, blockIdx.x / TB, blockIdx.x % TB, sm);
      else prefetch_l2(L.wr, 24L * 72 * 2048, blockIdx.x - B * TB, nblk - B * TB);
#endif
      grid_bar(c, nbar, barbase);
    }
    TM(i, 7);
    // F: router
    if (!RED) stage_frags(sm, c.x2frag, 73728);
    { OpRouter<RED> op{i, RED ? sm.fx2 : reinterpret_cast<const bf16*>(sm.stage)}; gemv_sel(c, op, 24, 72, 4, &sm.opart[0][0]); }
    TM(i, 8);
    // G: routing (every block)
#ifdef ICTEST
    phase_route(c, i, sm);   // a second, i-cache-warm run is timed 31 -> 9
    TM(i, 31);
#endif
    phase_route(c, i, sm);
    TM(i, 9);
    int nu = sm.nuni;
    // H: w13 (+ act, amax to all cards)
    if (!RED) {
      if (L.mx) stage_frags(sm, c.w13frag, 36864, c.w13sc, 144 * MAXB * 4);
      else stage_frags(sm, c.w13frag, 73728);
    }
    { OpW13<RED> op{i, nu, &sm, RED ? sm.f13 : sm.stage,
                    RED ? sm.sc13 : (L.mx ? reinterpret_cast<const float*>(sm.stage + 36864) : c.w13sc), RED ? sm.sc13 : c.w13sc};
      gemv_sel(c, op, (long)nu * 72, 72, 8, &sm.opart[0][0]); }
    __syncthreads();
    if (c.tprof && threadIdx.x == 0 && i == 20) c.tprof[49 * 64 + 1 * 152 + blockIdx.x] = gtime();
    {
      // every block: its share of the union experts' w2 slabs (thread u: expert u; one instruction each)
#ifndef NO_W2PF
      const unsigned per = 288u * 9u * (L.mx ? UB8 : UB4);
      if (threadIdx.x < nu) prefetch_items(L.w2 + (long)sm.uni[threadIdx.x] * per, per, blockIdx.x, nblk);
#endif
    }
    ev_amax++;
    TM(i, 10);
    TM(i, 11);
    // I: quantize act for w2
    if (RED) {
      phase_quant2_red(c, i, nu, sm);
    } else {
      for (int it = blockIdx.x; it < nu * B; it += nblk) {
        int ui = it / B, b = it % B;
        bool routed = false;
        for (int r = 0; r < TOPK; r++) routed |= (sm.ids[b * TOPK + r] == sm.uni[ui]);
        if (routed) { phase_quant2(c, i, ui, b, sm); __syncthreads(); }
        else {  // not routed: zero scale and zero fragment column (a stale fragment of the other format could be Inf)
          if (threadIdx.x < 18) c.w2sc[(ui * 18 + threadIdx.x) * MAXB + b] = 0.f;
          if (threadIdx.x < ILOC) {
            uint8_t* frag = c.w2frag + (long)ui * 9 * 32 * (L.mx ? 16 : 32);
            if (L.mx) frag[fidx8(b, threadIdx.x)] = 0;
            else reinterpret_cast<__half*>(frag)[fidx16(b, threadIdx.x)] = __float2half_rn(0.f);
          }
        }
      }
      grid_bar(c, nbar, barbase);
    }
    TM(i, 12);
    // J: w2 -> all cards
    { OpW2<RED> op{i, nu, &sm, RED ? sm.f2 : c.w2frag, RED ? sm.sc2 : c.w2sc}; gemv_sel(c, op, 288, nu * 9, 16, &sm.opart[0][0]); }
    __syncthreads();
    if (c.tprof && threadIdx.x == 0 && i == 20) c.tprof[49 * 64 + 2 * 152 + blockIdx.x] = gtime();
    ev_mlp++;
    TM(i, 13);
  }
  if (layer_hi == NL) {
    TM(NL, 0);
    if (RED) {
      TM(NL, 1); phase_final<true>(c, 0, sm);
      __syncthreads();
    } else {
#ifdef NO_TEAM
      if (blockIdx.x < B) { TM(NL, 1); phase_final<false>(c, blockIdx.x, sm); }
#else
      TM(NL, 1);
      if (blockIdx.x < B * TB) team_final(c, blockIdx.x / TB, blockIdx.x % TB, sm);
#endif
      grid_bar(c, nbar, barbase);
    }
    TM(NL, 2);
    for (int k = threadIdx.x; k < NWARP * MAXB; k += NTH) { sm.bestv[k] = -INFINITY; sm.besti[k] = 1 << 30; }
    __syncthreads();
    if (!RED) stage_frags(sm, c.hfrag, 73728);
    { OpUnembed<RED> op{sm.bestv, sm.besti, RED ? sm.fh : reinterpret_cast<const bf16*>(sm.stage)}; gemv_sel(c, op, c.un_strips, 72, 32, &sm.opart[0][0]); }
    __syncthreads();
    // block best per col -> candidates on every card
    if (threadIdx.x < B) {
      int col = threadIdx.x;
      float bv = -INFINITY; int bi = 1 << 30;
      for (int w = 0; w < NWARP; w++) {
        float v = sm.bestv[w * MAXB + col]; int ii = sm.besti[w * MAXB + col];
        if (v > bv || (v == bv && ii < bi)) { bv = v; bi = ii; }
      }
      for (int d = 0; d < NCARD; d++) { c.comm[d]->cand_v[c.h.card][col][blockIdx.x] = bv; c.comm[d]->cand_i[c.h.card][col][blockIdx.x] = bi; }
    }
    xsignal(c, 3, nbar, barbase);
    TM(NL, 3);
    if (blockIdx.x == 0) {
      xwait(c, 3, 1);
      TM(NL, 4);
      if (threadIdx.x < B) {
        int col = threadIdx.x;
        float bv = -INFINITY; int bi = 1 << 30;
        for (int d = 0; d < NCARD; d++)
          for (int k = 0; k < nblk; k++) {
            float v = c.comm[c.h.card]->cand_v[d][col][k]; int ii = c.comm[c.h.card]->cand_i[d][col][k];
            if (v > bv || (v == bv && ii < bi)) { bv = v; bi = ii; }
          }
        c.next_tok[col] = bi;
        if (c.h.gen_out) {
          if (c.h.gen_n) c.h.gen_out[c.h.gen_idx * MAXB + col] = bi + 1;          // host-mapped stream: 0 = not yet
          else c.h.gen_out[c.h.gen_idx * MAXB + col] = bi;
        }
      }
    }
  }
  grid_bar(c, nbar, barbase);
  if (blockIdx.x == 0 && threadIdx.x == 0) c.bar[1] = barbase + nbar * gridDim.x;
}

// the kernel parameters (Ctx, ~14 KB) are copied into shared memory once: every later access is a shared load,
// immune to the L1 invalidations of the barriers' acquire fences
#define CTXB ((sizeof(Ctx) + 127) / 128 * 128)
#define SMEM_TOTAL (CTXB + sizeof(Smem))
__device__ __forceinline__ const Ctx& load_ctx(const Ctx* cp, const Hdr& hdr, unsigned char* smraw) {
  static_assert(sizeof(Ctx) % 8 == 0 && sizeof(Hdr) % 8 == 0, "Ctx size");
  const uint2* src = reinterpret_cast<const uint2*>(cp);
  uint2* dst = reinterpret_cast<uint2*>(smraw);
  const int nh = sizeof(Hdr) / 8;
  for (int k = threadIdx.x; k < (int)(sizeof(Ctx) / 8); k += NTH)
    dst[k] = (k < nh) ? reinterpret_cast<const uint2*>(&hdr)[k] : src[k];   // the per-step header comes by value
  __syncthreads();
  return *reinterpret_cast<const Ctx*>(smraw);
}
extern "C" __global__ void __launch_bounds__(NTH, 1) ink_step_std(const Ctx* __restrict__ cp, const Hdr hdr, int lo, int hi) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Ctx& c = load_ctx(cp, hdr, smraw);
  step_body<false>(c, *reinterpret_cast<Smem*>(smraw + CTXB), lo, hi);
}
extern "C" __global__ void __launch_bounds__(NTH, 1) ink_step_red(const Ctx* __restrict__ cp, const Hdr hdr, int lo, int hi) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Ctx& c = load_ctx(cp, hdr, smraw);
  step_body<true>(c, *reinterpret_cast<Smem*>(smraw + CTXB), lo, hi);
}

// ------------------------------------------------------------------------------------------------ host API
extern "C" int ink_smem_bytes() { return (int)sizeof(Smem); }
extern "C" int ink_ctx_bytes() { return (int)sizeof(Ctx); }
extern "C" int ink_comm_bytes() { return (int)sizeof(Comm); }
extern "C" int ink_layer_bytes() { return (int)sizeof(LayerW); }

extern "C" int ink_setup(int dev) {
  cudaSetDevice(dev);
  cudaError_t e = cudaFuncSetAttribute(ink_step_std, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)SMEM_TOTAL);
  if (e) return (int)e;
  e = cudaFuncSetAttribute(ink_step_red, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)SMEM_TOTAL);
  return (int)e;
}

extern "C" int ink_enable_peer(int n) {
  for (int a = 0; a < n; a++) {
    cudaSetDevice(a);
    for (int b = 0; b < n; b++) if (a != b) {
      cudaError_t e = cudaDeviceEnablePeerAccess(b, 0);
      if (e != cudaSuccess && e != cudaErrorPeerAccessAlreadyEnabled) return (int)e;
      cudaGetLastError();
    }
  }
  return 0;
}
extern "C" void* ink_host_alloc(size_t n) {
  void* p = nullptr;
  if (cudaHostAlloc(&p, n, cudaHostAllocMapped | cudaHostAllocPortable) != cudaSuccess) return nullptr;
  memset(p, 0, n);
  return p;
}
extern "C" int ink_h2d(void* dst, const void* src, size_t n, void* stream) {
  return (int)cudaMemcpyAsync(dst, src, n, cudaMemcpyHostToDevice, (cudaStream_t)stream);
}
extern "C" int ink_launch(int dev, const void* ctx, const void* hdr, int nblk, void* stream, int lo, int hi, int red) {
  cudaSetDevice(dev);
  const Hdr h = *reinterpret_cast<const Hdr*>(hdr);
  if (red) ink_step_red<<<nblk, NTH, SMEM_TOTAL, (cudaStream_t)stream>>>((const Ctx*)ctx, h, lo, hi);
  else ink_step_std<<<nblk, NTH, SMEM_TOTAL, (cudaStream_t)stream>>>((const Ctx*)ctx, h, lo, hi);
  return (int)cudaGetLastError();
}
