#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
LIB=${MK_LIBNAME:-libmk.so}
rm -f build/$LIB build/${LIB%.so}_b1.so
# build switch: engine/TRACK (or $MK_TRACK): "A ..." = the checkpoint's formats and data flow; "B ..." adds track-B items.
# Tokens: W12 (track B storage); K1 (track A: a second library compiled for batch 1 only);
# NAME[=VALUE] = -D for both kernels, NAME[=VALUE]:1 = batch-1 kernel only, NAME[=VALUE]:N = generic kernel only.
TRACKV=${MK_TRACK:-$(cat TRACK 2>/dev/null || echo A)}
DEFS="${MK_DEFS:-}"; B1DEFS="${MK_DEFS_B1-}"; GDEFS="${MK_DEFS_BN-}"
for tok in $TRACKV; do
  case "$tok" in
    A|B|K1) ;;
    W12) DEFS="$DEFS -DW12";;
    *:1) n=${tok%:1}; case "$n" in *=*) B1DEFS="$B1DEFS -D$n";; *) B1DEFS="$B1DEFS -D$n=1";; esac;;
    *:N) n=${tok%:N}; case "$n" in *=*) GDEFS="$GDEFS -D$n";; *) GDEFS="$GDEFS -D$n=1";; esac;;
    *=*) DEFS="$DEFS -D$tok";;
    *) DEFS="$DEFS -D$tok=1";;
  esac
done
if [ -n "${MK_PRINT_DEFS:-}" ]; then echo "$DEFS | $B1DEFS | $GDEFS"; exit 0; fi
# --use_fast_math: approximate exp / tanh / division / sqrt in the vector code (softmax, sigmoid, activation, norms);
# flush-to-zero is harmless here: no expert scale or operand of the f16 / f32 paths is denormal (tests/mxscales.py)
NV="nvcc -O3 --use_fast_math -std=c++17 -gencode arch=compute_100a,code=sm_100a -Xcompiler -fPIC -shared -Xptxas -v ${MK_CFLAGS:-}"
K1=0; case " $TRACKV " in *" K1 "*) K1=1;; esac
if [ "$K1" = 1 ]; then
  $NV $DEFS -DKB1=1 $B1DEFS -o build/${LIB%.so}_b1.so mk.cu 2> build/ptxas_b1.log &
  PB1=$!
fi
$NV $DEFS $GDEFS -o build/$LIB mk.cu 2> build/ptxas.log || { cat build/ptxas.log; exit 1; }
if [ "$K1" = 1 ]; then wait $PB1 || { cat build/ptxas_b1.log; exit 1; }; grep -E "registers|spill" build/ptxas_b1.log | head -3 | sed 's/^/b1: /' || true; fi
grep -E "mk_step|registers|spill" build/ptxas.log | head -8 || true
