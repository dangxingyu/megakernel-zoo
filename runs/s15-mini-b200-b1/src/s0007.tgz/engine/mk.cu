// Inkling-2-Mini decode engine: one persistent cooperative kernel per decode step on one B200.
// Track A: the checkpoint's formats (BF16 dense weights, NVFP4 / MXFP8 experts with their block scales), the
// specification's data flow (unquantized BF16 expert inputs). See notes/design.md for layouts and phases.
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef __nv_bfloat16 bf16;

#define H 2304
#define QD 3072
#define KVD 1024
#define NHQ 24
#define NHKV 8
#define HD 128
#define NE 128
#define TOPK 8
#define IM 1152
#define DREL 16
#define RELX 1024
#define WIN 1024
#define MAXB 8
#ifndef NT
#define NT 512
#endif
#define NW (NT / 32)
#define XS (H + 8)            // smem row stride (elements) of token vectors
#define NAPP 48
#define VOCAB 200058          // real vocabulary (output columns)
#define VSTRIPS 12504         // 16-row strips of the unembedding covering it
#define CH 64                 // attention positions per work unit
#define MAXCH 40              // max chunks (context <= 2560)
#define GSEG 12               // k segments of the controller down projection (attn gates)
#define MSEG 36               // k segments of the controller down projection (mlp gate)
#define RSEG 16               // k segments of the router

// ------------------------------------------------------------------------------------------------ parameters
struct LayerW {               // all fields 8 bytes (host packs them as uint64)
  const uint4* wqkv;          // bf16 tiles [strips][144][32] (rows: q | gate | r | sink+pad | k (| kproj) | v (| vproj))
  const uint4* wo;            // [144 strips][192][32]
  const uint4* wr;            // router [8][144][32]
  const float* rbias;         // [128]
  const uint8_t* w13;         // experts, packed per expert (see pack.py)
  const uint8_t* w13s;
  const float* f13;           // [128] amax / denominator (nvfp4)
  const uint8_t* w2;
  const uint8_t* w2s;
  const float* f2;
  const bf16* normq;          // attn_norm (local) or q_input_norm
  const bf16* normk;
  const bf16* normv;
  const bf16* mlpnorm;
  const bf16* kconv;          // local [1024][4] (tap 3 = current); global static_w [4][1024] (lag 0 = current)
  const bf16* vconv;
  const bf16* aconv;          // [2304][4]
  const bf16* mconv;
  const bf16* qscale;         // [24][128]
  const bf16* rscale;         // [24][16]
  const bf16* relp;           // [16][1024]
  const float* aq;            // attention-residual queries [nq][2304] (layer 0: null)
  const float* mq;            // [2304]
  const uint4* cdown;         // controllers down [4 gates (q,k,v,mlp)][4 strips][288][32] bf16 tiles (loop layers)
  const bf16* cforget;        // [4][2304][64]
  const bf16* cgain;          // [4][2304][64]
  long long glob;
  long long mx;               // experts are MXFP8
  long long nstrip;           // qkv strips
  long long koff;             // first k row in the qkv output
  long long voff;             // first v row
  long long kpoff;            // global: first kproj row (-1 local)
  long long vpoff;
};

__constant__ LayerW cL[24];   // per-layer descriptors: constant cache, no dependent global load per phase

struct Params {
  const LayerW* L;            // [24]
  const bf16* emb;            // [201024][2304]
  const bf16* embnorm;
  const bf16* finalnorm;
  const float* outq;          // [2304]
  const float* loopq;         // [12][4][2304]
  const uint4* unemb;         // [12564][144][32] tiles
  const long long* tok;       // [B] int64 input tokens
  int* pos;                   // [MAXB] position of every slot
  float* logits;              // [B][VOCAB]
  bf16* kc;                   // K cache [48 slots][MAXB][8][ctx][128]
  bf16* vc;
  bf16* kring;                // raw K projection history [48][MAXB][4][1024]
  bf16* vring;
  bf16* oring;                // raw attention output-projection history [48][MAXB][4][2304]
  bf16* mring;                // raw MoE output history [48][MAXB][4][2304]
  bf16* blk;                  // block states [8][MAXB][2304]: 0 h0, 1 P5, 2-4 P11 pass 0-2, 5-7 P17 pass 0-2
  bf16* pbuf;                 // entering partial, ping-pong [2][MAXB][2304]
  bf16* att;                  // attention output after conv [MAXB][2304]
  bf16* xm;                   // normalized MoE input [MAXB][2304]
  float* qkv;                 // [MAXB][8704]
  bf16* ao;                   // gated attention output [MAXB][3072]
  float* apart;               // attention partials [MAXB][24][MAXCH][132]
  float* gpart;               // controller partials [MAXB][3][GSEG or MSEG][64]
  float* coef;                // stream coefficients [MAXB][8][8]
  float* xg;                  // gated streams [3][MAXB][2304]
  float* rpart;               // router partials [MAXB][RSEG][128]
  __half* act;                // expert activations x 64 [MAXB][8][1152]
  unsigned* sync;             // [0] grid barrier, [64..] attention combine counters [48][MAXB][8]
  float* dbg;                 // optional [48][MAXB][2304] entering partial of every application
  unsigned long long* outkey; // greedy: argmax keys of this step [MAXB] (null: no argmax)
  const unsigned long long* tokkey;   // greedy: input tokens decoded from the previous step's keys (null: tok)
  int* hostout;               // greedy: host-mapped [MAXB + 2]: tokens, then the step sequence number
  long long seq;              // step sequence number written to hostout[MAXB] when the tokens are there
  long long nohead;           // prefill step: skip the unembedding
  const uint4* skq;           // track B: 8-bit sketch of the unembedding (biased codes, tile order) or null
  const float* sks;           // per-row scale
  const float* skc;           // per-row certified error bound factor
  const float* skn;           // per-row ||s q||_2 (bound of the input-digit error term)
  float* skab;                // [MAXB][VSTRIPS*16] upper bounds of the sketch logits
  unsigned* sklo;             // [MAXB] best lower bound (orderable key)
  float* hpart;               // W2-epilogue dot partials [144][MAXB][NPS]
  float* epart;               // O-projection-epilogue dot partials [144][MAXB][NPS]
  unsigned long long* prof;   // optional: (globaltimer, phase code) after every grid barrier, block 0
  long long ctx;
  long long B;
  long long nb;               // grid size
};

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ unsigned lane_id() { unsigned r; asm("mov.u32 %0, %%laneid;" : "=r"(r)); return r; }
__device__ __forceinline__ float warp_sum(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v += __shfl_xor_sync(0xffffffffu, v, o);
  return v;
}
__device__ __forceinline__ float warp_max(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, o));
  return v;
}
__device__ __forceinline__ uint4 ldw(const uint4* p) {   // streamed weights
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldw2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ unsigned short ldw16(const void* p) {
  unsigned short r;
  asm volatile("ld.global.nc.L1::no_allocate.u16 %0, [%1];" : "=h"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ float ldbf(const bf16* p) {      // activation written in this launch: L2
  unsigned short r;
  asm volatile("ld.global.cg.u16 %0, [%1];" : "=h"(r) : "l"(p));
  return __uint_as_float(((unsigned)r) << 16);
}
__device__ __forceinline__ float ldf(const float* p) { return __ldcg(p); }
__device__ __forceinline__ float rbf(float x) { return __bfloat162float(__float2bfloat16(x)); }   // round to bf16
__device__ __forceinline__ float sigm(float x) { return 1.f / (1.f + __expf(-x)); }

__device__ __forceinline__ void mma_bf16(float c[4], const uint32_t a[4], uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_f16(float c[4], const uint32_t a[4], uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b0), "r"(b1));
}
// 4 bytes of E2M1 pairs -> 4 f16x2 (low nibble -> low half)
__device__ __forceinline__ void e2m1x8(uint32_t w, uint32_t o[4]) {
#ifdef FAKE_DECODE
  o[0] = (w << 9) & 0x8E008E00u; o[1] = (w << 5) & 0x8E008E00u; o[2] = (w << 1) & 0x8E008E00u; o[3] = (w >> 3) & 0x8E008E00u;
  return;
#endif
  asm("{\n.reg .b8 b0, b1, b2, b3;\nmov.b32 {b0, b1, b2, b3}, %4;\n"
      "cvt.rn.f16x2.e2m1x2 %0, b0;\ncvt.rn.f16x2.e2m1x2 %1, b1;\ncvt.rn.f16x2.e2m1x2 %2, b2;\ncvt.rn.f16x2.e2m1x2 %3, b3;\n}"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
__device__ __forceinline__ uint32_t e4m3x2(unsigned short v) {
  uint32_t r;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(v));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) {
  uint32_t r;
  asm("mul.rn.f16x2 %0, %1, %2;" : "=r"(r) : "r"(a), "r"(b));
  return r;
}
__device__ __forceinline__ uint32_t lo2(uint32_t x) { return __byte_perm(x, 0, 0x1010); }
__device__ __forceinline__ uint32_t hi2(uint32_t x) { return __byte_perm(x, 0, 0x3232); }
__device__ __forceinline__ float e8m0(unsigned s) { return s ? __uint_as_float(s << 23) : __uint_as_float(0x00400000u); }

__device__ __forceinline__ unsigned ld_acquire(const unsigned* p) {
  unsigned v;
  asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory");
  return v;
}
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); return t; }
__device__ __forceinline__ void gbar(unsigned* ctr, unsigned& target, int nb) {
  __syncthreads();
  target += nb;
  if (threadIdx.x == 0) {
    __threadfence();
    atomicAdd(ctr, 1u);
    while (ld_acquire(ctr) < target) { }
  }
  __syncthreads();
}

#ifndef USE_PF13
#define USE_PF13 0
#endif
#ifndef PF_O
#define PF_O 0
#endif
#ifndef PF_W2
#define PF_W2 0
#endif
// L2 prefetch of a weight range by the whole block (bulk prefetch, 16-byte granularity)
__device__ __forceinline__ void pf_l2(const void* p, unsigned bytes) {
  asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(p), "r"(bytes) : "memory");
}
__device__ __forceinline__ void pf_rangeX(const void* p, size_t bytes) {
  const char* c = (const char*)p;
  for (size_t off = (size_t)threadIdx.x * 16384; off < bytes; off += (size_t)NT * 16384)
    pf_l2(c + off, (unsigned)(bytes - off < 16384 ? bytes - off : 16384));
}
__device__ __forceinline__ void pf_range(const void* p, size_t bytes) {
#ifdef USE_PF
  const char* c = (const char*)p;
  for (size_t off = (size_t)threadIdx.x * 16384; off < bytes; off += (size_t)NT * 16384)
    pf_l2(c + off, (unsigned)(bytes - off < 16384 ? bytes - off : 16384));
#endif
}

// ------------------------------------------------------------------------------------------------ strip kernels
// One warp: C fragment (rows g, g+8; tokens 2t, 2t+1) of a 16-row strip over k tiles [k0, k1).
// x: smem token rows [8][XS] (bf16 or f16), tokens >= B read as zero.
template <int U>
__device__ __forceinline__ void strip_bf16_i(const uint4* A, int k0, int k1, const bf16* xs, int B, float c[4], int xst = XS) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  const bf16* xr = xs + g * xst + 2 * t;
  const bool on = g < (unsigned)B;
  for (int k = k0; k < k1; k += U) {
    uint4 a[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (k + u < k1) a[u] = ldw(A + (size_t)(k + u) * 32 + lane);
#pragma unroll
    for (int u = 0; u < U; u++)
      if (k + u < k1) {
        uint32_t b0 = 0, b1 = 0;
        if (on) { b0 = *(const uint32_t*)(xr + (k + u) * 16); b1 = *(const uint32_t*)(xr + (k + u) * 16 + 8); }
        mma_bf16(c, (const uint32_t*)&a[u], b0, b1);
      }
  }
}

#ifndef STRIP_INLINE
template <int U>
__device__ __noinline__ float4 strip_bf16_n(const uint4* A, int k0, int k1, const bf16* xs, int B, float4 ci, int xst) {
  float c[4] = {ci.x, ci.y, ci.z, ci.w};
  strip_bf16_i<U>(A, k0, k1, xs, B, c, xst);
  return make_float4(c[0], c[1], c[2], c[3]);
}
template <int U>
__device__ __forceinline__ void strip_bf16(const uint4* A, int k0, int k1, const bf16* xs, int B, float c[4], int xst = XS) {
  const float4 r = strip_bf16_n<U>(A, k0, k1, xs, B, make_float4(c[0], c[1], c[2], c[3]), xst);
  c[0] = r.x; c[1] = r.y; c[2] = r.z; c[3] = r.w;
}
#else
template <int U>
__device__ __forceinline__ void strip_bf16(const uint4* A, int k0, int k1, const bf16* xs, int B, float c[4], int xst = XS) { strip_bf16_i<U>(A, k0, k1, xs, B, c, xst); }
#endif

// NVFP4: chunk = 64 k (4 MMAs). A: [chunk][32 lanes] uint4 codes; S: [chunk][8 g] uint2 scale pairs.
template <int U>
__device__ __forceinline__ void strip_nv_i(const uint4* A, const uint2* S, int c0, int c1, const __half* xs, int B, float c[4]) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  const __half* xr = xs + g * XS + 2 * t;
  const bool on = g < (unsigned)B;
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    uint2 s[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) { a[u] = ldw(A + (size_t)(ch + u) * 32 + lane); s[u] = ldw2(S + (size_t)(ch + u) * 8 + g); }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
#pragma unroll
        for (int q = 0; q < 4; q++) {
          uint32_t r[4];
          e2m1x8((&a[u].x)[q], r);
          const uint32_t sp = (q < 2 ? s[u].x : s[u].y) >> (16 * (q & 1));
          const uint32_t sc = e4m3x2((unsigned short)(sp & 0xffff));
          const uint32_t sg = lo2(sc), sg8 = hi2(sc);
          r[0] = hmul2(r[0], sg); r[2] = hmul2(r[2], sg); r[1] = hmul2(r[1], sg8); r[3] = hmul2(r[3], sg8);
          uint32_t b0 = 0, b1 = 0;
          const int kk = (ch + u) * 64 + q * 16;
          if (on) { b0 = *(const uint32_t*)(xr + kk); b1 = *(const uint32_t*)(xr + kk + 8); }
          mma_f16(c, r, b0, b1);
        }
      }
  }
}

#ifndef STRIP_INLINE
template <int U>
__device__ __noinline__ float4 strip_nv_n(const uint4* A, const uint2* S, int c0, int c1, const __half* xs, int B, float4 ci) {
  float c[4] = {ci.x, ci.y, ci.z, ci.w};
  strip_nv_i<U>(A, S, c0, c1, xs, B, c);
  return make_float4(c[0], c[1], c[2], c[3]);
}
template <int U>
__device__ __forceinline__ void strip_nv(const uint4* A, const uint2* S, int c0, int c1, const __half* xs, int B, float c[4]) {
  const float4 r = strip_nv_n<U>(A, S, c0, c1, xs, B, make_float4(c[0], c[1], c[2], c[3]));
  c[0] = r.x; c[1] = r.y; c[2] = r.z; c[3] = r.w;
}
#else
template <int U>
__device__ __forceinline__ void strip_nv(const uint4* A, const uint2* S, int c0, int c1, const __half* xs, int B, float c[4]) { strip_nv_i<U>(A, S, c0, c1, xs, B, c); }
#endif

// MXFP8: chunk = 32 k (2 MMAs), scale per (row, chunk) applied after the chunk's MMAs. A: [chunk][32] uint4; S: [chunk][8 g] u16.
template <int U>
__device__ __forceinline__ void strip_mx_i(const uint4* A, const unsigned short* S, int c0, int c1, const __half* xs, int B, float c[4]) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  const __half* xr = xs + g * XS + 2 * t;
  const bool on = g < (unsigned)B;
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    unsigned short s[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) { a[u] = ldw(A + (size_t)(ch + u) * 32 + lane); s[u] = ldw16(S + (size_t)(ch + u) * 8 + g); }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
        float tmp[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
        for (int q = 0; q < 2; q++) {
          uint32_t r[4];
          const uint32_t w0 = (&a[u].x)[2 * q], w1 = (&a[u].x)[2 * q + 1];
          r[0] = e4m3x2((unsigned short)(w0 & 0xffff)); r[1] = e4m3x2((unsigned short)(w0 >> 16));
          r[2] = e4m3x2((unsigned short)(w1 & 0xffff)); r[3] = e4m3x2((unsigned short)(w1 >> 16));
          uint32_t b0 = 0, b1 = 0;
          const int kk = (ch + u) * 32 + q * 16;
          if (on) { b0 = *(const uint32_t*)(xr + kk); b1 = *(const uint32_t*)(xr + kk + 8); }
          mma_f16(tmp, r, b0, b1);
        }
        const float sg = e8m0(s[u] & 0xff), sg8 = e8m0(s[u] >> 8);
        c[0] = fmaf(tmp[0], sg, c[0]); c[1] = fmaf(tmp[1], sg, c[1]);
        c[2] = fmaf(tmp[2], sg8, c[2]); c[3] = fmaf(tmp[3], sg8, c[3]);
      }
  }
}

#ifndef STRIP_INLINE
template <int U>
__device__ __noinline__ float4 strip_mx_n(const uint4* A, const unsigned short* S, int c0, int c1, const __half* xs, int B, float4 ci) {
  float c[4] = {ci.x, ci.y, ci.z, ci.w};
  strip_mx_i<U>(A, S, c0, c1, xs, B, c);
  return make_float4(c[0], c[1], c[2], c[3]);
}
template <int U>
__device__ __forceinline__ void strip_mx(const uint4* A, const unsigned short* S, int c0, int c1, const __half* xs, int B, float c[4]) {
  const float4 r = strip_mx_n<U>(A, S, c0, c1, xs, B, make_float4(c[0], c[1], c[2], c[3]));
  c[0] = r.x; c[1] = r.y; c[2] = r.z; c[3] = r.w;
}
#else
template <int U>
__device__ __forceinline__ void strip_mx(const uint4* A, const unsigned short* S, int c0, int c1, const __half* xs, int B, float c[4]) { strip_mx_i<U>(A, S, c0, c1, xs, B, c); }
#endif


// W2 strips: the B operand (expert activations x 64, f16) comes from global memory per token; all loads of U chunks
// (weights, scales, activations) are issued together.
template <int U>
__device__ __noinline__ float4 strip2_nv(const uint4* A, const uint2* S, int c0, int c1, const __half* ab, int on) {
  const unsigned lane = lane_id(), g = lane >> 2;
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    uint2 sv[U];
    uint32_t bb[U][8];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
        a[u] = ldw(A + (size_t)(ch + u) * 32 + lane);
        sv[u] = ldw2(S + (size_t)(ch + u) * 8 + g);
#pragma unroll
        for (int q = 0; q < 4; q++) {
          const int kk = (ch + u) * 64 + q * 16;
          bb[u][2 * q] = on ? __ldcg((const unsigned*)(ab + kk)) : 0u;
          bb[u][2 * q + 1] = on ? __ldcg((const unsigned*)(ab + kk + 8)) : 0u;
        }
      }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
#pragma unroll
        for (int q = 0; q < 4; q++) {
          uint32_t r[4];
          e2m1x8((&a[u].x)[q], r);
          const uint32_t sp = (q < 2 ? sv[u].x : sv[u].y) >> (16 * (q & 1));
          const uint32_t scv = e4m3x2((unsigned short)(sp & 0xffff));
          const uint32_t sg = lo2(scv), sg8 = hi2(scv);
          r[0] = hmul2(r[0], sg); r[2] = hmul2(r[2], sg); r[1] = hmul2(r[1], sg8); r[3] = hmul2(r[3], sg8);
          mma_f16(c, r, bb[u][2 * q], bb[u][2 * q + 1]);
        }
      }
  }
  return make_float4(c[0], c[1], c[2], c[3]);
}
template <int U>
__device__ __noinline__ float4 strip2_mx(const uint4* A, const unsigned short* S, int c0, int c1, const __half* ab, int on) {
  const unsigned lane = lane_id(), g = lane >> 2;
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    unsigned short sv[U];
    uint32_t bb[U][4];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
        a[u] = ldw(A + (size_t)(ch + u) * 32 + lane);
        sv[u] = ldw16(S + (size_t)(ch + u) * 8 + g);
#pragma unroll
        for (int q = 0; q < 2; q++) {
          const int kk = (ch + u) * 32 + q * 16;
          bb[u][2 * q] = on ? __ldcg((const unsigned*)(ab + kk)) : 0u;
          bb[u][2 * q + 1] = on ? __ldcg((const unsigned*)(ab + kk + 8)) : 0u;
        }
      }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
        float tt[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
        for (int q = 0; q < 2; q++) {
          uint32_t r[4];
          const uint32_t w0 = (&a[u].x)[2 * q], w1 = (&a[u].x)[2 * q + 1];
          r[0] = e4m3x2((unsigned short)(w0 & 0xffff)); r[1] = e4m3x2((unsigned short)(w0 >> 16));
          r[2] = e4m3x2((unsigned short)(w1 & 0xffff)); r[3] = e4m3x2((unsigned short)(w1 >> 16));
          mma_f16(tt, r, bb[u][2 * q], bb[u][2 * q + 1]);
        }
        const float sg = e8m0(sv[u] & 0xff), sg8 = e8m0(sv[u] >> 8);
        c[0] = fmaf(tt[0], sg, c[0]); c[1] = fmaf(tt[1], sg, c[1]);
        c[2] = fmaf(tt[2], sg8, c[2]); c[3] = fmaf(tt[3], sg8, c[3]);
      }
  }
  return make_float4(c[0], c[1], c[2], c[3]);
}


// W2 strips: B operand from a lane-specific shared-memory row (token g's activations of this expert), or zero
template <int U>
__device__ __noinline__ float4 strip_nv_r(const uint4* A, const uint2* S, int c0, int c1, const __half* xr, int on) {
  const unsigned lane = lane_id(), g = lane >> 2;
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    uint2 s[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) { a[u] = ldw(A + (size_t)(ch + u) * 32 + lane); s[u] = ldw2(S + (size_t)(ch + u) * 8 + g); }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
#pragma unroll
        for (int q = 0; q < 4; q++) {
          uint32_t r[4];
          e2m1x8((&a[u].x)[q], r);
          const uint32_t sp = (q < 2 ? s[u].x : s[u].y) >> (16 * (q & 1));
          const uint32_t sc = e4m3x2((unsigned short)(sp & 0xffff));
          const uint32_t sg = lo2(sc), sg8 = hi2(sc);
          r[0] = hmul2(r[0], sg); r[2] = hmul2(r[2], sg); r[1] = hmul2(r[1], sg8); r[3] = hmul2(r[3], sg8);
          uint32_t b0 = 0, b1 = 0;
          const int kk = (ch + u) * 64 + q * 16;
          if (on) { b0 = *(const uint32_t*)(xr + kk); b1 = *(const uint32_t*)(xr + kk + 8); }
          mma_f16(c, r, b0, b1);
        }
      }
  }
  return make_float4(c[0], c[1], c[2], c[3]);
}
template <int U>
__device__ __noinline__ float4 strip_mx_r(const uint4* A, const unsigned short* S, int c0, int c1, const __half* xr, int on) {
  const unsigned lane = lane_id(), g = lane >> 2;
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    unsigned short s[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) { a[u] = ldw(A + (size_t)(ch + u) * 32 + lane); s[u] = ldw16(S + (size_t)(ch + u) * 8 + g); }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
        float tmp[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
        for (int q = 0; q < 2; q++) {
          uint32_t r[4];
          const uint32_t w0 = (&a[u].x)[2 * q], w1 = (&a[u].x)[2 * q + 1];
          r[0] = e4m3x2((unsigned short)(w0 & 0xffff)); r[1] = e4m3x2((unsigned short)(w0 >> 16));
          r[2] = e4m3x2((unsigned short)(w1 & 0xffff)); r[3] = e4m3x2((unsigned short)(w1 >> 16));
          uint32_t b0 = 0, b1 = 0;
          const int kk = (ch + u) * 32 + q * 16;
          if (on) { b0 = *(const uint32_t*)(xr + kk); b1 = *(const uint32_t*)(xr + kk + 8); }
          mma_f16(tmp, r, b0, b1);
        }
        const float sg = e8m0(s[u] & 0xff), sg8 = e8m0(s[u] >> 8);
        c[0] = fmaf(tmp[0], sg, c[0]); c[1] = fmaf(tmp[1], sg, c[1]);
        c[2] = fmaf(tmp[2], sg8, c[2]); c[3] = fmaf(tmp[3], sg8, c[3]);
      }
  }
  return make_float4(c[0], c[1], c[2], c[3]);
}

// Block-level: strips [s0, s1); each has NK k units. fn(strip, k0, k1, c) accumulates; epi(strip, c) consumes the
// final fragment (one warp per strip). Deterministic: the k split of a strip depends only on the strip count.
template <class F, class E>
__device__ __forceinline__ void block_strips(int s0, int s1, int NK, float* red, F fn, E epi) {
  const int n = s1 - s0;
  if (n <= 0) return;
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  if (n >= NW) {
    for (int s = s0 + w; s < s1; s += NW) {
      float c[4] = {0.f, 0.f, 0.f, 0.f};
      fn(s, 0, NK, c);
      epi(s, c);
    }
    return;
  }
  const int ks = NW / n, si = w / ks, kk = w % ks;
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  if (si < n) fn(s0 + si, kk * NK / ks, (kk + 1) * NK / ks, c);
  float4* r4 = (float4*)red;
  r4[w * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
  __syncthreads();
  if (w < n) {
    float4 acc = r4[(w * ks) * 32 + lane];
    for (int j = 1; j < ks; j++) {
      const float4 v = r4[(w * ks + j) * 32 + lane];
      acc.x += v.x; acc.y += v.y; acc.z += v.z; acc.w += v.w;
    }
    float cc[4] = {acc.x, acc.y, acc.z, acc.w};
    epi(s0 + w, cc);
  }
  __syncthreads();
}


// ------------------------------------------------------------------------------------------------ GEMV phases
// One non-inlined call per phase with the strip loops inlined inside: the call overhead is paid once per phase
// and the streaming loop is register-allocated on its own (inlining it into mk_step spilled the streamed tiles;
// one call per strip saved ~80 registers per call through local memory).
__device__ __noinline__ void gemv_qkv(const LayerW& L, const bf16* sIn, int nin, int B, int s0, int s1, float* qkv, float* red) {
  const int lane = threadIdx.x & 31;
  const int kst = (int)L.koff / 16, vst = (int)L.voff / 16;
  block_strips(s0, s1, 144, red,
    [&](int s, int k0, int k1, float c[4]) {
      const bf16* xs = sIn + (nin == 3 ? (s >= vst ? 2 : (s >= kst ? 1 : 0)) : 0) * B * XS;
      strip_bf16_i<8>(L.wqkv + (size_t)s * 144 * 32, k0, k1, xs, B, c);
    },
    [&](int s, float c[4]) {
      const unsigned g = lane >> 2, t = lane & 3;
      for (int h2 = 0; h2 < 2; h2++) {
        const int b = 2 * t + h2;
        if (b < B) { qkv[(size_t)b * 8704 + s * 16 + g] = c[h2]; qkv[(size_t)b * 8704 + s * 16 + g + 8] = c[2 + h2]; }
      }
    });
}
__device__ __forceinline__ unsigned long long amax_key(float v, int idx) {
  unsigned u = __float_as_uint(v);
  u = (u & 0x80000000u) ? ~u : (u | 0x80000000u);
  return ((unsigned long long)u << 32) | (unsigned long long)(0xffffffffu - (unsigned)idx);
}

// Unembedding strips, 4 at a time: warp w computes K segment (w & 3) of strip (w >> 2) of the group; the 4 partials
// are summed in a fixed order. The exact head and the sketch's rescoring both use this, so the rescored logits are
// bit for bit those of the exact head.
template <class E>
__device__ __forceinline__ void head_group(const uint4* W, const bf16* hs, int B, const int* strips, int cnt, float* red, E epi) {
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  const int si = w >> 2, seg = w & 3;
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  if (si < cnt) strip_bf16_i<12>(W + (size_t)strips[si] * 144 * 32, seg * 36, seg * 36 + 36, hs, B, c);
  float4* r4 = (float4*)red;
  r4[w * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
  __syncthreads();
  if (w < cnt) {
    float4 acc = r4[(w * 4) * 32 + lane];
    for (int j = 1; j < 4; j++) {
      const float4 v = r4[(w * 4 + j) * 32 + lane];
      acc.x += v.x; acc.y += v.y; acc.z += v.z; acc.w += v.w;
    }
    float cc[4] = {acc.x, acc.y, acc.z, acc.w};
    epi(strips[w], cc);
  }
  __syncthreads();
}
__device__ __forceinline__ void head_epi(int s, const float c[4], int B, float* logits, unsigned long long* skey) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  for (int h2 = 0; h2 < 2; h2++) {
    const int b = 2 * t + h2;
    const int r0 = s * 16 + g, r1 = s * 16 + g + 8;
    const float v0 = 30.f * tanhf(c[h2] * (1.f / 30.f)), v1 = 30.f * tanhf(c[2 + h2] * (1.f / 30.f));
    if (b < B && logits) {
      if (r0 < VOCAB) logits[(size_t)b * VOCAB + r0] = v0;
      if (r1 < VOCAB) logits[(size_t)b * VOCAB + r1] = v1;
    }
    if (skey) {
      unsigned long long k = 0;
      if (b < B && r0 < VOCAB) k = amax_key(v0, r0);
      if (b < B && r1 < VOCAB) { const unsigned long long k1 = amax_key(v1, r1); k = k1 > k ? k1 : k; }
      for (int o = 4; o < 32; o <<= 1) { const unsigned long long ok = __shfl_xor_sync(0xffffffffu, k, o); k = ok > k ? ok : k; }
      if (g == 0 && b < B) atomicMax(skey + b, k);
    }
  }
}
__device__ __noinline__ void gemv_head(const uint4* W, const bf16* hs, int B, int s0, int s1, float* logits, float* red,
                                       unsigned long long* skey) {
  const int w = threadIdx.x >> 5;
  // s1 - s0 >= 16 here (12504 strips over <= 152 blocks): every warp computes whole strips, k = 0..143 in order
  for (int s = s0 + w; s < s1; s += NW) {
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    strip_bf16_i<8>(W + (size_t)s * 144 * 32, 0, 144, hs, B, c);
    head_epi(s, c, B, logits, skey);
  }
  (void)red;
}
__device__ __noinline__ void gemv_w13(const LayerW& L, const __half* x16, int B, int s0, int s1, const int* uni, const int* uslot,
                                      const float* xsc, const float* selw, __half* act, float* red) {
  const int lane = threadIdx.x & 31;
  const bool mx = L.mx != 0;
  const size_t cstride = mx ? (size_t)144 * 72 * 512 : (size_t)144 * 36 * 512;
  const size_t sstride = mx ? (size_t)144 * 72 * 16 : (size_t)144 * 36 * 64;
  block_strips(s0, s1, mx ? 72 : 36, red,
    [&](int s, int k0, int k1, float c[4]) {
      const int u = s / 144, st = s % 144, e = uni[u];
      if (mx) {
        const uint4* A = (const uint4*)(L.w13 + e * cstride) + (size_t)st * 72 * 32;
        const unsigned short* S = (const unsigned short*)(L.w13s + e * sstride) + (size_t)st * 72 * 8;
        strip_mx_i<4>(A, S, k0, k1, x16, B, c);
      } else {
        const uint4* A = (const uint4*)(L.w13 + e * cstride) + (size_t)st * 36 * 32;
        const uint2* S = (const uint2*)(L.w13s + e * sstride) + (size_t)st * 36 * 8;
        strip_nv_i<4>(A, S, k0, k1, x16, B, c);
      }
    },
    [&](int s, float c[4]) {
      const int u = s / 144, st = s % 144, e = uni[u];
      const unsigned g = lane >> 2, t = lane & 3;
      const float fe = mx ? 1.f : L.f13[e];
      for (int h2 = 0; h2 < 2; h2++) {
        const int b = 2 * t + h2;
        if (b < B) {
          const int sl = uslot[u * 8 + b];
          if (sl >= 0) {
            const float gg = c[h2] * xsc[b] * fe, uu = c[2 + h2] * xsc[b] * fe;
            float a2 = 4.f * tanhf(gg * 0.25f) * sigm(gg) * (25.f * tanhf(uu * 0.04f));
            a2 = rbf(a2 * selw[b * 8 + sl]);
            act[((size_t)b * 8 + sl) * IM + st * 8 + g] = __float2half_rn(a2 * 64.f);
          }
        }
      }
    });
}


// ------------------------------------------------------------------------------------------------ sketch head (track B)
#define XDS (2 * H + 16)   // byte stride of a token's input digits (16-byte pad: token rows on different banks)
// 8-bit codes q + 128 in the bf16 tile element order (8 bytes per lane per 16x16 tile), decoded exactly to f16 by
// byte permute (0x64xx = 1024 + byte) and one f16x2 subtraction of 1152.
__device__ __forceinline__ uint32_t hsub2u(uint32_t a, uint32_t b) {
  uint32_t r;
  asm("sub.rn.f16x2 %0, %1, %2;" : "=r"(r) : "r"(a), "r"(b));
  return r;
}
__device__ __forceinline__ void mma_s8(int c[4], const uint4& a, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+r"(c[0]), "+r"(c[1]), "+r"(c[2]), "+r"(c[3]) : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b0), "r"(b1));
}
// int8 codes x two int8 digits of the input (hi, lo: X = 128 hi + lo): exact int32 sums
template <int U>
__device__ __forceinline__ void strip_s8_i(const uint4* A, int k0, int k1, const int8_t* xd, int B, int ch[4], int cl[4]) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  const int8_t* xh = xd + g * XDS + 4 * t;     // [token][hi 2304 | lo 2304 | pad]
  const bool on = g < (unsigned)B;
  for (int k = k0; k < k1; k += U) {
    uint4 a[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (k + u < k1) a[u] = ldw(A + (size_t)(k + u) * 32 + lane);
#pragma unroll
    for (int u = 0; u < U; u++)
      if (k + u < k1) {
        uint32_t h0 = 0, h1 = 0, l0 = 0, l1 = 0;
        if (on) {
          const int kk = (k + u) * 32;
          h0 = *(const uint32_t*)(xh + kk); h1 = *(const uint32_t*)(xh + kk + 16);
          l0 = *(const uint32_t*)(xh + H + kk); l1 = *(const uint32_t*)(xh + H + kk + 16);
        }
        mma_s8(ch, a[u], h0, h1);
        mma_s8(cl, a[u], l0, l1);
      }
  }
}
__device__ __forceinline__ unsigned okey32(float v) {
  const unsigned u = __float_as_uint(v);
  return (u & 0x80000000u) ? ~u : (u | 0x80000000u);
}
__device__ __forceinline__ float okey32_inv(unsigned k) {
  return __uint_as_float((k & 0x80000000u) ? (k & 0x7fffffffu) : ~k);
}
// pass 1: sketch logits -> upper bounds stored, best lower bound per token (block max in slo)
__device__ __noinline__ void sketch_pass1(const Params& P, const int8_t* xd, const float* xsc, const float* xn, const float* dxn,
                                          int B, int s0, int s1, float* red, unsigned* slo) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const int n = s1 - s0;   // >= 16 strips per block: whole strips per warp
  for (int s = s0 + w; s < s1; s += NW) {
    int ch[4] = {0, 0, 0, 0}, cl[4] = {0, 0, 0, 0};
    strip_s8_i<8>(P.skq + (size_t)s * 72 * 32, 0, 72, xd, B, ch, cl);
    const unsigned g = lane >> 2, t = lane & 3;
    for (int h2 = 0; h2 < 2; h2++) {
      const int b = 2 * t + h2;
      unsigned best = 0;
      if (b < B) {
        for (int rr = 0; rr < 2; rr++) {
          const int r = s * 16 + g + 8 * rr;
          if (r < VOCAB) {
            const int i = h2 + 2 * rr;
            const float acc = fmaf(128.f, (float)ch[i], (float)cl[i]);
            const float a = acc * __ldg(P.sks + r) * xsc[b];
            const float bnd = fmaf(__ldg(P.skc + r), xn[b], __ldg(P.skn + r) * dxn[b]);
            P.skab[(size_t)b * (VSTRIPS * 16) + r] = a + bnd;
            const unsigned k = okey32(a - bnd);
            best = k > best ? k : best;
          }
        }
      }
      for (int o = 4; o < 32; o <<= 1) { const unsigned ok = __shfl_xor_sync(0xffffffffu, best, o); best = ok > best ? ok : best; }
      if (g == 0 && b < B) atomicMax(slo + b, best);
    }
  }
  (void)n; (void)red;
}
// pass 2: exact rescoring (the exact head's own strip arithmetic) of every strip whose upper bound reaches the best
// lower bound of some token (minus a margin), argmax keys of the exact soft-capped logits
__device__ __noinline__ void sketch_pass2(const Params& P, const bf16* hs, int B, int s0, int s1, unsigned long long* skey,
                                          float* red) {
  __shared__ int flags[128];
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31;
  const int n = s1 - s0;
  float lo[MAXB];
#pragma unroll
  for (int b = 0; b < MAXB; b++) lo[b] = b < B ? okey32_inv(__ldcg(P.sklo + b)) - 0.05f : 0.f;
  for (int i = tid; i < n; i += NT) flags[i] = 0;
  __syncthreads();
  // candidate strips: warp per strip, lanes over (row, token pair)
  for (int si = w; si < n; si += NW) {
    const int r = (s0 + si) * 16 + (lane & 15);
    bool hit = false;
    for (int b = lane >> 4; b < B; b += 2)
      hit |= r < VOCAB && __ldcg(P.skab + (size_t)b * (VSTRIPS * 16) + r) >= lo[b];
    const bool any = __any_sync(0xffffffffu, hit);
    if (lane == 0) flags[si] = any;
  }
  __syncthreads();
  // compaction by ballots (n <= 96 strips: warps 0-2)
  __shared__ int wcnt[3];
  __shared__ int clist[96];
  bool f = false;
  unsigned bal = 0;
  if (w < 3) {
    f = (w * 32 + lane) < n && flags[w * 32 + lane];
    bal = __ballot_sync(0xffffffffu, f);
    if (lane == 0) wcnt[w] = __popc(bal);
  }
  __syncthreads();
  if (w < 3 && f) {
    int pos = __popc(bal & ((1u << lane) - 1));
    for (int ww = 0; ww < w; ww++) pos += wcnt[ww];
    clist[pos] = s0 + w * 32 + lane;
  }
  if (tid == 0) flags[127] = wcnt[0] + wcnt[1] + wcnt[2];
  __syncthreads();
  const int m = flags[127];
  for (int i = w; i < m; i += NW) {
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    strip_bf16_i<24>(P.unemb + (size_t)clist[i] * 144 * 32, 0, 144, hs, B, c);   // same MMA order as the exact head
    head_epi(clist[i], c, B, nullptr, skey);
  }
  (void)red;
}

// ------------------------------------------------------------------------------------------------ vector machinery
// Token vectors are processed in 8-element chunks: 288 per token = 9 warps of 32 chunks (a warp never spans two
// tokens). A source of the attention residuals is a bf16 vector per token (global write-once / global rewritten (.cg)
// / shared), optionally plus a second one (partial + attention output of the MoE input, summed in fp32).
#define NC8 288
#define NWT8 9

struct Src {
  const bf16* p;
  const bf16* q;
  int stride, qstride;
  int mode, qmode;    // 0 global (write-once in this launch), 1 global rewritten (.cg), 2 shared
};
__device__ __forceinline__ Src mksrc(const bf16* p, int stride, int mode) { return Src{p, nullptr, stride, 0, mode, 0}; }
__device__ __forceinline__ void unpack4(uint2 r, float v[4]) {
  v[0] = __uint_as_float(r.x << 16); v[1] = __uint_as_float(r.x & 0xffff0000u);
  v[2] = __uint_as_float(r.y << 16); v[3] = __uint_as_float(r.y & 0xffff0000u);
}
__device__ __forceinline__ void unpack8(const uint4& r, float v[8]) {
  v[0] = __uint_as_float(r.x << 16); v[1] = __uint_as_float(r.x & 0xffff0000u);
  v[2] = __uint_as_float(r.y << 16); v[3] = __uint_as_float(r.y & 0xffff0000u);
  v[4] = __uint_as_float(r.z << 16); v[5] = __uint_as_float(r.z & 0xffff0000u);
  v[6] = __uint_as_float(r.w << 16); v[7] = __uint_as_float(r.w & 0xffff0000u);
}
__device__ __forceinline__ float el8(const uint4& r, int e) {
  const uint32_t wv = e < 2 ? r.x : (e < 4 ? r.y : (e < 6 ? r.z : r.w));
  return (e & 1) ? __uint_as_float(wv & 0xffff0000u) : __uint_as_float(wv << 16);
}
__device__ __forceinline__ uint2 pack4(const float v[4]) {
  __nv_bfloat162 a = __floats2bfloat162_rn(v[0], v[1]), b = __floats2bfloat162_rn(v[2], v[3]);
  return make_uint2(*(uint32_t*)&a, *(uint32_t*)&b);
}
__device__ __forceinline__ uint4 pack8(const float v[8]) {
  const uint2 a = pack4(v), b = pack4(v + 4);
  return make_uint4(a.x, a.y, b.x, b.y);
}
__device__ __forceinline__ uint4 ld8raw(const bf16* p, int mode) {
  return mode == 1 ? __ldcg((const uint4*)p) : *(const uint4*)p;
}
__device__ __forceinline__ void ld8f(const Src& s, int b, int c, float v[8]) {
  unpack8(ld8raw(s.p + (size_t)b * s.stride + 8 * c, s.mode), v);
  if (s.q) {
    float u[8];
    unpack8(ld8raw(s.q + (size_t)b * s.qstride + 8 * c, s.qmode), u);
#pragma unroll
    for (int i = 0; i < 8; i++) v[i] += u[i];
  }
}
__device__ __forceinline__ void ldq8(const float* q, int c, float v[8]) {
  const float4 a = __ldg((const float4*)(q + 8 * c)), b = __ldg((const float4*)(q + 8 * c + 4));
  v[0] = a.x; v[1] = a.y; v[2] = a.z; v[3] = a.w; v[4] = b.x; v[5] = b.y; v[6] = b.z; v[7] = b.w;
}
__device__ __forceinline__ void ldw8(const bf16* w, int c, float v[8]) { unpack8(__ldg((const uint4*)(w + 8 * c)), v); }

// transpose reduction: v[32] per lane -> lane l returns the warp's sum of v[l] (31 shuffles)
__device__ __forceinline__ float selp(bool c, float a, float b) {   // c ? a : b, never a branch
  float r;
  asm("{\n.reg .pred p;\nsetp.ne.u32 p, %3, 0;\nselp.f32 %0, %1, %2, p;\n}" : "=f"(r) : "f"(a), "f"(b), "r"((unsigned)c));
  return r;
}
__device__ __forceinline__ float xred32(float* v) {
  const unsigned lane = lane_id();
#pragma unroll
  for (int h = 16; h >= 1; h >>= 1) {
    const bool up = (lane & h) != 0;
#pragma unroll
    for (int i = 0; i < h; i++) {
      const float send = selp(up, v[i], v[i + h]);
      const float keep = selp(up, v[i + h], v[i]);
      v[i] = keep + __shfl_xor_sync(0xffffffffu, send, h);
    }
  }
  return v[0];
}

// dot products per token, slots: group 1: G(i,j) = 5i+j (i<=j<5), MG = 25 (00), 26 (01), 27 (11);
// group 2 (+32): SQ(i,j) = 3i+j, MQ(i,j) = 15+3i+j. The last S source may carry an addend (unpacked).
struct DotSet {
  int nv, nq, nm, nmq;
  Src S[5];
  Src M[2];
  const float* q[3];
  const float* mq[3];
};
__device__ __noinline__ void dot_pass(const DotSet& d, int B, float* part, float* out) {
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int ntask = B * NWT8;
  for (int base = 0; base < ntask; base += NW) {      // uniform trip count: shuffles stay in converged code
    const int task = base + w;
    const bool act = task < ntask;
    const int b = act ? task / NWT8 : 0, wt = task % NWT8, c = act ? wt * 32 + lane : 0;
    uint4 pv[4], pm[2];
    float o[8];
#pragma unroll
    for (int i = 0; i < 4; i++) if (i < d.nv - 1) pv[i] = ld8raw(d.S[i].p + (size_t)b * d.S[i].stride + 8 * c, d.S[i].mode);
#pragma unroll
    for (int i = 0; i < 2; i++) if (i < d.nm) pm[i] = ld8raw(d.M[i].p + (size_t)b * d.M[i].stride + 8 * c, d.M[i].mode);
    ld8f(d.S[d.nv - 1], b, c, o);
    const int last = d.nv - 1;
    float acc[32];
#pragma unroll
    for (int i = 0; i < 32; i++) acc[i] = 0.f;
#pragma unroll
    for (int e = 0; e < 8; e++) {
      float v[5];
#pragma unroll
      for (int i = 0; i < 5; i++) v[i] = i < last ? el8(pv[i < 4 ? i : 3], e) : (i == last ? o[e] : 0.f);
#pragma unroll
      for (int i = 0; i < 5; i++)
#pragma unroll
        for (int j = i; j < 5; j++) if (j < d.nv) acc[5 * i + j] = fmaf(v[i], v[j], acc[5 * i + j]);
      if (d.nm) {
        const float m0 = el8(pm[0], e), m1 = el8(pm[1], e);
        acc[25] = fmaf(m0, m0, acc[25]); acc[26] = fmaf(m0, m1, acc[26]); acc[27] = fmaf(m1, m1, acc[27]);
      }
    }
    float r = xred32(acc);
    if (act) part[(b * NWT8 + wt) * 64 + lane] = r;
#pragma unroll
    for (int i = 0; i < 32; i++) acc[i] = 0.f;
#pragma unroll
    for (int j = 0; j < 3; j++)
      if (j < d.nq) {
        float qq[8];
        ldq8(d.q[j], c, qq);
#pragma unroll
        for (int e = 0; e < 8; e++)
#pragma unroll
          for (int i = 0; i < 5; i++)
            if (i < d.nv) acc[3 * i + j] = fmaf(i < last ? el8(pv[i < 4 ? i : 3], e) : o[e], qq[e], acc[3 * i + j]);
      }
#pragma unroll
    for (int j = 0; j < 3; j++)
      if (j < d.nmq) {
        float qq[8];
        ldq8(d.mq[j], c, qq);
#pragma unroll
        for (int e = 0; e < 8; e++) {
          acc[15 + j] = fmaf(el8(pm[0], e), qq[e], acc[15 + j]);
          acc[18 + j] = fmaf(el8(pm[1], e), qq[e], acc[18 + j]);
        }
      }
    r = xred32(acc);
    if (act) part[(b * NWT8 + wt) * 64 + 32 + lane] = r;
  }
  __syncthreads();
  for (int i = tid; i < B * 64; i += NT) {
    const int b = i / 64, s = i % 64;
    float r = 0.f;
    for (int k = 0; k < NWT8; k++) r += part[(b * NWT8 + k) * 64 + s];
    out[b * 64 + s] = r;
  }
  __syncthreads();
}
__device__ __forceinline__ void dot_pass_t(const DotSet& d, int B, float* part, float* out, long long* ts) {
  long long c0 = clock64();
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int ntask = B * NWT8;
  for (int base = 0; base < ntask; base += NW) {      // uniform trip count: shuffles stay in converged code
    const int task = base + w;
    const bool act = task < ntask;
    const int b = act ? task / NWT8 : 0, wt = task % NWT8, c = act ? wt * 32 + lane : 0;
    uint4 pv[4], pm[2];
    float o[8];
#pragma unroll
    for (int i = 0; i < 4; i++) if (i < d.nv - 1) pv[i] = ld8raw(d.S[i].p + (size_t)b * d.S[i].stride + 8 * c, d.S[i].mode);
#pragma unroll
    for (int i = 0; i < 2; i++) if (i < d.nm) pm[i] = ld8raw(d.M[i].p + (size_t)b * d.M[i].stride + 8 * c, d.M[i].mode);
    ld8f(d.S[d.nv - 1], b, c, o);
    const int last = d.nv - 1;
    float acc[32];
#pragma unroll
    for (int i = 0; i < 32; i++) acc[i] = 0.f;
#pragma unroll
    for (int e = 0; e < 8; e++) {
      float v[5];
#pragma unroll
      for (int i = 0; i < 5; i++) v[i] = i < last ? el8(pv[i < 4 ? i : 3], e) : (i == last ? o[e] : 0.f);
#pragma unroll
      for (int i = 0; i < 5; i++)
#pragma unroll
        for (int j = i; j < 5; j++) if (j < d.nv) acc[5 * i + j] = fmaf(v[i], v[j], acc[5 * i + j]);
      if (d.nm) {
        const float m0 = el8(pm[0], e), m1 = el8(pm[1], e);
        acc[25] = fmaf(m0, m0, acc[25]); acc[26] = fmaf(m0, m1, acc[26]); acc[27] = fmaf(m1, m1, acc[27]);
      }
    }
    long long c1 = clock64();
    float r = xred32(acc);
    if (act) part[(b * NWT8 + wt) * 64 + lane] = r;
    long long c2 = clock64();
    if (lane == 0 && ts) { ts[0] += c1 - c0; ts[1] += c2 - c1; }
#pragma unroll
    for (int i = 0; i < 32; i++) acc[i] = 0.f;
#pragma unroll
    for (int j = 0; j < 3; j++)
      if (j < d.nq) {
        float qq[8];
        ldq8(d.q[j], c, qq);
#pragma unroll
        for (int e = 0; e < 8; e++)
#pragma unroll
          for (int i = 0; i < 5; i++)
            if (i < d.nv) acc[3 * i + j] = fmaf(i < last ? el8(pv[i < 4 ? i : 3], e) : o[e], qq[e], acc[3 * i + j]);
      }
#pragma unroll
    for (int j = 0; j < 3; j++)
      if (j < d.nmq) {
        float qq[8];
        ldq8(d.mq[j], c, qq);
#pragma unroll
        for (int e = 0; e < 8; e++) {
          acc[15 + j] = fmaf(el8(pm[0], e), qq[e], acc[15 + j]);
          acc[18 + j] = fmaf(el8(pm[1], e), qq[e], acc[18 + j]);
        }
      }
    r = xred32(acc);
    if (act) part[(b * NWT8 + wt) * 64 + 32 + lane] = r;
  }
  long long c3 = clock64();
  __syncthreads();
  long long c4 = clock64();
  if (tid == 0 && ts) { ts[2] += c3 - c0; ts[3] += c4 - c3; }
  for (int i = tid; i < B * 64; i += NT) {
    const int b = i / 64, s = i % 64;
    float r = 0.f;
    for (int k = 0; k < NWT8; k++) r += part[(b * NWT8 + k) * 64 + s];
    out[b * 64 + s] = r;
  }
  __syncthreads();
  if (tid == 0 && ts) ts[4] += clock64() - c4;
}
// softmax-over-depth coefficients of stream j from the dots: c[i] = p_i * ir_i, c[7] = 1/rms of the mixed stream.
// raw: the stream is S[0] itself (layer 0).
__device__ __noinline__ void coefs(const float* o, int n, int j, bool msg, bool raw, float* c) {
  auto G = [&](int i, int k) {
    const int a = i < k ? i : k, bb = i < k ? k : i;
    return msg ? o[25 + a + bb] : o[5 * a + bb];
  };
  auto Q = [&](int i) { return msg ? o[32 + 15 + 3 * i + j] : o[32 + 3 * i + j]; };
  for (int i = 0; i < 8; i++) c[i] = 0.f;
  float ssq;
  if (raw) { c[0] = 1.f; ssq = G(0, 0); }
  else {
    float ir[5], lg[5], mx = -1e30f;
    for (int i = 0; i < n; i++) { ir[i] = rsqrtf(G(i, i) / H + 1e-6f); lg[i] = Q(i) * ir[i] * (1.f / 48.f); mx = fmaxf(mx, lg[i]); }
    float den = 0.f;
    for (int i = 0; i < n; i++) { lg[i] = __expf(lg[i] - mx); den += lg[i]; }
    for (int i = 0; i < n; i++) c[i] = lg[i] / den * ir[i];
    ssq = 0.f;
    for (int i = 0; i < n; i++)
      for (int k = 0; k < n; k++) ssq = fmaf(c[i] * c[k], G(i, k), ssq);
  }
  c[7] = rsqrtf(ssq / H + 1e-6f);
}
// x[8] = sum_i c_i S_i (chunk c of token b)
__device__ __forceinline__ void mix8(const Src* S, int n, const float* cf, int b, int c, float x[8]) {
#pragma unroll
  for (int e = 0; e < 8; e++) x[e] = 0.f;
#pragma unroll
  for (int i = 0; i < 5; i++)
    if (i < n) {
      float v[8];
      ld8f(S[i], b, c, v);
#pragma unroll
      for (int e = 0; e < 8; e++) x[e] = fmaf(cf[i], v[e], x[e]);
    }
}
// scalar element k of the mix
__device__ __forceinline__ float ldsrc1(const Src& s, int b, int k) {
  const bf16* p = s.p + (size_t)b * s.stride + k;
  float v = s.mode == 1 ? ldbf(p) : bf(*p);
  if (s.q) { const bf16* q = s.q + (size_t)b * s.qstride + k; v += s.qmode == 1 ? ldbf(q) : bf(*q); }
  return v;
}
__device__ __forceinline__ float mix1(const Src* S, int n, const float* cf, int b, int k) {
  float x = 0.f;
#pragma unroll
  for (int i = 0; i < 5; i++) if (i < n) x = fmaf(cf[i], ldsrc1(S[i], b, k), x);
  return x;
}
// x' = (1 - tanh(F g)) x + tanh(G g) m for one element: a warp computes 32 consecutive elements; lanes split the
// 64-dots of F/G rows (row r of a gate: 64 bf16 = 128 B; lane l reads 4 B of 32 rows... simpler: each lane one row)
__device__ __forceinline__ float gate1(const bf16* Fr, const bf16* Gr, const float* gv, float x, float m) {
  float f = 0.f, gg = 0.f;
#pragma unroll
  for (int r = 0; r < 8; r++) {
    const uint4 fv = __ldg((const uint4*)Fr + r), gw = __ldg((const uint4*)Gr + r);
    const uint32_t fa[4] = {fv.x, fv.y, fv.z, fv.w}, ga[4] = {gw.x, gw.y, gw.z, gw.w};
#pragma unroll
    for (int q = 0; q < 4; q++) {
      f = fmaf(__uint_as_float(fa[q] << 16), gv[8 * r + 2 * q], f);
      f = fmaf(__uint_as_float(fa[q] & 0xffff0000u), gv[8 * r + 2 * q + 1], f);
      gg = fmaf(__uint_as_float(ga[q] << 16), gv[8 * r + 2 * q], gg);
      gg = fmaf(__uint_as_float(ga[q] & 0xffff0000u), gv[8 * r + 2 * q + 1], gg);
    }
  }
  return (1.f - tanhf(f)) * x + tanhf(gg) * m;
}


// ------------------------------------------------------------------------------------------------ epilogue dots
// The W2 epilogue (16 rows of the MoE output per strip) finalizes the next entering partial X for its rows and
// accumulates the next mix's dot products; the O-projection epilogue does the same for the attention conv and the
// MoE-input mix. Partials: [144 strips][MAXB][40] in a compact slot order, reduced by the consumer.
// compact slots: G(i,j) (i<=j<5) 0..14, MG 15..17, SQ(i,j) 18+3i+j, MQ(i,j) 33+3i+j (i<2, j<3)
#define NPS 40
__device__ __forceinline__ int cg_idx(int i, int j) { return i * 5 - (i * (i - 1)) / 2 + (j - i); }
struct EpiDesc {
  int nblk;                   // block sources (global bf16 [MAXB][H] each)
  const bf16* blkp[4];
  int two;                    // MoE at a boundary: S = blocks + [X, attn]; else the last source is X (+ attn)
  int nq;
  const float* q[3];
  int nm, m1F, nmq;           // messages: m0, m1 (m1F: m1 is the freshly finalized vector)
  const bf16* m0;
  const bf16* m1;
  const float* mq[3];
  int restart, bi, fi;        // H epilogue: next app restarts from P5 (F -> blk[fi]); X_next -> blk[bi]
};
// per-element products of S = [bv[0..nblk), last0 (, last1)], queries q, messages
__device__ __forceinline__ void epi_acc(const EpiDesc& D, float acc[NPS], const float* bv, float l0, float l1, const float* qv,
                                        float m0, float m1, const float* mqv) {
  float v[5];
  const int nv = D.nblk + 1 + D.two;
#pragma unroll
  for (int i = 0; i < 5; i++) v[i] = i < D.nblk ? bv[i < 4 ? i : 3] : (i == D.nblk ? l0 : l1);
#pragma unroll
  for (int i = 0; i < 5; i++)
#pragma unroll
    for (int j = i; j < 5; j++) if (j < nv) acc[cg_idx(i, j)] = fmaf(v[i], v[j], acc[cg_idx(i, j)]);
#pragma unroll
  for (int j = 0; j < 3; j++)
    if (j < D.nq)
#pragma unroll
      for (int i = 0; i < 5; i++) if (i < nv) acc[18 + 3 * i + j] = fmaf(v[i], qv[j], acc[18 + 3 * i + j]);
  if (D.nm) {
    acc[15] = fmaf(m0, m0, acc[15]); acc[16] = fmaf(m0, m1, acc[16]); acc[17] = fmaf(m1, m1, acc[17]);
#pragma unroll
    for (int j = 0; j < 3; j++)
      if (j < D.nmq) { acc[33 + j] = fmaf(m0, mqv[j], acc[33 + j]); acc[36 + j] = fmaf(m1, mqv[j], acc[36 + j]); }
  }
}
// reduce acc[40] over the 8 lanes sharing t (lanes t, t+4, ..): lane g ends with slots [5g, 5g+5)
__device__ __forceinline__ void xred8(float* v) {
  const unsigned lane = lane_id();
#pragma unroll
  for (int h = 20, sh = 16; h >= 5; h >>= 1, sh >>= 1) {
    const bool up = (lane & sh) != 0;
#pragma unroll
    for (int i = 0; i < h; i++) {
      const float send = selp(up, v[i], v[i + h]);
      const float keep = selp(up, v[i + h], v[i]);
      v[i] = keep + __shfl_xor_sync(0xffffffffu, send, sh);
    }
  }
}
__device__ __forceinline__ void epi_load(const EpiDesc& D, int b, int r, float* bv, float* qv, float& m0, float& m1, float* mqv) {
#pragma unroll
  for (int i = 0; i < 4; i++) bv[i] = i < D.nblk ? bf(D.blkp[i][(size_t)b * H + r]) : 0.f;
#pragma unroll
  for (int j = 0; j < 3; j++) qv[j] = j < D.nq ? __ldg(D.q[j] + r) : 0.f;
  m0 = m1 = 0.f;
  if (D.nm) {
    m0 = bf(D.m0[(size_t)b * H + r]);
    if (!D.m1F) m1 = bf(D.m1[(size_t)b * H + r]);
  }
#pragma unroll
  for (int j = 0; j < 3; j++) mqv[j] = j < D.nmq ? __ldg(D.mq[j] + r) : 0.f;
}
__device__ long long RP_PROF_BUF[8];
#define RP_PROF RP_PROF_BUF
// consumer: out[b*64 + DotSet slot] = sum over the 144 strips (fixed order). Only the slots the mix needs
// (nv sources, nq queries, messages): pairs (token, slot) x TP threads, each summing 144/TP strips; red: smem scratch.
__device__ __forceinline__ int dot_slot(int k) {
  if (k < 15) { int i = 0; while (k >= cg_idx(i, 4) + 1) i++; return 5 * i + (k - cg_idx(i, i)) + i; }
  if (k < 18) return 25 + (k - 15);
  if (k < 33) return 32 + (k - 18);
  return 32 + 15 + (k - 33);
}
__device__ __noinline__ void reduce_parts(const float* part, int B, int nv, int nq, int nm, int nmq, float* out, float* red) {
  const int tid = threadIdx.x;
  long long T0 = clock64();
  __shared__ int klist[NPS];
  __shared__ int nk_s;
  if (tid == 0) {
    int n = 0;
    for (int i = 0; i < 5; i++) for (int j = i; j < nv; j++) klist[n++] = cg_idx(i, j);
    if (nm) { klist[n++] = 15; klist[n++] = 16; klist[n++] = 17; }
    for (int i = 0; i < nv; i++) for (int j = 0; j < nq; j++) klist[n++] = 18 + 3 * i + j;
    for (int i = 0; i < (nm ? 2 : 0); i++) for (int j = 0; j < nmq; j++) klist[n++] = 33 + 3 * i + j;
    nk_s = n;
  }
  __syncthreads();
  long long T1 = clock64();
  const int nk = nk_s, pairs = B * nk;
  int tp = 1;
  const int cand[9] = {16, 12, 9, 8, 6, 4, 3, 2, 1};
  for (int i = 0; i < 9; i++) if (cand[i] * pairs <= NT) { tp = cand[i]; break; }
  const int per = 144 / tp;
  const int pi = tid / tp, sub = tid % tp;
  if (pi < pairs) {
    const int b = pi / nk, k = klist[pi % nk];
    const float* src = part + (size_t)b * NPS + k + (size_t)sub * per * MAXB * NPS;
    float acc = 0.f;
    for (int st = 0; st < per; st += 9) {        // per is 9, 12, 16, 18, 24, ... 144: batches of up to 9 loads
      float v[9];
#pragma unroll
      for (int u = 0; u < 9; u++) v[u] = (st + u < per) ? __ldcg(src + (size_t)(st + u) * MAXB * NPS) : 0.f;
#pragma unroll
      for (int u = 0; u < 9; u++) acc += v[u];
    }
    red[tid] = acc;
  }
  long long T2 = clock64();
  __syncthreads();
  long long T3 = clock64();
  if (tid < pairs) {
    float s = 0.f;
    for (int j = 0; j < tp; j++) s += red[tid * tp + j];
    const int b = tid / nk, k = klist[tid % nk];
    out[b * 64 + dot_slot(k)] = s;
  }
  __syncthreads();
  if (RP_PROF && tid == 0 && blockIdx.x == 0) { RP_PROF[0] += T1 - T0; RP_PROF[1] += T2 - T1; RP_PROF[2] += T3 - T2; RP_PROF[3] += clock64() - T3; RP_PROF[4] += 1; }
}

// ------------------------------------------------------------------------------------------------ application table
struct App { int layer, pass, slot; };
__device__ __forceinline__ App app_of(int a) {
  App r;
  if (a < 6) { r.layer = a; r.pass = 0; r.slot = a; }
  else if (a < 42) { r.pass = (a - 6) / 12; r.layer = 6 + (a - 6) % 12; r.slot = r.pass == 0 ? r.layer : 24 + (r.pass - 1) * 12 + (r.layer - 6); }
  else { r.layer = a - 24; r.pass = 0; r.slot = r.layer; }
  return r;
}
__device__ __forceinline__ bool boundary(int layer) { return layer % 6 == 0; }

__device__ int attn_blk_idx(int layer, int pass, int* idx) {
  int n = 0;
  if (layer > 0) idx[n++] = 0;
  if (layer > 6) idx[n++] = 1;
  if (layer > 12) idx[n++] = layer >= 18 ? 4 : 2 + pass;
  if (layer > 18) idx[n++] = 7;
  return n;
}
// block-state sources visible to the attention input of a layer (pass p): h0 (i>0), P5 (i>6), P11_p (i>12), P17_2 (i>18)
// blk slots: 0 h0, 1 P5, 2-4 P11 of pass 0-2, 5-7 P17 of pass 0-2
__device__ int attn_blocks(const Params& P, int layer, int pass, Src* s) {
  int n = 0;
  auto add = [&](int idx) { s[n++] = mksrc(P.blk + (size_t)idx * MAXB * H, H, 0); };
  if (layer > 0) add(0);
  if (layer > 6) add(1);
  if (layer > 12) add(layer >= 18 ? 4 : 2 + pass);
  if (layer > 18) add(7);
  return n;
}

// ------------------------------------------------------------------------------------------------ the step kernel
__host__ __device__ __forceinline__ int sin_bytes(int B) { const int v = 3 * B * XS * 2; return v > 24576 ? v : 24576; }
__host__ __device__ __forceinline__ int smem_bytes(int B) { return B * XS * 2 + sin_bytes(B) + NW * 32 * 16 + 4608 * 4; }
#define SMEM_BYTES (smem_bytes(MAXB))
#define GBAR(code) do { if (P.prof) { __syncthreads(); if (tid == 0) P.prof[8192 + pidx * 160 + blk] = gtime(); } gbar(bar, bt, nb); if (P.prof && blk == 0 && tid == 0) { P.prof[2 * pidx] = gtime(); P.prof[2 * pidx + 1] = (unsigned long long)(a * 16 + (code)); } pidx++; } while (0)

#define STAMP(k) do { if (P.prof && blk == 0) { __syncthreads(); if (tid == 0) P.prof[4096 + a * 16 + (k)] = gtime(); } } while (0)
// sc (float scratch) layout
#define SC_DOT 0        // [8][64]
#define SC_CF 512       // [8][3][8] stream coefficients (c0..c4, c7 = 1/rms)
#define SC_CM 704       // [8][3][8] message coefficients
#define SC_CFX 896      // [8][8] MoE input stream
#define SC_CMM 960      // [8][8] MoE message
#define SC_G 1024       // [8][3][64] gate down values
#define SC_XSC 2600     // [16] f16 scales
#define SC_IR 2624      // [3][8]

__device__ __noinline__ void epi_h(const Params& P, const EpiDesc& eH, const LayerW& L, int a, int layer, int slot, int pos, int B, int st, float4 c4) {
  const unsigned lane = lane_id();
  const float c[4] = {c4.x, c4.y, c4.z, c4.w};
  bf16* mr = P.mring + (size_t)slot * MAXB * 4 * H;
          const unsigned g = lane >> 2, t = lane & 3;
          const bool bnd = boundary(layer);
          const bf16* xprev = P.pbuf + (size_t)(a & 1) * MAXB * H;
          bf16* xnext = P.pbuf + (size_t)((a + 1) & 1) * MAXB * H;
#pragma unroll 1
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            const bool on = b < B;
            float acc[NPS];
#pragma unroll
            for (int i = 0; i < NPS; i++) acc[i] = 0.f;
#pragma unroll
            for (int rr = 0; rr < 2; rr++) {
              const int r = st * 16 + g + 8 * rr;
              if (on) {
                const float mraw = rbf(c[h2 + 2 * rr] * (1.f / 64.f));
                bf16* mb = mr + (size_t)b * 4 * H;
                mb[(size_t)(pos & 3) * H + r] = __float2bfloat16(mraw);
                float cw[4];
                unpack4(__ldg((const uint2*)(L.mconv + (size_t)r * 4)), cw);
                float hs[3];
#pragma unroll
                for (int tap = 0; tap < 3; tap++) { const int pp = pos - 3 + tap; hs[tap] = pp >= 0 ? ldbf(mb + (size_t)(pp & 3) * H + r) : 0.f; }
                const float at = ldbf(P.att + (size_t)b * H + r);
                const float xp = bnd ? 0.f : ldbf(xprev + (size_t)b * H + r);
                const float p5 = eH.restart ? ldbf(P.blk + ((size_t)1 * MAXB + b) * H + r) : 0.f;
                float bv[4], qv[3], m0, m1, mqv[3];
                epi_load(eH, b, r, bv, qv, m0, m1, mqv);
                float ac = 0.f;
#pragma unroll
                for (int tap = 0; tap < 3; tap++) ac = fmaf(hs[tap], cw[tap], ac);
                ac = fmaf(mraw, cw[3], ac);
                const float mlp = rbf((ac + mraw) * 0.4472135954999579f);
                const float F = bnd ? rbf(at + mlp) : rbf((xp + at) + mlp);
#ifdef DBG_DOTS
                if (a == DBG_DOTS && b == 0 && P.dbg) { P.dbg[((size_t)44 * MAXB + 7) * H + r] = mraw; P.dbg[((size_t)43 * MAXB + 7) * H + r] = mlp; }
#endif
                const float Xn = eH.restart ? p5 : F;
                const bf16 xb = __float2bfloat16(Xn);
                xnext[(size_t)b * H + r] = xb;
                if (eH.bi >= 0) P.blk[((size_t)eH.bi * MAXB + b) * H + r] = xb;
                if (eH.restart) P.blk[((size_t)eH.fi * MAXB + b) * H + r] = __float2bfloat16(F);
                if (P.dbg && a + 1 < NAPP) P.dbg[((size_t)(a + 1) * MAXB + b) * H + r] = Xn;
                if (eH.m1F) m1 = F;
                epi_acc(eH, acc, bv, Xn, 0.f, qv, m0, m1, mqv);
              }
            }
            xred8(acc);
            if (on)
#pragma unroll
              for (int i = 0; i < 5; i++) P.hpart[((size_t)st * MAXB + b) * NPS + 5 * g + i] = acc[i];
          }
}

__device__ __noinline__ void epi_e(const Params& P, const EpiDesc& eE, const LayerW& L, int a, int slot, int pos, int B, int s, float4 c4) {
  const unsigned lane = lane_id();
  const float c[4] = {c4.x, c4.y, c4.z, c4.w};
  bf16* orr = P.oring + (size_t)slot * MAXB * 4 * H;
          const unsigned g = lane >> 2, t = lane & 3;
          const bf16* Xg = P.pbuf + (size_t)(a & 1) * MAXB * H;
#pragma unroll 1
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            const bool on = b < B;
            float acc[NPS];
#pragma unroll
            for (int i = 0; i < NPS; i++) acc[i] = 0.f;
#pragma unroll
            for (int rr = 0; rr < 2; rr++) {
              const int r = s * 16 + g + 8 * rr;
              if (on) {
                const float o = rbf(c[h2 + 2 * rr]);
                bf16* ob = orr + (size_t)b * 4 * H;
                ob[(size_t)(pos & 3) * H + r] = __float2bfloat16(o);
                float cw[4];
                unpack4(__ldg((const uint2*)(L.aconv + (size_t)r * 4)), cw);
                float hs[3];
#pragma unroll
                for (int tap = 0; tap < 3; tap++) { const int pp = pos - 3 + tap; hs[tap] = pp >= 0 ? ldbf(ob + (size_t)(pp & 3) * H + r) : 0.f; }
                float bv[4], qv[3], m0, m1, mqv[3];
                epi_load(eE, b, r, bv, qv, m0, m1, mqv);
                const float X = ldbf(Xg + (size_t)b * H + r);
                float ac = 0.f;
#pragma unroll
                for (int tap = 0; tap < 3; tap++) ac = fmaf(hs[tap], cw[tap], ac);
                ac = fmaf(o, cw[3], ac);
                const float at = rbf((ac + o) * 0.4472135954999579f);
                P.att[(size_t)b * H + r] = __float2bfloat16(at);
                epi_acc(eE, acc, bv, eE.two ? X : X + at, at, qv, m0, m1, mqv);
              }
            }
            xred8(acc);
            if (on)
#pragma unroll
              for (int i = 0; i < 5; i++) P.epart[((size_t)s * MAXB + b) * NPS + 5 * g + i] = acc[i];
          }
}

__device__ __noinline__ void phase_attn(const Params& P, const LayerW& L, int a, int slot, int pos, int B, bool glob,
                                       float* sc, bf16* sIn, float* red) {
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31;
  const int nb = (int)P.nb, blk = blockIdx.x;
    {
      if (PF_O) { const int s0 = blk * 144 / nb, s1 = (blk + 1) * 144 / nb; pf_rangeX(L.wo + (size_t)s0 * 192 * 32, (size_t)(s1 - s0) * 192 * 512); }
      const int lo = glob ? 0 : (pos - (WIN - 1) > 0 ? pos - (WIN - 1) : 0);
      const int c_lo = lo / CH, c_hi = pos / CH;
      const int nch = c_hi - c_lo + 1;
      const int units = B * NHKV * nch;
      const size_t ctx = (size_t)P.ctx;
      float* sq = sc;                 // q [3][128]
      float* sr = sc + 384;           // r [3][16]
      float* sbias = sc + 448;        // [3][CH]
      float* ss = sc + 448 + 3 * CH;  // scores / probs [3][CH]
      float* skv = sc + 448 + 6 * CH; // k_cur [128], v_cur [128]
      float* sml = skv + 256;         // m, l [3][2]
      float* so = (float*)red;        // o partial [16 warps][3][128]? use sIn as float scratch
      float* sop = (float*)sIn;       // [NW][3][128]
      for (int u = blk; u < units; u += nb) {
        const int b = u / (NHKV * nch), h = (u / nch) % NHKV, ci = c_lo + u % nch;
        const int j0 = ci * CH > lo ? ci * CH : lo, j1 = (ci * CH + CH - 1) < pos ? ci * CH + CH - 1 : pos;
        const int n = j1 - j0 + 1;
        const bool last = ci == c_hi;
        const float* qk = P.qkv + (size_t)b * 8704;
        const float tau = glob ? 1.f + 0.1f * logf(fmaxf((pos + 1) / 8192.f, 1.f)) : 1.f;
        // issue the unit's independent loads first: this warp's K/V rows (keys w, w+16, ..) and the bias table
        const bf16* Kb = P.kc + (((size_t)slot * MAXB + b) * NHKV + h) * ctx * HD;
        const bf16* Vb = P.vc + (((size_t)slot * MAXB + b) * NHKV + h) * ctx * HD;
        uint2 kr[CH / NW], vr[CH / NW];
#pragma unroll
        for (int i = 0; i < CH / NW; i++) {
          const int jj = w + NW * i, j = j0 + jj;
          kr[i] = make_uint2(0, 0); vr[i] = make_uint2(0, 0);
          if (jj < n && j != pos) {
            kr[i] = __ldcg((const uint2*)(Kb + (size_t)j * HD + lane * 4));
            vr[i] = __ldcg((const uint2*)(Vb + (size_t)j * HD + lane * 4));
          }
        }
        float rp[DREL];
        const int dist_t = pos - (j0 + tid);
        const bool bias_on = tid < n && tid < CH && dist_t < RELX;
#pragma unroll
        for (int r = 0; r < DREL; r++) rp[r] = bias_on ? bf(L.relp[r * RELX + dist_t]) : 0.f;
        if (w < 3) {      // q of head 3h+w
          const int hq = 3 * h + w;
          float v[4], s = 0.f;
          for (int i = 0; i < 4; i++) {
            const int d = lane * 4 + i;
            v[i] = rbf(ldf(qk + hq * HD + d)) * bf(L.qscale[hq * HD + d]);
            s = fmaf(v[i], v[i], s);
          }
          s = warp_sum(s);
          const float f = fminf(22.627416997969522f / (sqrtf(s) + 1e-6f), 1.f);
          for (int i = 0; i < 4; i++) {
            float o = rbf(v[i] * f);
            if (glob) o = rbf(o * tau);
            sq[w * HD + lane * 4 + i] = o;
          }
        } else if (w < 6) {   // r of head 3h+w-3
          const int hq = 3 * h + w - 3;
          float v = 0.f;
          if (lane < DREL) v = rbf(ldf(qk + 6144 + hq * DREL + lane)) * bf(L.rscale[hq * DREL + lane]);
          const float s = warp_sum(v * v);
          const float f = fminf(8.0f / (sqrtf(s) + 1e-6f), 1.f);
          if (lane < DREL) {
            float o = rbf(v * f);
            if (glob) o = rbf(o * tau);
            sr[(w - 3) * DREL + lane] = o;
          }
        } else if (w < 8 && last) {   // current k (w 6) / v (w 7) of head h
          const bool isk = w == 6;
          const int off = (isk ? (int)L.koff : (int)L.voff) + h * HD;
          bf16* ring = (isk ? P.kring : P.vring) + ((size_t)slot * MAXB + b) * 4 * KVD;
          const bf16* cw = isk ? L.kconv : L.vconv;
          float x[4], v[4], s = 0.f;
          for (int i = 0; i < 4; i++) {
            const int d = lane * 4 + i, c = h * HD + d;
            x[i] = rbf(ldf(qk + off + lane * 4 + i));
            float acc = 0.f;
            if (!glob) {
              for (int tap = 0; tap < 3; tap++) {
                const int pp = pos - 3 + tap;
                const float hv = pp >= 0 ? ldbf(ring + (size_t)(pp & 3) * KVD + c) : 0.f;
                acc = fmaf(hv, bf(cw[c * 4 + tap]), acc);
              }
              acc = fmaf(x[i], bf(cw[c * 4 + 3]), acc);
              v[i] = rbf((acc + x[i]) * 0.4472135954999579f);
            } else {
              const int dp = (isk ? (int)L.kpoff : (int)L.vpoff) + h * 4;
              for (int lag = 0; lag < 4; lag++) {
                const float dyn = rbf(ldf(qk + dp + lag));
                const float wt = bf(cw[lag * KVD + c]) + dyn;
                const int pp = pos - lag;
                const float hv = lag == 0 ? x[i] : (pp >= 0 ? ldbf(ring + (size_t)(pp & 3) * KVD + c) : 0.f);
                acc = fmaf(hv, wt, acc);
              }
              v[i] = rbf((acc + x[i]) * (1.f / 3.f));
            }
            s = fmaf(v[i], v[i], s);
          }
          s = warp_sum(s);
          const float f = isk ? fminf(22.627416997969522f / (sqrtf(s) + 1e-6f), 1.f) : rsqrtf(s / HD + 1e-6f);
          bf16* cache = (isk ? P.kc : P.vc) + ((((size_t)slot * MAXB + b) * NHKV + h) * ctx + pos) * HD;
          for (int i = 0; i < 4; i++) {
            const float o = rbf(v[i] * f);
            skv[(isk ? 0 : 128) + lane * 4 + i] = o;
            cache[lane * 4 + i] = __float2bfloat16(o);
            ring[(size_t)(pos & 3) * KVD + h * HD + lane * 4 + i] = __float2bfloat16(x[i]);
          }
        }
        __syncthreads();
        // relative bias of the chunk's keys (one thread per key, 3 heads)
        if (tid < CH) {
#pragma unroll
          for (int hw = 0; hw < 3; hw++) {
            float bv = 0.f;
#pragma unroll
            for (int r = 0; r < DREL; r++) bv = fmaf(sr[hw * DREL + r], rp[r], bv);
            sbias[hw * CH + tid] = bias_on ? bv : 0.f;
          }
        }
        // scores (K rows already in registers; the current position from shared memory)
#pragma unroll
        for (int i = 0; i < CH / NW; i++) {
          const int jj = w + NW * i;
          if (jj < n) {
            const int j = j0 + jj;
            float kv[4];
            if (j == pos) { for (int e = 0; e < 4; e++) kv[e] = skv[lane * 4 + e]; }
            else {
              kv[0] = __uint_as_float(kr[i].x << 16); kv[1] = __uint_as_float(kr[i].x & 0xffff0000u);
              kv[2] = __uint_as_float(kr[i].y << 16); kv[3] = __uint_as_float(kr[i].y & 0xffff0000u);
            }
            for (int hw = 0; hw < 3; hw++) {
              float d = 0.f;
              for (int e = 0; e < 4; e++) d = fmaf(sq[hw * HD + lane * 4 + e], kv[e], d);
              d = warp_sum(d);
              if (lane == 0) ss[hw * CH + jj] = d * 0.08838834764831845f;   // 1/sqrt(128)
            }
          }
        }
        __syncthreads();
        if (w < 3) {
          float m = -1e30f;
          for (int jj = lane; jj < n; jj += 32) { ss[w * CH + jj] += sbias[w * CH + jj]; m = fmaxf(m, ss[w * CH + jj]); }
          m = warp_max(m);
          float l = 0.f;
          for (int jj = lane; jj < n; jj += 32) { const float p = __expf(ss[w * CH + jj] - m); ss[w * CH + jj] = p; l += p; }
          l = warp_sum(l);
          if (lane == 0) { sml[w * 2] = m; sml[w * 2 + 1] = l; }
        }
        __syncthreads();
        // o = sum p v: warp w handles keys jj = w, w+16..; lane 4 dims
        {
          float o[3][4] = {};
#pragma unroll
          for (int i2 = 0; i2 < CH / NW; i2++) {
            const int jj = w + NW * i2;
            if (jj >= n) continue;
            const int j = j0 + jj;
            float vv[4];
            if (j == pos) { for (int e = 0; e < 4; e++) vv[e] = skv[128 + lane * 4 + e]; }
            else {
              vv[0] = __uint_as_float(vr[i2].x << 16); vv[1] = __uint_as_float(vr[i2].x & 0xffff0000u);
              vv[2] = __uint_as_float(vr[i2].y << 16); vv[3] = __uint_as_float(vr[i2].y & 0xffff0000u);
            }
            for (int hw = 0; hw < 3; hw++) {
              const float p = ss[hw * CH + jj];
              for (int e = 0; e < 4; e++) o[hw][e] = fmaf(p, vv[e], o[hw][e]);
            }
          }
          for (int hw = 0; hw < 3; hw++)
            for (int i = 0; i < 4; i++) sop[(w * 3 + hw) * HD + lane * 4 + i] = o[hw][i];
        }
        __syncthreads();
        for (int i = tid; i < 3 * HD; i += NT) {
          const int hw = i / HD, d = i % HD;
          float s = 0.f;
          for (int ww = 0; ww < NW; ww++) s += sop[(ww * 3 + hw) * HD + d];
          float* dst = P.apart + (((size_t)b * NHQ + 3 * h + hw) * MAXCH + (ci - c_lo)) * 132;
          dst[d] = s;
          if (d == 0) { dst[128] = sml[hw * 2]; dst[129] = sml[hw * 2 + 1]; }
        }
        __threadfence();
        __syncthreads();
        // the last unit of (b, h) combines the chunks
        __shared__ unsigned s_last;
        if (tid == 0) {
          const unsigned old = atomicAdd(P.sync + 64 + ((size_t)a * MAXB + b) * NHKV + h, 1u);
          s_last = (old == (unsigned)(nch - 1));
          __threadfence();
        }
        __syncthreads();
        if (s_last) {
          for (int i = tid; i < 3 * HD; i += NT) {
            const int hw = i / HD, d = i % HD, hq = 3 * h + hw;
            const float* base = P.apart + ((size_t)b * NHQ + hq) * MAXCH * 132;
            float M = -1e30f;
            for (int c = 0; c < nch; c++) M = fmaxf(M, ldf(base + c * 132 + 128));
            float Lsum = 0.f, O = 0.f;
            for (int c = 0; c < nch; c++) {
              const float e = __expf(ldf(base + c * 132 + 128) - M);
              Lsum = fmaf(ldf(base + c * 132 + 129), e, Lsum);
              O = fmaf(ldf(base + c * 132 + d), e, O);
            }
            const float lse = M + logf(Lsum);
            const float gate = rbf(ldf(qk + 3072 + hq * HD + d));
            const float sink = rbf(ldf(qk + 6528 + hq));
            const float out = O / Lsum * sigm(gate) * sigm(lse - sink);
            P.ao[(size_t)b * QD + hq * HD + d] = __float2bfloat16(out);
          }
        }
        __syncthreads();
      }
    }
}

__global__ void __launch_bounds__(NT, 1) mk_step(const __grid_constant__ Params P) {
  extern __shared__ __align__(16) uint8_t smem[];
  __shared__ DotSet sdA, sdM;
  __shared__ EpiDesc eH, eE;
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31;
  const int nb = (int)P.nb, blk = blockIdx.x;
  const int B = (int)P.B;
  unsigned bt = 0;
  unsigned* bar = P.sync;
  int pidx = 1;
  int a = 0;
  if (P.prof && blk == 0 && tid == 0) { P.prof[0] = gtime(); P.prof[1] = 0; }
  const int pos = P.pos[0];
  if (P.outkey && blk == 0 && tid < B) { P.outkey[tid] = 0ull; if (P.sklo) P.sklo[tid] = 0u; }

  bf16* sX = (bf16*)smem;                       // entering partial X [8][XS]
  bf16* sIn = sX + B * XS;                      // [3][B][XS] (at least 24 KB: attention scratch)
  float* red = (float*)((uint8_t*)sIn + sin_bytes(B));   // 8 KB
  float* sc = red + NW * 32 * 4;                // 4608 floats
  float* part2 = (float*)(sIn + 2 * B * XS);    // dot partials (third stream region)

  for (a = 0; a <= NAPP; a++) {
    const App ap = a < NAPP ? app_of(a) : App{24, 0, -1};
    const bool restart = a < NAPP && ap.layer == 6 && ap.pass >= 1;
    if (a < NAPP) {   // this block's q|gate|r|sink|k|v strips -> L2 while the vector work runs
      const LayerW& Lf = cL[ap.layer];
      const int N = (int)Lf.nstrip, s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      pf_range(Lf.wqkv + (size_t)s0 * 144 * 32, (size_t)(s1 - s0) * 144 * 512);
    }
    // ---------------------------------------------------------------- entering partial X_0 (embedding); later X_a
    // comes from the previous application's W2 epilogue (pbuf[a & 1], with its dot-product partials in hpart)
    if (a == 0) {
      for (int p = tid; p < B * NC8; p += NT) {
        const int b = p / NC8, c = p % NC8;
        long long tk = P.tokkey ? (long long)(0xffffffffu - (unsigned)(P.tokkey[b] & 0xffffffffu)) : P.tok[b];
        tk = tk < 0 ? 0 : (tk >= 201024 ? 201023 : tk);
        *(uint4*)(sX + b * XS + 8 * c) = __ldg((const uint4*)(P.emb + (size_t)tk * H + 8 * c));
      }
      __syncthreads();
      if (tid == 0) { sdA.nv = 1; sdA.nq = 0; sdA.nm = 0; sdA.nmq = 0; sdA.S[0] = mksrc(sX, XS, 2); }
      __syncthreads();
      dot_pass(sdA, B, part2, sc + SC_DOT);
      for (int p = tid; p < B * NC8; p += NT) {
        const int b = p / NC8, c = p % NC8;
        const float ir = rsqrtf(sc[SC_DOT + b * 64] / H + 1e-6f);
        float v[8], wv[8];
        unpack8(*(const uint4*)(sX + b * XS + 8 * c), v);
        ldw8(P.embnorm, c, wv);
        for (int e = 0; e < 8; e++) v[e] = v[e] * ir * wv[e];
        const uint4 pk = pack8(v);
        *(uint4*)(sX + b * XS + 8 * c) = pk;
        if (blk == 0) {
          *(uint4*)(P.pbuf + (size_t)b * H + 8 * c) = pk;
          *(uint4*)(P.blk + (size_t)b * H + 8 * c) = pk;
          if (P.dbg) {
            float* dd = P.dbg + (size_t)b * H + 8 * c;
            unpack8(pk, v);
            *(float4*)dd = make_float4(v[0], v[1], v[2], v[3]);
            *(float4*)(dd + 4) = make_float4(v[4], v[5], v[6], v[7]);
          }
        }
      }
      __syncthreads();
    }

    STAMP(0);
    if (a == NAPP) break;
    const LayerW& L = cL[ap.layer];
    const int layer = ap.layer, pass = ap.pass, slot = ap.slot;
    const bool glob = L.glob != 0;
    const bool gated = pass >= 1;
    const int nq = glob ? 3 : 1;

    // ---------------------------------------------------------------- attention-input sources and coefficients
    __syncthreads();
    if (tid == 0) {
      DotSet& d = sdA;
      d.nv = 0; d.nq = 0; d.nm = 0; d.nmq = 0;
      if (layer > 0) d.nv = attn_blocks(P, layer, pass, d.S);
      d.S[d.nv++] = a == 0 ? mksrc(sX, XS, 2) : mksrc(P.pbuf + (size_t)(a & 1) * MAXB * H, H, 1);
      if (layer > 0) { d.nq = nq; for (int j = 0; j < nq; j++) d.q[j] = L.aq + (glob ? j * H : 0); }
      if (gated) {
        d.M[0] = mksrc(P.blk + (size_t)(2 + pass - 1) * MAXB * H, H, 0);
        d.M[1] = mksrc(P.blk + (size_t)(5 + pass - 1) * MAXB * H, H, 1);
        d.nm = 2; d.nmq = 3;
        const float* lq = P.loopq + (size_t)(layer - 6) * 4 * H;
        for (int j = 0; j < 3; j++) d.mq[j] = lq + j * H;
      }
    }
    __syncthreads();
    Src* S = sdA.S;
    Src* Ms = sdA.M;
    const int ns = sdA.nv;
    {
      STAMP(1);
      if (a > 0) reduce_parts(P.hpart, B, ns, sdA.nq, sdA.nm, sdA.nmq, sc + SC_DOT, red);
      else dot_pass(sdA, B, part2, sc + SC_DOT);   // layer 0: the dots of the normalized X_0
      STAMP(2);
      if (tid < B * 3) {
        const int b = tid / 3, j = tid % 3;
        if (j < nq) coefs(sc + SC_DOT + b * 64, ns, j, false, layer == 0, sc + SC_CF + (b * 3 + j) * 8);
        if (gated) coefs(sc + SC_DOT + b * 64, 2, j, true, false, sc + SC_CM + (b * 3 + j) * 8);
      }
      __syncthreads();
    }

    if (gated) {
      // ------------------------------------------------ phase A: controller down projections (q, k, v gates)
      // item = blk (< 3*4*GSEG): gate j, strip st, segment sg of the 4608 inputs (24 tiles = 384 inputs)
      const int item = blk;
      if (item < 3 * 4 * GSEG) {
        const int j = item / (4 * GSEG), st = (item / GSEG) % 4, sg = item % GSEG;
        const int sj = glob ? j : 0;
        bf16* seg = sIn;   // rows [b][0..384)
        const int kb = sg * 384;
        for (int p = tid; p < B * 48; p += NT) {
          const int b = p / 48, cc = p % 48;
          const int k = kb + 8 * cc;
          float x[8];
          if (k < H) {
            const float* cf = sc + SC_CF + (b * 3 + sj) * 8;
            mix8(S, ns, cf, b, k / 8, x);
            for (int e = 0; e < 8; e++) x[e] *= cf[7];
          } else {
            const float* cm = sc + SC_CM + (b * 3 + j) * 8;
            mix8(Ms, 2, cm, b, (k - H) / 8, x);
            for (int e = 0; e < 8; e++) x[e] *= cm[7];
          }
          *(uint4*)(seg + b * XS + 8 * cc) = pack8(x);
        }
        __syncthreads();
        if (w == 0) {
          float c[4] = {0.f, 0.f, 0.f, 0.f};
          const uint4* A = L.cdown + ((size_t)(j * 4 + st) * 288 + sg * 24) * 32;
          strip_bf16<8>(A, 0, 24, seg, B, c);
          const unsigned g = lane >> 2, t = lane & 3;
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) {
              P.gpart[(((size_t)b * 3 + j) * GSEG + sg) * 64 + st * 16 + g] = c[h2];
              P.gpart[(((size_t)b * 3 + j) * GSEG + sg) * 64 + st * 16 + g + 8] = c[2 + h2];
            }
          }
        }
      }
      if (blk == 0) for (int i = tid; i < 384; i += NT) P.coef[i] = sc[SC_CF + i];   // CF and CM are adjacent
      GBAR(0);
      // ------------------------------------------------ phase B: x' = (1 - tanh(F g)) x + tanh(G g) m
      // warp tasks (gate j, token b, 32-element group); one element per lane; spread over all blocks
      {
        float* gs = sc + SC_G;
        for (int i = tid; i < B * 3 * 64; i += NT) {
          const int b = i / 192, j = (i / 64) % 3, r = i % 64;
          float s = 0.f;
          for (int sg = 0; sg < GSEG; sg++) s += ldf(P.gpart + (((size_t)b * 3 + j) * GSEG + sg) * 64 + r);
          gs[i] = s;
        }
        for (int i = tid; i < 384; i += NT) sc[SC_CF + i] = ldf(P.coef + i);
        __syncthreads();
        const int tasks = 3 * B * (H / 32);
        for (int t = w * nb + blk; t < tasks; t += nb * NW) {
          const int j = t / (B * 72), b = (t / 72) % B, k = (t % 72) * 32 + lane;
          const int sj = glob ? j : 0;
          const float x = mix1(S, ns, sc + SC_CF + (b * 3 + sj) * 8, b, k);
          const float m = mix1(Ms, 2, sc + SC_CM + (b * 3 + j) * 8, b, k);
          P.xg[((size_t)j * MAXB + b) * H + k] =
              gate1(L.cforget + ((size_t)j * H + k) * 64, L.cgain + ((size_t)j * H + k) * 64, gs + (b * 3 + j) * 64, x, m);
        }
      }
      GBAR(1);
      // rms of the gated streams
      {
        for (int task = w; task < B * NWT8; task += NW) {
          const int b = task / NWT8, wt = task % NWT8, c = wt * 32 + lane;
          float acc[32];
#pragma unroll
          for (int i = 0; i < 32; i++) acc[i] = 0.f;
#pragma unroll
          for (int j = 0; j < 3; j++) {
            const float4 v0 = __ldcg((const float4*)(P.xg + ((size_t)j * MAXB + b) * H + 8 * c));
            const float4 v1 = __ldcg((const float4*)(P.xg + ((size_t)j * MAXB + b) * H + 8 * c + 4));
            acc[j] = v0.x * v0.x + v0.y * v0.y + v0.z * v0.z + v0.w * v0.w + v1.x * v1.x + v1.y * v1.y + v1.z * v1.z + v1.w * v1.w;
          }
          const float r = xred32(acc);
          part2[(b * NWT8 + wt) * 32 + lane] = r;
        }
        __syncthreads();
        if (tid < B * 3) {
          const int b = tid / 3, j = tid % 3;
          float s = 0.f;
          for (int k = 0; k < NWT8; k++) s += part2[(b * NWT8 + k) * 32 + j];
          sc[SC_IR + j * 8 + b] = rsqrtf(s / H + 1e-6f);
        }
        __syncthreads();
      }
    }

    // ---------------------------------------------------------------- phase C: the q|gate|r|sink, k, v projections
    {
      const int nin = (glob || gated) ? 3 : 1;
      for (int p = tid; p < B * NC8; p += NT) {
        const int b = p / NC8, c = p % NC8;
        float xs0[8];
        if (!gated) {
          // one pass over the sources accumulates every stream (packed bf16 sources, 8 x nin accumulators)
          uint4 pv[5];
#pragma unroll
          for (int i = 0; i < 5; i++) if (i < ns) pv[i] = ld8raw(S[i].p + (size_t)b * S[i].stride + 8 * c, S[i].mode);
          float x0[8], x1[8], x2[8];
          const float* cf0 = sc + SC_CF + (b * 3) * 8;
          const float* cf1 = sc + SC_CF + (b * 3 + (glob ? 1 : 0)) * 8;
          const float* cf2 = sc + SC_CF + (b * 3 + (glob ? 2 : 0)) * 8;
#pragma unroll
          for (int e = 0; e < 8; e++) { x0[e] = 0.f; x1[e] = 0.f; x2[e] = 0.f; }
#pragma unroll
          for (int i = 0; i < 5; i++)
            if (i < ns) {
              const float c0 = cf0[i], c1 = cf1[i], c2 = cf2[i];
#pragma unroll
              for (int e = 0; e < 8; e++) {
                const float v = el8(pv[i], e);
                x0[e] = fmaf(c0, v, x0[e]); x1[e] = fmaf(c1, v, x1[e]); x2[e] = fmaf(c2, v, x2[e]);
              }
            }
          float wv[8];
          ldw8(L.normq, c, wv);
#pragma unroll
          for (int e = 0; e < 8; e++) xs0[e] = x0[e] * cf0[7] * wv[e];
          *(uint4*)(sIn + (0 * B + b) * XS + 8 * c) = pack8(xs0);
          if (nin == 3) {
            ldw8(L.normk, c, wv);
#pragma unroll
            for (int e = 0; e < 8; e++) xs0[e] = x1[e] * cf1[7] * wv[e];
            *(uint4*)(sIn + (1 * B + b) * XS + 8 * c) = pack8(xs0);
            ldw8(L.normv, c, wv);
#pragma unroll
            for (int e = 0; e < 8; e++) xs0[e] = x2[e] * cf2[7] * wv[e];
            *(uint4*)(sIn + (2 * B + b) * XS + 8 * c) = pack8(xs0);
          }
        } else {
          for (int j = 0; j < 3; j++) {
            const bf16* nw = j == 0 ? L.normq : (j == 1 ? L.normk : L.normv);
            const float4 v0 = __ldcg((const float4*)(P.xg + ((size_t)j * MAXB + b) * H + 8 * c));
            const float4 v1 = __ldcg((const float4*)(P.xg + ((size_t)j * MAXB + b) * H + 8 * c + 4));
            const float xv[8] = {v0.x, v0.y, v0.z, v0.w, v1.x, v1.y, v1.z, v1.w};
            const float ir = sc[SC_IR + j * 8 + b];
            float wv[8];
            ldw8(nw, c, wv);
            for (int e = 0; e < 8; e++) xs0[e] = xv[e] * ir * wv[e];
            *(uint4*)(sIn + (j * B + b) * XS + 8 * c) = pack8(xs0);
          }
        }
      }
      __syncthreads();
      STAMP(3);
      const int N = (int)L.nstrip;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      const int kst = (int)L.koff / 16, vst = (int)L.voff / 16;
      block_strips(s0, s1, 144, red,
        [&](int s, int k0, int k1, float c[4]) {
          const bf16* xs = sIn + (nin == 3 ? (s >= vst ? 2 : (s >= kst ? 1 : 0)) : 0) * B * XS;
          strip_bf16<8>(L.wqkv + (size_t)s * 144 * 32, k0, k1, xs, B, c);
        },
        [&](int s, float c[4]) {
          const unsigned g = lane >> 2, t = lane & 3;
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) { P.qkv[(size_t)b * 8704 + s * 16 + g] = c[h2]; P.qkv[(size_t)b * 8704 + s * 16 + g + 8] = c[2 + h2]; }
          }
        });
    }
    GBAR(2);
    // ---------------------------------------------------------------- phase D: attention
    phase_attn(P, L, a, slot, pos, B, glob, sc, sIn, red);
    GBAR(3);

    // ---------------------------------------------------------------- phase E: output projection
    {
      if (tid == 0) {
        int idx[4];
        eE.nblk = attn_blk_idx(layer, pass, idx);
        for (int i = 0; i < eE.nblk; i++) eE.blkp[i] = P.blk + (size_t)idx[i] * MAXB * H;
        eE.two = boundary(layer);
        eE.nq = 1; eE.q[0] = L.mq;
        eE.nm = gated ? 2 : 0; eE.m1F = 0; eE.nmq = gated ? 1 : 0;
        if (gated) {
          eE.m0 = P.blk + (size_t)(2 + pass - 1) * MAXB * H;
          eE.m1 = P.blk + (size_t)(5 + pass - 1) * MAXB * H;
          eE.mq[0] = P.loopq + ((size_t)(layer - 6) * 4 + 3) * H;
        }
        eE.restart = 0; eE.bi = -1; eE.fi = -1;
      }
      bf16* xs = sIn;   // [8][XS] used as 3072-wide rows: stride XS >= 3072? no: use dedicated stride
      // ao rows are 3072 wide: store with stride 3072+8 in sIn (fits: 8*3080*2 = 49 KB)
      const int AS = QD + 8;
#ifdef DBG_DOTS
      if (a == DBG_DOTS && blk == 0 && P.dbg) for (int i = tid; i < QD; i += NT) P.dbg[((size_t)42 * MAXB + 7) * H + i] = ldbf(P.ao + i);
      if (a == DBG_DOTS && blk == 0 && P.dbg) for (int i = tid; i < 2048; i += NT) P.dbg[((size_t)40 * MAXB + 7) * H + i] = ldf(P.qkv + 6560 + i);
      if (a == DBG_DOTS && blk == 0 && P.dbg) for (int i = tid; i < 2304; i += NT) P.dbg[((size_t)39 * MAXB + 7) * H + i] = ldf(P.qkv + i);
#endif
      for (int b = 0; b < B; b++)
        for (int k = tid; k < QD / 2; k += NT)
          *(uint32_t*)(xs + b * AS + 2 * k) = __ldcg((const unsigned*)(P.ao + (size_t)b * QD) + k);
      __syncthreads();
      const int N = 144;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      bf16* orr = P.oring + (size_t)slot * MAXB * 4 * H;
      block_strips(s0, s1, 192, red,
        [&](int s, int k0, int k1, float c[4]) { strip_bf16<8>(L.wo + (size_t)s * 192 * 32, k0, k1, xs, B, c, AS); },
        [&](int s, float c[4]) { epi_e(P, eE, L, a, slot, pos, B, s, make_float4(c[0], c[1], c[2], c[3]));         });
    }
    GBAR(4);

    // ---------------------------------------------------------------- phase F: MoE input, router
    // (the attention conv and the MoE-input dots were done by the O-projection epilogue: P.att, epart)
    {
      bf16* sM = sIn + B * XS;           // MoE input (normalized) [B][XS]
      const bf16* Xg = P.pbuf + (size_t)(a & 1) * MAXB * H;
      if (tid == 0) {
        DotSet& d = sdM;
        d.nm = 0; d.nmq = 0;
        int nm0 = attn_blocks(P, layer, pass, d.S);
        if (boundary(layer)) {
          d.S[nm0++] = mksrc(Xg, H, 1);
          d.S[nm0++] = mksrc(P.att, H, 1);
        } else {
          d.S[nm0] = Src{Xg, P.att, H, H, 1, 1};
          nm0++;
        }
        d.nv = nm0;
        d.nq = 1; d.q[0] = L.mq;
        if (gated) {
          d.M[0] = mksrc(P.blk + (size_t)(2 + pass - 1) * MAXB * H, H, 0);
          d.M[1] = mksrc(P.blk + (size_t)(5 + pass - 1) * MAXB * H, H, 0);
          d.nm = 2; d.nmq = 1;
          d.mq[0] = P.loopq + ((size_t)(layer - 6) * 4 + 3) * H;
        }
      }
      __syncthreads();
      Src* ms = sdM.S;
      Src* mm = sdM.M;
      const int nm = sdM.nv;
      reduce_parts(P.epart, B, nm, 1, sdM.nm, sdM.nmq, sc + SC_DOT, red);
#ifdef DBG_DOTS
      if (a == DBG_DOTS) {
        dot_pass(sdM, B, part2, sc + 3584);
        if (blk == 0 && P.dbg) for (int i = tid; i < 64 * B; i += NT) { P.dbg[((size_t)47 * MAXB + 7) * H + i] = sc[SC_DOT + i]; P.dbg[((size_t)47 * MAXB + 7) * H + 1024 + i] = sc[3584 + i]; }
        __syncthreads();
      }
#endif
      if (tid < B) {
        coefs(sc + SC_DOT + tid * 64, nm, 0, false, false, sc + SC_CFX + tid * 8);
        if (gated) coefs(sc + SC_DOT + tid * 64, 2, 0, true, false, sc + SC_CMM + tid * 8);
      }
      __syncthreads();
      if (gated) {
        // phase F1: down projection segments of cat(unit(x), unit(m)) (128 inputs each): item = blk < 4*MSEG
        const int item = blk;
        bf16* seg = sM;
        if (item < 4 * MSEG) {
          const int st = item / MSEG, sg = item % MSEG;
          const int kb = sg * 128;
          for (int p = tid; p < B * 16; p += NT) {
            const int b = p / 16, cc = p % 16;
            const int k = kb + 8 * cc;
            float x[8];
            if (k < H) {
              const float* cf = sc + SC_CFX + b * 8;
              mix8(ms, nm, cf, b, k / 8, x);
              for (int e = 0; e < 8; e++) x[e] *= cf[7];
            } else {
              const float* cm = sc + SC_CMM + b * 8;
              mix8(mm, 2, cm, b, (k - H) / 8, x);
              for (int e = 0; e < 8; e++) x[e] *= cm[7];
            }
            *(uint4*)(seg + b * XS + 8 * cc) = pack8(x);
          }
          __syncthreads();
          if (w == 0) {
            float c[4] = {0.f, 0.f, 0.f, 0.f};
            const uint4* A = L.cdown + ((size_t)(3 * 4 + st) * 288 + sg * 8) * 32;
            strip_bf16<8>(A, 0, 8, seg, B, c);
            const unsigned g = lane >> 2, t = lane & 3;
            for (int h2 = 0; h2 < 2; h2++) {
              const int b = 2 * t + h2;
              if (b < B) {
                P.gpart[((size_t)b * MSEG + sg) * 64 + st * 16 + g] = c[h2];
                P.gpart[((size_t)b * MSEG + sg) * 64 + st * 16 + g + 8] = c[2 + h2];
              }
            }
          }
        }
        if (blk == 0) for (int i = tid; i < 128; i += NT) P.coef[512 + i] = sc[SC_CFX + i];   // CFX, CMM adjacent
        GBAR(5);
        // phase F2: x' for the MoE input
        {
          float* gs = sc + SC_G;    // [8][64]
          for (int i = tid; i < B * 64; i += NT) {
            const int b = i / 64, r = i % 64;
            float s = 0.f;
            for (int sg = 0; sg < MSEG; sg++) s += ldf(P.gpart + ((size_t)b * MSEG + sg) * 64 + r);
            gs[i] = s;
          }
          for (int i = tid; i < 128; i += NT) sc[SC_CFX + i] = ldf(P.coef + 512 + i);
          __syncthreads();
          const int nm2 = nm;
          const int tasks = B * (H / 32);
          for (int t = w * nb + blk; t < tasks; t += nb * NW) {
            const int b = t / 72, k = (t % 72) * 32 + lane;
            const float x = mix1(ms, nm2, sc + SC_CFX + b * 8, b, k);
            const float m = mix1(mm, 2, sc + SC_CMM + b * 8, b, k);
            P.xg[(size_t)b * H + k] = gate1(L.cforget + ((size_t)3 * H + k) * 64, L.cgain + ((size_t)3 * H + k) * 64, gs + b * 64, x, m);
          }
        }
        GBAR(6);
        // rms of x'
        for (int task = w; task < B * NWT8; task += NW) {
          const int b = task / NWT8, wt = task % NWT8, c = wt * 32 + lane;
          float acc[32];
#pragma unroll
          for (int i = 0; i < 32; i++) acc[i] = 0.f;
          const float4 v0 = __ldcg((const float4*)(P.xg + (size_t)b * H + 8 * c));
          const float4 v1 = __ldcg((const float4*)(P.xg + (size_t)b * H + 8 * c + 4));
          acc[0] = v0.x * v0.x + v0.y * v0.y + v0.z * v0.z + v0.w * v0.w + v1.x * v1.x + v1.y * v1.y + v1.z * v1.z + v1.w * v1.w;
          const float r = xred32(acc);
          part2[(b * NWT8 + wt) * 32 + lane] = r;
        }
        __syncthreads();
        if (tid < B) {
          float s = 0.f;
          for (int k = 0; k < NWT8; k++) s += part2[(tid * NWT8 + k) * 32];
          sc[SC_IR + tid] = rsqrtf(s / H + 1e-6f);
        }
        __syncthreads();
      }
      // normalized MoE input -> sM (bf16)
      for (int p = tid; p < B * NC8; p += NT) {
        const int b = p / NC8, c = p % NC8;
        float x[8], wv[8], ir;
        if (gated) {
          const float4 v0 = __ldcg((const float4*)(P.xg + (size_t)b * H + 8 * c));
          const float4 v1 = __ldcg((const float4*)(P.xg + (size_t)b * H + 8 * c + 4));
          x[0] = v0.x; x[1] = v0.y; x[2] = v0.z; x[3] = v0.w; x[4] = v1.x; x[5] = v1.y; x[6] = v1.z; x[7] = v1.w;
          ir = sc[SC_IR + b];
        } else {
          const float* cf = sc + SC_CFX + b * 8;
          mix8(ms, nm, cf, b, c, x);
          ir = cf[7];
        }
        ldw8(L.mlpnorm, c, wv);
        for (int e = 0; e < 8; e++) x[e] = x[e] * ir * wv[e];
        const uint4 pk = pack8(x);
        *(uint4*)(sM + b * XS + 8 * c) = pk;
        if (blk == 0) *(uint4*)(P.xm + (size_t)b * H + 8 * c) = pk;
#ifdef DBG_DOTS
        if (a == DBG_DOTS && blk == 0 && P.dbg && b == 0) {
          for (int e = 0; e < 8; e++) { P.dbg[((size_t)46 * MAXB + 7) * H + 8 * c + e] = x[e]; P.dbg[((size_t)45 * MAXB + 7) * H + 8 * c + e] = ldbf(P.att + 8 * c + e); }
        }
#endif
      }
      __syncthreads();
      // router: item = blk < 8 * RSEG: strip st, segment sg (9 tiles)
      if (blk < 8 * RSEG && w == 0) {
        const int st = blk / RSEG, sg = blk % RSEG;
        float c[4] = {0.f, 0.f, 0.f, 0.f};
        strip_bf16<9>(L.wr + (size_t)st * 144 * 32, sg * 9, sg * 9 + 9, sM, B, c);
        const unsigned g = lane >> 2, t = lane & 3;
        for (int h2 = 0; h2 < 2; h2++) {
          const int b = 2 * t + h2;
          if (b < B) {
            P.rpart[((size_t)b * RSEG + sg) * 128 + st * 16 + g] = c[h2];
            P.rpart[((size_t)b * RSEG + sg) * 128 + st * 16 + g + 8] = c[2 + h2];
          }
        }
      }
    }
    GBAR(7);

    // ---------------------------------------------------------------- routing (every block, redundant)
    int* sel = (int*)(sc + 3072);        // [8][8] expert ids
    float* selw = sc + 3136;             // [8][8] weights
    int* uni = (int*)(sc + 3200);        // [128] union experts (sorted)
    int* uslot = (int*)(sc + 3328);      // [128][8] slot of token b in union expert u (-1)
    int* nuni = (int*)(sc + 3330 + 1024);
    {
      if (w < B) {
        const int b = w;
        float sv[4], sgv[4];
#pragma unroll
        for (int i = 0; i < 4; i++) {
          const int e = lane * 4 + i;
          float v[RSEG];
#pragma unroll
          for (int sg = 0; sg < RSEG; sg++) v[sg] = ldf(P.rpart + ((size_t)b * RSEG + sg) * 128 + e);
          float s = 0.f;
#pragma unroll
          for (int sg = 0; sg < RSEG; sg++) s += v[sg];
          sgv[i] = sigm(s);
          sv[i] = sgv[i] + L.rbias[e];
        }
        float wsum = 0.f, wsel = 0.f;
#pragma unroll 1
        for (int r = 0; r < TOPK; r++) {
          // lane-local best (ties: lower index), then warp max of the orderable key, then min index among ties
          float bv = sv[0]; int bi = lane * 4;
#pragma unroll
          for (int i = 1; i < 4; i++) { const bool gt = sv[i] > bv; bv = selp(gt, sv[i], bv); bi = gt ? lane * 4 + i : bi; }
          unsigned key = __float_as_uint(bv);
          key = (key & 0x80000000u) ? ~key : (key | 0x80000000u);
          const unsigned mx = __reduce_max_sync(0xffffffffu, key);
          const int e = (int)__reduce_min_sync(0xffffffffu, key == mx ? (unsigned)bi : 0xffffffffu);
          float mine = 0.f;
#pragma unroll
          for (int i = 0; i < 4; i++) {
            const bool hit = (lane * 4 + i) == e;
            mine = selp(hit, sgv[i], mine);
            sv[i] = selp(hit, -1e30f, sv[i]);
          }
          const float sg_ = __shfl_sync(0xffffffffu, mine, e >> 2);
          if (lane == 0) sel[b * 8 + r] = e;
          wsel = selp(lane == r, sg_, wsel);
          wsum += sg_;
        }
        if (lane < TOPK) selw[b * 8 + lane] = wsel / wsum * 8.0f;
      }
      __syncthreads();
      // union of the chosen experts in ascending order (ballot prefix), and each token's slot in it
      int* cnt4 = (int*)(sc + 3330 + 1028);
      int f = 0;
      if (tid < NE) {
        for (int b = 0; b < B; b++)
#pragma unroll
          for (int r = 0; r < TOPK; r++) f |= sel[b * 8 + r] == tid;
      }
      const unsigned bal = __ballot_sync(0xffffffffu, f);
      if (tid < NE && lane == 0) cnt4[w] = __popc(bal);
      __syncthreads();
      if (tid < NE) {
        int idx = __popc(bal & ((1u << lane) - 1));
        for (int ww = 0; ww < w; ww++) idx += cnt4[ww];
        if (f) {
          uni[idx] = tid;
          for (int b = 0; b < MAXB; b++) {
            int sl = -1;
            if (b < B)
#pragma unroll
              for (int r = 0; r < TOPK; r++) sl = sel[b * 8 + r] == tid ? r : sl;
            uslot[idx * 8 + b] = sl;
          }
        }
        if (tid == 0) *nuni = cnt4[0] + cnt4[1] + cnt4[2] + cnt4[3];
      }
      __syncthreads();
    }
    const int U = *nuni;
    {
      const bool mx = L.mx != 0;
      const size_t c13 = mx ? (size_t)144 * 72 * 512 : (size_t)144 * 36 * 512, s13 = mx ? (size_t)144 * 72 * 16 : (size_t)144 * 36 * 64;
      const size_t pc13 = c13 / 144, ps13 = s13 / 144;      // bytes per strip
      const int N = U * 144, s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      for (int sidx = s0; sidx < s1; sidx++) {
        const int e = uni[sidx / 144], st = sidx % 144;
        if (USE_PF13 && tid == 0) pf_l2(L.w13 + e * c13 + st * pc13, (unsigned)pc13);
        if (USE_PF13 && tid == 32) pf_l2(L.w13s + e * s13 + st * ps13, (unsigned)ps13);
      }
      const size_t c2 = mx ? (size_t)144 * 36 * 512 : (size_t)144 * 18 * 512, s2s = mx ? (size_t)144 * 36 * 16 : (size_t)144 * 18 * 64;
      const int t0 = blk * 144 / nb, t1 = (blk + 1) * 144 / nb;
      for (int st = t0; st < t1; st++)
        for (int u = w; u < U; u += NW) {
          if ((USE_PF13 || PF_W2) && lane == 0) pf_l2(L.w2 + uni[u] * c2 + st * (c2 / 144), (unsigned)(c2 / 144));
          if ((USE_PF13 || PF_W2) && lane == 1) pf_l2(L.w2s + uni[u] * s2s + st * (s2s / 144), (unsigned)(s2s / 144));
        }
    }
    STAMP(4);

    // ---------------------------------------------------------------- phase G: expert gate|up projections
    {
      __half* x16 = (__half*)sIn;     // [8][XS]
      float* xsc = sc + 2600;         // per-token scale 2^-s
      if (w < B) {   // one warp per token: max |x| -> power-of-two scale -> exact f16 copy
        const uint4* xr = (const uint4*)(P.xm + (size_t)w * H);
        uint4 v[9];
#pragma unroll
        for (int i = 0; i < 9; i++) v[i] = __ldcg(xr + lane + 32 * i);
        float m = 0.f;
#pragma unroll
        for (int i = 0; i < 9; i++) {
          float f[8];
          unpack8(v[i], f);
#pragma unroll
          for (int e = 0; e < 8; e++) m = fmaxf(m, fabsf(f[e]));
        }
        m = warp_max(m);
        int ex = 0;
        if (m > 0.f) frexpf(m, &ex);         // m in [2^(ex-1), 2^ex)
        const int sh = 15 - ex;              // m * 2^sh in [2^14, 2^15)
        const float up = ldexpf(1.f, sh);
        if (lane == 0) { xsc[w] = ldexpf(1.f, -sh); xsc[8 + w] = up; }
#pragma unroll
        for (int i = 0; i < 9; i++) {
          float f[8];
          unpack8(v[i], f);
          __half2 hv[4];
#pragma unroll
          for (int e = 0; e < 4; e++) hv[e] = __floats2half2_rn(f[2 * e] * up, f[2 * e + 1] * up);
          *(uint4*)(x16 + w * XS + 8 * (lane + 32 * i)) = *(uint4*)hv;
        }
      }
      __syncthreads();
      STAMP(5);
      const int N = U * 144;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      const bool mx = L.mx != 0;
      const size_t cstride = mx ? (size_t)144 * 72 * 512 : (size_t)144 * 36 * 512;
      const size_t sstride = mx ? (size_t)144 * 72 * 16 : (size_t)144 * 36 * 64;
      block_strips(s0, s1, mx ? 72 : 36, red,
        [&](int s, int k0, int k1, float c[4]) {
          const int u = s / 144, st = s % 144, e = uni[u];
          if (mx) {
            const uint4* A = (const uint4*)(L.w13 + e * cstride) + (size_t)st * 72 * 32;
            const unsigned short* S = (const unsigned short*)(L.w13s + e * sstride) + (size_t)st * 72 * 8;
            strip_mx<4>(A, S, k0, k1, x16, B, c);
          } else {
            const uint4* A = (const uint4*)(L.w13 + e * cstride) + (size_t)st * 36 * 32;
            const uint2* S = (const uint2*)(L.w13s + e * sstride) + (size_t)st * 36 * 8;
            strip_nv<4>(A, S, k0, k1, x16, B, c);
          }
        },
        [&](int s, float c[4]) {
          const int u = s / 144, st = s % 144, e = uni[u];
          const unsigned g = lane >> 2, t = lane & 3;
          const float fe = mx ? 1.f : L.f13[e];
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) {
              const int sl = uslot[u * 8 + b];
              if (sl >= 0) {
                const float gg = c[h2] * xsc[b] * fe, uu = c[2 + h2] * xsc[b] * fe;
                float act = 4.f * tanhf(gg * 0.25f) * sigm(gg) * (25.f * tanhf(uu * 0.04f));
                act = rbf(act * selw[b * 8 + sl]);
                P.act[((size_t)b * 8 + sl) * IM + st * 8 + g] = __float2half_rn(act * 64.f);
              }
            }
          }
        });
    }
    GBAR(8);

    // ---------------------------------------------------------------- phase H: expert down projections
    {
      if (tid == 0) {
        const int an = a + 1;
        const App nx = an < NAPP ? app_of(an) : App{24, 0, -1};
        int idx[4];
        eH.nblk = attn_blk_idx(nx.layer, nx.pass, idx);
        for (int i = 0; i < eH.nblk; i++) eH.blkp[i] = P.blk + (size_t)idx[i] * MAXB * H;
        eH.two = 0;
        if (an < NAPP) {
          const LayerW& Ln = cL[nx.layer];
          eH.nq = Ln.glob ? 3 : 1;
          for (int j = 0; j < eH.nq; j++) eH.q[j] = Ln.aq + j * H;
        } else { eH.nq = 1; eH.q[0] = P.outq; }
        const bool ngated = an < NAPP && nx.pass >= 1;
        eH.restart = an < NAPP && nx.layer == 6 && nx.pass >= 1;
        eH.fi = eH.restart ? 5 + nx.pass - 1 : -1;
        eH.nm = ngated ? 2 : 0; eH.nmq = ngated ? 3 : 0; eH.m1F = eH.restart;
        if (ngated) {
          eH.m0 = P.blk + (size_t)(2 + nx.pass - 1) * MAXB * H;
          eH.m1 = P.blk + (size_t)(5 + nx.pass - 1) * MAXB * H;
          for (int j = 0; j < 3; j++) eH.mq[j] = P.loopq + ((size_t)(nx.layer - 6) * 4 + j) * H;
        }
        int bi = -1;
        if (an < NAPP) {
          if (nx.layer == 6 && nx.pass == 0) bi = 1;
          else if (nx.layer == 12) bi = 2 + nx.pass;
          else if (nx.layer == 18) bi = 7;
        }
        eH.bi = bi;
      }
      __half* actS = (__half*)sX;    // expert activations x 64 of all tokens: [B][8][1152] (fits in sX + sIn)
      __syncthreads();
      const bool mx = L.mx != 0;
      const int nkc = mx ? 36 : 18;                       // chunks per expert
      const size_t cstride = mx ? (size_t)144 * 36 * 512 : (size_t)144 * 18 * 512;
      const size_t sstride = mx ? (size_t)144 * 36 * 16 : (size_t)144 * 18 * 64;
      const int N = 144;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      bf16* mr = P.mring + (size_t)slot * MAXB * 4 * H;
      block_strips(s0, s1, U * nkc, red,
        [&](int st, int k0, int k1, float c[4]) {
          const unsigned g = lane >> 2, t = lane & 3;
          int kq = k0;
          while (kq < k1) {
            const int u = kq / nkc, e = uni[u];
            const int ce = (u + 1) * nkc < k1 ? (u + 1) * nkc : k1;
            const int cl0 = kq - u * nkc, cl1 = ce - u * nkc;
            // B operand: act of token g in expert u (zero if unused)
            const int sl = g < (unsigned)B ? uslot[u * 8 + g] : -1;
            const __half* ab = P.act + ((size_t)g * 8 + (sl < 0 ? 0 : sl)) * IM + 2 * t;
            float tmp[4] = {0.f, 0.f, 0.f, 0.f};
            if (mx) {
              const uint4* A = (const uint4*)(L.w2 + e * cstride) + (size_t)st * 36 * 32;
              const unsigned short* S = (const unsigned short*)(L.w2s + e * sstride) + (size_t)st * 36 * 8;
              for (int ch = cl0; ch < cl1; ch++) {
                const uint4 av = ldw(A + (size_t)ch * 32 + lane);
                const unsigned short sv = ldw16(S + (size_t)ch * 8 + g);
                float tt[4] = {0.f, 0.f, 0.f, 0.f};
                for (int q = 0; q < 2; q++) {
                  uint32_t r[4];
                  const uint32_t w0 = (&av.x)[2 * q], w1 = (&av.x)[2 * q + 1];
                  r[0] = e4m3x2((unsigned short)(w0 & 0xffff)); r[1] = e4m3x2((unsigned short)(w0 >> 16));
                  r[2] = e4m3x2((unsigned short)(w1 & 0xffff)); r[3] = e4m3x2((unsigned short)(w1 >> 16));
                  const int kk = ch * 32 + q * 16;
                  uint32_t b0 = 0, b1 = 0;
                  if (sl >= 0) { b0 = __ldcg((const unsigned*)(ab + kk)); b1 = __ldcg((const unsigned*)(ab + kk + 8)); }
                  mma_f16(tt, r, b0, b1);
                }
                const float sg = e8m0(sv & 0xff), sg8 = e8m0(sv >> 8);
                tmp[0] = fmaf(tt[0], sg, tmp[0]); tmp[1] = fmaf(tt[1], sg, tmp[1]);
                tmp[2] = fmaf(tt[2], sg8, tmp[2]); tmp[3] = fmaf(tt[3], sg8, tmp[3]);
              }
            } else {
              const uint4* A = (const uint4*)(L.w2 + e * cstride) + (size_t)st * 18 * 32;
              const uint2* S = (const uint2*)(L.w2s + e * sstride) + (size_t)st * 18 * 8;
              for (int ch = cl0; ch < cl1; ch++) {
                const uint4 av = ldw(A + (size_t)ch * 32 + lane);
                const uint2 sv = ldw2(S + (size_t)ch * 8 + g);
                for (int q = 0; q < 4; q++) {
                  uint32_t r[4];
                  e2m1x8((&av.x)[q], r);
                  const uint32_t sp = (q < 2 ? sv.x : sv.y) >> (16 * (q & 1));
                  const uint32_t scv = e4m3x2((unsigned short)(sp & 0xffff));
                  const uint32_t sg = lo2(scv), sg8 = hi2(scv);
                  r[0] = hmul2(r[0], sg); r[2] = hmul2(r[2], sg); r[1] = hmul2(r[1], sg8); r[3] = hmul2(r[3], sg8);
                  const int kk = ch * 64 + q * 16;
                  uint32_t b0 = 0, b1 = 0;
                  if (sl >= 0) { b0 = __ldcg((const unsigned*)(ab + kk)); b1 = __ldcg((const unsigned*)(ab + kk + 8)); }
                  mma_f16(tmp, r, b0, b1);
                }
              }
            }
            const float fe = mx ? 1.f : L.f2[e];
            for (int i = 0; i < 4; i++) c[i] = fmaf(tmp[i], fe, c[i]);
            kq = ce;
          }
        },
        [&](int st, float c[4]) { epi_h(P, eH, L, a, layer, slot, pos, B, st, make_float4(c[0], c[1], c[2], c[3]));         });
    }
    GBAR(9);
  }

  // ------------------------------------------------------------------ head: final mix, norm, unembedding
  {
    __syncthreads();
    if (tid == 0) {
      DotSet& d = sdA;
      d.nm = 0; d.nmq = 0;
      d.nv = attn_blocks(P, 24, 0, d.S);
      d.S[d.nv++] = mksrc(P.pbuf + (size_t)(NAPP & 1) * MAXB * H, H, 1);
      d.nq = 1; d.q[0] = P.outq;
    }
    __syncthreads();
    Src* fs = sdA.S;
    const int n = sdA.nv;
    reduce_parts(P.hpart, B, n, 1, 0, 0, sc + SC_DOT, red);
    if (tid < B) coefs(sc + SC_DOT + tid * 64, n, 0, false, false, sc + SC_CFX + tid * 8);
    __syncthreads();
    bf16* hs = sIn;
    for (int p = tid; p < B * NC8; p += NT) {
      const int b = p / NC8, c = p % NC8;
      float x[8], wv[8];
      const float* cf = sc + SC_CFX + b * 8;
      mix8(fs, n, cf, b, c, x);
      ldw8(P.finalnorm, c, wv);
      for (int e = 0; e < 8; e++) x[e] = x[e] * cf[7] * wv[e];
      *(uint4*)(hs + b * XS + 8 * c) = pack8(x);
    }
    __syncthreads();
    const int N = VSTRIPS;
    const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
    __shared__ unsigned long long skey[MAXB];
    if (tid < MAXB) skey[tid] = 0ull;
    __syncthreads();
    if (P.skq && P.outkey && !P.logits && !P.nohead) {
      // track B: certified 8-bit sketch, then exact rescoring of the candidate strips (greedy path only)
      int8_t* xd = (int8_t*)(sIn + B * XS);   // [B][hi 2304 | lo 2304]
      float* xsc = sc + SC_XSC;           // [8] 2^-k
      float* xnrm = sc + SC_XSC + 8;      // [8] |x|_2 rounded up
      float* dxn = sc + SC_XSC + 16;      // [8] bound of |x - X 2^-k|_2
      __shared__ unsigned slo[MAXB];
      if (tid < MAXB) slo[tid] = 0u;
      if (w < B) {
        const uint4* xr = (const uint4*)(hs + w * XS);
        uint4 v[9];
#pragma unroll
        for (int i = 0; i < 9; i++) v[i] = xr[lane + 32 * i];
        float m = 0.f, ss = 0.f;
#pragma unroll
        for (int i = 0; i < 9; i++) {
          float f[8];
          unpack8(v[i], f);
#pragma unroll
          for (int e = 0; e < 8; e++) { m = fmaxf(m, fabsf(f[e])); ss = fmaf(f[e], f[e], ss); }
        }
        m = warp_max(m);
        ss = warp_sum(ss);
        int ex = 0;
        if (m > 0.f) frexpf(m, &ex);        // m < 2^ex
        const int kk = 13 - ex;              // |x| 2^kk < 2^13 = 8192: X = round(x 2^kk) in [-8192, 8192]
        const float up = ldexpf(1.f, kk);
        if (lane == 0) {
          xsc[w] = ldexpf(1.f, -kk);
          xnrm[w] = sqrtf(ss) * (1.f + 1.f / 1024.f);
          dxn[w] = 48.f * ldexpf(1.f, -kk - 1) * 1.001f;   // sqrt(2304) x half an LSB
        }
        int8_t* hi = xd + w * XDS;
        int8_t* lo = hi + H;
#pragma unroll
        for (int i = 0; i < 9; i++) {
          float f[8];
          unpack8(v[i], f);
          char hb[8], lb[8];
#pragma unroll
          for (int e = 0; e < 8; e++) {
            const int X = __float2int_rn(f[e] * up);
            const int hh = (X + 64) >> 7;            // floor((X + 64) / 128): X = 128 hh + ll, ll in [-64, 63]
            hb[e] = (char)hh; lb[e] = (char)(X - 128 * hh);
          }
          *(uint2*)(hi + 8 * (lane + 32 * i)) = *(uint2*)hb;
          *(uint2*)(lo + 8 * (lane + 32 * i)) = *(uint2*)lb;
        }
      }
      __syncthreads();
      sketch_pass1(P, xd, xsc, xnrm, dxn, B, s0, s1, red, slo);
      __syncthreads();
      if (tid < B) atomicMax(P.sklo + tid, slo[tid]);
      gbar(bar, bt, nb);
      sketch_pass2(P, hs, B, s0, s1, skey, red);
    } else if (!P.nohead) gemv_head(P.unemb, hs, B, s0, s1, P.logits, red, P.outkey ? skey : nullptr);
    if (P.outkey) {
      __syncthreads();
      if (tid < B) atomicMax(P.outkey + tid, skey[tid]);
      __shared__ unsigned s_lastblk;
      __threadfence();
      __syncthreads();
      if (tid == 0) s_lastblk = atomicAdd(P.sync + 1, 1u) == (unsigned)(nb - 1);
      __syncthreads();
      if (s_lastblk && P.hostout) {   // every block's keys are in: publish the tokens to the host
        __threadfence();
        if (tid < B) P.hostout[tid] = (int)(0xffffffffu - (unsigned)(__ldcg(P.outkey + tid) & 0xffffffffu));
        __threadfence_system();
        __syncthreads();
        if (tid == 0) { *(volatile int*)(P.hostout + MAXB) = (int)P.seq; __threadfence_system(); }
      }
    }
  }
  if (P.prof) { __syncthreads(); if (tid == 0) P.prof[8192 + pidx * 160 + blk] = gtime(); }
  // advance positions: all blocks are past every read of pos (grid barriers above)
  if (blk == 0 && tid < B) P.pos[tid] = pos + 1;
}

// ------------------------------------------------------------------------------------------------ host API
extern "C" {
int mk_sizes(int* out) { out[0] = sizeof(LayerW); out[1] = sizeof(Params); return 0; }

int mk_rp_prof(long long* out) { cudaMemcpyFromSymbol(out, RP_PROF_BUF, 64); long long z[8] = {0}; cudaMemcpyToSymbol(RP_PROF_BUF, z, 64); return 0; }
int mk_set_layers(const void* host_layers) {
  return (int)cudaMemcpyToSymbol(cL, host_layers, sizeof(LayerW) * 24);
}
int mk_launch(const void* params, int nb, void* stream) {
  static bool init = false;
  if (!init) {
    cudaFuncSetAttribute(mk_step, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES);
    init = true;
  }
  Params p;
  memcpy(&p, params, sizeof(Params));
  cudaStream_t s = (cudaStream_t)stream;
  cudaMemsetAsync(p.sync, 0, (64 + NAPP * MAXB * NHKV) * sizeof(unsigned), s);
  void* args[] = {&p};
  cudaError_t e = cudaLaunchCooperativeKernel((const void*)mk_step, dim3(nb), dim3(NT), args, smem_bytes((int)p.B), s);
  return (int)e;
}
int mk_occupancy() {
  int n = 0;
  cudaFuncSetAttribute(mk_step, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES);
  cudaOccupancyMaxActiveBlocksPerMultiprocessor(&n, mk_step, NT, SMEM_BYTES);
  return n;
}
const char* mk_err(int e) { return cudaGetErrorString((cudaError_t)e); }
}

// conversion-order self test: out[0..7] = e2m1x8(0x76543210) as floats, out[8..9] = e4m3x2(0x4038) (1.0 lo?, 2.0?)
__global__ void k_cvt_test(float* out) {
  uint32_t r[4];
  e2m1x8(0x00002301u, r);  // byte0 = 0x01 -> (lo nibble 1 = 0.5, hi 0), byte1 = 0x23 -> (lo 3 = 1.5, hi 2 = 1.0)
  for (int i = 0; i < 2; i++) { __half2 h = *(__half2*)&r[i]; out[2 * i] = __low2float(h); out[2 * i + 1] = __high2float(h); }
  uint32_t s = e4m3x2((unsigned short)0x4038);  // lo byte 0x38 = 1.0, hi byte 0x40 = 2.0
  __half2 h = *(__half2*)&s; out[4] = __low2float(h); out[5] = __high2float(h);
}
extern "C" int mk_cvt_test(float* out) { k_cvt_test<<<1, 1>>>(out); return (int)cudaDeviceSynchronize(); }

// standalone dot-pass timing: n repetitions over sources in global memory (bench only)
__global__ void __launch_bounds__(NT, 1) k_dot_bench(const bf16* srcs, const float* q, int nv, int nq, int B, int reps, unsigned long long* t) {
  extern __shared__ __align__(16) uint8_t smem[];
  __shared__ DotSet sd;
  float* part = (float*)smem;
  float* out = part + 8 * 9 * 64;
  if (threadIdx.x == 0) {
    sd.nv = nv; sd.nq = nq; sd.nm = 0; sd.nmq = 0;
    for (int i = 0; i < nv; i++) sd.S[i] = mksrc(srcs + (size_t)i * MAXB * H, H, 0);
    for (int j = 0; j < nq; j++) sd.q[j] = q + j * H;
  }
  __syncthreads();
  unsigned long long t0 = gtime();
  __shared__ long long ts[8];
  if (threadIdx.x < 8) ts[threadIdx.x] = 0;
  __syncthreads();
  for (int r = 0; r < reps; r++) dot_pass_t(sd, B, part, out, (threadIdx.x & 31) == 0 && threadIdx.x == 0 ? ts : nullptr);
  if (threadIdx.x == 0 && blockIdx.x == 0) { t[0] = gtime() - t0; for (int i = 0; i < 5; i++) t[2 + i] = ts[i]; }
}
extern "C" int mk_dot_bench(const void* srcs, const void* q, int nv, int nq, int B, int reps, void* t) {
  cudaFuncSetAttribute(k_dot_bench, cudaFuncAttributeMaxDynamicSharedMemorySize, 64 * 1024);
  k_dot_bench<<<152, NT, 64 * 1024>>>((const bf16*)srcs, (const float*)q, nv, nq, B, reps, (unsigned long long*)t);
  return (int)cudaDeviceSynchronize();
}

// standalone GEMV timing over bf16 tiles (bench only): N strips x NK k-tiles, x in smem, output to out
template <int U>
__global__ void __launch_bounds__(NT, 1) k_gemv_bench(const uint4* A, int N, int NK, int B, int reps, float* out, unsigned long long* t) {
  extern __shared__ __align__(16) uint8_t smem[];
  bf16* xs = (bf16*)smem;
  float* red = (float*)(xs + MAXB * XS);
  for (int i = threadIdx.x; i < MAXB * XS; i += NT) xs[i] = __float2bfloat16(0.001f * (i % 97));
  __syncthreads();
  const int lane = threadIdx.x & 31;
  unsigned long long t0 = gtime();
  for (int r = 0; r < reps; r++) {
    const int s0 = blockIdx.x * N / gridDim.x, s1 = (blockIdx.x + 1) * N / gridDim.x;
    block_strips(s0, s1, NK, red,
      [&](int s, int k0, int k1, float c[4]) { strip_bf16<U>(A + (size_t)s * NK * 32, k0, k1, xs, B, c); },
      [&](int s, float c[4]) { if (lane == 0) out[s] = c[0]; });
    __syncthreads();
  }
  if (threadIdx.x == 0 && blockIdx.x == 0) t[0] = gtime() - t0;
}
extern "C" int mk_gemv_bench(const void* A, int N, int NK, int B, int reps, int U, void* out, void* t) {
  const int sm = MAXB * XS * 2 + NW * 32 * 16;
  if (U == 8) {
    cudaFuncSetAttribute(k_gemv_bench<8>, cudaFuncAttributeMaxDynamicSharedMemorySize, sm);
    k_gemv_bench<8><<<152, NT, sm>>>((const uint4*)A, N, NK, B, reps, (float*)out, (unsigned long long*)t);
  } else if (U == 16) {
    cudaFuncSetAttribute(k_gemv_bench<16>, cudaFuncAttributeMaxDynamicSharedMemorySize, sm);
    k_gemv_bench<16><<<152, NT, sm>>>((const uint4*)A, N, NK, B, reps, (float*)out, (unsigned long long*)t);
  } else {
    cudaFuncSetAttribute(k_gemv_bench<4>, cudaFuncAttributeMaxDynamicSharedMemorySize, sm);
    k_gemv_bench<4><<<152, NT, sm>>>((const uint4*)A, N, NK, B, reps, (float*)out, (unsigned long long*)t);
  }
  return (int)cudaDeviceSynchronize();
}

// standalone NVFP4 GEMV timing (bench only): N strips x 36 chunks, x16 in smem
template <int U>
__global__ void __launch_bounds__(NT, 1) k_nv_bench(const uint4* A, const uint2* S, int N, int B, unsigned long long* t, float* out) {
  extern __shared__ __align__(16) uint8_t smem[];
  __half* xs = (__half*)smem;
  float* red = (float*)(xs + MAXB * XS);
  for (int i = threadIdx.x; i < MAXB * XS; i += NT) xs[i] = __float2half(0.001f * (i % 97));
  __syncthreads();
  const int lane = threadIdx.x & 31;
  unsigned long long t0 = gtime();
  const int s0 = blockIdx.x * N / gridDim.x, s1 = (blockIdx.x + 1) * N / gridDim.x;
  block_strips(s0, s1, 36, red,
    [&](int s, int k0, int k1, float c[4]) { strip_nv<U>(A + (size_t)s * 36 * 32, S + (size_t)s * 36 * 8, k0, k1, xs, B, c); },
    [&](int s, float c[4]) { if (lane == 0) out[s] = c[0]; });
  __syncthreads();
  if (threadIdx.x == 0) t[blockIdx.x] = gtime() - t0;
}
extern "C" int mk_nv_bench(const void* A, const void* S, int N, int B, int U, void* t, void* out) {
  const int sm = MAXB * XS * 2 + NW * 32 * 16;
#define NVB(u) if (U == u) { cudaFuncSetAttribute(k_nv_bench<u>, cudaFuncAttributeMaxDynamicSharedMemorySize, sm); \
    k_nv_bench<u><<<152, NT, sm>>>((const uint4*)A, (const uint2*)S, N, B, (unsigned long long*)t, (float*)out); }
  NVB(2) NVB(4) NVB(6) NVB(8) NVB(12)
  return (int)cudaDeviceSynchronize();
}
