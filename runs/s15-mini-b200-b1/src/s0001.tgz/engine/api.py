"""Inkling-2-Mini decode engine: one persistent cooperative CUDA kernel per decode step (engine/mk.cu), weights
packed at load (engine/pack.py). Contract: Engine(model_dir, max_batch, max_context), reset(), step(tokens[B]),
generate(), stats().
"""
import ctypes
import os
import struct
from pathlib import Path

import torch

from pack import Weights

HERE = Path(__file__).resolve().parent
MAXB = 8
H = 2304
VOCAB = 200058
NAPP = 48

LAYER_FIELDS = ["wqkv", "wo", "wr", "rbias", "w13", "w13s", "f13", "w2", "w2s", "f2", "normq", "normk", "normv",
                "mlpnorm", "kconv", "vconv", "aconv", "mconv", "qscale", "rscale", "relp", "aq", "mq", "cdown",
                "cforget", "cgain", "glob", "mx", "nstrip", "koff", "voff", "kpoff", "vpoff"]
PARAM_FIELDS = ["L", "emb", "embnorm", "finalnorm", "outq", "loopq", "unemb", "tok", "pos", "logits", "kc", "vc",
                "kring", "vring", "oring", "mring", "blk", "pbuf", "att", "xm", "qkv", "ao", "apart", "gpart", "coef",
                "xg", "rpart", "act", "sync", "dbg", "prof", "ctx", "B", "nb"]


def _ptr(x):
    if x is None:
        return 0
    if isinstance(x, int):
        return x & 0xFFFFFFFFFFFFFFFF
    return x.data_ptr()


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        assert 1 <= max_batch <= MAXB, max_batch
        self.lib = ctypes.CDLL(str(HERE / "build" / "libmk.so"))
        self.lib.mk_launch.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
        self.lib.mk_err.restype = ctypes.c_char_p
        sizes = (ctypes.c_int * 2)()
        self.lib.mk_sizes(sizes)
        assert sizes[0] == 8 * len(LAYER_FIELDS) and sizes[1] == 8 * len(PARAM_FIELDS), (sizes[0], sizes[1])
        self.max_batch, self.max_context = max_batch, max_context
        dev = torch.device("cuda")
        self.w = Weights(model_dir, dev)
        occ = self.lib.mk_occupancy()
        assert occ >= 1, "kernel does not fit on an SM"
        self.nb = torch.cuda.get_device_properties(0).multi_processor_count
        ctx = max_context
        bf, f32 = torch.bfloat16, torch.float32
        z = lambda *s, dt=bf: torch.zeros(*s, dtype=dt, device=dev)  # noqa: E731
        self.buf = dict(
            pos=z(MAXB, dt=torch.int32), logits=z(MAXB, VOCAB, dt=f32),
            kc=z(NAPP, MAXB, 8, ctx, 128), vc=z(NAPP, MAXB, 8, ctx, 128),
            kring=z(NAPP, MAXB, 4, 1024), vring=z(NAPP, MAXB, 4, 1024),
            oring=z(NAPP, MAXB, 4, H), mring=z(NAPP, MAXB, 4, H),
            blk=z(8, MAXB, H), pbuf=z(2, MAXB, H), att=z(MAXB, H), xm=z(MAXB, H),
            qkv=z(MAXB, 8704, dt=f32), ao=z(MAXB, 3072), apart=z(MAXB, 24, 40, 132, dt=f32),
            gpart=z(32768, dt=f32), coef=z(1024, dt=f32), xg=z(3, MAXB, H, dt=f32), rpart=z(MAXB, 16, 128, dt=f32),
            act=z(MAXB, 8, 1152, dt=torch.float16), sync=z(64 + NAPP * MAXB * 8, dt=torch.int32),
        )
        self.dbg = None
        self.prof = None
        lw = []
        for L in self.w.layers:
            lw += [_ptr(L[f]) if not isinstance(L[f], int) else (L[f] & 0xFFFFFFFFFFFFFFFF) for f in LAYER_FIELDS]
        blob = struct.pack(f"<{len(lw)}Q", *lw)
        self.layer_dev = torch.frombuffer(bytearray(blob), dtype=torch.uint8).to(dev)
        self.pos = 0
        self.B = None
        self.steps = 0
        self._tok = None

    def _params(self, tok, B):
        w, b = self.w, self.buf
        vals = dict(L=self.layer_dev, emb=w.emb, embnorm=w.embnorm, finalnorm=w.finalnorm, outq=w.outq, loopq=w.loopq,
                    unemb=w.unemb, tok=tok, dbg=self.dbg, prof=self.prof, ctx=self.max_context, B=B, nb=self.nb, **b)
        arr = [_ptr(vals[f]) for f in PARAM_FIELDS]
        return ctypes.create_string_buffer(struct.pack(f"<{len(arr)}Q", *arr), 8 * len(arr))

    def reset(self) -> None:
        self.pos = 0
        self.B = None
        self.buf["pos"].zero_()

    @torch.no_grad()
    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        B = int(tokens.shape[0])
        if B < 1 or B > self.max_batch:
            raise ValueError(f"batch {B} outside 1..{self.max_batch}")
        if self.B is None:
            self.B = B
        elif B != self.B:
            raise ValueError("batch size changed without reset()")
        if self.pos >= self.max_context:
            raise ValueError(f"context full ({self.max_context} positions)")
        tok = tokens.to(device="cuda", dtype=torch.int64).contiguous()
        self._tok = tok
        params = self._params(tok, B)
        stream = torch.cuda.current_stream().cuda_stream
        err = self.lib.mk_launch(params, self.nb, ctypes.c_void_p(stream))
        if err != 0:
            raise RuntimeError("mk_launch: " + self.lib.mk_err(err).decode())
        self.pos += 1
        self.steps += 1
        return self.buf["logits"][:B]

    def close(self) -> None:
        self.w = None
        self.buf = None

    def stats(self) -> dict:
        return {"implementation": "mk persistent kernel", "track": "A", "steps": self.steps}
