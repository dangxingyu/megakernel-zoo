// Inkling-2-Mini decode engine: one persistent cooperative kernel per decode step on one B200.
// Track A: the checkpoint's formats (BF16 dense weights, NVFP4 / MXFP8 experts with their block scales), the
// specification's data flow (unquantized BF16 expert inputs). See notes/design.md for layouts and phases.
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef __nv_bfloat16 bf16;

#define H 2304
#define QD 3072
#define KVD 1024
#define NHQ 24
#define NHKV 8
#define HD 128
#define NE 128
#define TOPK 8
#define IM 1152
#define DREL 16
#define RELX 1024
#define WIN 1024
#define MAXB 8
#define NT 512
#define NW 16
#define XS (H + 8)            // smem row stride (elements) of token vectors
#define NAPP 48
#define VOCAB 200058          // real vocabulary (output columns)
#define VSTRIPS 12504         // 16-row strips of the unembedding covering it
#define CH 64                 // attention positions per work unit
#define MAXCH 40              // max chunks (context <= 2560)
#define GSEG 12               // k segments of the controller down projection (attn gates)
#define MSEG 36               // k segments of the controller down projection (mlp gate)
#define RSEG 16               // k segments of the router

// ------------------------------------------------------------------------------------------------ parameters
struct LayerW {               // all fields 8 bytes (host packs them as uint64)
  const uint4* wqkv;          // bf16 tiles [strips][144][32] (rows: q | gate | r | sink+pad | k (| kproj) | v (| vproj))
  const uint4* wo;            // [144 strips][192][32]
  const uint4* wr;            // router [8][144][32]
  const float* rbias;         // [128]
  const uint8_t* w13;         // experts, packed per expert (see pack.py)
  const uint8_t* w13s;
  const float* f13;           // [128] amax / denominator (nvfp4)
  const uint8_t* w2;
  const uint8_t* w2s;
  const float* f2;
  const bf16* normq;          // attn_norm (local) or q_input_norm
  const bf16* normk;
  const bf16* normv;
  const bf16* mlpnorm;
  const bf16* kconv;          // local [1024][4] (tap 3 = current); global static_w [4][1024] (lag 0 = current)
  const bf16* vconv;
  const bf16* aconv;          // [2304][4]
  const bf16* mconv;
  const bf16* qscale;         // [24][128]
  const bf16* rscale;         // [24][16]
  const bf16* relp;           // [16][1024]
  const float* aq;            // attention-residual queries [nq][2304] (layer 0: null)
  const float* mq;            // [2304]
  const uint4* cdown;         // controllers down [4 gates (q,k,v,mlp)][4 strips][288][32] bf16 tiles (loop layers)
  const bf16* cforget;        // [4][2304][64]
  const bf16* cgain;          // [4][2304][64]
  long long glob;
  long long mx;               // experts are MXFP8
  long long nstrip;           // qkv strips
  long long koff;             // first k row in the qkv output
  long long voff;             // first v row
  long long kpoff;            // global: first kproj row (-1 local)
  long long vpoff;
};

struct Params {
  const LayerW* L;            // [24]
  const bf16* emb;            // [201024][2304]
  const bf16* embnorm;
  const bf16* finalnorm;
  const float* outq;          // [2304]
  const float* loopq;         // [12][4][2304]
  const uint4* unemb;         // [12564][144][32] tiles
  const long long* tok;       // [B] int64 input tokens
  int* pos;                   // [MAXB] position of every slot
  float* logits;              // [B][VOCAB]
  bf16* kc;                   // K cache [48 slots][MAXB][8][ctx][128]
  bf16* vc;
  bf16* kring;                // raw K projection history [48][MAXB][4][1024]
  bf16* vring;
  bf16* oring;                // raw attention output-projection history [48][MAXB][4][2304]
  bf16* mring;                // raw MoE output history [48][MAXB][4][2304]
  bf16* blk;                  // block states [8][MAXB][2304]: 0 h0, 1 P5, 2-4 P11 pass 0-2, 5-7 P17 pass 0-2
  bf16* pbuf;                 // entering partial, ping-pong [2][MAXB][2304]
  bf16* att;                  // attention output after conv [MAXB][2304]
  bf16* xm;                   // normalized MoE input [MAXB][2304]
  float* qkv;                 // [MAXB][8704]
  bf16* ao;                   // gated attention output [MAXB][3072]
  float* apart;               // attention partials [MAXB][24][MAXCH][132]
  float* gpart;               // controller partials [MAXB][3][GSEG or MSEG][64]
  float* coef;                // stream coefficients [MAXB][8][8]
  float* xg;                  // gated streams [3][MAXB][2304]
  float* rpart;               // router partials [MAXB][RSEG][128]
  __half* act;                // expert activations x 64 [MAXB][8][1152]
  unsigned* sync;             // [0] grid barrier, [64..] attention combine counters [48][MAXB][8]
  float* dbg;                 // optional [48][MAXB][2304] entering partial of every application
  unsigned long long* prof;   // optional: (globaltimer, phase code) after every grid barrier, block 0
  long long ctx;
  long long B;
  long long nb;               // grid size
};

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ unsigned lane_id() { unsigned r; asm("mov.u32 %0, %%laneid;" : "=r"(r)); return r; }
__device__ __forceinline__ float warp_sum(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v += __shfl_xor_sync(0xffffffffu, v, o);
  return v;
}
__device__ __forceinline__ float warp_max(float v) {
#pragma unroll
  for (int o = 16; o; o >>= 1) v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, o));
  return v;
}
__device__ __forceinline__ uint4 ldw(const uint4* p) {   // streamed weights
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldw2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ unsigned short ldw16(const void* p) {
  unsigned short r;
  asm volatile("ld.global.nc.L1::no_allocate.u16 %0, [%1];" : "=h"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ float ldbf(const bf16* p) {      // activation written in this launch: L2
  unsigned short r;
  asm volatile("ld.global.cg.u16 %0, [%1];" : "=h"(r) : "l"(p));
  return __uint_as_float(((unsigned)r) << 16);
}
__device__ __forceinline__ float ldf(const float* p) { return __ldcg(p); }
__device__ __forceinline__ float rbf(float x) { return __bfloat162float(__float2bfloat16(x)); }   // round to bf16
__device__ __forceinline__ float sigm(float x) { return 1.f / (1.f + __expf(-x)); }

__device__ __forceinline__ void mma_bf16(float c[4], const uint32_t a[4], uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_f16(float c[4], const uint32_t a[4], uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b0), "r"(b1));
}
// 4 bytes of E2M1 pairs -> 4 f16x2 (low nibble -> low half)
__device__ __forceinline__ void e2m1x8(uint32_t w, uint32_t o[4]) {
  asm("{\n.reg .b8 b0, b1, b2, b3;\nmov.b32 {b0, b1, b2, b3}, %4;\n"
      "cvt.rn.f16x2.e2m1x2 %0, b0;\ncvt.rn.f16x2.e2m1x2 %1, b1;\ncvt.rn.f16x2.e2m1x2 %2, b2;\ncvt.rn.f16x2.e2m1x2 %3, b3;\n}"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
__device__ __forceinline__ uint32_t e4m3x2(unsigned short v) {
  uint32_t r;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(v));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) {
  uint32_t r;
  asm("mul.rn.f16x2 %0, %1, %2;" : "=r"(r) : "r"(a), "r"(b));
  return r;
}
__device__ __forceinline__ uint32_t lo2(uint32_t x) { return __byte_perm(x, 0, 0x1010); }
__device__ __forceinline__ uint32_t hi2(uint32_t x) { return __byte_perm(x, 0, 0x3232); }
__device__ __forceinline__ float e8m0(unsigned s) { return s ? __uint_as_float(s << 23) : __uint_as_float(0x00400000u); }

__device__ __forceinline__ unsigned ld_acquire(const unsigned* p) {
  unsigned v;
  asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory");
  return v;
}
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); return t; }
__device__ __forceinline__ void gbar(unsigned* ctr, unsigned& target, int nb) {
  __syncthreads();
  target += nb;
  if (threadIdx.x == 0) {
    __threadfence();
    atomicAdd(ctr, 1u);
    while (ld_acquire(ctr) < target) { }
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ strip kernels
// One warp: C fragment (rows g, g+8; tokens 2t, 2t+1) of a 16-row strip over k tiles [k0, k1).
// x: smem token rows [8][XS] (bf16 or f16), tokens >= B read as zero.
template <int U>
__device__ __forceinline__ void strip_bf16(const uint4* A, int k0, int k1, const bf16* xs, int B, float c[4]) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  const bf16* xr = xs + g * XS + 2 * t;
  const bool on = g < (unsigned)B;
  for (int k = k0; k < k1; k += U) {
    uint4 a[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (k + u < k1) a[u] = ldw(A + (size_t)(k + u) * 32 + lane);
#pragma unroll
    for (int u = 0; u < U; u++)
      if (k + u < k1) {
        uint32_t b0 = 0, b1 = 0;
        if (on) { b0 = *(const uint32_t*)(xr + (k + u) * 16); b1 = *(const uint32_t*)(xr + (k + u) * 16 + 8); }
        mma_bf16(c, (const uint32_t*)&a[u], b0, b1);
      }
  }
}

// NVFP4: chunk = 64 k (4 MMAs). A: [chunk][32 lanes] uint4 codes; S: [chunk][8 g] uint2 scale pairs.
template <int U>
__device__ __forceinline__ void strip_nv(const uint4* A, const uint2* S, int c0, int c1, const __half* xs, int B, float c[4]) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  const __half* xr = xs + g * XS + 2 * t;
  const bool on = g < (unsigned)B;
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    uint2 s[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) { a[u] = ldw(A + (size_t)(ch + u) * 32 + lane); s[u] = ldw2(S + (size_t)(ch + u) * 8 + g); }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
#pragma unroll
        for (int q = 0; q < 4; q++) {
          uint32_t r[4];
          e2m1x8((&a[u].x)[q], r);
          const uint32_t sp = (q < 2 ? s[u].x : s[u].y) >> (16 * (q & 1));
          const uint32_t sc = e4m3x2((unsigned short)(sp & 0xffff));
          const uint32_t sg = lo2(sc), sg8 = hi2(sc);
          r[0] = hmul2(r[0], sg); r[2] = hmul2(r[2], sg); r[1] = hmul2(r[1], sg8); r[3] = hmul2(r[3], sg8);
          uint32_t b0 = 0, b1 = 0;
          const int kk = (ch + u) * 64 + q * 16;
          if (on) { b0 = *(const uint32_t*)(xr + kk); b1 = *(const uint32_t*)(xr + kk + 8); }
          mma_f16(c, r, b0, b1);
        }
      }
  }
}

// MXFP8: chunk = 32 k (2 MMAs), scale per (row, chunk) applied after the chunk's MMAs. A: [chunk][32] uint4; S: [chunk][8 g] u16.
template <int U>
__device__ __forceinline__ void strip_mx(const uint4* A, const unsigned short* S, int c0, int c1, const __half* xs, int B, float c[4]) {
  const unsigned lane = lane_id(), g = lane >> 2, t = lane & 3;
  const __half* xr = xs + g * XS + 2 * t;
  const bool on = g < (unsigned)B;
  for (int ch = c0; ch < c1; ch += U) {
    uint4 a[U];
    unsigned short s[U];
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) { a[u] = ldw(A + (size_t)(ch + u) * 32 + lane); s[u] = ldw16(S + (size_t)(ch + u) * 8 + g); }
#pragma unroll
    for (int u = 0; u < U; u++)
      if (ch + u < c1) {
        float tmp[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
        for (int q = 0; q < 2; q++) {
          uint32_t r[4];
          const uint32_t w0 = (&a[u].x)[2 * q], w1 = (&a[u].x)[2 * q + 1];
          r[0] = e4m3x2((unsigned short)(w0 & 0xffff)); r[1] = e4m3x2((unsigned short)(w0 >> 16));
          r[2] = e4m3x2((unsigned short)(w1 & 0xffff)); r[3] = e4m3x2((unsigned short)(w1 >> 16));
          uint32_t b0 = 0, b1 = 0;
          const int kk = (ch + u) * 32 + q * 16;
          if (on) { b0 = *(const uint32_t*)(xr + kk); b1 = *(const uint32_t*)(xr + kk + 8); }
          mma_f16(tmp, r, b0, b1);
        }
        const float sg = e8m0(s[u] & 0xff), sg8 = e8m0(s[u] >> 8);
        c[0] = fmaf(tmp[0], sg, c[0]); c[1] = fmaf(tmp[1], sg, c[1]);
        c[2] = fmaf(tmp[2], sg8, c[2]); c[3] = fmaf(tmp[3], sg8, c[3]);
      }
  }
}

// Block-level: strips [s0, s1); each has NK k units. fn(strip, k0, k1, c) accumulates; epi(strip, c) consumes the
// final fragment (one warp per strip). Deterministic: the k split of a strip depends only on the strip count.
template <class F, class E>
__device__ __forceinline__ void block_strips(int s0, int s1, int NK, float* red, F fn, E epi) {
  const int n = s1 - s0;
  if (n <= 0) return;
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  if (n >= NW) {
    for (int s = s0 + w; s < s1; s += NW) {
      float c[4] = {0.f, 0.f, 0.f, 0.f};
      fn(s, 0, NK, c);
      epi(s, c);
    }
    return;
  }
  const int ks = NW / n, si = w / ks, kk = w % ks;
  float c[4] = {0.f, 0.f, 0.f, 0.f};
  if (si < n) fn(s0 + si, kk * NK / ks, (kk + 1) * NK / ks, c);
  float4* r4 = (float4*)red;
  r4[w * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
  __syncthreads();
  if (w < n) {
    float4 acc = r4[(w * ks) * 32 + lane];
    for (int j = 1; j < ks; j++) {
      const float4 v = r4[(w * ks + j) * 32 + lane];
      acc.x += v.x; acc.y += v.y; acc.z += v.z; acc.w += v.w;
    }
    float cc[4] = {acc.x, acc.y, acc.z, acc.w};
    epi(s0 + w, cc);
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ vector machinery
// Token vectors are processed in 4-element chunks (576 per token, 18 warps of 32 chunks: a warp never spans two
// tokens). A source of the attention residuals is a bf16 vector per token (global plain / global .cg / smem),
// optionally plus a second one (partial + attention output of the MoE input, summed in fp32).
#define NCH 576
#define NWT 18
#define DSL 64
#define NSL 50

struct Src {
  const bf16* p;
  const bf16* q;
  int stride, qstride;
  int mode, qmode;    // 0 global (write-once in this launch), 1 global rewritten (.cg), 2 shared
};
__device__ __forceinline__ Src mksrc(const bf16* p, int stride, int mode) { return Src{p, nullptr, stride, 0, mode, 0}; }
__device__ __forceinline__ void unpack4(uint2 r, float v[4]) {
  v[0] = __uint_as_float(r.x << 16); v[1] = __uint_as_float(r.x & 0xffff0000u);
  v[2] = __uint_as_float(r.y << 16); v[3] = __uint_as_float(r.y & 0xffff0000u);
}
__device__ __forceinline__ void ld4raw(const bf16* p, int mode, float v[4]) {
  uint2 r;
  if (mode == 1) r = __ldcg((const uint2*)p);
  else r = *(const uint2*)p;
  unpack4(r, v);
}
__device__ __forceinline__ void ld4(const Src& s, int b, int c, float v[4]) {
  ld4raw(s.p + (size_t)b * s.stride + 4 * c, s.mode, v);
  if (s.q) {
    float u[4];
    ld4raw(s.q + (size_t)b * s.qstride + 4 * c, s.qmode, u);
#pragma unroll
    for (int i = 0; i < 4; i++) v[i] += u[i];
  }
}
__device__ __forceinline__ uint2 pack4(const float v[4]) {
  __nv_bfloat162 a = __floats2bfloat162_rn(v[0], v[1]), b = __floats2bfloat162_rn(v[2], v[3]);
  return make_uint2(*(uint32_t*)&a, *(uint32_t*)&b);
}
__device__ __forceinline__ float dot4(const float a[4], const float b[4]) {
  return fmaf(a[3], b[3], fmaf(a[2], b[2], fmaf(a[1], b[1], a[0] * b[0])));
}

// slots: G(i,j) = 5i+j (i<=j<5), SQ(i,j) = 25+3i+j, MG(i,j) = 40+2i+j (i<=j<2), MQ(i,j) = 44+3i+j
struct DotSet {
  int nv, nq, nm, nmq;
  Src S[5];
  Src M[2];
  const float* q[3];
  const float* mq[3];
};
__device__ __forceinline__ bool slot_needed(const DotSet& d, int s) {
  if (s < 25) { const int i = s / 5, j = s % 5; return i <= j && j < d.nv; }
  if (s < 40) { const int i = (s - 25) / 3, j = (s - 25) % 3; return i < d.nv && j < d.nq; }
  if (s < 44) { const int i = (s - 40) / 2, j = (s - 40) % 2; return i <= j && j < d.nm; }
  const int i = (s - 44) / 3, j = (s - 44) % 3; return i < d.nm && j < d.nmq;
}
// out[b * DSL + slot]: exact-order (deterministic) sums over the token's chunks. part: smem [B][NWT][NSL].
__device__ void dot_pass(const DotSet& d, int B, float* part, float* out) {
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int tasks = B * NCH;
  for (int base = 0; base < tasks; base += NT) {
    const int p = base + tid;
    if (base + 32 * w >= tasks) continue;          // whole warp idle (tasks % 32 == 0)
    const int b = p / NCH, c = p % NCH;
    const int wt = ((base + 32 * w) % NCH) / 32;
    float acc[NSL];
#pragma unroll
    for (int i = 0; i < NSL; i++) acc[i] = 0.f;
    float v[5][4], m[2][4];
#pragma unroll
    for (int i = 0; i < 5; i++) if (i < d.nv) ld4(d.S[i], b, c, v[i]);
#pragma unroll
    for (int i = 0; i < 2; i++) if (i < d.nm) ld4(d.M[i], b, c, m[i]);
#pragma unroll
    for (int i = 0; i < 5; i++)
#pragma unroll
      for (int j = i; j < 5; j++) if (j < d.nv) acc[5 * i + j] = dot4(v[i], v[j]);
#pragma unroll
    for (int j = 0; j < 3; j++)
      if (j < d.nq) {
        const float4 q4 = __ldg((const float4*)(d.q[j] + 4 * c));
        const float qq[4] = {q4.x, q4.y, q4.z, q4.w};
#pragma unroll
        for (int i = 0; i < 5; i++) if (i < d.nv) acc[25 + 3 * i + j] = dot4(v[i], qq);
      }
#pragma unroll
    for (int i = 0; i < 2; i++)
#pragma unroll
      for (int j = i; j < 2; j++) if (j < d.nm) acc[40 + 2 * i + j] = dot4(m[i], m[j]);
#pragma unroll
    for (int j = 0; j < 3; j++)
      if (j < d.nmq) {
        const float4 q4 = __ldg((const float4*)(d.mq[j] + 4 * c));
        const float qq[4] = {q4.x, q4.y, q4.z, q4.w};
#pragma unroll
        for (int i = 0; i < 2; i++) if (i < d.nm) acc[44 + 3 * i + j] = dot4(m[i], qq);
      }
#pragma unroll
    for (int s = 0; s < NSL; s++)
      if (slot_needed(d, s)) {
        const float r = warp_sum(acc[s]);
        if (lane == 0) part[(b * NWT + wt) * NSL + s] = r;
      }
  }
  __syncthreads();
  for (int i = tid; i < B * NSL; i += NT) {
    const int b = i / NSL, s = i % NSL;
    if (!slot_needed(d, s)) continue;
    float r = 0.f;
    for (int k = 0; k < NWT; k++) r += part[(b * NWT + k) * NSL + s];
    out[b * DSL + s] = r;
  }
  __syncthreads();
}
// softmax-over-depth coefficients of stream j from the dots: c[i] = p_i * ir_i, c[7] = 1/rms of the mixed stream.
// gbase/qbase: slot bases (S: 0 / 25 with row 5; M: 40 / 44 with row 2). raw: the stream is S[0] itself (layer 0).
__device__ void coefs(const float* o, int n, int j, bool msg, bool raw, float* c) {
  auto G = [&](int i, int k) { const int a = i < k ? i : k, bb = i < k ? k : i; return msg ? o[40 + 2 * a + bb] : o[5 * a + bb]; };
  auto Q = [&](int i) { return msg ? o[44 + 3 * i + j] : o[25 + 3 * i + j]; };
  for (int i = 0; i < 8; i++) c[i] = 0.f;
  float ssq;
  if (raw) { c[0] = 1.f; ssq = G(0, 0); }
  else {
    float ir[5], lg[5], mx = -1e30f;
    for (int i = 0; i < n; i++) { ir[i] = rsqrtf(G(i, i) / H + 1e-6f); lg[i] = Q(i) * ir[i] * (1.f / 48.f); mx = fmaxf(mx, lg[i]); }
    float den = 0.f;
    for (int i = 0; i < n; i++) { lg[i] = __expf(lg[i] - mx); den += lg[i]; }
    for (int i = 0; i < n; i++) c[i] = lg[i] / den * ir[i];
    ssq = 0.f;
    for (int i = 0; i < n; i++)
      for (int k = 0; k < n; k++) ssq = fmaf(c[i] * c[k], G(i, k), ssq);
  }
  c[7] = rsqrtf(ssq / H + 1e-6f);
}
__device__ __forceinline__ void mix4(const Src* S, int n, const float* c, int b, int ch, float x[4]) {
  x[0] = x[1] = x[2] = x[3] = 0.f;
  for (int i = 0; i < n; i++) {
    float v[4];
    ld4(S[i], b, ch, v);
#pragma unroll
    for (int e = 0; e < 4; e++) x[e] = fmaf(c[i], v[e], x[e]);
  }
}
__device__ __forceinline__ void ldw4(const bf16* w, int ch, float v[4]) { unpack4(__ldg((const uint2*)(w + 4 * ch)), v); }

// ------------------------------------------------------------------------------------------------ application table
struct App { int layer, pass, slot; };
__device__ __forceinline__ App app_of(int a) {
  App r;
  if (a < 6) { r.layer = a; r.pass = 0; r.slot = a; }
  else if (a < 42) { r.pass = (a - 6) / 12; r.layer = 6 + (a - 6) % 12; r.slot = r.pass == 0 ? r.layer : 24 + (r.pass - 1) * 12 + (r.layer - 6); }
  else { r.layer = a - 24; r.pass = 0; r.slot = r.layer; }
  return r;
}
__device__ __forceinline__ bool boundary(int layer) { return layer % 6 == 0; }

// block-state sources visible to the attention input of a layer (pass p): h0 (i>0), P5 (i>6), P11_p (i>12), P17_2 (i>18)
// blk slots: 0 h0, 1 P5, 2-4 P11 of pass 0-2, 5-7 P17 of pass 0-2
__device__ int attn_blocks(const Params& P, int layer, int pass, Src* s) {
  int n = 0;
  auto add = [&](int idx) { s[n++] = mksrc(P.blk + (size_t)idx * MAXB * H, H, 0); };
  if (layer > 0) add(0);
  if (layer > 6) add(1);
  if (layer > 12) add(layer >= 18 ? 4 : 2 + pass);
  if (layer > 18) add(7);
  return n;
}

// ------------------------------------------------------------------------------------------------ the step kernel
#define SMEM_BYTES (172 * 1024)
#define GBAR(code) do { gbar(bar, bt, nb); if (P.prof && blk == 0 && tid == 0) { P.prof[2 * pidx] = gtime(); P.prof[2 * pidx + 1] = (unsigned long long)(a * 16 + (code)); } pidx++; } while (0)

// sc (float scratch) layout
#define SC_DOT 0        // [8][64]
#define SC_CF 512       // [8][3][8] stream coefficients (c0..c4, c7 = 1/rms)
#define SC_CM 704       // [8][3][8] message coefficients
#define SC_CFX 896      // [8][8] MoE input stream
#define SC_CMM 960      // [8][8] MoE message
#define SC_G 1024       // [8][3][64] gate down values
#define SC_XSC 2600     // [16] f16 scales
#define SC_IR 2624      // [3][8]

__global__ void __launch_bounds__(NT, 1) mk_step(const Params P) {
  extern __shared__ __align__(16) uint8_t smem[];
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31;
  const int nb = (int)P.nb, blk = blockIdx.x;
  const int B = (int)P.B;
  unsigned bt = 0;
  unsigned* bar = P.sync;
  int pidx = 1;
  int a = 0;
  if (P.prof && blk == 0 && tid == 0) { P.prof[0] = gtime(); P.prof[1] = 0; }
  const int pos = P.pos[0];

  bf16* sX = (bf16*)smem;                       // entering partial X [8][XS]
  bf16* sIn = sX + MAXB * XS;                   // [3][8][XS]
  float* red = (float*)(sIn + 3 * MAXB * XS);   // 8 KB
  float* sc = red + NW * 32 * 4;                // 4608 floats
  float* part2 = (float*)(sIn + 2 * MAXB * XS); // dot partials (third stream region, 37 KB)

  for (a = 0; a <= NAPP; a++) {
    const App ap = a < NAPP ? app_of(a) : App{24, 0, -1};
    // ---------------------------------------------------------------- entering partial X_a (every block)
    if (a == 0) {
      for (int p = tid; p < B * NCH; p += NT) {
        const int b = p / NCH, c = p % NCH;
        long long tk = P.tok[b];
        tk = tk < 0 ? 0 : (tk >= 201024 ? 201023 : tk);
        *(uint2*)(sX + b * XS + 4 * c) = __ldg((const uint2*)(P.emb + (size_t)tk * H + 4 * c));
      }
      __syncthreads();
      DotSet d{};
      d.nv = 1; d.S[0] = mksrc(sX, XS, 2);
      dot_pass(d, B, part2, sc + SC_DOT);
      for (int p = tid; p < B * NCH; p += NT) {
        const int b = p / NCH, c = p % NCH;
        const float ir = rsqrtf(sc[SC_DOT + b * DSL] / H + 1e-6f);
        float v[4], wv[4];
        unpack4(*(const uint2*)(sX + b * XS + 4 * c), v);
        ldw4(P.embnorm, c, wv);
        for (int e = 0; e < 4; e++) v[e] = v[e] * ir * wv[e];
        *(uint2*)(sX + b * XS + 4 * c) = pack4(v);
      }
    } else {
      const App pv = app_of(a - 1);
      const LayerW& Lp = P.L[pv.layer];
      const bf16* xprev = P.pbuf + (size_t)((a - 1) & 1) * MAXB * H;
      const bf16* mr = P.mring + (size_t)pv.slot * MAXB * 4 * H;
      const bool bnd = boundary(pv.layer);
      const bool restart = a < NAPP && ap.layer == 6 && ap.pass >= 1;
      bf16* dstX = restart ? sIn + 2 * MAXB * XS : sX;    // the finalized P17 of the previous pass goes aside
      for (int p = tid; p < B * NCH; p += NT) {
        const int b = p / NCH, c = p % NCH;
        float r[4][4], cw[4][4], at[4], xp[4], x[4];
        for (int tap = 0; tap < 4; tap++) {
          const int pp = pos - 3 + tap;
          if (pp >= 0) ld4raw(mr + ((size_t)b * 4 + (pp & 3)) * H + 4 * c, 1, r[tap]);
          else r[tap][0] = r[tap][1] = r[tap][2] = r[tap][3] = 0.f;
        }
        ld4raw(P.att + (size_t)b * H + 4 * c, 1, at);
        if (!bnd) ld4raw(xprev + (size_t)b * H + 4 * c, 1, xp);
        for (int e = 0; e < 4; e++) {
          const uint2 cv = __ldg((const uint2*)(Lp.mconv + (size_t)(4 * c + e) * 4));
          unpack4(cv, cw[e]);
        }
        for (int e = 0; e < 4; e++) {
          float acc = 0.f;
          for (int tap = 0; tap < 4; tap++) acc = fmaf(r[tap][e], cw[e][tap], acc);
          const float mlp = rbf((acc + r[3][e]) * 0.4472135954999579f);
          x[e] = bnd ? rbf(at[e] + mlp) : rbf((xp[e] + at[e]) + mlp);
        }
        *(uint2*)(dstX + b * XS + 4 * c) = pack4(x);
        if (restart) *(uint2*)(sX + b * XS + 4 * c) = *(const uint2*)(P.blk + ((size_t)1 * MAXB + b) * H + 4 * c);
      }
      if (restart && blk == 0) {
        __syncthreads();
        for (int p = tid; p < B * NCH; p += NT) {
          const int b = p / NCH, c = p % NCH;
          *(uint2*)(P.blk + ((size_t)(5 + ap.pass - 1) * MAXB + b) * H + 4 * c) = *(const uint2*)(dstX + b * XS + 4 * c);
        }
      }
    }
    __syncthreads();
    if (blk == 0) {
      int bi = -1;
      if (a < NAPP) {
        if (ap.layer == 0) bi = 0;
        else if (ap.layer == 6 && ap.pass == 0) bi = 1;
        else if (ap.layer == 12) bi = 2 + ap.pass;
        else if (ap.layer == 18) bi = 7;
      }
      bf16* dst = P.pbuf + (size_t)(a & 1) * MAXB * H;
      for (int p = tid; p < B * NCH; p += NT) {
        const int b = p / NCH, c = p % NCH;
        const uint2 v = *(const uint2*)(sX + b * XS + 4 * c);
        *(uint2*)(dst + (size_t)b * H + 4 * c) = v;
        if (bi >= 0) *(uint2*)(P.blk + ((size_t)bi * MAXB + b) * H + 4 * c) = v;
        if (P.dbg && a < NAPP) {
          float f[4];
          unpack4(v, f);
          *(float4*)(P.dbg + ((size_t)a * MAXB + b) * H + 4 * c) = make_float4(f[0], f[1], f[2], f[3]);
        }
      }
    }

    if (a == NAPP) break;
    const LayerW& L = P.L[ap.layer];
    const int layer = ap.layer, pass = ap.pass, slot = ap.slot;
    const bool glob = L.glob != 0;
    const bool gated = pass >= 1;
    const int nq = glob ? 3 : 1;

    // ---------------------------------------------------------------- attention-input dots and coefficients
    Src S[5];
    int ns = 0;
    if (layer > 0) ns = attn_blocks(P, layer, pass, S);
    S[ns++] = mksrc(sX, XS, 2);
    Src Ms[2];
    {
      DotSet d{};
      d.nv = ns;
      for (int i = 0; i < ns; i++) d.S[i] = S[i];
      if (layer > 0) { d.nq = nq; for (int j = 0; j < nq; j++) d.q[j] = L.aq + (glob ? j * H : 0); }
      if (gated) {
        Ms[0] = mksrc(P.blk + (size_t)(2 + pass - 1) * MAXB * H, H, 0);
        Ms[1] = layer == 6 ? mksrc(sIn + 2 * MAXB * XS, XS, 2) : mksrc(P.blk + (size_t)(5 + pass - 1) * MAXB * H, H, 0);
        d.nm = 2; d.nmq = 3; d.M[0] = Ms[0]; d.M[1] = Ms[1];
        const float* lq = P.loopq + (size_t)(layer - 6) * 4 * H;
        for (int j = 0; j < 3; j++) d.mq[j] = lq + j * H;
      }
      // layer 6 restart: the P17 copy lives in the third sIn region, so use the red buffer region... partials go to
      // sIn rows 0..7 (stream 0) which are rebuilt afterwards
      float* pp = (gated && layer == 6) ? (float*)sIn : part2;
      dot_pass(d, B, pp, sc + SC_DOT);
      if (tid < B * 3) {
        const int b = tid / 3, j = tid % 3;
        if (j < nq) coefs(sc + SC_DOT + b * DSL, ns, j, false, layer == 0, sc + SC_CF + (b * 3 + j) * 8);
        if (gated) coefs(sc + SC_DOT + b * DSL, 2, j, true, false, sc + SC_CM + (b * 3 + j) * 8);
      }
      __syncthreads();
    }

    if (gated) {
      // ------------------------------------------------ phase A: controller down projections (q, k, v gates)
      // item = blk (< 3*4*GSEG): gate j, strip st, segment sg of the 4608 inputs (24 tiles = 384 inputs)
      const int item = blk;
      if (item < 3 * 4 * GSEG) {
        const int j = item / (4 * GSEG), st = (item / GSEG) % 4, sg = item % GSEG;
        const int sj = glob ? j : 0;
        bf16* seg = sIn;   // rows [b][0..384)
        const int kb = sg * 384;
        for (int p = tid; p < B * 96; p += NT) {
          const int b = p / 96, cc = p % 96;
          const int k = kb + 4 * cc;
          float x[4];
          if (k < H) {
            const float* cf = sc + SC_CF + (b * 3 + sj) * 8;
            mix4(S, ns, cf, b, k / 4, x);
            for (int e = 0; e < 4; e++) x[e] *= cf[7];
          } else {
            const float* cm = sc + SC_CM + (b * 3 + j) * 8;
            mix4(Ms, 2, cm, b, (k - H) / 4, x);
            for (int e = 0; e < 4; e++) x[e] *= cm[7];
          }
          *(uint2*)(seg + b * XS + 4 * cc) = pack4(x);
        }
        __syncthreads();
        if (w == 0) {
          float c[4] = {0.f, 0.f, 0.f, 0.f};
          const uint4* A = L.cdown + ((size_t)(j * 4 + st) * 288 + sg * 24) * 32;
          strip_bf16<8>(A, 0, 24, seg, B, c);
          const unsigned g = lane >> 2, t = lane & 3;
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) {
              P.gpart[(((size_t)b * 3 + j) * GSEG + sg) * 64 + st * 16 + g] = c[h2];
              P.gpart[(((size_t)b * 3 + j) * GSEG + sg) * 64 + st * 16 + g + 8] = c[2 + h2];
            }
          }
        }
      }
      if (blk == 0) for (int i = tid; i < 384; i += NT) P.coef[i] = sc[SC_CF + i];   // CF and CM are adjacent
      GBAR(0);
      // ------------------------------------------------ phase B: x' = (1 - tanh(F g)) x + tanh(G g) m
      {
        float* gs = sc + SC_G;
        for (int i = tid; i < B * 3 * 64; i += NT) {
          const int b = i / 192, j = (i / 64) % 3, r = i % 64;
          float s = 0.f;
          for (int sg = 0; sg < GSEG; sg++) s += ldf(P.gpart + (((size_t)b * 3 + j) * GSEG + sg) * 64 + r);
          gs[i] = s;
        }
        for (int i = tid; i < 384; i += NT) sc[SC_CF + i] = ldf(P.coef + i);
        __syncthreads();
        // X and P17 from their global copies
        S[ns - 1] = mksrc(P.pbuf + (size_t)(a & 1) * MAXB * H, H, 1);
        Ms[1] = mksrc(P.blk + (size_t)(5 + pass - 1) * MAXB * H, H, 1);
        const int total = 3 * B * NCH;
        for (int i = blk * NT + tid; i < total; i += nb * NT) {
          const int j = i / (B * NCH), b = (i / NCH) % B, c = i % NCH;
          const int sj = glob ? j : 0;
          float x[4], m[4];
          mix4(S, ns, sc + SC_CF + (b * 3 + sj) * 8, b, c, x);
          mix4(Ms, 2, sc + SC_CM + (b * 3 + j) * 8, b, c, m);
          const float* gv = gs + (b * 3 + j) * 64;
          float o[4];
          for (int e = 0; e < 4; e++) {
            const uint4* Fr = (const uint4*)(L.cforget + ((size_t)j * H + 4 * c + e) * 64);
            const uint4* Gr = (const uint4*)(L.cgain + ((size_t)j * H + 4 * c + e) * 64);
            float f = 0.f, gg = 0.f;
#pragma unroll
            for (int r = 0; r < 8; r++) {
              const uint4 fv = __ldg(Fr + r), gw = __ldg(Gr + r);
              const uint32_t fa[4] = {fv.x, fv.y, fv.z, fv.w}, ga[4] = {gw.x, gw.y, gw.z, gw.w};
#pragma unroll
              for (int q = 0; q < 4; q++) {
                f = fmaf(__uint_as_float(fa[q] << 16), gv[8 * r + 2 * q], f);
                f = fmaf(__uint_as_float(fa[q] & 0xffff0000u), gv[8 * r + 2 * q + 1], f);
                gg = fmaf(__uint_as_float(ga[q] << 16), gv[8 * r + 2 * q], gg);
                gg = fmaf(__uint_as_float(ga[q] & 0xffff0000u), gv[8 * r + 2 * q + 1], gg);
              }
            }
            o[e] = (1.f - tanhf(f)) * x[e] + tanhf(gg) * m[e];
          }
          *(float4*)(P.xg + ((size_t)j * MAXB + b) * H + 4 * c) = make_float4(o[0], o[1], o[2], o[3]);
        }
      }
      GBAR(1);
      // rms of the gated streams
      {
        for (int base = 0; base < B * NCH; base += NT) {
          if (base + 32 * w >= B * NCH) continue;
          const int p = base + tid, b = p / NCH, c = p % NCH, wt = ((base + 32 * w) % NCH) / 32;
          for (int j = 0; j < 3; j++) {
            const float4 v = __ldcg((const float4*)(P.xg + ((size_t)j * MAXB + b) * H + 4 * c));
            const float s = warp_sum(v.x * v.x + v.y * v.y + v.z * v.z + v.w * v.w);
            if (lane == 0) part2[(b * NWT + wt) * 3 + j] = s;
          }
        }
        __syncthreads();
        if (tid < B * 3) {
          const int b = tid / 3, j = tid % 3;
          float s = 0.f;
          for (int k = 0; k < NWT; k++) s += part2[(b * NWT + k) * 3 + j];
          sc[SC_IR + j * 8 + b] = rsqrtf(s / H + 1e-6f);
        }
        __syncthreads();
      }
    }

    // ---------------------------------------------------------------- phase C: the q|gate|r|sink, k, v projections
    {
      const int nin = (glob || gated) ? 3 : 1;
      for (int p = tid; p < B * NCH; p += NT) {
        const int b = p / NCH, c = p % NCH;
        for (int j = 0; j < nin; j++) {
          const bf16* nw = j == 0 ? L.normq : (j == 1 ? L.normk : L.normv);
          float x[4], wv[4];
          float ir;
          if (gated) {
            const float4 v = __ldcg((const float4*)(P.xg + ((size_t)j * MAXB + b) * H + 4 * c));
            x[0] = v.x; x[1] = v.y; x[2] = v.z; x[3] = v.w;
            ir = sc[SC_IR + j * 8 + b];
          } else {
            const float* cf = sc + SC_CF + (b * 3 + (glob ? j : 0)) * 8;
            mix4(S, ns, cf, b, c, x);
            ir = cf[7];
          }
          ldw4(nw, c, wv);
          for (int e = 0; e < 4; e++) x[e] = x[e] * ir * wv[e];
          *(uint2*)(sIn + (j * MAXB + b) * XS + 4 * c) = pack4(x);
        }
      }
      __syncthreads();
      const int N = (int)L.nstrip;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      const int kst = (int)L.koff / 16, vst = (int)L.voff / 16;
      block_strips(s0, s1, 144, red,
        [&](int s, int k0, int k1, float c[4]) {
          const bf16* xs = sIn + (nin == 3 ? (s >= vst ? 2 : (s >= kst ? 1 : 0)) : 0) * MAXB * XS;
          strip_bf16<8>(L.wqkv + (size_t)s * 144 * 32, k0, k1, xs, B, c);
        },
        [&](int s, float c[4]) {
          const unsigned g = lane >> 2, t = lane & 3;
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) { P.qkv[(size_t)b * 8704 + s * 16 + g] = c[h2]; P.qkv[(size_t)b * 8704 + s * 16 + g + 8] = c[2 + h2]; }
          }
        });
    }
    GBAR(2);
    // ---------------------------------------------------------------- phase D: attention
    {
      const int lo = glob ? 0 : (pos - (WIN - 1) > 0 ? pos - (WIN - 1) : 0);
      const int c_lo = lo / CH, c_hi = pos / CH;
      const int nch = c_hi - c_lo + 1;
      const int units = B * NHKV * nch;
      const size_t ctx = (size_t)P.ctx;
      float* sq = sc;                 // q [3][128]
      float* sr = sc + 384;           // r [3][16]
      float* sbias = sc + 448;        // [3][CH]
      float* ss = sc + 448 + 3 * CH;  // scores / probs [3][CH]
      float* skv = sc + 448 + 6 * CH; // k_cur [128], v_cur [128]
      float* sml = skv + 256;         // m, l [3][2]
      float* so = (float*)red;        // o partial [16 warps][3][128]? use sIn as float scratch
      float* sop = (float*)sIn;       // [NW][3][128]
      for (int u = blk; u < units; u += nb) {
        const int b = u / (NHKV * nch), h = (u / nch) % NHKV, ci = c_lo + u % nch;
        const int j0 = ci * CH > lo ? ci * CH : lo, j1 = (ci * CH + CH - 1) < pos ? ci * CH + CH - 1 : pos;
        const int n = j1 - j0 + 1;
        const bool last = ci == c_hi;
        const float* qk = P.qkv + (size_t)b * 8704;
        const float tau = glob ? 1.f + 0.1f * logf(fmaxf((pos + 1) / 8192.f, 1.f)) : 1.f;
        if (w < 3) {      // q of head 3h+w
          const int hq = 3 * h + w;
          float v[4], s = 0.f;
          for (int i = 0; i < 4; i++) {
            const int d = lane * 4 + i;
            v[i] = rbf(ldf(qk + hq * HD + d)) * bf(L.qscale[hq * HD + d]);
            s = fmaf(v[i], v[i], s);
          }
          s = warp_sum(s);
          const float f = fminf(22.627416997969522f / (sqrtf(s) + 1e-6f), 1.f);
          for (int i = 0; i < 4; i++) {
            float o = rbf(v[i] * f);
            if (glob) o = rbf(o * tau);
            sq[w * HD + lane * 4 + i] = o;
          }
        } else if (w < 6) {   // r of head 3h+w-3
          const int hq = 3 * h + w - 3;
          float v = 0.f;
          if (lane < DREL) v = rbf(ldf(qk + 6144 + hq * DREL + lane)) * bf(L.rscale[hq * DREL + lane]);
          const float s = warp_sum(v * v);
          const float f = fminf(8.0f / (sqrtf(s) + 1e-6f), 1.f);
          if (lane < DREL) {
            float o = rbf(v * f);
            if (glob) o = rbf(o * tau);
            sr[(w - 3) * DREL + lane] = o;
          }
        } else if (w < 8 && last) {   // current k (w 6) / v (w 7) of head h
          const bool isk = w == 6;
          const int off = (isk ? (int)L.koff : (int)L.voff) + h * HD;
          bf16* ring = (isk ? P.kring : P.vring) + ((size_t)slot * MAXB + b) * 4 * KVD;
          const bf16* cw = isk ? L.kconv : L.vconv;
          float x[4], v[4], s = 0.f;
          for (int i = 0; i < 4; i++) {
            const int d = lane * 4 + i, c = h * HD + d;
            x[i] = rbf(ldf(qk + off + lane * 4 + i));
            float acc = 0.f;
            if (!glob) {
              for (int tap = 0; tap < 3; tap++) {
                const int pp = pos - 3 + tap;
                const float hv = pp >= 0 ? ldbf(ring + (size_t)(pp & 3) * KVD + c) : 0.f;
                acc = fmaf(hv, bf(cw[c * 4 + tap]), acc);
              }
              acc = fmaf(x[i], bf(cw[c * 4 + 3]), acc);
              v[i] = rbf((acc + x[i]) * 0.4472135954999579f);
            } else {
              const int dp = (isk ? (int)L.kpoff : (int)L.vpoff) + h * 4;
              for (int lag = 0; lag < 4; lag++) {
                const float dyn = rbf(ldf(qk + dp + lag));
                const float wt = bf(cw[lag * KVD + c]) + dyn;
                const int pp = pos - lag;
                const float hv = lag == 0 ? x[i] : (pp >= 0 ? ldbf(ring + (size_t)(pp & 3) * KVD + c) : 0.f);
                acc = fmaf(hv, wt, acc);
              }
              v[i] = rbf((acc + x[i]) * (1.f / 3.f));
            }
            s = fmaf(v[i], v[i], s);
          }
          s = warp_sum(s);
          const float f = isk ? fminf(22.627416997969522f / (sqrtf(s) + 1e-6f), 1.f) : rsqrtf(s / HD + 1e-6f);
          bf16* cache = (isk ? P.kc : P.vc) + ((((size_t)slot * MAXB + b) * NHKV + h) * ctx + pos) * HD;
          for (int i = 0; i < 4; i++) {
            const float o = rbf(v[i] * f);
            skv[(isk ? 0 : 128) + lane * 4 + i] = o;
            cache[lane * 4 + i] = __float2bfloat16(o);
            ring[(size_t)(pos & 3) * KVD + h * HD + lane * 4 + i] = __float2bfloat16(x[i]);
          }
        }
        __syncthreads();
        // relative bias of the chunk's keys
        for (int i = tid; i < 3 * CH; i += NT) {
          const int hw = i / CH, jj = i % CH;
          float bv = 0.f;
          if (jj < n) {
            const int dist = pos - (j0 + jj);
            if (dist < RELX) {
              for (int r = 0; r < DREL; r++) bv = fmaf(sr[hw * DREL + r], bf(L.relp[r * RELX + dist]), bv);
            }
          }
          sbias[i] = bv;
        }
        // scores
        const bf16* Kb = P.kc + (((size_t)slot * MAXB + b) * NHKV + h) * ctx * HD;
        const bf16* Vb = P.vc + (((size_t)slot * MAXB + b) * NHKV + h) * ctx * HD;
        for (int jj = w; jj < n; jj += NW) {
          const int j = j0 + jj;
          float kv[4];
          if (j == pos) { for (int i = 0; i < 4; i++) kv[i] = skv[lane * 4 + i]; }
          else {
            const uint2 r = __ldcg((const uint2*)(Kb + (size_t)j * HD + lane * 4));
            kv[0] = __uint_as_float(r.x << 16); kv[1] = __uint_as_float(r.x & 0xffff0000u);
            kv[2] = __uint_as_float(r.y << 16); kv[3] = __uint_as_float(r.y & 0xffff0000u);
          }
          for (int hw = 0; hw < 3; hw++) {
            float d = 0.f;
            for (int i = 0; i < 4; i++) d = fmaf(sq[hw * HD + lane * 4 + i], kv[i], d);
            d = warp_sum(d);
            if (lane == 0) ss[hw * CH + jj] = d * 0.08838834764831845f;   // 1/sqrt(128)
          }
        }
        __syncthreads();
        if (w < 3) {
          float m = -1e30f;
          for (int jj = lane; jj < n; jj += 32) { ss[w * CH + jj] += sbias[w * CH + jj]; m = fmaxf(m, ss[w * CH + jj]); }
          m = warp_max(m);
          float l = 0.f;
          for (int jj = lane; jj < n; jj += 32) { const float p = __expf(ss[w * CH + jj] - m); ss[w * CH + jj] = p; l += p; }
          l = warp_sum(l);
          if (lane == 0) { sml[w * 2] = m; sml[w * 2 + 1] = l; }
        }
        __syncthreads();
        // o = sum p v: warp w handles keys jj = w, w+16..; lane 4 dims
        {
          float o[3][4] = {};
          for (int jj = w; jj < n; jj += NW) {
            const int j = j0 + jj;
            float vv[4];
            if (j == pos) { for (int i = 0; i < 4; i++) vv[i] = skv[128 + lane * 4 + i]; }
            else {
              const uint2 r = __ldcg((const uint2*)(Vb + (size_t)j * HD + lane * 4));
              vv[0] = __uint_as_float(r.x << 16); vv[1] = __uint_as_float(r.x & 0xffff0000u);
              vv[2] = __uint_as_float(r.y << 16); vv[3] = __uint_as_float(r.y & 0xffff0000u);
            }
            for (int hw = 0; hw < 3; hw++) {
              const float p = ss[hw * CH + jj];
              for (int i = 0; i < 4; i++) o[hw][i] = fmaf(p, vv[i], o[hw][i]);
            }
          }
          for (int hw = 0; hw < 3; hw++)
            for (int i = 0; i < 4; i++) sop[(w * 3 + hw) * HD + lane * 4 + i] = o[hw][i];
        }
        __syncthreads();
        for (int i = tid; i < 3 * HD; i += NT) {
          const int hw = i / HD, d = i % HD;
          float s = 0.f;
          for (int ww = 0; ww < NW; ww++) s += sop[(ww * 3 + hw) * HD + d];
          float* dst = P.apart + (((size_t)b * NHQ + 3 * h + hw) * MAXCH + (ci - c_lo)) * 132;
          dst[d] = s;
          if (d == 0) { dst[128] = sml[hw * 2]; dst[129] = sml[hw * 2 + 1]; }
        }
        __threadfence();
        __syncthreads();
        // the last unit of (b, h) combines the chunks
        __shared__ unsigned s_last;
        if (tid == 0) {
          const unsigned old = atomicAdd(P.sync + 64 + ((size_t)a * MAXB + b) * NHKV + h, 1u);
          s_last = (old == (unsigned)(nch - 1));
          __threadfence();
        }
        __syncthreads();
        if (s_last) {
          for (int i = tid; i < 3 * HD; i += NT) {
            const int hw = i / HD, d = i % HD, hq = 3 * h + hw;
            const float* base = P.apart + ((size_t)b * NHQ + hq) * MAXCH * 132;
            float M = -1e30f;
            for (int c = 0; c < nch; c++) M = fmaxf(M, ldf(base + c * 132 + 128));
            float Lsum = 0.f, O = 0.f;
            for (int c = 0; c < nch; c++) {
              const float e = __expf(ldf(base + c * 132 + 128) - M);
              Lsum = fmaf(ldf(base + c * 132 + 129), e, Lsum);
              O = fmaf(ldf(base + c * 132 + d), e, O);
            }
            const float lse = M + logf(Lsum);
            const float gate = rbf(ldf(qk + 3072 + hq * HD + d));
            const float sink = rbf(ldf(qk + 6528 + hq));
            const float out = O / Lsum * sigm(gate) * sigm(lse - sink);
            P.ao[(size_t)b * QD + hq * HD + d] = __float2bfloat16(out);
          }
        }
        __syncthreads();
      }
    }
    GBAR(3);

    // ---------------------------------------------------------------- phase E: output projection
    {
      bf16* xs = sIn;   // [8][XS] used as 3072-wide rows: stride XS >= 3072? no: use dedicated stride
      // ao rows are 3072 wide: store with stride 3072+8 in sIn (fits: 8*3080*2 = 49 KB)
      const int AS = QD + 8;
      for (int b = 0; b < B; b++)
        for (int k = tid; k < QD / 2; k += NT)
          *(uint32_t*)(xs + b * AS + 2 * k) = __ldcg((const unsigned*)(P.ao + (size_t)b * QD) + k);
      __syncthreads();
      const int N = 144;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      bf16* orr = P.oring + (size_t)slot * MAXB * 4 * H;
      block_strips(s0, s1, 192, red,
        [&](int s, int k0, int k1, float c[4]) {
          // strip_bf16 assumes stride XS; emulate with AS by a local copy of the loop
          const unsigned g = lane >> 2, t = lane & 3;
          const bf16* xr = xs + g * AS + 2 * t;
          const bool on = g < (unsigned)B;
          const uint4* A = L.wo + (size_t)s * 192 * 32;
          for (int k = k0; k < k1; k += 8) {
            uint4 av[8];
#pragma unroll
            for (int u = 0; u < 8; u++) if (k + u < k1) av[u] = ldw(A + (size_t)(k + u) * 32 + lane);
#pragma unroll
            for (int u = 0; u < 8; u++)
              if (k + u < k1) {
                uint32_t b0 = 0, b1 = 0;
                if (on) { b0 = *(const uint32_t*)(xr + (k + u) * 16); b1 = *(const uint32_t*)(xr + (k + u) * 16 + 8); }
                mma_bf16(c, (const uint32_t*)&av[u], b0, b1);
              }
          }
        },
        [&](int s, float c[4]) {
          const unsigned g = lane >> 2, t = lane & 3;
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) {
              orr[((size_t)b * 4 + (pos & 3)) * H + s * 16 + g] = __float2bfloat16(c[h2]);
              orr[((size_t)b * 4 + (pos & 3)) * H + s * 16 + g + 8] = __float2bfloat16(c[2 + h2]);
            }
          }
        });
    }
    GBAR(4);

    // ---------------------------------------------------------------- phase F: attention conv, MoE input, router
    {
      bf16* sA = sIn;                    // attn output after conv [8][XS]
      bf16* sM = sIn + MAXB * XS;        // MoE input (normalized) [8][XS]
      const bf16* orr = P.oring + (size_t)slot * MAXB * 4 * H;
      for (int p = tid; p < B * NCH; p += NT) {
        const int b = p / NCH, c = p % NCH;
        float r[4][4], cw[4][4], x[4];
        for (int tap = 0; tap < 4; tap++) {
          const int pp = pos - 3 + tap;
          if (pp >= 0) ld4raw(orr + ((size_t)b * 4 + (pp & 3)) * H + 4 * c, 1, r[tap]);
          else r[tap][0] = r[tap][1] = r[tap][2] = r[tap][3] = 0.f;
        }
        for (int e = 0; e < 4; e++) unpack4(__ldg((const uint2*)(L.aconv + (size_t)(4 * c + e) * 4)), cw[e]);
        for (int e = 0; e < 4; e++) {
          float acc = 0.f;
          for (int tap = 0; tap < 4; tap++) acc = fmaf(r[tap][e], cw[e][tap], acc);
          x[e] = (acc + r[3][e]) * 0.4472135954999579f;
        }
        const uint2 pk = pack4(x);
        *(uint2*)(sA + b * XS + 4 * c) = pk;
        if (blk == 0) *(uint2*)(P.att + (size_t)b * H + 4 * c) = pk;
      }
      __syncthreads();
      // sources of the MoE input
      Src ms[5];
      int nm = attn_blocks(P, layer, pass, ms);
      if (boundary(layer)) {
        ms[nm++] = mksrc(sX, XS, 2);
        ms[nm++] = mksrc(sA, XS, 2);
      } else {
        ms[nm] = Src{sX, sA, XS, XS, 2, 2};
        nm++;
      }
      Src mm[2];
      {
        DotSet d{};
        d.nv = nm; for (int i = 0; i < nm; i++) d.S[i] = ms[i];
        d.nq = 1; d.q[0] = L.mq;
        if (gated) {
          mm[0] = mksrc(P.blk + (size_t)(2 + pass - 1) * MAXB * H, H, 0);
          mm[1] = mksrc(P.blk + (size_t)(5 + pass - 1) * MAXB * H, H, 0);
          d.nm = 2; d.nmq = 1; d.M[0] = mm[0]; d.M[1] = mm[1];
          d.mq[0] = P.loopq + ((size_t)(layer - 6) * 4 + 3) * H;
        }
        dot_pass(d, B, part2, sc + SC_DOT);
        if (tid < B) {
          coefs(sc + SC_DOT + tid * DSL, nm, 0, false, false, sc + SC_CFX + tid * 8);
          if (gated) coefs(sc + SC_DOT + tid * DSL, 2, 0, true, false, sc + SC_CMM + tid * 8);
        }
        __syncthreads();
      }
      if (gated) {
        // phase F1: down projection segments of cat(unit(x), unit(m)) (128 inputs each): item = blk < 4*MSEG
        const int item = blk;
        bf16* seg = sM;
        if (item < 4 * MSEG) {
          const int st = item / MSEG, sg = item % MSEG;
          const int kb = sg * 128;
          for (int p = tid; p < B * 32; p += NT) {
            const int b = p / 32, cc = p % 32;
            const int k = kb + 4 * cc;
            float x[4];
            if (k < H) {
              const float* cf = sc + SC_CFX + b * 8;
              mix4(ms, nm, cf, b, k / 4, x);
              for (int e = 0; e < 4; e++) x[e] *= cf[7];
            } else {
              const float* cm = sc + SC_CMM + b * 8;
              mix4(mm, 2, cm, b, (k - H) / 4, x);
              for (int e = 0; e < 4; e++) x[e] *= cm[7];
            }
            *(uint2*)(seg + b * XS + 4 * cc) = pack4(x);
          }
          __syncthreads();
          if (w == 0) {
            float c[4] = {0.f, 0.f, 0.f, 0.f};
            const uint4* A = L.cdown + ((size_t)(3 * 4 + st) * 288 + sg * 8) * 32;
            strip_bf16<8>(A, 0, 8, seg, B, c);
            const unsigned g = lane >> 2, t = lane & 3;
            for (int h2 = 0; h2 < 2; h2++) {
              const int b = 2 * t + h2;
              if (b < B) {
                P.gpart[((size_t)b * MSEG + sg) * 64 + st * 16 + g] = c[h2];
                P.gpart[((size_t)b * MSEG + sg) * 64 + st * 16 + g + 8] = c[2 + h2];
              }
            }
          }
        }
        if (blk == 0) for (int i = tid; i < 128; i += NT) P.coef[512 + i] = sc[SC_CFX + i];   // CFX, CMM adjacent
        GBAR(5);
        // phase F2: x' for the MoE input
        {
          float* gs = sc + SC_G;    // [8][64]
          for (int i = tid; i < B * 64; i += NT) {
            const int b = i / 64, r = i % 64;
            float s = 0.f;
            for (int sg = 0; sg < MSEG; sg++) s += ldf(P.gpart + ((size_t)b * MSEG + sg) * 64 + r);
            gs[i] = s;
          }
          for (int i = tid; i < 128; i += NT) sc[SC_CFX + i] = ldf(P.coef + 512 + i);
          __syncthreads();
          // sources: the smem X / attn copies are this block's own; other blocks' elements need the global copies
          int nm2 = attn_blocks(P, layer, pass, ms);
          const bf16* Xg = P.pbuf + (size_t)(a & 1) * MAXB * H;
          if (boundary(layer)) {
            ms[nm2++] = mksrc(Xg, H, 1);
            ms[nm2++] = mksrc(P.att, H, 1);
          } else {
            ms[nm2] = Src{Xg, P.att, H, H, 1, 1};
            nm2++;
          }
          for (int i = blk * NT + tid; i < B * NCH; i += nb * NT) {
            const int b = i / NCH, c = i % NCH;
            float x[4], m[4], o[4];
            mix4(ms, nm2, sc + SC_CFX + b * 8, b, c, x);
            mix4(mm, 2, sc + SC_CMM + b * 8, b, c, m);
            const float* gv = gs + b * 64;
            for (int e = 0; e < 4; e++) {
              const uint4* Fr = (const uint4*)(L.cforget + ((size_t)3 * H + 4 * c + e) * 64);
              const uint4* Gr = (const uint4*)(L.cgain + ((size_t)3 * H + 4 * c + e) * 64);
              float f = 0.f, gg = 0.f;
#pragma unroll
              for (int r = 0; r < 8; r++) {
                const uint4 fv = __ldg(Fr + r), gw = __ldg(Gr + r);
                const uint32_t fa[4] = {fv.x, fv.y, fv.z, fv.w}, ga[4] = {gw.x, gw.y, gw.z, gw.w};
#pragma unroll
                for (int q = 0; q < 4; q++) {
                  f = fmaf(__uint_as_float(fa[q] << 16), gv[8 * r + 2 * q], f);
                  f = fmaf(__uint_as_float(fa[q] & 0xffff0000u), gv[8 * r + 2 * q + 1], f);
                  gg = fmaf(__uint_as_float(ga[q] << 16), gv[8 * r + 2 * q], gg);
                  gg = fmaf(__uint_as_float(ga[q] & 0xffff0000u), gv[8 * r + 2 * q + 1], gg);
                }
              }
              o[e] = (1.f - tanhf(f)) * x[e] + tanhf(gg) * m[e];
            }
            *(float4*)(P.xg + (size_t)b * H + 4 * c) = make_float4(o[0], o[1], o[2], o[3]);
          }
        }
        GBAR(6);
        // rms of x'
        for (int base = 0; base < B * NCH; base += NT) {
          if (base + 32 * w >= B * NCH) continue;
          const int p = base + tid, b = p / NCH, c = p % NCH, wt = ((base + 32 * w) % NCH) / 32;
          const float4 v = __ldcg((const float4*)(P.xg + (size_t)b * H + 4 * c));
          const float s = warp_sum(v.x * v.x + v.y * v.y + v.z * v.z + v.w * v.w);
          if (lane == 0) part2[b * NWT + wt] = s;
        }
        __syncthreads();
        if (tid < B) {
          float s = 0.f;
          for (int k = 0; k < NWT; k++) s += part2[tid * NWT + k];
          sc[SC_IR + tid] = rsqrtf(s / H + 1e-6f);
        }
        __syncthreads();
      }
      // normalized MoE input -> sM (bf16)
      for (int p = tid; p < B * NCH; p += NT) {
        const int b = p / NCH, c = p % NCH;
        float x[4], wv[4], ir;
        if (gated) {
          const float4 v = __ldcg((const float4*)(P.xg + (size_t)b * H + 4 * c));
          x[0] = v.x; x[1] = v.y; x[2] = v.z; x[3] = v.w;
          ir = sc[SC_IR + b];
        } else {
          const float* cf = sc + SC_CFX + b * 8;
          mix4(ms, nm, cf, b, c, x);
          ir = cf[7];
        }
        ldw4(L.mlpnorm, c, wv);
        for (int e = 0; e < 4; e++) x[e] = x[e] * ir * wv[e];
        const uint2 pk = pack4(x);
        *(uint2*)(sM + b * XS + 4 * c) = pk;
        if (blk == 0) *(uint2*)(P.xm + (size_t)b * H + 4 * c) = pk;
      }
      __syncthreads();
      // router: item = blk < 8 * RSEG: strip st, segment sg (9 tiles)
      if (blk < 8 * RSEG && w == 0) {
        const int st = blk / RSEG, sg = blk % RSEG;
        float c[4] = {0.f, 0.f, 0.f, 0.f};
        strip_bf16<9>(L.wr + (size_t)st * 144 * 32, sg * 9, sg * 9 + 9, sM, B, c);
        const unsigned g = lane >> 2, t = lane & 3;
        for (int h2 = 0; h2 < 2; h2++) {
          const int b = 2 * t + h2;
          if (b < B) {
            P.rpart[((size_t)b * RSEG + sg) * 128 + st * 16 + g] = c[h2];
            P.rpart[((size_t)b * RSEG + sg) * 128 + st * 16 + g + 8] = c[2 + h2];
          }
        }
      }
    }
    GBAR(7);

    // ---------------------------------------------------------------- routing (every block, redundant)
    int* sel = (int*)(sc + 3072);        // [8][8] expert ids
    float* selw = sc + 3136;             // [8][8] weights
    int* uni = (int*)(sc + 3200);        // [128] union experts (sorted)
    int* uslot = (int*)(sc + 3328);      // [128][8] slot of token b in union expert u (-1)
    int* nuni = (int*)(sc + 3330 + 1024);
    {
      if (w < B) {
        const int b = w;
        float lg[4], sv[4];
        for (int i = 0; i < 4; i++) {
          const int e = lane * 4 + i;
          float s = 0.f;
          for (int sg = 0; sg < RSEG; sg++) s += ldf(P.rpart + ((size_t)b * RSEG + sg) * 128 + e);
          lg[i] = s;
          sv[i] = sigm(s) + L.rbias[e];
        }
        float wsum = 0.f, wsel = 0.f;
        int mine = -1;
        for (int r = 0; r < TOPK; r++) {
          float bv = -1e30f; int bi = 1 << 30;
          for (int i = 0; i < 4; i++) if (sv[i] > bv) { bv = sv[i]; bi = lane * 4 + i; }
          for (int o = 16; o; o >>= 1) {
            const float ov = __shfl_xor_sync(0xffffffffu, bv, o);
            const int oi = __shfl_xor_sync(0xffffffffu, bi, o);
            if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
          }
          if ((bi >> 2) == lane) { sv[bi & 3] = -1e30f; }
          const float sg_ = __shfl_sync(0xffffffffu, sigm(lg[bi & 3]), bi >> 2);
          if (lane == 0) { sel[b * 8 + r] = bi; }
          if (lane == r) { mine = bi; wsel = sg_; }
          wsum += sg_;
        }
        if (lane < TOPK) selw[b * 8 + lane] = wsel / wsum * 8.0f;
      }
      __syncthreads();
      if (tid < NE) {
        int f = -1;
        for (int b = 0; b < B; b++) for (int r = 0; r < TOPK; r++) if (sel[b * 8 + r] == tid) f = 1;
        red[tid] = f > 0 ? 1.f : 0.f;
      }
      __syncthreads();
      if (tid < NE) {
        int idx = 0;
        for (int e = 0; e < tid; e++) idx += red[e] > 0.f;
        if (red[tid] > 0.f) {
          uni[idx] = tid;
          for (int b = 0; b < MAXB; b++) {
            int s = -1;
            if (b < B) for (int r = 0; r < TOPK; r++) if (sel[b * 8 + r] == tid) s = r;
            uslot[idx * 8 + b] = s;
          }
        }
        if (tid == NE - 1) *nuni = idx + (red[tid] > 0.f);
      }
      __syncthreads();
    }
    const int U = *nuni;

    // ---------------------------------------------------------------- phase G: expert gate|up projections
    {
      __half* x16 = (__half*)sIn;     // [8][XS]
      float* xsc = sc + 2600;         // per-token scale 2^-s
      for (int b = 0; b < B; b++) {
        float m = 0.f;
        for (int k = tid; k < H; k += NT) m = fmaxf(m, fabsf(ldbf(P.xm + (size_t)b * H + k)));
        m = warp_max(m);
        if (lane == 0) red[w] = m;
        __syncthreads();
        if (tid == 0) {
          float mm = 0.f;
          for (int i = 0; i < NW; i++) mm = fmaxf(mm, red[i]);
          int e = 0;
          if (mm > 0.f) { frexpf(mm, &e); }   // mm in [2^(e-1), 2^e)
          const int s = 15 - e;               // mm * 2^s in [2^14, 2^15)
          xsc[b] = ldexpf(1.f, -s);
          xsc[8 + b] = ldexpf(1.f, s);
        }
        __syncthreads();
        const float up = xsc[8 + b];
        for (int k = tid; k < H; k += NT) x16[b * XS + k] = __float2half_rn(ldbf(P.xm + (size_t)b * H + k) * up);
      }
      __syncthreads();
      const int N = U * 144;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      const bool mx = L.mx != 0;
      const size_t cstride = mx ? (size_t)144 * 72 * 512 : (size_t)144 * 36 * 512;
      const size_t sstride = mx ? (size_t)144 * 72 * 16 : (size_t)144 * 36 * 64;
      block_strips(s0, s1, mx ? 72 : 36, red,
        [&](int s, int k0, int k1, float c[4]) {
          const int u = s / 144, st = s % 144, e = uni[u];
          if (mx) {
            const uint4* A = (const uint4*)(L.w13 + e * cstride) + (size_t)st * 72 * 32;
            const unsigned short* S = (const unsigned short*)(L.w13s + e * sstride) + (size_t)st * 72 * 8;
            strip_mx<4>(A, S, k0, k1, x16, B, c);
          } else {
            const uint4* A = (const uint4*)(L.w13 + e * cstride) + (size_t)st * 36 * 32;
            const uint2* S = (const uint2*)(L.w13s + e * sstride) + (size_t)st * 36 * 8;
            strip_nv<4>(A, S, k0, k1, x16, B, c);
          }
        },
        [&](int s, float c[4]) {
          const int u = s / 144, st = s % 144, e = uni[u];
          const unsigned g = lane >> 2, t = lane & 3;
          const float fe = mx ? 1.f : L.f13[e];
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) {
              const int sl = uslot[u * 8 + b];
              if (sl >= 0) {
                const float gg = c[h2] * xsc[b] * fe, uu = c[2 + h2] * xsc[b] * fe;
                float act = 4.f * tanhf(gg * 0.25f) * sigm(gg) * (25.f * tanhf(uu * 0.04f));
                act = rbf(act * selw[b * 8 + sl]);
                P.act[((size_t)b * 8 + sl) * IM + st * 8 + g] = __float2half_rn(act * 64.f);
              }
            }
          }
        });
    }
    GBAR(8);

    // ---------------------------------------------------------------- phase H: expert down projections
    {
      const bool mx = L.mx != 0;
      const int nkc = mx ? 36 : 18;                       // chunks per expert
      const size_t cstride = mx ? (size_t)144 * 36 * 512 : (size_t)144 * 18 * 512;
      const size_t sstride = mx ? (size_t)144 * 36 * 16 : (size_t)144 * 18 * 64;
      const int N = 144;
      const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
      bf16* mr = P.mring + (size_t)slot * MAXB * 4 * H;
      block_strips(s0, s1, U * nkc, red,
        [&](int st, int k0, int k1, float c[4]) {
          const unsigned g = lane >> 2, t = lane & 3;
          int kq = k0;
          while (kq < k1) {
            const int u = kq / nkc, e = uni[u];
            const int ce = (u + 1) * nkc < k1 ? (u + 1) * nkc : k1;
            const int cl0 = kq - u * nkc, cl1 = ce - u * nkc;
            // B operand: act of token g in expert u (zero if unused)
            const int sl = g < (unsigned)B ? uslot[u * 8 + g] : -1;
            const __half* ab = P.act + ((size_t)g * 8 + (sl < 0 ? 0 : sl)) * IM + 2 * t;
            float tmp[4] = {0.f, 0.f, 0.f, 0.f};
            if (mx) {
              const uint4* A = (const uint4*)(L.w2 + e * cstride) + (size_t)st * 36 * 32;
              const unsigned short* S = (const unsigned short*)(L.w2s + e * sstride) + (size_t)st * 36 * 8;
              for (int ch = cl0; ch < cl1; ch++) {
                const uint4 av = ldw(A + (size_t)ch * 32 + lane);
                const unsigned short sv = ldw16(S + (size_t)ch * 8 + g);
                float tt[4] = {0.f, 0.f, 0.f, 0.f};
                for (int q = 0; q < 2; q++) {
                  uint32_t r[4];
                  const uint32_t w0 = (&av.x)[2 * q], w1 = (&av.x)[2 * q + 1];
                  r[0] = e4m3x2((unsigned short)(w0 & 0xffff)); r[1] = e4m3x2((unsigned short)(w0 >> 16));
                  r[2] = e4m3x2((unsigned short)(w1 & 0xffff)); r[3] = e4m3x2((unsigned short)(w1 >> 16));
                  const int kk = ch * 32 + q * 16;
                  uint32_t b0 = 0, b1 = 0;
                  if (sl >= 0) { b0 = __ldcg((const unsigned*)(ab + kk)); b1 = __ldcg((const unsigned*)(ab + kk + 8)); }
                  mma_f16(tt, r, b0, b1);
                }
                const float sg = e8m0(sv & 0xff), sg8 = e8m0(sv >> 8);
                tmp[0] = fmaf(tt[0], sg, tmp[0]); tmp[1] = fmaf(tt[1], sg, tmp[1]);
                tmp[2] = fmaf(tt[2], sg8, tmp[2]); tmp[3] = fmaf(tt[3], sg8, tmp[3]);
              }
            } else {
              const uint4* A = (const uint4*)(L.w2 + e * cstride) + (size_t)st * 18 * 32;
              const uint2* S = (const uint2*)(L.w2s + e * sstride) + (size_t)st * 18 * 8;
              for (int ch = cl0; ch < cl1; ch++) {
                const uint4 av = ldw(A + (size_t)ch * 32 + lane);
                const uint2 sv = ldw2(S + (size_t)ch * 8 + g);
                for (int q = 0; q < 4; q++) {
                  uint32_t r[4];
                  e2m1x8((&av.x)[q], r);
                  const uint32_t sp = (q < 2 ? sv.x : sv.y) >> (16 * (q & 1));
                  const uint32_t scv = e4m3x2((unsigned short)(sp & 0xffff));
                  const uint32_t sg = lo2(scv), sg8 = hi2(scv);
                  r[0] = hmul2(r[0], sg); r[2] = hmul2(r[2], sg); r[1] = hmul2(r[1], sg8); r[3] = hmul2(r[3], sg8);
                  const int kk = ch * 64 + q * 16;
                  uint32_t b0 = 0, b1 = 0;
                  if (sl >= 0) { b0 = __ldcg((const unsigned*)(ab + kk)); b1 = __ldcg((const unsigned*)(ab + kk + 8)); }
                  mma_f16(tmp, r, b0, b1);
                }
              }
            }
            const float fe = mx ? 1.f : L.f2[e];
            for (int i = 0; i < 4; i++) c[i] = fmaf(tmp[i], fe, c[i]);
            kq = ce;
          }
        },
        [&](int st, float c[4]) {
          const unsigned g = lane >> 2, t = lane & 3;
          for (int h2 = 0; h2 < 2; h2++) {
            const int b = 2 * t + h2;
            if (b < B) {
              mr[((size_t)b * 4 + (pos & 3)) * H + st * 16 + g] = __float2bfloat16(c[h2] * (1.f / 64.f));
              mr[((size_t)b * 4 + (pos & 3)) * H + st * 16 + g + 8] = __float2bfloat16(c[2 + h2] * (1.f / 64.f));
            }
          }
        });
    }
    GBAR(9);
  }

  // ------------------------------------------------------------------ head: final mix, norm, unembedding
  {
    Src fs[5];
    int n = attn_blocks(P, 24, 0, fs);
    fs[n++] = mksrc(sX, XS, 2);
    DotSet d{};
    d.nv = n; for (int i = 0; i < n; i++) d.S[i] = fs[i];
    d.nq = 1; d.q[0] = P.outq;
    dot_pass(d, B, part2, sc + SC_DOT);
    if (tid < B) coefs(sc + SC_DOT + tid * DSL, n, 0, false, false, sc + SC_CFX + tid * 8);
    __syncthreads();
    bf16* hs = sIn;
    for (int p = tid; p < B * NCH; p += NT) {
      const int b = p / NCH, c = p % NCH;
      float x[4], wv[4];
      const float* cf = sc + SC_CFX + b * 8;
      mix4(fs, n, cf, b, c, x);
      ldw4(P.finalnorm, c, wv);
      for (int e = 0; e < 4; e++) x[e] = x[e] * cf[7] * wv[e];
      *(uint2*)(hs + b * XS + 4 * c) = pack4(x);
    }
    __syncthreads();
    const int N = VSTRIPS;
    const int s0 = blk * N / nb, s1 = (blk + 1) * N / nb;
    block_strips(s0, s1, 144, red,
      [&](int s, int k0, int k1, float c[4]) { strip_bf16<8>(P.unemb + (size_t)s * 144 * 32, k0, k1, hs, B, c); },
      [&](int s, float c[4]) {
        const unsigned g = lane >> 2, t = lane & 3;
        for (int h2 = 0; h2 < 2; h2++) {
          const int b = 2 * t + h2;
          if (b < B) {
            if (s * 16 + g < VOCAB) P.logits[(size_t)b * VOCAB + s * 16 + g] = 30.f * tanhf(c[h2] * (1.f / 30.f));
            if (s * 16 + g + 8 < VOCAB) P.logits[(size_t)b * VOCAB + s * 16 + g + 8] = 30.f * tanhf(c[2 + h2] * (1.f / 30.f));
          }
        }
      });
  }
  if (P.prof) { __syncthreads(); if (tid == 0) { P.prof[2 * pidx + 2 * blk] = gtime(); P.prof[2 * pidx + 2 * blk + 1] = 10 + 16 * 48; } }
  // advance positions: all blocks are past every read of pos (grid barriers above)
  if (blk == 0 && tid < B) P.pos[tid] = pos + 1;
}

// ------------------------------------------------------------------------------------------------ host API
extern "C" {
int mk_sizes(int* out) { out[0] = sizeof(LayerW); out[1] = sizeof(Params); return 0; }

int mk_launch(const void* params, int nb, void* stream) {
  static bool init = false;
  if (!init) {
    cudaFuncSetAttribute(mk_step, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES);
    init = true;
  }
  Params p;
  memcpy(&p, params, sizeof(Params));
  cudaStream_t s = (cudaStream_t)stream;
  cudaMemsetAsync(p.sync, 0, (64 + NAPP * MAXB * NHKV) * sizeof(unsigned), s);
  void* args[] = {&p};
  cudaError_t e = cudaLaunchCooperativeKernel((const void*)mk_step, dim3(nb), dim3(NT), args, SMEM_BYTES, s);
  return (int)e;
}
int mk_occupancy() {
  int n = 0;
  cudaFuncSetAttribute(mk_step, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES);
  cudaOccupancyMaxActiveBlocksPerMultiprocessor(&n, mk_step, NT, SMEM_BYTES);
  return n;
}
const char* mk_err(int e) { return cudaGetErrorString((cudaError_t)e); }
}

// conversion-order self test: out[0..7] = e2m1x8(0x76543210) as floats, out[8..9] = e4m3x2(0x4038) (1.0 lo?, 2.0?)
__global__ void k_cvt_test(float* out) {
  uint32_t r[4];
  e2m1x8(0x00002301u, r);  // byte0 = 0x01 -> (lo nibble 1 = 0.5, hi 0), byte1 = 0x23 -> (lo 3 = 1.5, hi 2 = 1.0)
  for (int i = 0; i < 2; i++) { __half2 h = *(__half2*)&r[i]; out[2 * i] = __low2float(h); out[2 * i + 1] = __high2float(h); }
  uint32_t s = e4m3x2((unsigned short)0x4038);  // lo byte 0x38 = 1.0, hi byte 0x40 = 2.0
  __half2 h = *(__half2*)&s; out[4] = __low2float(h); out[5] = __high2float(h);
}
extern "C" int mk_cvt_test(float* out) { k_cvt_test<<<1, 1>>>(out); return (int)cudaDeviceSynchronize(); }
