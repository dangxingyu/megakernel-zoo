"""Load the checkpoint and lay its weights out for the kernel (engine/mk.cu). Values and formats are the checkpoint's
(BF16 dense weights, NVFP4 / MXFP8 expert codes and their block scales); only the order of the bytes changes.

Layouts (lane = 4 g + t of an m16n8k16 MMA; rows g and g+8 of a 16-row strip):
  bf16 tiles   [strips][k/16][32 lanes][8]: W[g][2t,2t+1], W[g+8][2t,2t+1], W[g][2t+8,+9], W[g+8][2t+8,+9]
  w13 rows     strip s holds gate rows j = 8s..8s+7 (checkpoint rows 2j) at 0..7 and up rows (2j+1) at 8..15
  nvfp4        codes [E][strips][k/64][32][4 q][4 B]: bytes (g,t) (g+8,t) (g,t+4) (g+8,t+4) of k16 subtile q
               scales [E][strips][k/64][8 g][4 q][2]: (row g, row g+8) E4M3 of subtile q
  mxfp8        codes [E][strips][k/32][32][2 q][8 B]: (g,2t) (g,2t+1) (g+8,2t) (g+8,2t+1) (g,2t+8) (g,2t+9) (g+8,..)
               scales [E][strips][k/32][8 g][2]: UE8M0 of rows g, g+8
"""
import json
import torch
from safetensors import safe_open

H = 2304
PRE = "model.llm."


def _lane_idx():
    g = torch.arange(32) // 4
    t = torch.arange(32) % 4
    return g, t


def pack_bf16(W):
    """W [R, K] bf16 (R % 16 == 0, K % 16 == 0) -> uint8 tensor of tiles [R/16][K/16][32][8] bf16."""
    R, K = W.shape
    assert R % 16 == 0 and K % 16 == 0, (R, K)
    g, t = _lane_idx()
    r = torch.stack([g, g, g + 8, g + 8, g, g, g + 8, g + 8], 1).to(W.device)
    c = torch.stack([2 * t, 2 * t + 1, 2 * t, 2 * t + 1, 2 * t + 8, 2 * t + 9, 2 * t + 8, 2 * t + 9], 1).to(W.device)
    W4 = W.view(R // 16, 16, K // 16, 16).permute(0, 2, 1, 3)  # [S, KT, 16, 16]
    T = W4[:, :, r, c]  # [S, KT, 32, 8]
    return T.contiguous().view(torch.uint8).reshape(-1)


def w13_perm(device):
    s = torch.arange(144).repeat_interleave(16)
    m = torch.arange(16).repeat(144)
    j = 8 * s + (m % 8)
    return (2 * j + (m >= 8).long()).to(device)


def pack_nv_codes(Wc):
    """Wc [E, R, K/2] uint8 (rows already in strip order) -> [E][R/16][K/64][32][4][4] uint8."""
    E, R, KB = Wc.shape
    W6 = Wc.view(E, R // 16, 16, KB // 32, 4, 8).permute(0, 1, 3, 4, 2, 5)  # [E,S,C,q,16 rows,8 bytes]
    g, t = _lane_idx()
    r = torch.stack([g, g + 8, g, g + 8], 1).to(Wc.device)
    b = torch.stack([t, t, t + 4, t + 4], 1).to(Wc.device)
    T = W6[:, :, :, :, r, b]  # [E,S,C,q,32,4]
    return T.permute(0, 1, 2, 4, 3, 5).contiguous().reshape(-1)


def pack_nv_scales(Sc):
    """Sc [E, R, K/16] uint8 (strip row order) -> [E][R/16][K/64][8 g][4 q][2]."""
    E, R, NS = Sc.shape
    S5 = Sc.view(E, R // 16, 2, 8, NS // 4, 4)  # [E,S,hi,g,C,q]
    return S5.permute(0, 1, 4, 3, 5, 2).contiguous().reshape(-1)


def pack_mx_codes(Wc):
    """Wc [E, R, K] uint8 (e4m3 bytes, strip row order) -> [E][R/16][K/32][32][2][8]."""
    E, R, K = Wc.shape
    W6 = Wc.view(E, R // 16, 16, K // 32, 2, 16).permute(0, 1, 3, 4, 2, 5)  # [E,S,C,q,16 rows,16 k]
    g, t = _lane_idx()
    r = torch.stack([g, g, g + 8, g + 8, g, g, g + 8, g + 8], 1).to(Wc.device)
    k = torch.stack([2 * t, 2 * t + 1, 2 * t, 2 * t + 1, 2 * t + 8, 2 * t + 9, 2 * t + 8, 2 * t + 9], 1).to(Wc.device)
    T = W6[:, :, :, :, r, k]  # [E,S,C,q,32,8]
    return T.permute(0, 1, 2, 4, 3, 5).contiguous().reshape(-1)


def pack_mx_scales(Sc):
    """Sc [E, R, K/32] uint8 -> [E][R/16][K/32][8 g][2]."""
    E, R, NC = Sc.shape
    S4 = Sc.view(E, R // 16, 2, 8, NC)
    return S4.permute(0, 1, 4, 3, 2).contiguous().reshape(-1)


class Weights:
    def __init__(self, model_dir, device="cuda"):
        cfg = json.load(open(f"{model_dir}/config.json"))["text_config"]
        self.cfg = cfg
        self.local = set(cfg["local_layer_ids"])
        idx = json.load(open(f"{model_dir}/model.safetensors.index.json"))["weight_map"]
        files = sorted(set(v for k, v in idx.items() if k.startswith(PRE)))
        self.t = {}
        for fn in files:
            with safe_open(f"{model_dir}/{fn}", framework="pt", device="cuda:0") as f:
                for k in f.keys():
                    if k.startswith(PRE):
                        self.t[k[len(PRE):]] = f.get_tensor(k)
        self.keep = []  # every tensor the kernel points to
        self.build(device)

    def k(self, x):
        x = x.contiguous()
        self.keep.append(x)
        return x

    def build(self, device):
        t = self.t
        self.layers = []
        dev = device
        perm = w13_perm(dev)
        for i in range(24):
            p = f"layers.{i}."
            glob = i not in self.local
            L = {"glob": int(glob)}
            q = t[p + "attn.wq_du.weight"]
            gate = t[p + "attn.gate_attn.weight"]
            r = t[p + "attn.wr_du.weight"]
            sink = torch.cat([t[p + "attn.attn_sink_proj.weight"], torch.zeros(8, H, dtype=torch.bfloat16, device=dev)])
            k = t[p + "attn.wk_dv.weight"]
            v = t[p + "attn.wv_dv.weight"]
            if glob:
                rows = [q, gate, r, sink, k, t[p + "attn.k_sconv.weight_proj"], v, t[p + "attn.v_sconv.weight_proj"]]
                L.update(koff=6560, kpoff=7584, voff=7616, vpoff=8640, nstrip=542)
            else:
                rows = [q, gate, r, sink, k, v]
                L.update(koff=6560, kpoff=-1, voff=7584, vpoff=-1, nstrip=538)
            Wqkv = torch.cat(rows)
            assert Wqkv.shape[0] == L["nstrip"] * 16
            L["wqkv"] = self.k(pack_bf16(Wqkv))
            L["wo"] = self.k(pack_bf16(t[p + "attn.wo_ud.weight"]))
            L["wr"] = self.k(pack_bf16(t[p + "mlp.gate.weight"]))
            L["rbias"] = self.k(t[p + "mlp.gate.bias"].float())
            ex = p + "mlp.experts."
            w13, w2 = t[ex + "w13_weight"], t[ex + "w2_weight"]
            if w13.dtype == torch.uint8:
                L["mx"] = 0
                L["w13"] = self.k(pack_nv_codes(w13[:, perm]))
                L["w13s"] = self.k(pack_nv_scales(t[ex + "w13_weight_scale"].view(torch.uint8)[:, perm]))
                L["w2"] = self.k(pack_nv_codes(w2))
                L["w2s"] = self.k(pack_nv_scales(t[ex + "w2_weight_scale"].view(torch.uint8)))
                d13 = t[ex + "w13_weight_outer_scale_denominator"].double()
                d2 = t[ex + "w2_weight_outer_scale_denominator"].double()
                L["f13"] = self.k((t[ex + "w13_weight_amax"].double() / d13).float())
                L["f2"] = self.k((t[ex + "w2_weight_amax"].double() / d2).float())
            else:
                L["mx"] = 1
                L["w13"] = self.k(pack_mx_codes(w13.view(torch.uint8)[:, perm]))
                L["w13s"] = self.k(pack_mx_scales(t[ex + "w13_weight_scale"].view(torch.uint8)[:, perm]))
                L["w2"] = self.k(pack_mx_codes(w2.view(torch.uint8)))
                L["w2s"] = self.k(pack_mx_scales(t[ex + "w2_weight_scale"].view(torch.uint8)))
                L["f13"] = L["f2"] = None
            del w13, w2
            if glob:
                L["normq"] = self.k(t[p + "q_input_norm.weight"])
                L["normk"] = self.k(t[p + "k_input_norm.weight"])
                L["normv"] = self.k(t[p + "v_input_norm.weight"])
                L["kconv"] = self.k(t[p + "attn.k_sconv.static_w"])   # [4][1024]
                L["vconv"] = self.k(t[p + "attn.v_sconv.static_w"])
            else:
                n = self.k(t[p + "attn_norm.weight"])
                L["normq"] = L["normk"] = L["normv"] = n
                L["kconv"] = self.k(t[p + "attn.k_sconv.weight"].reshape(1024, 4))
                L["vconv"] = self.k(t[p + "attn.v_sconv.weight"].reshape(1024, 4))
            L["mlpnorm"] = self.k(t[p + "mlp_norm.weight"])
            L["aconv"] = self.k(t[p + "attn_sconv.weight"].reshape(H, 4))
            L["mconv"] = self.k(t[p + "mlp_sconv.weight"].reshape(H, 4))
            L["qscale"] = self.k(t[p + "attn.q_l2_clip.scale"])
            L["rscale"] = self.k(t[p + "attn.rel_l2_clip.scale"])
            L["relp"] = self.k(t[p + "attn.rel_logits_proj.proj"])
            L["aq"] = self.k(t[f"attn_res.attn_queries.{i - 1}"].float().reshape(-1)) if i > 0 else None
            L["mq"] = self.k(t[f"attn_res.mlp_queries.{i}"].float())
            if 6 <= i < 18:
                downs = [pack_bf16(t[p + f"controllers.{w}.down_weight"]) for w in ("attn", "k", "v", "mlp")]
                L["cdown"] = self.k(torch.cat(downs))
                L["cforget"] = self.k(torch.stack([t[p + f"controllers.{w}.forget_weight"] for w in ("attn", "k", "v", "mlp")]))
                L["cgain"] = self.k(torch.stack([t[p + f"controllers.{w}.gain_weight"] for w in ("attn", "k", "v", "mlp")]))
            else:
                L["cdown"] = L["cforget"] = L["cgain"] = None
            self.layers.append(L)
            # free the checkpoint copies of what was packed
            for name in list(t.keys()):
                if name.startswith(p + "mlp.experts.") or name in (p + "attn.wq_du.weight", p + "attn.gate_attn.weight",
                                                                   p + "attn.wk_dv.weight", p + "attn.wv_dv.weight", p + "attn.wo_ud.weight"):
                    del t[name]
        torch.cuda.empty_cache()
        self.emb = self.k(t["embed.weight"])
        self.embnorm = self.k(t["embed_norm.weight"])
        self.finalnorm = self.k(t["norm.weight"])
        self.outq = self.k(t["attn_res.output_query"].float())
        qm = t["middle_cycle_cross_pass_queries"].float().unflatten(0, (-1, 2))
        kv = t["middle_cycle_cross_pass_kv_queries"].float().unflatten(0, (-1, 2))
        self.loopq = self.k(torch.stack([qm[:, 0], kv[:, 0], kv[:, 1], qm[:, 1]], dim=1))  # [12][4][2304]
        self.unemb = self.k(pack_bf16(t["unembed.weight"][: 12504 * 16]))
        del t["unembed.weight"]
        torch.cuda.empty_cache()
