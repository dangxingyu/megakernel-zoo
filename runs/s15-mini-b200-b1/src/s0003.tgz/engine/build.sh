#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
rm -f build/libmk.so
EXTRA=${MK_NVCC_EXTRA:-}
nvcc -O3 -std=c++17 -gencode arch=compute_100a,code=sm_100a -lineinfo -Xptxas -v -shared -Xcompiler -fPIC $EXTRA -o build/libmk.so mk.cu 2> build/ptxas.log || { cat build/ptxas.log; exit 1; }
grep -E "registers|spill" build/ptxas.log | head -5
