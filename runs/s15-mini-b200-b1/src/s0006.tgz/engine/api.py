"""Inkling-2-Mini decode engine: one persistent cooperative CUDA kernel per decode step (engine/mk.cu), weights
packed at load (engine/pack.py). Contract: Engine(model_dir, max_batch, max_context), reset(), step(tokens[B]),
generate(), stats().
"""
import ctypes
import os
import struct
from pathlib import Path

import torch

from pack import Weights

HERE = Path(__file__).resolve().parent
MAXB = 8
H = 2304
VOCAB = 200058
NAPP = 48

LAYER_FIELDS = ["wqkv", "wo", "wr", "rbias", "w13", "w13s", "f13", "w2", "w2s", "f2", "normq", "normk", "normv",
                "mlpnorm", "kconv", "vconv", "aconv", "mconv", "qscale", "rscale", "relp", "aq", "mq", "cdown",
                "cforget", "cgain", "glob", "mx", "nstrip", "koff", "voff", "kpoff", "vpoff"]
PARAM_FIELDS = ["L", "emb", "embnorm", "finalnorm", "outq", "loopq", "unemb", "tok", "pos", "logits", "kc", "vc",
                "kring", "vring", "oring", "mring", "blk", "pbuf", "att", "xm", "qkv", "ao", "apart", "gpart", "coef",
                "xg", "rpart", "act", "sync", "dbg", "outkey", "tokkey", "hostout", "seq", "nohead", "hpart", "epart", "prof", "ctx", "B", "nb"]


def _ptr(x):
    if x is None:
        return 0
    if isinstance(x, int):
        return x & 0xFFFFFFFFFFFFFFFF
    return x.data_ptr()


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        assert 1 <= max_batch <= MAXB, max_batch
        self.lib = ctypes.CDLL(str(HERE / "build" / "libmk.so"))
        self.lib.mk_launch.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
        self.lib.mk_err.restype = ctypes.c_char_p
        sizes = (ctypes.c_int * 2)()
        self.lib.mk_sizes(sizes)
        assert sizes[0] == 8 * len(LAYER_FIELDS) and sizes[1] == 8 * len(PARAM_FIELDS), (sizes[0], sizes[1])
        self.max_batch, self.max_context = max_batch, max_context
        dev = torch.device("cuda")
        self.w = Weights(model_dir, dev)
        occ = self.lib.mk_occupancy()
        assert occ >= 1, "kernel does not fit on an SM"
        self.nb = torch.cuda.get_device_properties(0).multi_processor_count
        ctx = max_context
        bf, f32 = torch.bfloat16, torch.float32
        z = lambda *s, dt=bf: torch.zeros(*s, dtype=dt, device=dev)  # noqa: E731
        self.buf = dict(
            pos=z(MAXB, dt=torch.int32),
            kc=z(NAPP, MAXB, 8, ctx, 128), vc=z(NAPP, MAXB, 8, ctx, 128),
            kring=z(NAPP, MAXB, 4, 1024), vring=z(NAPP, MAXB, 4, 1024),
            oring=z(NAPP, MAXB, 4, H), mring=z(NAPP, MAXB, 4, H),
            blk=z(8, MAXB, H), pbuf=z(2, MAXB, H), att=z(MAXB, H), xm=z(MAXB, H),
            qkv=z(MAXB, 8704, dt=f32), ao=z(MAXB, 3072), apart=z(MAXB, 24, 40, 132, dt=f32),
            gpart=z(32768, dt=f32), coef=z(1024, dt=f32), xg=z(3, MAXB, H, dt=f32), rpart=z(MAXB, 16, 128, dt=f32),
            act=z(MAXB, 8, 1152, dt=torch.float16), hpart=z(144, MAXB, 40, dt=f32), epart=z(144, MAXB, 40, dt=f32), sync=z(64 + NAPP * MAXB * 8, dt=torch.int32),
        )
        self.dbg = None
        self.prof = None
        lw = []
        for L in self.w.layers:
            lw += [_ptr(L[f]) if not isinstance(L[f], int) else (L[f] & 0xFFFFFFFFFFFFFFFF) for f in LAYER_FIELDS]
        blob = struct.pack(f"<{len(lw)}Q", *lw)
        self.layer_dev = torch.frombuffer(bytearray(blob), dtype=torch.uint8).to(dev)
        self._layer_blob = ctypes.create_string_buffer(blob, len(blob))
        err = self.lib.mk_set_layers(self._layer_blob)
        assert err == 0, err
        self.pos = 0
        self.B = None
        self.steps = 0
        self._tok = None

    def _params(self, tok, B, logits, outkey=None, tokkey=None, hostout=None, seq=0, nohead=0):
        w, b = self.w, self.buf
        vals = dict(L=self.layer_dev, emb=w.emb, embnorm=w.embnorm, finalnorm=w.finalnorm, outq=w.outq, loopq=w.loopq,
                    unemb=w.unemb, tok=tok, dbg=self.dbg, prof=self.prof, ctx=self.max_context, B=B, nb=self.nb,
                    outkey=outkey, tokkey=tokkey, hostout=hostout, seq=seq, nohead=nohead, **b)
        vals["logits"] = logits
        arr = [_ptr(vals[f]) for f in PARAM_FIELDS]
        return ctypes.create_string_buffer(struct.pack(f"<{len(arr)}Q", *arr), 8 * len(arr))

    def reset(self) -> None:
        self.pos = 0
        self.B = None
        self.buf["pos"].zero_()

    @torch.no_grad()
    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        B = int(tokens.shape[0])
        if B < 1 or B > self.max_batch:
            raise ValueError(f"batch {B} outside 1..{self.max_batch}")
        if self.B is None:
            self.B = B
        elif B != self.B:
            raise ValueError("batch size changed without reset()")
        if self.pos >= self.max_context:
            raise ValueError(f"context full ({self.max_context} positions)")
        tok = tokens.to(device="cuda", dtype=torch.int64).contiguous()
        self._tok = tok
        logits = torch.empty(B, VOCAB, dtype=torch.float32, device="cuda")   # fresh: callers may keep it
        params = self._params(tok, B, logits)
        stream = torch.cuda.current_stream().cuda_stream
        err = self.lib.mk_launch(params, self.nb, ctypes.c_void_p(stream))
        if err != 0:
            raise RuntimeError("mk_launch: " + self.lib.mk_err(err).decode())
        self.pos += 1
        self.steps += 1
        return logits

    def _launch(self, params):
        stream = torch.cuda.current_stream().cuda_stream
        err = self.lib.mk_launch(params, self.nb, ctypes.c_void_p(stream))
        if err != 0:
            raise RuntimeError("mk_launch: " + self.lib.mk_err(err).decode())

    @torch.no_grad()
    def generate(self, tokens: torch.Tensor, n_steps: int) -> torch.Tensor:
        """Greedy decode on the device: argmax inside the kernel, fed to the next step on the device."""
        B = int(tokens.shape[0])
        if self.B is None:
            self.B = B
        elif B != self.B:
            raise ValueError("batch size changed without reset()")
        if self.pos + n_steps > self.max_context:
            raise ValueError(f"context full ({self.max_context} positions)")
        tok = tokens.to(device="cuda", dtype=torch.int64).contiguous()
        keys = torch.zeros(n_steps, MAXB, dtype=torch.int64, device="cuda")
        self._keep = [tok, keys]
        for k in range(n_steps):
            prm = self._params(tok if k == 0 else None, B, None, outkey=keys[k].data_ptr(),
                               tokkey=None if k == 0 else keys[k - 1].data_ptr())
            self._launch(prm)
        self.pos += n_steps
        self.steps += n_steps
        return (0xFFFFFFFF - (keys[:, :B] & 0xFFFFFFFF)).t().contiguous()

    # ---------------------------------------------------------------------------------------- serving
    def submit(self, rid, prompt, n):
        prompt = [int(t) for t in prompt]
        if not prompt or any(t < 0 or t >= 201024 for t in prompt):
            raise ValueError("prompt token ids must be in [0, 201024) and non-empty")
        self._ensure_server()
        with self._lock:
            if int(n) <= 0:
                self._events.append((rid, [], True))
                return
            self._pending.append((rid, prompt, int(n)))
        self._wake.set()

    def poll(self):
        if getattr(self, "_thread", None) is None:
            return []
        with self._lock:
            ev, self._events = self._events, []
        return ev

    def _ensure_server(self):
        if getattr(self, "_thread", None) is not None:
            return
        import threading
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._pending, self._events = [], []
        self._hostout = torch.zeros(4, MAXB + 2, dtype=torch.int32).pin_memory()
        self._hkeys = torch.zeros(4, MAXB, dtype=torch.int64, device="cuda")
        self._stop = False
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    def _serve(self):
        import time
        torch.cuda.set_device(0)
        stream = torch.cuda.Stream()
        seq = 0
        gather_s = float(os.environ.get("MK_GATHER_MS", "4")) / 1e3
        with torch.cuda.stream(stream), torch.no_grad():
            while not self._stop:
                with self._lock:
                    have = len(self._pending)
                if 0 < have < self.max_batch:      # requests that arrive together form one cohort
                    t_end = time.perf_counter() + gather_s
                    while time.perf_counter() < t_end:
                        with self._lock:
                            if len(self._pending) >= self.max_batch:
                                break
                        time.sleep(0.0002)
                with self._lock:
                    if not self._pending:
                        cohort = None
                    else:
                        L0 = len(self._pending[0][1])
                        cohort = [r for r in self._pending if len(r[1]) == L0][: self.max_batch]
                        self._pending = [r for r in self._pending if all(r is not c for c in cohort)]
                if cohort is None:
                    self._wake.wait(0.002); self._wake.clear()
                    continue
                B = len(cohort)
                P = len(cohort[0][1])
                nmax = max(r[2] for r in cohort)
                nmax = min(nmax, self.max_context - P + 1)
                self.reset(); self.B = B
                ids = torch.tensor([r[1] for r in cohort], dtype=torch.int64).cuda()
                idsT = ids.t().contiguous()      # [P][B]: one contiguous row per step
                for t in range(P - 1):
                    self._launch(self._params(idsT[t], B, None, nohead=1))
                self.pos = P - 1
                hold = [ids, idsT]
                sent = [0] * B
                pending_steps = []   # (k, slot index in the host ring, seq)
                k = 0
                depth = 3
                while k < nmax or pending_steps:
                    while k < nmax and len(pending_steps) < depth:
                        sl = k % 4
                        seq += 1
                        prm = self._params(idsT[P - 1] if k == 0 else None, B, None,
                                           outkey=self._hkeys[sl].data_ptr(),
                                           tokkey=None if k == 0 else self._hkeys[(k - 1) % 4].data_ptr(),
                                           hostout=self._hostout[sl].data_ptr(), seq=seq)
                        self._launch(prm)
                        pending_steps.append((k, sl, seq))
                        k += 1
                    kk, sl, sq = pending_steps[0]
                    while int(self._hostout[sl, MAXB]) != sq:
                        time.sleep(0)
                    pending_steps.pop(0)
                    toks = self._hostout[sl, :B].tolist()
                    ev = []
                    for i, r in enumerate(cohort):
                        if kk < r[2] and kk < nmax:
                            ev.append((r[0], [toks[i]], kk == min(r[2], nmax) - 1))
                    with self._lock:
                        self._events += ev
                self.pos = P - 1 + nmax
                torch.cuda.current_stream().synchronize()

    def close(self) -> None:
        if getattr(self, "_thread", None) is not None:
            self._stop = True
            self._thread.join(timeout=5)
        self.w = None
        self.buf = None

    def stats(self) -> dict:
        return {"implementation": "mk persistent kernel", "track": "A", "steps": self.steps}
