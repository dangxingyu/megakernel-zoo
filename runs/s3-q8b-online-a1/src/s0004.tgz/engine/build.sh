#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
NVCC=${NVCC:-nvcc}
if [ ! -f libeng.so ] || [ eng.cu -nt libeng.so ] || [ build.sh -nt libeng.so ]; then
  $NVCC -O3 -use_fast_math -std=c++17 -arch=sm_90 -shared -Xcompiler -fPIC ${MK_DEFS:-} -o libeng.so.tmp eng.cu
  mv libeng.so.tmp libeng.so
fi
