// Decode megakernel for Qwen3-8B (bf16 weights) on one H100.
// One CUDA source: device code for every operator of a decode step + a small host API (ctypes).
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define H 4096
#define NL 36
#define QKV_ROWS 6144
#define INNER 12288
#define VOCAB 151936
// Warps per block. 65536 registers per SM: 32 warps -> 64 registers per thread, 24 -> 80 (the build passes
// -maxrregcount accordingly), 16 -> 128. Measured (generate us/step B=1 / B=8), each with its best pipeline depth:
// 32 warps, 2 loads: 5377 / 5857; 24 warps, 3 loads: 5340 / 5838; 16 warps, 8 loads: 5350 / 5878.
#ifndef NWARP
#define NWARP 24
#endif
#define NTHREAD (NWARP * 32)
#define MAXB 8
#ifndef LM_NEXT
#define LM_NEXT 1      // step(): prefetch layer 0's first q/k/v tile at the end of lm_head for the next launch
#endif
#ifndef WCB
#define WCB 3               // wide-layout input copy: loads per thread requested before the stores (4 spills)
#endif
#ifndef ECB
#define ECB 2               // input copy: loads requested back to back per thread before the stores
#endif
#ifndef NORM_WARP0
#define NORM_WARP0 (NWARP / 2)   // first of the 8 warps that compute 1/rms (one per sequence) in a norm phase's entry
#endif
#define NLOAD (NWARP - 1)  // warps 0..NLOAD-1 stream weights
#define CW (NWARP - 1)     // coordinator warp: sums the partial accumulators, runs the epilogue, drives the barrier

// tiles x ksteps of each matrix (tile = 16 output rows, kstep = 16 input dims, 512 bytes per (tile,kstep))
#define QKV_T 384
#define O_T 256
#define GU_T 1536
#define DN_T 256
#define LM_T 9496
#define KS_H 256
#define KS_I 768
// offsets inside a layer, in uint4 (16 byte) units
#define OFF_QKV 0ull
#define OFF_O (OFF_QKV + (size_t)QKV_T * KS_H * 32)
#define OFF_GU (OFF_O + (size_t)O_T * KS_H * 32)
#define OFF_DN (OFF_GU + (size_t)GU_T * KS_H * 32)
#define LAYER_U4 (OFF_DN + (size_t)DN_T * KS_I * 32)

#define SX_BYTES (KS_I * 32 * 8)
#define RED_BYTES (2 * 32 * 32 * 16)
#define MISC_OFF (SX_BYTES + RED_BYTES)   // Params copy, tile table, small scratch
#define MISC_BYTES 1024
#define TB_OFF (MISC_OFF + 256)           // int[8]: this block's [t0,t1) for qkv, down, gate+up, lm
#define TBO_OFF (TB_OFF + 48)             // int[2]: this block's [t0,t1) for o (depends on the batch size)
#define RN_OFF (MISC_OFF + 320)           // float[8]: 1/rms of the current norm, per sequence
#define SCR_OFF (MISC_OFF + 352)          // float[168]
#define CTL_OFF (MISC_OFF + 992)          // Ctl: layer, barrier index, generate step
#define SMEM_BYTES (SX_BYTES + RED_BYTES + MISC_BYTES)
#define ATT_OFF_BYTES (KS_H * 32 * 8)     // attention scratch lives in sx beyond the K=4096 fragments
#define STASH_OFF (KS_H * 32 * 8)         // non-attention blocks: image of their first o tile (256 ksteps x 512 B)
#define MAX_CTX_SMEM 3904

#define BARRIERS_PER_LAYER 5
#define BARRIERS_PER_STEP (1 + NL * BARRIERS_PER_LAYER)
#define BARRIERS_PER_GEN_STEP (2 + NL * BARRIERS_PER_LAYER)

struct Params {
  const uint4* W;             // packed weights: 36 layers (qkv, o, gateup, down), then lm_head
  const unsigned short* embed;// [VOCAB][H] bf16
  const float* norm_w;        // [2*NL+1][H]: input norm l, post-attention norm l, ..., final norm
  const float* qk_norm_w;     // [NL][2][128]
  const float* rope;          // [max_ctx][128]: cos[64], sin[64]
  float* xres;                // [MAXB][H] residual stream, float32
  float* qkv;                 // [MAXB][QKV_ROWS]
  unsigned short* afrag;      // [MAXB][KS_H][4][4] bf16: attention output as MMA B-fragments
  unsigned short* mfrag;      // [MAXB][KS_I][4][4] bf16: silu(gate)*up as MMA B-fragments
  unsigned short* xfrag;      // [MAXB][KS_H][4][4] bf16: w_norm * x (not yet scaled by 1/rms) for the next norm+matvec
  float* ssq;                 // [MAXB][256]: per 16-row tile sum of x^2 (partial sums of the next RMSNorm)
  uint4* kc;                  // K cache, MMA A-fragment layout: [NL][MAXB][8][ctx_tiles][8][32]
  uint4* vc;                  // V cache (transposed), [NL][MAXB][8][ctx_tiles][8][32]
  unsigned* sync;             // barrier counter
  unsigned* wstat;            // calibration: [9 phase kinds][blocks] barrier poll iterations (how long a block waited)
  const int* tiles;           // [blocks][8]: tile ranges per block
  const int* tiles_o;         // [MAXB][blocks][2]: tile ranges of the o projection per batch size
  const long long* tokens;    // [B]
  float* logits;              // [B][VOCAB]
  long long* gen_out;         // generate(): [B][n_steps] tokens
  float* bm_val;              // generate(): [MAXB][blocks] best logit seen by each block
  int* bm_idx;                // generate(): [MAXB][blocks] its row
  int n_steps;
  unsigned* clk;              // TRACE: software clock
  unsigned* trace;            // TRACE: [blocks][8 phases][8 points]
  int nwork;                  // number of working blocks (TRACE: one less than the grid)
  int stop_layer;             // debug: run only the first stop_layer layers (NL in production)
  int calib;                  // calibration: record barrier waits
  unsigned trace_stop;        // TRACE: value of *sync at which the clock stops
  size_t kv_stride;           // uint4 per (layer, seq, kv head)
  unsigned sync_base;
  int B, pos;
};

#define TSEL_O T_O
enum { T_QKV = 0, T_DN = 1, T_GU = 2, T_LM = 3, T_O = 6 };   // index into the block's tile table (T_O: per batch size)

// TRACE build: the last block is a software clock (a counter in global memory), the coordinator thread of every
// working block timestamps points of the phases of one layer. Diagnosis only; never in a submission.
#ifdef TRACE
#ifndef TRACE_LAYER
#define TRACE_LAYER 17
#endif
#define TR_PARAM , int tr
#define TR_ARG(x) , (x)
#define TP(i) do { if (tr >= 0 && threadIdx.x == CW * 32) P.trace[(blockIdx.x * 8 + tr) * 8 + (i)] = *(volatile unsigned*)P.clk; } while (0)
#define NWORK (P.nwork)
#define TRACE_EXTRA 1
#else
#define TRACE_EXTRA 0
#define TR_PARAM
#define TR_ARG(x)
#define TP(i) do { } while (0)
#define NWORK ((int)gridDim.x)
#endif

// Control state of the block lives in shared memory, not in registers: the kernel's top level only makes
// calls, and a value kept across a call is spilled to local memory by every one of the 1024 threads at every
// phase boundary (measured: +85 us/step). The coordinator thread updates it before a block barrier.
struct Ctl { int l; unsigned bi; int s; int lm; };   // layer, barrier index, generate step, lm phase (PH_LM / PH_LMARG)

#define MMA(c, a, b) asm volatile( \
  "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
  : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) \
  : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y))

__device__ __forceinline__ unsigned short f2bf(float f) {
  unsigned u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (unsigned short)(u >> 16);
}
__device__ __forceinline__ float bf2f(unsigned v) { return __uint_as_float(v << 16); }

// index (in bf16 units) of element k of batch column n inside a B-fragment buffer of `stride` entries per kstep
// smem layout: [kstep][lane = 4n + t][slot]; global compact layout: [n][kstep][t][slot]
__device__ __forceinline__ int frag_slot(int k) { return (k & 1) + 2 * ((k >> 3) & 1); }
__device__ __forceinline__ int frag_t(int k) { return (k & 7) >> 1; }
__device__ __forceinline__ int sx_index(int k, int n) { return (((k >> 4) * 32 + 4 * n + frag_t(k)) << 2) + frag_slot(k); }
__device__ __forceinline__ size_t gfrag_index_c(int k, int n, int ksteps) { return ((((size_t)n * ksteps + (k >> 4)) * 4 + frag_t(k)) << 2) + frag_slot(k); }
// With WIDE_MIN_B or more sequences the fragments are stored in global memory exactly as they sit in shared
// memory ([kstep][32 lanes][4 bf16], unused lanes included): the input copy is then a plain block copy instead
// of ~12 instructions of index arithmetic per 16 bytes on every thread (the copy is 64-196 KB per SM and phase).
// With few sequences the compact per-sequence layout is smaller to copy. Same values either way.
#ifndef WIDE_MIN_B
#define WIDE_MIN_B 5
#endif
__device__ __forceinline__ size_t gfrag_index(int k, int n, int ksteps, int B) {
  return B >= WIDE_MIN_B ? (size_t)sx_index(k, n) : gfrag_index_c(k, n, ksteps);
}

__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
__device__ __forceinline__ float warp_max(float v) {
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 16));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 8));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 4));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 2));
  v = fmaxf(v, __shfl_xor_sync(0xffffffffu, v, 1));
  return v;
}

// ---------------------------------------------------------------------------------------------------------
// entries: put the bf16 input of a matvec into shared memory as MMA B-fragments
// ---------------------------------------------------------------------------------------------------------

// x = embedding row (bf16 -> f32); also publishes the input of the first RMSNorm+matvec:
// fragments of bf16(w * x) and per-tile partial sums of x^2 (the 1/rms factor is applied to matvec OUTPUTS)
// gs < 0: step(): token = tokens[b]. gs >= 0: generate() step gs: token = tokens[b] for gs == 0, otherwise the
// argmax of the previous step's logits (reduced over the per-block maxima, ties -> lowest row, like torch.argmax),
// which is also stored as output token gs-1. embed == 0: only the argmax (after the last step).
__device__ __forceinline__ void op_embed(unsigned char* smem, int gs, int embed) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const int b = blockIdx.x, tid = threadIdx.x, lane = tid & 31;
  if (b < P.B) {
    long long tok;
    if (gs <= 0) {
      tok = P.tokens[b];
    } else {
      int* stok = (int*)(smem + SCR_OFF);
      if (tid < 32) {
        const int nb = NWORK;
        float bv = -__int_as_float(0x7f800000); int bidx = 0x7fffffff;
        for (int i = lane; i < nb; i += 32) {
          float v = __ldcg(P.bm_val + b * nb + i); int ix = __ldcg(P.bm_idx + b * nb + i);
          if (v > bv || (v == bv && ix < bidx)) { bv = v; bidx = ix; }
        }
#pragma unroll
        for (int o = 16; o > 0; o >>= 1) {
          float v = __shfl_xor_sync(0xffffffffu, bv, o); int ix = __shfl_xor_sync(0xffffffffu, bidx, o);
          if (v > bv || (v == bv && ix < bidx)) { bv = v; bidx = ix; }
        }
        if (lane == 0) { stok[0] = bidx; P.gen_out[(size_t)b * P.n_steps + gs - 1] = bidx; __threadfence(); }
      }
      __syncthreads();
      tok = stok[0];
    }
    if (embed) {
      const uint2* e = (const uint2*)(P.embed + (size_t)tok * H);
      for (int i = tid; i < H / 4; i += NTHREAD) {      // 4 elements per (virtual) thread i; 4 consecutive i = one 16-row tile
        uint2 v = e[i];
        float4 f = make_float4(bf2f(v.x & 0xffffu), bf2f(v.x >> 16), bf2f(v.y & 0xffffu), bf2f(v.y >> 16));
        ((float4*)(P.xres + (size_t)b * H))[i] = f;
        float4 wv = ((const float4*)P.norm_w)[i];
        const int k = i * 4;
        P.xfrag[gfrag_index(k + 0, b, KS_H, P.B)] = f2bf(wv.x * f.x);
        P.xfrag[gfrag_index(k + 1, b, KS_H, P.B)] = f2bf(wv.y * f.y);
        P.xfrag[gfrag_index(k + 2, b, KS_H, P.B)] = f2bf(wv.z * f.z);
        P.xfrag[gfrag_index(k + 3, b, KS_H, P.B)] = f2bf(wv.w * f.w);
        float p = (f.x * f.x + f.y * f.y) + (f.z * f.z + f.w * f.w);
        p += __shfl_xor_sync(0xffffffffu, p, 1);
        p += __shfl_xor_sync(0xffffffffu, p, 2);
        if ((i & 3) == 0) P.ssq[b * 256 + (i >> 2)] = p;
      }
      __threadfence();
    }
  }
  __syncthreads();
}

// ---------------------------------------------------------------------------------------------------------
// One generic phase = (input copy, matvec, epilogue), parameterized at run time, so that the kernel contains ONE
// copy of the hot code for all five matvec phases (code that is not re-executed for a while has to be
// fetched again: the SM's instruction cache is small).
// ---------------------------------------------------------------------------------------------------------
enum { EP_QKV = 0, EP_ADD = 1, EP_GU = 2, EP_LM = 3, EP_LMARG = 4 };
// phase ids (0..4 are also the trace slots)
enum { PH_QKV = 0, PH_ATT = 1, PH_O = 2, PH_GU = 3, PH_DN = 4, PH_LM = 5, PH_LMARG = 6, PH_EMBED = 7, PH_DONE = 8 };

// The current phase as a descriptor in shared memory ("instruction"): the coordinator thread of the block writes
// it before the grid barrier that precedes the phase; every thread then reads the few fields it needs. Deriving
// these values in every thread costs ~100 instructions x 1024 threads per phase, which is real time at 181
// phases per step.
struct Desc {
  const uint4* W;               // weights of the matrix
  const unsigned short* frag;   // input fragments (global memory)
  const float* aux;             // ADD epilogue: weights of the next RMSNorm
  int t0, t1;                   // this block's tiles
  int ks, ep;                   // ksteps of the matrix (256 / 768); epilogue type
  int norm;                     // input is a norm: outputs are scaled by 1/rms
  int k, l;                     // phase id, layer
  const uint4* nextW;           // first tile of this block in the NEXT matvec phase (warp 0, lane 0); prefetch target
  int nextks;                   // ksteps of that matrix (0: nothing to prefetch)
};
#define DESC_OFF (MISC_OFF + 912)
static_assert(sizeof(Desc) <= 80 && DESC_OFF + sizeof(Desc) <= CTL_OFF && sizeof(Params) <= 256 && CTL_OFF + sizeof(Ctl) <= MISC_OFF + MISC_BYTES, "shared-memory layout");
__device__ __forceinline__ void set_desc(unsigned char* smem, int k, int l) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const int* tb = (const int*)(smem + TB_OFF);
  Desc d;
  const uint4* WL = P.W + (size_t)(k >= PH_LM ? NL : l) * LAYER_U4;
  int tsel = T_QKV;
  d.W = WL; d.frag = P.xfrag; d.aux = nullptr; d.ks = KS_H; d.ep = EP_QKV; d.norm = 1; d.k = k; d.l = l;
  if (k == PH_O) { d.W = WL + OFF_O; d.frag = P.afrag; d.aux = P.norm_w + (size_t)(2 * l + 1) * H; tsel = T_O; d.ep = EP_ADD; d.norm = 0; }
  else if (k == PH_GU) { d.W = WL + OFF_GU; tsel = T_GU; d.ep = EP_GU; }
  else if (k == PH_DN) { d.W = WL + OFF_DN; d.frag = P.mfrag; d.aux = P.norm_w + (size_t)(2 * l + 2) * H; tsel = T_DN; d.ks = KS_I; d.ep = EP_ADD; d.norm = 0; }
  else if (k == PH_LM) { tsel = T_LM; d.ep = EP_LM; }
  else if (k == PH_LMARG) { tsel = T_LM; d.ep = EP_LMARG; }
  d.t0 = tb[2 * tsel]; d.t1 = tb[2 * tsel + 1];
  // the phase after this one (for the prefetch at the end of this phase)
  d.nextW = nullptr; d.nextks = 0;
  if (k == PH_O) { d.nextW = WL + OFF_GU + (size_t)tb[2 * T_GU] * KS_H * 32; d.nextks = KS_H; }
  else if (k == PH_GU) { d.nextW = WL + OFF_DN + (size_t)tb[2 * T_DN] * KS_I * 32; d.nextks = KS_I; }
  else if (k == PH_DN) {
    if (l + 1 < P.stop_layer) d.nextW = WL + LAYER_U4 + OFF_QKV + (size_t)tb[2 * T_QKV] * KS_H * 32;
    else d.nextW = P.W + (size_t)NL * LAYER_U4 + (size_t)tb[2 * T_LM] * KS_H * 32;
    d.nextks = KS_H;
  } else if (k == PH_LMARG || (k == PH_LM && LM_NEXT)) { d.nextW = P.W + OFF_QKV + (size_t)tb[2 * T_QKV] * KS_H * 32; d.nextks = KS_H; }
  *(Desc*)(smem + DESC_OFF) = d;
}
#ifdef TRACE
#define TR_OF(D) int tr = ((D).l == TRACE_LAYER && (D).k < PH_LM) ? (D).k : -100
#else
#define TR_OF(D)
#endif

__device__ __forceinline__ float4 add4(float4 a, float4 b) { return make_float4(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w); }

// epilogue of one 16-row tile, run by the coordinator warp. Lane (g, t) holds rows g and g+8 of batch columns
// 2t and 2t+1: c.x (row g, n0), c.y (row g, n1), c.z (row g+8, n0), c.w (row g+8, n1).
// r0, r1: 1/rms of the input norm for the two columns (QKV, GU, LM). ADD: w0, w1 = weight of the NEXT RMSNorm for
// the two rows, xin = residual rows; the residual add publishes that norm's input (bf16(w*x) and sum of x^2).
__device__ __forceinline__ void epilogue(const Params& P, int ep, int tile, int lane, float4 c, float r0, float r1, float w0, float w1, float4 xin) {
  const int g = lane >> 2, t = lane & 3, B = P.B;
  const int n0 = 2 * t, n1 = 2 * t + 1;
  const int row = tile * 16 + g;
  if (ep == EP_ADD) {
    float s0 = 0.f, s1 = 0.f;
    if (n0 < B) {
      float* p = P.xres + (size_t)n0 * H + row;
      float a = xin.x + c.x, b = xin.y + c.z;
      p[0] = a; p[8] = b;
      P.xfrag[gfrag_index(row, n0, KS_H, B)] = f2bf(w0 * a);
      P.xfrag[gfrag_index(row + 8, n0, KS_H, B)] = f2bf(w1 * b);
      s0 = a * a + b * b;
    }
    if (n1 < B) {
      float* p = P.xres + (size_t)n1 * H + row;
      float a = xin.z + c.y, b = xin.w + c.w;
      p[0] = a; p[8] = b;
      P.xfrag[gfrag_index(row, n1, KS_H, B)] = f2bf(w0 * a);
      P.xfrag[gfrag_index(row + 8, n1, KS_H, B)] = f2bf(w1 * b);
      s1 = a * a + b * b;
    }
    // sum of x^2 over the 16 rows of the tile: lanes with the same t hold the 8 row pairs
    s0 += __shfl_xor_sync(0xffffffffu, s0, 4); s1 += __shfl_xor_sync(0xffffffffu, s1, 4);
    s0 += __shfl_xor_sync(0xffffffffu, s0, 8); s1 += __shfl_xor_sync(0xffffffffu, s1, 8);
    s0 += __shfl_xor_sync(0xffffffffu, s0, 16); s1 += __shfl_xor_sync(0xffffffffu, s1, 16);
    if (g == 0) {
      if (n0 < B) P.ssq[n0 * 256 + tile] = s0;
      if (n1 < B) P.ssq[n1 * 256 + tile] = s1;
    }
  } else if (ep == EP_GU) {
    const int j = tile * 8 + g;     // rows 0..7 of the tile are gate[j], rows 8..15 are up[j]
    if (n0 < B) { float gt = c.x * r0; float m = gt / (1.0f + __expf(-gt)) * (c.z * r0); P.mfrag[gfrag_index(j, n0, KS_I, B)] = f2bf(m); }
    if (n1 < B) { float gt = c.y * r1; float m = gt / (1.0f + __expf(-gt)) * (c.w * r1); P.mfrag[gfrag_index(j, n1, KS_I, B)] = f2bf(m); }
  } else {
    // QKV: [B][6144] ; LM: logits [B][VOCAB]
    float* out = ep == EP_QKV ? P.qkv : P.logits;
    const size_t stride = ep == EP_QKV ? QKV_ROWS : VOCAB;
    if (n0 < B) { out[(size_t)n0 * stride + row] = c.x * r0; out[(size_t)n0 * stride + row + 8] = c.z * r0; }
    if (n1 < B) { out[(size_t)n1 * stride + row] = c.y * r1; out[(size_t)n1 * stride + row + 8] = c.w * r1; }
  }
}

// grid-wide barrier: every block adds one to a counter, then waits until all have (132 blocks: 0.54 us when all
// arrive together; a per-block flag variant measured slower). Run by the coordinator thread only; every
// operator ends with its global stores fenced and a block barrier.
__device__ __forceinline__ void grid_barrier(unsigned char* smem, int kind TR_PARAM) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  Ctl& C = *(Ctl*)(smem + CTL_OFF);
  const unsigned idx = C.bi;
  atomicAdd(P.sync, 1u);
  TP(4);
  unsigned target = P.sync_base + (idx + 1u) * NWORK;
  unsigned polls = 0;
  while ((int)(*(volatile unsigned*)P.sync - target) < 0) polls++;
  TP(5);
  if (P.calib) P.wstat[kind * NWORK + blockIdx.x] += polls;   // how long this block waited for the others
  C.bi = idx + 1u;
}

// input copy: sx <- fragments written to global memory by the previous phase ([n][kstep][4 lanes][4 bf16]).
// norm phases: the fragments are bf16(w * x); also compute 1/rms per sequence from the per-tile partial sums
// (fixed order, the same in every block); the matvec epilogue multiplies its outputs by it.
__device__ __forceinline__ void entry_copy(unsigned char* smem) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const Desc& D = *(const Desc*)(smem + DESC_OFF);
  uint4* sx4 = (uint4*)smem;
  const int ks = D.ks, per = ks * 2, tot = per * P.B;
  const uint4* g = (const uint4*)D.frag;
  // Flat index over (sequence, entry) so that the loads are spread over all threads of the block. Every
  // instruction here is executed by up to 1024 threads at each of the 181 phases, so: threads without work leave
  // at once, a single load takes the short path, and several loads of one thread are requested ECB at a time
  // before the first store (a load->store chain makes every load a full round trip of its own).
  const int i0 = threadIdx.x;
  if (P.B < WIDE_MIN_B) {
   if (i0 < tot) {
    if (i0 + NTHREAD >= tot) {
      const int n = ks == KS_H ? (i0 >> 9) : (i0 / (2 * KS_I)), r = i0 - n * per;
      sx4[(r >> 1) * 16 + 2 * n + (r & 1)] = __ldcg(g + i0);
    } else {
      for (int i = i0; i < tot; i += ECB * NTHREAD) {
        uint4 v[ECB];
#pragma unroll
        for (int u = 0; u < ECB; u++) if (i + u * NTHREAD < tot) v[u] = __ldcg(g + i + u * NTHREAD);
#pragma unroll
        for (int u = 0; u < ECB; u++) {
          const int j = i + u * NTHREAD;
          if (j < tot) {
            const int n = ks == KS_H ? (j >> 9) : (j / (2 * KS_I)), r = j - n * per;
            sx4[(r >> 1) * 16 + 2 * n + (r & 1)] = v[u];
          }
        }
      }
    }
   }
  } else {
    const int n16 = ks * 16;                              // the whole fragment area of this input, 16 bytes at a time
    for (int i = i0; i < n16; i += WCB * NTHREAD) {
      uint4 v[WCB];
#pragma unroll
      for (int u = 0; u < WCB; u++) if (i + u * NTHREAD < n16) v[u] = __ldcg(g + i + u * NTHREAD);
#pragma unroll
      for (int u = 0; u < WCB; u++) if (i + u * NTHREAD < n16) sx4[i + u * NTHREAD] = v[u];
    }
  }
  if (D.norm) {
    // warps 16..23 (no copy loads below 5 sequences): one warp per sequence
    const int n = (threadIdx.x >> 5) - NORM_WARP0, lane = threadIdx.x & 31;
    if (n >= 0 && n < P.B) {
      const float4* q = (const float4*)(P.ssq + n * 256) + lane * 2;
      float4 a = __ldcg(q), b = __ldcg(q + 1);
      float v = ((a.x + a.y) + (a.z + a.w)) + ((b.x + b.y) + (b.z + b.w));
      v = warp_sum(v);
      if (lane == 0) ((float*)(smem + RN_OFF))[n] = 1.0f / sqrtf(v * (1.0f / H) + 1e-6f);
    }
  }
  __syncthreads();
}

// Matvec, block team. The block owns tiles [t0, t1). Loader warp w streams ksteps [s0, s0 + BASE (+1 for the first
// EXTRA warps)) of every tile and leaves its partial accumulator in shared memory; one block barrier per tile.
// Loaders and the coordinator run DIFFERENT functions: in one function the registers of the coordinator's
// epilogue push the loaders' weights into local memory, and with 229 KB of shared memory the SM has almost
// no L1 left, so every spill is an L2 round trip queued behind the warp's own weight loads (+900..2000 us/step).
// Weight loads carry the cache operator "last use" (ld.global.lu): a weight line is read exactly once per step,
// and with the default operator the stream evicts what the phases share through L2 (input fragments, residual,
// K/V). Measured, generate us/step B=1 / B=8: default (ca) 5649 / 6184, cg 5618 / 6128, cs 5637 / 6100, lu 5602 / 6047.
#ifndef WLOAD
#define WLOAD(ptr) __ldlu(ptr)
#endif
#ifndef PIPE
#define PIPE 3     // loads of the next tile requested before the block barrier (2 with 32 warps: more spills)
#endif
// end-of-phase prefetch of the next phase's first loads: NPF ksteps per warp
#ifndef NPF
#define NPF 2
#endif
// chunks prefetched per poll while a block waits at the grid barrier after a matvec phase (0: off), and how many
// ksteps deep per loader warp at most
#ifndef WPF
#define WPF 8
#endif
#ifndef WPF_SMALL_B
#define WPF_SMALL_B 2
#endif
#ifndef WPF_DEPTH
#define WPF_DEPTH 4
#endif
#ifndef NPF_ATT
#define NPF_ATT 8   // attention blocks, end of attention: ksteps of their o tile
#endif
#ifndef NPF_ST
#define NPF_ST 4    // stash blocks, during attention: ksteps of their second o tile
#endif
#ifndef NPF_EMB
#define NPF_EMB 4   // embedding phase: ksteps of the first q/k/v tile
#endif
// `prefetch.global.L2` asks L2 for a line without producing a value, so the warp never waits for it (the
// disassembler shows it as a NOP, but it is effective: 1 / 2 / 3 / 4 / 8 ksteps at the end of a phase give
// 5478 / 5449 / 5455 / 5476 / 5612 us against 5520 without; a load into a dead register is removed by the compiler)
#ifndef PREFETCH
#define PREFETCH(ptr) asm volatile("prefetch.global.L2 [%0];" :: "l"(ptr))
#endif
#ifndef LGRP
#define LGRP 8   // weight loads issued back to back before the first MMA of a group
#endif
template <int KS>
__device__ __forceinline__ void tile_loop(unsigned char* smem, const uint4* W, int t, int t1, bool pre) {
  enum { BASE = KS / NLOAD, EXTRA = KS % NLOAD };
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const int s0 = w * BASE + min(w, (int)EXTRA);
  const bool extra = w < EXTRA;
  const uint2* xb = (const uint2*)smem + s0 * 32 + lane;
  float4* redw = (float4*)(smem + SX_BYTES) + w * 32 + lane;
  const uint4* p = W + ((size_t)t * KS + s0) * 32 + lane;
  uint4 nx[PIPE], nxe = make_uint4(0, 0, 0, 0);
  bool have = false;
  if (pre) {
    // first tile from the stash (same layout as a tile: [kstep][lane])
    const uint4* q = (const uint4*)(smem + STASH_OFF) + s0 * 32 + lane;
    float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
    for (int u = 0; u < BASE; u++) { uint4 a = q[u * 32]; uint2 bb = xb[u * 32]; MMA(c, a, bb); }
    if (extra) { uint4 a = q[BASE * 32]; uint2 bb = xb[BASE * 32]; MMA(c, a, bb); }
    redw[(t & 1) * 1024] = make_float4(c[0], c[1], c[2], c[3]);
    t++; p += (size_t)KS * 32;
    if (t < t1) {
#pragma unroll
      for (int u = 0; u < PIPE; u++) nx[u] = WLOAD(p + u * 32);
      if (extra) nxe = WLOAD(p + BASE * 32);
      have = true;
    }
    __syncthreads();
  }
  // Software pipeline across the block barrier: the first PIPE loads and the extra kstep of the NEXT tile are
  // requested before the barrier, so the warp's load queue is not empty while the block synchronizes.
  // Measured (generate us/step B=1 / B=8): none 5600 / 6060; 2 + extra 5525 / 5962. More than 12 registers
  // carried across the barrier (3 or more loads, in any formulation incl. a register ring) make the compiler
  // spill elsewhere in the kernel, which costs more than the deeper pipeline gains (3: 5583 / 6019).
  for (; t < t1; t++, p += (size_t)KS * 32) {
    float c[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
    for (int j = 0; j < BASE; j += LGRP) {
      uint4 a[LGRP];
#pragma unroll
      for (int u = 0; u < LGRP; u++) {
        if (j + u >= BASE) continue;                       // ragged last group (BASE is not always a multiple)
        if (j + u < PIPE && have) a[u] = nx[(j + u) < PIPE ? (j + u) : 0];
        else a[u] = WLOAD(p + (j + u) * 32);
      }
#pragma unroll
      for (int u = 0; u < LGRP; u++) { if (j + u >= BASE) continue; uint2 bb = xb[(j + u) * 32]; MMA(c, a[u], bb); }
    }
    if (extra) { uint4 a = have ? nxe : WLOAD(p + BASE * 32); uint2 bb = xb[BASE * 32]; MMA(c, a, bb); }
    redw[(t & 1) * 1024] = make_float4(c[0], c[1], c[2], c[3]);
    if (t + 1 < t1) {
      const uint4* pn = p + (size_t)KS * 32;
#pragma unroll
      for (int u = 0; u < PIPE; u++) nx[u] = WLOAD(pn + u * 32);
      if (extra) nxe = WLOAD(pn + BASE * 32);
      have = true;
    }
    __syncthreads();
  }
}

// a loader warp's phase: input copy, tile loop, then wait for the coordinator (last epilogue + grid barrier)
__device__ __forceinline__ void loader_phase(unsigned char* smem) {
  entry_copy(smem);
  const Desc& D = *(const Desc*)(smem + DESC_OFF);
  // PH_O: blocks that did not run attention preloaded their first tile into shared memory (the stash)
  const bool pre = D.k == PH_O && blockIdx.x >= 8 * ((const Params*)(smem + MISC_OFF))->B;
  if (D.ks == KS_H) tile_loop<KS_H>(smem, D.W, D.t0, D.t1, pre);
  else tile_loop<KS_I>(smem, D.W, D.t0, D.t1, pre);
  // HBM would idle from here until the next phase has copied its input: ask L2 for the first NPF ksteps of this
  // warp in the next phase now. The request does not block the warp (nothing waits for a result). (Issuing it
  // before the last tile's barrier instead: +36 us.)
  if (D.nextks) {
    const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
    const int base = D.nextks / NLOAD;                   // ksteps per warp (8 or 24 with 31 loaders)
    const uint4* p = D.nextW + (w * base + min(w, base)) * 32 + lane;
#pragma unroll
    for (int u = 0; u < NPF; u++) PREFETCH(p + u * 32);
  }
  __syncthreads();
}

// The coordinator warp's phase: input copy; per tile: request the epilogue inputs (they arrive while the
// loaders stream), meet the loaders at the block barrier, sum the 31 partials in a fixed order (tree), run the
// epilogue; then advance the control state, write the next phase's descriptor and run the grid barrier.
__device__ __forceinline__ void coord_phase(unsigned char* smem) {
  entry_copy(smem);
  Params& P = *(Params*)(smem + MISC_OFF);
  const Desc D = *(const Desc*)(smem + DESC_OFF);
  TR_OF(D);
  TP(0);
  const int lane = threadIdx.x & 31;
  const int ep = D.ep;
  const float4* red = (const float4*)(smem + SX_BYTES) + lane;
  const float* rn = (const float*)(smem + RN_OFF);
  const float r0 = rn[2 * (lane & 3)], r1 = rn[2 * (lane & 3) + 1];
  float bv0 = -__int_as_float(0x7f800000), bv1 = bv0;   // EP_LMARG: running argmax of this lane's rows
  int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
  for (int t = D.t0; t < D.t1; t++) {
    float w0 = 0.f, w1 = 0.f;
    float4 xin = make_float4(0.f, 0.f, 0.f, 0.f);
    if (ep == EP_ADD) {
      const int row = t * 16 + (lane >> 2), n0 = 2 * (lane & 3), n1 = n0 + 1;
      w0 = (*(D.aux + row)); w1 = (*(D.aux + row + 8));
      if (n0 < P.B) { const float* q = P.xres + (size_t)n0 * H + row; xin.x = __ldcg(q); xin.y = __ldcg(q + 8); }
      if (n1 < P.B) { const float* q = P.xres + (size_t)n1 * H + row; xin.z = __ldcg(q); xin.w = __ldcg(q + 8); }
    }
    __syncthreads();
    if (t == D.t0) TP(1);
    if (t == D.t1 - 1) TP(2);
    const float4* r = red + (t & 1) * 1024;
#define R_(i) r[(i) * 32]
#define S8_(o) add4(add4(add4(R_(o), R_(o + 1)), add4(R_(o + 2), R_(o + 3))), add4(add4(R_(o + 4), R_(o + 5)), add4(R_(o + 6), R_(o + 7))))
#if NLOAD == 31
    float4 q0 = S8_(0), q1 = S8_(8), q2 = S8_(16);
    float4 q3 = add4(add4(add4(R_(24), R_(25)), add4(R_(26), R_(27))), add4(add4(R_(28), R_(29)), R_(30)));
    float4 c = add4(add4(q0, q1), add4(q2, q3));
#elif NLOAD == 15
    float4 q0 = S8_(0);
    float4 q1 = add4(add4(add4(R_(8), R_(9)), add4(R_(10), R_(11))), add4(add4(R_(12), R_(13)), R_(14)));
    float4 c = add4(q0, q1);
#elif NLOAD == 23
    float4 q0 = S8_(0), q1 = S8_(8);
    float4 q2 = add4(add4(add4(R_(16), R_(17)), add4(R_(18), R_(19))), add4(add4(R_(20), R_(21)), R_(22)));
    float4 c = add4(add4(q0, q1), q2);
#else
#error "reduction tree for this NLOAD"
#endif
#undef S8_
#undef R_
    if (ep == EP_LMARG) {
      // same values as the logits of step(): c * r; rows ascend, so strict > keeps the lowest row among equals
      const int row = t * 16 + (lane >> 2);
      float v;
      v = c.x * r0; if (v > bv0) { bv0 = v; bi0 = row; }
      v = c.z * r0; if (v > bv0) { bv0 = v; bi0 = row + 8; }
      v = c.y * r1; if (v > bv1) { bv1 = v; bi1 = row; }
      v = c.w * r1; if (v > bv1) { bv1 = v; bi1 = row + 8; }
      if (t == D.t1 - 1) {
#pragma unroll
        for (int o = 16; o >= 4; o >>= 1) {
          float u = __shfl_xor_sync(0xffffffffu, bv0, o); int ix = __shfl_xor_sync(0xffffffffu, bi0, o);
          if (u > bv0 || (u == bv0 && ix < bi0)) { bv0 = u; bi0 = ix; }
          u = __shfl_xor_sync(0xffffffffu, bv1, o); ix = __shfl_xor_sync(0xffffffffu, bi1, o);
          if (u > bv1 || (u == bv1 && ix < bi1)) { bv1 = u; bi1 = ix; }
        }
        if (lane < 4) {
          const int n0 = 2 * lane, n1 = 2 * lane + 1, nb = NWORK, b = blockIdx.x;
          if (n0 < P.B) { P.bm_val[n0 * nb + b] = bv0; P.bm_idx[n0 * nb + b] = bi0; }
          if (n1 < P.B) { P.bm_val[n1 * nb + b] = bv1; P.bm_idx[n1 * nb + b] = bi1; }
        }
      }
    } else {
      epilogue(P, ep, t, lane, c, r0, r1, w0, w1, xin);
    }
    if (t == D.t1 - 1) { __threadfence(); TP(3); }
  }
  // control: next phase (the loaders are waiting at the block barrier below)
  if (lane == 0) {
    Ctl& C = *(Ctl*)(smem + CTL_OFF);
    const int k = D.k, l = D.l;
    if (k == PH_QKV) set_desc(smem, PH_O, l);
    else if (k == PH_O) set_desc(smem, PH_GU, l);
    else if (k == PH_GU) set_desc(smem, PH_DN, l);
    else if (k == PH_DN) { const bool more = l + 1 < P.stop_layer; set_desc(smem, more ? PH_QKV : C.lm, more ? l + 1 : 0); }
    else if (k == PH_LMARG) { C.s = C.s + 1; P.pos = P.pos + 1; ((Desc*)(smem + DESC_OFF))->k = PH_EMBED; }   // generate(): next step
    else ((Desc*)(smem + DESC_OFF))->k = PH_DONE;                                                           // step(): logits are out
  }
  // Grid barrier run by the whole coordinator warp: while this block waits for the others, every poll also
  // prefetches WPF more 512-byte chunks of the block's first tile of the next phase, one kstep deeper for all
  // 31 loader warps in turn (the loaders prefetched ksteps 0 and 1). A block that waits longer prefetches more;
  // the block everybody waits for prefetches nothing.
  if (D.k != PH_LM) {
    Ctl& C = *(Ctl*)(smem + CTL_OFF);
    const unsigned idx = C.bi;
    if (lane == 0) atomicAdd(P.sync, 1u);
    const unsigned target = P.sync_base + (idx + 1u) * NWORK;
    const int base = D.nextks / NLOAD;
    unsigned polls = 0;
    int j = 0;
    while ((int)(*(volatile unsigned*)P.sync - target) < 0) {
      polls++;
      if (D.nextks && j < NLOAD * WPF_DEPTH) {
#pragma unroll
        for (int q = 0; q < WPF; q++, j++) {
          const int d = j / NLOAD, w = j - d * NLOAD;
          PREFETCH(D.nextW + (w * base + min(w, base) + NPF + d) * 32 + lane);
        }
        if (P.B <= WPF_SMALL_B) {   // few sequences: the barrier chain is short, twice the intensity pays (measured)
#pragma unroll
          for (int q = 0; q < WPF; q++, j++) {
            const int d = j / NLOAD, w = j - d * NLOAD;
            PREFETCH(D.nextW + (w * base + min(w, base) + NPF + d) * 32 + lane);
          }
        }
      }
    }
    if (lane == 0) {
      if (P.calib) P.wstat[D.k * NWORK + blockIdx.x] += polls;
      C.bi = idx + 1u;
    }
  }
  __syncthreads();
}

// ---------------------------------------------------------------------------------------------------------
// attention: block b < 8B handles (sequence n = b/8, kv head g = b%8): q/k norms, RoPE, append K/V,
// scores (MMA over the K cache), softmax, weighted V sum (MMA over the V cache)
// ---------------------------------------------------------------------------------------------------------
__device__ __forceinline__ void attention_body(unsigned char* smem, int layer TR_PARAM) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const int b = blockIdx.x, B = P.B;
  const int n = b >> 3, g = b & 7;
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const int pos = P.pos, T = pos + 1, nt = (T + 15) >> 4, NTP = nt * 16;
  float* y = (float*)(smem + ATT_OFF_BYTES);                 // [5][128]
  unsigned short* qfrag16 = (unsigned short*)(y + 768);      // [8][32][4]
  const uint2* qfrag = (const uint2*)qfrag16;
  float* sc = (float*)(qfrag16 + 8 * 32 * 4);                // [4][NTP]
  unsigned short* pfrag16 = (unsigned short*)(sc + 4 * NTP); // [nt][32][4]
  const uint2* pfrag = (const uint2*)pfrag16;
  float* scr = (float*)(smem + SCR_OFF);
  float4* red = (float4*)(smem + SX_BYTES);
  uint4* Kc = P.kc + (((size_t)layer * MAXB + n) * 8 + g) * P.kv_stride;
  uint4* Vc = P.vc + (((size_t)layer * MAXB + n) * 8 + g) * P.kv_stride;

  // ---- step 1: q (4 heads), k, v of the new token. One warp per vector (warp = vec: 0..3 q heads, 4 k, 5 v),
  // lane holds elements 4*lane .. 4*lane+3: RMSNorm is a warp reduction and the RoPE partner (d ^ 64) is
  // lane ^ 16, so this stage needs no block barrier and no shared-memory round trip.
  if (w < 6) {
    const int vec = w;
    const int row = vec < 4 ? (4 * g + vec) * 128 : (vec == 4 ? 4096 + g * 128 : 5120 + g * 128);
    const float4 x = __ldcg((const float4*)(P.qkv + (size_t)n * QKV_ROWS + row) + lane);
    float xe[4] = {x.x, x.y, x.z, x.w};
    unsigned short ob[4];
    if (vec < 5) {
      const float4 wn = ((const float4*)(P.qk_norm_w + (layer * 2 + (vec < 4 ? 0 : 1)) * 128))[lane];
      const float4 cs = ((const float4*)(P.rope + (size_t)pos * 128))[lane & 15];
      const float4 sn = ((const float4*)(P.rope + (size_t)pos * 128 + 64))[lane & 15];
      const float ss = warp_sum((x.x * x.x + x.y * x.y) + (x.z * x.z + x.w * x.w));
      const float r = 1.0f / sqrtf(ss * (1.0f / 128) + 1e-6f);
      const float we[4] = {wn.x, wn.y, wn.z, wn.w}, ce[4] = {cs.x, cs.y, cs.z, cs.w}, se[4] = {sn.x, sn.y, sn.z, sn.w};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const float yv = we[i] * (xe[i] * r);
        const float other = __shfl_xor_sync(0xffffffffu, yv, 16);
        ob[i] = f2bf(lane < 16 ? yv * ce[i] - other * se[i] : yv * ce[i] + other * se[i]);
      }
    } else {
#pragma unroll
      for (int i = 0; i < 4; i++) ob[i] = f2bf(xe[i]);
    }
#pragma unroll
    for (int i = 0; i < 4; i++) {
      const int d = 4 * lane + i;
      if (vec < 4) {
        qfrag16[(((d >> 4) * 32 + 4 * vec + frag_t(d)) << 2) + frag_slot(d)] = ob[i];
      } else if (vec == 4) {
        const int m = pos & 15, kcol = d & 15;
        const int ln = (m & 7) * 4 + ((kcol & 7) >> 1), el = (kcol >> 3) * 4 + (m >> 3) * 2 + (kcol & 1);
        ((unsigned short*)Kc)[((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ln) << 3) + el] = ob[i];
      } else {
        const int kcol = pos & 15, m = d & 15;
        const int ln = (m & 7) * 4 + ((kcol & 7) >> 1), el = (kcol >> 3) * 4 + (m >> 3) * 2 + (kcol & 1);
        ((unsigned short*)Vc)[((((size_t)(pos >> 4) * 8 + (d >> 4)) * 32 + ln) << 3) + el] = ob[i];
      }
    }
    __threadfence();
  }
  __syncthreads();
  TP(1);

  // ---- step 2: scores[h][j] = q_h . K_j / sqrt(128)
  for (int tile = w; tile < nt; tile += NWARP) {
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    const uint4* p = Kc + (size_t)tile * 256 + lane;
#pragma unroll
    for (int s = 0; s < 8; s++) {
      uint4 a = __ldcg(p + s * 32);
      uint2 bq = make_uint2(0, 0);
      if (lane < 16) bq = qfrag[s * 32 + lane];
      MMA(c, a, bq);
    }
    int t = lane & 3, j = tile * 16 + (lane >> 2);
    if (t < 2) {
      const float scale = 0.08838834764831845f;
      const float ninf = -__int_as_float(0x7f800000);
      sc[(2 * t) * NTP + j] = j < T ? c[0] * scale : ninf;
      sc[(2 * t + 1) * NTP + j] = j < T ? c[1] * scale : ninf;
      sc[(2 * t) * NTP + j + 8] = j + 8 < T ? c[2] * scale : ninf;
      sc[(2 * t + 1) * NTP + j + 8] = j + 8 < T ? c[3] * scale : ninf;
    }
  }
  __syncthreads();
  TP(2);

  // ---- step 3: softmax per head; warp w: head w&3, slice w>>2 of 8
  {
    enum { NSL = NWARP / 4 };          // slices of the position range per head
    const int h = w & 3, r = w >> 2;
    const float* s = sc + h * NTP;
    float mx = -__int_as_float(0x7f800000);
    for (int j = r + NSL * lane; j < NTP; j += NSL * 32) mx = fmaxf(mx, s[j]);
    mx = warp_max(mx);
    if (lane == 0) scr[w] = mx;
    __syncthreads();
    mx = scr[h];
    for (int i = 1; i < NSL; i++) mx = fmaxf(mx, scr[h + 4 * i]);
    float sum = 0.f;
    for (int j = r + NSL * lane; j < NTP; j += NSL * 32) { float e = __expf(s[j] - mx); sc[h * NTP + j] = e; sum += e; }
    sum = warp_sum(sum);
    if (lane == 0) scr[32 + w] = sum;
    __syncthreads();
    float Z = scr[32 + h];
    for (int i = 1; i < NSL; i++) Z += scr[32 + h + 4 * i];
    for (int j = r + NSL * lane; j < NTP; j += NSL * 32) {
      float p = s[j] / Z;
      pfrag16[(((j >> 4) * 32 + 4 * h + frag_t(j)) << 2) + frag_slot(j)] = f2bf(p);
    }
    __syncthreads();
    TP(6);
  }

  // ---- step 4: out[h][d] = sum_j p[h][j] V[j][d]; warp w: dim tile w&7, kstep segment w>>3 of 4
  {
    enum { NSEG = NWARP / 8 };         // kstep segments per dim tile
    const int dt = w & 7, r = w >> 3;
    const int s0 = r * nt / NSEG, s1 = (r + 1) * nt / NSEG;
    float c[4] = {0.f, 0.f, 0.f, 0.f};
    for (int s = s0; s < s1; s++) {
      uint4 a = __ldcg(Vc + ((size_t)s * 8 + dt) * 32 + lane);
      uint2 bp = make_uint2(0, 0);
      if (lane < 16) bp = pfrag[s * 32 + lane];
      MMA(c, a, bp);
    }
    red[w * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
    __syncthreads();
    if (w < 8) {
      float4 v = red[w * 32 + lane];
      for (int i = 1; i < NSEG; i++) { float4 u = red[(w + 8 * i) * 32 + lane]; v.x += u.x; v.y += u.y; v.z += u.z; v.w += u.w; }
      int t = lane & 3, m = lane >> 2;
      if (t < 2) {
        int base0 = (4 * g + 2 * t) * 128 + dt * 16 + m, base1 = (4 * g + 2 * t + 1) * 128 + dt * 16 + m;
        P.afrag[gfrag_index(base0, n, KS_H, P.B)] = f2bf(v.x);
        P.afrag[gfrag_index(base1, n, KS_H, P.B)] = f2bf(v.y);
        P.afrag[gfrag_index(base0 + 8, n, KS_H, P.B)] = f2bf(v.z);
        P.afrag[gfrag_index(base1 + 8, n, KS_H, P.B)] = f2bf(v.w);
      }
      __threadfence();
    }
    __syncthreads();
  }
}


__device__ __forceinline__ void kernel_init(unsigned char* smem, const Params& Pk, int lm) {
  uint4* sx4 = (uint4*)smem;
  for (int i = threadIdx.x; i < SX_BYTES / 16; i += NTHREAD) sx4[i] = make_uint4(0, 0, 0, 0);
  const unsigned* src = (const unsigned*)&Pk;
  if (threadIdx.x < sizeof(Params) / 4) ((unsigned*)(smem + MISC_OFF))[threadIdx.x] = src[threadIdx.x];
  if (threadIdx.x < 8) ((int*)(smem + TB_OFF))[threadIdx.x] = Pk.tiles[blockIdx.x * 8 + threadIdx.x];
  if (threadIdx.x < 4) ((int*)(smem + CTL_OFF))[threadIdx.x] = 0;
  if (threadIdx.x < 2) ((int*)(smem + TBO_OFF))[threadIdx.x] = Pk.tiles_o[((Pk.B - 1) * Pk.nwork + blockIdx.x) * 2 + threadIdx.x];
  __syncthreads();
  if (threadIdx.x == 0) { ((Ctl*)(smem + CTL_OFF))->lm = lm; ((Desc*)(smem + DESC_OFF))->k = PH_EMBED; }
  __syncthreads();
}

// block barrier + (coordinator thread) grid barrier, for the phases that are not matvecs
__device__ __forceinline__ void barrier(unsigned char* smem TR_PARAM) {
  if (threadIdx.x == CW * 32) grid_barrier(smem, PH_ATT TR_ARG(tr));
  __syncthreads();
}

// Attention phase. While the 8B attention blocks work, every other SM would idle, so its loader warps stream
// their share of the block's first o tile into shared memory (the 131 KB behind the K=4096 input fragments,
// free outside the down projection); those bytes cross HBM during attention and the o matvec takes its first
// tile from there. Attention blocks own a single o tile (tile table), the others share the rest.
__device__ __forceinline__ void att_phase(unsigned char* smem) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const Desc& D = *(const Desc*)(smem + DESC_OFF);   // the o projection of this layer
#ifdef TRACE
  int tr = (D.l == TRACE_LAYER) ? PH_ATT : -100;
#endif
  TP(0);
  if (blockIdx.x < 8 * P.B) {
    attention_body(smem, D.l TR_ARG(tr));
#if NPF_ATT > 0
    {   // this block's o tile is cold: ask L2 for its first ksteps now
      const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
      enum { BASE = KS_H / NLOAD, EXTRA = KS_H % NLOAD };
      if (w < NLOAD) {
        const uint4* p = D.W + ((size_t)D.t0 * KS_H + w * BASE + min(w, (int)EXTRA)) * 32 + lane;
#pragma unroll
        for (int u = 0; u < NPF_ATT; u++) PREFETCH(p + u * 32);
      }
    }
#endif
  } else {
    const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
    enum { BASE = KS_H / NLOAD, EXTRA = KS_H % NLOAD };
    if (w < NLOAD) {
      // First pull this layer's K/V history into L2 for the attention blocks: their loads would otherwise
      // be HBM misses queued behind the weight flood below. 512-byte chunks, spread over all idle loader warps.
      {
        const int nt = (P.pos + 16) >> 4, per_unit = 16 * nt, total = 8 * P.B * per_unit;
        const int nidle = (NWORK - 8 * P.B) * NLOAD;
        unsigned acc = 0;
        for (int c = (blockIdx.x - 8 * P.B) * NLOAD + w; c < total; c += nidle) {
          const int u = c / per_unit, i = c - u * per_unit;
          const uint4* base = (i < 8 * nt ? P.kc : P.vc) + ((size_t)D.l * MAXB * 8 + u) * P.kv_stride;
          acc ^= __ldcg(base + (size_t)(i < 8 * nt ? i : i - 8 * nt) * 32 + lane).x;
        }
        if (acc == 0x9e3779b9u) ((unsigned*)(smem + SCR_OFF))[lane] = acc;   // keeps the loads alive
      }
      const int s0 = w * BASE + min(w, (int)EXTRA);
      const uint4* p = D.W + ((size_t)D.t0 * KS_H + s0) * 32 + lane;
      uint4* st = (uint4*)(smem + STASH_OFF) + s0 * 32 + lane;
#pragma unroll
      for (int j = 0; j < BASE; j += 8) {
        uint4 a[8];
#pragma unroll
        for (int u = 0; u < 8; u++) if (j + u < BASE) a[u] = (*(p + (j + u) * 32));
#pragma unroll
        for (int u = 0; u < 8; u++) if (j + u < BASE) st[(j + u) * 32] = a[u];
      }
      if (w < EXTRA) st[BASE * 32] = (*(p + BASE * 32));
#if NPF_ST > 0
      if (D.t0 + 1 < D.t1) {   // and the start of this block's second o tile into L2
#pragma unroll
        for (int u = 0; u < NPF_ST; u++) PREFETCH(p + (size_t)KS_H * 32 + u * 32);
      }
#endif
    }
  }
  TP(3);
  barrier(smem TR_ARG(tr));
}

// embedding of the step's input token; generate(): token = argmax of the previous step (see op_embed), and
// after the last step only the argmax
__device__ __forceinline__ void embed_phase(unsigned char* smem) {
  const Params& P = *(const Params*)(smem + MISC_OFF);
  const Ctl& C = *(const Ctl*)(smem + CTL_OFF);
#ifdef TRACE
  int tr = -100;
#endif
  const bool gen = C.lm == PH_LMARG;
  const int gs = gen ? C.s : -1;
  const bool embed = gen ? (gs < P.n_steps) : true;
  op_embed(smem, gs, embed);
#if NPF_EMB > 0
  if (embed && (threadIdx.x >> 5) < NLOAD) {
    const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
    enum { BASE = KS_H / NLOAD, EXTRA = KS_H % NLOAD };
    const uint4* p = P.W + OFF_QKV + ((size_t)((const int*)(smem + TB_OFF))[2 * T_QKV] * KS_H + w * BASE + min(w, (int)EXTRA)) * 32 + lane;
#pragma unroll
    for (int u = 0; u < NPF_EMB; u++) PREFETCH(p + u * 32);
  }
#endif
  if (threadIdx.x == CW * 32) {
    if (embed) { set_desc(smem, PH_QKV, 0); grid_barrier(smem, PH_EMBED TR_ARG(tr)); }
    else ((Desc*)(smem + DESC_OFF))->k = PH_DONE;
  }
  __syncthreads();
}

// ---------------------------------------------------------------------------------------------------------
// The kernel: an interpreter of phase descriptors. step(): one decode step, logits out (lm = PH_LM).
// generate(): n_steps greedy steps; argmax, token feedback and the loop are on the device (lm = PH_LMARG).
// The loop keeps nothing in registers from one phase to the next and makes no calls: a value kept across a
// call (and the return address of a register-hungry callee) is spilled to local memory by all 1024 threads.
// ---------------------------------------------------------------------------------------------------------
__device__ __forceinline__ void run(unsigned char* smem, const Params& Pk, int lm) {
  kernel_init(smem, Pk, lm);
  for (;;) {
    const int k = ((const volatile Desc*)(smem + DESC_OFF))->k;
    if (k == PH_DONE) break;
    if (k == PH_EMBED) { embed_phase(smem); continue; }
    if (k == PH_O) att_phase(smem);
    if ((threadIdx.x >> 5) < NLOAD) loader_phase(smem); else coord_phase(smem);
  }
}

__global__ void k_step(Params Pk) {
  extern __shared__ __align__(16) unsigned char smem[];
#ifdef TRACE
  if (blockIdx.x == Pk.nwork) {   // the clock
    if (threadIdx.x == 0) {
      const unsigned stop = Pk.sync_base + (unsigned)(BARRIERS_PER_STEP + 1) * Pk.nwork;
      unsigned c = 0;
      for (;;) {
        c++;
        *(volatile unsigned*)Pk.clk = c;
        if ((c & 255u) == 0 && (int)(*(volatile unsigned*)Pk.sync - stop) >= 0) break;
      }
    }
    return;
  }
#endif
  run(smem, Pk, PH_LM);
#ifdef TRACE
  if (threadIdx.x == 0) atomicAdd(((const Params*)(smem + MISC_OFF))->sync, 1u);   // lets the clock block stop
#endif
}

__global__ void k_generate(Params Pk) {
  extern __shared__ __align__(16) unsigned char smem[];
  run(smem, Pk, PH_LMARG);
}

// ---------------------------------------------------------------------------------------------------------
// host API
// ---------------------------------------------------------------------------------------------------------
struct Engine {
  Params P;
  int nsm, max_batch, max_ctx;
  long long launches, steps, errors;
};

#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "CUDA error %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); abort(); } } while (0)

extern "C" {

void* mk_create(int max_batch, int max_ctx, const void* W, const void* embed, const void* norm_w, const void* qk_norm_w, const void* rope) {
  if (max_batch > MAXB || max_ctx > MAX_CTX_SMEM) { fprintf(stderr, "mk_create: unsupported max_batch %d / max_ctx %d\n", max_batch, max_ctx); return nullptr; }
  Engine* E = new Engine();
  memset(E, 0, sizeof(Engine));
  int dev = 0; CK(cudaGetDevice(&dev));
  cudaDeviceProp prop; CK(cudaGetDeviceProperties(&prop, dev));
  E->nsm = prop.multiProcessorCount;
  E->max_batch = max_batch; E->max_ctx = max_ctx;
  Params& P = E->P;
  P.W = (const uint4*)W; P.embed = (const unsigned short*)embed; P.norm_w = (const float*)norm_w;
  P.qk_norm_w = (const float*)qk_norm_w; P.rope = (const float*)rope;
  size_t ctx_tiles = (max_ctx + 15) / 16;
  P.kv_stride = ctx_tiles * 256;
  size_t kv_bytes = (size_t)NL * MAXB * 8 * P.kv_stride * 16;
  CK(cudaMalloc(&P.xres, sizeof(float) * MAXB * H));
  CK(cudaMalloc(&P.qkv, sizeof(float) * MAXB * QKV_ROWS));
  CK(cudaMalloc(&P.afrag, 2 * MAXB * H));
  CK(cudaMalloc(&P.mfrag, 2 * MAXB * INNER));
  CK(cudaMalloc(&P.xfrag, 2 * MAXB * H));
  CK(cudaMalloc(&P.ssq, sizeof(float) * MAXB * 256));
  CK(cudaMemset(P.xfrag, 0, 2 * MAXB * H));
  CK(cudaMemset(P.ssq, 0, sizeof(float) * MAXB * 256));
  CK(cudaMalloc(&P.kc, kv_bytes));
  CK(cudaMalloc(&P.vc, kv_bytes));
  CK(cudaMalloc(&P.sync, 64));
  CK(cudaMalloc(&P.wstat, 4 * 9 * 256)); CK(cudaMemset(P.wstat, 0, 4 * 9 * 256));
  CK(cudaMalloc(&P.bm_val, sizeof(float) * MAXB * E->nsm));
  CK(cudaMalloc(&P.bm_idx, sizeof(int) * MAXB * E->nsm));
  {
#ifdef TRACE
    int nb = E->nsm - 1;
#else
    int nb = E->nsm;
#endif
    P.nwork = nb;
    P.stop_layer = NL;
    CK(cudaMalloc(&P.clk, 64)); CK(cudaMemset(P.clk, 0, 64));
    CK(cudaMalloc(&P.trace, sizeof(unsigned) * 64 * 256)); CK(cudaMemset(P.trace, 0, sizeof(unsigned) * 64 * 256));
    int* tb = new int[nb * 8];
    const int nt[4] = {QKV_T, O_T, GU_T, LM_T};
    for (int b = 0; b < nb; b++) for (int k = 0; k < 4; k++) {
      tb[b * 8 + 2 * k] = (int)((long long)b * nt[k] / nb); tb[b * 8 + 2 * k + 1] = (int)((long long)(b + 1) * nt[k] / nb);
      if (tb[b * 8 + 2 * k + 1] <= tb[b * 8 + 2 * k]) { fprintf(stderr, "mk_create: block without tiles\n"); abort(); }
    }
    int* d; CK(cudaMalloc(&d, sizeof(int) * nb * 8)); CK(cudaMemcpy(d, tb, sizeof(int) * nb * 8, cudaMemcpyHostToDevice));
    P.tiles = d; delete[] tb;
    // o projection: blocks 0..8B-1 are busy with attention while the others stream their first o tile into shared
    // memory, so the attention blocks own one o tile each and the other blocks share the rest evenly
    int* to = new int[MAXB * nb * 2];
    for (int B = 1; B <= MAXB; B++) {
      int A = 8 * B < nb ? 8 * B : nb, N = nb - A;
      int cnt[1024];
      int rest = O_T - A;
      for (int b = 0; b < A; b++) cnt[b] = 1;
      for (int b = A; b < nb; b++) cnt[b] = (int)((long long)(b - A + 1) * rest / N) - (int)((long long)(b - A) * rest / N);
      int t = 0;
      for (int b = 0; b < nb; b++) {
        if (cnt[b] < 1) { fprintf(stderr, "mk_create: block without o tiles\n"); abort(); }
        to[((B - 1) * nb + b) * 2] = t; t += cnt[b]; to[((B - 1) * nb + b) * 2 + 1] = t;
      }
      if (t != O_T) { fprintf(stderr, "mk_create: o tile table broken\n"); abort(); }
    }
    CK(cudaMalloc(&d, sizeof(int) * MAXB * nb * 2)); CK(cudaMemcpy(d, to, sizeof(int) * MAXB * nb * 2, cudaMemcpyHostToDevice));
    P.tiles_o = d; delete[] to;
  }
  CK(cudaMemset(P.xres, 0, sizeof(float) * MAXB * H));
  CK(cudaMemset(P.qkv, 0, sizeof(float) * MAXB * QKV_ROWS));
  CK(cudaMemset(P.afrag, 0, 2 * MAXB * H));
  CK(cudaMemset(P.mfrag, 0, 2 * MAXB * INNER));
  CK(cudaMemset(P.kc, 0, kv_bytes));
  CK(cudaMemset(P.vc, 0, kv_bytes));   // V must stay finite: masked positions are multiplied by p = 0
  CK(cudaMemset(P.sync, 0, 64));
  CK(cudaFuncSetAttribute(k_step, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES));
  CK(cudaFuncSetAttribute(k_generate, cudaFuncAttributeMaxDynamicSharedMemorySize, SMEM_BYTES));
  return E;
}

void mk_step(void* h, const void* tokens, void* logits, int B, int pos, int mode) {
  Engine* E = (Engine*)h;
  Params P = E->P;
  P.tokens = (const long long*)tokens; P.logits = (float*)logits; P.B = B; P.pos = pos;
  k_step<<<E->nsm, NTHREAD, SMEM_BYTES>>>(P);
  E->P.sync_base += (unsigned)(1 + E->P.stop_layer * BARRIERS_PER_LAYER + TRACE_EXTRA) * E->P.nwork;
  E->launches += 1;
  E->steps += 1;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess && E->errors++ < 5) fprintf(stderr, "mk_step: launch error: %s\n", cudaGetErrorString(e));
}

void mk_generate(void* h, const void* tokens, void* out, int B, int pos, int n_steps) {
  Engine* E = (Engine*)h;
  Params P = E->P;
  P.tokens = (const long long*)tokens; P.gen_out = (long long*)out; P.B = B; P.pos = pos; P.n_steps = n_steps;
  k_generate<<<E->nsm, NTHREAD, SMEM_BYTES>>>(P);
  E->P.sync_base += (unsigned)BARRIERS_PER_GEN_STEP * n_steps * E->P.nwork;
  E->launches += 1;
  E->steps += n_steps;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess && E->errors++ < 5) fprintf(stderr, "mk_generate: launch error: %s\n", cudaGetErrorString(e));
}

// TRACE: copy out [blocks][8][8] timestamps and the final clock value
void mk_trace(void* h, unsigned* out, unsigned* clk) {
  Engine* E = (Engine*)h;
  CK(cudaDeviceSynchronize());
  CK(cudaMemcpy(out, E->P.trace, sizeof(unsigned) * 64 * 256, cudaMemcpyDeviceToHost));
  CK(cudaMemcpy(clk, E->P.clk, sizeof(unsigned), cudaMemcpyDeviceToHost));
}

// ---- calibration of the tile tables (engine start, off the per-token path) ----
// record barrier waits (poll iterations per block and phase kind) while on
void mk_calib(void* h, int on) { ((Engine*)h)->P.calib = on; }
// read and clear the wait statistics: out[9][blocks]
void mk_get_wstat(void* h, unsigned* out) {
  Engine* E = (Engine*)h;
  CK(cudaDeviceSynchronize());
  CK(cudaMemcpy(out, E->P.wstat, sizeof(unsigned) * 9 * E->P.nwork, cudaMemcpyDeviceToHost));
  CK(cudaMemset(E->P.wstat, 0, sizeof(unsigned) * 9 * E->P.nwork));
}
// set the number of tiles of every block for one matrix kind (0 qkv, 1 down, 2 gate+up, 3 lm_head); contiguous
// ranges in block order. Any table gives bitwise the same results: a tile's arithmetic does not depend on the block.
int mk_set_tiles(void* h, int kind, const int* counts) {
  Engine* E = (Engine*)h;
  const int nt[4] = {QKV_T, DN_T, GU_T, LM_T};
  const int nb = E->P.nwork;
  int tot = 0;
  for (int b = 0; b < nb; b++) { if (counts[b] < 1) return -1; tot += counts[b]; }
  if (kind < 0 || kind > 3 || tot != nt[kind]) return -2;
  CK(cudaDeviceSynchronize());
  int t = 0;
  for (int b = 0; b < nb; b++) {
    int pair[2] = {t, t + counts[b]};
    CK(cudaMemcpy((void*)(E->P.tiles + b * 8 + 2 * kind), pair, sizeof(pair), cudaMemcpyHostToDevice));
    t += counts[b];
  }
  return 0;
}

// debug: run only the first n layers from now on (NL = normal); read the residual stream [MAXB][H]
void mk_set_stop_layer(void* h, int n) { ((Engine*)h)->P.stop_layer = n; }
void mk_read_x(void* h, float* out) {
  Engine* E = (Engine*)h;
  CK(cudaDeviceSynchronize());
  CK(cudaMemcpy(out, E->P.xres, sizeof(float) * MAXB * H, cudaMemcpyDeviceToHost));
}

long long mk_stat(void* h, int which) {
  Engine* E = (Engine*)h;
  return which == 0 ? E->launches : which == 1 ? E->steps : which == 2 ? E->nsm : which == 3 ? E->errors : 0;
}

int mk_check() { cudaError_t e = cudaGetLastError(); if (e != cudaSuccess) fprintf(stderr, "mk_check: %s\n", cudaGetErrorString(e)); return (int)e; }

void mk_destroy(void* h) {
  Engine* E = (Engine*)h;
  cudaDeviceSynchronize();
  Params& P = E->P;
  cudaFree(P.xres); cudaFree(P.qkv); cudaFree(P.afrag); cudaFree(P.mfrag); cudaFree(P.xfrag); cudaFree(P.ssq); cudaFree(P.kc); cudaFree(P.vc); cudaFree(P.sync); cudaFree(P.wstat); cudaFree(P.bm_val); cudaFree(P.bm_idx); cudaFree((void*)P.tiles); cudaFree((void*)P.tiles_o);
  delete E;
}

}  // extern "C"
