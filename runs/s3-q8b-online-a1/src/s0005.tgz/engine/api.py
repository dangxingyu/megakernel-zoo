"""Qwen3-8B online engine: own CUDA kernels (engine/eng.cu) behind the offline and the online contract.

A *pass* runs T token columns once over the weights: the decode rows of every running request and chunks of the
prompts being prefilled, together. Python here loads the weights, keeps the slot / page tables and composes the
plan of each pass; no torch module and no library computes anything of the model.

    offline:  reset(), step(tokens[B]) -> logits [B, vocab], generate(tokens[B], n) -> tokens [B, n]
    online:   submit(rid, prompt, max_new_tokens), poll() -> [(rid, tokens, finished)], idle(), kv_pages(),
              drop_cache(), stats()
"""

import ctypes
import json
import os
import struct
import subprocess
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sched  # noqa: E402
H, NL, VOCAB, INNER = 4096, 36, 151936, 12288
PAGE_TOK = 512
NSLOT, MAXPG = 64, 68
LASTBIT = 0x10000


def _load_lib():
    so = os.environ.get("MK_SO") or os.path.join(HERE, "libeng.so")
    if not os.path.exists(so):
        subprocess.check_call(["bash", os.path.join(HERE, "build.sh")])
    lib = ctypes.CDLL(so)
    vp, ci = ctypes.c_void_p, ctypes.c_int
    lib.eng_create.restype = vp
    lib.eng_create.argtypes = [ci] + [vp] * 5
    lib.eng_plan_ints.restype = ci
    lib.eng_tcap.restype = ci
    lib.eng_selcap.restype = ci
    lib.eng_page_bytes.restype = ctypes.c_size_t
    lib.eng_set_plan.restype = None
    lib.eng_set_plan.argtypes = [vp, vp, ci, ci]
    lib.eng_pass.restype = None
    lib.eng_pass.argtypes = [vp, ci, ci, ci, ci, ci, ci, vp, vp, vp, ci, ci]
    lib.eng_const.restype = ci
    lib.eng_const.argtypes = [ci]
    lib.eng_fixed_bytes.restype = ctypes.c_size_t
    lib.eng_read_tokens.restype = None
    lib.eng_read_tokens.argtypes = [vp, vp, ci]
    lib.eng_poison_page.restype = None
    lib.eng_poison_page.argtypes = [vp, ci]
    lib.eng_stat.restype = ctypes.c_longlong
    lib.eng_stat.argtypes = [vp, ci]
    lib.eng_sync.restype = None
    lib.eng_destroy.restype = None
    lib.eng_destroy.argtypes = [vp]
    return lib


def pack_matrix(w: torch.Tensor) -> torch.Tensor:
    """[M, K] bf16 -> int16 stream in the kernels' operand layout [k // 64][row // 8][(k % 64) // 8][row % 8][k % 8]:
    a K chunk of 64 for a block of rows is one contiguous byte range, and in shared memory it is the K-major
    operand of the warpgroup MMA as it is (see xidx in eng.cu)."""
    m, k = w.shape
    v = w.contiguous().view(torch.int16).view(m // 8, 8, k // 64, 8, 8)   # [n, i8, c, ko, e]
    return v.permute(2, 0, 3, 1, 4).reshape(-1)


class _Weights:
    """Reads tensors from the safetensors shards straight to the GPU, one at a time."""

    def __init__(self, model_dir):
        self.dir = model_dir
        with open(os.path.join(model_dir, "model.safetensors.index.json")) as f:
            self.map = json.load(f)["weight_map"]
        self.headers = {}

    def get(self, name) -> torch.Tensor:
        fn = os.path.join(self.dir, self.map[name])
        if fn not in self.headers:
            with open(fn, "rb") as f:
                n = struct.unpack("<Q", f.read(8))[0]
                self.headers[fn] = (json.loads(f.read(n)), 8 + n)
        hdr, base = self.headers[fn]
        e = hdr[name]
        assert e["dtype"] == "BF16", (name, e["dtype"])
        b0, b1 = e["data_offsets"]
        arr = np.memmap(fn, dtype=np.int16, mode="r", offset=base + b0, shape=((b1 - b0) // 2,))
        t = torch.from_numpy(np.array(arr)).cuda()
        return t.view(torch.bfloat16).view(e["shape"])


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        self.lib = _load_lib()
        self.max_batch, self.max_context = max_batch, max_context
        wts = _Weights(model_dir)
        layer_i16 = (6144 * 4096 + 4096 * 4096 + 24576 * 4096 + 4096 * 12288)
        total = NL * layer_i16 + VOCAB * H
        self.W = torch.empty(total, dtype=torch.int16, device="cuda")
        self.norm_w = torch.empty((2 * NL + 1, H), dtype=torch.float32, device="cuda")
        self.qk_norm_w = torch.empty((NL, 2, 128), dtype=torch.float32, device="cuda")
        off = 0

        def put(w):
            nonlocal off
            p = pack_matrix(w)
            self.W[off : off + p.numel()] = p
            off += p.numel()

        for l in range(NL):
            pre = f"model.layers.{l}."
            q, k, v = (wts.get(pre + f"self_attn.{n}_proj.weight") for n in "qkv")
            put(torch.cat([q, k, v], dim=0))
            del q, k, v
            put(wts.get(pre + "self_attn.o_proj.weight"))
            g = wts.get(pre + "mlp.gate_proj.weight")
            u = wts.get(pre + "mlp.up_proj.weight")
            # tile i = gate rows 8i..8i+7 then up rows 8i..8i+7: silu(gate)*up is computed inside one thread
            put(torch.cat([g.view(INNER // 8, 8, H), u.view(INNER // 8, 8, H)], dim=1).reshape(2 * INNER, H))
            del g, u
            put(wts.get(pre + "mlp.down_proj.weight"))
            self.norm_w[2 * l] = wts.get(pre + "input_layernorm.weight").float()
            self.norm_w[2 * l + 1] = wts.get(pre + "post_attention_layernorm.weight").float()
            self.qk_norm_w[l, 0] = wts.get(pre + "self_attn.q_norm.weight").float()
            self.qk_norm_w[l, 1] = wts.get(pre + "self_attn.k_norm.weight").float()
        put(wts.get("lm_head.weight"))
        assert off == total
        self.norm_w[2 * NL] = wts.get("model.norm.weight").float()
        self.embed = wts.get("model.embed_tokens.weight").contiguous()
        # RoPE table exactly as the reference computes it (float32 angles)
        inv_freq = 1.0 / (1000000.0 ** (torch.arange(0, 128, 2, dtype=torch.float) / 128))
        ang = torch.arange(max_context, dtype=torch.float)[:, None] * inv_freq[None, :]
        self.rope = torch.cat([ang.cos(), ang.sin()], dim=1).contiguous().cuda()
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        self.n_slots = min(max_batch, NSLOT)
        self.max_pages_per_seq = min(MAXPG, -(-max_context // PAGE_TOK))
        page_bytes = self.lib.eng_page_bytes()
        free, _ = torch.cuda.mem_get_info()
        reserve = int(float(os.environ.get("MK_RESERVE_GB", "1.0")) * 2**30) + self.lib.eng_fixed_bytes()
        self.n_pages = int(min(self.n_slots * self.max_pages_per_seq, (free - reserve) // page_bytes))
        if os.environ.get("MK_PAGES"):
            self.n_pages = min(self.n_pages, int(os.environ["MK_PAGES"]))
        self.h = self.lib.eng_create(self.n_pages, self.W.data_ptr(), self.embed.data_ptr(), self.norm_w.data_ptr(),
                                     self.qk_norm_w.data_ptr(), self.rope.data_ptr())
        if not self.h:
            raise RuntimeError("eng_create failed")
        self.TCAP, self.SELCAP = self.lib.eng_tcap(), self.lib.eng_selcap()
        self.PL_SLOT, self.PL_POS, self.PL_TOK = 0, self.TCAP, 2 * self.TCAP
        (self.PL_UNIT, self.PL_WT, self.PL_BT, self.PL_FOLD, self.PL_SEL, self.PL_PT, self.MAXU, self.MAXWT, self.MAXBT,
         self.PARTCAP, self.PL_CU, self.SS) = (self.lib.eng_const(i) for i in range(12))
        self.plan = np.zeros(self.lib.eng_plan_ints(), dtype=np.int32)
        self.pt = self.plan[self.PL_PT : self.PL_PT + NSLOT * MAXPG].reshape(NSLOT, MAXPG)   # view: page table inside the plan
        self.poison = bool(int(os.environ.get("MK_POISON", "0")))  # tests: NaN in every page that is freed
        if self.poison:
            for p in range(self.n_pages):
                self.lib.eng_poison_page(self.h, p)
        env = os.environ.get
        self.S = sched.Scheduler(self.n_pages, self.n_slots, self.TCAP, self.SELCAP,
                                 policy=env("MK_POLICY", "deadline"), reuse=bool(int(env("MK_REUSE", "1"))),
                                 target_s=float(env("MK_TARGET_MS", "80")) * 1e-3, margin_s=float(env("MK_MARGIN_S", "0.3")),
                                 min_chunk=int(env("MK_MIN_CHUNK", "64")))
        if self.poison:
            self.S.freed_hook = lambda page: self.lib.eng_poison_page(self.h, page)
        self.bt_order = int(env("MK_BT_ORDER", "0"))
        self.short_block_max = int(env("MK_SHORT_BLOCK_MAX", "132"))   # decode-row attention tasks up to which blocks are used
        self.block_min = int(env("MK_BLOCK_MIN", "8"))     # runs of at least this many columns use the block attention kernel
        self.adapt = bool(int(env("MK_ADAPT", "1")))        # correct the cost model by the measured pass times
        self.corr = 1.0
        self.t0 = time.perf_counter()
        # offline state
        self.pos = 0
        self._off_B = 0
        self._off_ss = -1
        self._off_pages = [[] for _ in range(NSLOT)]
        self._keep = None
        self.counters = dict(passes=0, host_syncs=0, columns=0, pass_ms_max=0.0, pass_ms_sum=0.0, est_ms_sum=0.0, compose_ms_sum=0.0)

    # ------------------------------------------------------------------ pages (offline path and tests)
    def _alloc(self, n):
        if len(self.S.free) < n:
            return None
        return [self.S.free.pop() for _ in range(n)]

    def _free(self, pages):
        for p in pages:
            self.S._release(p)

    def _upload(self):
        self.lib.eng_set_plan(self.h, self.plan.ctypes.data, 0, self.plan.size)

    # ------------------------------------------------------------------ offline contract
    def reset(self) -> None:
        self.pos = 0
        for b in range(NSLOT):
            if self._off_pages[b]:
                self._free(self._off_pages[b])
                self._off_pages[b] = []
        self._off_B = 0

    def _off_prepare(self, B, pos0, last_pos):
        """slots 0..B-1 own pages up to position last_pos; the plan is the B columns at position pos_add"""
        need = last_pos // PAGE_TOK + 1
        changed = B != self._off_B
        for b in range(B):
            while len(self._off_pages[b]) < need:
                got = self._alloc(1)
                if got is None:
                    raise RuntimeError("out of KV pages")
                self.pt[b, len(self._off_pages[b])] = got[0]
                self._off_pages[b].append(got[0])
                changed = True
        if changed or (pos0 >> self.SS) != self._off_ss:
            self._off_ss = pos0 >> self.SS
            self._off_counts = self._fill_plan([(b, 0, None, 1) for b in range(B)], pos_add=pos0)
            self._off_B = B
            self._upload()

    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        if tokens.dtype != torch.int64 or not tokens.is_contiguous():
            tokens = tokens.to(torch.int64).contiguous()
        B = tokens.shape[0]
        self._off_prepare(B, self.pos, self.pos)
        logits = torch.empty((B, VOCAB), dtype=torch.float32, device="cuda")
        nb, nw, nf = self._off_counts
        self.lib.eng_pass(self.h, B, nb, nw, nf, B, self.pos, tokens.data_ptr(), logits.data_ptr(), None, 0, 0)
        self.pos += 1
        self._keep = tokens  # the kernels read it asynchronously
        return logits

    def generate(self, tokens: torch.Tensor, n_steps: int) -> torch.Tensor:
        """Greedy decode n_steps tokens: argmax and token feedback are on the device, the host only launches."""
        if tokens.dtype != torch.int64 or not tokens.is_contiguous():
            tokens = tokens.to(torch.int64).contiguous()
        B = tokens.shape[0]
        if self.pos + n_steps > self.max_context:
            raise ValueError("generate() would exceed max_context")
        out = torch.empty((B, n_steps), dtype=torch.int64, device="cuda")
        for i in range(n_steps):
            if i == 0 or ((self.pos + i) & ((1 << self.SS) - 1)) == 0:   # the plan changes when the rows enter a new super-segment
                self._off_prepare(B, self.pos + i, self.pos + n_steps - 1)
                nb, nw, nf = self._off_counts
            self.lib.eng_pass(self.h, B, nb, nw, nf, B, self.pos + i, tokens.data_ptr() if i == 0 else None, None, out.data_ptr(), n_steps, i)
        self.pos += n_steps
        self._keep = tokens
        return out

    # ------------------------------------------------------------------ online contract
    def submit(self, rid: int, prompt, max_new_tokens: int) -> None:
        self.S.submit(rid, prompt, max_new_tokens, time.perf_counter() - self.t0)

    def idle(self) -> bool:
        return self.S.idle()

    def kv_pages(self):
        return (self.S.pages_free(), self.n_pages)

    def drop_cache(self) -> None:
        self.S.drop_cache()

    def _fill_plan(self, runs, pos_add=0):
        """runs: [(slot, pos0, tokens or None (decode: the slot's last token), select)] -> the plan (host copy).
        Returns (block tasks, warp tasks, units to fold); sets self._plan_cols, self._plan_sel."""
        p, SS = self.plan, self.SS
        col, sel, units, wt, bt, fold, nparts, short = 0, [], [], [], [], [], 0, []
        for ri, (slot, pos0, toks, select) in enumerate(runs):
            n = 1 if toks is None else len(toks)
            p[self.PL_SLOT + col : self.PL_SLOT + col + n] = slot | ((np.arange(n, dtype=np.int32) & 3) << 17)
            p[self.PL_SLOT + col + n - 1] |= LASTBIT
            p[self.PL_POS + col : self.PL_POS + col + n] = np.arange(pos0, pos0 + n, dtype=np.int32)
            p[self.PL_TOK + col : self.PL_TOK + col + n] = -1 if toks is None else toks
            p[self.PL_CU + col : self.PL_CU + col + n] = len(units) + (np.arange(n, dtype=np.int32) >> 2)
            # attention units of at most 4 positions; a unit that spans several super-segments (4096 positions)
            # leaves one part per super-segment in the scratch, folded afterwards
            u0 = len(units)
            for c0 in range(0, n, 4):
                nq = min(4, n - c0)
                nss = ((pos0 + pos_add + c0 + nq - 1) >> SS) + 1
                if nss > 1:
                    fold.append(len(units))
                    units.append((col + c0, nq, nparts, 0))
                    nparts += nss
                else:
                    units.append((col + c0, nq, -1, 0))
            nu = len(units) - u0
            if n >= self.block_min:   # groups of 8 units (32 positions) share a block: K/V staged in shared memory
                grp = []
                for g0 in range(0, nu, 8):
                    gn = min(8, nu - g0)
                    last = units[u0 + g0 + gn - 1]
                    grp.append(((u0 + g0) | (gn << 12), ((pos0 + pos_add + last[0] - col + last[1] - 1) >> SS) + 1))
                order = self.bt_order
                for ss in range(grp[-1][1]):
                    live = [e for e, nss in grp if nss > ss]
                    if order == 0:      # by (super-segment, kv head, group): concurrent blocks share K/V in L2
                        bt.extend(e | (ss << 16) | (g << 22) for g in range(8) for e in live)
                    else:               # by (super-segment, group, kv head)
                        bt.extend(e | (ss << 16) | (g << 22) for e in live for g in range(8))
            else:                      # decode rows and short runs: decided below
                for u in range(u0, u0 + nu):
                    for ss in range(((pos0 + pos_add + units[u][0] - col + units[u][1] - 1) >> SS) + 1):
                        short.append(u | (ss << 16))
            if select == 1:
                sel.append((col + n - 1, slot, ri))
            elif select == 2:   # tests: every column of the run
                sel.extend((col + i, slot if i == n - 1 else -1, ri) for i in range(n))
            col += n
        # Decode rows and short runs. A warp that reads K/V itself moves 10 KB/us: a super-segment (2 MB of K and V)
        # takes it ~250 us, whatever else the GPU does. A block that stages K/V with all its warps moves 52 KB/us
        # (~42 us per super-segment) but computes with one warp only. So: blocks while there are few such tasks
        # (the pass waits for the longest task), warps when there are more tasks than blocks can turn over.
        if len(short) * 8 <= self.short_block_max:
            bt[:0] = [u | (1 << 12) | (g << 22) for u in short for g in range(8)]
        else:
            wt = short
        assert col <= self.TCAP and len(sel) <= self.SELCAP, (col, len(sel))
        assert len(units) <= self.MAXU and len(wt) <= self.MAXWT and len(bt) <= self.MAXBT and nparts <= self.PARTCAP, (len(units), len(wt), len(bt), nparts)
        p[self.PL_UNIT : self.PL_UNIT + 4 * len(units)] = np.asarray(units, dtype=np.int32).reshape(-1)
        p[self.PL_WT : self.PL_WT + len(wt)] = wt
        p[self.PL_BT : self.PL_BT + len(bt)] = bt
        p[self.PL_FOLD : self.PL_FOLD + len(fold)] = fold
        if sel:
            p[self.PL_SEL : self.PL_SEL + 2 * len(sel)] = np.asarray([(c, s) for c, s, _ in sel], dtype=np.int32).reshape(-1)
        self._plan_cols, self._plan_sel = col, [ri for _, _, ri in sel]
        return len(bt), len(wt), len(fold)

    def _run_pass(self, runs, want_logits=False):
        """Fill and upload the plan of a pass, launch it. Returns (run index of every selected column, logits)."""
        nb, nw, nf = self._fill_plan(runs)
        col, sel = self._plan_cols, self._plan_sel
        self._upload()
        logits = torch.empty((len(sel), VOCAB), dtype=torch.float32, device="cuda") if want_logits else None
        self.lib.eng_pass(self.h, col, nb, nw, nf, len(sel), 0, None, logits.data_ptr() if want_logits else None, None, 0, 0)
        self.counters["passes"] += 1
        self.counters["columns"] += col
        return sel, logits

    def poll(self):
        S = self.S
        t_a = time.perf_counter()
        if self.adapt:
            S.speed = self.corr
        plan = S.compose(t_a - self.t0)
        if plan is None:
            return []
        runs = []
        for r, slot, pos0, n, toks, select in plan.runs:
            self.pt[slot, :len(r.pages)] = r.pages
            runs.append((slot, pos0, toks, select))
        t_b = time.perf_counter()
        sel, _ = self._run_pass(runs)
        S.launched(plan)
        toks = np.empty(max(1, len(sel)), dtype=np.int32)
        if sel:
            self.lib.eng_read_tokens(self.h, toks.ctypes.data, len(sel))   # the one host sync of a pass
        else:
            self.lib.eng_sync()
        t_c = time.perf_counter()
        c = self.counters
        c["host_syncs"] += 1
        dt = t_c - t_b
        c["pass_ms_max"] = max(c["pass_ms_max"], dt * 1e3)
        c["pass_ms_sum"] += dt * 1e3
        c["est_ms_sum"] += plan.est_s * 1e3
        c["compose_ms_sum"] += (t_b - t_a) * 1e3
        if self.adapt:
            self.corr = min(1.5, max(0.8, 0.95 * self.corr + 0.05 * dt / plan.est_s))
        return S.complete(plan, toks, t_c - self.t0)

    # ------------------------------------------------------------------
    def close(self) -> None:
        if getattr(self, "h", None):
            self.lib.eng_destroy(self.h)
            self.h = None
        self.W = self.embed = self.norm_w = self.qk_norm_w = self.rope = None

    def stats(self) -> dict:
        s = {
            "implementation": "pass engine (eng.cu): decode rows and prefill chunks in one pass over the weights",
            "kernel_launches": int(self.lib.eng_stat(self.h, 0)),
            "passes": int(self.lib.eng_stat(self.h, 1)),
            "plan_uploads": int(self.lib.eng_stat(self.h, 3)),
            "token_reads": int(self.lib.eng_stat(self.h, 4)),
            "kv_pages_total": self.n_pages,
            "kv_pages_free": len(self.S.free),
            "kv_pages_cached": len(self.S.cache),
            "queue": len(self.S.queue),
            "running": len(self.S.running),
            "policy": self.S.policy,
            "prefix_reuse": self.S.reuse,
            "target_pass_ms": self.S.target_s * 1e3,
            "cost_model_correction": round(self.corr, 3),
            "host_syncs_per_pass": 1,
            "max_batch": self.max_batch,
            "max_context": self.max_context,
        }
        s.update(self.S.c)
        s.update(self.counters)
        return s
