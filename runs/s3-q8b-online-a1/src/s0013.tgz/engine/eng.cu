// Online engine for Qwen3-8B (bf16) on one H100: a "pass" runs T token columns (decode rows and prefill chunks
// together) once over the weights. Every column's arithmetic is independent of the other columns of the pass,
// of where a prefill is cut into chunks and of whether its prefix K/V came from a cache.
//
// Canonical arithmetic (what makes batching / chunking / prefix reuse invisible):
//  * matvec: y[row] = one f32 accumulator per (row, column), 16 input dims per tensor-core instruction
//    (wgmma m64nNk16, bf16 x bf16 -> f32), dims ascending. Inputs are bf16.
//  * attention of a query at position t over keys 0..t. Positions are cut (at absolute positions) into
//    segments of 128 and super-segments of 128 << SS_LOG.
//    q is stored as bf16(q * log2 e / sqrt(128)), so a score s_j = q . k_j (MMA over the 8 dim-ksteps, f32)
//    is in units of log2. State of a query inside a super-segment: (M, Z, O), starting at (-inf, 0, 0).
//    Per segment, in ascending order: m = max of s_j over the valid positions, R = max(M, m),
//    a = 2^(M - R) (exactly 1 when M == R, 0 for M = -inf), O *= a, Z *= a, w_j = bf16(2^(s_j - R)) (0 for
//    j > t), O += sum_j w_j V_j and Z += sum_j w_j (tensor-core instructions over 16 positions each,
//    positions ascending, accumulating into O and Z; Z against a V dim group of ones), M = R.
//    The super-segments of a query are folded in ascending order from (-inf, 0, 0): M' = max(M, m),
//    a = 2^(M - M'), b = 2^(m - M') (exactly 1 / 0 as above), Z' = Z a + z b, O' = O a + o b.
//    Output = bf16(O * (1 / Z)).
//    So a (query, super-segment) part can be computed anywhere, in any pass, next to any other work.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstddef>

#define H 4096
#define NL 36
#define QKV_ROWS 6144
#define INNER 12288
#define VOCAB 151936
#define QKV_T 384
#define O_T 256
#define GU_T 1536
#define DN_T 256
#define LM_T 9496
#define KS_H 256
#define KS_I 768
#define OFF_QKV 0ull
#define OFF_O (OFF_QKV + (size_t)QKV_T * KS_H * 32)
#define OFF_GU (OFF_O + (size_t)O_T * KS_H * 32)
#define OFF_DN (OFF_GU + (size_t)GU_T * KS_H * 32)
#define LAYER_U4 (OFF_DN + (size_t)DN_T * KS_I * 32)

#define NSLOT 64
#define MAXPG 68                         // pages per sequence: 34816 / 512
#define PG_TILES 32                      // a page = 512 positions = 32 position tiles
#define PG_U4 (PG_TILES * 8 * 32)        // uint4 per (page, layer, kv head) for K; the same again for V
#define PAGE_BYTES ((size_t)NL * 8 * 2 * PG_U4 * 16)
#define SEG 128                          // attention segment (positions)

#include "dsched.h"
// The plan of a pass (ints): written by the device scheduler (ds_step in dsched.h) or, for the offline contract and
// the tests, by the host. Layout in dsched.h.
#define TCAP DS_TCAP                     // columns per pass at most
#define SELCAP DS_SELCAP                 // columns per pass that need logits / a token
#define MAXU DS_MAXU                     // attention units per pass (a unit: up to 16 consecutive positions of one sequence)
#define MAXBT DS_MAXBT                   // attention tasks per pass
#ifndef SS_LOG
#define SS_LOG 5
#endif
#define SS_SEGS (1 << SS_LOG)            // segments per super-segment
#define SS_SHIFT (7 + SS_LOG)            // log2 of the positions of a super-segment
#define PARTCAP (SS_LOG == 5 ? 2048 : SS_LOG == 4 ? 4096 : 8192)   // (unit, super-segment) parts kept in the scratch per pass
#define PL_SLOT DS_PL_SLOT               // [TCAP] slot | (last column of its run ? LASTBIT : 0) | (column - first column of its attention unit) << 17
#define PL_POS DS_PL_POS                 // [TCAP] position of the column in its sequence
#define PL_TOK DS_PL_TOK                 // [TCAP] -1: the slot's last generated token; else the token id (host plan) or its index in the prompt arena (device plan)
#define PL_UNIT DS_PL_UNIT               // [MAXU][4] attention units: first column, columns (<= 16), first part in the scratch (-1: one super-segment, no fold), super-segments
#define PL_BT DS_PL_BT                   // [MAXBT] attention tasks, those of two units first: first unit | super-segment << 16 | kv head << 22
#define PL_FOLD DS_PL_FOLD               // [MAXU] units whose super-segments have to be folded
#define PL_SEL DS_PL_SEL                 // [SELCAP][2]: column, slot (-1: none)
#define PL_PT DS_PL_PT                   // [NSLOT][MAXPG] page ids
#define PL_CU DS_PL_CU                   // [TCAP] attention unit of the column
#define PL_HDR DS_PL_HDR                 // [16] 0 columns, 1 tasks of two units, 2 tasks of one unit, 3 units to fold, 4 selected columns, 5 pages freed
#define PL_INTS DS_PL_INTS
// a kernel argument >= 0 is the value; -1 - i means: element i of the plan header (the host does not know it)
#define HV(arg, plan) ((arg) >= 0 ? (arg) : (plan)[PL_HDR + (-(arg) - 1)])
// position offset of a pass: the argument, or (negative) the cell the generate() loop on the device advances
#define PV(arg, D) ((arg) >= 0 ? (arg) : __ldcg((D).cell))
#define LASTBIT 0x10000

#define MMA(c, a, b) asm volatile( \
  "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
  : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) \
  : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y))

__device__ __forceinline__ unsigned short f2bf(float f) {
  unsigned u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (unsigned short)(u >> 16);
}
__device__ __forceinline__ float bf2f(unsigned v) { return __uint_as_float(v << 16); }
// Layout of every GEMM operand in global memory, weights [M rows][K] and activations [columns][K] alike
// ("rows" below are M rows or token columns): [k / 64][row / 8][(k % 64) / 8][row % 8][k % 8] in bf16 elements.
// One (K chunk of 64, 8 rows) is 1 KB; inside it the 8 rows x 8 K-elements of each K-octet are 128 contiguous
// bytes. A K chunk of consecutive row groups is therefore one contiguous byte range that the copy engine moves
// into shared memory as it is, and there it is the canonical K-major operand of wgmma (no swizzle: leading
// offset 128 B between the two K-octets of an instruction, stride 1 KB between groups of 8 rows).
__device__ __forceinline__ size_t xidx(int k, int row, int groups) {
  return ((((size_t)(k >> 6) * groups + (row >> 3)) * 8 + ((k >> 3) & 7)) * 8 + (row & 7)) * 8 + (k & 7);
}
#define NG_X (TCAP / 8)      // column groups of the activation buffers
#define NG_LM (SELCAP / 8)   // ... of the lm_head input
__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
#define NINF (-__int_as_float(0x7f800000))
#define SC2 ((float)(0.08838834764831845 * 1.4426950408889634))   // log2(e) / sqrt(128)

// ---------------------------------------------------------------------------------------------------------
// GEMM: Y[M x T] = W[M x K] X[K x T] on the Hopper path.
//   * wgmma: one instruction of a warpgroup (4 warps) multiplies 64 rows x NB columns x 16 K, both operands read
//     from shared memory through descriptors, accumulators in registers (NB / 2 per thread);
//   * cp.async.bulk: the copy engine moves a contiguous byte range global -> shared memory; no warp loads
//     anything, so the copy overlaps the multiply completely;
//   * mbarriers: a stage (K chunk of 64) is "full" when its bytes have arrived, "empty" when both consumer
//     warpgroups are done with it.
// A block = 2 consumer warpgroups + 1 producer warp: 128 rows x 2 NB columns (warpgroup w: columns w * NB ..),
// 4 stages of (A: 128 rows x 64 K = 16 KB, B: 2 NB columns x 64 K) in shared memory. Block b takes units
// b, b + grid, ... in row-major order: the SMs work on a window of row blocks whose weights stay in L2 while
// every column block of them is computed.
// Why this path (all measured here, T = 1024, 24576 x 4096): my m16n8k16 kernels with warp loads into shared
// memory reached 255 / 334 / 292 / 301 TFLOPS in four designs. tests/copy_rate.cu: an SM copies global -> shared
// memory at 10 KB/us per loading warp up to ~55 KB/us; tests/roles_rate.cu, tests/l1_stage.cu: while it does,
// the multiplies stall (same warps, other warps, or L1 as the buffer: always copy time + multiply time).
// The vendor GEMM runs at 790-820 TFLOPS on these shapes; its launch (132 blocks x 384 threads, 168 registers,
// 213 KB shared memory, "64x4" in the kernel name) pointed to wgmma + the copy engine. This kernel: 738 TFLOPS,
// and 2.2-2.8 TB/s of weights at T <= 64 (the old one: 1.2), tests/wg_bench.cu.
// Instruction forms after CUTLASS (cute/arch/mma_sm90_gmma.hpp, copy_sm90_tma.hpp, cutlass/arch/barrier.h).
// ---------------------------------------------------------------------------------------------------------
#include "wg_gen.h"
#ifndef WG_NS1
#define WG_NS1 8                             // stages of the 64-row variant (weights straight from HBM: deeper look-ahead)
#endif
#define WG_NS(NB, NT) ((NT) != 1 || (NB) > 64 ? 4 : (NB) <= 16 ? WG_NS1 : 8)   // stages in shared memory
#ifndef WG_PIPE
#define WG_PIPE 1
#endif
#define WG_KC 64                               // K per stage: 4 wgmma instructions per 64-row tile
#define WG_A_TILE (64 * WG_KC * 2)              // one 64-row tile of a stage: 8 KB
#define WG_THREADS 288
#define WG_SMEM(NB, NT) (WG_NS(NB, NT) * ((NT) * WG_A_TILE + 2 * (NB) * WG_KC * 2) + 16 * WG_NS(NB, NT))
__device__ __forceinline__ uint32_t sm32(const void* p) { return (uint32_t)__cvta_generic_to_shared(p); }
__device__ __forceinline__ void mbar_init(uint64_t* b, uint32_t count) { asm volatile("mbarrier.init.shared::cta.b64 [%1], %0;" :: "r"(count), "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_arrive(uint64_t* b) { asm volatile("mbarrier.arrive.shared::cta.b64 _, [%0];" :: "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_expect(uint64_t* b, uint32_t bytes) { asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%1], %0;" :: "r"(bytes), "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_wait(uint64_t* b, uint32_t phase) {
  asm volatile("{\n.reg .pred P1;\nLAB_WAIT:\nmbarrier.try_wait.parity.shared::cta.b64 P1, [%0], %1;\n@P1 bra DONE;\nbra LAB_WAIT;\nDONE:\n}" :: "r"(sm32(b)), "r"(phase) : "memory");
}
__device__ __forceinline__ void bulk_g2s(void* smem_dst, const void* gsrc, uint32_t bytes, uint64_t* b) {
  asm volatile("cp.async.bulk.shared::cluster.global.mbarrier::complete_tx::bytes [%0], [%1], %2, [%3];" :: "r"(sm32(smem_dst)), "l"(gsrc), "r"(bytes), "r"(sm32(b)) : "memory");
}
__device__ __forceinline__ uint64_t wg_desc(const void* smem_ptr) {
  return (uint64_t)((sm32(smem_ptr) >> 4) & 0x3fff) | ((uint64_t)8 << 16) | ((uint64_t)64 << 32);
}
template <int NB> struct WG;
template <> struct WG<8> { static __device__ __forceinline__ void mma(float (&d)[4], uint64_t da, uint64_t db) { WGMMA_N8(d, da, db); } };
template <> struct WG<16> { static __device__ __forceinline__ void mma(float (&d)[8], uint64_t da, uint64_t db) { WGMMA_N16(d, da, db); } };
template <> struct WG<32> { static __device__ __forceinline__ void mma(float (&d)[16], uint64_t da, uint64_t db) { WGMMA_N32(d, da, db); } };
template <> struct WG<64> { static __device__ __forceinline__ void mma(float (&d)[32], uint64_t da, uint64_t db) { WGMMA_N64(d, da, db); } };
template <> struct WG<128> { static __device__ __forceinline__ void mma(float (&d)[64], uint64_t da, uint64_t db) { WGMMA_N128(d, da, db); } };

enum { EP_QKV = 0, EP_ADD = 1, EP_GU = 2, EP_LM = 3, EP_LMARG = 4, EP_RAW = 5 };

struct GemmArgs {
  const unsigned short* W;   // weights [M][K] in the operand layout (see xidx)
  const unsigned short* X;   // activations [columns][K] in the operand layout with NG column groups
  int M, K, T, NG;
  const float* rn;        // [T] 1/rms of the input norm (QKV, GU, LM)
  float* out;             // QKV: [T][6144]; LM: logits [T][VOCAB]; RAW: [T][M]
  float* x;               // ADD: residual stream [T][4096]
  const float* aux;       // ADD: weights of the next RMSNorm [4096]
  unsigned short* frag;   // ADD: next norm's input (K = 4096); GU: silu(gate)*up (K = 12288); operand layout, NG_X groups
  float* ssq;             // ADD: [T][256] per-16-row sums of x^2
  float* bm_val; int* bm_idx;   // LMARG: [M / 32][T] best logit and its row per (row block, warp)
  const int* plan;        // T < 0: the number of columns is element -T - 1 of the plan header
  int shape;              // block shape (gemm_shape()), or -1: chosen on the device from the number of columns
};

// Block shapes. A block computes 64 NT rows x 2 NB columns per unit (NB columns per consumer warpgroup); the units of
// a matrix (row blocks x column blocks) are dealt to the blocks of the grid, one block per SM. The arithmetic of
// an output element does not depend on the shape (tests/gemm_shapes.py compares the bits), so the shape is free:
//  - up to 64 columns the kernel is bound by streaming the weights: 64-row blocks, so that 64 SMs stream the
//    4096-row matrices (an SM takes 40-60 KB/us from the copy engine), and the smallest wgmma that covers T;
//  - beyond, by how full the SMs are: a 4096-row matrix at 256 columns has 32 units of 128 x 256 for 132 SMs. A stage
//    (64 of K) of a block takes about 0.19 us + 0.072 us per 64 x 64 of the block's area, so the time of a matrix
//    is about (units per SM, rounded up) x stage time x K / 64: gemm_shape() takes the shape with the least.
//    Measured over all shapes per matrix and T (tests/gemm_shapes.py): the GEMMs of a pass of 256 columns
//    11.1 -> 7.2 ms, 512: 13.2 -> 10.8, 768: 18.4 -> 16.5, 1024: 21.2 -> 19.8.
#define N_SHAPES 8
#ifndef SHAPE8_T
#define SHAPE8_T 16                           // up to this many columns: 8 columns per warpgroup
#endif
__host__ __device__ __forceinline__ void shape_dims(int s, int& nb, int& nt, float& stage_us) {
  switch (s) {
    case 0: nb = 16; nt = 1; stage_us = 0.22f; break;
    case 1: nb = 32; nt = 1; stage_us = 0.25f; break;
    case 2: nb = 64; nt = 1; stage_us = 0.31f; break;
    case 3: nb = 64; nt = 2; stage_us = 0.49f; break;
    case 4: nb = 64; nt = 3; stage_us = 0.60f; break;
    case 5: nb = 64; nt = 4; stage_us = 0.77f; break;
    case 7: nb = 8; nt = 1; stage_us = 0.20f; break;
    default: nb = 128; nt = 2; stage_us = 0.76f; break;
  }
}
__host__ __device__ __forceinline__ int gemm_shape(int M, int T, int nsm) {
  if (T <= SHAPE8_T) return 7;
  if (T <= 32) return 0;
  if (T <= 64) return 1;
  int best = 6; float best_c = 1e30f;
  for (int s = 1; s <= 6; s++) {
    int nb, nt; float us;
    shape_dims(s, nb, nt, us);
    if (M % (64 * nt)) continue;
    const int units = (M / (64 * nt)) * ((T + 2 * nb - 1) / (2 * nb));
    const float c = (float)((units + nsm - 1) / nsm) * us;
    if (c < best_c) { best_c = c; best = s; }
  }
  return best;
}

template <int EP, int NB, int NT>
__device__ __forceinline__ void gemm_body(const GemmArgs& a, const int T, unsigned char* smem) {
  enum { A_STAGE = NT * WG_A_TILE, B_STAGE = 2 * NB * WG_KC * 2, STAGE = A_STAGE + B_STAGE, WG_STAGES = WG_NS(NB, NT) };
  uint64_t* full = (uint64_t*)(smem + WG_STAGES * STAGE);
  uint64_t* empty = full + WG_STAGES;
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, wg = warp >> 2;
  if (tid == 0) {
    for (int s = 0; s < WG_STAGES; s++) { mbar_init(full + s, 1); mbar_init(empty + s, 2); }
    asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  }
  __syncthreads();
  const int n_cb = (T + 2 * NB - 1) / (2 * NB), n_rb = a.M / (64 * NT), n_units = n_rb * n_cb, nchunk = a.K / WG_KC;
  const int mg = a.M / 8;
  unsigned gc = 0;                               // chunks so far: the producer and the consumers count alike
  if (wg == 2) {
    // ---- producer: one thread asks the copy engine for A and B of every chunk, up to WG_STAGES ahead
    if (lane != 0) return;
    for (int u = blockIdx.x; u < n_units; u += gridDim.x) {
      const int rb = u / n_cb, cb = u - rb * n_cb;
      for (int c = 0; c < nchunk; c++, gc++) {
        const int s = gc % WG_STAGES; const unsigned r = gc / WG_STAGES;
        if (r >= 1) mbar_wait(empty + s, (r - 1) & 1);
        mbar_expect(full + s, STAGE);
        bulk_g2s(smem + s * STAGE, a.W + ((size_t)c * mg + rb * 8 * NT) * 512, A_STAGE, full + s);
        bulk_g2s(smem + s * STAGE + A_STAGE, a.X + ((size_t)c * a.NG + cb * (NB / 4)) * 512, B_STAGE, full + s);
      }
    }
    return;
  }
  // ---- consumers: warpgroup wg computes rows 0..127 x columns wg * NB .. + NB - 1 of the block
  for (int u = blockIdx.x; u < n_units; u += gridDim.x) {
    const int rb = u / n_cb, cb = u - rb * n_cb;
    float acc[NT][NB / 2];
#pragma unroll
    for (int i = 0; i < NT; i++)
#pragma unroll
      for (int j = 0; j < NB / 2; j++) acc[i][j] = 0.f;
    for (int c = 0; c < nchunk; c++, gc++) {
      const int s = gc % WG_STAGES; const unsigned r = gc / WG_STAGES;
      mbar_wait(full + s, r & 1);
      const unsigned char* As = smem + s * STAGE;
      const unsigned char* Bs = As + A_STAGE + wg * (NB * WG_KC * 2);
      asm volatile("wgmma.fence.sync.aligned;" ::: "memory");
#pragma unroll
      for (int j = 0; j < WG_KC / 16; j++) {
        const uint64_t db = wg_desc(Bs + j * 256);
#pragma unroll
        for (int i = 0; i < NT; i++) WG<NB>::mma(acc[i], wg_desc(As + i * WG_A_TILE + j * 256), db);
      }
      asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory");
#if WG_PIPE
      // the instructions of this stage stay in flight while the next stage is issued; the stage before is released
      asm volatile("wgmma.wait_group.sync.aligned 1;" ::: "memory");
      if (c > 0 && (tid & 127) == 0) mbar_arrive(empty + (gc - 1) % WG_STAGES);
#else
      asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
      if ((tid & 127) == 0) mbar_arrive(empty + s);
#endif
    }
#if WG_PIPE
    asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
    if ((tid & 127) == 0) mbar_arrive(empty + (gc - 1) % WG_STAGES);
#endif
    // ---- epilogue. Register 4 j + e of thread (warp t2 of the group, lane (g, t)) of the 64-row tile i holds
    // column group j of the warpgroup, e: 0 (row g, col 2t), 1 (row g, col 2t+1), 2 (row g+8, col 2t), 3 (row g+8, col 2t+1)
    // with rows relative to the 16-row tile 4 i + t2 of the block.
    {
      const int g = lane >> 2, t = lane & 3, t2 = warp & 3;
#pragma unroll
      for (int j = 0; j < NB / 8; j++) {
        const int n0 = cb * 2 * NB + wg * NB + 8 * j + 2 * t, n1 = n0 + 1;
        const bool v0 = n0 < T, v1 = n1 < T;
        float r0 = 0.f, r1 = 0.f;
        float bv0 = NINF, bv1 = NINF; int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
        if (EP == EP_QKV || EP == EP_GU || EP == EP_LM || EP == EP_LMARG) {
          if (v0) r0 = __ldcg(a.rn + n0);
          if (v1) r1 = __ldcg(a.rn + n1);
        }
        // ADD: the residual values of this column pair are requested together, before anything is stored
        // (a load between stores waits for its turn: the epilogue was 4.4 of 23.7 ms of GEMM time per 1024-column pass)
        float xin[NT][4];
        if (EP == EP_ADD) {
#pragma unroll
          for (int i = 0; i < NT; i++) {
            const int row = (rb * (4 * NT) + 4 * i + t2) * 16 + g;
            if (v0) { const float* p = a.x + (size_t)n0 * H + row; xin[i][0] = __ldcg(p); xin[i][1] = __ldcg(p + 8); }
            if (v1) { const float* p = a.x + (size_t)n1 * H + row; xin[i][2] = __ldcg(p); xin[i][3] = __ldcg(p + 8); }
          }
        }
#pragma unroll
        for (int i = 0; i < NT; i++) {
          const int tile = rb * (4 * NT) + 4 * i + t2;
          const int row = tile * 16 + g;
          const float* cc = &acc[i][4 * j];
          if (EP == EP_QKV || EP == EP_LM || EP == EP_RAW) {
            const size_t stride = EP == EP_QKV ? QKV_ROWS : (EP == EP_LM ? VOCAB : (size_t)a.M);
            const float q0 = EP == EP_RAW ? 1.f : r0, q1 = EP == EP_RAW ? 1.f : r1;
            if (v0) { a.out[(size_t)n0 * stride + row] = cc[0] * q0; a.out[(size_t)n0 * stride + row + 8] = cc[2] * q0; }
            if (v1) { a.out[(size_t)n1 * stride + row] = cc[1] * q1; a.out[(size_t)n1 * stride + row + 8] = cc[3] * q1; }
          } else if (EP == EP_GU) {
            const int jr = tile * 8 + g;   // rows 0..7 of the tile are gate[jr], rows 8..15 are up[jr]
            if (v0) { float gt = cc[0] * r0; float m = gt / (1.0f + __expf(-gt)) * (cc[2] * r0); a.frag[xidx(jr, n0, NG_X)] = f2bf(m); }
            if (v1) { float gt = cc[1] * r1; float m = gt / (1.0f + __expf(-gt)) * (cc[3] * r1); a.frag[xidx(jr, n1, NG_X)] = f2bf(m); }
          } else if (EP == EP_ADD) {
            const float w0 = a.aux[row], w1 = a.aux[row + 8];
            float s0 = 0.f, s1 = 0.f;
            if (v0) {
              float* p = a.x + (size_t)n0 * H + row;
              float xa = xin[i][0] + cc[0], xb = xin[i][1] + cc[2];
              p[0] = xa; p[8] = xb;
              a.frag[xidx(row, n0, NG_X)] = f2bf(w0 * xa);
              a.frag[xidx(row + 8, n0, NG_X)] = f2bf(w1 * xb);
              s0 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            if (v1) {
              float* p = a.x + (size_t)n1 * H + row;
              float xa = xin[i][2] + cc[1], xb = xin[i][3] + cc[3];
              p[0] = xa; p[8] = xb;
              a.frag[xidx(row, n1, NG_X)] = f2bf(w0 * xa);
              a.frag[xidx(row + 8, n1, NG_X)] = f2bf(w1 * xb);
              s1 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            s0 += __shfl_xor_sync(0xffffffffu, s0, 4); s1 += __shfl_xor_sync(0xffffffffu, s1, 4);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 8); s1 += __shfl_xor_sync(0xffffffffu, s1, 8);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 16); s1 += __shfl_xor_sync(0xffffffffu, s1, 16);
            if (g == 0) {
              if (v0) a.ssq[(size_t)n0 * 256 + tile] = s0;
              if (v1) a.ssq[(size_t)n1 * 256 + tile] = s1;
            }
          } else if (EP == EP_LMARG) {
            // the logits of EP_LM, reduced to the best row per column; rows ascend, strict > keeps the lowest
            float v;
            v = cc[0] * r0; if (v > bv0) { bv0 = v; bi0 = row; }
            v = cc[2] * r0; if (v > bv0) { bv0 = v; bi0 = row + 8; }
            v = cc[1] * r1; if (v > bv1) { bv1 = v; bi1 = row; }
            v = cc[3] * r1; if (v > bv1) { bv1 = v; bi1 = row + 8; }
          }
        }
        if (EP == EP_LMARG) {
#pragma unroll
          for (int o = 16; o >= 4; o >>= 1) {
            float uv = __shfl_xor_sync(0xffffffffu, bv0, o); int ix = __shfl_xor_sync(0xffffffffu, bi0, o);
            if (uv > bv0 || (uv == bv0 && ix < bi0)) { bv0 = uv; bi0 = ix; }
            uv = __shfl_xor_sync(0xffffffffu, bv1, o); ix = __shfl_xor_sync(0xffffffffu, bi1, o);
            if (uv > bv1 || (uv == bv1 && ix < bi1)) { bv1 = uv; bi1 = ix; }
          }
          if (g == 0) {
            const size_t base = (size_t)(rb * 4 + t2) * T;
            if (v0) { a.bm_val[base + n0] = bv0; a.bm_idx[base + n0] = bi0; }
            if (v1) { a.bm_val[base + n1] = bv1; a.bm_idx[base + n1] = bi1; }
          }
        }
      }
    }
  }
}

template <int EP>
__global__ void __launch_bounds__(WG_THREADS, 1) k_gemm(GemmArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  const int T = HV(a.T, a.plan);
  if (T == 0) return;
  switch (a.shape >= 0 ? a.shape : gemm_shape(a.M, T, gridDim.x)) {
    case 0: gemm_body<EP, 16, 1>(a, T, smem); break;
    case 7: gemm_body<EP, 8, 1>(a, T, smem); break;
    case 1: gemm_body<EP, 32, 1>(a, T, smem); break;
    case 2: gemm_body<EP, 64, 1>(a, T, smem); break;
    case 3: gemm_body<EP, 64, 2>(a, T, smem); break;
    case 4: if constexpr (EP != EP_LM && EP != EP_LMARG) gemm_body<EP, 64, 3>(a, T, smem); break;   // the vocabulary is not
    case 5: if constexpr (EP != EP_LM && EP != EP_LMARG) gemm_body<EP, 64, 4>(a, T, smem); break;   // a multiple of 192
    default: gemm_body<EP, 128, 2>(a, T, smem); break;
  }
}
// the same with the shape fixed at compile time (the host launches these when it knows the number of columns)
template <int EP, int NB, int NT>
__global__ void __launch_bounds__(WG_THREADS, 1) k_gemm1(GemmArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  gemm_body<EP, NB, NT>(a, a.T, smem);
}
#define WG_SMEM_MAX (WG_SMEM(64, 1) > WG_SMEM(16, 1) ? WG_SMEM(64, 1) : WG_SMEM(16, 1))
static_assert(WG_SMEM(64, 4) <= WG_SMEM_MAX && WG_SMEM(128, 2) <= WG_SMEM_MAX && WG_SMEM(64, 3) <= WG_SMEM_MAX && WG_SMEM(32, 1) <= WG_SMEM_MAX && WG_SMEM(8, 1) <= WG_SMEM_MAX, "smem");

// ---------------------------------------------------------------------------------------------------------
// small per-column kernels
// ---------------------------------------------------------------------------------------------------------
struct Dev {
  const unsigned short* W; const unsigned short* embed; const float* norm_w; const float* qk_norm_w; const float* rope;
  uint4* kv;                 // page pool: [page][layer][kv head][K | V][PG_U4]
  const int* plan;           // device copy of the pass plan
  float* x;                  // [TCAP][H] residual stream
  unsigned short* xfrag;     // [TCAP][H] bf16(w * x) in the operand layout: input of the next norm + matvec
  float* ssq;                // [TCAP][256]
  float* rn;                 // [TCAP]
  float* qkv;                // [TCAP][6144]
  unsigned short* qfrag;     // [MAXU][8 kv heads][16 KB] q after norm, RoPE and score scale, bf16 (see qidx)
  unsigned short* afrag;     // [TCAP][H] attention output, operand layout
  unsigned short* mfrag;     // [TCAP][INNER] silu(gate) * up, operand layout
  unsigned short* lmfrag;    // [SELCAP][H] final-norm input of the selected columns, operand layout (NG_LM groups)
  float* lm_rn;              // [SELCAP]
  float* bm_val; int* bm_idx;// [VOCAB / 16][SELCAP] best logit and row per (row block, warp) of the lm_head: VOCAB / 16 of them with 64-row blocks
  int* last_tok;             // [NSLOT] last generated token of a slot
  int* sel_tok;              // [SELCAP] tokens of this pass
  int* cell;                 // [4] generate() loop on the device: position offset of the pass, step, end step
  float4* att_part;          // [PARTCAP][8 kv heads][17][128]: fold state of a (unit, kv head, super-segment)
  int* ctr;                  // [2 NL] task counters of the attention kernel, one per layer (zeroed by k_embed)
};

// embedding: x = embed[token]; fragments of bf16(w0 * x) and per-tile sums of x^2 for the first norm
struct EmbedArgs { Dev d; int T; int pos_add; const long long* tok64; const int* arena; };   // arena: PL_TOK holds indices into it
__global__ void __launch_bounds__(256) k_embed(EmbedArgs a) {
  const Dev& D = a.d;
  if (blockIdx.x == 0 && threadIdx.x < NL * 2) D.ctr[threadIdx.x] = 0;
  const int T = HV(a.T, D.plan);
  for (int col = blockIdx.x; col < T; col += gridDim.x) {
    long long tok;
    if (a.tok64) tok = a.tok64[col];
    else {
      tok = D.plan[PL_TOK + col];
      if (tok < 0) tok = __ldcg(D.last_tok + (D.plan[PL_SLOT + col] & 0xffff));
      else if (a.arena) tok = a.arena[tok];
    }
    const uint2* e = (const uint2*)(D.embed + (size_t)tok * H);
    for (int i = threadIdx.x; i < H / 4; i += 256) {
      uint2 v = e[i];
      float4 f = make_float4(bf2f(v.x & 0xffffu), bf2f(v.x >> 16), bf2f(v.y & 0xffffu), bf2f(v.y >> 16));
      ((float4*)(D.x + (size_t)col * H))[i] = f;
      float4 wv = ((const float4*)D.norm_w)[i];
      const int k = i * 4;
      D.xfrag[xidx(k + 0, col, NG_X)] = f2bf(wv.x * f.x);
      D.xfrag[xidx(k + 1, col, NG_X)] = f2bf(wv.y * f.y);
      D.xfrag[xidx(k + 2, col, NG_X)] = f2bf(wv.z * f.z);
      D.xfrag[xidx(k + 3, col, NG_X)] = f2bf(wv.w * f.w);
      float p = __fadd_rn(__fmaf_rn(f.x, f.x, __fmul_rn(f.y, f.y)), __fmaf_rn(f.z, f.z, __fmul_rn(f.w, f.w)));
      p += __shfl_xor_sync(0xffffffffu, p, 1);
      p += __shfl_xor_sync(0xffffffffu, p, 2);
      if ((i & 3) == 0) D.ssq[(size_t)col * 256 + (i >> 2)] = p;
    }
  }
}

// 1/rms per column from the 256 per-tile partial sums (fixed order). One warp per column.
struct RnArgs { const float* ssq; float* rn; int T; const int* plan; };
__global__ void __launch_bounds__(256) k_rnorm(RnArgs a) {
  const int lane = threadIdx.x & 31;
  const int T = HV(a.T, a.plan);
  for (int col = blockIdx.x * 8 + (threadIdx.x >> 5); col < T; col += gridDim.x * 8) {
    const float4* q = (const float4*)(a.ssq + (size_t)col * 256) + lane * 2;
    float4 u = __ldcg(q), v = __ldcg(q + 1);
    float s = ((u.x + u.y) + (u.z + u.w)) + ((v.x + v.y) + (v.z + v.w));
    s = warp_sum(s);
    if (lane == 0) a.rn[col] = rsqrtf(__fmaf_rn(s, 1.0f / H, 1e-6f));
  }
}

// K, V and q are stored as operands of the warpgroup MMA (8 x 8 bf16 per 128 bytes, see wg_desc):
//   K of a page (512 positions) of one (layer, kv head): [pos / 8][dim / 8][pos % 8][dim % 8]; a segment of 128
//     positions is 32 KB contiguous = the B operand (positions x dims) of the score product;
//   V: [pos / 128][dim / 8][(pos % 128) / 8][dim % 8][pos % 8]; a segment is 32 KB contiguous = the B operand
//     (dims x positions) of the value product;
//   q of a unit (16 positions x the 4 heads of a kv head = 64 rows, row = 4 * position + head): [row / 8][dim / 8][row % 8][dim % 8].
__device__ __forceinline__ size_t kidx(int pp, int d) { return ((((size_t)(pp >> 3) * 16 + (d >> 3)) * 8 + (pp & 7)) * 8 + (d & 7)); }
__device__ __forceinline__ size_t vidx(int pp, int d) { return (((((size_t)(pp >> 7) * 16 + (d >> 3)) * 16 + ((pp >> 3) & 15)) * 8 + (d & 7)) * 8 + (pp & 7)); }
__device__ __forceinline__ size_t qidx(int row, int d) { return ((((size_t)(row >> 3) * 16 + (d >> 3)) * 8 + (row & 7)) * 8 + (d & 7)); }
__device__ __forceinline__ unsigned short* page_k(const Dev& D, int slot, int pos, int layer, int g) {
  const int page = D.plan[PL_PT + slot * MAXPG + (pos >> 9)];
  return (unsigned short*)(D.kv + ((((size_t)page * NL + layer) * 8 + g) * 2) * PG_U4);
}

// After the q/k/v matvec: per column 48 vectors of 128 (32 q heads, 8 k heads, 8 v heads), one warp each.
// q, k: RMSNorm over the head, RoPE at the column's position. q -> qfrag; k, v -> the sequence's KV pages.
#ifndef PREP_BLOCKS
#define PREP_BLOCKS 2      // blocks of 16 warps per SM (4 or 8: no difference)
#endif
struct PrepArgs { Dev d; int T; int layer; int pos_add; };
__global__ void __launch_bounds__(512) k_prep(PrepArgs a) {
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31;
  const int total = HV(a.T, D.plan) * 48, padd = PV(a.pos_add, D);
  for (int wt = blockIdx.x * 16 + (threadIdx.x >> 5); wt < total; wt += gridDim.x * 16) {
    const int col = wt / 48, vec = wt - col * 48;
    const int sl = D.plan[PL_SLOT + col], slot = sl & 0xffff, pos = D.plan[PL_POS + col] + padd;
    const int row = vec < 32 ? vec * 128 : (vec < 40 ? 4096 + (vec - 32) * 128 : 5120 + (vec - 40) * 128);
    const float4 x = __ldcg((const float4*)(D.qkv + (size_t)col * QKV_ROWS + row) + lane);
    float xe[4] = {x.x, x.y, x.z, x.w};
    unsigned short ob[4];
    if (vec < 40) {
      const float4 wn = ((const float4*)(D.qk_norm_w + (a.layer * 2 + (vec < 32 ? 0 : 1)) * 128))[lane];
      const float4 cs = ((const float4*)(D.rope + (size_t)pos * 128))[lane & 15];
      const float4 sn = ((const float4*)(D.rope + (size_t)pos * 128 + 64))[lane & 15];
      const float ss = warp_sum(__fadd_rn(__fmaf_rn(x.x, x.x, __fmul_rn(x.y, x.y)), __fmaf_rn(x.z, x.z, __fmul_rn(x.w, x.w))));
      const float r = rsqrtf(__fmaf_rn(ss, 1.0f / 128, 1e-6f));
      const float we[4] = {wn.x, wn.y, wn.z, wn.w}, ce[4] = {cs.x, cs.y, cs.z, cs.w}, se[4] = {sn.x, sn.y, sn.z, sn.w};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const float yv = __fmul_rn(we[i], __fmul_rn(xe[i], r));
        const float other = __shfl_xor_sync(0xffffffffu, yv, 16);
        const float rot = lane < 16 ? __fmaf_rn(yv, ce[i], -__fmul_rn(other, se[i])) : __fmaf_rn(yv, ce[i], __fmul_rn(other, se[i]));
        ob[i] = f2bf(vec < 32 ? __fmul_rn(rot, SC2) : rot);   // q carries the score scale log2(e) / sqrt(128)
      }
    } else {
#pragma unroll
      for (int i = 0; i < 4; i++) ob[i] = f2bf(xe[i]);
    }
    if (vec < 32) {
      const int g = vec >> 2, h = vec & 3, iq = (sl >> 17) & 15;
      unsigned short* Q = D.qfrag + ((size_t)D.plan[PL_CU + col] * 8 + g) * 8192;
      // the 4 dims of a lane are 8 contiguous bytes in the operand layout: one store instead of four
      *(unsigned long long*)(Q + qidx(4 * iq + h, 4 * lane)) = (unsigned long long)ob[0] | ((unsigned long long)ob[1] << 16) | ((unsigned long long)ob[2] << 32) | ((unsigned long long)ob[3] << 48);
    } else if (vec < 40) {
      unsigned short* Kc = page_k(D, slot, pos, a.layer, vec - 32);
      *(unsigned long long*)(Kc + kidx(pos & 511, 4 * lane)) = (unsigned long long)ob[0] | ((unsigned long long)ob[1] << 16) | ((unsigned long long)ob[2] << 32) | ((unsigned long long)ob[3] << 48);
    } else {
      unsigned short* Vc = page_k(D, slot, pos, a.layer, vec - 40) + (size_t)PG_U4 * 8;
      // The last column of a run also clears the rest of its group of 16 positions: they enter the value product
      // of that group with weight 0 and must be finite. A run of one column (a decode row) that does not start a
      // group needs no clearing: the run that wrote the position before it cleared the same group to its end.
      // (The clearing is 2-byte stores to memory that is not in the cache: 0.9 us per position; a decode step
      // spent 3 to 17 us per layer here depending on the position.)
      const int p0 = pos & 511;
      const bool single = (sl & LASTBIT) && (col == 0 || (D.plan[PL_SLOT + col - 1] & LASTBIT));
      const int pend = ((sl & LASTBIT) && !(single && (p0 & 15))) ? (p0 | 15) : p0;
      if (single && pend != p0) {
        // a decode row at the start of a group: the 16 positions of a dim are two rows of 8, one 16-byte store each
#pragma unroll
        for (int i = 0; i < 4; i++) {
          *(uint4*)(Vc + vidx(p0, 4 * lane + i)) = make_uint4(ob[i], 0u, 0u, 0u);
          *(uint4*)(Vc + vidx(p0 + 8, 4 * lane + i)) = make_uint4(0u, 0u, 0u, 0u);
        }
      } else {
        for (int pp = p0; pp <= pend; pp++) {
#pragma unroll
          for (int i = 0; i < 4; i++) Vc[vidx(pp, 4 * lane + i)] = pp == p0 ? ob[i] : (unsigned short)0;
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// attention (see the canonical arithmetic at the top), on the warpgroup MMA.
// A task = (1 or 2 units of up to 16 consecutive positions of one sequence, kv head, super-segment), claimed by a
// block from a counter. Warpgroup w of the block computes unit w: 64 query rows (16 positions x 4 heads).
// Per segment of 128 keys:
//   scores [64 rows x 128 positions] = 8 instructions m64n128k16 (A = q rows x dims from shared memory, B = K);
//   thread (warp t2, lane (g8, t)) holds rows g8, g8 + 8 of the warp's 16 rows and positions 8 v2 + 2t, 2t + 1:
//   register 4 v2 + 2 v1 + v0. Max, 2^(s - R), bf16 pack: per thread, in registers;
//   the packed weights of 16 positions ARE the register A operand of the value product
//   O [64 rows x 128 dims] += W x V (B = V from shared memory), and Z against a group of ones.
// K and V of a segment (32 KB each, contiguous) come into shared memory by the copy engine, one segment ahead.
// Decode rows are units of one position: the same kernel, one warpgroup active.
// A unit with more than one super-segment leaves its parts in a scratch and k_attn_fold folds them in order; with
// one super-segment the fold is the identity and the kernel writes the output itself.
// History: v1 scores through shared memory 6.0 ns per (query, key) pair; v3 block kernel + two-level fold 3.0;
// v4 state in registers 2.35; v5 copy engine for K/V 1.63 (all m16n8k16; the instruction count per segment
// bounded them); v6 this one.
// ---------------------------------------------------------------------------------------------------------
#define A_THREADS 256
__device__ __forceinline__ float ex2(float x) { float r; asm("ex2.approx.ftz.f32 %0, %1;" : "=f"(r) : "f"(x)); return r; }
__device__ __forceinline__ unsigned cvt_bf(float x) { unsigned short r; asm("cvt.rn.bf16.f32 %0, %1;" : "=h"(r) : "f"(x)); return r; }
__device__ __forceinline__ void fold_factors(float M, float m, float& Mn, float& fa, float& fb) {
  Mn = fmaxf(M, m);
  fa = (M == Mn) ? 1.0f : (M == NINF ? 0.0f : ex2(__fsub_rn(M, Mn)));
  fb = (m == Mn) ? 1.0f : (m == NINF ? 0.0f : ex2(__fsub_rn(m, Mn)));
}
__device__ __forceinline__ unsigned pack2(float a, float b) { return cvt_bf(a) | (cvt_bf(b) << 16); }
__device__ __forceinline__ uint64_t wg_desc2(const void* smem_ptr, unsigned stride16) {   // operand with `stride16` x 16 bytes per 8 rows
  return (uint64_t)((sm32(smem_ptr) >> 4) & 0x3fff) | ((uint64_t)8 << 16) | ((uint64_t)stride16 << 32);
}

// maxima of the valid scores of the two rows of this thread, reduced over the 4 lanes that share the rows
template <bool FULL>
__device__ __forceinline__ void seg_max(const float (&sc)[64], int limA, int limB, int t, float& mA, float& mB) {
  mA = NINF; mB = NINF;
#pragma unroll
  for (int r = 0; r < 64; r++) {
    const int pos = 8 * (r >> 2) + 2 * t + (r & 1);
    if (r & 2) { if (FULL || pos <= limB) mB = fmaxf(mB, sc[r]); }
    else { if (FULL || pos <= limA) mA = fmaxf(mA, sc[r]); }
  }
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 1)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 1));
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 2)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 2));
}
// the weights of positions 16 jv .. 16 jv + 15 as the register A operand: (row A, 2t), (row B, 2t), (row A, 2t + 8), (row B, 2t + 8), two positions each
template <bool FULL>
__device__ __forceinline__ uint4 seg_weights(const float (&sc)[64], int jv, int limA, int limB, int t, float RA, float RB) {
  unsigned w[8];
#pragma unroll
  for (int e = 0; e < 8; e++) {
    const int r = 8 * jv + e;              // 4 v2 + 2 v1 + v0 with v2 = 2 jv + (e >> 2)
    const int pos = 8 * (r >> 2) + 2 * t + (r & 1);
    const unsigned b = cvt_bf(ex2(__fsub_rn(sc[r], (r & 2) ? RB : RA)));
    w[e] = (FULL || pos <= ((r & 2) ? limB : limA)) ? b : 0u;
  }
  return make_uint4(w[0] | (w[1] << 16), w[2] | (w[3] << 16), w[4] | (w[5] << 16), w[6] | (w[7] << 16));
}
// output of this thread's two rows (positions pA, pB of the unit, head h): bf16(O / Z) into the o projection's input
__device__ __forceinline__ void att_out(const Dev& D, const float* O, float ZA, float ZB, int col0, int nq, int g, int t2, int lane) {
  const int g8 = lane >> 2, t = lane & 3, pA = 4 * t2 + (g8 >> 2), pB = pA + 2, kb = (4 * g + (g8 & 3)) * 128;
  const float rzA = __fdiv_rn(1.0f, ZA), rzB = __fdiv_rn(1.0f, ZB);
#pragma unroll
  for (int v2 = 0; v2 < 16; v2++) {
    if (pA < nq) *(unsigned*)(D.afrag + xidx(kb + 8 * v2 + 2 * t, col0 + pA, NG_X)) = pack2(__fmul_rn(O[4 * v2], rzA), __fmul_rn(O[4 * v2 + 1], rzA));
    if (pB < nq) *(unsigned*)(D.afrag + xidx(kb + 8 * v2 + 2 * t, col0 + pB, NG_X)) = pack2(__fmul_rn(O[4 * v2 + 2], rzB), __fmul_rn(O[4 * v2 + 3], rzB));
  }
}

struct AttArgs { Dev d; int task0; int n_tasks; int layer; int pos_add; int* ctr; };
// Pipeline of a task over its segments s (per warpgroup; "group" = a committed batch of async instructions):
//   A  scores(s+1) -> scB                       needs K(s+1) in shared memory
//   B  wait: values(s-1) done; block barrier; thread 0 asks the copy engine for V(s+1) and K(s+2)
//   C  scalar work of segment s on scA: maxima, rescale of O/Z if a maximum moved, weights of the 8 x 16 positions
//   D  values(s): O += W V, Z += W 1            needs V(s) in shared memory
//   E  wait: scores(s+1) done; scA = scB
// so the tensor cores always have a batch while the threads do the scalar work, and the copies have a whole
// iteration. The warpgroup MMAs are issued without any condition around them (ptxas serializes them otherwise,
// "C7519"): a warpgroup without valid positions in a segment runs with all weights 0 (an exact identity), and
// the groups of 16 positions past the end of the sequence take V from the last valid group (finite) with
// weights 0. Hence two instances: NWG = 2 for pairs of units, NWG = 1 for single units (decode rows).
// Ablation of the unpipelined version (1024 columns at context 16k, attention 27.5 ms): tensor instructions 14.4,
// scalar 6.8, copies and barriers ~6: they ran one after the other.
#define AT_K 0                                // [2][32 KB] K segments
#define AT_V 65536                            // [2][32 KB V segment | 2 KB: a 17th dim group of ones, which gives Z]
#define AT_VBUF (32768 + 2048)
#define AT_Q (AT_V + 2 * AT_VBUF)             // q of the units, 16 KB each
#define AT_BAR(NWG) (AT_Q + (NWG) * 16384)    // uint64 [5]: K0, K1, V0, V1, q arrived
#define AT_SMEM(NWG) (AT_BAR(NWG) + 40 + 24)
template <int NWG>
__global__ void __launch_bounds__(NWG * 128, 1) k_attn(AttArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  const Dev& D = a.d;
  const int tid = threadIdx.x, lane = tid & 31, wg = tid >> 7, t2 = (tid >> 5) & 3, g8 = lane >> 2, t = lane & 3;
  uint64_t* bar = (uint64_t*)(smem + AT_BAR(NWG));
  int* ctl = (int*)(bar + 5);
  if (tid == 0) {
#pragma unroll
    for (int i = 0; i < 5; i++) mbar_init(bar + i, 1);
    asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  }
  for (int i = tid; i < 1024; i += NWG * 128) {   // bf16 1.0
    ((unsigned short*)(smem + AT_V + 32768))[i] = 0x3f80; ((unsigned short*)(smem + AT_V + AT_VBUF + 32768))[i] = 0x3f80;
  }
  const int n_tasks = HV(a.n_tasks, D.plan), task0 = HV(a.task0, D.plan), padd = PV(a.pos_add, D);
  if (n_tasks == 0) return;
  unsigned phk0 = 0, phk1 = 0, phv0 = 0, phv1 = 0, phq = 0;   // completions of each barrier so far (every thread counts alike)
  const unsigned char* qs = smem + AT_Q + wg * 16384;
  for (;;) {
    if (tid == 0) ctl[0] = atomicAdd(a.ctr, 1);
    __syncthreads();
    const int task = ctl[0];
    if (task >= n_tasks) break;
    const int bt = D.plan[PL_BT + task0 + task];
    const int u0 = bt & 0xfff, ss = (bt >> 16) & 0x3f, g = bt >> 22;
    // the group: positions up to gtmax of one sequence
    const int ul = u0 + NWG - 1;
    const int gcol = D.plan[PL_UNIT + 4 * ul];
    const int slot = D.plan[PL_SLOT + gcol] & 0xffff;
    const int gtmax = D.plan[PL_POS + gcol] + padd + D.plan[PL_UNIT + 4 * ul + 1] - 1;
    const int s0 = ss * SS_SEGS, s1 = min((gtmax >> 7) + 1, s0 + SS_SEGS);
    // this warpgroup's unit
    const int unit = u0 + wg;
    const int col0 = D.plan[PL_UNIT + 4 * unit], nq = D.plan[PL_UNIT + 4 * unit + 1], pbase = D.plan[PL_UNIT + 4 * unit + 2];
    const int pos0 = D.plan[PL_POS + col0] + padd;
    const int pA = 4 * t2 + (g8 >> 2), pB = pA + 2;
    const int tA = pA < nq ? pos0 + pA : -1, tB = pB < nq ? pos0 + pB : -1;
    const unsigned short* Kpage0 = nullptr;
    if (tid == 0) {
      mbar_expect(bar + 4, NWG * 16384);
#pragma unroll
      for (int w = 0; w < NWG; w++) bulk_g2s(smem + AT_Q + w * 16384, D.qfrag + ((size_t)(u0 + w) * 8 + g) * 8192, 16384, bar + 4);
      // K(s0), K(s0 + 1), V(s0)
#pragma unroll
      for (int e = 0; e < 2; e++) {
        if (s0 + e < s1) {
          const unsigned short* Kn = page_k(D, slot, (s0 + e) * SEG, a.layer, g) + (size_t)((s0 + e) & 3) * 16384;
          mbar_expect(bar + e, 32768);
          bulk_g2s(smem + AT_K + e * 32768, Kn, 32768, bar + e);
          if (e == 0) { mbar_expect(bar + 2, 32768); bulk_g2s(smem + AT_V, Kn + (size_t)PG_U4 * 8, 32768, bar + 2); }
        }
      }
    }
    float O[68], scA[64], scB[64];          // O[64 .. 67]: Z of row A (twice) and of row B (twice)
#pragma unroll
    for (int i = 0; i < 64; i++) { O[i] = 0.f; scA[i] = 0.f; scB[i] = 0.f; }
    O[64] = 0.f; O[65] = 0.f; O[66] = 0.f; O[67] = 0.f;
    float MA = NINF, MB = NINF;
    mbar_wait(bar + 4, phq & 1); phq++;
    mbar_wait(bar, phk0 & 1); phk0++;
    asm volatile("wgmma.fence.sync.aligned;" ::: "memory");
#pragma unroll
    for (int j = 0; j < 8; j++) WGMMA_N128_P(scA, wg_desc2(qs + j * 256, 128), wg_desc2(smem + AT_K + j * 256, 128), j ? 1 : 0);
    asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory");
    asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
    // one segment: CUR holds its scores, NXT receives those of the next one (two register sets, used in turn)
#define ATT_STEP(CUR, NXT, s) do { \
      const int b = ((s) - s0) & 1; \
      /* ---- A: scores of the next segment (of this one again after the last: a batch whose result is not used) */ \
      const bool more = (s) + 1 < s1; \
      if (more) { if (b) { mbar_wait(bar, phk0 & 1); phk0++; } else { mbar_wait(bar + 1, phk1 & 1); phk1++; } } \
      const unsigned char* Kn = smem + AT_K + (more ? b ^ 1 : b) * 32768; \
      asm volatile("wgmma.fence.sync.aligned;" ::: "memory"); \
      _Pragma("unroll") \
      for (int j = 0; j < 8; j++) WGMMA_N128_P(NXT, wg_desc2(qs + j * 256, 128), wg_desc2(Kn + j * 256, 128), j ? 1 : 0); \
      asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory"); \
      /* ---- B: the values of the previous segment are done; the copies of V(s+1) and K(s+2) may start */ \
      asm volatile("wgmma.wait_group.sync.aligned 1;" ::: "memory"); \
      __syncthreads(); \
      if (tid == 0) { \
        if ((s) + 1 < s1) { \
          const unsigned short* Kp = page_k(D, slot, ((s) + 1) * SEG, a.layer, g) + (size_t)(((s) + 1) & 3) * 16384; \
          mbar_expect(bar + 2 + (b ^ 1), 32768); \
          bulk_g2s(smem + AT_V + (b ^ 1) * AT_VBUF, Kp + (size_t)PG_U4 * 8, 32768, bar + 2 + (b ^ 1)); \
        } \
        if ((s) + 2 < s1) { \
          const unsigned short* Kp = page_k(D, slot, ((s) + 2) * SEG, a.layer, g) + (size_t)(((s) + 2) & 3) * 16384; \
          mbar_expect(bar + b, 32768); \
          bulk_g2s(smem + AT_K + b * 32768, Kp, 32768, bar + b); \
        } \
      } \
      /* ---- C: scalar work of segment s */ \
      const int limA = tA - (s) * SEG, limB = tB - (s) * SEG; \
      const int gnpt = min(8, ((gtmax - (s) * SEG) >> 4) + 1);          /* groups of 16 positions that exist in the sequence */ \
      float mA, mB; \
      const bool full = pos0 >= (s) * SEG + SEG - 1; \
      if (full) seg_max<true>(CUR, 0, 0, t, mA, mB); else seg_max<false>(CUR, limA, limB, t, mA, mB); \
      const float RA = fmaxf(MA, mA), RB = fmaxf(MB, mB); \
      const float faA = (MA == RA) ? 1.0f : (MA == NINF ? 0.0f : ex2(__fsub_rn(MA, RA))); \
      const float faB = (MB == RB) ? 1.0f : (MB == NINF ? 0.0f : ex2(__fsub_rn(MB, RB))); \
      /* a factor of exactly 1 changes nothing: skip the multiplies when no row of the warp has a new maximum */ \
      if (__any_sync(0xffffffffu, MA != RA || MB != RB)) { \
        _Pragma("unroll") \
        for (int i = 0; i < 68; i++) O[i] = __fmul_rn(O[i], (i & 2) ? faB : faA); \
      } \
      MA = RA; MB = RB; \
      uint4 pa[8]; \
      if (full) { \
        _Pragma("unroll") \
        for (int jv = 0; jv < 8; jv++) pa[jv] = seg_weights<true>(CUR, jv, 0, 0, t, RA, RB); \
      } else { \
        _Pragma("unroll") \
        for (int jv = 0; jv < 8; jv++) pa[jv] = seg_weights<false>(CUR, jv, limA, limB, t, RA, RB); \
      } \
      /* ---- D: values: O += W V over the 16 dim groups, and against the group of ones behind them: Z += W 1 */ \
      if (b) { mbar_wait(bar + 3, phv1 & 1); phv1++; } else { mbar_wait(bar + 2, phv0 & 1); phv0++; } \
      const unsigned char* Vs = smem + AT_V + b * AT_VBUF; \
      asm volatile("wgmma.fence.sync.aligned;" ::: "memory"); \
      _Pragma("unroll") \
      for (int jv = 0; jv < 8; jv++) WGMMA_RS_N136(O, pa[jv], wg_desc2(Vs + min(jv, gnpt - 1) * 256, 128)); \
      asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory"); \
      /* ---- E: the scores of the next segment are done */ \
      asm volatile("wgmma.wait_group.sync.aligned 1;" ::: "memory"); \
    } while (0)
    for (int s = s0; s < s1; s += 2) {
      ATT_STEP(scA, scB, s);
      if (s + 1 < s1) ATT_STEP(scB, scA, s + 1);
    }
#undef ATT_STEP
    asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
    if (pbase < 0) att_out(D, O, O[64], O[66], col0, nq, g, t2, lane);
    else {
      float4* P = D.att_part + ((size_t)(pbase + ss) * 8 + g) * (17 * 128) + (tid & 127);
#pragma unroll
      for (int i = 0; i < 16; i++) P[i * 128] = make_float4(O[4 * i], O[4 * i + 1], O[4 * i + 2], O[4 * i + 3]);
      P[16 * 128] = make_float4(MA, MB, O[64], O[66]);
    }
  }
}

// ---- fold of the super-segments of a unit, in order: 128 threads per (unit, kv head)
struct FoldArgs { Dev d; int n_fold; int pos_add; };
__global__ void __launch_bounds__(A_THREADS, 1) k_attn_fold(FoldArgs a) {
  const Dev& D = a.d;
  const int tid = threadIdx.x, lane = tid & 31, wg = tid >> 7, t2 = (tid >> 5) & 3;
  const int total = HV(a.n_fold, D.plan) * 8, padd = PV(a.pos_add, D);
  for (int task = blockIdx.x * 2 + wg; task < total; task += gridDim.x * 2) {
    const int unit = D.plan[PL_FOLD + (task >> 3)], g = task & 7;
    const int col0 = D.plan[PL_UNIT + 4 * unit], nq = D.plan[PL_UNIT + 4 * unit + 1], pbase = D.plan[PL_UNIT + 4 * unit + 2];
    const int nss = ((D.plan[PL_POS + col0] + padd + nq - 1) >> SS_SHIFT) + 1;
    float O[64];
#pragma unroll
    for (int i = 0; i < 64; i++) O[i] = 0.f;
    float MA = NINF, MB = NINF, ZA = 0.f, ZB = 0.f;
    for (int ss = 0; ss < nss; ss++) {
      const float4* P = D.att_part + ((size_t)(pbase + ss) * 8 + g) * (17 * 128) + (tid & 127);
      float4 v[17];
#pragma unroll
      for (int i = 0; i < 17; i++) v[i] = __ldcg(P + i * 128);
      float faA, fbA, faB, fbB, Mn;
      fold_factors(MA, v[16].x, Mn, faA, fbA); MA = Mn; ZA = __fmaf_rn(ZA, faA, __fmul_rn(v[16].z, fbA));
      fold_factors(MB, v[16].y, Mn, faB, fbB); MB = Mn; ZB = __fmaf_rn(ZB, faB, __fmul_rn(v[16].w, fbB));
#pragma unroll
      for (int i = 0; i < 16; i++) {
        O[4 * i + 0] = __fmaf_rn(O[4 * i + 0], faA, __fmul_rn(v[i].x, fbA));
        O[4 * i + 1] = __fmaf_rn(O[4 * i + 1], faA, __fmul_rn(v[i].y, fbA));
        O[4 * i + 2] = __fmaf_rn(O[4 * i + 2], faB, __fmul_rn(v[i].z, fbB));
        O[4 * i + 3] = __fmaf_rn(O[4 * i + 3], faB, __fmul_rn(v[i].w, fbB));
      }
    }
    att_out(D, O, ZA, ZB, col0, nq, g, t2, lane);
  }
}

// ---------------------------------------------------------------------------------------------------------
// lm_head helpers: gather the selected columns' final-norm input; reduce the per-warp maxima to a token
// ---------------------------------------------------------------------------------------------------------
struct SelArgs { Dev d; int n_sel; long long* out64; int out_stride; int out_step; };
__global__ void __launch_bounds__(256) k_gather(SelArgs a) {
  const Dev& D = a.d;
  const int n_sel = HV(a.n_sel, D.plan);
  for (int j = blockIdx.x; j < n_sel; j += gridDim.x) {
    const int col = D.plan[PL_SEL + 2 * j];
    for (int i = threadIdx.x; i < H / 8; i += 256)   // 16 bytes = 8 consecutive K elements of the column
      ((uint4*)D.lmfrag)[xidx(8 * i, j, NG_LM) >> 3] = __ldcg((const uint4*)D.xfrag + (xidx(8 * i, col, NG_X) >> 3));
    if (threadIdx.x == 0) D.lm_rn[j] = __ldcg(D.rn + col);
  }
}
__global__ void __launch_bounds__(256) k_argmax(SelArgs a) {
  const Dev& D = a.d;
  __shared__ float sv[8]; __shared__ int si[8];
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  // the LM head's blocks have 64 rows up to 64 columns and 128 rows beyond (gemm_shape(): the vocabulary is not a multiple of 192)
  const int n_sel = HV(a.n_sel, D.plan), ncand = n_sel <= 64 ? VOCAB / 16 : VOCAB / 32;
  for (int j = blockIdx.x; j < n_sel; j += gridDim.x) {
    float bv = NINF; int bi = 0x7fffffff;
    for (int i = threadIdx.x; i < ncand; i += 256) {
      float v = __ldcg(D.bm_val + (size_t)i * n_sel + j); int ix = __ldcg(D.bm_idx + (size_t)i * n_sel + j);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
#pragma unroll
    for (int o = 16; o > 0; o >>= 1) {
      float v = __shfl_xor_sync(0xffffffffu, bv, o); int ix = __shfl_xor_sync(0xffffffffu, bi, o);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
    if (lane == 0) { sv[w] = bv; si[w] = bi; }
    __syncthreads();
    if (threadIdx.x == 0) {
      for (int i = 1; i < 8; i++) if (sv[i] > bv || (sv[i] == bv && si[i] < bi)) { bv = sv[i]; bi = si[i]; }
      D.sel_tok[j] = bi;
      const int slot = D.plan[PL_SEL + 2 * j + 1];
      if (slot >= 0) D.last_tok[slot] = bi;
      if (a.out64) a.out64[(size_t)j * a.out_stride + (a.out_step >= 0 ? a.out_step : __ldcg(D.cell + 1))] = bi;
    }
    __syncthreads();
  }
}

// ---------------------------------------------------------------------------------------------------------
// The scheduler kernel: one block at every pass boundary. All threads hash the pages of the prompts that arrived
// since the last pass; then one thread runs ds_step (dsched.h): requests leave and enter slots, pages are taken,
// adopted from the prefix cache, registered, evicted; the plan of the pass and the result header are written.
// The host does not see any of it: it copied prompts into the arena and will copy the result block out.
// ---------------------------------------------------------------------------------------------------------
#define NRES 256                         // result blocks kept on the device (the host has to read them before they wrap)
struct DsCtl { int tail; float now; float speed; int harvested; };   // written by the host (other stream): requests so far, its clock, cost-model correction, result blocks read
struct DsStatus { int done; int pad[3]; };                     // written by the device: steps finished
struct SchedArgs { DsState* S; const DsReqHost* rh; int* plan; DsResult* res; const int* arena; const DsCtl* ctl; int cmd; };
__global__ void __launch_bounds__(256) k_sched(SchedArgs a) {
  const int seen = a.S->seen, tail = __ldcg(&a.ctl->tail);   // the host writes it while kernels run: never from L1
  for (int q = seen; q < tail; q++) {
    const int ri = q % DS_RING;
    const int np = a.rh[ri].n_in / DS_PAGE;
    for (int k = threadIdx.x; k < np; k += blockDim.x) a.S->req[ri].chain[k] = ds_hash_page(a.arena + a.rh[ri].prompt_off + k * DS_PAGE);
  }
  __syncthreads();
  for (int q = seen + threadIdx.x; q < tail; q += blockDim.x) ds_chain(a.S->req[q % DS_RING].chain, a.rh[q % DS_RING].n_in / DS_PAGE);
  __syncthreads();
  if (threadIdx.x == 0) {
    const float sp = __ldcg(&a.ctl->speed);
    if (sp > 0.f) a.S->P.speed = sp;
    ds_step(*a.S, a.rh, a.plan, a.res[a.S->cnt[DS_C_STEPS] % NRES], (double)__ldcg(&a.ctl->now), tail, a.cmd);
  }
}
// End of a pass: its tokens go into its result block, the step is published, and the loop on the device continues
// while a request is waiting, running or arriving.
struct CommitArgs { const DsState* S; DsResult* res; const int* tok; DsStatus* status; const DsCtl* ctl; cudaGraphConditionalHandle handle; int in_graph; };
__global__ void k_commit(CommitArgs a) {
  const int step = (int)a.S->cnt[DS_C_STEPS] - 1;
  DsResult& R = a.res[step % NRES];
  for (int j = threadIdx.x; j < R.n_sel; j += blockDim.x) R.tok[j] = __ldcg(a.tok + j);
  __syncthreads();
  if (threadIdx.x == 0) {
    __threadfence();
    a.status->done = step + 1;
    // the loop goes on while there is work, and stops (the host restarts it) if the host has not read the result
    // blocks for so long that they would be overwritten
    const bool work = R.n_running > 0 || R.n_queued > 0 || __ldcg(&a.ctl->tail) > a.S->seen;
    const bool room = step + 1 - __ldcg(&a.ctl->harvested) < NRES - 8;
    if (a.in_graph) cudaGraphSetConditional(a.handle, work && room ? 1 : 0);
  }
}
// tests: NaN into every page the scheduler returned to the free list in this step
__global__ void k_poison_freed(const DsState* S, uint4* kv) {
  const int n = S->n_freed;
  for (int i = blockIdx.x; i < n; i += gridDim.x) {
    unsigned short* p = (unsigned short*)((char*)kv + PAGE_BYTES * (size_t)S->freed[i]);
    for (size_t j = threadIdx.x; j < PAGE_BYTES / 2; j += blockDim.x) p[j] = 0x7fc0;
  }
}

// generate() on the device: the first input tokens become the slots' "last generated token"; after every pass the
// position and the step advance and the loop goes on until the last step
__global__ void k_settok(int* last_tok, const long long* tok64, int B) {
  if (threadIdx.x < B) last_tok[threadIdx.x] = (int)tok64[threadIdx.x];
}
// the cells of a generate() / step() launch; the values travel with the launch (the host may queue many launches
// before the first one runs)
__global__ void k_setcell(int* cell, int pos, int step, int end) {
  if (threadIdx.x == 0) { cell[0] = pos; cell[1] = step; cell[2] = end; }
}
__global__ void k_gen_commit(int* cell, cudaGraphConditionalHandle handle) {
  if (threadIdx.x == 0) {
    cell[0] += 1;
    const int step = cell[1] + 1;
    cell[1] = step;
    cudaGraphSetConditional(handle, step < cell[2] ? 1 : 0);
  }
}

// test helper: fill a page with NaN (bf16 0x7fc0)
__global__ void k_fill16(unsigned short* p, size_t n, unsigned short v) {
  for (size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x; i < n; i += (size_t)gridDim.x * blockDim.x) p[i] = v;
}

// ---------------------------------------------------------------------------------------------------------
// host API
// ---------------------------------------------------------------------------------------------------------
#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "CUDA error %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); abort(); } } while (0)

#ifndef ARENA_TOK
#define ARENA_TOK (16 << 20)             // prompt arena, tokens
#endif
struct Eng {
  Dev D;
  int nsm, n_pages;
  int* plan_dev;
  long long passes, launches, plan_uploads, tok_reads;
  int force_shape;
  // device scheduler
  DsState* S; DsReqHost* rh; DsResult* res; int* arena; DsCtl* ctl; DsStatus* status; int* tok_cur;     // device
  DsReqHost* rh_host; DsResult* res_host; int* arena_host; DsCtl* ctl_host; DsStatus* status_host;      // pinned host mirrors
  cudaStream_t sA, sB;                   // sA: the serving loop; sB: the host's copies (prompts in, results out)
  cudaGraph_t graph; cudaGraphExec_t exec; cudaGraphConditionalHandle hwhile;
  long long tail, arena_pos, harvested, graph_launches, host_launched, sched_only;
  int poison, use_graph;
  // generate(): the loop over the steps as a graph (rebuilt when batch or plan counts change)
  cudaGraph_t ggraph; cudaGraphExec_t gexec; cudaGraphConditionalHandle ghandle; int gkey[4]; long long* gen_buf; long long gen_launches;
  // step(): one pass as a graph; the token pointer of its embedding node and the logits pointer of its LM-head node
  // are set per call
  cudaGraph_t sgraph; cudaGraphExec_t sexec; int skey[4]; long long step_launches;
  cudaGraphNode_t s_embed, s_lm; cudaKernelNodeParams s_embed_kp, s_lm_kp; EmbedArgs s_ea; GemmArgs s_lmg;
  cudaGraphNode_t c_embed, c_lm; cudaKernelNodeParams c_embed_kp, c_lm_kp; EmbedArgs c_ea; GemmArgs c_lmg;   // of the graph built last
  // launching: directly, or as nodes of the graph being built
  cudaGraph_t gb; cudaGraphNode_t glast; int ghave; cudaStream_t cur;
  cudaKernelNodeParams last_kp; GemmArgs last_gemm;     // of the node added last / the GEMM launched last
};
// one kernel of a pass: launched on the current stream, or appended to the graph under construction
template <class A>
static void emit(Eng* E, void (*fn)(A), int grid, int block, size_t smem, A args) {
  if (!E->gb) { fn<<<grid, block, smem, E->cur>>>(args); return; }
  cudaKernelNodeParams kp = {};
  void* argv[1] = {&args};
  kp.func = (void*)fn; kp.gridDim = dim3(grid); kp.blockDim = dim3(block); kp.sharedMemBytes = (unsigned)smem; kp.kernelParams = argv;
  cudaGraphNode_t n;
  CK(cudaGraphAddKernelNode(&n, E->gb, E->ghave ? &E->glast : nullptr, E->ghave ? 1 : 0, &kp));
  E->glast = n; E->ghave = 1; E->last_kp = kp;
}

static int g_split = 1;
template <int EP, int NB, int NT>
static void emit1(Eng* E, int grid, const GemmArgs& g) {
  static bool attr = false;
  if (!attr) { CK(cudaFuncSetAttribute(k_gemm1<EP, NB, NT>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(NB, NT))); attr = true; }
  emit<GemmArgs>(E, k_gemm1<EP, NB, NT>, grid, WG_THREADS, WG_SMEM(NB, NT), g);
}
// One GEMM. Launched by the host for a known number of columns: the shape is chosen here and the grid is no larger
// than the number of units. In the serving loop on the device the kernel reads the number of columns from the plan
// and chooses the shape itself.
template <int EP>
static void launch_gemm(Eng* E, GemmArgs g, bool dev = false) {
  int grid = E->nsm;
  g.shape = -1;
  if (!dev) {
    int nb, nt; float us;
    g.shape = gemm_shape(g.M, g.T, E->nsm);
    shape_dims(g.shape, nb, nt, us);
    const int n_units = (g.M / (64 * nt)) * ((g.T + 2 * nb - 1) / (2 * nb));
    if (n_units < grid) grid = n_units;
  }
  // up to 64 columns (step(), generate()) the kernel with just that shape: the general one costs 0.8 us more per
  // launch (5.81 against 5.69 ms for the GEMMs of a decode step)
  if (!dev && g_split && g.shape == 0) emit1<EP, 16, 1>(E, grid, g);
  else if (!dev && g_split && g.shape == 7) emit1<EP, 8, 1>(E, grid, g);
  else if (!dev && g_split && g.shape == 1) emit1<EP, 32, 1>(E, grid, g);
  else emit<GemmArgs>(E, k_gemm<EP>, grid, WG_THREADS, WG_SMEM_MAX, g);
  E->last_gemm = g;
  E->launches++;
}
template <int EP>
static void gemm_attr() {
  CK(cudaFuncSetAttribute(k_gemm<EP>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM_MAX));
}

extern "C" {

void* eng_create(int n_pages, const void* W, const void* embed, const void* norm_w, const void* qk_norm_w, const void* rope) {
  if (getenv("MK_GEMM_SPLIT")) g_split = atoi(getenv("MK_GEMM_SPLIT"));
  Eng* E = new Eng();
  memset(E, 0, sizeof(Eng));
  int dev = 0; CK(cudaGetDevice(&dev));
  cudaDeviceProp prop; CK(cudaGetDeviceProperties(&prop, dev));
  E->nsm = prop.multiProcessorCount;
  E->n_pages = n_pages;
  E->force_shape = getenv("MK_GEMM_NB") ? atoi(getenv("MK_GEMM_NB")) : -1;
  Dev& D = E->D;
  D.W = (const unsigned short*)W; D.embed = (const unsigned short*)embed; D.norm_w = (const float*)norm_w;
  D.qk_norm_w = (const float*)qk_norm_w; D.rope = (const float*)rope;
  CK(cudaMalloc(&D.kv, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMalloc(&E->plan_dev, sizeof(int) * PL_INTS)); D.plan = E->plan_dev;
  CK(cudaMalloc(&D.x, sizeof(float) * (size_t)TCAP * H));
  CK(cudaMalloc(&D.xfrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.ssq, sizeof(float) * (size_t)TCAP * 256));
  CK(cudaMalloc(&D.rn, sizeof(float) * TCAP));
  CK(cudaMalloc(&D.qkv, sizeof(float) * (size_t)TCAP * QKV_ROWS));
  CK(cudaMalloc(&D.qfrag, (size_t)MAXU * 8 * 16384));
  CK(cudaMalloc(&D.afrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.mfrag, (size_t)TCAP * INNER * 2));
  CK(cudaMalloc(&D.lmfrag, (size_t)SELCAP * H * 2));
  CK(cudaMalloc(&D.lm_rn, sizeof(float) * SELCAP));
  CK(cudaMalloc(&D.bm_val, sizeof(float) * (size_t)(VOCAB / 16) * SELCAP));
  CK(cudaMalloc(&D.bm_idx, sizeof(int) * (size_t)(VOCAB / 16) * SELCAP));
  CK(cudaMalloc(&D.last_tok, sizeof(int) * NSLOT));
  CK(cudaMalloc(&D.sel_tok, sizeof(int) * SELCAP));
  CK(cudaMalloc(&D.att_part, sizeof(float4) * (size_t)PARTCAP * 8 * 17 * 128));
  CK(cudaMalloc(&D.cell, sizeof(int) * 4));
  CK(cudaMemset(D.cell, 0, sizeof(int) * 4));
  CK(cudaMalloc(&D.ctr, sizeof(int) * NL * 2));
  CK(cudaMemset(D.ctr, 0, sizeof(int) * NL * 2));
  CK(cudaMemset(D.kv, 0, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMemset(D.xfrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.qfrag, 0, (size_t)MAXU * 8 * 16384));
  CK(cudaMemset(D.afrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.mfrag, 0, (size_t)TCAP * INNER * 2));
  CK(cudaMemset(D.lmfrag, 0, (size_t)SELCAP * H * 2));
  CK(cudaMemset(D.last_tok, 0, sizeof(int) * NSLOT));
  CK(cudaMemset(E->plan_dev, 0, sizeof(int) * PL_INTS));
  gemm_attr<EP_QKV>(); gemm_attr<EP_ADD>(); gemm_attr<EP_GU>(); gemm_attr<EP_LM>(); gemm_attr<EP_LMARG>(); gemm_attr<EP_RAW>();
  CK(cudaFuncSetAttribute(k_attn<1>, cudaFuncAttributeMaxDynamicSharedMemorySize, AT_SMEM(1)));
  CK(cudaFuncSetAttribute(k_attn<2>, cudaFuncAttributeMaxDynamicSharedMemorySize, AT_SMEM(2)));
  return E;
}

int eng_plan_ints() { return PL_INTS; }
int eng_tcap() { return TCAP; }
// plan layout for the host: 0 PL_UNIT, 1 (unused), 2 PL_BT, 3 PL_FOLD, 4 PL_SEL, 5 PL_PT, 6 MAXU, 7 (unused), 8 MAXBT, 9 PARTCAP, 10 PL_CU, 11 SS_SHIFT
int eng_const(int i) { static const int c[12] = {PL_UNIT, 0, PL_BT, PL_FOLD, PL_SEL, PL_PT, MAXU, 0, MAXBT, PARTCAP, PL_CU, SS_SHIFT}; return c[i]; }
// bytes of device memory the engine allocates besides the KV pages
size_t eng_fixed_bytes() { return sizeof(float4) * (size_t)PARTCAP * 8 * 17 * 128 + (size_t)TCAP * (H * 4 + H * 2 * 2 + INNER * 2 + QKV_ROWS * 4 + 256 * 4) + (size_t)MAXU * 8 * 16384 + (size_t)(VOCAB / 16) * SELCAP * 8; }
int eng_selcap() { return SELCAP; }
size_t eng_page_bytes() { return PAGE_BYTES; }

// copy the plan (host ints, layout PL_*) to the device. `n` leading ints are copied.
void eng_set_plan(void* h, const int* plan, int off, int n) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->plan_dev + off, plan + off, sizeof(int) * (size_t)n, cudaMemcpyHostToDevice));
  E->plan_uploads++;
}

// One pass over the weights for the T columns of the current plan.
//   pos_add: added to every column's position (step()/generate() reuse one plan)
//   tok64:   device int64 [T] input tokens, or null (tokens from the plan / the slots' last tokens)
//   logits:  device float [n_sel][VOCAB] or null (then only the argmax: sel_tok, last_tok, out64)
// The kernels of one pass. dev = false: the host knows the counts (offline contract, tests). dev = true: the plan
// was written by the scheduler kernel just before; the kernels read their counts from its header and are launched
// with full grids (blocks without work return at once).
static void launch_pass(Eng* E, bool dev, int T, int n_bt2, int n_bt1, int n_fold, int n_sel, int pos_add, const void* tok64, void* logits,
                        void* out64, int out_stride, int out_step, int* sel_tok) {
  Dev D = E->D;
  if (sel_tok) D.sel_tok = sel_tok;
  const int nsm = E->nsm;
  const int cT = dev ? -1 : T;
  EmbedArgs ea{D, cT, pos_add, (const long long*)tok64, dev ? E->arena : nullptr};
  emit<EmbedArgs>(E, k_embed, dev ? 4 * nsm : (T < 4 * nsm ? T : 4 * nsm), 256, 0, ea);
  if (E->gb) { E->c_embed = E->glast; E->c_embed_kp = E->last_kp; E->c_ea = ea; }
  RnArgs ra{D.ssq, D.rn, cT, D.plan};
  const int rn_grid = dev ? nsm : ((T + 7) / 8 < nsm ? (T + 7) / 8 : nsm);
  for (int l = 0; l < NL; l++) {
    const unsigned short* WL = D.W + (size_t)l * LAYER_U4 * 8;
    emit<RnArgs>(E, k_rnorm, rn_grid, 256, 0, ra);
    GemmArgs g{};
    g.W = WL + OFF_QKV * 8; g.X = D.xfrag; g.NG = NG_X; g.M = QKV_ROWS; g.K = H; g.T = cT; g.plan = D.plan; g.rn = D.rn; g.out = D.qkv;
    launch_gemm<EP_QKV>(E, g, dev);
    PrepArgs pa{D, cT, l, pos_add};
    const int pgrid = dev ? PREP_BLOCKS * nsm : ((T * 48 + 15) / 16 < PREP_BLOCKS * nsm ? (T * 48 + 15) / 16 : PREP_BLOCKS * nsm);
    emit<PrepArgs>(E, k_prep, pgrid, 512, 0, pa);
    if (dev || n_bt2 > 0) {   // tasks of two units: tasks 0 .. n_bt2 - 1 of the plan
      AttArgs aa{D, 0, dev ? -2 : n_bt2, l, pos_add, D.ctr + 2 * l};
      emit<AttArgs>(E, k_attn<2>, dev ? nsm : (n_bt2 < nsm ? n_bt2 : nsm), 256, AT_SMEM(2), aa);
    }
    if (dev || n_bt1 > 0) {   // tasks of one unit (decode rows, odd ends of runs): after them
      AttArgs aa{D, dev ? -2 : n_bt2, dev ? -3 : n_bt1, l, pos_add, D.ctr + 2 * l + 1};
      emit<AttArgs>(E, k_attn<1>, dev ? nsm : (n_bt1 < nsm ? n_bt1 : nsm), 128, AT_SMEM(1), aa);
    }
    if (dev || n_fold > 0) {
      FoldArgs fa{D, dev ? -4 : n_fold, pos_add};
      emit<FoldArgs>(E, k_attn_fold, dev ? nsm : (n_fold * 4 < nsm ? n_fold * 4 : nsm), A_THREADS, 0, fa);
    }
    g = GemmArgs{};
    g.W = WL + OFF_O * 8; g.X = D.afrag; g.NG = NG_X; g.M = H; g.K = H; g.T = cT; g.plan = D.plan;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 1) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g, dev);
    emit<RnArgs>(E, k_rnorm, rn_grid, 256, 0, ra);
    g = GemmArgs{};
    g.W = WL + OFF_GU * 8; g.X = D.xfrag; g.NG = NG_X; g.M = 2 * INNER; g.K = H; g.T = cT; g.plan = D.plan; g.rn = D.rn; g.frag = D.mfrag;
    launch_gemm<EP_GU>(E, g, dev);
    g = GemmArgs{};
    g.W = WL + OFF_DN * 8; g.X = D.mfrag; g.NG = NG_X; g.M = H; g.K = INNER; g.T = cT; g.plan = D.plan;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 2) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g, dev);
    E->launches += 5;
  }
  if (dev || n_sel > 0) {
    emit<RnArgs>(E, k_rnorm, rn_grid, 256, 0, ra);
    SelArgs sa{D, dev ? -5 : n_sel, (long long*)out64, out_stride, out_step};
    emit<SelArgs>(E, k_gather, dev ? 64 : n_sel, 256, 0, sa);
    GemmArgs g{};
    g.W = D.W + (size_t)NL * LAYER_U4 * 8; g.X = D.lmfrag; g.NG = NG_LM; g.M = VOCAB; g.K = H; g.T = dev ? -5 : n_sel; g.plan = D.plan; g.rn = D.lm_rn;
    if (logits) {
      g.out = (float*)logits; launch_gemm<EP_LM>(E, g, dev);
      if (E->gb) { E->c_lm = E->glast; E->c_lm_kp = E->last_kp; E->c_lmg = E->last_gemm; }
    }
    else {
      g.bm_val = D.bm_val; g.bm_idx = D.bm_idx;
      launch_gemm<EP_LMARG>(E, g, dev);
      emit<SelArgs>(E, k_argmax, dev ? 64 : n_sel, 256, 0, sa);
    }
    E->launches += 3;
  }
  E->launches += 1;
  E->passes++;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) fprintf(stderr, "launch_pass: launch error: %s\n", cudaGetErrorString(e));
}

// One pass over the weights for the T columns of the current (host-written) plan.
//   pos_add: added to every column's position (step()/generate() reuse one plan)
//   tok64:   device int64 [T] input tokens, or null (tokens from the plan / the slots' last tokens)
//   logits:  device float [n_sel][VOCAB] or null (then only the argmax: sel_tok, last_tok, out64)
void eng_pass(void* h, int T, int n_bt2, int n_bt1, int n_fold, int n_sel, int pos_add, const void* tok64, void* logits, void* out64, int out_stride, int out_step) {
  Eng* E = (Eng*)h;
  E->gb = nullptr; E->cur = 0;
  launch_pass(E, false, T, n_bt2, n_bt1, n_fold, n_sel, pos_add, tok64, logits, out64, out_stride, out_step, nullptr);
}

// step(): one pass for the B rows at position `pos` as ONE graph launch (190 kernel nodes) instead of 190 launches.
// The graph is built per (B, plan counts); per call the host writes the position cell and points the embedding
// node at the caller's tokens and the LM-head node at the caller's logits.
void eng_step(void* h, int B, int n_bt2, int n_bt1, int n_fold, int pos, const void* tok64, void* logits) {
  Eng* E = (Eng*)h;
  Dev& D = E->D;
  const int key[4] = {B, n_bt2, n_bt1, n_fold};
  if (!E->sexec || memcmp(key, E->skey, sizeof(key))) {
    if (E->sexec) { CK(cudaDeviceSynchronize()); CK(cudaGraphExecDestroy(E->sexec)); CK(cudaGraphDestroy(E->sgraph)); }
    CK(cudaGraphCreate(&E->sgraph, 0));
    E->gb = E->sgraph; E->ghave = 0;
    launch_pass(E, false, B, n_bt2, n_bt1, n_fold, B, -1, tok64, logits, nullptr, 0, 0, nullptr);
    E->gb = nullptr;
    E->s_embed = E->c_embed; E->s_embed_kp = E->c_embed_kp; E->s_ea = E->c_ea;
    E->s_lm = E->c_lm; E->s_lm_kp = E->c_lm_kp; E->s_lmg = E->c_lmg;
    CK(cudaGraphInstantiate(&E->sexec, E->sgraph, 0));
    memcpy(E->skey, key, sizeof(key));
  } else {
    void* argv[1];
    cudaKernelNodeParams kp = E->s_embed_kp;
    E->s_ea.tok64 = (const long long*)tok64; argv[0] = &E->s_ea; kp.kernelParams = argv;
    CK(cudaGraphExecKernelNodeSetParams(E->sexec, E->s_embed, &kp));
    kp = E->s_lm_kp;
    E->s_lmg.out = (float*)logits; argv[0] = &E->s_lmg; kp.kernelParams = argv;
    CK(cudaGraphExecKernelNodeSetParams(E->sexec, E->s_lm, &kp));
    E->passes++;
  }
  k_setcell<<<1, 32>>>(D.cell, pos, 0, 0);
  CK(cudaGraphLaunch(E->sexec, 0));
  E->step_launches++;
}

// generate(): `nrun` greedy steps from step `step0` of `n_total` at position `pos`, with the current (host-written)
// plan of B decode rows, as ONE graph launch: WHILE (step < end) { pass; position and step advance }. Argmax, token
// feedback and the loop are on the device; the host launches once per stretch of steps with the same plan (the
// plan changes when the rows enter a new super-segment of 4096 positions) and does not wait.
#define GEN_STRIDE 34816
void eng_generate(void* h, int B, int n_bt2, int n_bt1, int n_fold, int pos, const void* tok64, void* out64, int n_total, int step0, int nrun) {
  Eng* E = (Eng*)h;
  Dev& D = E->D;
  if (!E->gen_buf) CK(cudaMalloc(&E->gen_buf, sizeof(long long) * (size_t)NSLOT * GEN_STRIDE));
  const int key[4] = {B, n_bt2, n_bt1, n_fold};
  if (!E->gexec || memcmp(key, E->gkey, sizeof(key))) {
    if (E->gexec) { CK(cudaDeviceSynchronize()); CK(cudaGraphExecDestroy(E->gexec)); CK(cudaGraphDestroy(E->ggraph)); }
    CK(cudaGraphCreate(&E->ggraph, 0));
    CK(cudaGraphConditionalHandleCreate(&E->ghandle, E->ggraph, 1, cudaGraphCondAssignDefault));
    cudaGraphNodeParams wp = {};
    wp.type = cudaGraphNodeTypeConditional;
    wp.conditional.handle = E->ghandle; wp.conditional.type = cudaGraphCondTypeWhile; wp.conditional.size = 1;
    cudaGraphNode_t wnode;
    CK(cudaGraphAddNode(&wnode, E->ggraph, nullptr, nullptr, 0, &wp));
    E->gb = wp.conditional.phGraph_out[0]; E->ghave = 0;
    launch_pass(E, false, B, n_bt2, n_bt1, n_fold, B, -1, nullptr, nullptr, E->gen_buf, GEN_STRIDE, -1, nullptr);
    cudaKernelNodeParams kp = {};
    void* argv[2] = {&D.cell, &E->ghandle};
    kp.func = (void*)k_gen_commit; kp.gridDim = dim3(1); kp.blockDim = dim3(32); kp.kernelParams = argv;
    cudaGraphNode_t n; CK(cudaGraphAddKernelNode(&n, E->gb, &E->glast, 1, &kp));
    E->gb = nullptr;
    CK(cudaGraphInstantiate(&E->gexec, E->ggraph, 0));
    memcpy(E->gkey, key, sizeof(key));
  }
  k_setcell<<<1, 32>>>(D.cell, pos, step0, step0 + nrun);
  if (step0 == 0) k_settok<<<1, 64>>>(D.last_tok, (const long long*)tok64, B);
  CK(cudaGraphLaunch(E->gexec, 0));
  if (step0 + nrun == n_total)
    for (int b = 0; b < B; b++)
      CK(cudaMemcpyAsync((long long*)out64 + (size_t)b * n_total, E->gen_buf + (size_t)b * GEN_STRIDE, sizeof(long long) * (size_t)n_total, cudaMemcpyDeviceToDevice, 0));
  E->gen_launches++;
  E->passes += nrun;
}

// ---------------------------------------------------------------------------------------------------------
// online path with the scheduler on the device
// ---------------------------------------------------------------------------------------------------------
int eng_ds_param_bytes() { return (int)sizeof(DsParams); }
int eng_ds_result_bytes() { return (int)sizeof(DsResult); }
int eng_ds_ring() { return DS_RING; }
// the step and the pass it plans (and, tests, the poison of freed pages), ending with the commit of the results
static void launch_step(Eng* E, int cmd, bool with_pass, bool in_graph) {
  SchedArgs sa{E->S, E->rh, E->plan_dev, E->res, E->arena, E->ctl, cmd};
  emit<SchedArgs>(E, k_sched, 1, 256, 0, sa);
  if (E->poison) {
    if (E->gb) {
      cudaKernelNodeParams kp = {};
      void* argv[2] = {&E->S, &E->D.kv};
      kp.func = (void*)k_poison_freed; kp.gridDim = dim3(64); kp.blockDim = dim3(256); kp.kernelParams = argv;
      cudaGraphNode_t n; CK(cudaGraphAddKernelNode(&n, E->gb, &E->glast, 1, &kp)); E->glast = n;
    } else k_poison_freed<<<64, 256, 0, E->cur>>>(E->S, E->D.kv);
  }
  if (with_pass) launch_pass(E, true, 0, 0, 0, 0, 0, 0, nullptr, nullptr, nullptr, 0, 0, E->tok_cur);
  CommitArgs ca{E->S, E->res, E->tok_cur, E->status, E->ctl, E->hwhile, in_graph ? 1 : 0};
  emit<CommitArgs>(E, k_commit, 1, 256, 0, ca);
}
void eng_ds_init(void* h, const DsParams* P, int poison, int use_graph) {
  Eng* E = (Eng*)h;
  if (!E->S) {
    CK(cudaMalloc(&E->S, sizeof(DsState)));
    CK(cudaMalloc(&E->rh, sizeof(DsReqHost) * DS_RING));
    CK(cudaMalloc(&E->res, sizeof(DsResult) * NRES));
    CK(cudaMalloc(&E->arena, sizeof(int) * (size_t)ARENA_TOK));
    CK(cudaMalloc(&E->ctl, sizeof(DsCtl)));
    CK(cudaMalloc(&E->status, sizeof(DsStatus)));
    CK(cudaMalloc(&E->tok_cur, sizeof(int) * SELCAP));
    CK(cudaHostAlloc(&E->rh_host, sizeof(DsReqHost) * DS_RING, cudaHostAllocDefault));
    CK(cudaHostAlloc(&E->res_host, sizeof(DsResult) * NRES, cudaHostAllocDefault));
    CK(cudaHostAlloc(&E->arena_host, sizeof(int) * (size_t)ARENA_TOK, cudaHostAllocDefault));
    CK(cudaHostAlloc(&E->ctl_host, sizeof(DsCtl), cudaHostAllocDefault));
    CK(cudaHostAlloc(&E->status_host, sizeof(DsStatus), cudaHostAllocDefault));
    CK(cudaStreamCreateWithFlags(&E->sA, cudaStreamNonBlocking));
    CK(cudaStreamCreateWithFlags(&E->sB, cudaStreamNonBlocking));
  }
  CK(cudaDeviceSynchronize());
  DsState* S0 = (DsState*)calloc(1, sizeof(DsState));
  ds_init(*S0, *P);
  CK(cudaMemcpy(E->S, S0, sizeof(DsState), cudaMemcpyHostToDevice));
  free(S0);
  CK(cudaMemset(E->res, 0, sizeof(DsResult) * NRES));
  CK(cudaMemset(E->ctl, 0, sizeof(DsCtl)));
  CK(cudaMemset(E->status, 0, sizeof(DsStatus)));
  memset(E->ctl_host, 0, sizeof(DsCtl));
  E->tail = 0; E->arena_pos = 0; E->harvested = 0; E->poison = poison; E->use_graph = use_graph;
  if (use_graph) {
    // The serving loop as one graph: WHILE (a request is waiting, running or arriving) { step; pass; commit }.
    // Once launched it runs on the device without the host. Conditional kernels are not IF nodes (5.7 us each,
    // tests/graph_while.cu) but plain kernels that return at once when they have no work (0.9 us).
    if (E->exec) { CK(cudaGraphExecDestroy(E->exec)); CK(cudaGraphDestroy(E->graph)); E->exec = nullptr; }
    CK(cudaGraphCreate(&E->graph, 0));
    CK(cudaGraphConditionalHandleCreate(&E->hwhile, E->graph, 1, cudaGraphCondAssignDefault));
    cudaGraphNodeParams wp = {};
    wp.type = cudaGraphNodeTypeConditional;
    wp.conditional.handle = E->hwhile; wp.conditional.type = cudaGraphCondTypeWhile; wp.conditional.size = 1;
    cudaGraphNode_t wnode;
    CK(cudaGraphAddNode(&wnode, E->graph, nullptr, nullptr, 0, &wp));
    E->gb = wp.conditional.phGraph_out[0]; E->ghave = 0;
    launch_step(E, 0, true, true);
    E->gb = nullptr;
    CK(cudaGraphInstantiate(&E->exec, E->graph, 0));
  }
}
// A request arrives: the prompt goes into the arena, its record into the ring, then the ring count is published
// (three asynchronous copies from pinned memory on the copy stream; the serving loop is not touched).
// `oldest`: ring count of the oldest request the host still waits for (its arena space and everything after it is
// in use). Returns the request's ring count, or -1 if ring or arena are full (the host retries later).
long long eng_ds_submit(void* h, const int* prompt, int n_in, int n_out, double t_arrive, long long oldest, long long oldest_off) {
  Eng* E = (Eng*)h;
  if (E->tail - oldest >= DS_RING - 1) return -1;
  // the live prompts occupy the cyclic range [oldest_off, arena_pos) of the arena
  long long off = E->arena_pos;
  if (oldest == E->tail) off = 0;                               // nothing alive
  else if (off >= oldest_off) {                                 // not wrapped: free are [off, end) and [0, oldest_off)
    if (off + n_in > ARENA_TOK) { if (n_in >= oldest_off) return -1; off = 0; }
  } else if (off + n_in >= oldest_off) return -1;               // wrapped: free is [off, oldest_off)
  memcpy(E->arena_host + off, prompt, sizeof(int) * (size_t)n_in);
  CK(cudaMemcpyAsync(E->arena + off, E->arena_host + off, sizeof(int) * (size_t)n_in, cudaMemcpyHostToDevice, E->sB));
  const int ri = (int)(E->tail % DS_RING);
  E->rh_host[ri].n_in = n_in; E->rh_host[ri].n_out = n_out; E->rh_host[ri].prompt_off = (int)off; E->rh_host[ri].t_arrive = (float)t_arrive;
  CK(cudaMemcpyAsync(E->rh + ri, E->rh_host + ri, sizeof(DsReqHost), cudaMemcpyHostToDevice, E->sB));
  E->arena_pos = off + n_in;
  E->tail++;
  CK(cudaStreamSynchronize(E->sB));   // the copies are there (waits for the copy stream only) before the count says so
  E->ctl_host->tail = (int)E->tail;
  CK(cudaMemcpyAsync(E->ctl, E->ctl_host, sizeof(DsCtl), cudaMemcpyHostToDevice, E->sB));
  return E->tail - 1;
}
long long eng_ds_arena_off(void* h, long long count) { return ((Eng*)h)->rh_host[count % DS_RING].prompt_off; }
// The host's clock and the cost-model correction, for the next step the device takes.
void eng_ds_tick(void* h, double now, double speed) {
  Eng* E = (Eng*)h;
  CK(cudaStreamSynchronize(E->sB));
  E->ctl_host->now = (float)now; E->ctl_host->speed = (float)speed; E->ctl_host->harvested = (int)E->harvested;
  CK(cudaMemcpyAsync(E->ctl, E->ctl_host, sizeof(DsCtl), cudaMemcpyHostToDevice, E->sB));
}
// Result blocks of the steps finished since the last call (at most `maxn`), copied on the copy stream.
int eng_ds_harvest(void* h, DsResult* out, int maxn) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpyAsync(E->status_host, E->status, sizeof(DsStatus), cudaMemcpyDeviceToHost, E->sB));
  CK(cudaStreamSynchronize(E->sB));
  const long long done = E->status_host->done;
  if (done - E->harvested > NRES) { fprintf(stderr, "eng_ds_harvest: %lld result blocks were overwritten before the host read them\n", done - E->harvested - NRES); abort(); }
  int n = 0;
  while (E->harvested < done && n < maxn) {
    const int slot = (int)(E->harvested % NRES);
    CK(cudaMemcpyAsync(E->res_host + slot, E->res + slot, sizeof(DsResult), cudaMemcpyDeviceToHost, E->sB));
    CK(cudaStreamSynchronize(E->sB));
    out[n++] = E->res_host[slot];
    E->harvested++;
  }
  return n;
}
// 1 if the serving loop is on the device now.
int eng_ds_running(void* h) {
  Eng* E = (Eng*)h;
  const cudaError_t e = cudaStreamQuery(E->sA);
  if (e == cudaErrorNotReady) return 1;
  CK(e);
  return 0;
}
// Start the serving loop (graph), or, without the graph, launch one step and its pass.
void eng_ds_run(void* h) {
  Eng* E = (Eng*)h;
  if (E->use_graph) { CK(cudaGraphLaunch(E->exec, E->sA)); E->graph_launches++; }
  else { E->gb = nullptr; E->cur = E->sA; launch_step(E, 0, true, false); E->cur = 0; E->host_launched++; }
}
// Off the serving path (waits for the loop to end): one scheduler step without a pass. cmd 2: bookkeeping only
// (requests whose last token is out leave their slots); cmd 1: also forget every retained prefix.
void eng_ds_step_only(void* h, int cmd) {   // the caller has made sure the loop is not running
  Eng* E = (Eng*)h;
  CK(cudaStreamSynchronize(E->sA));
  E->gb = nullptr; E->cur = E->sA;
  launch_step(E, cmd, false, false);
  E->cur = 0;
  CK(cudaStreamSynchronize(E->sA));
  E->sched_only++;
}
void eng_ds_counters(void* h, long long* out) {   // statistics: read while the loop may be running
  Eng* E = (Eng*)h;
  CK(cudaMemcpyAsync(out, (char*)E->S + offsetof(DsState, cnt), sizeof(long long) * DS_NCNT, cudaMemcpyDeviceToHost, E->sB));
  CK(cudaStreamSynchronize(E->sB));
  out[DS_NCNT - 1] = E->graph_launches; out[DS_NCNT - 2] = E->host_launched;
}

// tokens of the last pass (blocks until the pass is done: one host sync)
void eng_read_tokens(void* h, int* out, int n_sel) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(out, E->D.sel_tok, sizeof(int) * (size_t)n_sel, cudaMemcpyDeviceToHost));
  E->tok_reads++;
}

void eng_set_last_tok(void* h, int slot, int tok) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->D.last_tok + slot, &tok, sizeof(int), cudaMemcpyHostToDevice));
}

// tests: poison a page's K and V with NaN
void eng_poison_page(void* h, int page) {
  Eng* E = (Eng*)h;
  k_fill16<<<256, 256>>>((unsigned short*)((char*)E->D.kv + PAGE_BYTES * (size_t)page), PAGE_BYTES / 2, (unsigned short)0x7fc0);
}

// tests / bench: a bare matvec through the GEMM kernel. W: [M][K], X: [columns][K] with ng column groups, both in
// the operand layout (xidx); out [T][M] f32
void eng_gemm_raw(void* h, const void* W, const void* X, void* out, int M, int K, int T, int ng) {
  Eng* E = (Eng*)h;
  GemmArgs g{};
  g.W = (const unsigned short*)W; g.X = (const unsigned short*)X; g.NG = ng; g.M = M; g.K = K; g.T = T; g.out = (float*)out;
  launch_gemm<EP_RAW>(E, g);
}

// bench (tests/gemm_shapes.py): the same matvec with a given block shape; returns the shape used
int eng_gemm_shape(void* h, const void* W, const void* X, void* out, int M, int K, int T, int ng, int shape) {
  Eng* E = (Eng*)h;
  GemmArgs g{};
  g.W = (const unsigned short*)W; g.X = (const unsigned short*)X; g.NG = ng; g.M = M; g.K = K; g.T = T; g.out = (float*)out;
  int nb, nt; float us;
  if (shape < 0) shape = gemm_shape(M, T, E->nsm);
  shape_dims(shape, nb, nt, us);
  if (M % (64 * nt)) return -1;
  g.shape = shape;
  const int n_units = (M / (64 * nt)) * ((T + 2 * nb - 1) / (2 * nb)), grid = n_units < E->nsm ? n_units : E->nsm;
  emit<GemmArgs>(E, k_gemm<EP_RAW>, grid, WG_THREADS, WG_SMEM_MAX, g);
  return shape;
}

long long eng_stat(void* h, int which) {
  Eng* E = (Eng*)h;
  return which == 0 ? E->launches : which == 1 ? E->passes : which == 2 ? E->nsm : which == 3 ? E->plan_uploads : which == 4 ? E->tok_reads : which == 5 ? E->gen_launches : 0;
}

void eng_sync() { CK(cudaDeviceSynchronize()); }

void eng_destroy(void* h) {
  Eng* E = (Eng*)h;
  cudaDeviceSynchronize();
  Dev& D = E->D;
  cudaFree(D.kv); cudaFree(E->plan_dev); cudaFree(D.x); cudaFree(D.xfrag); cudaFree(D.ssq); cudaFree(D.rn); cudaFree(D.qkv);
  cudaFree(D.qfrag); cudaFree(D.afrag); cudaFree(D.mfrag); cudaFree(D.lmfrag); cudaFree(D.lm_rn); cudaFree(D.bm_val);
  cudaFree(D.bm_idx); cudaFree(D.last_tok); cudaFree(D.sel_tok); cudaFree(D.att_part); cudaFree(D.ctr);
  delete E;
}

}  // extern "C"
