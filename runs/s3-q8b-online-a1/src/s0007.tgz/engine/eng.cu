// Online engine for Qwen3-8B (bf16) on one H100: a "pass" runs T token columns (decode rows and prefill chunks
// together) once over the weights. Every column's arithmetic is independent of the other columns of the pass,
// of where a prefill is cut into chunks and of whether its prefix K/V came from a cache.
//
// Canonical arithmetic (what makes batching / chunking / prefix reuse invisible):
//  * matvec: y[row] = one f32 accumulator per (row, column), 16 input dims per tensor-core instruction
//    (wgmma m64nNk16, bf16 x bf16 -> f32), dims ascending. Inputs are bf16.
//  * attention of a query at position t over keys 0..t. Positions are cut (at absolute positions) into
//    segments of 128 and super-segments of 128 << SS_LOG.
//    q is stored as bf16(q * log2 e / sqrt(128)), so a score s_j = q . k_j (MMA over the 8 dim-ksteps, f32)
//    is in units of log2. State of a query inside a super-segment: (M, Z, O), starting at (-inf, 0, 0).
//    Per segment, in ascending order: m = max of s_j over the valid positions, R = max(M, m),
//    a = 2^(M - R) (exactly 1 when M == R, 0 for M = -inf), O *= a, Z *= a, w_j = bf16(2^(s_j - R)) (0 for
//    j > t), O += sum_j w_j V_j and Z += sum_j w_j (tensor-core instructions over 16 positions each,
//    positions ascending, accumulating into O and Z; Z against a V dim group of ones), M = R.
//    The super-segments of a query are folded in ascending order from (-inf, 0, 0): M' = max(M, m),
//    a = 2^(M - M'), b = 2^(m - M') (exactly 1 / 0 as above), Z' = Z a + z b, O' = O a + o b.
//    Output = bf16(O * (1 / Z)).
//    So a (query, super-segment) part can be computed anywhere, in any pass, next to any other work.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define H 4096
#define NL 36
#define QKV_ROWS 6144
#define INNER 12288
#define VOCAB 151936
#define QKV_T 384
#define O_T 256
#define GU_T 1536
#define DN_T 256
#define LM_T 9496
#define KS_H 256
#define KS_I 768
#define OFF_QKV 0ull
#define OFF_O (OFF_QKV + (size_t)QKV_T * KS_H * 32)
#define OFF_GU (OFF_O + (size_t)O_T * KS_H * 32)
#define OFF_DN (OFF_GU + (size_t)GU_T * KS_H * 32)
#define LAYER_U4 (OFF_DN + (size_t)DN_T * KS_I * 32)

#define NSLOT 64
#define MAXPG 68                         // pages per sequence: 34816 / 512
#define PG_TILES 32                      // a page = 512 positions = 32 position tiles
#define PG_U4 (PG_TILES * 8 * 32)        // uint4 per (page, layer, kv head) for K; the same again for V
#define PAGE_BYTES ((size_t)NL * 8 * 2 * PG_U4 * 16)
#define SEG 128                          // attention segment (positions)

#ifndef TCAP
#define TCAP 2048                        // columns per pass at most
#endif
#define SELCAP 256                       // columns per pass that need logits / a token
// plan buffer (ints), written by the host before a pass
#define MAXU 512                         // attention units per pass (a unit: up to 16 consecutive positions of one sequence)
#define MAXBT 32768                      // attention tasks per pass
#ifndef SS_LOG
#define SS_LOG 5
#endif
#define SS_SEGS (1 << SS_LOG)            // segments per super-segment
#define SS_SHIFT (7 + SS_LOG)            // log2 of the positions of a super-segment
#define PARTCAP (SS_LOG == 5 ? 2048 : SS_LOG == 4 ? 4096 : 8192)   // (unit, super-segment) parts kept in the scratch per pass
#define PL_SLOT 0                        // [TCAP] slot | (last column of its run ? LASTBIT : 0) | (column - first column of its attention unit) << 17
#define PL_POS (TCAP)                    // [TCAP] position of the column in its sequence
#define PL_TOK (2 * TCAP)                // [TCAP] token id, or -1: the slot's last generated token
#define PL_UNIT (3 * TCAP)               // [MAXU][4] attention units: first column, columns (<= 16), first part in the scratch (-1: one super-segment, no fold), unused
#define PL_BT (PL_UNIT + 4 * MAXU)       // [MAXBT] attention tasks, those of two units first: first unit | super-segment << 16 | kv head << 22
#define PL_FOLD (PL_BT + MAXBT)          // [MAXU] units whose super-segments have to be folded
#define PL_SEL (PL_FOLD + MAXU)          // [SELCAP][2]: column, slot (-1: none)
#define PL_PT (PL_SEL + 2 * SELCAP)      // [NSLOT][MAXPG] page ids
#define PL_CU (PL_PT + NSLOT * MAXPG)    // [TCAP] attention unit of the column
#define PL_INTS (PL_CU + TCAP)
#define LASTBIT 0x10000

#define MMA(c, a, b) asm volatile( \
  "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
  : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) \
  : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y))

__device__ __forceinline__ unsigned short f2bf(float f) {
  unsigned u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (unsigned short)(u >> 16);
}
__device__ __forceinline__ float bf2f(unsigned v) { return __uint_as_float(v << 16); }
// Layout of every GEMM operand in global memory, weights [M rows][K] and activations [columns][K] alike
// ("rows" below are M rows or token columns): [k / 64][row / 8][(k % 64) / 8][row % 8][k % 8] in bf16 elements.
// One (K chunk of 64, 8 rows) is 1 KB; inside it the 8 rows x 8 K-elements of each K-octet are 128 contiguous
// bytes. A K chunk of consecutive row groups is therefore one contiguous byte range that the copy engine moves
// into shared memory as it is, and there it is the canonical K-major operand of wgmma (no swizzle: leading
// offset 128 B between the two K-octets of an instruction, stride 1 KB between groups of 8 rows).
__device__ __forceinline__ size_t xidx(int k, int row, int groups) {
  return ((((size_t)(k >> 6) * groups + (row >> 3)) * 8 + ((k >> 3) & 7)) * 8 + (row & 7)) * 8 + (k & 7);
}
#define NG_X (TCAP / 8)      // column groups of the activation buffers
#define NG_LM (SELCAP / 8)   // ... of the lm_head input
__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
#define NINF (-__int_as_float(0x7f800000))
#define SC2 ((float)(0.08838834764831845 * 1.4426950408889634))   // log2(e) / sqrt(128)

// ---------------------------------------------------------------------------------------------------------
// GEMM: Y[M x T] = W[M x K] X[K x T] on the Hopper path.
//   * wgmma: one instruction of a warpgroup (4 warps) multiplies 64 rows x NB columns x 16 K, both operands read
//     from shared memory through descriptors, accumulators in registers (NB / 2 per thread);
//   * cp.async.bulk: the copy engine moves a contiguous byte range global -> shared memory; no warp loads
//     anything, so the copy overlaps the multiply completely;
//   * mbarriers: a stage (K chunk of 64) is "full" when its bytes have arrived, "empty" when both consumer
//     warpgroups are done with it.
// A block = 2 consumer warpgroups + 1 producer warp: 128 rows x 2 NB columns (warpgroup w: columns w * NB ..),
// 4 stages of (A: 128 rows x 64 K = 16 KB, B: 2 NB columns x 64 K) in shared memory. Block b takes units
// b, b + grid, ... in row-major order: the SMs work on a window of row blocks whose weights stay in L2 while
// every column block of them is computed.
// Why this path (all measured here, T = 1024, 24576 x 4096): my m16n8k16 kernels with warp loads into shared
// memory reached 255 / 334 / 292 / 301 TFLOPS in four designs. tests/copy_rate.cu: an SM copies global -> shared
// memory at 10 KB/us per loading warp up to ~55 KB/us; tests/roles_rate.cu, tests/l1_stage.cu: while it does,
// the multiplies stall (same warps, other warps, or L1 as the buffer: always copy time + multiply time).
// The vendor GEMM runs at 790-820 TFLOPS on these shapes; its launch (132 blocks x 384 threads, 168 registers,
// 213 KB shared memory, "64x4" in the kernel name) pointed to wgmma + the copy engine. This kernel: 738 TFLOPS,
// and 2.2-2.8 TB/s of weights at T <= 64 (the old one: 1.2), tests/wg_bench.cu.
// Instruction forms after CUTLASS (cute/arch/mma_sm90_gmma.hpp, copy_sm90_tma.hpp, cutlass/arch/barrier.h).
// ---------------------------------------------------------------------------------------------------------
#include "wg_gen.h"
#define WG_STAGES 4
#define WG_KC 64                               // K per stage: 4 wgmma instructions per 64-row tile
#define WG_A_STAGE (128 * WG_KC * 2)
#define WG_THREADS 288
#define WG_SMEM(NB) (WG_STAGES * (WG_A_STAGE + 2 * (NB) * WG_KC * 2) + 64)
__device__ __forceinline__ uint32_t sm32(const void* p) { return (uint32_t)__cvta_generic_to_shared(p); }
__device__ __forceinline__ void mbar_init(uint64_t* b, uint32_t count) { asm volatile("mbarrier.init.shared::cta.b64 [%1], %0;" :: "r"(count), "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_arrive(uint64_t* b) { asm volatile("mbarrier.arrive.shared::cta.b64 _, [%0];" :: "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_expect(uint64_t* b, uint32_t bytes) { asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%1], %0;" :: "r"(bytes), "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_wait(uint64_t* b, uint32_t phase) {
  asm volatile("{\n.reg .pred P1;\nLAB_WAIT:\nmbarrier.try_wait.parity.shared::cta.b64 P1, [%0], %1;\n@P1 bra DONE;\nbra LAB_WAIT;\nDONE:\n}" :: "r"(sm32(b)), "r"(phase) : "memory");
}
__device__ __forceinline__ void bulk_g2s(void* smem_dst, const void* gsrc, uint32_t bytes, uint64_t* b) {
  asm volatile("cp.async.bulk.shared::cluster.global.mbarrier::complete_tx::bytes [%0], [%1], %2, [%3];" :: "r"(sm32(smem_dst)), "l"(gsrc), "r"(bytes), "r"(sm32(b)) : "memory");
}
__device__ __forceinline__ uint64_t wg_desc(const void* smem_ptr) {
  return (uint64_t)((sm32(smem_ptr) >> 4) & 0x3fff) | ((uint64_t)8 << 16) | ((uint64_t)64 << 32);
}
template <int NB> struct WG;
template <> struct WG<16> { static __device__ __forceinline__ void mma(float (&d)[8], uint64_t da, uint64_t db) { WGMMA_N16(d, da, db); } };
template <> struct WG<32> { static __device__ __forceinline__ void mma(float (&d)[16], uint64_t da, uint64_t db) { WGMMA_N32(d, da, db); } };
template <> struct WG<64> { static __device__ __forceinline__ void mma(float (&d)[32], uint64_t da, uint64_t db) { WGMMA_N64(d, da, db); } };
template <> struct WG<128> { static __device__ __forceinline__ void mma(float (&d)[64], uint64_t da, uint64_t db) { WGMMA_N128(d, da, db); } };

enum { EP_QKV = 0, EP_ADD = 1, EP_GU = 2, EP_LM = 3, EP_LMARG = 4, EP_RAW = 5 };

struct GemmArgs {
  const unsigned short* W;   // weights [M][K] in the operand layout (see xidx)
  const unsigned short* X;   // activations [columns][K] in the operand layout with NG column groups
  int M, K, T, NG;
  const float* rn;        // [T] 1/rms of the input norm (QKV, GU, LM)
  float* out;             // QKV: [T][6144]; LM: logits [T][VOCAB]; RAW: [T][M]
  float* x;               // ADD: residual stream [T][4096]
  const float* aux;       // ADD: weights of the next RMSNorm [4096]
  unsigned short* frag;   // ADD: next norm's input (K = 4096); GU: silu(gate)*up (K = 12288); operand layout, NG_X groups
  float* ssq;             // ADD: [T][256] per-16-row sums of x^2
  float* bm_val; int* bm_idx;   // LMARG: [M / 32][T] best logit and its row per (row block, warp)
};

template <int EP, int NB>
__global__ void __launch_bounds__(WG_THREADS, 1) k_gemm(GemmArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  enum { B_STAGE = 2 * NB * WG_KC * 2, STAGE = WG_A_STAGE + B_STAGE };
  uint64_t* full = (uint64_t*)(smem + WG_STAGES * STAGE);
  uint64_t* empty = full + WG_STAGES;
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, wg = warp >> 2;
  if (tid == 0) {
    for (int s = 0; s < WG_STAGES; s++) { mbar_init(full + s, 1); mbar_init(empty + s, 2); }
    asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  }
  __syncthreads();
  const int n_cb = (a.T + 2 * NB - 1) / (2 * NB), n_rb = a.M / 128, n_units = n_rb * n_cb, nchunk = a.K / WG_KC;
  const int mg = a.M / 8;
  unsigned gc = 0;                               // chunks so far: the producer and the consumers count alike
  if (wg == 2) {
    // ---- producer: one thread asks the copy engine for A and B of every chunk, up to WG_STAGES ahead
    if (lane != 0) return;
    for (int u = blockIdx.x; u < n_units; u += gridDim.x) {
      const int rb = u / n_cb, cb = u - rb * n_cb;
      for (int c = 0; c < nchunk; c++, gc++) {
        const int s = gc % WG_STAGES; const unsigned r = gc / WG_STAGES;
        if (r >= 1) mbar_wait(empty + s, (r - 1) & 1);
        mbar_expect(full + s, STAGE);
        bulk_g2s(smem + s * STAGE, a.W + ((size_t)c * mg + rb * 16) * 512, WG_A_STAGE, full + s);
        bulk_g2s(smem + s * STAGE + WG_A_STAGE, a.X + ((size_t)c * a.NG + cb * (NB / 4)) * 512, B_STAGE, full + s);
      }
    }
    return;
  }
  // ---- consumers: warpgroup wg computes rows 0..127 x columns wg * NB .. + NB - 1 of the block
  for (int u = blockIdx.x; u < n_units; u += gridDim.x) {
    const int rb = u / n_cb, cb = u - rb * n_cb;
    float acc[2][NB / 2];
#pragma unroll
    for (int i = 0; i < 2; i++)
#pragma unroll
      for (int j = 0; j < NB / 2; j++) acc[i][j] = 0.f;
    for (int c = 0; c < nchunk; c++, gc++) {
      const int s = gc % WG_STAGES; const unsigned r = gc / WG_STAGES;
      mbar_wait(full + s, r & 1);
      const unsigned char* As = smem + s * STAGE;
      const unsigned char* Bs = As + WG_A_STAGE + wg * (NB * WG_KC * 2);
      asm volatile("wgmma.fence.sync.aligned;" ::: "memory");
#pragma unroll
      for (int j = 0; j < WG_KC / 16; j++) {
        const uint64_t db = wg_desc(Bs + j * 256);
        WG<NB>::mma(acc[0], wg_desc(As + j * 256), db);
        WG<NB>::mma(acc[1], wg_desc(As + 8192 + j * 256), db);
      }
      asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory");
      asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
      if ((tid & 127) == 0) mbar_arrive(empty + s);
    }
    // ---- epilogue. Register 4 j + e of thread (warp t2 of the group, lane (g, t)) of the 64-row tile i holds
    // column group j of the warpgroup, e: 0 (row g, col 2t), 1 (row g, col 2t+1), 2 (row g+8, col 2t), 3 (row g+8, col 2t+1)
    // with rows relative to the 16-row tile 4 i + t2 of the block.
    {
      const int g = lane >> 2, t = lane & 3, t2 = warp & 3;
#pragma unroll
      for (int j = 0; j < NB / 8; j++) {
        const int n0 = cb * 2 * NB + wg * NB + 8 * j + 2 * t, n1 = n0 + 1;
        const bool v0 = n0 < a.T, v1 = n1 < a.T;
        float r0 = 0.f, r1 = 0.f;
        float bv0 = NINF, bv1 = NINF; int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
        if (EP == EP_QKV || EP == EP_GU || EP == EP_LM || EP == EP_LMARG) {
          if (v0) r0 = __ldcg(a.rn + n0);
          if (v1) r1 = __ldcg(a.rn + n1);
        }
#pragma unroll
        for (int i = 0; i < 2; i++) {
          const int tile = rb * 8 + 4 * i + t2;
          const int row = tile * 16 + g;
          const float* cc = &acc[i][4 * j];
          if (EP == EP_QKV || EP == EP_LM || EP == EP_RAW) {
            const size_t stride = EP == EP_QKV ? QKV_ROWS : (EP == EP_LM ? VOCAB : (size_t)a.M);
            const float q0 = EP == EP_RAW ? 1.f : r0, q1 = EP == EP_RAW ? 1.f : r1;
            if (v0) { a.out[(size_t)n0 * stride + row] = cc[0] * q0; a.out[(size_t)n0 * stride + row + 8] = cc[2] * q0; }
            if (v1) { a.out[(size_t)n1 * stride + row] = cc[1] * q1; a.out[(size_t)n1 * stride + row + 8] = cc[3] * q1; }
          } else if (EP == EP_GU) {
            const int jr = tile * 8 + g;   // rows 0..7 of the tile are gate[jr], rows 8..15 are up[jr]
            if (v0) { float gt = cc[0] * r0; float m = gt / (1.0f + __expf(-gt)) * (cc[2] * r0); a.frag[xidx(jr, n0, NG_X)] = f2bf(m); }
            if (v1) { float gt = cc[1] * r1; float m = gt / (1.0f + __expf(-gt)) * (cc[3] * r1); a.frag[xidx(jr, n1, NG_X)] = f2bf(m); }
          } else if (EP == EP_ADD) {
            const float w0 = a.aux[row], w1 = a.aux[row + 8];
            float s0 = 0.f, s1 = 0.f;
            if (v0) {
              float* p = a.x + (size_t)n0 * H + row;
              float xa = __ldcg(p) + cc[0], xb = __ldcg(p + 8) + cc[2];
              p[0] = xa; p[8] = xb;
              a.frag[xidx(row, n0, NG_X)] = f2bf(w0 * xa);
              a.frag[xidx(row + 8, n0, NG_X)] = f2bf(w1 * xb);
              s0 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            if (v1) {
              float* p = a.x + (size_t)n1 * H + row;
              float xa = __ldcg(p) + cc[1], xb = __ldcg(p + 8) + cc[3];
              p[0] = xa; p[8] = xb;
              a.frag[xidx(row, n1, NG_X)] = f2bf(w0 * xa);
              a.frag[xidx(row + 8, n1, NG_X)] = f2bf(w1 * xb);
              s1 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            s0 += __shfl_xor_sync(0xffffffffu, s0, 4); s1 += __shfl_xor_sync(0xffffffffu, s1, 4);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 8); s1 += __shfl_xor_sync(0xffffffffu, s1, 8);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 16); s1 += __shfl_xor_sync(0xffffffffu, s1, 16);
            if (g == 0) {
              if (v0) a.ssq[(size_t)n0 * 256 + tile] = s0;
              if (v1) a.ssq[(size_t)n1 * 256 + tile] = s1;
            }
          } else if (EP == EP_LMARG) {
            // the logits of EP_LM, reduced to the best row per column; rows ascend, strict > keeps the lowest
            float v;
            v = cc[0] * r0; if (v > bv0) { bv0 = v; bi0 = row; }
            v = cc[2] * r0; if (v > bv0) { bv0 = v; bi0 = row + 8; }
            v = cc[1] * r1; if (v > bv1) { bv1 = v; bi1 = row; }
            v = cc[3] * r1; if (v > bv1) { bv1 = v; bi1 = row + 8; }
          }
        }
        if (EP == EP_LMARG) {
#pragma unroll
          for (int o = 16; o >= 4; o >>= 1) {
            float uv = __shfl_xor_sync(0xffffffffu, bv0, o); int ix = __shfl_xor_sync(0xffffffffu, bi0, o);
            if (uv > bv0 || (uv == bv0 && ix < bi0)) { bv0 = uv; bi0 = ix; }
            uv = __shfl_xor_sync(0xffffffffu, bv1, o); ix = __shfl_xor_sync(0xffffffffu, bi1, o);
            if (uv > bv1 || (uv == bv1 && ix < bi1)) { bv1 = uv; bi1 = ix; }
          }
          if (g == 0) {
            const size_t base = (size_t)(rb * 4 + t2) * a.T;
            if (v0) { a.bm_val[base + n0] = bv0; a.bm_idx[base + n0] = bi0; }
            if (v1) { a.bm_val[base + n1] = bv1; a.bm_idx[base + n1] = bi1; }
          }
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// small per-column kernels
// ---------------------------------------------------------------------------------------------------------
struct Dev {
  const unsigned short* W; const unsigned short* embed; const float* norm_w; const float* qk_norm_w; const float* rope;
  uint4* kv;                 // page pool: [page][layer][kv head][K | V][PG_U4]
  const int* plan;           // device copy of the pass plan
  float* x;                  // [TCAP][H] residual stream
  unsigned short* xfrag;     // [TCAP][H] bf16(w * x) in the operand layout: input of the next norm + matvec
  float* ssq;                // [TCAP][256]
  float* rn;                 // [TCAP]
  float* qkv;                // [TCAP][6144]
  unsigned short* qfrag;     // [MAXU][8 kv heads][16 KB] q after norm, RoPE and score scale, bf16 (see qidx)
  unsigned short* afrag;     // [TCAP][H] attention output, operand layout
  unsigned short* mfrag;     // [TCAP][INNER] silu(gate) * up, operand layout
  unsigned short* lmfrag;    // [SELCAP][H] final-norm input of the selected columns, operand layout (NG_LM groups)
  float* lm_rn;              // [SELCAP]
  float* bm_val; int* bm_idx;// [VOCAB / 32][SELCAP]
  int* last_tok;             // [NSLOT] last generated token of a slot
  int* sel_tok;              // [SELCAP] tokens of this pass
  float4* att_part;          // [PARTCAP][8 kv heads][17][128]: fold state of a (unit, kv head, super-segment)
  int* ctr;                  // [2 NL] task counters of the attention kernel, one per layer (zeroed by k_embed)
};

// embedding: x = embed[token]; fragments of bf16(w0 * x) and per-tile sums of x^2 for the first norm
struct EmbedArgs { Dev d; int T; int pos_add; const long long* tok64; };
__global__ void __launch_bounds__(256) k_embed(EmbedArgs a) {
  const Dev& D = a.d;
  if (blockIdx.x == 0 && threadIdx.x < NL * 2) D.ctr[threadIdx.x] = 0;
  for (int col = blockIdx.x; col < a.T; col += gridDim.x) {
    long long tok;
    if (a.tok64) tok = a.tok64[col];
    else {
      tok = D.plan[PL_TOK + col];
      if (tok < 0) tok = __ldcg(D.last_tok + (D.plan[PL_SLOT + col] & 0xffff));
    }
    const uint2* e = (const uint2*)(D.embed + (size_t)tok * H);
    for (int i = threadIdx.x; i < H / 4; i += 256) {
      uint2 v = e[i];
      float4 f = make_float4(bf2f(v.x & 0xffffu), bf2f(v.x >> 16), bf2f(v.y & 0xffffu), bf2f(v.y >> 16));
      ((float4*)(D.x + (size_t)col * H))[i] = f;
      float4 wv = ((const float4*)D.norm_w)[i];
      const int k = i * 4;
      D.xfrag[xidx(k + 0, col, NG_X)] = f2bf(wv.x * f.x);
      D.xfrag[xidx(k + 1, col, NG_X)] = f2bf(wv.y * f.y);
      D.xfrag[xidx(k + 2, col, NG_X)] = f2bf(wv.z * f.z);
      D.xfrag[xidx(k + 3, col, NG_X)] = f2bf(wv.w * f.w);
      float p = __fadd_rn(__fmaf_rn(f.x, f.x, __fmul_rn(f.y, f.y)), __fmaf_rn(f.z, f.z, __fmul_rn(f.w, f.w)));
      p += __shfl_xor_sync(0xffffffffu, p, 1);
      p += __shfl_xor_sync(0xffffffffu, p, 2);
      if ((i & 3) == 0) D.ssq[(size_t)col * 256 + (i >> 2)] = p;
    }
  }
}

// 1/rms per column from the 256 per-tile partial sums (fixed order). One warp per column.
struct RnArgs { const float* ssq; float* rn; int T; };
__global__ void __launch_bounds__(256) k_rnorm(RnArgs a) {
  const int lane = threadIdx.x & 31;
  for (int col = blockIdx.x * 8 + (threadIdx.x >> 5); col < a.T; col += gridDim.x * 8) {
    const float4* q = (const float4*)(a.ssq + (size_t)col * 256) + lane * 2;
    float4 u = __ldcg(q), v = __ldcg(q + 1);
    float s = ((u.x + u.y) + (u.z + u.w)) + ((v.x + v.y) + (v.z + v.w));
    s = warp_sum(s);
    if (lane == 0) a.rn[col] = rsqrtf(__fmaf_rn(s, 1.0f / H, 1e-6f));
  }
}

// K, V and q are stored as operands of the warpgroup MMA (8 x 8 bf16 per 128 bytes, see wg_desc):
//   K of a page (512 positions) of one (layer, kv head): [pos / 8][dim / 8][pos % 8][dim % 8]; a segment of 128
//     positions is 32 KB contiguous = the B operand (positions x dims) of the score product;
//   V: [pos / 128][dim / 8][(pos % 128) / 8][dim % 8][pos % 8]; a segment is 32 KB contiguous = the B operand
//     (dims x positions) of the value product;
//   q of a unit (16 positions x the 4 heads of a kv head = 64 rows, row = 4 * position + head): [row / 8][dim / 8][row % 8][dim % 8].
__device__ __forceinline__ size_t kidx(int pp, int d) { return ((((size_t)(pp >> 3) * 16 + (d >> 3)) * 8 + (pp & 7)) * 8 + (d & 7)); }
__device__ __forceinline__ size_t vidx(int pp, int d) { return (((((size_t)(pp >> 7) * 16 + (d >> 3)) * 16 + ((pp >> 3) & 15)) * 8 + (d & 7)) * 8 + (pp & 7)); }
__device__ __forceinline__ size_t qidx(int row, int d) { return ((((size_t)(row >> 3) * 16 + (d >> 3)) * 8 + (row & 7)) * 8 + (d & 7)); }
__device__ __forceinline__ unsigned short* page_k(const Dev& D, int slot, int pos, int layer, int g) {
  const int page = D.plan[PL_PT + slot * MAXPG + (pos >> 9)];
  return (unsigned short*)(D.kv + ((((size_t)page * NL + layer) * 8 + g) * 2) * PG_U4);
}

// After the q/k/v matvec: per column 48 vectors of 128 (32 q heads, 8 k heads, 8 v heads), one warp each.
// q, k: RMSNorm over the head, RoPE at the column's position. q -> qfrag; k, v -> the sequence's KV pages.
struct PrepArgs { Dev d; int T; int layer; int pos_add; };
__global__ void __launch_bounds__(512) k_prep(PrepArgs a) {
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31;
  const int total = a.T * 48;
  for (int wt = blockIdx.x * 16 + (threadIdx.x >> 5); wt < total; wt += gridDim.x * 16) {
    const int col = wt / 48, vec = wt - col * 48;
    const int sl = D.plan[PL_SLOT + col], slot = sl & 0xffff, pos = D.plan[PL_POS + col] + a.pos_add;
    const int row = vec < 32 ? vec * 128 : (vec < 40 ? 4096 + (vec - 32) * 128 : 5120 + (vec - 40) * 128);
    const float4 x = __ldcg((const float4*)(D.qkv + (size_t)col * QKV_ROWS + row) + lane);
    float xe[4] = {x.x, x.y, x.z, x.w};
    unsigned short ob[4];
    if (vec < 40) {
      const float4 wn = ((const float4*)(D.qk_norm_w + (a.layer * 2 + (vec < 32 ? 0 : 1)) * 128))[lane];
      const float4 cs = ((const float4*)(D.rope + (size_t)pos * 128))[lane & 15];
      const float4 sn = ((const float4*)(D.rope + (size_t)pos * 128 + 64))[lane & 15];
      const float ss = warp_sum(__fadd_rn(__fmaf_rn(x.x, x.x, __fmul_rn(x.y, x.y)), __fmaf_rn(x.z, x.z, __fmul_rn(x.w, x.w))));
      const float r = rsqrtf(__fmaf_rn(ss, 1.0f / 128, 1e-6f));
      const float we[4] = {wn.x, wn.y, wn.z, wn.w}, ce[4] = {cs.x, cs.y, cs.z, cs.w}, se[4] = {sn.x, sn.y, sn.z, sn.w};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const float yv = __fmul_rn(we[i], __fmul_rn(xe[i], r));
        const float other = __shfl_xor_sync(0xffffffffu, yv, 16);
        const float rot = lane < 16 ? __fmaf_rn(yv, ce[i], -__fmul_rn(other, se[i])) : __fmaf_rn(yv, ce[i], __fmul_rn(other, se[i]));
        ob[i] = f2bf(vec < 32 ? __fmul_rn(rot, SC2) : rot);   // q carries the score scale log2(e) / sqrt(128)
      }
    } else {
#pragma unroll
      for (int i = 0; i < 4; i++) ob[i] = f2bf(xe[i]);
    }
    if (vec < 32) {
      const int g = vec >> 2, h = vec & 3, iq = (sl >> 17) & 15;
      unsigned short* Q = D.qfrag + ((size_t)D.plan[PL_CU + col] * 8 + g) * 8192;
#pragma unroll
      for (int i = 0; i < 4; i++) Q[qidx(4 * iq + h, 4 * lane + i)] = ob[i];
    } else if (vec < 40) {
      unsigned short* Kc = page_k(D, slot, pos, a.layer, vec - 32);
#pragma unroll
      for (int i = 0; i < 4; i++) Kc[kidx(pos & 511, 4 * lane + i)] = ob[i];
    } else {
      unsigned short* Vc = page_k(D, slot, pos, a.layer, vec - 40) + (size_t)PG_U4 * 8;
      // the last column of a run also clears the rest of its group of 16 positions: they enter the value product
      // of that group with weight 0 and must be finite
      const int p0 = pos & 511, pend = (sl & LASTBIT) ? (p0 | 15) : p0;
      for (int pp = p0; pp <= pend; pp++) {
#pragma unroll
        for (int i = 0; i < 4; i++) Vc[vidx(pp, 4 * lane + i)] = pp == p0 ? ob[i] : (unsigned short)0;
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// attention (see the canonical arithmetic at the top), on the warpgroup MMA.
// A task = (1 or 2 units of up to 16 consecutive positions of one sequence, kv head, super-segment), claimed by a
// block from a counter. Warpgroup w of the block computes unit w: 64 query rows (16 positions x 4 heads).
// Per segment of 128 keys:
//   scores [64 rows x 128 positions] = 8 instructions m64n128k16 (A = q rows x dims from shared memory, B = K);
//   thread (warp t2, lane (g8, t)) holds rows g8, g8 + 8 of the warp's 16 rows and positions 8 v2 + 2t, 2t + 1:
//   register 4 v2 + 2 v1 + v0. Max, 2^(s - R), bf16 pack: per thread, in registers;
//   the packed weights of 16 positions ARE the register A operand of the value product
//   O [64 rows x 128 dims] += W x V (B = V from shared memory), and Z against a group of ones.
// K and V of a segment (32 KB each, contiguous) come into shared memory by the copy engine, one segment ahead.
// Decode rows are units of one position: the same kernel, one warpgroup active.
// A unit with more than one super-segment leaves its parts in a scratch and k_attn_fold folds them in order; with
// one super-segment the fold is the identity and the kernel writes the output itself.
// History: v1 scores through shared memory 6.0 ns per (query, key) pair; v3 block kernel + two-level fold 3.0;
// v4 state in registers 2.35; v5 copy engine for K/V 1.63 (all m16n8k16; the instruction count per segment
// bounded them); v6 this one.
// ---------------------------------------------------------------------------------------------------------
#define A_THREADS 256
__device__ __forceinline__ float ex2(float x) { float r; asm("ex2.approx.ftz.f32 %0, %1;" : "=f"(r) : "f"(x)); return r; }
__device__ __forceinline__ unsigned cvt_bf(float x) { unsigned short r; asm("cvt.rn.bf16.f32 %0, %1;" : "=h"(r) : "f"(x)); return r; }
__device__ __forceinline__ void fold_factors(float M, float m, float& Mn, float& fa, float& fb) {
  Mn = fmaxf(M, m);
  fa = (M == Mn) ? 1.0f : (M == NINF ? 0.0f : ex2(__fsub_rn(M, Mn)));
  fb = (m == Mn) ? 1.0f : (m == NINF ? 0.0f : ex2(__fsub_rn(m, Mn)));
}
__device__ __forceinline__ unsigned pack2(float a, float b) { return cvt_bf(a) | (cvt_bf(b) << 16); }
__device__ __forceinline__ uint64_t wg_desc2(const void* smem_ptr, unsigned stride16) {   // operand with `stride16` x 16 bytes per 8 rows
  return (uint64_t)((sm32(smem_ptr) >> 4) & 0x3fff) | ((uint64_t)8 << 16) | ((uint64_t)stride16 << 32);
}

// maxima of the valid scores of the two rows of this thread, reduced over the 4 lanes that share the rows
template <bool FULL>
__device__ __forceinline__ void seg_max(const float (&sc)[64], int limA, int limB, int t, float& mA, float& mB) {
  mA = NINF; mB = NINF;
#pragma unroll
  for (int r = 0; r < 64; r++) {
    const int pos = 8 * (r >> 2) + 2 * t + (r & 1);
    if (r & 2) { if (FULL || pos <= limB) mB = fmaxf(mB, sc[r]); }
    else { if (FULL || pos <= limA) mA = fmaxf(mA, sc[r]); }
  }
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 1)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 1));
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 2)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 2));
}
// the weights of positions 16 jv .. 16 jv + 15 as the register A operand: (row A, 2t), (row B, 2t), (row A, 2t + 8), (row B, 2t + 8), two positions each
template <bool FULL>
__device__ __forceinline__ uint4 seg_weights(const float (&sc)[64], int jv, int limA, int limB, int t, float RA, float RB) {
  unsigned w[8];
#pragma unroll
  for (int e = 0; e < 8; e++) {
    const int r = 8 * jv + e;              // 4 v2 + 2 v1 + v0 with v2 = 2 jv + (e >> 2)
    const int pos = 8 * (r >> 2) + 2 * t + (r & 1);
    const unsigned b = cvt_bf(ex2(__fsub_rn(sc[r], (r & 2) ? RB : RA)));
    w[e] = (FULL || pos <= ((r & 2) ? limB : limA)) ? b : 0u;
  }
  return make_uint4(w[0] | (w[1] << 16), w[2] | (w[3] << 16), w[4] | (w[5] << 16), w[6] | (w[7] << 16));
}
// output of this thread's two rows (positions pA, pB of the unit, head h): bf16(O / Z) into the o projection's input
__device__ __forceinline__ void att_out(const Dev& D, const float* O, float ZA, float ZB, int col0, int nq, int g, int t2, int lane) {
  const int g8 = lane >> 2, t = lane & 3, pA = 4 * t2 + (g8 >> 2), pB = pA + 2, kb = (4 * g + (g8 & 3)) * 128;
  const float rzA = __fdiv_rn(1.0f, ZA), rzB = __fdiv_rn(1.0f, ZB);
#pragma unroll
  for (int v2 = 0; v2 < 16; v2++) {
    if (pA < nq) *(unsigned*)(D.afrag + xidx(kb + 8 * v2 + 2 * t, col0 + pA, NG_X)) = pack2(__fmul_rn(O[4 * v2], rzA), __fmul_rn(O[4 * v2 + 1], rzA));
    if (pB < nq) *(unsigned*)(D.afrag + xidx(kb + 8 * v2 + 2 * t, col0 + pB, NG_X)) = pack2(__fmul_rn(O[4 * v2 + 2], rzB), __fmul_rn(O[4 * v2 + 3], rzB));
  }
}

struct AttArgs { Dev d; int task0; int n_tasks; int layer; int pos_add; int* ctr; };
// Pipeline of a task over its segments s (per warpgroup; "group" = a committed batch of async instructions):
//   A  scores(s+1) -> scB                       needs K(s+1) in shared memory
//   B  wait: values(s-1) done; block barrier; thread 0 asks the copy engine for V(s+1) and K(s+2)
//   C  scalar work of segment s on scA: maxima, rescale of O/Z if a maximum moved, weights of the 8 x 16 positions
//   D  values(s): O += W V, Z += W 1            needs V(s) in shared memory
//   E  wait: scores(s+1) done; scA = scB
// so the tensor cores always have a batch while the threads do the scalar work, and the copies have a whole
// iteration. The warpgroup MMAs are issued without any condition around them (ptxas serializes them otherwise,
// "C7519"): a warpgroup without valid positions in a segment runs with all weights 0 (an exact identity), and
// the groups of 16 positions past the end of the sequence take V from the last valid group (finite) with
// weights 0. Hence two instances: NWG = 2 for pairs of units, NWG = 1 for single units (decode rows).
// Ablation of the unpipelined version (1024 columns at context 16k, attention 27.5 ms): tensor instructions 14.4,
// scalar 6.8, copies and barriers ~6: they ran one after the other.
#define AT_K 0                                // [2][32 KB] K segments
#define AT_V 65536                            // [2][32 KB V segment | 2 KB: a 17th dim group of ones, which gives Z]
#define AT_VBUF (32768 + 2048)
#define AT_Q (AT_V + 2 * AT_VBUF)             // q of the units, 16 KB each
#define AT_BAR(NWG) (AT_Q + (NWG) * 16384)    // uint64 [5]: K0, K1, V0, V1, q arrived
#define AT_SMEM(NWG) (AT_BAR(NWG) + 40 + 24)
template <int NWG>
__global__ void __launch_bounds__(NWG * 128, 1) k_attn(AttArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  const Dev& D = a.d;
  const int tid = threadIdx.x, lane = tid & 31, wg = tid >> 7, t2 = (tid >> 5) & 3, g8 = lane >> 2, t = lane & 3;
  uint64_t* bar = (uint64_t*)(smem + AT_BAR(NWG));
  int* ctl = (int*)(bar + 5);
  if (tid == 0) {
#pragma unroll
    for (int i = 0; i < 5; i++) mbar_init(bar + i, 1);
    asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  }
  for (int i = tid; i < 1024; i += NWG * 128) {   // bf16 1.0
    ((unsigned short*)(smem + AT_V + 32768))[i] = 0x3f80; ((unsigned short*)(smem + AT_V + AT_VBUF + 32768))[i] = 0x3f80;
  }
  unsigned phk0 = 0, phk1 = 0, phv0 = 0, phv1 = 0, phq = 0;   // completions of each barrier so far (every thread counts alike)
  const unsigned char* qs = smem + AT_Q + wg * 16384;
  for (;;) {
    if (tid == 0) ctl[0] = atomicAdd(a.ctr, 1);
    __syncthreads();
    const int task = ctl[0];
    if (task >= a.n_tasks) break;
    const int bt = D.plan[PL_BT + a.task0 + task];
    const int u0 = bt & 0xfff, ss = (bt >> 16) & 0x3f, g = bt >> 22;
    // the group: positions up to gtmax of one sequence
    const int ul = u0 + NWG - 1;
    const int gcol = D.plan[PL_UNIT + 4 * ul];
    const int slot = D.plan[PL_SLOT + gcol] & 0xffff;
    const int gtmax = D.plan[PL_POS + gcol] + a.pos_add + D.plan[PL_UNIT + 4 * ul + 1] - 1;
    const int s0 = ss * SS_SEGS, s1 = min((gtmax >> 7) + 1, s0 + SS_SEGS);
    // this warpgroup's unit
    const int unit = u0 + wg;
    const int col0 = D.plan[PL_UNIT + 4 * unit], nq = D.plan[PL_UNIT + 4 * unit + 1], pbase = D.plan[PL_UNIT + 4 * unit + 2];
    const int pos0 = D.plan[PL_POS + col0] + a.pos_add;
    const int pA = 4 * t2 + (g8 >> 2), pB = pA + 2;
    const int tA = pA < nq ? pos0 + pA : -1, tB = pB < nq ? pos0 + pB : -1;
    const unsigned short* Kpage0 = nullptr;
    if (tid == 0) {
      mbar_expect(bar + 4, NWG * 16384);
#pragma unroll
      for (int w = 0; w < NWG; w++) bulk_g2s(smem + AT_Q + w * 16384, D.qfrag + ((size_t)(u0 + w) * 8 + g) * 8192, 16384, bar + 4);
      // K(s0), K(s0 + 1), V(s0)
#pragma unroll
      for (int e = 0; e < 2; e++) {
        if (s0 + e < s1) {
          const unsigned short* Kn = page_k(D, slot, (s0 + e) * SEG, a.layer, g) + (size_t)((s0 + e) & 3) * 16384;
          mbar_expect(bar + e, 32768);
          bulk_g2s(smem + AT_K + e * 32768, Kn, 32768, bar + e);
          if (e == 0) { mbar_expect(bar + 2, 32768); bulk_g2s(smem + AT_V, Kn + (size_t)PG_U4 * 8, 32768, bar + 2); }
        }
      }
    }
    float O[68], scA[64], scB[64];          // O[64 .. 67]: Z of row A (twice) and of row B (twice)
#pragma unroll
    for (int i = 0; i < 64; i++) { O[i] = 0.f; scA[i] = 0.f; scB[i] = 0.f; }
    O[64] = 0.f; O[65] = 0.f; O[66] = 0.f; O[67] = 0.f;
    float MA = NINF, MB = NINF;
    mbar_wait(bar + 4, phq & 1); phq++;
    mbar_wait(bar, phk0 & 1); phk0++;
    asm volatile("wgmma.fence.sync.aligned;" ::: "memory");
#pragma unroll
    for (int j = 0; j < 8; j++) WGMMA_N128_P(scA, wg_desc2(qs + j * 256, 128), wg_desc2(smem + AT_K + j * 256, 128), j ? 1 : 0);
    asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory");
    asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
    // one segment: CUR holds its scores, NXT receives those of the next one (two register sets, used in turn)
#define ATT_STEP(CUR, NXT, s) do { \
      const int b = ((s) - s0) & 1; \
      /* ---- A: scores of the next segment (of this one again after the last: a batch whose result is not used) */ \
      const bool more = (s) + 1 < s1; \
      if (more) { if (b) { mbar_wait(bar, phk0 & 1); phk0++; } else { mbar_wait(bar + 1, phk1 & 1); phk1++; } } \
      const unsigned char* Kn = smem + AT_K + (more ? b ^ 1 : b) * 32768; \
      asm volatile("wgmma.fence.sync.aligned;" ::: "memory"); \
      _Pragma("unroll") \
      for (int j = 0; j < 8; j++) WGMMA_N128_P(NXT, wg_desc2(qs + j * 256, 128), wg_desc2(Kn + j * 256, 128), j ? 1 : 0); \
      asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory"); \
      /* ---- B: the values of the previous segment are done; the copies of V(s+1) and K(s+2) may start */ \
      asm volatile("wgmma.wait_group.sync.aligned 1;" ::: "memory"); \
      __syncthreads(); \
      if (tid == 0) { \
        if ((s) + 1 < s1) { \
          const unsigned short* Kp = page_k(D, slot, ((s) + 1) * SEG, a.layer, g) + (size_t)(((s) + 1) & 3) * 16384; \
          mbar_expect(bar + 2 + (b ^ 1), 32768); \
          bulk_g2s(smem + AT_V + (b ^ 1) * AT_VBUF, Kp + (size_t)PG_U4 * 8, 32768, bar + 2 + (b ^ 1)); \
        } \
        if ((s) + 2 < s1) { \
          const unsigned short* Kp = page_k(D, slot, ((s) + 2) * SEG, a.layer, g) + (size_t)(((s) + 2) & 3) * 16384; \
          mbar_expect(bar + b, 32768); \
          bulk_g2s(smem + AT_K + b * 32768, Kp, 32768, bar + b); \
        } \
      } \
      /* ---- C: scalar work of segment s */ \
      const int limA = tA - (s) * SEG, limB = tB - (s) * SEG; \
      const int gnpt = min(8, ((gtmax - (s) * SEG) >> 4) + 1);          /* groups of 16 positions that exist in the sequence */ \
      float mA, mB; \
      const bool full = pos0 >= (s) * SEG + SEG - 1; \
      if (full) seg_max<true>(CUR, 0, 0, t, mA, mB); else seg_max<false>(CUR, limA, limB, t, mA, mB); \
      const float RA = fmaxf(MA, mA), RB = fmaxf(MB, mB); \
      const float faA = (MA == RA) ? 1.0f : (MA == NINF ? 0.0f : ex2(__fsub_rn(MA, RA))); \
      const float faB = (MB == RB) ? 1.0f : (MB == NINF ? 0.0f : ex2(__fsub_rn(MB, RB))); \
      /* a factor of exactly 1 changes nothing: skip the multiplies when no row of the warp has a new maximum */ \
      if (__any_sync(0xffffffffu, MA != RA || MB != RB)) { \
        _Pragma("unroll") \
        for (int i = 0; i < 68; i++) O[i] = __fmul_rn(O[i], (i & 2) ? faB : faA); \
      } \
      MA = RA; MB = RB; \
      uint4 pa[8]; \
      if (full) { \
        _Pragma("unroll") \
        for (int jv = 0; jv < 8; jv++) pa[jv] = seg_weights<true>(CUR, jv, 0, 0, t, RA, RB); \
      } else { \
        _Pragma("unroll") \
        for (int jv = 0; jv < 8; jv++) pa[jv] = seg_weights<false>(CUR, jv, limA, limB, t, RA, RB); \
      } \
      /* ---- D: values: O += W V over the 16 dim groups, and against the group of ones behind them: Z += W 1 */ \
      if (b) { mbar_wait(bar + 3, phv1 & 1); phv1++; } else { mbar_wait(bar + 2, phv0 & 1); phv0++; } \
      const unsigned char* Vs = smem + AT_V + b * AT_VBUF; \
      asm volatile("wgmma.fence.sync.aligned;" ::: "memory"); \
      _Pragma("unroll") \
      for (int jv = 0; jv < 8; jv++) WGMMA_RS_N136(O, pa[jv], wg_desc2(Vs + min(jv, gnpt - 1) * 256, 128)); \
      asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory"); \
      /* ---- E: the scores of the next segment are done */ \
      asm volatile("wgmma.wait_group.sync.aligned 1;" ::: "memory"); \
    } while (0)
    for (int s = s0; s < s1; s += 2) {
      ATT_STEP(scA, scB, s);
      if (s + 1 < s1) ATT_STEP(scB, scA, s + 1);
    }
#undef ATT_STEP
    asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
    if (pbase < 0) att_out(D, O, O[64], O[66], col0, nq, g, t2, lane);
    else {
      float4* P = D.att_part + ((size_t)(pbase + ss) * 8 + g) * (17 * 128) + (tid & 127);
#pragma unroll
      for (int i = 0; i < 16; i++) P[i * 128] = make_float4(O[4 * i], O[4 * i + 1], O[4 * i + 2], O[4 * i + 3]);
      P[16 * 128] = make_float4(MA, MB, O[64], O[66]);
    }
  }
}

// ---- fold of the super-segments of a unit, in order: 128 threads per (unit, kv head)
struct FoldArgs { Dev d; int n_fold; int pos_add; };
__global__ void __launch_bounds__(A_THREADS, 1) k_attn_fold(FoldArgs a) {
  const Dev& D = a.d;
  const int tid = threadIdx.x, lane = tid & 31, wg = tid >> 7, t2 = (tid >> 5) & 3;
  const int total = a.n_fold * 8;
  for (int task = blockIdx.x * 2 + wg; task < total; task += gridDim.x * 2) {
    const int unit = D.plan[PL_FOLD + (task >> 3)], g = task & 7;
    const int col0 = D.plan[PL_UNIT + 4 * unit], nq = D.plan[PL_UNIT + 4 * unit + 1], pbase = D.plan[PL_UNIT + 4 * unit + 2];
    const int nss = ((D.plan[PL_POS + col0] + a.pos_add + nq - 1) >> SS_SHIFT) + 1;
    float O[64];
#pragma unroll
    for (int i = 0; i < 64; i++) O[i] = 0.f;
    float MA = NINF, MB = NINF, ZA = 0.f, ZB = 0.f;
    for (int ss = 0; ss < nss; ss++) {
      const float4* P = D.att_part + ((size_t)(pbase + ss) * 8 + g) * (17 * 128) + (tid & 127);
      float4 v[17];
#pragma unroll
      for (int i = 0; i < 17; i++) v[i] = __ldcg(P + i * 128);
      float faA, fbA, faB, fbB, Mn;
      fold_factors(MA, v[16].x, Mn, faA, fbA); MA = Mn; ZA = __fmaf_rn(ZA, faA, __fmul_rn(v[16].z, fbA));
      fold_factors(MB, v[16].y, Mn, faB, fbB); MB = Mn; ZB = __fmaf_rn(ZB, faB, __fmul_rn(v[16].w, fbB));
#pragma unroll
      for (int i = 0; i < 16; i++) {
        O[4 * i + 0] = __fmaf_rn(O[4 * i + 0], faA, __fmul_rn(v[i].x, fbA));
        O[4 * i + 1] = __fmaf_rn(O[4 * i + 1], faA, __fmul_rn(v[i].y, fbA));
        O[4 * i + 2] = __fmaf_rn(O[4 * i + 2], faB, __fmul_rn(v[i].z, fbB));
        O[4 * i + 3] = __fmaf_rn(O[4 * i + 3], faB, __fmul_rn(v[i].w, fbB));
      }
    }
    att_out(D, O, ZA, ZB, col0, nq, g, t2, lane);
  }
}

// ---------------------------------------------------------------------------------------------------------
// lm_head helpers: gather the selected columns' final-norm input; reduce the per-warp maxima to a token
// ---------------------------------------------------------------------------------------------------------
struct SelArgs { Dev d; int n_sel; long long* out64; int out_stride; int out_step; };
__global__ void __launch_bounds__(256) k_gather(SelArgs a) {
  const Dev& D = a.d;
  for (int j = blockIdx.x; j < a.n_sel; j += gridDim.x) {
    const int col = D.plan[PL_SEL + 2 * j];
    for (int i = threadIdx.x; i < H / 8; i += 256)   // 16 bytes = 8 consecutive K elements of the column
      ((uint4*)D.lmfrag)[xidx(8 * i, j, NG_LM) >> 3] = __ldcg((const uint4*)D.xfrag + (xidx(8 * i, col, NG_X) >> 3));
    if (threadIdx.x == 0) D.lm_rn[j] = __ldcg(D.rn + col);
  }
}
__global__ void __launch_bounds__(256) k_argmax(SelArgs a) {
  const Dev& D = a.d;
  __shared__ float sv[8]; __shared__ int si[8];
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const int ncand = VOCAB / 32;
  for (int j = blockIdx.x; j < a.n_sel; j += gridDim.x) {
    float bv = NINF; int bi = 0x7fffffff;
    for (int i = threadIdx.x; i < ncand; i += 256) {
      float v = __ldcg(D.bm_val + (size_t)i * a.n_sel + j); int ix = __ldcg(D.bm_idx + (size_t)i * a.n_sel + j);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
#pragma unroll
    for (int o = 16; o > 0; o >>= 1) {
      float v = __shfl_xor_sync(0xffffffffu, bv, o); int ix = __shfl_xor_sync(0xffffffffu, bi, o);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
    if (lane == 0) { sv[w] = bv; si[w] = bi; }
    __syncthreads();
    if (threadIdx.x == 0) {
      for (int i = 1; i < 8; i++) if (sv[i] > bv || (sv[i] == bv && si[i] < bi)) { bv = sv[i]; bi = si[i]; }
      D.sel_tok[j] = bi;
      const int slot = D.plan[PL_SEL + 2 * j + 1];
      if (slot >= 0) D.last_tok[slot] = bi;
      if (a.out64) a.out64[(size_t)j * a.out_stride + a.out_step] = bi;
    }
    __syncthreads();
  }
}

// test helper: fill a page with NaN (bf16 0x7fc0)
__global__ void k_fill16(unsigned short* p, size_t n, unsigned short v) {
  for (size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x; i < n; i += (size_t)gridDim.x * blockDim.x) p[i] = v;
}

// ---------------------------------------------------------------------------------------------------------
// host API
// ---------------------------------------------------------------------------------------------------------
#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "CUDA error %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); abort(); } } while (0)

struct Eng {
  Dev D;
  int nsm, n_pages;
  int* plan_dev;
  long long passes, launches, plan_uploads, tok_reads;
  int force_shape;
};

// Columns per consumer warpgroup: the smallest wgmma that covers T with one column block, 128 beyond 128 columns
template <int EP, int NB>
static void launch_gemm_nb(Eng* E, const GemmArgs& g) {
  const int n_units = (g.M / 128) * ((g.T + 2 * NB - 1) / (2 * NB));
  k_gemm<EP, NB><<<n_units < E->nsm ? n_units : E->nsm, WG_THREADS, WG_SMEM(NB)>>>(g);
}
template <int EP>
static void launch_gemm(Eng* E, const GemmArgs& g) {
  const int nb = E->force_shape > 0 ? E->force_shape : (g.T <= 32 ? 16 : g.T <= 64 ? 32 : g.T <= 128 ? 64 : 128);
  if (nb == 16) launch_gemm_nb<EP, 16>(E, g);
  else if (nb == 32) launch_gemm_nb<EP, 32>(E, g);
  else if (nb == 64) launch_gemm_nb<EP, 64>(E, g);
  else launch_gemm_nb<EP, 128>(E, g);
  E->launches++;
}
template <int EP>
static void gemm_attr() {
  CK(cudaFuncSetAttribute(k_gemm<EP, 16>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(16)));
  CK(cudaFuncSetAttribute(k_gemm<EP, 32>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(32)));
  CK(cudaFuncSetAttribute(k_gemm<EP, 64>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(64)));
  CK(cudaFuncSetAttribute(k_gemm<EP, 128>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(128)));
}

extern "C" {

void* eng_create(int n_pages, const void* W, const void* embed, const void* norm_w, const void* qk_norm_w, const void* rope) {
  Eng* E = new Eng();
  memset(E, 0, sizeof(Eng));
  int dev = 0; CK(cudaGetDevice(&dev));
  cudaDeviceProp prop; CK(cudaGetDeviceProperties(&prop, dev));
  E->nsm = prop.multiProcessorCount;
  E->n_pages = n_pages;
  E->force_shape = getenv("MK_GEMM_NB") ? atoi(getenv("MK_GEMM_NB")) : -1;
  Dev& D = E->D;
  D.W = (const unsigned short*)W; D.embed = (const unsigned short*)embed; D.norm_w = (const float*)norm_w;
  D.qk_norm_w = (const float*)qk_norm_w; D.rope = (const float*)rope;
  CK(cudaMalloc(&D.kv, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMalloc(&E->plan_dev, sizeof(int) * PL_INTS)); D.plan = E->plan_dev;
  CK(cudaMalloc(&D.x, sizeof(float) * (size_t)TCAP * H));
  CK(cudaMalloc(&D.xfrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.ssq, sizeof(float) * (size_t)TCAP * 256));
  CK(cudaMalloc(&D.rn, sizeof(float) * TCAP));
  CK(cudaMalloc(&D.qkv, sizeof(float) * (size_t)TCAP * QKV_ROWS));
  CK(cudaMalloc(&D.qfrag, (size_t)MAXU * 8 * 16384));
  CK(cudaMalloc(&D.afrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.mfrag, (size_t)TCAP * INNER * 2));
  CK(cudaMalloc(&D.lmfrag, (size_t)SELCAP * H * 2));
  CK(cudaMalloc(&D.lm_rn, sizeof(float) * SELCAP));
  CK(cudaMalloc(&D.bm_val, sizeof(float) * (size_t)(VOCAB / 32) * SELCAP));
  CK(cudaMalloc(&D.bm_idx, sizeof(int) * (size_t)(VOCAB / 32) * SELCAP));
  CK(cudaMalloc(&D.last_tok, sizeof(int) * NSLOT));
  CK(cudaMalloc(&D.sel_tok, sizeof(int) * SELCAP));
  CK(cudaMalloc(&D.att_part, sizeof(float4) * (size_t)PARTCAP * 8 * 17 * 128));
  CK(cudaMalloc(&D.ctr, sizeof(int) * NL * 2));
  CK(cudaMemset(D.ctr, 0, sizeof(int) * NL * 2));
  CK(cudaMemset(D.kv, 0, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMemset(D.xfrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.qfrag, 0, (size_t)MAXU * 8 * 16384));
  CK(cudaMemset(D.afrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.mfrag, 0, (size_t)TCAP * INNER * 2));
  CK(cudaMemset(D.lmfrag, 0, (size_t)SELCAP * H * 2));
  CK(cudaMemset(D.last_tok, 0, sizeof(int) * NSLOT));
  CK(cudaMemset(E->plan_dev, 0, sizeof(int) * PL_INTS));
  gemm_attr<EP_QKV>(); gemm_attr<EP_ADD>(); gemm_attr<EP_GU>(); gemm_attr<EP_LM>(); gemm_attr<EP_LMARG>(); gemm_attr<EP_RAW>();
  CK(cudaFuncSetAttribute(k_attn<1>, cudaFuncAttributeMaxDynamicSharedMemorySize, AT_SMEM(1)));
  CK(cudaFuncSetAttribute(k_attn<2>, cudaFuncAttributeMaxDynamicSharedMemorySize, AT_SMEM(2)));
  return E;
}

int eng_plan_ints() { return PL_INTS; }
int eng_tcap() { return TCAP; }
// plan layout for the host: 0 PL_UNIT, 1 (unused), 2 PL_BT, 3 PL_FOLD, 4 PL_SEL, 5 PL_PT, 6 MAXU, 7 (unused), 8 MAXBT, 9 PARTCAP, 10 PL_CU, 11 SS_SHIFT
int eng_const(int i) { static const int c[12] = {PL_UNIT, 0, PL_BT, PL_FOLD, PL_SEL, PL_PT, MAXU, 0, MAXBT, PARTCAP, PL_CU, SS_SHIFT}; return c[i]; }
// bytes of device memory the engine allocates besides the KV pages
size_t eng_fixed_bytes() { return sizeof(float4) * (size_t)PARTCAP * 8 * 17 * 128 + (size_t)TCAP * (H * 4 + H * 2 * 2 + INNER * 2 + QKV_ROWS * 4 + 256 * 4) + (size_t)MAXU * 8 * 16384 + (size_t)(VOCAB / 32) * SELCAP * 8; }
int eng_selcap() { return SELCAP; }
size_t eng_page_bytes() { return PAGE_BYTES; }

// copy the plan (host ints, layout PL_*) to the device. `n` leading ints are copied.
void eng_set_plan(void* h, const int* plan, int off, int n) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->plan_dev + off, plan + off, sizeof(int) * (size_t)n, cudaMemcpyHostToDevice));
  E->plan_uploads++;
}

// One pass over the weights for the T columns of the current plan.
//   pos_add: added to every column's position (step()/generate() reuse one plan)
//   tok64:   device int64 [T] input tokens, or null (tokens from the plan / the slots' last tokens)
//   logits:  device float [n_sel][VOCAB] or null (then only the argmax: sel_tok, last_tok, out64)
void eng_pass(void* h, int T, int n_bt2, int n_bt1, int n_fold, int n_sel, int pos_add, const void* tok64, void* logits, void* out64, int out_stride, int out_step) {
  Eng* E = (Eng*)h;
  const Dev& D = E->D;
  const int nsm = E->nsm;
  EmbedArgs ea{D, T, pos_add, (const long long*)tok64};
  k_embed<<<T < 4 * nsm ? T : 4 * nsm, 256>>>(ea);
  RnArgs ra{D.ssq, D.rn, T};
  const int rn_grid = (T + 7) / 8 < nsm ? (T + 7) / 8 : nsm;
  for (int l = 0; l < NL; l++) {
    const unsigned short* WL = D.W + (size_t)l * LAYER_U4 * 8;
    k_rnorm<<<rn_grid, 256>>>(ra);
    GemmArgs g{};
    g.W = WL + OFF_QKV * 8; g.X = D.xfrag; g.NG = NG_X; g.M = QKV_ROWS; g.K = H; g.T = T; g.rn = D.rn; g.out = D.qkv;
    launch_gemm<EP_QKV>(E, g);
    PrepArgs pa{D, T, l, pos_add};
    const int pgrid = (T * 48 + 15) / 16 < 2 * nsm ? (T * 48 + 15) / 16 : 2 * nsm;
    k_prep<<<pgrid, 512>>>(pa);
    if (n_bt2 > 0) {   // tasks of two units: tasks 0 .. n_bt2 - 1 of the plan
      AttArgs aa{D, 0, n_bt2, l, pos_add, D.ctr + 2 * l};
      k_attn<2><<<n_bt2 < nsm ? n_bt2 : nsm, 256, AT_SMEM(2)>>>(aa);
    }
    if (n_bt1 > 0) {   // tasks of one unit (decode rows, odd ends of runs): after them
      AttArgs aa{D, n_bt2, n_bt1, l, pos_add, D.ctr + 2 * l + 1};
      k_attn<1><<<n_bt1 < nsm ? n_bt1 : nsm, 128, AT_SMEM(1)>>>(aa);
    }
    if (n_fold > 0) {
      FoldArgs fa{D, n_fold, pos_add};
      k_attn_fold<<<n_fold * 4 < nsm ? n_fold * 4 : nsm, A_THREADS>>>(fa);
    }
    g = GemmArgs{};
    g.W = WL + OFF_O * 8; g.X = D.afrag; g.NG = NG_X; g.M = H; g.K = H; g.T = T;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 1) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g);
    k_rnorm<<<rn_grid, 256>>>(ra);
    g = GemmArgs{};
    g.W = WL + OFF_GU * 8; g.X = D.xfrag; g.NG = NG_X; g.M = 2 * INNER; g.K = H; g.T = T; g.rn = D.rn; g.frag = D.mfrag;
    launch_gemm<EP_GU>(E, g);
    g = GemmArgs{};
    g.W = WL + OFF_DN * 8; g.X = D.mfrag; g.NG = NG_X; g.M = H; g.K = INNER; g.T = T;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 2) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g);
    E->launches += 5;
  }
  if (n_sel > 0) {
    k_rnorm<<<rn_grid, 256>>>(ra);
    SelArgs sa{D, n_sel, (long long*)out64, out_stride, out_step};
    k_gather<<<n_sel, 256>>>(sa);
    GemmArgs g{};
    g.W = D.W + (size_t)NL * LAYER_U4 * 8; g.X = D.lmfrag; g.NG = NG_LM; g.M = VOCAB; g.K = H; g.T = n_sel; g.rn = D.lm_rn;
    if (logits) { g.out = (float*)logits; launch_gemm<EP_LM>(E, g); }
    else {
      g.bm_val = D.bm_val; g.bm_idx = D.bm_idx;
      launch_gemm<EP_LMARG>(E, g);
      k_argmax<<<n_sel, 256>>>(sa);
    }
    E->launches += 3;
  }
  E->launches += 1;
  E->passes++;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) fprintf(stderr, "eng_pass: launch error: %s\n", cudaGetErrorString(e));
}

// tokens of the last pass (blocks until the pass is done: one host sync)
void eng_read_tokens(void* h, int* out, int n_sel) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(out, E->D.sel_tok, sizeof(int) * (size_t)n_sel, cudaMemcpyDeviceToHost));
  E->tok_reads++;
}

void eng_set_last_tok(void* h, int slot, int tok) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->D.last_tok + slot, &tok, sizeof(int), cudaMemcpyHostToDevice));
}

// tests: poison a page's K and V with NaN
void eng_poison_page(void* h, int page) {
  Eng* E = (Eng*)h;
  k_fill16<<<256, 256>>>((unsigned short*)((char*)E->D.kv + PAGE_BYTES * (size_t)page), PAGE_BYTES / 2, (unsigned short)0x7fc0);
}

// tests / bench: a bare matvec through the GEMM kernel. W: [M][K], X: [columns][K] with ng column groups, both in
// the operand layout (xidx); out [T][M] f32
void eng_gemm_raw(void* h, const void* W, const void* X, void* out, int M, int K, int T, int ng) {
  Eng* E = (Eng*)h;
  GemmArgs g{};
  g.W = (const unsigned short*)W; g.X = (const unsigned short*)X; g.NG = ng; g.M = M; g.K = K; g.T = T; g.out = (float*)out;
  launch_gemm<EP_RAW>(E, g);
}

long long eng_stat(void* h, int which) {
  Eng* E = (Eng*)h;
  return which == 0 ? E->launches : which == 1 ? E->passes : which == 2 ? E->nsm : which == 3 ? E->plan_uploads : which == 4 ? E->tok_reads : 0;
}

void eng_sync() { CK(cudaDeviceSynchronize()); }

void eng_destroy(void* h) {
  Eng* E = (Eng*)h;
  cudaDeviceSynchronize();
  Dev& D = E->D;
  cudaFree(D.kv); cudaFree(E->plan_dev); cudaFree(D.x); cudaFree(D.xfrag); cudaFree(D.ssq); cudaFree(D.rn); cudaFree(D.qkv);
  cudaFree(D.qfrag); cudaFree(D.afrag); cudaFree(D.mfrag); cudaFree(D.lmfrag); cudaFree(D.lm_rn); cudaFree(D.bm_val);
  cudaFree(D.bm_idx); cudaFree(D.last_tok); cudaFree(D.sel_tok); cudaFree(D.att_part); cudaFree(D.ctr);
  delete E;
}

}  // extern "C"
