# The engine

One model (Qwen3-8B, bf16), one GPU (H100 80 GB), no inference engine around the kernels.
History, measurements and dead ends: `notes/journal.md`.

## What runs

A **pass** takes T token columns once over the weights: every decode row and every chunk of every prompt that is
being prefilled ride the same pass. The arithmetic of a column does not depend on the other columns, on where a
prompt is cut into chunks, on whether its prefix K/V came from the cache, or on which kernel variant computed it
(the canonical arithmetic is at the top of `eng.cu`). That is what the `schedule` and `online_vs_step` gates test.

| file | what |
|---|---|
| `eng.cu` | every kernel and the C entry points |
| `dsched.h` | the scheduler, C++ compiled for the device (kernel `k_sched`) and for the host (tests) |
| `sched.py` | the same policy in Python: reference for the simulator and for `MK_DEVSCHED=0` |
| `api.py` | `Engine`: offline `reset / step / generate`, online `submit / poll / idle / kv_pages / drop_cache / stats` |
| `gen_wg.py` | generates `wg_gen.h`, the wgmma instruction macros |
| `build.sh` | builds `libeng.so` (run by the evaluator; rebuilds when any source is newer) |

### Kernels of a pass (per layer)

- `k_gemm<epilogue>`: Y = W X with wgmma (operands in shared memory), `cp.async.bulk` (the copy engine brings weights
  and activations) and mbarriers. A block = 2 consumer warpgroups + up to 4 producer threads; it computes units of
  64 NT rows x 2 NB columns. `gemm_shape()` picks (NB, NT) per matrix and number of columns from a small cost model;
  every shape gives the same bits (`tests/gemm_shapes.py`). Epilogues: q/k/v (up to 16 columns it also prepares
  q, K and V: RMSNorm, RoPE, stores), residual add + next norm's input, gate/up with SiLU, LM head (logits or
  arg max). Up to 64 columns the kernel computes the 1/rms of its input norm itself.
- `k_prep`: q, K, V of the columns the GEMM did not prepare. K and V go to the sequence's KV pages.
- `k_attn<2>`: attention for pairs of units (a unit = up to 16 consecutive positions of a sequence), per kv head
  and super-segment of 4096 positions; K/V segments staged by the copy engine.
- `k_attn<1>`: single units. A unit of one position (a decode row) takes `att_dec()`: the same products with the
  operand roles swapped (keys or dims on the 64-row side), on three warpgroups (`tests/att_roles.cu`: same bits).
- `k_attn_fold`: folds the super-segments of a unit in order.
- once per pass: `k_embed`, `k_gather`, `k_argmax`; in the serving loop `k_sched` (admission, pages, prefix cache,
  eviction, the plan of the pass) and `k_commit` (tokens to the result ring, loop condition).

### Who drives

- **Serving** (`submit` / `poll`): one CUDA graph `WHILE (work) { k_sched; pass; k_commit }` runs on the device.
  The host copies prompts into an arena and a request ring, ticks a clock word, and copies result blocks out. It
  never waits for the device and the device never waits for it (`stats()['host_syncs']` stays 0).
- **Offline** (`step`, `generate`): the host writes a plan of B decode rows; `step` is one graph launch per call,
  `generate` one graph `WHILE (step < end) { pass }` per stretch of steps.

### Scheduler policy (`dsched.h`, mirrored in `sched.py`)

KV pages of 512 positions with reference counts; prefix cache keyed by chained page hashes; a request whose next
page another request is computing waits for it; LRU eviction of unused pages; admission by page reservation.
Prompts are served in Moore-Hodgson order over their first-token deadlines; among prompts that arrive together
(within a quarter of a second) the shortest first; those that cannot make their deadline last, shortest first. The size of a pass comes from a cost model (`classes`, `c_seg`, `c_dseg`, `c_pair` in `sched.py`,
calibrated with `tests/calib_cost.py`): as many prompt columns as fit the pass target next to the decode rows.

## Knobs (environment)

| variable | default | meaning |
|---|---|---|
| `MK_TARGET_MS` | 27 | pass time aimed at while prompts are prefilled: the time between tokens of the streams |
| `MK_BOOST_S`, `MK_TARGET_HI_MS` | 1.2, 45 | while an on-time prompt has less slack than this, passes aim at the higher target |
| `MK_SHARE`, `MK_MARGIN_S` | 0.7, 0.3 | cap of the GPU share assumed for prompts; safety margin on the first-token deadline |
| `MK_DEVSCHED`, `MK_GRAPH` | 1, 1 | 0: Python scheduler on the host / host-launched steps (tests) |
| `MK_GEN_GRAPH` | 1 | 0: `step` / `generate` as plain kernel launches |
| `MK_PREPQ`, `MK_GEMM_SPLIT` | 1, 1 | 0: always `k_prep` / always the general GEMM kernel (A/B switches) |
| `MK_POISON` | 0 | 1: freed KV pages are filled with NaN (tests) |
| `MK_PASSLOG` | unset | record (columns, selected, estimated ms, measured ms) per pass (`tests/replay.py`) |
| `MK_PAGES`, `MK_RESERVE_GB`, `MK_SO` | | KV pages, memory left free, another library to load |

`MK_TARGET_MS=80 MK_BOOST_S=0` is the setting with the largest share within the service levels (0.952) at a median
time between tokens of 34 ms; the default trades 5 requests for a median of 23 ms.

## Tests (in the pod, `$MK_PY`)

`bash tests/run_all.sh` (about 8 minutes): float32 reference and bitwise batch / chunking invariance, every GEMM
shape against the others, `generate` against step-by-step greedy, 34000 positions against the reference with NaN in
free pages, and the online contract with shared prefixes, eviction and recomputation under four configurations
(device loop, host-launched steps, Python scheduler, a request ring of 8 entries).

- `tests/replay.py`: the evaluator's replay with a per-request report (`--out`), `tests/sim.py`: the same replay on
  the CPU against the cost model (`--impl both` compares the Python and the device scheduler pass by pass).
- `tests/calib_cost.py`, `tests/time_step2.py`, `tests/gemm_shapes.py`: pass, step and GEMM timings. Compare builds
  in ONE command with `MK_SO`, alternating: numbers from different commands differ by a few percent.
- `tests/wg_scale.cu`, `tests/kv_stride.cu`, `tests/att_roles.cu`: what the tensor cores, HBM and the copy engine
  give, and that swapping operand roles keeps the bits.
