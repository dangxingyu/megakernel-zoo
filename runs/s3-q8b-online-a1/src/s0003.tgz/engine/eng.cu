// Online engine for Qwen3-8B (bf16) on one H100: a "pass" runs T token columns (decode rows and prefill chunks
// together) once over the weights. Every column's arithmetic is independent of the other columns of the pass,
// of where a prefill is cut into chunks and of whether its prefix K/V came from a cache.
//
// Canonical arithmetic (what makes batching / chunking / prefix reuse invisible):
//  * matvec: y[row] = sum over ksteps (16 input dims each) in ascending order, one f32 accumulator per
//    (row, column), each kstep one tensor-core MMA (m16n8k16, bf16 x bf16 -> f32). Inputs are bf16.
//  * attention of a query at position t over keys 0..t: positions are cut into segments of 128 (absolute).
//    Per segment: scores s_j by MMA over the 8 dim-ksteps (f32) times 1/sqrt(128), local max m over the valid
//    positions, w_j = bf16(exp2((s_j - m) * log2 e)) (0 for j > t), z = sum of w_j (per 4 positions
//    (w0+w1)+(w8+w9), chained over the position tiles, the 4 chains combined (c0+c1)+(c2+c3)),
//    o = sum_j w_j V_j (one MMA per position tile, tiles ascending). Segments are combined in ascending
//    order with running (M, Z, O), starting from (-inf, 0, 0): M' = max(M, m), a = exp(M - M'),
//    b = exp(m - M') (exactly 1 when the exponent is 0, 0 for -inf), Z' = Z a + z b, O' = O a + o b.
//    Output = bf16(O * (1 / Z)).
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define H 4096
#define NL 36
#define QKV_ROWS 6144
#define INNER 12288
#define VOCAB 151936
#define QKV_T 384
#define O_T 256
#define GU_T 1536
#define DN_T 256
#define LM_T 9496
#define KS_H 256
#define KS_I 768
#define OFF_QKV 0ull
#define OFF_O (OFF_QKV + (size_t)QKV_T * KS_H * 32)
#define OFF_GU (OFF_O + (size_t)O_T * KS_H * 32)
#define OFF_DN (OFF_GU + (size_t)GU_T * KS_H * 32)
#define LAYER_U4 (OFF_DN + (size_t)DN_T * KS_I * 32)

#define NSLOT 64
#define MAXPG 68                         // pages per sequence: 34816 / 512
#define PG_TILES 32                      // a page = 512 positions = 32 position tiles
#define PG_U4 (PG_TILES * 8 * 32)        // uint4 per (page, layer, kv head) for K; the same again for V
#define PAGE_BYTES ((size_t)NL * 8 * 2 * PG_U4 * 16)
#define SEG 128                          // attention segment (positions)

#ifndef TCAP
#define TCAP 2048                        // columns per pass at most
#endif
#define SELCAP 256                       // columns per pass that need logits / a token
// plan buffer (ints), written by the host before a pass
#define PL_SLOT 0                        // [TCAP] slot | (last column of its run ? LASTBIT : 0)
#define PL_POS (TCAP)                    // [TCAP] position of the column in its sequence
#define PL_TOK (2 * TCAP)                // [TCAP] token id, or -1: the slot's last generated token
#define PL_UNIT (3 * TCAP)               // [TCAP][2] attention units: first column, number of columns (<= 4, one sequence, consecutive positions)
#define PL_SEL (5 * TCAP)                // [SELCAP][2]: column, slot (-1: none)
#define PL_PT (5 * TCAP + 2 * SELCAP)    // [NSLOT][MAXPG] page ids
#define PL_INTS (PL_PT + NSLOT * MAXPG)
#define LASTBIT 0x10000

#define MMA(c, a, b) asm volatile( \
  "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
  : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) \
  : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y))

__device__ __forceinline__ unsigned short f2bf(float f) {
  unsigned u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (unsigned short)(u >> 16);
}
__device__ __forceinline__ float bf2f(unsigned v) { return __uint_as_float(v << 16); }
__device__ __forceinline__ int frag_slot(int k) { return (k & 1) + 2 * ((k >> 3) & 1); }
__device__ __forceinline__ int frag_t(int k) { return (k & 7) >> 1; }
// bf16 index of element k of column `col` in a global B-fragment buffer
// [pair of column groups = col >> 4][kstep][lane = 4 (col & 7) + t][column group & 1][slot]:
// 16 bytes per lane hold the fragments of two column groups (one shared-memory load feeds two MMAs)
__device__ __forceinline__ size_t gfrag(int k, int col, int ksteps) {
  return ((((size_t)(col >> 4) * ksteps + (k >> 4)) * 32 + 4 * (col & 7) + frag_t(k)) << 3) + ((col >> 3) & 1) * 4 + frag_slot(k);
}
// the same in 8-byte words: word (kstep, t) of a column = elements 2t, 2t+1, 2t+8, 2t+9 of the kstep
__device__ __forceinline__ size_t gword(int kstep, int t, int col, int ksteps) {
  return ((((size_t)(col >> 4) * ksteps + kstep) * 32 + 4 * (col & 7) + t) << 1) + ((col >> 3) & 1);
}
__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
#define NINF (-__int_as_float(0x7f800000))

// ---------------------------------------------------------------------------------------------------------
// GEMM: Y[M x T] = W[M x K] X[K x T]. A warp owns 64 rows x 64 columns (4 row tiles x 8 column groups = 32
// accumulators in registers). A block is nwr x nwc such warps (at most 2 x 4: 128 rows x 256 columns); block b
// takes units b, b + grid, ... in row-major order, so the SMs work on a window of a few row blocks at a time:
// the weights of the window stay in L2 while every column block of it is computed.
// Weights and inputs go through shared memory in chunks of 8 ksteps, double buffered; the copy of the next
// chunk is interleaved with the MMAs of this one, so the loads are in flight while the tensor cores work.
// Warp w copies kstep w of the next chunk (8 row tiles, 16 pairs of column groups) in two groups of 12 loads,
// requested before ksteps 0 and 4 and stored after ksteps 3 and 7.
// Measured at T = 1024 (tests/gemm_bench.cu; tests/mma_rate.cu: the tensor cores alone sustain ~650 TFLOPS with
// both operands read from shared memory):
//   v1: 16 warps of 32 x 32, block 128 x 128, 8 loads per thread up front per chunk       255 TFLOPS
//   v2a: 8 warps of 64 x 64, block 128 x 256, one load requested and stored per kstep      239 (one load in flight per warp)
//   v2: the same with two groups of 12 loads                                               324   <- this
//   v3: 16 warps of 32 x 64, block 128 x 256, three groups of 4 loads                       292 (tests/eng_gemm_v3_16warps.cu.txt)
// ---------------------------------------------------------------------------------------------------------
#define G_WARPS 8
#define G_THREADS (G_WARPS * 32)
#define G_KC 8
#define G_A_U4 (8 * G_KC * 32)      // 8 row tiles
#define G_B_U4 (16 * G_KC * 32)     // 16 pairs of column groups
#define G_SMEM (2 * (G_A_U4 + G_B_U4) * 16)
#ifndef WLD
#define WLD(p) (*(p))
#endif
enum { EP_QKV = 0, EP_ADD = 1, EP_GU = 2, EP_LM = 3, EP_LMARG = 4, EP_RAW = 5 };

struct GemmArgs {
  const uint4* W;         // packed A fragments [tile][kstep][32 lanes]
  const uint4* X;         // B fragments [pair of column groups][kstep][32 lanes]
  int m_tiles, ks, T;
  int nwr, nwc;           // warps of a block: nwr (1..2) x nwc (1..4)
  const float* rn;        // [T] 1/rms of the input norm (QKV, GU, LM)
  float* out;             // QKV: [T][6144]; LM: logits [T][VOCAB]; RAW: [T][16 m_tiles]
  float* x;               // ADD: residual stream [T][4096]
  const float* aux;       // ADD: weights of the next RMSNorm [4096]
  unsigned short* frag;   // ADD: next norm's input fragments (K = 4096); GU: silu(gate)*up fragments (K = 12288)
  float* ssq;             // ADD: [T][256] per-tile sums of x^2
  float* bm_val; int* bm_idx;   // LMARG: [m_tiles / 4][T] best logit and its row per warp tile
};

template <int EP>
__global__ void __launch_bounds__(G_THREADS, 1) k_gemm(GemmArgs a) {
  extern __shared__ __align__(16) unsigned char smem[];
  uint4* As = (uint4*)smem;
  uint4* Bs = As + 2 * G_A_U4;
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5, wr = w >> 2, wc = w & 3;
  const int npair = (a.T + 15) >> 4;
  const int ntile_u = 4 * a.nwr;
  const int n_cb = (npair + 4 * a.nwc - 1) / (4 * a.nwc), n_rb = a.m_tiles / ntile_u, n_units = n_rb * n_cb;
  const int ks = a.ks, nchunk = ks / G_KC;
  for (int u = blockIdx.x; u < n_units; u += gridDim.x) {
    const int rb = u / n_cb, cb = u - rb * n_cb;
    const int tile0 = rb * ntile_u, pair0 = cb * 4 * a.nwc;
    const int npair_u = min(4 * a.nwc, npair - pair0);
    const bool active = wr < a.nwr && wc * 4 < npair_u;
    const uint4* wsrc = a.W + ((size_t)tile0 * ks + w) * 32 + lane;    // + (tile * ks + first kstep of the chunk) * 32
    const uint4* xsrc = a.X + ((size_t)pair0 * ks + w) * 32 + lane;
    float c[4][8][4];
#pragma unroll
    for (int i = 0; i < 4; i++)
#pragma unroll
      for (int j = 0; j < 8; j++) { c[i][j][0] = 0.f; c[i][j][1] = 0.f; c[i][j][2] = 0.f; c[i][j][3] = 0.f; }
    uint4 la[4], lb[8];
    // first chunk
#pragma unroll
    for (int h = 0; h < 2; h++) {
#pragma unroll
      for (int q = 0; q < 4; q++) if (4 * h + q < ntile_u) la[q] = WLD(wsrc + (size_t)(4 * h + q) * ks * 32);
#pragma unroll
      for (int q = 0; q < 8; q++) if (8 * h + q < npair_u) lb[q] = __ldcg(xsrc + (size_t)(8 * h + q) * ks * 32);
#pragma unroll
      for (int q = 0; q < 4; q++) if (4 * h + q < ntile_u) As[(4 * h + q) * 256 + w * 32 + lane] = la[q];
#pragma unroll
      for (int q = 0; q < 8; q++) if (8 * h + q < npair_u) Bs[(8 * h + q) * 256 + w * 32 + lane] = lb[q];
    }
    __syncthreads();
    for (int ch = 0; ch < nchunk; ch++) {
      const int buf = ch & 1;
      const bool more = ch + 1 < nchunk;
      const size_t ko = (size_t)(ch + 1) * G_KC * 32;
      const uint4* ap = As + buf * G_A_U4 + (wr * 4) * 256 + lane;
      const uint4* bp = Bs + buf * G_B_U4 + (wc * 4) * 256 + lane;
      uint4* an = As + (buf ^ 1) * G_A_U4 + w * 32 + lane;
      uint4* bn = Bs + (buf ^ 1) * G_B_U4 + w * 32 + lane;
#pragma unroll
      for (int k = 0; k < G_KC; k++) {
#ifndef ABL_NOLOAD
        if (more && (k & 3) == 0) {
          const int h = k >> 2;
#pragma unroll
          for (int q = 0; q < 4; q++) if (4 * h + q < ntile_u) la[q] = WLD(wsrc + (size_t)(4 * h + q) * ks * 32 + ko);
#pragma unroll
          for (int q = 0; q < 8; q++) if (8 * h + q < npair_u) lb[q] = __ldcg(xsrc + (size_t)(8 * h + q) * ks * 32 + ko);
        }
#endif
        if (active) {
          uint4 av[4], bv[4];
#pragma unroll
          for (int i = 0; i < 4; i++) av[i] = ap[i * 256 + k * 32];
#pragma unroll
          for (int j = 0; j < 4; j++) bv[j] = bp[j * 256 + k * 32];
#pragma unroll
          for (int i = 0; i < 4; i++)
#pragma unroll
            for (int j = 0; j < 4; j++) {
              const uint2 b0 = make_uint2(bv[j].x, bv[j].y), b1 = make_uint2(bv[j].z, bv[j].w);
              MMA(c[i][2 * j], av[i], b0); MMA(c[i][2 * j + 1], av[i], b1);
            }
        }
#ifndef ABL_NOSTORE
        if (more && (k & 3) == 3) {
          const int h = k >> 2;
#pragma unroll
          for (int q = 0; q < 4; q++) if (4 * h + q < ntile_u) an[(4 * h + q) * 256] = la[q];
#pragma unroll
          for (int q = 0; q < 8; q++) if (8 * h + q < npair_u) bn[(8 * h + q) * 256] = lb[q];
        }
#endif
      }
#ifndef ABL_NOSYNC
      __syncthreads();
#endif
    }
    // ---- epilogue. Lane (g, t): c[0] (row g, col 2t), c[1] (row g, col 2t+1), c[2] (row g+8, col 2t), c[3] (row g+8, col 2t+1)
    if (active) {
      const int g = lane >> 2, t = lane & 3;
#pragma unroll
      for (int j = 0; j < 8; j++) {
        const int cg = (pair0 + wc * 4) * 2 + j;
        const int n0 = cg * 8 + 2 * t, n1 = n0 + 1;
        const bool v0 = n0 < a.T, v1 = n1 < a.T;
        float r0 = 0.f, r1 = 0.f;
        float bv0 = NINF, bv1 = NINF; int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
        if (EP == EP_QKV || EP == EP_GU || EP == EP_LM || EP == EP_LMARG) {
          if (v0) r0 = __ldcg(a.rn + n0);
          if (v1) r1 = __ldcg(a.rn + n1);
        }
#pragma unroll
        for (int i = 0; i < 4; i++) {
          const int tile = tile0 + wr * 4 + i;
          const int row = tile * 16 + g;
          const float* cc = c[i][j];
          if (EP == EP_QKV || EP == EP_LM || EP == EP_RAW) {
            const size_t stride = EP == EP_QKV ? QKV_ROWS : (EP == EP_LM ? VOCAB : (size_t)a.m_tiles * 16);
            const float q0 = EP == EP_RAW ? 1.f : r0, q1 = EP == EP_RAW ? 1.f : r1;
            if (v0) { a.out[(size_t)n0 * stride + row] = cc[0] * q0; a.out[(size_t)n0 * stride + row + 8] = cc[2] * q0; }
            if (v1) { a.out[(size_t)n1 * stride + row] = cc[1] * q1; a.out[(size_t)n1 * stride + row + 8] = cc[3] * q1; }
          } else if (EP == EP_GU) {
            const int jr = tile * 8 + g;   // rows 0..7 of the tile are gate[jr], rows 8..15 are up[jr]
            if (v0) { float gt = cc[0] * r0; float m = gt / (1.0f + __expf(-gt)) * (cc[2] * r0); a.frag[gfrag(jr, n0, KS_I)] = f2bf(m); }
            if (v1) { float gt = cc[1] * r1; float m = gt / (1.0f + __expf(-gt)) * (cc[3] * r1); a.frag[gfrag(jr, n1, KS_I)] = f2bf(m); }
          } else if (EP == EP_ADD) {
            const float w0 = a.aux[row], w1 = a.aux[row + 8];
            float s0 = 0.f, s1 = 0.f;
            if (v0) {
              float* p = a.x + (size_t)n0 * H + row;
              float xa = __ldcg(p) + cc[0], xb = __ldcg(p + 8) + cc[2];
              p[0] = xa; p[8] = xb;
              a.frag[gfrag(row, n0, KS_H)] = f2bf(w0 * xa);
              a.frag[gfrag(row + 8, n0, KS_H)] = f2bf(w1 * xb);
              s0 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            if (v1) {
              float* p = a.x + (size_t)n1 * H + row;
              float xa = __ldcg(p) + cc[1], xb = __ldcg(p + 8) + cc[3];
              p[0] = xa; p[8] = xb;
              a.frag[gfrag(row, n1, KS_H)] = f2bf(w0 * xa);
              a.frag[gfrag(row + 8, n1, KS_H)] = f2bf(w1 * xb);
              s1 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            s0 += __shfl_xor_sync(0xffffffffu, s0, 4); s1 += __shfl_xor_sync(0xffffffffu, s1, 4);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 8); s1 += __shfl_xor_sync(0xffffffffu, s1, 8);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 16); s1 += __shfl_xor_sync(0xffffffffu, s1, 16);
            if (g == 0) {
              if (v0) a.ssq[(size_t)n0 * 256 + tile] = s0;
              if (v1) a.ssq[(size_t)n1 * 256 + tile] = s1;
            }
          } else if (EP == EP_LMARG) {
            // the logits of EP_LM, reduced to the best row per column; rows ascend, strict > keeps the lowest
            float v;
            v = cc[0] * r0; if (v > bv0) { bv0 = v; bi0 = row; }
            v = cc[2] * r0; if (v > bv0) { bv0 = v; bi0 = row + 8; }
            v = cc[1] * r1; if (v > bv1) { bv1 = v; bi1 = row; }
            v = cc[3] * r1; if (v > bv1) { bv1 = v; bi1 = row + 8; }
          }
        }
        if (EP == EP_LMARG) {
#pragma unroll
          for (int o = 16; o >= 4; o >>= 1) {
            float uv = __shfl_xor_sync(0xffffffffu, bv0, o); int ix = __shfl_xor_sync(0xffffffffu, bi0, o);
            if (uv > bv0 || (uv == bv0 && ix < bi0)) { bv0 = uv; bi0 = ix; }
            uv = __shfl_xor_sync(0xffffffffu, bv1, o); ix = __shfl_xor_sync(0xffffffffu, bi1, o);
            if (uv > bv1 || (uv == bv1 && ix < bi1)) { bv1 = uv; bi1 = ix; }
          }
          if (g == 0) {
            const size_t base = (size_t)((tile0 >> 2) + wr) * a.T;
            if (v0) { a.bm_val[base + n0] = bv0; a.bm_idx[base + n0] = bi0; }
            if (v1) { a.bm_val[base + n1] = bv1; a.bm_idx[base + n1] = bi1; }
          }
        }
      }
    }
    __syncthreads();
  }
}

// ---------------------------------------------------------------------------------------------------------
// small per-column kernels
// ---------------------------------------------------------------------------------------------------------
struct Dev {
  const uint4* W; const unsigned short* embed; const float* norm_w; const float* qk_norm_w; const float* rope;
  uint4* kv;                 // page pool: [page][layer][kv head][K | V][PG_U4]
  const int* plan;           // device copy of the pass plan
  float* x;                  // [TCAP][H] residual stream
  unsigned short* xfrag;     // [TCAP/8][KS_H][32][4] bf16(w * x): input of the next norm + matvec
  float* ssq;                // [TCAP][256]
  float* rn;                 // [TCAP]
  float* qkv;                // [TCAP][6144]
  unsigned short* qfrag;     // [TCAP][8 g][8 ks][4 h][4 t][4] q after norm and RoPE, bf16
  unsigned short* afrag;     // [TCAP/8][KS_H][32][4] attention output
  unsigned short* mfrag;     // [TCAP/8][KS_I][32][4] silu(gate) * up
  unsigned short* lmfrag;    // [SELCAP/8][KS_H][32][4] final-norm input of the selected columns
  float* lm_rn;              // [SELCAP]
  float* bm_val; int* bm_idx;// [LM_T / 4][SELCAP]
  int* last_tok;             // [NSLOT] last generated token of a slot
  int* sel_tok;              // [SELCAP] tokens of this pass
};

// embedding: x = embed[token]; fragments of bf16(w0 * x) and per-tile sums of x^2 for the first norm
struct EmbedArgs { Dev d; int T; int pos_add; const long long* tok64; };
__global__ void __launch_bounds__(256) k_embed(EmbedArgs a) {
  const Dev& D = a.d;
  for (int col = blockIdx.x; col < a.T; col += gridDim.x) {
    long long tok;
    if (a.tok64) tok = a.tok64[col];
    else {
      tok = D.plan[PL_TOK + col];
      if (tok < 0) tok = __ldcg(D.last_tok + (D.plan[PL_SLOT + col] & 0xffff));
    }
    const uint2* e = (const uint2*)(D.embed + (size_t)tok * H);
    for (int i = threadIdx.x; i < H / 4; i += 256) {
      uint2 v = e[i];
      float4 f = make_float4(bf2f(v.x & 0xffffu), bf2f(v.x >> 16), bf2f(v.y & 0xffffu), bf2f(v.y >> 16));
      ((float4*)(D.x + (size_t)col * H))[i] = f;
      float4 wv = ((const float4*)D.norm_w)[i];
      const int k = i * 4;
      D.xfrag[gfrag(k + 0, col, KS_H)] = f2bf(wv.x * f.x);
      D.xfrag[gfrag(k + 1, col, KS_H)] = f2bf(wv.y * f.y);
      D.xfrag[gfrag(k + 2, col, KS_H)] = f2bf(wv.z * f.z);
      D.xfrag[gfrag(k + 3, col, KS_H)] = f2bf(wv.w * f.w);
      float p = __fadd_rn(__fmaf_rn(f.x, f.x, __fmul_rn(f.y, f.y)), __fmaf_rn(f.z, f.z, __fmul_rn(f.w, f.w)));
      p += __shfl_xor_sync(0xffffffffu, p, 1);
      p += __shfl_xor_sync(0xffffffffu, p, 2);
      if ((i & 3) == 0) D.ssq[(size_t)col * 256 + (i >> 2)] = p;
    }
  }
}

// 1/rms per column from the 256 per-tile partial sums (fixed order). One warp per column.
struct RnArgs { const float* ssq; float* rn; int T; };
__global__ void __launch_bounds__(256) k_rnorm(RnArgs a) {
  const int lane = threadIdx.x & 31;
  for (int col = blockIdx.x * 8 + (threadIdx.x >> 5); col < a.T; col += gridDim.x * 8) {
    const float4* q = (const float4*)(a.ssq + (size_t)col * 256) + lane * 2;
    float4 u = __ldcg(q), v = __ldcg(q + 1);
    float s = ((u.x + u.y) + (u.z + u.w)) + ((v.x + v.y) + (v.z + v.w));
    s = warp_sum(s);
    if (lane == 0) a.rn[col] = rsqrtf(__fmaf_rn(s, 1.0f / H, 1e-6f));
  }
}

__device__ __forceinline__ uint4* kv_ptr(const Dev& D, int slot, int pos, int layer, int g, int isv) {
  const int page = D.plan[PL_PT + slot * MAXPG + (pos >> 9)];
  return D.kv + ((((size_t)page * NL + layer) * 8 + g) * 2 + isv) * PG_U4 + (size_t)((pos & 511) >> 4) * 256;
}

// After the q/k/v matvec: per column 48 vectors of 128 (32 q heads, 8 k heads, 8 v heads), one warp each.
// q, k: RMSNorm over the head, RoPE at the column's position. q -> qfrag; k, v -> the sequence's KV pages.
struct PrepArgs { Dev d; int T; int layer; int pos_add; };
__global__ void __launch_bounds__(512) k_prep(PrepArgs a) {
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31;
  const int total = a.T * 48;
  for (int wt = blockIdx.x * 16 + (threadIdx.x >> 5); wt < total; wt += gridDim.x * 16) {
    const int col = wt / 48, vec = wt - col * 48;
    const int sl = D.plan[PL_SLOT + col], slot = sl & 0xffff, pos = D.plan[PL_POS + col] + a.pos_add;
    const int row = vec < 32 ? vec * 128 : (vec < 40 ? 4096 + (vec - 32) * 128 : 5120 + (vec - 40) * 128);
    const float4 x = __ldcg((const float4*)(D.qkv + (size_t)col * QKV_ROWS + row) + lane);
    float xe[4] = {x.x, x.y, x.z, x.w};
    unsigned short ob[4];
    if (vec < 40) {
      const float4 wn = ((const float4*)(D.qk_norm_w + (a.layer * 2 + (vec < 32 ? 0 : 1)) * 128))[lane];
      const float4 cs = ((const float4*)(D.rope + (size_t)pos * 128))[lane & 15];
      const float4 sn = ((const float4*)(D.rope + (size_t)pos * 128 + 64))[lane & 15];
      const float ss = warp_sum(__fadd_rn(__fmaf_rn(x.x, x.x, __fmul_rn(x.y, x.y)), __fmaf_rn(x.z, x.z, __fmul_rn(x.w, x.w))));
      const float r = rsqrtf(__fmaf_rn(ss, 1.0f / 128, 1e-6f));
      const float we[4] = {wn.x, wn.y, wn.z, wn.w}, ce[4] = {cs.x, cs.y, cs.z, cs.w}, se[4] = {sn.x, sn.y, sn.z, sn.w};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const float yv = __fmul_rn(we[i], __fmul_rn(xe[i], r));
        const float other = __shfl_xor_sync(0xffffffffu, yv, 16);
        ob[i] = f2bf(lane < 16 ? __fmaf_rn(yv, ce[i], -__fmul_rn(other, se[i])) : __fmaf_rn(yv, ce[i], __fmul_rn(other, se[i])));
      }
    } else {
#pragma unroll
      for (int i = 0; i < 4; i++) ob[i] = f2bf(xe[i]);
    }
    if (vec < 32) {
      // q word (column, kv head g, head h, kstep, t) = dims 2t, 2t+1, 2t+8, 2t+9 of the kstep
      const int g = vec >> 2, h = vec & 3;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int k16 = 4 * (lane & 3) + i;
        D.qfrag[((((((size_t)col * 8 + g) * 4 + h) * 8 + (lane >> 2)) * 4 + frag_t(k16)) << 2) + frag_slot(k16)] = ob[i];
      }
    } else if (vec < 40) {
      // K tile = MMA B fragments [8 dim ksteps][lane = 4 n + t][half]: dims x positions, n = position & 7, half = (position & 15) >> 3
      unsigned short* Kc = (unsigned short*)kv_ptr(D, slot, pos, a.layer, vec - 32, 0);
      const int pp = pos & 15;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int d = 4 * lane + i, k16 = d & 15;
        Kc[((((size_t)(d >> 4)) * 32 + 4 * (pp & 7) + frag_t(k16)) << 3) + (pp >> 3) * 4 + frag_slot(k16)] = ob[i];
      }
    } else {
      // V tile = MMA B fragments [8 pairs of dim groups][lane = 4 n + t][dim group & 1]: positions x dims, n = dim & 7
      unsigned short* Vc = (unsigned short*)kv_ptr(D, slot, pos, a.layer, vec - 40, 1);
      // the last column of a run also clears the rest of its position tile: those positions enter the V sum
      // of this tile with weight 0 and must be finite
      const int pend = (sl & LASTBIT) ? 15 : (pos & 15);
      for (int pp = pos & 15; pp <= pend; pp++) {
        const bool real = pp == (pos & 15);
#pragma unroll
        for (int i = 0; i < 4; i++) {
          const int d = 4 * lane + i, dg = d >> 3;
          Vc[((((size_t)(dg >> 1)) * 32 + 4 * (d & 7) + frag_t(pp)) << 3) + (dg & 1) * 4 + frag_slot(pp)] = real ? ob[i] : (unsigned short)0;
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// attention (see the canonical arithmetic at the top). A warp works on 16 query rows = 4 consecutive positions
// of one sequence x the 4 q heads of one kv head, and keeps everything of a segment in registers:
//   scores^T [16 rows x 8 positions] = MMA(A = q rows x dims, B = K dims x positions), two per position tile;
//   the weights of a tile, packed as bf16, ARE the A fragment (rows x 16 positions) of the second product
//   o^T [16 rows x 8 dims] += MMA(A = weights, B = V positions x dims), 16 dim groups.
// No shared memory round trip per score, no block barrier.
//   k_attn_pre: one task per warp (4 positions x kv head), segments in sequence, O kept in warp-private smem.
//   k_attn_dec: one task per block: the warps take the segments of one task in parallel (a decode row with a
//               long context is bound by streaming its K/V), warp 0 folds their results in order.
// Both run the same per-segment and fold code, so a query's result does not depend on the path.
// ---------------------------------------------------------------------------------------------------------
#define A_WARPS 8
#ifndef ABL_KMUL
#define ABL_KMUL 8   // ablation: 0 = every tile of a segment reads the first tile's K/V (L1-resident), timing only
#endif
#define A_THREADS (A_WARPS * 32)
#define L2E 1.4426950408889634f
__device__ __forceinline__ float cexp(float d) { return exp2f(__fmul_rn(d, L2E)); }
__device__ __forceinline__ void fold_factors(float M, float m, float& Mn, float& fa, float& fb) {
  Mn = fmaxf(M, m);
  fa = (M == Mn) ? 1.0f : (M == NINF ? 0.0f : cexp(__fsub_rn(M, Mn)));
  fb = (m == Mn) ? 1.0f : (m == NINF ? 0.0f : cexp(__fsub_rn(m, Mn)));
}
__device__ __forceinline__ unsigned pack2(float a, float b) { return (unsigned)f2bf(a) | ((unsigned)f2bf(b) << 16); }

// One segment for the 16 rows of the warp. qs: q A-fragments [8 ksteps][32 lanes] (shared memory);
// Kc / Vc: K and V of the segment's first position tile; npt: position tiles to visit; limA / limB: last valid
// position relative to the segment for row g8 / row g8 + 8 of this lane (negative: none).
// Out: acc = o (c[0], c[1]: row g8, dims 2t, 2t+1 of the dim group; c[2], c[3]: row g8 + 8), m and z per row.
__device__ __forceinline__ void seg_compute(const uint4* qs, const uint4* Kc, const uint4* Vc, int npt, int limA, int limB, int lane,
                                            float (&acc)[16][4], float& mA, float& mB, float& zA, float& zB) {
  const int t = lane & 3;
  const float scale = 0.08838834764831845f;
  float sc[8][2][4];
  uint4 kf[8];
#pragma unroll
  for (int ks = 0; ks < 8; ks++) kf[ks] = __ldcg(Kc + ks * 32 + lane);
#pragma unroll
  for (int k = 0; k < 8; k++) {
    float c0[4] = {0.f, 0.f, 0.f, 0.f}, c1[4] = {0.f, 0.f, 0.f, 0.f};
    if (k < npt) {
      uint4 kn[8];
      if (k + 1 < npt) {
#pragma unroll
        for (int ks = 0; ks < 8; ks++) kn[ks] = __ldcg(Kc + ((k + 1) * ABL_KMUL + ks) * 32 + lane);
      }
#pragma unroll
      for (int ks = 0; ks < 8; ks++) {
        const uint4 qa = qs[ks * 32 + lane];
        const uint2 b0 = make_uint2(kf[ks].x, kf[ks].y), b1 = make_uint2(kf[ks].z, kf[ks].w);
        MMA(c0, qa, b0); MMA(c1, qa, b1);
      }
      if (k + 1 < npt) {
#pragma unroll
        for (int ks = 0; ks < 8; ks++) kf[ks] = kn[ks];
      }
    }
#pragma unroll
    for (int e = 0; e < 4; e++) { sc[k][0][e] = __fmul_rn(c0[e], scale); sc[k][1][e] = __fmul_rn(c1[e], scale); }
  }
  mA = NINF; mB = NINF;
#pragma unroll
  for (int k = 0; k < 8; k++)
#pragma unroll
    for (int h = 0; h < 2; h++)
#pragma unroll
      for (int e = 0; e < 2; e++) {
        const int pos = 16 * k + 8 * h + 2 * t + e;
        if (pos <= limA) mA = fmaxf(mA, sc[k][h][e]);
        if (pos <= limB) mB = fmaxf(mB, sc[k][h][2 + e]);
      }
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 1)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 1));
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 2)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 2));
  zA = 0.f; zB = 0.f;
#pragma unroll
  for (int i = 0; i < 16; i++) { acc[i][0] = 0.f; acc[i][1] = 0.f; acc[i][2] = 0.f; acc[i][3] = 0.f; }
#pragma unroll
  for (int k = 0; k < 8; k++) {
    if (k < npt) {
      uint4 vf[8];
#pragma unroll
      for (int e8 = 0; e8 < 8; e8++) vf[e8] = __ldcg(Vc + (k * ABL_KMUL + e8) * 32 + lane);
      unsigned wb[2][4]; float wf[2][4];
#pragma unroll
      for (int h = 0; h < 2; h++)
#pragma unroll
        for (int e = 0; e < 4; e++) {
          const int pos = 16 * k + 8 * h + 2 * t + (e & 1);
          const bool valid = pos <= (e < 2 ? limA : limB);
          const float w = cexp(__fsub_rn(sc[k][h][e], e < 2 ? mA : mB));
          wb[h][e] = valid ? (unsigned)f2bf(w) : 0u;
          wf[h][e] = bf2f(wb[h][e]);
        }
      zA = __fadd_rn(zA, __fadd_rn(__fadd_rn(wf[0][0], wf[0][1]), __fadd_rn(wf[1][0], wf[1][1])));
      zB = __fadd_rn(zB, __fadd_rn(__fadd_rn(wf[0][2], wf[0][3]), __fadd_rn(wf[1][2], wf[1][3])));
      const uint4 pa = make_uint4(wb[0][0] | (wb[0][1] << 16), wb[0][2] | (wb[0][3] << 16), wb[1][0] | (wb[1][1] << 16), wb[1][2] | (wb[1][3] << 16));
#pragma unroll
      for (int e8 = 0; e8 < 8; e8++) {
        const uint2 b0 = make_uint2(vf[e8].x, vf[e8].y), b1 = make_uint2(vf[e8].z, vf[e8].w);
        MMA(acc[2 * e8], pa, b0); MMA(acc[2 * e8 + 1], pa, b1);
      }
    }
  }
  zA = __fadd_rn(zA, __shfl_xor_sync(0xffffffffu, zA, 1)); zB = __fadd_rn(zB, __shfl_xor_sync(0xffffffffu, zB, 1));
  zA = __fadd_rn(zA, __shfl_xor_sync(0xffffffffu, zA, 2)); zB = __fadd_rn(zB, __shfl_xor_sync(0xffffffffu, zB, 2));
}

// q A-fragment of this lane for kstep ks: rows g8 (position iA, head h) and g8 + 8 (position iA + 2, head h)
__device__ __forceinline__ uint4 load_q(const Dev& D, int col0, int nq, int g, int ks, int lane) {
  const int g8 = lane >> 2, t = lane & 3, iA = g8 >> 2, h = g8 & 3;
  uint2 qa = make_uint2(0, 0), qb = make_uint2(0, 0);
  if (iA < nq) qa = __ldcg((const uint2*)D.qfrag + (((((size_t)(col0 + iA) * 8 + g) * 4 + h) * 8 + ks) * 4 + t));
  if (iA + 2 < nq) qb = __ldcg((const uint2*)D.qfrag + (((((size_t)(col0 + iA + 2) * 8 + g) * 4 + h) * 8 + ks) * 4 + t));
  return make_uint4(qa.x, qb.x, qa.y, qb.y);
}
// output of one row pair of this lane: bf16(O / Z) into the o projection's input fragments (K index = (4g + h) * 128 + d)
__device__ __forceinline__ void store_att(const Dev& D, int col0, int nq, int g, int lane, int e8, float oA0, float oA1, float oA2, float oA3,
                                          float oB0, float oB1, float oB2, float oB3, float rzA, float rzB) {
  const int g8 = lane >> 2, t = lane & 3, iA = g8 >> 2, h = g8 & 3;
  const int kstep = (4 * g + h) * 8 + e8;
  if (iA < nq) {
    const int col = col0 + iA;
    ((uint2*)D.afrag)[gword(kstep, t, col, KS_H)] =
        make_uint2(pack2(__fmul_rn(oA0, rzA), __fmul_rn(oA1, rzA)), pack2(__fmul_rn(oA2, rzA), __fmul_rn(oA3, rzA)));
  }
  if (iA + 2 < nq) {
    const int col = col0 + iA + 2;
    ((uint2*)D.afrag)[gword(kstep, t, col, KS_H)] =
        make_uint2(pack2(__fmul_rn(oB0, rzB), __fmul_rn(oB1, rzB)), pack2(__fmul_rn(oB2, rzB), __fmul_rn(oB3, rzB)));
  }
}

struct AttArgs { Dev d; int unit0; int n_units; int layer; int pos_add; };
#define AP_QS 0                               // uint4 [8 warps][8 ks][32]
#define AP_OT (A_WARPS * 8 * 32 * 16)         // float [8 warps][64][32]
#define AP_SMEM (AP_OT + A_WARPS * 64 * 32 * 4)
__global__ void __launch_bounds__(A_THREADS, 1) k_attn_pre(AttArgs a) {
  extern __shared__ __align__(16) unsigned char smem[];
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  uint4* qs = (uint4*)(smem + AP_QS) + w * 256;
  float* Ot = (float*)(smem + AP_OT) + w * 64 * 32 + lane;
  const int total = a.n_units * 8;
  for (int task = blockIdx.x * A_WARPS + w; task < total; task += gridDim.x * A_WARPS) {
    const int unit = a.unit0 + (task >> 3), g = task & 7;
    const int col0 = D.plan[PL_UNIT + 2 * unit], nq = D.plan[PL_UNIT + 2 * unit + 1];
    const int slot = D.plan[PL_SLOT + col0] & 0xffff, pos0 = D.plan[PL_POS + col0] + a.pos_add;
    const int tmax = pos0 + nq - 1, nseg = (tmax >> 7) + 1;
    const int iA = lane >> 4;
    const int tA = iA < nq ? pos0 + iA : -1, tB = iA + 2 < nq ? pos0 + iA + 2 : -1;
#pragma unroll
    for (int ks = 0; ks < 8; ks++) qs[ks * 32 + lane] = load_q(D, col0, nq, g, ks, lane);
#pragma unroll
    for (int i = 0; i < 64; i++) Ot[i * 32] = 0.f;
    float MA = NINF, MB = NINF, ZA = 0.f, ZB = 0.f;
    for (int s = 0; s < nseg; s++) {
      const int page = D.plan[PL_PT + slot * MAXPG + (s >> 2)];
      const uint4* Kc = D.kv + ((((size_t)page * NL + a.layer) * 8 + g) * 2) * PG_U4 + (size_t)((s & 3) * 8) * 256;
      const int npt = min(8, ((tmax - s * SEG) >> 4) + 1);
      float acc[16][4], mA, mB, zA, zB;
      seg_compute(qs, Kc, Kc + PG_U4, npt, tA - s * SEG, tB - s * SEG, lane, acc, mA, mB, zA, zB);
      float faA, fbA, faB, fbB, Mn;
      fold_factors(MA, mA, Mn, faA, fbA); MA = Mn; ZA = __fmaf_rn(ZA, faA, __fmul_rn(zA, fbA));
      fold_factors(MB, mB, Mn, faB, fbB); MB = Mn; ZB = __fmaf_rn(ZB, faB, __fmul_rn(zB, fbB));
#pragma unroll
      for (int i = 0; i < 16; i++) {
        Ot[(4 * i + 0) * 32] = __fmaf_rn(Ot[(4 * i + 0) * 32], faA, __fmul_rn(acc[i][0], fbA));
        Ot[(4 * i + 1) * 32] = __fmaf_rn(Ot[(4 * i + 1) * 32], faA, __fmul_rn(acc[i][1], fbA));
        Ot[(4 * i + 2) * 32] = __fmaf_rn(Ot[(4 * i + 2) * 32], faB, __fmul_rn(acc[i][2], fbB));
        Ot[(4 * i + 3) * 32] = __fmaf_rn(Ot[(4 * i + 3) * 32], faB, __fmul_rn(acc[i][3], fbB));
      }
    }
    const float rzA = __fdiv_rn(1.0f, ZA), rzB = __fdiv_rn(1.0f, ZB);
#pragma unroll
    for (int e8 = 0; e8 < 8; e8++)
      store_att(D, col0, nq, g, lane, e8, Ot[(8 * e8 + 0) * 32], Ot[(8 * e8 + 1) * 32], Ot[(8 * e8 + 4) * 32], Ot[(8 * e8 + 5) * 32],
                Ot[(8 * e8 + 2) * 32], Ot[(8 * e8 + 3) * 32], Ot[(8 * e8 + 6) * 32], Ot[(8 * e8 + 7) * 32], rzA, rzB);
  }
}

#define AD_QS 0                               // uint4 [8 ks][32]
#define AD_R (8 * 32 * 16)                    // float [8 warps][68][32]: o (64), mA, mB, zA, zB
#define AD_SMEM (AD_R + A_WARPS * 68 * 32 * 4)
__global__ void __launch_bounds__(A_THREADS, 1) k_attn_dec(AttArgs a) {
  extern __shared__ __align__(16) unsigned char smem[];
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  uint4* qs = (uint4*)(smem + AD_QS);
  float* R = (float*)(smem + AD_R);
  const int total = a.n_units * 8;
  for (int task = blockIdx.x; task < total; task += gridDim.x) {
    const int unit = a.unit0 + (task >> 3), g = task & 7;
    const int col0 = D.plan[PL_UNIT + 2 * unit], nq = D.plan[PL_UNIT + 2 * unit + 1];
    const int slot = D.plan[PL_SLOT + col0] & 0xffff, pos0 = D.plan[PL_POS + col0] + a.pos_add;
    const int tmax = pos0 + nq - 1, nseg = (tmax >> 7) + 1;
    const int iA = lane >> 4;
    const int tA = iA < nq ? pos0 + iA : -1, tB = iA + 2 < nq ? pos0 + iA + 2 : -1;
    if (w == 0) {
#pragma unroll
      for (int ks = 0; ks < 8; ks++) qs[ks * 32 + lane] = load_q(D, col0, nq, g, ks, lane);
    }
    __syncthreads();
    float Ot[16][4];
#pragma unroll
    for (int i = 0; i < 16; i++) { Ot[i][0] = 0.f; Ot[i][1] = 0.f; Ot[i][2] = 0.f; Ot[i][3] = 0.f; }
    float MA = NINF, MB = NINF, ZA = 0.f, ZB = 0.f;
    for (int s0 = 0; s0 < nseg; s0 += A_WARPS) {
      const int s = s0 + w;
      if (s < nseg) {
        const int page = D.plan[PL_PT + slot * MAXPG + (s >> 2)];
        const uint4* Kc = D.kv + ((((size_t)page * NL + a.layer) * 8 + g) * 2) * PG_U4 + (size_t)((s & 3) * 8) * 256;
        const int npt = min(8, ((tmax - s * SEG) >> 4) + 1);
        float acc[16][4], mA, mB, zA, zB;
        seg_compute(qs, Kc, Kc + PG_U4, npt, tA - s * SEG, tB - s * SEG, lane, acc, mA, mB, zA, zB);
        float* r = R + (w * 68) * 32 + lane;
#pragma unroll
        for (int i = 0; i < 16; i++) { r[(4 * i) * 32] = acc[i][0]; r[(4 * i + 1) * 32] = acc[i][1]; r[(4 * i + 2) * 32] = acc[i][2]; r[(4 * i + 3) * 32] = acc[i][3]; }
        r[64 * 32] = mA; r[65 * 32] = mB; r[66 * 32] = zA; r[67 * 32] = zB;
      }
      __syncthreads();
      if (w == 0) {
        const int nr = min((int)A_WARPS, nseg - s0);
        for (int q = 0; q < nr; q++) {
          const float* r = R + (q * 68) * 32 + lane;
          float faA, fbA, faB, fbB, Mn;
          fold_factors(MA, r[64 * 32], Mn, faA, fbA); MA = Mn; ZA = __fmaf_rn(ZA, faA, __fmul_rn(r[66 * 32], fbA));
          fold_factors(MB, r[65 * 32], Mn, faB, fbB); MB = Mn; ZB = __fmaf_rn(ZB, faB, __fmul_rn(r[67 * 32], fbB));
#pragma unroll
          for (int i = 0; i < 16; i++) {
            Ot[i][0] = __fmaf_rn(Ot[i][0], faA, __fmul_rn(r[(4 * i + 0) * 32], fbA));
            Ot[i][1] = __fmaf_rn(Ot[i][1], faA, __fmul_rn(r[(4 * i + 1) * 32], fbA));
            Ot[i][2] = __fmaf_rn(Ot[i][2], faB, __fmul_rn(r[(4 * i + 2) * 32], fbB));
            Ot[i][3] = __fmaf_rn(Ot[i][3], faB, __fmul_rn(r[(4 * i + 3) * 32], fbB));
          }
        }
      }
      __syncthreads();
    }
    if (w == 0) {
      const float rzA = __fdiv_rn(1.0f, ZA), rzB = __fdiv_rn(1.0f, ZB);
#pragma unroll
      for (int e8 = 0; e8 < 8; e8++)
        store_att(D, col0, nq, g, lane, e8, Ot[2 * e8][0], Ot[2 * e8][1], Ot[2 * e8 + 1][0], Ot[2 * e8 + 1][1],
                  Ot[2 * e8][2], Ot[2 * e8][3], Ot[2 * e8 + 1][2], Ot[2 * e8 + 1][3], rzA, rzB);
    }
    __syncthreads();
  }
}

// ---------------------------------------------------------------------------------------------------------
// lm_head helpers: gather the selected columns' final-norm input; reduce the per-warp maxima to a token
// ---------------------------------------------------------------------------------------------------------
struct SelArgs { Dev d; int n_sel; long long* out64; int out_stride; int out_step; };
__global__ void __launch_bounds__(256) k_gather(SelArgs a) {
  const Dev& D = a.d;
  for (int j = blockIdx.x; j < a.n_sel; j += gridDim.x) {
    const int col = D.plan[PL_SEL + 2 * j];
    for (int i = threadIdx.x; i < KS_H * 4; i += 256)
      ((uint2*)D.lmfrag)[gword(i >> 2, i & 3, j, KS_H)] = __ldcg((const uint2*)D.xfrag + gword(i >> 2, i & 3, col, KS_H));
    if (threadIdx.x == 0) D.lm_rn[j] = __ldcg(D.rn + col);
  }
}
__global__ void __launch_bounds__(256) k_argmax(SelArgs a) {
  const Dev& D = a.d;
  __shared__ float sv[8]; __shared__ int si[8];
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const int ncand = LM_T / 4;
  for (int j = blockIdx.x; j < a.n_sel; j += gridDim.x) {
    float bv = NINF; int bi = 0x7fffffff;
    for (int i = threadIdx.x; i < ncand; i += 256) {
      float v = __ldcg(D.bm_val + (size_t)i * a.n_sel + j); int ix = __ldcg(D.bm_idx + (size_t)i * a.n_sel + j);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
#pragma unroll
    for (int o = 16; o > 0; o >>= 1) {
      float v = __shfl_xor_sync(0xffffffffu, bv, o); int ix = __shfl_xor_sync(0xffffffffu, bi, o);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
    if (lane == 0) { sv[w] = bv; si[w] = bi; }
    __syncthreads();
    if (threadIdx.x == 0) {
      for (int i = 1; i < 8; i++) if (sv[i] > bv || (sv[i] == bv && si[i] < bi)) { bv = sv[i]; bi = si[i]; }
      D.sel_tok[j] = bi;
      const int slot = D.plan[PL_SEL + 2 * j + 1];
      if (slot >= 0) D.last_tok[slot] = bi;
      if (a.out64) a.out64[(size_t)j * a.out_stride + a.out_step] = bi;
    }
    __syncthreads();
  }
}

// test helper: fill a page with NaN (bf16 0x7fc0)
__global__ void k_fill16(unsigned short* p, size_t n, unsigned short v) {
  for (size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x; i < n; i += (size_t)gridDim.x * blockDim.x) p[i] = v;
}

// ---------------------------------------------------------------------------------------------------------
// host API
// ---------------------------------------------------------------------------------------------------------
#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "CUDA error %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); abort(); } } while (0)

struct Eng {
  Dev D;
  int nsm, n_pages;
  int* plan_dev;
  long long passes, launches, plan_uploads, tok_reads;
  int force_shape;
};

// Block shape: the largest of 2x4, 2x2, 1x2, 1x1 warps (64 rows x 64 columns each) that still gives every SM a unit
template <int EP>
static void launch_gemm(Eng* E, GemmArgs g) {
  static const int shapes[4][2] = {{2, 4}, {2, 2}, {1, 2}, {1, 1}};
  const int npair = (g.T + 15) >> 4;
  int n_units = 0;
  for (int i = 0; i < 4; i++) {
    g.nwr = shapes[i][0]; g.nwc = shapes[i][1];
    n_units = (g.m_tiles / (4 * g.nwr)) * ((npair + 4 * g.nwc - 1) / (4 * g.nwc));
    if (E->force_shape >= 0 ? i == E->force_shape : n_units * 10 >= E->nsm * 9) break;
  }
  const int grid = n_units < E->nsm ? n_units : E->nsm;
  k_gemm<EP><<<grid, G_THREADS, G_SMEM>>>(g);
  E->launches++;
}

extern "C" {

void* eng_create(int n_pages, const void* W, const void* embed, const void* norm_w, const void* qk_norm_w, const void* rope) {
  Eng* E = new Eng();
  memset(E, 0, sizeof(Eng));
  int dev = 0; CK(cudaGetDevice(&dev));
  cudaDeviceProp prop; CK(cudaGetDeviceProperties(&prop, dev));
  E->nsm = prop.multiProcessorCount;
  E->n_pages = n_pages;
  E->force_shape = getenv("MK_GEMM_SHAPE") ? atoi(getenv("MK_GEMM_SHAPE")) : -1;
  Dev& D = E->D;
  D.W = (const uint4*)W; D.embed = (const unsigned short*)embed; D.norm_w = (const float*)norm_w;
  D.qk_norm_w = (const float*)qk_norm_w; D.rope = (const float*)rope;
  CK(cudaMalloc(&D.kv, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMalloc(&E->plan_dev, sizeof(int) * PL_INTS)); D.plan = E->plan_dev;
  CK(cudaMalloc(&D.x, sizeof(float) * (size_t)TCAP * H));
  CK(cudaMalloc(&D.xfrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.ssq, sizeof(float) * (size_t)TCAP * 256));
  CK(cudaMalloc(&D.rn, sizeof(float) * TCAP));
  CK(cudaMalloc(&D.qkv, sizeof(float) * (size_t)TCAP * QKV_ROWS));
  CK(cudaMalloc(&D.qfrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.afrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.mfrag, (size_t)TCAP * INNER * 2));
  CK(cudaMalloc(&D.lmfrag, (size_t)SELCAP * H * 2));
  CK(cudaMalloc(&D.lm_rn, sizeof(float) * SELCAP));
  CK(cudaMalloc(&D.bm_val, sizeof(float) * (size_t)(LM_T / 4) * SELCAP));
  CK(cudaMalloc(&D.bm_idx, sizeof(int) * (size_t)(LM_T / 4) * SELCAP));
  CK(cudaMalloc(&D.last_tok, sizeof(int) * NSLOT));
  CK(cudaMalloc(&D.sel_tok, sizeof(int) * SELCAP));
  CK(cudaMemset(D.kv, 0, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMemset(D.xfrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.afrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.mfrag, 0, (size_t)TCAP * INNER * 2));
  CK(cudaMemset(D.lmfrag, 0, (size_t)SELCAP * H * 2));
  CK(cudaMemset(D.last_tok, 0, sizeof(int) * NSLOT));
  CK(cudaMemset(E->plan_dev, 0, sizeof(int) * PL_INTS));
  CK(cudaFuncSetAttribute(k_gemm<EP_QKV>, cudaFuncAttributeMaxDynamicSharedMemorySize, G_SMEM));
  CK(cudaFuncSetAttribute(k_gemm<EP_ADD>, cudaFuncAttributeMaxDynamicSharedMemorySize, G_SMEM));
  CK(cudaFuncSetAttribute(k_gemm<EP_GU>, cudaFuncAttributeMaxDynamicSharedMemorySize, G_SMEM));
  CK(cudaFuncSetAttribute(k_gemm<EP_LM>, cudaFuncAttributeMaxDynamicSharedMemorySize, G_SMEM));
  CK(cudaFuncSetAttribute(k_gemm<EP_LMARG>, cudaFuncAttributeMaxDynamicSharedMemorySize, G_SMEM));
  CK(cudaFuncSetAttribute(k_gemm<EP_RAW>, cudaFuncAttributeMaxDynamicSharedMemorySize, G_SMEM));
  CK(cudaFuncSetAttribute(k_attn_pre, cudaFuncAttributeMaxDynamicSharedMemorySize, AP_SMEM));
  CK(cudaFuncSetAttribute(k_attn_dec, cudaFuncAttributeMaxDynamicSharedMemorySize, AD_SMEM));
  return E;
}

int eng_plan_ints() { return PL_INTS; }
int eng_tcap() { return TCAP; }
int eng_selcap() { return SELCAP; }
size_t eng_page_bytes() { return PAGE_BYTES; }

// copy the plan (host ints, layout PL_*) to the device. `n` leading ints are copied.
void eng_set_plan(void* h, const int* plan, int off, int n) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->plan_dev + off, plan + off, sizeof(int) * (size_t)n, cudaMemcpyHostToDevice));
  E->plan_uploads++;
}

// One pass over the weights for the T columns of the current plan.
//   pos_add: added to every column's position (step()/generate() reuse one plan)
//   tok64:   device int64 [T] input tokens, or null (tokens from the plan / the slots' last tokens)
//   logits:  device float [n_sel][VOCAB] or null (then only the argmax: sel_tok, last_tok, out64)
void eng_pass(void* h, int T, int n_pre, int n_dec, int n_sel, int pos_add, const void* tok64, void* logits, void* out64, int out_stride, int out_step) {
  Eng* E = (Eng*)h;
  const Dev& D = E->D;
  const int nsm = E->nsm;
  EmbedArgs ea{D, T, pos_add, (const long long*)tok64};
  k_embed<<<T < 4 * nsm ? T : 4 * nsm, 256>>>(ea);
  RnArgs ra{D.ssq, D.rn, T};
  const int rn_grid = (T + 7) / 8 < nsm ? (T + 7) / 8 : nsm;
  for (int l = 0; l < NL; l++) {
    const uint4* WL = D.W + (size_t)l * LAYER_U4;
    k_rnorm<<<rn_grid, 256>>>(ra);
    GemmArgs g{};
    g.W = WL + OFF_QKV; g.X = (const uint4*)D.xfrag; g.m_tiles = QKV_T; g.ks = KS_H; g.T = T; g.rn = D.rn; g.out = D.qkv;
    launch_gemm<EP_QKV>(E, g);
    PrepArgs pa{D, T, l, pos_add};
    const int pgrid = (T * 48 + 15) / 16 < 2 * nsm ? (T * 48 + 15) / 16 : 2 * nsm;
    k_prep<<<pgrid, 512>>>(pa);
    if (n_pre > 0) {   // units 0 .. n_pre-1: one warp per (unit, kv head)
      AttArgs aa{D, 0, n_pre, l, pos_add};
      k_attn_pre<<<n_pre < nsm ? n_pre : nsm, A_THREADS, AP_SMEM>>>(aa);
    }
    if (n_dec > 0) {   // units n_pre .. : one block per (unit, kv head)
      AttArgs aa{D, n_pre, n_dec, l, pos_add};
      k_attn_dec<<<n_dec * 8 < nsm ? n_dec * 8 : nsm, A_THREADS, AD_SMEM>>>(aa);
    }
    g = GemmArgs{};
    g.W = WL + OFF_O; g.X = (const uint4*)D.afrag; g.m_tiles = O_T; g.ks = KS_H; g.T = T;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 1) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g);
    k_rnorm<<<rn_grid, 256>>>(ra);
    g = GemmArgs{};
    g.W = WL + OFF_GU; g.X = (const uint4*)D.xfrag; g.m_tiles = GU_T; g.ks = KS_H; g.T = T; g.rn = D.rn; g.frag = D.mfrag;
    launch_gemm<EP_GU>(E, g);
    g = GemmArgs{};
    g.W = WL + OFF_DN; g.X = (const uint4*)D.mfrag; g.m_tiles = DN_T; g.ks = KS_I; g.T = T;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 2) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g);
    E->launches += 5;
  }
  if (n_sel > 0) {
    k_rnorm<<<rn_grid, 256>>>(ra);
    SelArgs sa{D, n_sel, (long long*)out64, out_stride, out_step};
    k_gather<<<n_sel, 256>>>(sa);
    GemmArgs g{};
    g.W = D.W + (size_t)NL * LAYER_U4; g.X = (const uint4*)D.lmfrag; g.m_tiles = LM_T; g.ks = KS_H; g.T = n_sel; g.rn = D.lm_rn;
    if (logits) { g.out = (float*)logits; launch_gemm<EP_LM>(E, g); }
    else {
      g.bm_val = D.bm_val; g.bm_idx = D.bm_idx;
      launch_gemm<EP_LMARG>(E, g);
      k_argmax<<<n_sel, 256>>>(sa);
    }
    E->launches += 3;
  }
  E->launches += 1;
  E->passes++;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) fprintf(stderr, "eng_pass: launch error: %s\n", cudaGetErrorString(e));
}

// tokens of the last pass (blocks until the pass is done: one host sync)
void eng_read_tokens(void* h, int* out, int n_sel) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(out, E->D.sel_tok, sizeof(int) * (size_t)n_sel, cudaMemcpyDeviceToHost));
  E->tok_reads++;
}

void eng_set_last_tok(void* h, int slot, int tok) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->D.last_tok + slot, &tok, sizeof(int), cudaMemcpyHostToDevice));
}

// tests: poison a page's K and V with NaN
void eng_poison_page(void* h, int page) {
  Eng* E = (Eng*)h;
  k_fill16<<<256, 256>>>((unsigned short*)((char*)E->D.kv + PAGE_BYTES * (size_t)page), PAGE_BYTES / 2, (unsigned short)0x7fc0);
}

// tests / bench: a bare matvec through the GEMM kernel. X: fragments [ceil(T/8)][ks][32][4] bf16; out [T][16 m_tiles] f32
void eng_gemm_raw(void* h, const void* W, const void* X, void* out, int m_tiles, int ks, int T) {
  Eng* E = (Eng*)h;
  GemmArgs g{};
  g.W = (const uint4*)W; g.X = (const uint4*)X; g.m_tiles = m_tiles; g.ks = ks; g.T = T; g.out = (float*)out;
  launch_gemm<EP_RAW>(E, g);
}

long long eng_stat(void* h, int which) {
  Eng* E = (Eng*)h;
  return which == 0 ? E->launches : which == 1 ? E->passes : which == 2 ? E->nsm : which == 3 ? E->plan_uploads : which == 4 ? E->tok_reads : 0;
}

void eng_sync() { CK(cudaDeviceSynchronize()); }

void eng_destroy(void* h) {
  Eng* E = (Eng*)h;
  cudaDeviceSynchronize();
  Dev& D = E->D;
  cudaFree(D.kv); cudaFree(E->plan_dev); cudaFree(D.x); cudaFree(D.xfrag); cudaFree(D.ssq); cudaFree(D.rn); cudaFree(D.qkv);
  cudaFree(D.qfrag); cudaFree(D.afrag); cudaFree(D.mfrag); cudaFree(D.lmfrag); cudaFree(D.lm_rn); cudaFree(D.bm_val);
  cudaFree(D.bm_idx); cudaFree(D.last_tok); cudaFree(D.sel_tok);
  delete E;
}

}  // extern "C"
