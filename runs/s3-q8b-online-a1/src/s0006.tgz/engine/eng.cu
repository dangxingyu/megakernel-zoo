// Online engine for Qwen3-8B (bf16) on one H100: a "pass" runs T token columns (decode rows and prefill chunks
// together) once over the weights. Every column's arithmetic is independent of the other columns of the pass,
// of where a prefill is cut into chunks and of whether its prefix K/V came from a cache.
//
// Canonical arithmetic (what makes batching / chunking / prefix reuse invisible):
//  * matvec: y[row] = one f32 accumulator per (row, column), 16 input dims per tensor-core instruction
//    (wgmma m64nNk16, bf16 x bf16 -> f32), dims ascending. Inputs are bf16.
//  * attention of a query at position t over keys 0..t. Positions are cut (at absolute positions) into
//    segments of 128 and super-segments of 128 << SS_LOG.
//    q is stored as bf16(q * log2 e / sqrt(128)), so a score s_j = q . k_j (MMA over the 8 dim-ksteps, f32)
//    is in units of log2. State of a query inside a super-segment: (M, Z, O), starting at (-inf, 0, 0).
//    Per segment, in ascending order: m = max of s_j over the valid positions, R = max(M, m),
//    a = 2^(M - R) (exactly 1 when M == R, 0 for M = -inf), O *= a, Z *= a, w_j = bf16(2^(s_j - R)) (0 for
//    j > t), O += sum_j w_j V_j and Z += sum_j w_j (one MMA per position tile and dim group, tiles
//    ascending, accumulating into O and Z; Z through a V column of ones), M = R.
//    The super-segments of a query are folded in ascending order from (-inf, 0, 0): M' = max(M, m),
//    a = 2^(M - M'), b = 2^(m - M') (exactly 1 / 0 as above), Z' = Z a + z b, O' = O a + o b.
//    Output = bf16(O * (1 / Z)).
//    So a (query, super-segment) part can be computed anywhere, in any pass, next to any other work.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#define H 4096
#define NL 36
#define QKV_ROWS 6144
#define INNER 12288
#define VOCAB 151936
#define QKV_T 384
#define O_T 256
#define GU_T 1536
#define DN_T 256
#define LM_T 9496
#define KS_H 256
#define KS_I 768
#define OFF_QKV 0ull
#define OFF_O (OFF_QKV + (size_t)QKV_T * KS_H * 32)
#define OFF_GU (OFF_O + (size_t)O_T * KS_H * 32)
#define OFF_DN (OFF_GU + (size_t)GU_T * KS_H * 32)
#define LAYER_U4 (OFF_DN + (size_t)DN_T * KS_I * 32)

#define NSLOT 64
#define MAXPG 68                         // pages per sequence: 34816 / 512
#define PG_TILES 32                      // a page = 512 positions = 32 position tiles
#define PG_U4 (PG_TILES * 8 * 32)        // uint4 per (page, layer, kv head) for K; the same again for V
#define PAGE_BYTES ((size_t)NL * 8 * 2 * PG_U4 * 16)
#define SEG 128                          // attention segment (positions)

#ifndef TCAP
#define TCAP 2048                        // columns per pass at most
#endif
#define SELCAP 256                       // columns per pass that need logits / a token
// plan buffer (ints), written by the host before a pass
#define MAXU 768                         // attention units per pass
#define MAXWT 4096                       // warp tasks per pass
#define MAXBT 32768                      // block tasks per pass
#ifndef SS_LOG
#define SS_LOG 5
#endif
#define SS_SEGS (1 << SS_LOG)            // segments per super-segment
#define SS_SHIFT (7 + SS_LOG)            // log2 of the positions of a super-segment
#define PARTCAP (SS_LOG == 5 ? 6144 : SS_LOG == 4 ? 10240 : 20480)   // (unit, super-segment) parts kept in the scratch per pass
#define PL_SLOT 0                        // [TCAP] slot | (last column of its run ? LASTBIT : 0) | (column - first column of its attention unit) << 17
#define PL_POS (TCAP)                    // [TCAP] position of the column in its sequence
#define PL_TOK (2 * TCAP)                // [TCAP] token id, or -1: the slot's last generated token
#define PL_UNIT (3 * TCAP)               // [MAXU][4] attention units (<= 4 consecutive positions of one sequence): first column, columns, first part in the scratch (-1: one super-segment, no fold), unused
#define PL_WT (PL_UNIT + 4 * MAXU)       // [MAXWT] warp tasks: unit | super-segment << 16
#define PL_BT (PL_WT + MAXWT)            // [MAXBT] block tasks: first unit | units (<= 8) << 12 | super-segment << 16 | kv head << 22
#define PL_FOLD (PL_BT + MAXBT)          // [MAXU] units whose super-segments have to be folded
#define PL_SEL (PL_FOLD + MAXU)          // [SELCAP][2]: column, slot (-1: none)
#define PL_PT (PL_SEL + 2 * SELCAP)      // [NSLOT][MAXPG] page ids
#define PL_CU (PL_PT + NSLOT * MAXPG)     // [TCAP] attention unit of the column
#define PL_INTS (PL_CU + TCAP)
#define LASTBIT 0x10000

#define MMA(c, a, b) asm volatile( \
  "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
  : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3]) \
  : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y))

__device__ __forceinline__ unsigned short f2bf(float f) {
  unsigned u = __float_as_uint(f);
  u += 0x7fffu + ((u >> 16) & 1u);
  return (unsigned short)(u >> 16);
}
__device__ __forceinline__ float bf2f(unsigned v) { return __uint_as_float(v << 16); }
__device__ __forceinline__ int frag_slot(int k) { return (k & 1) + 2 * ((k >> 3) & 1); }
__device__ __forceinline__ int frag_t(int k) { return (k & 7) >> 1; }
// Layout of every GEMM operand in global memory, weights [M rows][K] and activations [columns][K] alike
// ("rows" below are M rows or token columns): [k / 64][row / 8][(k % 64) / 8][row % 8][k % 8] in bf16 elements.
// One (K chunk of 64, 8 rows) is 1 KB; inside it the 8 rows x 8 K-elements of each K-octet are 128 contiguous
// bytes. A K chunk of consecutive row groups is therefore one contiguous byte range that the copy engine moves
// into shared memory as it is, and there it is the canonical K-major operand of wgmma (no swizzle: leading
// offset 128 B between the two K-octets of an instruction, stride 1 KB between groups of 8 rows).
__device__ __forceinline__ size_t xidx(int k, int row, int groups) {
  return ((((size_t)(k >> 6) * groups + (row >> 3)) * 8 + ((k >> 3) & 7)) * 8 + (row & 7)) * 8 + (k & 7);
}
#define NG_X (TCAP / 8)      // column groups of the activation buffers
#define NG_LM (SELCAP / 8)   // ... of the lm_head input
__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
#define NINF (-__int_as_float(0x7f800000))
#define SC2 ((float)(0.08838834764831845 * 1.4426950408889634))   // log2(e) / sqrt(128)

// ---------------------------------------------------------------------------------------------------------
// GEMM: Y[M x T] = W[M x K] X[K x T] on the Hopper path.
//   * wgmma: one instruction of a warpgroup (4 warps) multiplies 64 rows x NB columns x 16 K, both operands read
//     from shared memory through descriptors, accumulators in registers (NB / 2 per thread);
//   * cp.async.bulk: the copy engine moves a contiguous byte range global -> shared memory; no warp loads
//     anything, so the copy overlaps the multiply completely;
//   * mbarriers: a stage (K chunk of 64) is "full" when its bytes have arrived, "empty" when both consumer
//     warpgroups are done with it.
// A block = 2 consumer warpgroups + 1 producer warp: 128 rows x 2 NB columns (warpgroup w: columns w * NB ..),
// 4 stages of (A: 128 rows x 64 K = 16 KB, B: 2 NB columns x 64 K) in shared memory. Block b takes units
// b, b + grid, ... in row-major order: the SMs work on a window of row blocks whose weights stay in L2 while
// every column block of them is computed.
// Why this path (all measured here, T = 1024, 24576 x 4096): my m16n8k16 kernels with warp loads into shared
// memory reached 255 / 334 / 292 / 301 TFLOPS in four designs. tests/copy_rate.cu: an SM copies global -> shared
// memory at 10 KB/us per loading warp up to ~55 KB/us; tests/roles_rate.cu, tests/l1_stage.cu: while it does,
// the multiplies stall (same warps, other warps, or L1 as the buffer: always copy time + multiply time).
// The vendor GEMM runs at 790-820 TFLOPS on these shapes; its launch (132 blocks x 384 threads, 168 registers,
// 213 KB shared memory, "64x4" in the kernel name) pointed to wgmma + the copy engine. This kernel: 738 TFLOPS,
// and 2.2-2.8 TB/s of weights at T <= 64 (the old one: 1.2), tests/wg_bench.cu.
// Instruction forms after CUTLASS (cute/arch/mma_sm90_gmma.hpp, copy_sm90_tma.hpp, cutlass/arch/barrier.h).
// ---------------------------------------------------------------------------------------------------------
#include "wg_gen.h"
#define WG_STAGES 4
#define WG_KC 64                               // K per stage: 4 wgmma instructions per 64-row tile
#define WG_A_STAGE (128 * WG_KC * 2)
#define WG_THREADS 288
#define WG_SMEM(NB) (WG_STAGES * (WG_A_STAGE + 2 * (NB) * WG_KC * 2) + 64)
__device__ __forceinline__ uint32_t sm32(const void* p) { return (uint32_t)__cvta_generic_to_shared(p); }
__device__ __forceinline__ void mbar_init(uint64_t* b, uint32_t count) { asm volatile("mbarrier.init.shared::cta.b64 [%1], %0;" :: "r"(count), "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_arrive(uint64_t* b) { asm volatile("mbarrier.arrive.shared::cta.b64 _, [%0];" :: "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_expect(uint64_t* b, uint32_t bytes) { asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%1], %0;" :: "r"(bytes), "r"(sm32(b)) : "memory"); }
__device__ __forceinline__ void mbar_wait(uint64_t* b, uint32_t phase) {
  asm volatile("{\n.reg .pred P1;\nLAB_WAIT:\nmbarrier.try_wait.parity.shared::cta.b64 P1, [%0], %1;\n@P1 bra DONE;\nbra LAB_WAIT;\nDONE:\n}" :: "r"(sm32(b)), "r"(phase) : "memory");
}
__device__ __forceinline__ void bulk_g2s(void* smem_dst, const void* gsrc, uint32_t bytes, uint64_t* b) {
  asm volatile("cp.async.bulk.shared::cluster.global.mbarrier::complete_tx::bytes [%0], [%1], %2, [%3];" :: "r"(sm32(smem_dst)), "l"(gsrc), "r"(bytes), "r"(sm32(b)) : "memory");
}
__device__ __forceinline__ uint64_t wg_desc(const void* smem_ptr) {
  return (uint64_t)((sm32(smem_ptr) >> 4) & 0x3fff) | ((uint64_t)8 << 16) | ((uint64_t)64 << 32);
}
template <int NB> struct WG;
template <> struct WG<16> { static __device__ __forceinline__ void mma(float (&d)[8], uint64_t da, uint64_t db) { WGMMA_N16(d, da, db); } };
template <> struct WG<32> { static __device__ __forceinline__ void mma(float (&d)[16], uint64_t da, uint64_t db) { WGMMA_N32(d, da, db); } };
template <> struct WG<64> { static __device__ __forceinline__ void mma(float (&d)[32], uint64_t da, uint64_t db) { WGMMA_N64(d, da, db); } };
template <> struct WG<128> { static __device__ __forceinline__ void mma(float (&d)[64], uint64_t da, uint64_t db) { WGMMA_N128(d, da, db); } };

enum { EP_QKV = 0, EP_ADD = 1, EP_GU = 2, EP_LM = 3, EP_LMARG = 4, EP_RAW = 5 };

struct GemmArgs {
  const unsigned short* W;   // weights [M][K] in the operand layout (see xidx)
  const unsigned short* X;   // activations [columns][K] in the operand layout with NG column groups
  int M, K, T, NG;
  const float* rn;        // [T] 1/rms of the input norm (QKV, GU, LM)
  float* out;             // QKV: [T][6144]; LM: logits [T][VOCAB]; RAW: [T][M]
  float* x;               // ADD: residual stream [T][4096]
  const float* aux;       // ADD: weights of the next RMSNorm [4096]
  unsigned short* frag;   // ADD: next norm's input (K = 4096); GU: silu(gate)*up (K = 12288); operand layout, NG_X groups
  float* ssq;             // ADD: [T][256] per-16-row sums of x^2
  float* bm_val; int* bm_idx;   // LMARG: [M / 32][T] best logit and its row per (row block, warp)
};

template <int EP, int NB>
__global__ void __launch_bounds__(WG_THREADS, 1) k_gemm(GemmArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  enum { B_STAGE = 2 * NB * WG_KC * 2, STAGE = WG_A_STAGE + B_STAGE };
  uint64_t* full = (uint64_t*)(smem + WG_STAGES * STAGE);
  uint64_t* empty = full + WG_STAGES;
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5, wg = warp >> 2;
  if (tid == 0) {
    for (int s = 0; s < WG_STAGES; s++) { mbar_init(full + s, 1); mbar_init(empty + s, 2); }
    asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  }
  __syncthreads();
  const int n_cb = (a.T + 2 * NB - 1) / (2 * NB), n_rb = a.M / 128, n_units = n_rb * n_cb, nchunk = a.K / WG_KC;
  const int mg = a.M / 8;
  unsigned gc = 0;                               // chunks so far: the producer and the consumers count alike
  if (wg == 2) {
    // ---- producer: one thread asks the copy engine for A and B of every chunk, up to WG_STAGES ahead
    if (lane != 0) return;
    for (int u = blockIdx.x; u < n_units; u += gridDim.x) {
      const int rb = u / n_cb, cb = u - rb * n_cb;
      for (int c = 0; c < nchunk; c++, gc++) {
        const int s = gc % WG_STAGES; const unsigned r = gc / WG_STAGES;
        if (r >= 1) mbar_wait(empty + s, (r - 1) & 1);
        mbar_expect(full + s, STAGE);
        bulk_g2s(smem + s * STAGE, a.W + ((size_t)c * mg + rb * 16) * 512, WG_A_STAGE, full + s);
        bulk_g2s(smem + s * STAGE + WG_A_STAGE, a.X + ((size_t)c * a.NG + cb * (NB / 4)) * 512, B_STAGE, full + s);
      }
    }
    return;
  }
  // ---- consumers: warpgroup wg computes rows 0..127 x columns wg * NB .. + NB - 1 of the block
  for (int u = blockIdx.x; u < n_units; u += gridDim.x) {
    const int rb = u / n_cb, cb = u - rb * n_cb;
    float acc[2][NB / 2];
#pragma unroll
    for (int i = 0; i < 2; i++)
#pragma unroll
      for (int j = 0; j < NB / 2; j++) acc[i][j] = 0.f;
    for (int c = 0; c < nchunk; c++, gc++) {
      const int s = gc % WG_STAGES; const unsigned r = gc / WG_STAGES;
      mbar_wait(full + s, r & 1);
      const unsigned char* As = smem + s * STAGE;
      const unsigned char* Bs = As + WG_A_STAGE + wg * (NB * WG_KC * 2);
      asm volatile("wgmma.fence.sync.aligned;" ::: "memory");
#pragma unroll
      for (int j = 0; j < WG_KC / 16; j++) {
        const uint64_t db = wg_desc(Bs + j * 256);
        WG<NB>::mma(acc[0], wg_desc(As + j * 256), db);
        WG<NB>::mma(acc[1], wg_desc(As + 8192 + j * 256), db);
      }
      asm volatile("wgmma.commit_group.sync.aligned;" ::: "memory");
      asm volatile("wgmma.wait_group.sync.aligned 0;" ::: "memory");
      if ((tid & 127) == 0) mbar_arrive(empty + s);
    }
    // ---- epilogue. Register 4 j + e of thread (warp t2 of the group, lane (g, t)) of the 64-row tile i holds
    // column group j of the warpgroup, e: 0 (row g, col 2t), 1 (row g, col 2t+1), 2 (row g+8, col 2t), 3 (row g+8, col 2t+1)
    // with rows relative to the 16-row tile 4 i + t2 of the block.
    {
      const int g = lane >> 2, t = lane & 3, t2 = warp & 3;
#pragma unroll
      for (int j = 0; j < NB / 8; j++) {
        const int n0 = cb * 2 * NB + wg * NB + 8 * j + 2 * t, n1 = n0 + 1;
        const bool v0 = n0 < a.T, v1 = n1 < a.T;
        float r0 = 0.f, r1 = 0.f;
        float bv0 = NINF, bv1 = NINF; int bi0 = 0x7fffffff, bi1 = 0x7fffffff;
        if (EP == EP_QKV || EP == EP_GU || EP == EP_LM || EP == EP_LMARG) {
          if (v0) r0 = __ldcg(a.rn + n0);
          if (v1) r1 = __ldcg(a.rn + n1);
        }
#pragma unroll
        for (int i = 0; i < 2; i++) {
          const int tile = rb * 8 + 4 * i + t2;
          const int row = tile * 16 + g;
          const float* cc = &acc[i][4 * j];
          if (EP == EP_QKV || EP == EP_LM || EP == EP_RAW) {
            const size_t stride = EP == EP_QKV ? QKV_ROWS : (EP == EP_LM ? VOCAB : (size_t)a.M);
            const float q0 = EP == EP_RAW ? 1.f : r0, q1 = EP == EP_RAW ? 1.f : r1;
            if (v0) { a.out[(size_t)n0 * stride + row] = cc[0] * q0; a.out[(size_t)n0 * stride + row + 8] = cc[2] * q0; }
            if (v1) { a.out[(size_t)n1 * stride + row] = cc[1] * q1; a.out[(size_t)n1 * stride + row + 8] = cc[3] * q1; }
          } else if (EP == EP_GU) {
            const int jr = tile * 8 + g;   // rows 0..7 of the tile are gate[jr], rows 8..15 are up[jr]
            if (v0) { float gt = cc[0] * r0; float m = gt / (1.0f + __expf(-gt)) * (cc[2] * r0); a.frag[xidx(jr, n0, NG_X)] = f2bf(m); }
            if (v1) { float gt = cc[1] * r1; float m = gt / (1.0f + __expf(-gt)) * (cc[3] * r1); a.frag[xidx(jr, n1, NG_X)] = f2bf(m); }
          } else if (EP == EP_ADD) {
            const float w0 = a.aux[row], w1 = a.aux[row + 8];
            float s0 = 0.f, s1 = 0.f;
            if (v0) {
              float* p = a.x + (size_t)n0 * H + row;
              float xa = __ldcg(p) + cc[0], xb = __ldcg(p + 8) + cc[2];
              p[0] = xa; p[8] = xb;
              a.frag[xidx(row, n0, NG_X)] = f2bf(w0 * xa);
              a.frag[xidx(row + 8, n0, NG_X)] = f2bf(w1 * xb);
              s0 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            if (v1) {
              float* p = a.x + (size_t)n1 * H + row;
              float xa = __ldcg(p) + cc[1], xb = __ldcg(p + 8) + cc[3];
              p[0] = xa; p[8] = xb;
              a.frag[xidx(row, n1, NG_X)] = f2bf(w0 * xa);
              a.frag[xidx(row + 8, n1, NG_X)] = f2bf(w1 * xb);
              s1 = __fmaf_rn(xa, xa, __fmul_rn(xb, xb));
            }
            s0 += __shfl_xor_sync(0xffffffffu, s0, 4); s1 += __shfl_xor_sync(0xffffffffu, s1, 4);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 8); s1 += __shfl_xor_sync(0xffffffffu, s1, 8);
            s0 += __shfl_xor_sync(0xffffffffu, s0, 16); s1 += __shfl_xor_sync(0xffffffffu, s1, 16);
            if (g == 0) {
              if (v0) a.ssq[(size_t)n0 * 256 + tile] = s0;
              if (v1) a.ssq[(size_t)n1 * 256 + tile] = s1;
            }
          } else if (EP == EP_LMARG) {
            // the logits of EP_LM, reduced to the best row per column; rows ascend, strict > keeps the lowest
            float v;
            v = cc[0] * r0; if (v > bv0) { bv0 = v; bi0 = row; }
            v = cc[2] * r0; if (v > bv0) { bv0 = v; bi0 = row + 8; }
            v = cc[1] * r1; if (v > bv1) { bv1 = v; bi1 = row; }
            v = cc[3] * r1; if (v > bv1) { bv1 = v; bi1 = row + 8; }
          }
        }
        if (EP == EP_LMARG) {
#pragma unroll
          for (int o = 16; o >= 4; o >>= 1) {
            float uv = __shfl_xor_sync(0xffffffffu, bv0, o); int ix = __shfl_xor_sync(0xffffffffu, bi0, o);
            if (uv > bv0 || (uv == bv0 && ix < bi0)) { bv0 = uv; bi0 = ix; }
            uv = __shfl_xor_sync(0xffffffffu, bv1, o); ix = __shfl_xor_sync(0xffffffffu, bi1, o);
            if (uv > bv1 || (uv == bv1 && ix < bi1)) { bv1 = uv; bi1 = ix; }
          }
          if (g == 0) {
            const size_t base = (size_t)(rb * 4 + t2) * a.T;
            if (v0) { a.bm_val[base + n0] = bv0; a.bm_idx[base + n0] = bi0; }
            if (v1) { a.bm_val[base + n1] = bv1; a.bm_idx[base + n1] = bi1; }
          }
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// small per-column kernels
// ---------------------------------------------------------------------------------------------------------
struct Dev {
  const unsigned short* W; const unsigned short* embed; const float* norm_w; const float* qk_norm_w; const float* rope;
  uint4* kv;                 // page pool: [page][layer][kv head][K | V][PG_U4]
  const int* plan;           // device copy of the pass plan
  float* x;                  // [TCAP][H] residual stream
  unsigned short* xfrag;     // [TCAP][H] bf16(w * x) in the operand layout: input of the next norm + matvec
  float* ssq;                // [TCAP][256]
  float* rn;                 // [TCAP]
  float* qkv;                // [TCAP][6144]
  unsigned short* qfrag;     // q after norm, RoPE and score scale, bf16, as A fragments per attention unit (see k_prep)
  unsigned short* afrag;     // [TCAP][H] attention output, operand layout
  unsigned short* mfrag;     // [TCAP][INNER] silu(gate) * up, operand layout
  unsigned short* lmfrag;    // [SELCAP][H] final-norm input of the selected columns, operand layout (NG_LM groups)
  float* lm_rn;              // [SELCAP]
  float* bm_val; int* bm_idx;// [VOCAB / 32][SELCAP]
  int* last_tok;             // [NSLOT] last generated token of a slot
  int* sel_tok;              // [SELCAP] tokens of this pass
  float4* att_part;          // [PARTCAP][8 kv heads][17][32]: fold state of a (unit, kv head, super-segment)
  int* ctr;                  // [NL][2] task counters of the attention kernels (zeroed by k_embed)
};

// embedding: x = embed[token]; fragments of bf16(w0 * x) and per-tile sums of x^2 for the first norm
struct EmbedArgs { Dev d; int T; int pos_add; const long long* tok64; };
__global__ void __launch_bounds__(256) k_embed(EmbedArgs a) {
  const Dev& D = a.d;
  if (blockIdx.x == 0 && threadIdx.x < NL * 2) D.ctr[threadIdx.x] = 0;
  for (int col = blockIdx.x; col < a.T; col += gridDim.x) {
    long long tok;
    if (a.tok64) tok = a.tok64[col];
    else {
      tok = D.plan[PL_TOK + col];
      if (tok < 0) tok = __ldcg(D.last_tok + (D.plan[PL_SLOT + col] & 0xffff));
    }
    const uint2* e = (const uint2*)(D.embed + (size_t)tok * H);
    for (int i = threadIdx.x; i < H / 4; i += 256) {
      uint2 v = e[i];
      float4 f = make_float4(bf2f(v.x & 0xffffu), bf2f(v.x >> 16), bf2f(v.y & 0xffffu), bf2f(v.y >> 16));
      ((float4*)(D.x + (size_t)col * H))[i] = f;
      float4 wv = ((const float4*)D.norm_w)[i];
      const int k = i * 4;
      D.xfrag[xidx(k + 0, col, NG_X)] = f2bf(wv.x * f.x);
      D.xfrag[xidx(k + 1, col, NG_X)] = f2bf(wv.y * f.y);
      D.xfrag[xidx(k + 2, col, NG_X)] = f2bf(wv.z * f.z);
      D.xfrag[xidx(k + 3, col, NG_X)] = f2bf(wv.w * f.w);
      float p = __fadd_rn(__fmaf_rn(f.x, f.x, __fmul_rn(f.y, f.y)), __fmaf_rn(f.z, f.z, __fmul_rn(f.w, f.w)));
      p += __shfl_xor_sync(0xffffffffu, p, 1);
      p += __shfl_xor_sync(0xffffffffu, p, 2);
      if ((i & 3) == 0) D.ssq[(size_t)col * 256 + (i >> 2)] = p;
    }
  }
}

// 1/rms per column from the 256 per-tile partial sums (fixed order). One warp per column.
struct RnArgs { const float* ssq; float* rn; int T; };
__global__ void __launch_bounds__(256) k_rnorm(RnArgs a) {
  const int lane = threadIdx.x & 31;
  for (int col = blockIdx.x * 8 + (threadIdx.x >> 5); col < a.T; col += gridDim.x * 8) {
    const float4* q = (const float4*)(a.ssq + (size_t)col * 256) + lane * 2;
    float4 u = __ldcg(q), v = __ldcg(q + 1);
    float s = ((u.x + u.y) + (u.z + u.w)) + ((v.x + v.y) + (v.z + v.w));
    s = warp_sum(s);
    if (lane == 0) a.rn[col] = rsqrtf(__fmaf_rn(s, 1.0f / H, 1e-6f));
  }
}

__device__ __forceinline__ uint4* kv_ptr(const Dev& D, int slot, int pos, int layer, int g, int isv) {
  const int page = D.plan[PL_PT + slot * MAXPG + (pos >> 9)];
  return D.kv + ((((size_t)page * NL + layer) * 8 + g) * 2 + isv) * PG_U4 + (size_t)((pos & 511) >> 4) * 256;
}

// After the q/k/v matvec: per column 48 vectors of 128 (32 q heads, 8 k heads, 8 v heads), one warp each.
// q, k: RMSNorm over the head, RoPE at the column's position. q -> qfrag; k, v -> the sequence's KV pages.
struct PrepArgs { Dev d; int T; int layer; int pos_add; };
__global__ void __launch_bounds__(512) k_prep(PrepArgs a) {
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31;
  const int total = a.T * 48;
  for (int wt = blockIdx.x * 16 + (threadIdx.x >> 5); wt < total; wt += gridDim.x * 16) {
    const int col = wt / 48, vec = wt - col * 48;
    const int sl = D.plan[PL_SLOT + col], slot = sl & 0xffff, pos = D.plan[PL_POS + col] + a.pos_add;
    const int row = vec < 32 ? vec * 128 : (vec < 40 ? 4096 + (vec - 32) * 128 : 5120 + (vec - 40) * 128);
    const float4 x = __ldcg((const float4*)(D.qkv + (size_t)col * QKV_ROWS + row) + lane);
    float xe[4] = {x.x, x.y, x.z, x.w};
    unsigned short ob[4];
    if (vec < 40) {
      const float4 wn = ((const float4*)(D.qk_norm_w + (a.layer * 2 + (vec < 32 ? 0 : 1)) * 128))[lane];
      const float4 cs = ((const float4*)(D.rope + (size_t)pos * 128))[lane & 15];
      const float4 sn = ((const float4*)(D.rope + (size_t)pos * 128 + 64))[lane & 15];
      const float ss = warp_sum(__fadd_rn(__fmaf_rn(x.x, x.x, __fmul_rn(x.y, x.y)), __fmaf_rn(x.z, x.z, __fmul_rn(x.w, x.w))));
      const float r = rsqrtf(__fmaf_rn(ss, 1.0f / 128, 1e-6f));
      const float we[4] = {wn.x, wn.y, wn.z, wn.w}, ce[4] = {cs.x, cs.y, cs.z, cs.w}, se[4] = {sn.x, sn.y, sn.z, sn.w};
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const float yv = __fmul_rn(we[i], __fmul_rn(xe[i], r));
        const float other = __shfl_xor_sync(0xffffffffu, yv, 16);
        const float rot = lane < 16 ? __fmaf_rn(yv, ce[i], -__fmul_rn(other, se[i])) : __fmaf_rn(yv, ce[i], __fmul_rn(other, se[i]));
        ob[i] = f2bf(vec < 32 ? __fmul_rn(rot, SC2) : rot);   // q carries the score scale log2(e) / sqrt(128)
      }
    } else {
#pragma unroll
      for (int i = 0; i < 4; i++) ob[i] = f2bf(xe[i]);
    }
    if (vec < 32) {
      // q is stored per attention unit (up to 4 consecutive columns, this one is number iq) as the MMA A fragment the attention
      // kernels load with one 16-byte load per lane: [unit][kv head g][kstep][lane = 4 (4 iA + h) + t], component
      // (half + 2 * hi) = dims 2t, 2t+1 (hi = 0) or 2t+8, 2t+9 (hi = 1) of the kstep for position iA + 2 * half
      const int g = vec >> 2, h = vec & 3;
      const int iq = (sl >> 17) & 3, unit = D.plan[PL_CU + col], iA = iq & 1, half = iq >> 1;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int k16 = 4 * (lane & 3) + i;
        const size_t word = (size_t)unit * 2048 + (g * 8 + (lane >> 2)) * 32 + 4 * (4 * iA + h) + frag_t(k16);   // 32 KB per unit
        D.qfrag[word * 8 + 2 * (half + 2 * (k16 >> 3)) + (k16 & 1)] = ob[i];
      }
    } else if (vec < 40) {
      // K tile = MMA B fragments [8 dim ksteps][lane = 4 n + t][half]: dims x positions, n = position & 7, half = (position & 15) >> 3
      unsigned short* Kc = (unsigned short*)kv_ptr(D, slot, pos, a.layer, vec - 32, 0);
      const int pp = pos & 15;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        const int d = 4 * lane + i, k16 = d & 15;
        Kc[((((size_t)(d >> 4)) * 32 + 4 * (pp & 7) + frag_t(k16)) << 3) + (pp >> 3) * 4 + frag_slot(k16)] = ob[i];
      }
    } else {
      // V tile = MMA B fragments [8 pairs of dim groups][lane = 4 n + t][dim group & 1]: positions x dims, n = dim & 7
      unsigned short* Vc = (unsigned short*)kv_ptr(D, slot, pos, a.layer, vec - 40, 1);
      // the last column of a run also clears the rest of its position tile: those positions enter the V sum
      // of this tile with weight 0 and must be finite
      const int pend = (sl & LASTBIT) ? 15 : (pos & 15);
      for (int pp = pos & 15; pp <= pend; pp++) {
        const bool real = pp == (pos & 15);
#pragma unroll
        for (int i = 0; i < 4; i++) {
          const int d = 4 * lane + i, dg = d >> 3;
          Vc[((((size_t)(dg >> 1)) * 32 + 4 * (d & 7) + frag_t(pp)) << 3) + (dg & 1) * 4 + frag_slot(pp)] = real ? ob[i] : (unsigned short)0;
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// attention (see the canonical arithmetic at the top). A warp works on 16 query rows = 4 consecutive positions
// of one sequence x the 4 q heads of one kv head, and keeps everything of a segment in registers:
//   scores^T [16 rows x 8 positions] = MMA(A = q rows x dims, B = K dims x positions), two per position tile;
//   the weights of a tile, packed as bf16, ARE the A fragment (rows x 16 positions) of the second product
//   o^T [16 rows x 8 dims] += MMA(A = weights, B = V positions x dims), 16 dim groups.
// What bounds it (measured): the global loads of one warp are served one after the other (~85 ns per 512 bytes
// from L2), and the SM issues about one scalar warp-instruction per cycle. Hence two kernels with the same
// arithmetic per row:
//   k_attn_b: a block takes (up to 8 units = 32 consecutive positions, kv head, super-segment). All 256 threads
//             copy the segment's K and V into shared memory once (16 loads per thread instead of 128), double
//             buffered so the next segment is in flight during the multiply; the 8 warps each compute their unit.
//   k_attn_w: a warp takes (unit, kv head, super-segment) and reads K/V itself: decode rows and short runs,
//             where 8 warps streaming 8 different sequences use the memory system better than one block per row.
// Tasks are claimed from a counter (they differ in length). The host lists the block tasks of a run by
// (super-segment, kv head, group): the blocks that run at the same time then read the SAME K/V (4096 positions of
// one kv head: 2 MB), which the first of them pulls into L2; listed by group, every group streams the whole
// context from HBM again. A unit with more than one super-segment leaves its
// parts in a scratch and k_attn_fold folds them in order; with one super-segment the fold is the identity and
// the kernel writes the output itself.
// ---------------------------------------------------------------------------------------------------------
#define A_WARPS 8
#define A_THREADS (A_WARPS * 32)
__device__ __forceinline__ float ex2(float x) { float r; asm("ex2.approx.ftz.f32 %0, %1;" : "=f"(r) : "f"(x)); return r; }
#ifdef NO_CVT_BF16
__device__ __forceinline__ unsigned cvt_bf(float x) { return f2bf(x); }
#else
__device__ __forceinline__ unsigned cvt_bf(float x) { unsigned short r; asm("cvt.rn.bf16.f32 %0, %1;" : "=h"(r) : "f"(x)); return r; }
#endif
__device__ __forceinline__ void fold_factors(float M, float m, float& Mn, float& fa, float& fb) {
  Mn = fmaxf(M, m);
  fa = (M == Mn) ? 1.0f : (M == NINF ? 0.0f : ex2(__fsub_rn(M, Mn)));
  fb = (m == Mn) ? 1.0f : (m == NINF ? 0.0f : ex2(__fsub_rn(m, Mn)));
}
__device__ __forceinline__ unsigned pack2(float a, float b) { return cvt_bf(a) | (cvt_bf(b) << 16); }

// Scores of one segment for the 16 rows of the warp, and their maxima. q: the 8 q A-fragments of this lane;
// Kp: K of the segment's first position tile, this lane ([tile][kstep][32]); SM: Kp is shared memory.
// npt: position tiles to visit; limA / limB: last valid position relative to the segment for row g8 / row
// g8 + 8 of this lane; FULL: every position is valid for every row (then no masks).
template <bool SM, bool FULL>
__device__ __forceinline__ void seg_scores(const uint4 (&q)[8], const uint4* Kp, int npt, int limA, int limB, int lane, float (&sc)[8][2][4], float& mA, float& mB) {
  const int t = lane & 3;
#pragma unroll
  for (int k = 0; k < 8; k++) {
    float c0[4] = {0.f, 0.f, 0.f, 0.f}, c1[4] = {0.f, 0.f, 0.f, 0.f};
    if (FULL || k < npt) {
      if (SM) {
#pragma unroll
        for (int ks = 0; ks < 8; ks++) {
          const uint4 kf = Kp[(k * 8 + ks) * 32];
          const uint2 b0 = make_uint2(kf.x, kf.y), b1 = make_uint2(kf.z, kf.w);
          MMA(c0, q[ks], b0); MMA(c1, q[ks], b1);
        }
      } else {
        uint4 kf[8];
#pragma unroll
        for (int ks = 0; ks < 8; ks++) kf[ks] = __ldcg(Kp + (k * 8 + ks) * 32);
#pragma unroll
        for (int ks = 0; ks < 8; ks++) {
          const uint2 b0 = make_uint2(kf[ks].x, kf[ks].y), b1 = make_uint2(kf[ks].z, kf[ks].w);
          MMA(c0, q[ks], b0); MMA(c1, q[ks], b1);
        }
      }
    }
#pragma unroll
    for (int e = 0; e < 4; e++) { sc[k][0][e] = c0[e]; sc[k][1][e] = c1[e]; }
  }
  mA = NINF; mB = NINF;
#pragma unroll
  for (int k = 0; k < 8; k++)
#pragma unroll
    for (int h = 0; h < 2; h++)
#pragma unroll
      for (int e = 0; e < 2; e++) {
        const int pos = 16 * k + 8 * h + 2 * t + e;
        if (FULL || pos <= limA) mA = fmaxf(mA, sc[k][h][e]);
        if (FULL || pos <= limB) mB = fmaxf(mB, sc[k][h][2 + e]);
      }
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 1)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 1));
  mA = fmaxf(mA, __shfl_xor_sync(0xffffffffu, mA, 2)); mB = fmaxf(mB, __shfl_xor_sync(0xffffffffu, mB, 2));
}

// The segment's weights and their products with V, accumulated into the state of the super-segment:
// O (c[0], c[1]: row g8, dims 2t, 2t+1 of the dim group; c[2], c[3]: row g8 + 8), Z ([0], [1]: row g8; [2], [3]: row g8 + 8),
// MA / MB. The state stays in registers.
template <bool SM, bool FULL>
__device__ __forceinline__ void seg_accum(const uint4* Vp, int npt, int limA, int limB, int lane, const float (&sc)[8][2][4], float mA, float mB,
                                          float (&O)[16][4], float (&Z)[4], float& MA, float& MB) {
  const int t = lane & 3;
  const float RA = fmaxf(MA, mA), RB = fmaxf(MB, mB);
  const float faA = (MA == RA) ? 1.0f : (MA == NINF ? 0.0f : ex2(__fsub_rn(MA, RA)));
  const float faB = (MB == RB) ? 1.0f : (MB == NINF ? 0.0f : ex2(__fsub_rn(MB, RB)));
  // a factor of exactly 1 changes nothing: skip the 68 multiplies when no row of the warp has a new maximum
  if (__any_sync(0xffffffffu, MA != RA || MB != RB)) {
#pragma unroll
    for (int i = 0; i < 16; i++) { O[i][0] = __fmul_rn(O[i][0], faA); O[i][1] = __fmul_rn(O[i][1], faA); O[i][2] = __fmul_rn(O[i][2], faB); O[i][3] = __fmul_rn(O[i][3], faB); }
    Z[0] = __fmul_rn(Z[0], faA); Z[1] = __fmul_rn(Z[1], faA); Z[2] = __fmul_rn(Z[2], faB); Z[3] = __fmul_rn(Z[3], faB);
  }
  MA = RA; MB = RB;
  const uint2 ones = make_uint2(0x3f803f80u, 0x3f803f80u);
#pragma unroll
  for (int k = 0; k < 8; k++) {
    if (FULL || k < npt) {
      uint4 pa;
      if (FULL) {
        pa = make_uint4(pack2(ex2(__fsub_rn(sc[k][0][0], RA)), ex2(__fsub_rn(sc[k][0][1], RA))), pack2(ex2(__fsub_rn(sc[k][0][2], RB)), ex2(__fsub_rn(sc[k][0][3], RB))),
                        pack2(ex2(__fsub_rn(sc[k][1][0], RA)), ex2(__fsub_rn(sc[k][1][1], RA))), pack2(ex2(__fsub_rn(sc[k][1][2], RB)), ex2(__fsub_rn(sc[k][1][3], RB))));
      } else {
        unsigned wb[2][4];
#pragma unroll
        for (int h = 0; h < 2; h++)
#pragma unroll
          for (int e = 0; e < 4; e++) {
            const int pos = 16 * k + 8 * h + 2 * t + (e & 1);
            const unsigned b = cvt_bf(ex2(__fsub_rn(sc[k][h][e], e < 2 ? RA : RB)));
            wb[h][e] = pos <= (e < 2 ? limA : limB) ? b : 0u;
          }
        pa = make_uint4(wb[0][0] | (wb[0][1] << 16), wb[0][2] | (wb[0][3] << 16), wb[1][0] | (wb[1][1] << 16), wb[1][2] | (wb[1][3] << 16));
      }
      MMA(Z, pa, ones);
      if (SM) {
#pragma unroll
        for (int e8 = 0; e8 < 8; e8++) {
          const uint4 vf = Vp[(k * 8 + e8) * 32];
          const uint2 b0 = make_uint2(vf.x, vf.y), b1 = make_uint2(vf.z, vf.w);
          MMA(O[2 * e8], pa, b0); MMA(O[2 * e8 + 1], pa, b1);
        }
      } else {
        uint4 vf[8];
#pragma unroll
        for (int e8 = 0; e8 < 8; e8++) vf[e8] = __ldcg(Vp + (k * 8 + e8) * 32);
#pragma unroll
        for (int e8 = 0; e8 < 8; e8++) {
          const uint2 b0 = make_uint2(vf[e8].x, vf[e8].y), b1 = make_uint2(vf[e8].z, vf[e8].w);
          MMA(O[2 * e8], pa, b0); MMA(O[2 * e8 + 1], pa, b1);
        }
      }
    }
  }
}

// q A-fragment of this lane for kstep ks: rows g8 (position iA, head h) and g8 + 8 (position iA + 2, head h).
// One 16-byte load into four consecutive registers: the MMA takes them as they are (built from two 8-byte
// loads the compiler moved every fragment before every MMA: 4 moves per MMA pair, 256 per segment).
// Rows of positions the unit does not have hold stale (finite) values; their results are never stored.
__device__ __forceinline__ uint4 load_q(const Dev& D, int unit, int g, int ks, int lane) {
  return __ldcg((const uint4*)D.qfrag + (size_t)unit * 2048 + (g * 8 + ks) * 32 + lane);
}
// output of one dim-group pair of this lane: bf16(O / Z) into the o projection's input fragments (K index = (4g + h) * 128 + d)
__device__ __forceinline__ void store_att(const Dev& D, int col0, int nq, int g, int lane, int e8, float oA0, float oA1, float oA2, float oA3,
                                          float oB0, float oB1, float oB2, float oB3, float rzA, float rzB) {
  const int g8 = lane >> 2, t = lane & 3, iA = g8 >> 2, h = g8 & 3;
  const int kstep = (4 * g + h) * 8 + e8;
  if (iA < nq) {
    const int col = col0 + iA;
    *(unsigned*)(D.afrag + xidx(16 * kstep + 2 * t, col, NG_X)) = pack2(__fmul_rn(oA0, rzA), __fmul_rn(oA1, rzA));
    *(unsigned*)(D.afrag + xidx(16 * kstep + 8 + 2 * t, col, NG_X)) = pack2(__fmul_rn(oA2, rzA), __fmul_rn(oA3, rzA));
  }
  if (iA + 2 < nq) {
    const int col = col0 + iA + 2;
    *(unsigned*)(D.afrag + xidx(16 * kstep + 2 * t, col, NG_X)) = pack2(__fmul_rn(oB0, rzB), __fmul_rn(oB1, rzB));
    *(unsigned*)(D.afrag + xidx(16 * kstep + 8 + 2 * t, col, NG_X)) = pack2(__fmul_rn(oB2, rzB), __fmul_rn(oB3, rzB));
  }
}
// end of a (unit, kv head, super-segment): the only part -> output; otherwise the state goes to the scratch
__device__ __forceinline__ void part_done(const Dev& D, const float (&O)[16][4], float MA, float MB, float ZA, float ZB, int col0, int nq, int g, int pbase, int ss, int lane) {
  if (pbase < 0) {
    const float rzA = __fdiv_rn(1.0f, ZA), rzB = __fdiv_rn(1.0f, ZB);
#pragma unroll
    for (int e8 = 0; e8 < 8; e8++)
      store_att(D, col0, nq, g, lane, e8, O[2 * e8][0], O[2 * e8][1], O[2 * e8 + 1][0], O[2 * e8 + 1][1],
                O[2 * e8][2], O[2 * e8][3], O[2 * e8 + 1][2], O[2 * e8 + 1][3], rzA, rzB);
  } else {
    float4* P = D.att_part + ((size_t)(pbase + ss) * 8 + g) * (17 * 32) + lane;
#pragma unroll
    for (int i = 0; i < 16; i++) P[i * 32] = make_float4(O[i][0], O[i][1], O[i][2], O[i][3]);
    P[16 * 32] = make_float4(MA, MB, ZA, ZB);
  }
}
__device__ __forceinline__ const uint4* seg_k(const Dev& D, int slot, int layer, int g, int s) {
  const int page = D.plan[PL_PT + slot * MAXPG + (s >> 2)];
  return D.kv + ((((size_t)page * NL + layer) * 8 + g) * 2) * PG_U4 + (size_t)((s & 3) * 8) * 256;
}

struct AttArgs { Dev d; int n_tasks; int layer; int pos_add; int* ctr; };

// ---- warp tasks
__global__ void __launch_bounds__(A_THREADS, 1) k_attn_w(AttArgs a) {
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31;
  const int total = a.n_tasks * 8;
  for (;;) {
    int task = 0;
    if (lane == 0) task = atomicAdd(a.ctr, 1);
    task = __shfl_sync(0xffffffffu, task, 0);
    if (task >= total) break;
    const int wt = D.plan[PL_WT + (task >> 3)], g = task & 7;
    const int unit = wt & 0xffff, ss = wt >> 16;
    const int col0 = D.plan[PL_UNIT + 4 * unit], nq = D.plan[PL_UNIT + 4 * unit + 1], pbase = D.plan[PL_UNIT + 4 * unit + 2];
    const int slot = D.plan[PL_SLOT + col0] & 0xffff, pos0 = D.plan[PL_POS + col0] + a.pos_add;
    const int tmax = pos0 + nq - 1, nseg = (tmax >> 7) + 1;
    const int iA = lane >> 4;
    const int tA = iA < nq ? pos0 + iA : -1, tB = iA + 2 < nq ? pos0 + iA + 2 : -1;
    uint4 q[8];
#pragma unroll
    for (int ks = 0; ks < 8; ks++) q[ks] = load_q(D, unit, g, ks, lane);
    float O[16][4], Z[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
    for (int i = 0; i < 16; i++) { O[i][0] = 0.f; O[i][1] = 0.f; O[i][2] = 0.f; O[i][3] = 0.f; }
    float MA = NINF, MB = NINF;
    const int s1 = min(nseg, (ss + 1) * SS_SEGS);
    for (int s = ss * SS_SEGS; s < s1; s++) {
      const uint4* Kc = seg_k(D, slot, a.layer, g, s) + lane;
      const int npt = min(8, ((tmax - s * SEG) >> 4) + 1);
      float sc[8][2][4], mA, mB;
      if (pos0 >= s * SEG + SEG - 1) {
        seg_scores<false, true>(q, Kc, 8, 0, 0, lane, sc, mA, mB);
        seg_accum<false, true>(Kc + PG_U4, 8, 0, 0, lane, sc, mA, mB, O, Z, MA, MB);
      } else {
        seg_scores<false, false>(q, Kc, npt, tA - s * SEG, tB - s * SEG, lane, sc, mA, mB);
        seg_accum<false, false>(Kc + PG_U4, npt, tA - s * SEG, tB - s * SEG, lane, sc, mA, mB, O, Z, MA, MB);
      }
    }
    part_done(D, O, MA, MB, Z[0], Z[2], col0, nq, g, pbase, ss, lane);
  }
}

// ---- block tasks. K and V of a segment (8 position tiles = 32 KB each, contiguous in a page) are brought into
// shared memory by the copy engine (cp.async.bulk), one segment ahead, double buffered; no warp loads K/V.
// (With warp loads, 16 per thread and segment, the staging was 23% of the kernel: ablation of v3.)
#define AB_KV 0                               // uint4 [2 buffers][K: 8 tiles x 8 ks x 32 | V: the same]
#define AB_BAR (2 * 2 * 2048 * 16)            // uint64 [2]: "buffer arrived"
#define AB_CTL (AB_BAR + 16)
#define AB_SMEM (AB_CTL + 16)
__global__ void __launch_bounds__(A_THREADS, 1) k_attn_b(AttArgs a) {
  extern __shared__ __align__(128) unsigned char smem[];
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  uint4* kvb = (uint4*)(smem + AB_KV);
  uint64_t* bar = (uint64_t*)(smem + AB_BAR);
  int* ctl = (int*)(smem + AB_CTL);
  const int total = a.n_tasks;
  if (threadIdx.x == 0) {
    mbar_init(bar, 1); mbar_init(bar + 1, 1);
    asm volatile("fence.mbarrier_init.release.cluster;" ::: "memory");
  }
  unsigned ph0 = 0, ph1 = 0;                   // fills of each buffer so far (every thread counts alike)
  for (;;) {
    if (threadIdx.x == 0) ctl[0] = atomicAdd(a.ctr, 1);
    __syncthreads();
    const int task = ctl[0];
    if (task >= total) break;
    const int bt = D.plan[PL_BT + task];
    const int u0 = bt & 0xfff, nu = (bt >> 12) & 0xf, ss = (bt >> 16) & 0x3f, g = bt >> 22;
    // the group: positions up to gtmax of one sequence
    const int ul = u0 + nu - 1;
    const int gcol = D.plan[PL_UNIT + 4 * ul];
    const int slot = D.plan[PL_SLOT + gcol] & 0xffff;
    const int gtmax = D.plan[PL_POS + gcol] + a.pos_add + D.plan[PL_UNIT + 4 * ul + 1] - 1;
    const int s0 = ss * SS_SEGS, s1 = min((gtmax >> 7) + 1, s0 + SS_SEGS);
    // this warp's unit
    const int unit = u0 + min(w, nu - 1);
    const int col0 = D.plan[PL_UNIT + 4 * unit], nq = D.plan[PL_UNIT + 4 * unit + 1], pbase = D.plan[PL_UNIT + 4 * unit + 2];
    const int pos0 = D.plan[PL_POS + col0] + a.pos_add;
    const int tmax = pos0 + nq - 1, nseg = (tmax >> 7) + 1;
    const bool active = w < nu && s0 < nseg;
    const int iA = lane >> 4;
    const int tA = iA < nq ? pos0 + iA : -1, tB = iA + 2 < nq ? pos0 + iA + 2 : -1;
    uint4 q[8];
#pragma unroll
    for (int ks = 0; ks < 8; ks++) q[ks] = load_q(D, unit, g, ks, lane);
    float O[16][4], Z[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
    for (int i = 0; i < 16; i++) { O[i][0] = 0.f; O[i][1] = 0.f; O[i][2] = 0.f; O[i][3] = 0.f; }
    float MA = NINF, MB = NINF;
    for (int s = s0; s < s1; s++) {
      const int buf = (s - s0) & 1;
      if (threadIdx.x == 0) {
        // ask for the first segment (into buffer 0) and always for the next one (into the other buffer, which
        // every warp has finished reading: block barrier below / at the task claim)
#pragma unroll
        for (int e = (s == s0 ? 0 : 1); e < 2; e++) {
          const int sn = s + e;
          if (sn < s1) {
            const uint4* Kn = seg_k(D, slot, a.layer, g, sn);
            const unsigned bytes = (unsigned)min(8, ((gtmax - sn * SEG) >> 4) + 1) * 4096u;
            uint4* dst = kvb + ((sn - s0) & 1) * 4096;
            mbar_expect(bar + ((sn - s0) & 1), 2 * bytes);
            bulk_g2s(dst, Kn, bytes, bar + ((sn - s0) & 1));
            bulk_g2s(dst + 2048, Kn + PG_U4, bytes, bar + ((sn - s0) & 1));
          }
        }
      }
      if (buf == 0) { mbar_wait(bar, ph0 & 1); ph0++; } else { mbar_wait(bar + 1, ph1 & 1); ph1++; }
      const uint4* Ks = kvb + buf * 4096 + lane;
      if (active && s < nseg) {
        const int npt = min(8, ((tmax - s * SEG) >> 4) + 1);
        const int limA = tA - s * SEG, limB = tB - s * SEG;
        float sc[8][2][4], mA, mB;
        if (pos0 >= s * SEG + SEG - 1) {
          seg_scores<true, true>(q, Ks, 8, 0, 0, lane, sc, mA, mB);
          seg_accum<true, true>(Ks + 2048, 8, 0, 0, lane, sc, mA, mB, O, Z, MA, MB);
        } else {
          seg_scores<true, false>(q, Ks, npt, limA, limB, lane, sc, mA, mB);
          seg_accum<true, false>(Ks + 2048, npt, limA, limB, lane, sc, mA, mB, O, Z, MA, MB);
        }
      }
      __syncthreads();
    }
    if (active) part_done(D, O, MA, MB, Z[0], Z[2], col0, nq, g, pbase, ss, lane);
  }
}

// ---- fold of the super-segments of a unit, in order: one warp per (unit, kv head)
struct FoldArgs { Dev d; int n_fold; int pos_add; };
__global__ void __launch_bounds__(A_THREADS, 1) k_attn_fold(FoldArgs a) {
  const Dev& D = a.d;
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const int total = a.n_fold * 8;
  for (int task = blockIdx.x * A_WARPS + w; task < total; task += gridDim.x * A_WARPS) {
    const int unit = D.plan[PL_FOLD + (task >> 3)], g = task & 7;
    const int col0 = D.plan[PL_UNIT + 4 * unit], nq = D.plan[PL_UNIT + 4 * unit + 1], pbase = D.plan[PL_UNIT + 4 * unit + 2];
    const int nss = ((D.plan[PL_POS + col0] + a.pos_add + nq - 1) >> SS_SHIFT) + 1;
    float O[16][4];
#pragma unroll
    for (int i = 0; i < 16; i++) { O[i][0] = 0.f; O[i][1] = 0.f; O[i][2] = 0.f; O[i][3] = 0.f; }
    float MA = NINF, MB = NINF, ZA = 0.f, ZB = 0.f;
    for (int ss = 0; ss < nss; ss++) {
      const float4* P = D.att_part + ((size_t)(pbase + ss) * 8 + g) * (17 * 32) + lane;
      float4 v[17];
#pragma unroll
      for (int i = 0; i < 17; i++) v[i] = __ldcg(P + i * 32);
      float faA, fbA, faB, fbB, Mn;
      fold_factors(MA, v[16].x, Mn, faA, fbA); MA = Mn; ZA = __fmaf_rn(ZA, faA, __fmul_rn(v[16].z, fbA));
      fold_factors(MB, v[16].y, Mn, faB, fbB); MB = Mn; ZB = __fmaf_rn(ZB, faB, __fmul_rn(v[16].w, fbB));
#pragma unroll
      for (int i = 0; i < 16; i++) {
        O[i][0] = __fmaf_rn(O[i][0], faA, __fmul_rn(v[i].x, fbA));
        O[i][1] = __fmaf_rn(O[i][1], faA, __fmul_rn(v[i].y, fbA));
        O[i][2] = __fmaf_rn(O[i][2], faB, __fmul_rn(v[i].z, fbB));
        O[i][3] = __fmaf_rn(O[i][3], faB, __fmul_rn(v[i].w, fbB));
      }
    }
    const float rzA = __fdiv_rn(1.0f, ZA), rzB = __fdiv_rn(1.0f, ZB);
#pragma unroll
    for (int e8 = 0; e8 < 8; e8++)
      store_att(D, col0, nq, g, lane, e8, O[2 * e8][0], O[2 * e8][1], O[2 * e8 + 1][0], O[2 * e8 + 1][1],
                O[2 * e8][2], O[2 * e8][3], O[2 * e8 + 1][2], O[2 * e8 + 1][3], rzA, rzB);
  }
}

// ---------------------------------------------------------------------------------------------------------
// lm_head helpers: gather the selected columns' final-norm input; reduce the per-warp maxima to a token
// ---------------------------------------------------------------------------------------------------------
struct SelArgs { Dev d; int n_sel; long long* out64; int out_stride; int out_step; };
__global__ void __launch_bounds__(256) k_gather(SelArgs a) {
  const Dev& D = a.d;
  for (int j = blockIdx.x; j < a.n_sel; j += gridDim.x) {
    const int col = D.plan[PL_SEL + 2 * j];
    for (int i = threadIdx.x; i < H / 8; i += 256)   // 16 bytes = 8 consecutive K elements of the column
      ((uint4*)D.lmfrag)[xidx(8 * i, j, NG_LM) >> 3] = __ldcg((const uint4*)D.xfrag + (xidx(8 * i, col, NG_X) >> 3));
    if (threadIdx.x == 0) D.lm_rn[j] = __ldcg(D.rn + col);
  }
}
__global__ void __launch_bounds__(256) k_argmax(SelArgs a) {
  const Dev& D = a.d;
  __shared__ float sv[8]; __shared__ int si[8];
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  const int ncand = VOCAB / 32;
  for (int j = blockIdx.x; j < a.n_sel; j += gridDim.x) {
    float bv = NINF; int bi = 0x7fffffff;
    for (int i = threadIdx.x; i < ncand; i += 256) {
      float v = __ldcg(D.bm_val + (size_t)i * a.n_sel + j); int ix = __ldcg(D.bm_idx + (size_t)i * a.n_sel + j);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
#pragma unroll
    for (int o = 16; o > 0; o >>= 1) {
      float v = __shfl_xor_sync(0xffffffffu, bv, o); int ix = __shfl_xor_sync(0xffffffffu, bi, o);
      if (v > bv || (v == bv && ix < bi)) { bv = v; bi = ix; }
    }
    if (lane == 0) { sv[w] = bv; si[w] = bi; }
    __syncthreads();
    if (threadIdx.x == 0) {
      for (int i = 1; i < 8; i++) if (sv[i] > bv || (sv[i] == bv && si[i] < bi)) { bv = sv[i]; bi = si[i]; }
      D.sel_tok[j] = bi;
      const int slot = D.plan[PL_SEL + 2 * j + 1];
      if (slot >= 0) D.last_tok[slot] = bi;
      if (a.out64) a.out64[(size_t)j * a.out_stride + a.out_step] = bi;
    }
    __syncthreads();
  }
}

// test helper: fill a page with NaN (bf16 0x7fc0)
__global__ void k_fill16(unsigned short* p, size_t n, unsigned short v) {
  for (size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x; i < n; i += (size_t)gridDim.x * blockDim.x) p[i] = v;
}

// ---------------------------------------------------------------------------------------------------------
// host API
// ---------------------------------------------------------------------------------------------------------
#define CK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { fprintf(stderr, "CUDA error %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); abort(); } } while (0)

struct Eng {
  Dev D;
  int nsm, n_pages;
  int* plan_dev;
  long long passes, launches, plan_uploads, tok_reads;
  int force_shape;
};

// Columns per consumer warpgroup: the smallest wgmma that covers T with one column block, 128 beyond 128 columns
template <int EP, int NB>
static void launch_gemm_nb(Eng* E, const GemmArgs& g) {
  const int n_units = (g.M / 128) * ((g.T + 2 * NB - 1) / (2 * NB));
  k_gemm<EP, NB><<<n_units < E->nsm ? n_units : E->nsm, WG_THREADS, WG_SMEM(NB)>>>(g);
}
template <int EP>
static void launch_gemm(Eng* E, const GemmArgs& g) {
  const int nb = E->force_shape > 0 ? E->force_shape : (g.T <= 32 ? 16 : g.T <= 64 ? 32 : g.T <= 128 ? 64 : 128);
  if (nb == 16) launch_gemm_nb<EP, 16>(E, g);
  else if (nb == 32) launch_gemm_nb<EP, 32>(E, g);
  else if (nb == 64) launch_gemm_nb<EP, 64>(E, g);
  else launch_gemm_nb<EP, 128>(E, g);
  E->launches++;
}
template <int EP>
static void gemm_attr() {
  CK(cudaFuncSetAttribute(k_gemm<EP, 16>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(16)));
  CK(cudaFuncSetAttribute(k_gemm<EP, 32>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(32)));
  CK(cudaFuncSetAttribute(k_gemm<EP, 64>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(64)));
  CK(cudaFuncSetAttribute(k_gemm<EP, 128>, cudaFuncAttributeMaxDynamicSharedMemorySize, WG_SMEM(128)));
}

extern "C" {

void* eng_create(int n_pages, const void* W, const void* embed, const void* norm_w, const void* qk_norm_w, const void* rope) {
  Eng* E = new Eng();
  memset(E, 0, sizeof(Eng));
  int dev = 0; CK(cudaGetDevice(&dev));
  cudaDeviceProp prop; CK(cudaGetDeviceProperties(&prop, dev));
  E->nsm = prop.multiProcessorCount;
  E->n_pages = n_pages;
  E->force_shape = getenv("MK_GEMM_NB") ? atoi(getenv("MK_GEMM_NB")) : -1;
  Dev& D = E->D;
  D.W = (const unsigned short*)W; D.embed = (const unsigned short*)embed; D.norm_w = (const float*)norm_w;
  D.qk_norm_w = (const float*)qk_norm_w; D.rope = (const float*)rope;
  CK(cudaMalloc(&D.kv, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMalloc(&E->plan_dev, sizeof(int) * PL_INTS)); D.plan = E->plan_dev;
  CK(cudaMalloc(&D.x, sizeof(float) * (size_t)TCAP * H));
  CK(cudaMalloc(&D.xfrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.ssq, sizeof(float) * (size_t)TCAP * 256));
  CK(cudaMalloc(&D.rn, sizeof(float) * TCAP));
  CK(cudaMalloc(&D.qkv, sizeof(float) * (size_t)TCAP * QKV_ROWS));
  CK(cudaMalloc(&D.qfrag, (size_t)MAXU * 2048 * 16));
  CK(cudaMalloc(&D.afrag, (size_t)TCAP * H * 2));
  CK(cudaMalloc(&D.mfrag, (size_t)TCAP * INNER * 2));
  CK(cudaMalloc(&D.lmfrag, (size_t)SELCAP * H * 2));
  CK(cudaMalloc(&D.lm_rn, sizeof(float) * SELCAP));
  CK(cudaMalloc(&D.bm_val, sizeof(float) * (size_t)(VOCAB / 32) * SELCAP));
  CK(cudaMalloc(&D.bm_idx, sizeof(int) * (size_t)(VOCAB / 32) * SELCAP));
  CK(cudaMalloc(&D.last_tok, sizeof(int) * NSLOT));
  CK(cudaMalloc(&D.sel_tok, sizeof(int) * SELCAP));
  CK(cudaMalloc(&D.att_part, sizeof(float4) * (size_t)PARTCAP * 8 * 17 * 32));
  CK(cudaMalloc(&D.ctr, sizeof(int) * NL * 2));
  CK(cudaMemset(D.ctr, 0, sizeof(int) * NL * 2));
  CK(cudaMemset(D.kv, 0, PAGE_BYTES * (size_t)n_pages));
  CK(cudaMemset(D.xfrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.qfrag, 0, (size_t)MAXU * 2048 * 16));
  CK(cudaMemset(D.afrag, 0, (size_t)TCAP * H * 2));
  CK(cudaMemset(D.mfrag, 0, (size_t)TCAP * INNER * 2));
  CK(cudaMemset(D.lmfrag, 0, (size_t)SELCAP * H * 2));
  CK(cudaMemset(D.last_tok, 0, sizeof(int) * NSLOT));
  CK(cudaMemset(E->plan_dev, 0, sizeof(int) * PL_INTS));
  gemm_attr<EP_QKV>(); gemm_attr<EP_ADD>(); gemm_attr<EP_GU>(); gemm_attr<EP_LM>(); gemm_attr<EP_LMARG>(); gemm_attr<EP_RAW>();
  CK(cudaFuncSetAttribute(k_attn_b, cudaFuncAttributeMaxDynamicSharedMemorySize, AB_SMEM));
  return E;
}

int eng_plan_ints() { return PL_INTS; }
int eng_tcap() { return TCAP; }
// plan layout for the host: 0 PL_UNIT, 1 PL_WT, 2 PL_BT, 3 PL_FOLD, 4 PL_SEL, 5 PL_PT, 6 MAXU, 7 MAXWT, 8 MAXBT, 9 PARTCAP, 10 PL_CU, 11 SS_SHIFT
int eng_const(int i) { static const int c[12] = {PL_UNIT, PL_WT, PL_BT, PL_FOLD, PL_SEL, PL_PT, MAXU, MAXWT, MAXBT, PARTCAP, PL_CU, SS_SHIFT}; return c[i]; }
// bytes of device memory the engine allocates besides the KV pages
size_t eng_fixed_bytes() { return sizeof(float4) * (size_t)PARTCAP * 8 * 17 * 32 + (size_t)TCAP * (H * 4 + H * 2 * 3 + INNER * 2 + QKV_ROWS * 4 + 256 * 4) + (size_t)(VOCAB / 32) * SELCAP * 8; }
int eng_selcap() { return SELCAP; }
size_t eng_page_bytes() { return PAGE_BYTES; }

// copy the plan (host ints, layout PL_*) to the device. `n` leading ints are copied.
void eng_set_plan(void* h, const int* plan, int off, int n) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->plan_dev + off, plan + off, sizeof(int) * (size_t)n, cudaMemcpyHostToDevice));
  E->plan_uploads++;
}

// One pass over the weights for the T columns of the current plan.
//   pos_add: added to every column's position (step()/generate() reuse one plan)
//   tok64:   device int64 [T] input tokens, or null (tokens from the plan / the slots' last tokens)
//   logits:  device float [n_sel][VOCAB] or null (then only the argmax: sel_tok, last_tok, out64)
void eng_pass(void* h, int T, int n_bt, int n_wt, int n_fold, int n_sel, int pos_add, const void* tok64, void* logits, void* out64, int out_stride, int out_step) {
  Eng* E = (Eng*)h;
  const Dev& D = E->D;
  const int nsm = E->nsm;
  EmbedArgs ea{D, T, pos_add, (const long long*)tok64};
  k_embed<<<T < 4 * nsm ? T : 4 * nsm, 256>>>(ea);
  RnArgs ra{D.ssq, D.rn, T};
  const int rn_grid = (T + 7) / 8 < nsm ? (T + 7) / 8 : nsm;
  for (int l = 0; l < NL; l++) {
    const unsigned short* WL = D.W + (size_t)l * LAYER_U4 * 8;
    k_rnorm<<<rn_grid, 256>>>(ra);
    GemmArgs g{};
    g.W = WL + OFF_QKV * 8; g.X = D.xfrag; g.NG = NG_X; g.M = QKV_ROWS; g.K = H; g.T = T; g.rn = D.rn; g.out = D.qkv;
    launch_gemm<EP_QKV>(E, g);
    PrepArgs pa{D, T, l, pos_add};
    const int pgrid = (T * 48 + 15) / 16 < 2 * nsm ? (T * 48 + 15) / 16 : 2 * nsm;
    k_prep<<<pgrid, 512>>>(pa);
    if (n_bt > 0) {
      AttArgs aa{D, n_bt, l, pos_add, D.ctr + 2 * l};
      k_attn_b<<<n_bt < nsm ? n_bt : nsm, A_THREADS, AB_SMEM>>>(aa);
    }
    if (n_wt > 0) {
      AttArgs aa{D, n_wt, l, pos_add, D.ctr + 2 * l + 1};
      k_attn_w<<<n_wt < nsm ? n_wt : nsm, A_THREADS>>>(aa);
    }
    if (n_fold > 0) {
      FoldArgs fa{D, n_fold, pos_add};
      k_attn_fold<<<n_fold < nsm ? n_fold : nsm, A_THREADS>>>(fa);
    }
    g = GemmArgs{};
    g.W = WL + OFF_O * 8; g.X = D.afrag; g.NG = NG_X; g.M = H; g.K = H; g.T = T;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 1) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g);
    k_rnorm<<<rn_grid, 256>>>(ra);
    g = GemmArgs{};
    g.W = WL + OFF_GU * 8; g.X = D.xfrag; g.NG = NG_X; g.M = 2 * INNER; g.K = H; g.T = T; g.rn = D.rn; g.frag = D.mfrag;
    launch_gemm<EP_GU>(E, g);
    g = GemmArgs{};
    g.W = WL + OFF_DN * 8; g.X = D.mfrag; g.NG = NG_X; g.M = H; g.K = INNER; g.T = T;
    g.x = D.x; g.aux = D.norm_w + (size_t)(2 * l + 2) * H; g.frag = D.xfrag; g.ssq = D.ssq;
    launch_gemm<EP_ADD>(E, g);
    E->launches += 5;
  }
  if (n_sel > 0) {
    k_rnorm<<<rn_grid, 256>>>(ra);
    SelArgs sa{D, n_sel, (long long*)out64, out_stride, out_step};
    k_gather<<<n_sel, 256>>>(sa);
    GemmArgs g{};
    g.W = D.W + (size_t)NL * LAYER_U4 * 8; g.X = D.lmfrag; g.NG = NG_LM; g.M = VOCAB; g.K = H; g.T = n_sel; g.rn = D.lm_rn;
    if (logits) { g.out = (float*)logits; launch_gemm<EP_LM>(E, g); }
    else {
      g.bm_val = D.bm_val; g.bm_idx = D.bm_idx;
      launch_gemm<EP_LMARG>(E, g);
      k_argmax<<<n_sel, 256>>>(sa);
    }
    E->launches += 3;
  }
  E->launches += 1;
  E->passes++;
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) fprintf(stderr, "eng_pass: launch error: %s\n", cudaGetErrorString(e));
}

// tokens of the last pass (blocks until the pass is done: one host sync)
void eng_read_tokens(void* h, int* out, int n_sel) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(out, E->D.sel_tok, sizeof(int) * (size_t)n_sel, cudaMemcpyDeviceToHost));
  E->tok_reads++;
}

void eng_set_last_tok(void* h, int slot, int tok) {
  Eng* E = (Eng*)h;
  CK(cudaMemcpy(E->D.last_tok + slot, &tok, sizeof(int), cudaMemcpyHostToDevice));
}

// tests: poison a page's K and V with NaN
void eng_poison_page(void* h, int page) {
  Eng* E = (Eng*)h;
  k_fill16<<<256, 256>>>((unsigned short*)((char*)E->D.kv + PAGE_BYTES * (size_t)page), PAGE_BYTES / 2, (unsigned short)0x7fc0);
}

// tests / bench: a bare matvec through the GEMM kernel. W: [M][K], X: [columns][K] with ng column groups, both in
// the operand layout (xidx); out [T][M] f32
void eng_gemm_raw(void* h, const void* W, const void* X, void* out, int M, int K, int T, int ng) {
  Eng* E = (Eng*)h;
  GemmArgs g{};
  g.W = (const unsigned short*)W; g.X = (const unsigned short*)X; g.NG = ng; g.M = M; g.K = K; g.T = T; g.out = (float*)out;
  launch_gemm<EP_RAW>(E, g);
}

long long eng_stat(void* h, int which) {
  Eng* E = (Eng*)h;
  return which == 0 ? E->launches : which == 1 ? E->passes : which == 2 ? E->nsm : which == 3 ? E->plan_uploads : which == 4 ? E->tok_reads : 0;
}

void eng_sync() { CK(cudaDeviceSynchronize()); }

void eng_destroy(void* h) {
  Eng* E = (Eng*)h;
  cudaDeviceSynchronize();
  Dev& D = E->D;
  cudaFree(D.kv); cudaFree(E->plan_dev); cudaFree(D.x); cudaFree(D.xfrag); cudaFree(D.ssq); cudaFree(D.rn); cudaFree(D.qkv);
  cudaFree(D.qfrag); cudaFree(D.afrag); cudaFree(D.mfrag); cudaFree(D.lmfrag); cudaFree(D.lm_rn); cudaFree(D.bm_val);
  cudaFree(D.bm_idx); cudaFree(D.last_tok); cudaFree(D.sel_tok); cudaFree(D.att_part); cudaFree(D.ctr);
  delete E;
}

}  // extern "C"
