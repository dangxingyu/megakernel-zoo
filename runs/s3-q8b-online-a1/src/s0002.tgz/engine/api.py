"""Qwen3-8B online engine: own CUDA kernels (engine/eng.cu) behind the offline and the online contract.

A *pass* runs T token columns once over the weights: the decode rows of every running request and chunks of the
prompts being prefilled, together. Python here loads the weights, keeps the slot / page tables and composes the
plan of each pass; no torch module and no library computes anything of the model.

    offline:  reset(), step(tokens[B]) -> logits [B, vocab], generate(tokens[B], n) -> tokens [B, n]
    online:   submit(rid, prompt, max_new_tokens), poll() -> [(rid, tokens, finished)], idle(), kv_pages(),
              drop_cache(), stats()
"""

import ctypes
import json
import os
import struct
import subprocess
from collections import deque

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
H, NL, VOCAB, INNER = 4096, 36, 151936, 12288
PAGE_TOK = 512
NSLOT, MAXPG = 64, 68
LASTBIT = 0x10000


def _load_lib():
    so = os.environ.get("MK_SO") or os.path.join(HERE, "libeng.so")
    if not os.path.exists(so):
        subprocess.check_call(["bash", os.path.join(HERE, "build.sh")])
    lib = ctypes.CDLL(so)
    vp, ci = ctypes.c_void_p, ctypes.c_int
    lib.eng_create.restype = vp
    lib.eng_create.argtypes = [ci] + [vp] * 5
    lib.eng_plan_ints.restype = ci
    lib.eng_tcap.restype = ci
    lib.eng_selcap.restype = ci
    lib.eng_page_bytes.restype = ctypes.c_size_t
    lib.eng_set_plan.restype = None
    lib.eng_set_plan.argtypes = [vp, vp, ci, ci]
    lib.eng_pass.restype = None
    lib.eng_pass.argtypes = [vp, ci, ci, ci, ci, ci, vp, vp, vp, ci, ci]
    lib.eng_read_tokens.restype = None
    lib.eng_read_tokens.argtypes = [vp, vp, ci]
    lib.eng_poison_page.restype = None
    lib.eng_poison_page.argtypes = [vp, ci]
    lib.eng_stat.restype = ctypes.c_longlong
    lib.eng_stat.argtypes = [vp, ci]
    lib.eng_sync.restype = None
    lib.eng_destroy.restype = None
    lib.eng_destroy.argtypes = [vp]
    return lib


def pack_matrix(w: torch.Tensor) -> torch.Tensor:
    """[M, K] bf16 -> int16 stream in MMA A-fragment order: [tile][kstep][lane = 4*g + t][ch][rh][e],
    element = W[tile*16 + rh*8 + g][kstep*16 + ch*8 + t*2 + e]. A warp reads 512 contiguous bytes per MMA."""
    m, k = w.shape
    v = w.contiguous().view(torch.int16).view(m // 16, 2, 8, k // 16, 2, 4, 2)
    return v.permute(0, 3, 2, 5, 4, 1, 6).reshape(-1)


class _Weights:
    """Reads tensors from the safetensors shards straight to the GPU, one at a time."""

    def __init__(self, model_dir):
        self.dir = model_dir
        with open(os.path.join(model_dir, "model.safetensors.index.json")) as f:
            self.map = json.load(f)["weight_map"]
        self.headers = {}

    def get(self, name) -> torch.Tensor:
        fn = os.path.join(self.dir, self.map[name])
        if fn not in self.headers:
            with open(fn, "rb") as f:
                n = struct.unpack("<Q", f.read(8))[0]
                self.headers[fn] = (json.loads(f.read(n)), 8 + n)
        hdr, base = self.headers[fn]
        e = hdr[name]
        assert e["dtype"] == "BF16", (name, e["dtype"])
        b0, b1 = e["data_offsets"]
        arr = np.memmap(fn, dtype=np.int16, mode="r", offset=base + b0, shape=((b1 - b0) // 2,))
        t = torch.from_numpy(np.array(arr)).cuda()
        return t.view(torch.bfloat16).view(e["shape"])


class _Req:
    __slots__ = ("rid", "prompt", "n_in", "n_out", "slot", "pos", "produced", "pages", "t_submit")

    def __init__(self, rid, prompt, n_out):
        self.rid, self.prompt, self.n_in, self.n_out = rid, np.asarray(prompt, dtype=np.int32), len(prompt), int(n_out)
        self.slot, self.pos, self.produced, self.pages = -1, 0, 0, []


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        self.lib = _load_lib()
        self.max_batch, self.max_context = max_batch, max_context
        wts = _Weights(model_dir)
        layer_i16 = (6144 * 4096 + 4096 * 4096 + 24576 * 4096 + 4096 * 12288)
        total = NL * layer_i16 + VOCAB * H
        self.W = torch.empty(total, dtype=torch.int16, device="cuda")
        self.norm_w = torch.empty((2 * NL + 1, H), dtype=torch.float32, device="cuda")
        self.qk_norm_w = torch.empty((NL, 2, 128), dtype=torch.float32, device="cuda")
        off = 0

        def put(w):
            nonlocal off
            p = pack_matrix(w)
            self.W[off : off + p.numel()] = p
            off += p.numel()

        for l in range(NL):
            pre = f"model.layers.{l}."
            q, k, v = (wts.get(pre + f"self_attn.{n}_proj.weight") for n in "qkv")
            put(torch.cat([q, k, v], dim=0))
            del q, k, v
            put(wts.get(pre + "self_attn.o_proj.weight"))
            g = wts.get(pre + "mlp.gate_proj.weight")
            u = wts.get(pre + "mlp.up_proj.weight")
            # tile i = gate rows 8i..8i+7 then up rows 8i..8i+7: silu(gate)*up is computed inside one thread
            put(torch.cat([g.view(INNER // 8, 8, H), u.view(INNER // 8, 8, H)], dim=1).reshape(2 * INNER, H))
            del g, u
            put(wts.get(pre + "mlp.down_proj.weight"))
            self.norm_w[2 * l] = wts.get(pre + "input_layernorm.weight").float()
            self.norm_w[2 * l + 1] = wts.get(pre + "post_attention_layernorm.weight").float()
            self.qk_norm_w[l, 0] = wts.get(pre + "self_attn.q_norm.weight").float()
            self.qk_norm_w[l, 1] = wts.get(pre + "self_attn.k_norm.weight").float()
        put(wts.get("lm_head.weight"))
        assert off == total
        self.norm_w[2 * NL] = wts.get("model.norm.weight").float()
        self.embed = wts.get("model.embed_tokens.weight").contiguous()
        # RoPE table exactly as the reference computes it (float32 angles)
        inv_freq = 1.0 / (1000000.0 ** (torch.arange(0, 128, 2, dtype=torch.float) / 128))
        ang = torch.arange(max_context, dtype=torch.float)[:, None] * inv_freq[None, :]
        self.rope = torch.cat([ang.cos(), ang.sin()], dim=1).contiguous().cuda()
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        self.n_slots = min(max_batch, NSLOT)
        self.max_pages_per_seq = min(MAXPG, -(-max_context // PAGE_TOK))
        page_bytes = self.lib.eng_page_bytes()
        free, _ = torch.cuda.mem_get_info()
        reserve = int(float(os.environ.get("MK_RESERVE_GB", "1.5")) * 2**30)
        self.n_pages = int(min(self.n_slots * self.max_pages_per_seq, (free - reserve) // page_bytes))
        if os.environ.get("MK_PAGES"):
            self.n_pages = min(self.n_pages, int(os.environ["MK_PAGES"]))
        self.h = self.lib.eng_create(self.n_pages, self.W.data_ptr(), self.embed.data_ptr(), self.norm_w.data_ptr(),
                                     self.qk_norm_w.data_ptr(), self.rope.data_ptr())
        if not self.h:
            raise RuntimeError("eng_create failed")
        self.TCAP, self.SELCAP = self.lib.eng_tcap(), self.lib.eng_selcap()
        self.PL_SLOT, self.PL_POS, self.PL_TOK, self.PL_UNIT = 0, self.TCAP, 2 * self.TCAP, 3 * self.TCAP
        self.PL_SEL = 5 * self.TCAP
        self.PL_PT = self.PL_SEL + 2 * self.SELCAP
        self.plan = np.zeros(self.lib.eng_plan_ints(), dtype=np.int32)
        assert self.plan.size == self.PL_PT + NSLOT * MAXPG
        self.pt = self.plan[self.PL_PT:].reshape(NSLOT, MAXPG)   # view: page table inside the plan
        self.free_pages = list(range(self.n_pages - 1, -1, -1))
        self.poison = bool(int(os.environ.get("MK_POISON", "0")))  # tests: NaN in every page that is freed
        if self.poison:
            for p in range(self.n_pages):
                self.lib.eng_poison_page(self.h, p)
        # offline state
        self.pos = 0
        self._off_B = 0
        self._off_pages = [[] for _ in range(NSLOT)]
        self._keep = None
        # online state
        self.queue = deque()
        self.running = {}                 # slot -> _Req
        self.free_slots = list(range(self.n_slots - 1, -1, -1))
        self.budget = int(os.environ.get("MK_BUDGET", "1024"))   # columns per pass
        self.dec_unit_max = int(os.environ.get("MK_DEC_UNIT", "4"))  # runs up to this length use the block-parallel attention
        self.counters = dict(passes=0, host_syncs=0, columns=0, prefill_columns=0, decode_columns=0, admitted=0,
                             finished=0, queue_max=0, pages_min_free=self.n_pages)

    # ------------------------------------------------------------------ pages
    def _alloc(self, n):
        if len(self.free_pages) < n:
            return None
        return [self.free_pages.pop() for _ in range(n)]

    def _free(self, pages):
        for p in pages:
            if self.poison:
                self.lib.eng_poison_page(self.h, p)
            self.free_pages.append(p)

    def _upload(self):
        self.lib.eng_set_plan(self.h, self.plan.ctypes.data, 0, self.plan.size)

    # ------------------------------------------------------------------ offline contract
    def reset(self) -> None:
        self.pos = 0
        for b in range(NSLOT):
            if self._off_pages[b]:
                self._free(self._off_pages[b])
                self._off_pages[b] = []
        self._off_B = 0

    def _off_prepare(self, B, last_pos):
        """slots 0..B-1 own pages up to position last_pos; the plan is the B columns at position pos_add"""
        need = last_pos // PAGE_TOK + 1
        changed = B != self._off_B
        for b in range(B):
            while len(self._off_pages[b]) < need:
                got = self._alloc(1)
                if got is None:
                    raise RuntimeError("out of KV pages")
                self.pt[b, len(self._off_pages[b])] = got[0]
                self._off_pages[b].append(got[0])
                changed = True
        if changed:
            p = self.plan
            for b in range(B):
                p[self.PL_SLOT + b] = b | LASTBIT
                p[self.PL_POS + b] = 0
                p[self.PL_TOK + b] = -1
                p[self.PL_UNIT + 2 * b] = b
                p[self.PL_UNIT + 2 * b + 1] = 1
                p[self.PL_SEL + 2 * b] = b
                p[self.PL_SEL + 2 * b + 1] = b
            self._off_B = B
            self._upload()

    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        if tokens.dtype != torch.int64 or not tokens.is_contiguous():
            tokens = tokens.to(torch.int64).contiguous()
        B = tokens.shape[0]
        self._off_prepare(B, self.pos)
        logits = torch.empty((B, VOCAB), dtype=torch.float32, device="cuda")
        self.lib.eng_pass(self.h, B, 0, B, B, self.pos, tokens.data_ptr(), logits.data_ptr(), None, 0, 0)
        self.pos += 1
        self._keep = tokens  # the kernels read it asynchronously
        return logits

    def generate(self, tokens: torch.Tensor, n_steps: int) -> torch.Tensor:
        """Greedy decode n_steps tokens: argmax and token feedback are on the device, the host only launches."""
        if tokens.dtype != torch.int64 or not tokens.is_contiguous():
            tokens = tokens.to(torch.int64).contiguous()
        B = tokens.shape[0]
        if self.pos + n_steps > self.max_context:
            raise ValueError("generate() would exceed max_context")
        self._off_prepare(B, self.pos + n_steps - 1)
        out = torch.empty((B, n_steps), dtype=torch.int64, device="cuda")
        for i in range(n_steps):
            self.lib.eng_pass(self.h, B, 0, B, B, self.pos + i, tokens.data_ptr() if i == 0 else None, None, out.data_ptr(), n_steps, i)
        self.pos += n_steps
        self._keep = tokens
        return out

    # ------------------------------------------------------------------ online contract
    def submit(self, rid: int, prompt, max_new_tokens: int) -> None:
        self.queue.append(_Req(rid, prompt, max_new_tokens))
        self.counters["queue_max"] = max(self.counters["queue_max"], len(self.queue))

    def idle(self) -> bool:
        return not self.queue and not self.running

    def kv_pages(self):
        return (len(self.free_pages), self.n_pages)

    def drop_cache(self) -> None:
        pass  # no prefix is retained yet

    def _admit(self):
        while self.queue and self.free_slots:
            r = self.queue[0]
            need = (r.n_in + r.n_out - 1 + PAGE_TOK - 1) // PAGE_TOK
            pages = self._alloc(need)
            if pages is None:
                break
            self.queue.popleft()
            r.slot, r.pages = self.free_slots.pop(), pages
            self.pt[r.slot, :need] = pages
            self.running[r.slot] = r
            self.counters["admitted"] += 1
            self.counters["pages_min_free"] = min(self.counters["pages_min_free"], len(self.free_pages))

    def _run_pass(self, runs, want_logits=False):
        """runs: [(slot, pos0, tokens or None (decode: the slot's last token), select_last)]. Fills the plan,
        launches the pass. Returns the list of selected (run index)."""
        p = self.plan
        col, sel, pre, dec = 0, [], [], []
        for ri, (slot, pos0, toks, select) in enumerate(runs):
            n = 1 if toks is None else len(toks)
            p[self.PL_SLOT + col : self.PL_SLOT + col + n] = slot
            p[self.PL_SLOT + col + n - 1] = slot | LASTBIT
            p[self.PL_POS + col : self.PL_POS + col + n] = np.arange(pos0, pos0 + n, dtype=np.int32)
            p[self.PL_TOK + col : self.PL_TOK + col + n] = -1 if toks is None else toks
            # attention units of at most 4 positions; short runs (decode rows) get a whole block per kv head
            (dec if n <= self.dec_unit_max else pre).extend((col + c0, min(4, n - c0)) for c0 in range(0, n, 4))
            if select == 1:
                p[self.PL_SEL + 2 * len(sel)] = col + n - 1
                p[self.PL_SEL + 2 * len(sel) + 1] = slot
                sel.append(ri)
            elif select == 2:   # tests: every column of the run
                for i in range(n):
                    p[self.PL_SEL + 2 * len(sel)] = col + i
                    p[self.PL_SEL + 2 * len(sel) + 1] = slot if i == n - 1 else -1
                    sel.append(ri)
            col += n
        units = np.asarray(pre + dec, dtype=np.int32).reshape(-1)
        p[self.PL_UNIT : self.PL_UNIT + units.size] = units
        assert col <= self.TCAP and len(sel) <= self.SELCAP
        self._upload()
        logits = torch.empty((len(sel), VOCAB), dtype=torch.float32, device="cuda") if want_logits else None
        self.lib.eng_pass(self.h, col, len(pre), len(dec), len(sel), 0, None, logits.data_ptr() if want_logits else None, None, 0, 0)
        self.counters["passes"] += 1
        self.counters["columns"] += col
        return sel, logits

    def poll(self):
        self._admit()
        if not self.running:
            return []
        runs, owners = [], []
        budget = self.budget
        decoding = [r for r in self.running.values() if r.pos >= r.n_in]
        for r in decoding:
            runs.append((r.slot, r.pos, None, 1))
            owners.append((r, 1))
        budget -= len(decoding)
        self.counters["decode_columns"] += len(decoding)
        for r in self.running.values():        # insertion order = admission order
            if r.pos >= r.n_in or budget <= 0:
                continue
            n = min(r.n_in - r.pos, budget)
            runs.append((r.slot, r.pos, r.prompt[r.pos : r.pos + n], 1 if r.pos + n == r.n_in else 0))
            owners.append((r, n))
            budget -= n
            self.counters["prefill_columns"] += n
        sel, _ = self._run_pass(runs)
        toks = np.empty(max(1, len(sel)), dtype=np.int32)
        if sel:
            self.lib.eng_read_tokens(self.h, toks.ctypes.data, len(sel))
        else:
            self.lib.eng_sync()
        self.counters["host_syncs"] += 1
        events = []
        for r, n in owners:
            r.pos += n
        for j, ri in enumerate(sel):
            r = owners[ri][0]
            r.produced += 1
            done = r.produced >= r.n_out
            events.append((r.rid, [int(toks[j])], done))
            if done:
                del self.running[r.slot]
                self.free_slots.append(r.slot)
                self._free(r.pages)
                r.pages = []
                self.counters["finished"] += 1
        return events

    # ------------------------------------------------------------------
    def close(self) -> None:
        if getattr(self, "h", None):
            self.lib.eng_destroy(self.h)
            self.h = None
        self.W = self.embed = self.norm_w = self.qk_norm_w = self.rope = None

    def stats(self) -> dict:
        s = {
            "implementation": "pass engine (eng.cu): decode rows and prefill chunks in one pass over the weights",
            "kernel_launches": int(self.lib.eng_stat(self.h, 0)),
            "passes": int(self.lib.eng_stat(self.h, 1)),
            "plan_uploads": int(self.lib.eng_stat(self.h, 3)),
            "token_reads": int(self.lib.eng_stat(self.h, 4)),
            "kv_pages_total": self.n_pages,
            "kv_pages_free": len(self.free_pages),
            "queue": len(self.queue),
            "running": len(self.running),
            "budget_columns": self.budget,
            "max_batch": self.max_batch,
            "max_context": self.max_context,
        }
        s.update(self.counters)
        return s
