// Inkling-2-Small decode engine: one persistent kernel per card per step, four cards.
// Attention TP4 by heads, experts TP4 inside every expert (intermediate 576 per card), everything else replicated.
// See notes/plan.md for the design and the layouts.
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

typedef __nv_bfloat16 bf16;

#define H 4608
#define NL 48
#define NE 384
#define TOPK 8
#define ILOC 576
#define HD 128
#define NQL 12          // local q heads
#define NKVL 2          // local kv heads
#define DREL 16
#define RELEXT 1024
#define WIN 1024
#define NCARD 4
#define MAXB 8
#ifndef NTH
#define NTH 768   // 85 registers per thread (1024 threads: 64 and heavy spills; measured 5.95 -> 5.40 ms at B=1, e0056)
#endif
#define NWARP (NTH / 32)
#define CHUNK 128       // attention positions per block
#define MAXCHUNK 17     // up to 2176 positions
#define MAXU 64         // max union experts per layer (B<=8)
#define VOCAB_REAL 200058
#ifndef MAXSLOT
#define MAXSLOT 24
#endif

// ------------------------------------------------------------------------------------------------ parameters
struct W12M {               // exact 12-bit code of a BF16 matrix (engine/w12.py)
  const uint8_t* data;      // [strips][units][3][32][16]
  const uint8_t* base;      // [rows] window base exponent
  const int* hdr;           // [strips*units] escape count | offset << 8
  const int* esc;           // entries: lane<<27 | reg<<23 | half<<22 | bf16 bits
};
struct LayerW {
  const uint8_t* wqkv;      // bf16 frag [strips][U=72][4 j][32 lanes][16 B]
  const uint8_t* wo;        // bf16 frag [288][24]...
  const uint8_t* wr;        // router bf16 frag [24][72]
  const float* rbias;       // [384]
  const uint8_t* w13;       // [384][72 strips][72 units][UB]
  const uint8_t* w2;        // [384][288 strips][9 units][UB]
  const float* f13;         // [384] weight outer factor (nvfp4), unused for mxfp8
  const float* f2;
  const bf16* norm[3];      // attn_norm (local layers: all three the same) or q/k/v_input_norm
  const bf16* mlp_norm;
  const bf16* ksc;          // local: [256][4] (local channels); global: static_w [4][256]
  const bf16* vsc;
  const bf16* attn_sc;      // [4608][4]
  const bf16* mlp_sc;
  const bf16* qscale;       // [12][128]
  const bf16* rscale;       // [12][16]
  const bf16* relp;         // [16][1024]
  const float* aq;          // attention residual queries [nq][4608] (layer 0: null)
  const float* mq;          // [4608]
  W12M qkv12, wo12, wr12;
  int glob;                 // global layer
  int mx;                   // experts are mxfp8
  int qkv_strips;           // 237 or 239
  int pad;
};

struct Comm {                       // lives on each card, written by all cards
  // low-latency exchange: every value travels with its tag in one 8-byte store; buffers alternate by layer parity
  uint2 lla[2][NCARD][MAXB][H];       // o_proj partial per source card, token-major: (float bits, tag)
  uint2 llm[2][NCARD][MAXB][H];       // w2 partial
  uint2 llx[NL][NCARD][MAXU][MAXB];   // per source card: max |act| of its 576-slice per (union expert, token)
  float cand_v[NCARD][MAXB][256];   // argmax candidates per source card per block
  int cand_i[NCARD][MAXB][256];
  unsigned cnt[8];                  // 0 attn, 1 mlp, 2 amax, 3 final
};

struct Hdr {
  int card, B, nblk, pos, parity, want_logits, gen_idx, gen_n;
  unsigned xbase[4];
  unsigned tag0, mode;                // tags of this step: tag0 + layer + 1; mode: 0 normal, 1 also keep the normed
                                      // embedding in c.partial (table build), 2 use the layer-0 token tables (track B)
  float* logits; int* tokens; int* gen_out;
};
struct Ctx {
  Hdr h;
  LayerW L[NL];
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm;
  const uint8_t* unembed; int un_strips; int un_row0;
  W12M un12;
  bf16* blocks;     // [9][MAXB][H] finished blocks (block 0 = h0)
  bf16* partial;    // [MAXB][H]
  bf16* attn_s;     // [MAXB][H]  attention output after its sconv (current layer)
  bf16* hist_attn;  // [NL][MAXB][3][H]
  bf16* hist_mlp;   // [NL][MAXB][3][H]
  bf16* hist_k;     // [NL][MAXB][3][256]
  bf16* hist_v;
  bf16* kc; bf16* vc; int maxctx; int pad0;  // [NL][MAXB][2][maxctx][128]
  bf16* xfrag;      // [3][72 units][32][4][2][2] bf16 frags of xq/xk/xv
  bf16* x2frag;     // router frag of the mlp input (bf16)
  uint8_t* w13frag; // quantized mlp input: f16 frag (nvfp4) or e4m3 frag (mxfp8)
  float* w13sc;     // [MAXB] outer (nvfp4) or [144][MAXB] block scales (mxfp8)
  bf16* qkvo;       // [MAXB][3840]
  float* rlog;      // [MAXB][384]
  int* ids; float* wts;   // [MAXB][8]
  int* uni; int* nuni;
  bf16* act;        // [MAXU][MAXB][576]
  uint8_t* w2frag;  // [MAXU][9 units] frags
  float* w2sc;      // [MAXU][MAXB] / [MAXU][18][MAXB]
  float* achunk;    // [MAXB][2][MAXCHUNK][6][2+128]
  unsigned* acnt;   // [MAXB][2]
  bf16* ofrag;      // o_proj B frag
  bf16* hfrag;      // final hidden frag
  float* part;      // gemv partial slots
  unsigned* scnt;   // per-strip arrival counters
  int* next_tok;    // [MAXB]
  unsigned* bar;    // [0] counter, [1] base
  Comm* comm[NCARD];
  unsigned long long* tprof;  // optional [NL+1][16] globaltimer stamps of block 0
  bf16* dbg;        // optional [NL][2][MAXB][H]: attention and mlp outputs after their sconv
  int* dbg_ids;     // optional [NL][MAXB][8]
  unsigned* amax_loc;  // [MAXU][MAXB] local running max (float bits), reset by the last strip of each expert
  unsigned* ucnt;      // [MAXU] strips finished per union expert
  uint2* rll;          // [MAXB][384] router logits as (float bits, tag): routing polls them (no grid barrier)
  float* qd;           // [9][128] B=1: dots of the finished residual blocks with every later sublayer query
  bf16* rconv;         // [2][H] B=1: the conv output of the attention / MLP all-reduce, published by block 0
  unsigned* rtag;      // [2] its tag
  uint2* rtk;          // [MAXB][8][2] B>=2: a token's chosen experts and weights as (bits, tag), published by its block
  uint2* lls;          // [2][MAXB][H] conv output of the attention / MLP all-reduce as (float bits, tag), by the helpers
  const bf16* l0tab;   // [vocab][3840] track B: this card's layer-0 projections (q, gate, r, sink, k, v rows) per token id
};

// Phases as separate functions (own register allocation and spill slots) or inlined into the step function:
// NI_RED / NI_STD choose it per kernel (B = 1 / B >= 2) for the per-token vector phases and attention (measured, e0008:
// B=1 -2.4 %, B=8 +4 % when separate); NI_GEMV for the GEMV calls (slower in both).
#ifndef NI_RED
#define NI_RED 1
#endif
#ifndef NI_STD
#define NI_STD 0
#endif
#define NI_ON(RED) ((RED) ? (NI_RED != 0) : (NI_STD != 0))
#define PH_ATTR __forceinline__
#ifdef NI_GEMV
#define GV_ATTR __noinline__
#else
#define GV_ATTR __forceinline__
#endif
#ifndef QCACHE
#define QCACHE 0   // B=1: finished blocks' norms and query dots computed once (cache_block): bit-identical, but the
                   // work it removes was hidden behind the wait for the other cards' data, and 4.6 KB more shared
                   // memory slowed every phase (4681 -> 4981 us, e0026)
#endif
// ------------------------------------------------------------------------------------------------ small helpers
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint4 ld4(const void* p) { return *reinterpret_cast<const uint4*>(p); }
__device__ __forceinline__ uint32_t cvt_fp4x2(uint32_t b) {
  uint32_t r; unsigned short bs = (unsigned short)b;
  asm("{ .reg .b8 t; cvt.u8.u16 t, %1; cvt.rn.f16x2.e2m1x2 %0, t; }" : "=r"(r) : "h"(bs));
  return r;
}
__device__ __forceinline__ uint32_t cvt_e4m3x2_f16x2(uint32_t w16) {
  uint32_t r; unsigned short h = (unsigned short)w16;
  asm("cvt.rn.f16x2.e4m3x2 %0, %1;" : "=r"(r) : "h"(h));
  return r;
}
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ uint32_t prmt(uint32_t a, uint32_t b, uint32_t s) { uint32_t r; asm("prmt.b32 %0,%1,%2,%3;" : "=r"(r) : "r"(a), "r"(b), "r"(s)); return r; }
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_e4m3(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float ue8m0(uint32_t e) { return e == 0 ? __int_as_float(0x00400000) : __int_as_float(e << 23); }
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float rbf(float x) { return bf(tobf(x)); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }

__device__ __forceinline__ unsigned ld_relaxed_gpu(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ unsigned ld_relaxed_sys(const unsigned* p) { unsigned v; asm volatile("ld.relaxed.sys.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void fence_acqrel_gpu() { asm volatile("fence.acq_rel.gpu;" ::: "memory"); }
__device__ __forceinline__ void fence_acqrel_sys() { asm volatile("fence.acq_rel.sys;" ::: "memory"); }
__device__ __forceinline__ unsigned ld_acquire_gpu(const unsigned* p) { unsigned v; asm volatile("ld.acquire.gpu.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ unsigned ld_acquire_sys(const unsigned* p) { unsigned v; asm volatile("ld.acquire.sys.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void red_release_gpu(unsigned* p, unsigned v) { asm volatile("red.release.gpu.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void red_relaxed_sys(unsigned* p, unsigned v) { asm volatile("red.relaxed.sys.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }
__device__ __forceinline__ void red_release_sys(unsigned* p, unsigned v) { asm volatile("red.release.sys.global.add.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }

// bf16/f16 B-fragment index (m16n8k16), unit-major: element (token g, k) -> index in 16-bit elements
__device__ __forceinline__ int fidx16(int g, int k) {
  int u = k >> 6, j = (k >> 4) & 3, kk = k & 15, r = kk >> 3, t = (kk & 7) >> 1, h = kk & 1;
  return ((((u * 32 + g * 4 + t) * 4 + j) * 2 + r) * 2 + h);
}
// e4m3 B-fragment index (m16n8k32), unit = 64 k: element (g, k) -> byte index
__device__ __forceinline__ int fidx8(int g, int k) {
  int u = k >> 6, s = (k >> 5) & 1, kk = k & 31, r = kk >> 4, t = (kk & 15) >> 2, e = kk & 3;
  return ((((u * 32 + g * 4 + t) * 2 + s) * 2 + r) * 4 + e);
}

// compact layouts for B == 1 (column 0 only): lanes t = 0..3 of g = 0
__device__ __forceinline__ int fidx16c(int k) {
  int u = k >> 6, j = (k >> 4) & 3, kk = k & 15, r = kk >> 3, t = (kk & 7) >> 1, h = kk & 1;
  return ((((u * 4 + t) * 4 + j) * 2 + r) * 2 + h);
}
__device__ __forceinline__ int fidx8c(int k) {
  int u = k >> 6, s = (k >> 5) & 1, kk = k & 31, r = kk >> 4, t = (kk & 15) >> 2, e = kk & 3;
  return ((((u * 4 + t) * 2 + s) * 2 + r) * 4 + e);
}
template <bool CPT> __device__ __forceinline__ int fi16(int g, int k) { return CPT ? fidx16c(k) : fidx16(g, k); }
template <bool CPT> __device__ __forceinline__ int fi8(int g, int k) { return CPT ? fidx8c(k) : fidx8(g, k); }
#define LSZ (CPT ? 4 : 32)
#define LSL (CPT ? (lane & 3) : lane)
// ------------------------------------------------------------------------------------------------ barriers
__device__ unsigned g_barbase_dummy;
__device__ __forceinline__ void grid_bar(const Ctx& c, unsigned& nbar, unsigned base) {
  __syncthreads();
  nbar += 1;
  if (threadIdx.x == 0) {
    unsigned target = base + nbar * gridDim.x;
    red_release_gpu(&c.bar[0], 1);
    while ((int)(ld_relaxed_gpu(&c.bar[0]) - target) < 0) { }
    fence_acqrel_gpu();
  }
  __syncthreads();
}
// cross-card events. Host keeps xbase[k] = events of kind k before this launch.
#ifndef XSIG_FLAT
#define XSIG_HIER
#endif
#ifdef XSIG_HIER
// local grid barrier, then block 0 signals every card once (measured: 152 per-block system fences cost 5-10 us)
#define XPER 1u
#else
// every block of every card signals counter k on every card
#define XPER gridDim.x
#endif
__device__ __forceinline__ void xsignal(const Ctx& c, int k, unsigned& nbar, unsigned base);
__device__ __forceinline__ void xwait(const Ctx& c, int k, unsigned events) {
  if (threadIdx.x == 0) {
    unsigned target = (c.h.xbase[k] + events) * NCARD * XPER;
    const unsigned* p = &c.comm[c.h.card]->cnt[k];
    while ((int)(ld_relaxed_sys(p) - target) < 0) { }
    fence_acqrel_sys();
  }
  __syncthreads();
}

__device__ __forceinline__ void xsignal(const Ctx& c, int k, unsigned& nbar, unsigned base) {
#ifdef XSIG_HIER
  grid_bar(c, nbar, base);
  if (blockIdx.x == 0 && threadIdx.x == 0) {
    __threadfence_system();
    for (int d = 0; d < NCARD; d++) red_relaxed_sys(&c.comm[d]->cnt[k], 1);   // ordered by the fence above
  }
#else
  __syncthreads();
  if (threadIdx.x == 0) {
    __threadfence_system();
    for (int d = 0; d < NCARD; d++) red_relaxed_sys(&c.comm[d]->cnt[k], 1);   // ordered by the fence above
  }
#endif
}
// LL protocol: producer stores (value, tag) as one 8-byte store; consumer re-reads until the tag matches
__device__ __forceinline__ void ll_put(uint2* p, float v, unsigned tag) {
  asm volatile("st.relaxed.sys.global.v2.u32 [%0], {%1, %2};" :: "l"(p), "r"(__float_as_uint(v)), "r"(tag) : "memory");
}
__device__ __forceinline__ uint4 ld_relaxed_sys_v4(const void* p) {
  uint4 r;
  asm volatile("ld.relaxed.sys.global.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p) : "memory");
  return r;
}
__device__ __forceinline__ uint2 ld_relaxed_sys_v2(const void* p) {
  uint2 r;
  asm volatile("ld.relaxed.sys.global.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p) : "memory");
  return r;
}
// two neighbouring elements in one 16-byte store (half the cross-card stores)
__device__ __forceinline__ void ll_put2(uint2* p, float v0, float v1, unsigned tag) {
  asm volatile("st.relaxed.sys.global.v4.u32 [%0], {%1, %2, %3, %2};" :: "l"(p), "r"(__float_as_uint(v0)), "r"(tag), "r"(__float_as_uint(v1)) : "memory");
}
// two (value, tag) pairs; spins until both tags are current
#ifndef LL_BACKOFF
#define LL_BACKOFF 16   // (32: +0.5 % at B=1; 64, 128: slower, e0031)
#endif
__device__ __forceinline__ float2 ll_get2(const uint2* p, unsigned tag) {
  uint4 r = ld_relaxed_sys_v4(p);
  while (r.y != tag || r.w != tag) { __nanosleep(LL_BACKOFF); r = ld_relaxed_sys_v4(p); }
  return make_float2(__uint_as_float(r.x), __uint_as_float(r.z));
}
__device__ __forceinline__ float ll_get1(const uint2* p, unsigned tag) {
  uint2 r = ld_relaxed_sys_v2(p);
  while (r.y != tag) { __nanosleep(LL_BACKOFF); r = ld_relaxed_sys_v2(p); }
  return __uint_as_float(r.x);
}
#ifndef POLL_PAR_STD
#define POLL_PAR_STD 1
#endif
// conv helpers (see conv_help_one), per kernel: B>=2 on (-1.0 %: 7153 -> 7083 us); B=1 off (+1.6 %: the helper warps
// share their SM with the block's own token phase, e0050)
#ifndef CONVH_RED
#define CONVH_RED 0
#endif
#ifndef CONVH_STD
#define CONVH_STD 1
#endif
#ifndef ATT_TC_STD
#define ATT_TC_STD 0   // B>=2: attention as its own function with the tensor-core scores
#endif
#ifndef ATT_TC
#define ATT_TC 1
#endif
#ifndef ROUTE_DIST
#define ROUTE_DIST 1
#endif
#ifdef PF_WARP0
#define PFW(w) 0
#else
#define PFW(w) (w)
#endif
#ifndef W2PF_RED
#define W2PF_RED 1
#endif
#ifndef W2PF_STD
#define W2PF_STD 2
#endif
#ifndef KVPF
#define KVPF 1
#endif
#ifndef KVPF_STD
#define KVPF_STD 1
#endif
// ------------------------------------------------------------------------------------------------ L2 prefetch
// part `part` of `nparts` of [base, base+bytes): warp 0's lanes issue bulk L2 prefetches of 32 KB.
__device__ __forceinline__ void prefetch_l2(const void* base, long bytes, int part, int nparts, int warp = 0) {
#ifndef NO_PREFETCH
  if ((int)(threadIdx.x >> 5) != warp || nparts <= 0) return;
  long a = (bytes * part / nparts) & ~15L, b = (bytes * (part + 1) / nparts) & ~15L;
  if (part == nparts - 1) b = bytes & ~15L;
  const char* p = (const char*)base;
  for (long o = a + (long)(threadIdx.x & 31) * 32768; o < b; o += 32L * 32768) {
    unsigned n = (unsigned)min(32768L, b - o);
    asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(p + o), "r"(n) : "memory");
  }
#endif
}
// what the next dense GEMV will stream (the W12 build has no BF16 copy: a prefetch of a null range faults per page
// and made the first W12 build 10x slower, run s6)
#ifdef W12
#define PF_QKV(L) (L).qkv12.data, (long)(L).qkv_strips * 72 * 1536
#define PF_WO(L) (L).wo12.data, 288L * 24 * 1536
#define PF_WR(L) (L).wr12.data, 24L * 72 * 1536
#else
#define PF_QKV(L) (L).wqkv, (long)(L).qkv_strips * 72 * 2048
#define PF_WO(L) (L).wo, 288L * 24 * 2048
#define PF_WR(L) (L).wr, 24L * 72 * 2048
#endif
__device__ __forceinline__ unsigned long long gtime() { unsigned long long t; asm volatile("mov.u64 %0, %globaltimer;" : "=l"(t)); return t; }
#define TM(li, id) do { if (c.tprof && blockIdx.x == 0 && threadIdx.x == 0) c.tprof[(li) * 64 + (id)] = gtime(); } while (0)
// ------------------------------------------------------------------------------------------------ block reductions
template <int N>
__device__ __forceinline__ void block_sum(float* v, float* red) {  // red: smem [NWARP][N]
  int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
#pragma unroll
  for (int i = 0; i < N; i++) {
    float x = v[i];
#pragma unroll
    for (int o = 16; o; o >>= 1) x += __shfl_xor_sync(0xffffffff, x, o);
    v[i] = x;
  }
  __syncthreads();
  if (lane == 0)
#pragma unroll
    for (int i = 0; i < N; i++) red[w * N + i] = v[i];
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) {
    float s = 0.f;
    for (int j = 0; j < NWARP; j++) s += red[j * N + i];
    v[i] = s;
  }
  __syncthreads();
}
__device__ __forceinline__ float block_max1(float x, float* red) {
  int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  for (int o = 16; o; o >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffff, x, o));
  __syncthreads();
  if (lane == 0) red[w] = x;
  __syncthreads();
  float m = red[0];
  for (int j = 1; j < NWARP; j++) m = fmaxf(m, red[j]);
  __syncthreads();
  return m;
}

#define PER ((H + NTH - 1) / NTH)   // 5 elements per thread (the last one only for tid < 512)
#define VALID(e) (threadIdx.x + (e) * NTH < H)
// element e of thread: idx = threadIdx.x + e * NTH

// rms_norm of fp32 vector (per-thread regs) with bf16 weight -> bf16 values (as float)
__device__ __forceinline__ void rmsnorm_regs(const float* u, const bf16* w, float* y, float* red) {
  float s[1] = {0.f};
#pragma unroll
  for (int e = 0; e < PER; e++) if (VALID(e)) s[0] += u[e] * u[e];
  block_sum<1>(s, red);
  float r = rsqrtf(s[0] / (float)H + 1e-6f);
#pragma unroll
  for (int e = 0; e < PER; e++) {
    if (!VALID(e)) { y[e] = 0.f; continue; }
    float v = u[e] * r;
    if (w) v = v * bf(w[threadIdx.x + e * NTH]);
    y[e] = rbf(v);
  }
}

__device__ __forceinline__ float sconv4f(float h0, float h1, float h2, float cur, const float* w4) {
  float acc = 0.f;
  acc = acc + h0 * w4[0];
  acc = acc + h1 * w4[1];
  acc = acc + h2 * w4[2];
  acc = acc + cur * w4[3];
  return rbf((acc + cur) * 0.4472135954999579f);
}
// static short conv over [hist0, hist1, hist2, cur]; weight [C][4]; returns bf16-rounded float
__device__ __forceinline__ float sconv4(float h0, float h1, float h2, float cur, const bf16* w4) {
  float acc = 0.f;
  acc = acc + h0 * bf(w4[0]);
  acc = acc + h1 * bf(w4[1]);
  acc = acc + h2 * bf(w4[2]);
  acc = acc + cur * bf(w4[3]);
  return rbf((acc + cur) * 0.4472135954999579f);
}

// ------------------------------------------------------------------------------------------------ GEMV skeleton
// Flattened (strip, unit) space split evenly over all warps of the grid. A strip covered by several warps is
// summed in slot order by the last warp to arrive (per-strip counter). Epilogue gets per-lane d0..d3
// (row g, col 2t), (g, 2t+1), (g+8, 2t), (g+8, 2t+1).
__device__ __forceinline__ long wstart(long T, long w, long NW) { return T * w / NW; }
__device__ __forceinline__ long warp_of(long x, long T, long NW) { return ((x + 1) * NW - 1) / T; }

#ifndef MINU
#define MINU 4
#endif
template <class OP>
__device__ void gemv(const Ctx& c, OP& op, long strips, int U) {
  const long T = strips * U;
  const long NWALL = (long)gridDim.x * NWARP;
  const long NW = max(1L, min(NWALL, T / MINU));
  // logical warp index. Ops that use every warp: block-contiguous ranges (a block streams one contiguous region;
  // the strided mapping put a block's 32 streams 729 KB apart in lockstep and some blocks ran 2x slower).
  // Small ops: consecutive logical warps on different SMs.
#ifndef GW_SPREAD_ALL
  const long gw = (NW == NWALL) ? (long)blockIdx.x * NWARP + (threadIdx.x >> 5) : (long)(threadIdx.x >> 5) * gridDim.x + blockIdx.x;
#else
  const long gw = (long)(threadIdx.x >> 5) * gridDim.x + blockIdx.x;
#endif
  if (gw >= NW) return;
  const int lane = threadIdx.x & 31;
  long beg = wstart(T, gw, NW), end = wstart(T, gw + 1, NW);
  long x = beg;
  const bool tmw = c.tprof && op.tm && gw == 0;   // block 0 warp 0 stamps its first strip
  if (tmw && lane == 0) c.tprof[op.layer * 64 + op.tm] = gtime();
  while (x < end) {
    long s = x / U;
    int u0 = (int)(x - s * U);
    int u1 = (int)min((long)U, end - s * U);
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    op.run(c, s, u0, u1, acc);
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 64 + op.tm + 1] = gtime();
    long fw = warp_of(s * U, T, NW), lw = warp_of(s * U + U - 1, T, NW);
    if (fw == lw) {
      op.epi(c, s, acc);
    } else {
      float* slot = c.part + ((s * MAXSLOT + (gw - fw)) * 32 + lane) * 4;
      *reinterpret_cast<float4*>(slot) = make_float4(acc[0], acc[1], acc[2], acc[3]);
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) { __threadfence(); old = atomicAdd(&c.scnt[s], 1u); }
      old = __shfl_sync(0xffffffff, old, 0);
      if (old == (unsigned)(lw - fw)) {
        __threadfence();
        float a[4] = {0.f, 0.f, 0.f, 0.f};
        const int ns = (int)(lw - fw) + 1;
        for (int k0 = 0; k0 < ns; k0 += 8) {
          float4 p[8];
#pragma unroll
          for (int q = 0; q < 8; q++)
            p[q] = (k0 + q < ns) ? __ldcg(reinterpret_cast<const float4*>(c.part + ((s * MAXSLOT + k0 + q) * 32 + lane) * 4))
                                 : make_float4(0.f, 0.f, 0.f, 0.f);
#pragma unroll
          for (int q = 0; q < 8; q++)
            if (k0 + q < ns) { a[0] += p[q].x; a[1] += p[q].y; a[2] += p[q].z; a[3] += p[q].w; }
        }
        if (lane == 0) c.scnt[s] = 0;
        __syncwarp();
        __threadfence();
        op.epi(c, s, a);
      }
    }
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 64 + op.tm + 2] = gtime();
    x = s * U + u1;
  }
}

// Alternative schedule: block b owns strips b, b+nblk, ...; its 32 warps split the strip's units; partials reduced in
// shared memory in warp order (deterministic, no global hand-off). red: 32 warps x 32 lanes x float4 (16 KB).
template <class OP>
__device__ void gemv_blk(const Ctx& c, OP& op, int strips, int U, float* red) {
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  const int u0 = U * w / NWARP, u1 = U * (w + 1) / NWARP;
  for (int s = blockIdx.x; s < strips; s += gridDim.x) {
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    if (u1 > u0) op.run(c, s, u0, u1, acc);
    *reinterpret_cast<float4*>(red + (w * 32 + lane) * 4) = make_float4(acc[0], acc[1], acc[2], acc[3]);
    __syncthreads();
    if (w == (s / gridDim.x) % NWARP) {
      float a[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll 8
      for (int k = 0; k < NWARP; k++) {
        float4 p = *reinterpret_cast<const float4*>(red + (k * 32 + lane) * 4);
        a[0] += p.x; a[1] += p.y; a[2] += p.z; a[3] += p.w;
      }
      op.epi(c, s, a);
    }
    __syncthreads();
  }
}
// Third schedule: block b owns the whole strips [S b / nblk, S (b+1) / nblk); its warps split the block's units evenly.
// A strip cut between warps is summed in warp order by its last warp to arrive, through shared memory (two slots per
// warp: the piece that starts at the warp's range begin, and its last, cut piece; a counter per strip of the block):
// no global hand-off, no fences, deterministic order. slots: [NWARP * 2][32 lanes] float4 (24.6 KB); cnt: 64 words, zero.
template <class OP>
__device__ void gemv_ctg(const Ctx& c, OP& op, long strips, int U, float* slots, unsigned* cnt) {
  const int w = threadIdx.x >> 5, lane = threadIdx.x & 31;
  const long s0 = strips * blockIdx.x / gridDim.x, s1 = strips * (blockIdx.x + 1) / gridDim.x;
  const long T = (s1 - s0) * U;
  if (T <= 0) return;
  const long NW = max(1L, min((long)NWARP, T / MINU));
  if (w >= NW) return;
  const long beg = T * w / NW, end = T * (w + 1) / NW;
  long x = beg;
  const bool tmw = c.tprof && op.tm && blockIdx.x == 0 && w == 0;
  if (tmw && lane == 0) c.tprof[op.layer * 64 + op.tm] = gtime();
  while (x < end) {
    const long ls = x / U;
    const int u0 = (int)(x - ls * U), u1 = (int)min((long)U, end - ls * U);
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    op.run(c, s0 + ls, u0, u1, acc);
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 64 + op.tm + 1] = gtime();
    const long fw = warp_of(ls * U, T, NW), lw = warp_of(ls * U + U - 1, T, NW);
    if (fw == lw) {
      op.epi(c, s0 + ls, acc);
    } else {
      *reinterpret_cast<float4*>(slots + ((w * 2 + (x == beg ? 0 : 1)) * 32 + lane) * 4) = make_float4(acc[0], acc[1], acc[2], acc[3]);
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) old = atomicAdd(&cnt[ls], 1u);
      old = __shfl_sync(0xffffffff, old, 0);
      if (old == (unsigned)(lw - fw)) {
        float a[4] = {0.f, 0.f, 0.f, 0.f};
        for (long k = fw; k <= lw; k++) {
          const int si = (T * k / NW >= ls * U) ? 0 : 1;   // warp k's piece starts at its range begin, or it is its cut tail
          const float4 p = *reinterpret_cast<const float4*>(slots + ((k * 2 + si) * 32 + lane) * 4);
          a[0] += p.x; a[1] += p.y; a[2] += p.z; a[3] += p.w;
        }
        if (lane == 0) cnt[ls] = 0;
        op.epi(c, s0 + ls, a);
      }
    }
    if (tmw && lane == 0 && x == beg) c.tprof[op.layer * 64 + op.tm + 2] = gtime();
    x = ls * U + u1;
  }
}
#ifndef GEMV_CTG
#define GEMV_CTG 40   // ops on the block-contiguous schedule (bits as GEMV_BLK): 8 w13, 32 unembedding
#endif
#ifndef GEMV_BLK
#define GEMV_BLK 23   // qkv, o_proj, router, w2 by block-per-strip (measured best, e0053, e0062)
#endif
template <class OP>
__device__ __forceinline__ void gemv_sel(const Ctx& c, OP& op, long strips, int U, int bit, float* red) {
  if (GEMV_CTG & bit) gemv_ctg(c, op, strips, U, red, reinterpret_cast<unsigned*>(red) + NWARP * 2 * 32 * 4);
  else if (GEMV_BLK & bit) gemv_blk(c, op, (int)strips, U, red);
  else gemv(c, op, strips, U);
}

// BF16 dense: weights [strip][unit][j][lane][16B]; B frags (bf16) [unit][lane][j][2 u32]
template <bool CPT>
__device__ __forceinline__ void run_bf16(const uint8_t* wstrip, const uint32_t* xf, int u0, int u1, float* acc, int B) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  int u = u0;
  for (; u + 2 <= u1; u += 2) {
    uint4 w[8];
#pragma unroll
    for (int q = 0; q < 8; q++) w[q] = ldg_nc(wstrip + ((long)(u + (q >> 2)) * 4 + (q & 3)) * 512 + lane * 16);
    uint4 b[4];
#pragma unroll
    for (int q = 0; q < 4; q++) b[q] = act ? ld4(xf + ((u + (q >> 1)) * LSZ + LSL) * 8 + (q & 1) * 4) : make_uint4(0, 0, 0, 0);
#pragma unroll
    for (int q = 0; q < 8; q++) {
      const uint4& bb = b[q >> 1];
      uint32_t b0 = (q & 1) ? bb.z : bb.x, b1 = (q & 1) ? bb.w : bb.y;
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b0, b1);
    }
  }
  for (; u < u1; u++) {
    uint4 w[4];
#pragma unroll
    for (int q = 0; q < 4; q++) w[q] = ldg_nc(wstrip + ((long)u * 4 + q) * 512 + lane * 16);
    uint4 b[2];
#pragma unroll
    for (int q = 0; q < 2; q++) b[q] = act ? ld4(xf + (u * LSZ + LSL) * 8 + q * 4) : make_uint4(0, 0, 0, 0);
#pragma unroll
    for (int q = 0; q < 4; q++) {
      const uint4& bb = b[q >> 1];
      uint32_t b0 = (q & 1) ? bb.z : bb.x, b1 = (q & 1) ? bb.w : bb.y;
      mma_bf16(acc, w[q].x, w[q].y, w[q].z, w[q].w, b0, b1);
    }
  }
}

// 12-bit exact BF16 code (track B): decode into bf16x2 registers, patch escapes, MMA.
__device__ __forceinline__ uint32_t prmt0(uint32_t a, uint32_t sel) { uint32_t r; asm("prmt.b32 %0,%1,0,%2;" : "=r"(r) : "r"(a), "r"(sel)); return r; }
__device__ __forceinline__ uint32_t w12dec(uint32_t bytes, int half, uint32_t nib, int a, uint32_t E128) {
  uint32_t y = prmt0(bytes, half ? 0xB3A2u : 0x9180u);
  uint32_t t = (nib >> (4 * a)) & 0x000F000Fu;
  return (y & 0x807F807Fu) | (t * 128u + E128);
}
template <bool CPT>
__device__ __forceinline__ void run_w12(const W12M& M, long strip, const uint32_t* xf, int u0, int u1, float* acc, int B, int U) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  uint32_t eg = M.base[strip * 16 + g], eg8 = M.base[strip * 16 + g + 8];
  const uint32_t E0 = (eg | (eg << 16)) << 7, E1 = (eg8 | (eg8 << 16)) << 7;
  const uint8_t* wbase = M.data + strip * (long)U * 1536;
  const int* hdr = M.hdr + strip * (long)U;
  for (int u = u0; u < u1; u++) {
    uint4 d0 = ldg_nc(wbase + (long)u * 1536 + lane * 16);
    uint4 d1 = ldg_nc(wbase + (long)u * 1536 + 512 + lane * 16);
    uint4 dn = ldg_nc(wbase + (long)u * 1536 + 1024 + lane * 16);
    int hd = __ldg(hdr + u);
    uint4 b0 = act ? ld4(xf + (u * LSZ + LSL) * 8) : make_uint4(0, 0, 0, 0);
    uint4 b1 = act ? ld4(xf + (u * LSZ + LSL) * 8 + 4) : make_uint4(0, 0, 0, 0);
    uint32_t by[8] = {d0.x, d0.y, d0.z, d0.w, d1.x, d1.y, d1.z, d1.w};
    uint32_t nb[4] = {dn.x, dn.y, dn.z, dn.w};
    uint32_t a[16];
#pragma unroll
    for (int j = 0; j < 4; j++) {
      a[4 * j + 0] = w12dec(by[2 * j], 0, nb[j], 0, E0);
      a[4 * j + 1] = w12dec(by[2 * j], 1, nb[j], 1, E1);
      a[4 * j + 2] = w12dec(by[2 * j + 1], 0, nb[j], 2, E0);
      a[4 * j + 3] = w12dec(by[2 * j + 1], 1, nb[j], 3, E1);
    }
    int cnt = hd & 0xFF;
    if (cnt) {
      const int* e = M.esc + (hd >> 8);
      for (int q = 0; q < cnt; q++) {
        int en = __ldg(e + q);
        if ((en >> 27 & 31) == lane) {
          int r = (en >> 23) & 15, hf = (en >> 22) & 1;
          uint32_t val = en & 0xFFFF;
#pragma unroll
          for (int k = 0; k < 16; k++)
            if (k == r) a[k] = hf ? ((a[k] & 0x0000FFFFu) | (val << 16)) : ((a[k] & 0xFFFF0000u) | val);
        }
      }
    }
    uint32_t bb[8] = {b0.x, b0.y, b0.z, b0.w, b1.x, b1.y, b1.z, b1.w};
#pragma unroll
    for (int j = 0; j < 4; j++) mma_bf16(acc, a[4 * j], a[4 * j + 1], a[4 * j + 2], a[4 * j + 3], bb[2 * j], bb[2 * j + 1]);
  }
}

// NVFP4 unit (64 k): codes [lane][16B] (512 B) + scales [g][8B] (64 B). B frags f16 [unit][lane][j][2].
#define UB4 576
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {  // bytes (g,g8) j0, (g,g8) j1 -> {g,g},{g8,g8},{g,g},{g8,g8}
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
__device__ __forceinline__ void fp4_unit(const uint4& cw, const uint2& sw, const uint4& b01, const uint4& b23, float* acc) {
  uint32_t cc[4] = {cw.x, cw.y, cw.z, cw.w};
  uint32_t ss[2] = {sw.x, sw.y};
  uint32_t bb[8] = {b01.x, b01.y, b01.z, b01.w, b23.x, b23.y, b23.z, b23.w};
#pragma unroll
  for (int jj = 0; jj < 2; jj++) {
    uint32_t sc[4];
    scl4(ss[jj], sc);
#pragma unroll
    for (int h = 0; h < 2; h++) {
      int j = jj * 2 + h;
      uint32_t a[4];
      cvt4(cc[j], a);
      uint32_t sg = sc[2 * h], sg8 = sc[2 * h + 1];
      mma_f16(acc, hmul2(a[0], sg), hmul2(a[1], sg8), hmul2(a[2], sg), hmul2(a[3], sg8), bb[2 * j], bb[2 * j + 1]);
    }
  }
}
// MXFP8 unit (64 k = 2 k32 steps): codes [s][lane][16B] (1024 B) + scales [g][s][hi] (32 B).
// B frags e4m3 [unit][lane][s][2 u32] (16 B per lane); act block scales fp32 [kblock32][MAXB]
// NVFP4 units loaded ahead per warp: 2 at B=1 (4: +1.7 %), 4 at B>=2 (-2.1 %), e0015
#ifndef FP4_UNROLL_RED
#define FP4_UNROLL_RED 2
#endif
#ifndef FP4_UNROLL_STD
#define FP4_UNROLL_STD 4
#endif
#ifndef FP8_PIPE_STD
#define FP8_PIPE_STD 1
#endif
#define UB8 1056
#ifndef FP8_UNROLL
#define FP8_UNROLL 1
#endif
__device__ __forceinline__ void fp8_unit(const uint4& c0, const uint4& c1, uint32_t sw, const uint4& b, const float* xs, int u, float* acc) {
  const int lane = threadIdx.x & 31, t = lane & 3;
#pragma unroll
  for (int s = 0; s < 2; s++) {
    const uint4& cc = s ? c1 : c0;
    float d[4] = {0.f, 0.f, 0.f, 0.f};
    mma_e4m3(d, cc.x, cc.y, cc.z, cc.w, s ? b.z : b.x, s ? b.w : b.y);
    float fg = ue8m0((sw >> (16 * s)) & 0xff), fg8 = ue8m0((sw >> (16 * s + 8)) & 0xff);
    float2 fa = *reinterpret_cast<const float2*>(xs + (u * 2 + s) * MAXB + 2 * t);
    acc[0] = __fmaf_rn(d[0], __fmul_rn(fg, fa.x), acc[0]);
    acc[1] = __fmaf_rn(d[1], __fmul_rn(fg, fa.y), acc[1]);
    acc[2] = __fmaf_rn(d[2], __fmul_rn(fg8, fa.x), acc[2]);
    acc[3] = __fmaf_rn(d[3], __fmul_rn(fg8, fa.y), acc[3]);
  }
}
// NVFP4 stream with the next group's loads issued before the current group is computed (B>=2 kernel).
// LSZP / LSLP: lane stride and lane slot of the B fragment (32 / lane: dense 8 columns; 4 / t: one compact column)
template <int G, int LSZP>
__device__ __forceinline__ int run_q4_pipe(const uint8_t* wstrip, const uint8_t* xf, bool act, int u, int u1, float* acc) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const int lsl = (LSZP == 32) ? lane : (lane & 3);
  if (u + G > u1) return u;
  uint4 cw[G]; uint2 sw[G];
#pragma unroll
  for (int q = 0; q < G; q++) {
    cw[q] = ldg_nc(wstrip + (long)(u + q) * UB4 + lane * 16);
    sw[q] = ldg_nc2(wstrip + (long)(u + q) * UB4 + 512 + g * 8);
  }
  for (; u + G <= u1; u += G) {
    uint4 cn[G]; uint2 sn[G];
    const bool more = u + 2 * G <= u1;
#pragma unroll
    for (int q = 0; q < G; q++) {
      if (more) {
        cn[q] = ldg_nc(wstrip + (long)(u + G + q) * UB4 + lane * 16);
        sn[q] = ldg_nc2(wstrip + (long)(u + G + q) * UB4 + 512 + g * 8);
      }
    }
#pragma unroll
    for (int q = 0; q < G; q++) {
      uint4 b0 = act ? ld4(xf + ((u + q) * LSZP + lsl) * 32) : make_uint4(0, 0, 0, 0);
      uint4 b1 = act ? ld4(xf + ((u + q) * LSZP + lsl) * 32 + 16) : make_uint4(0, 0, 0, 0);
      fp4_unit(cw[q], sw[q], b0, b1, acc);
    }
#pragma unroll
    for (int q = 0; q < G; q++) { cw[q] = cn[q]; sw[q] = sn[q]; }
  }
  return u;
}
#ifndef FP4_PIPE_STD
#define FP4_PIPE_STD 0   // group size of the pipelined NVFP4 stream at B>=2 (0: plain groups of FP4_UNROLL_STD)
#endif
template <bool CPT>
__device__ __forceinline__ void run_q(const uint8_t* wstrip, const uint8_t* xf, const float* xs, int u0, int u1, float* acc, int B, int mx) {
  const int lane = threadIdx.x & 31, g = lane >> 2;
  const bool act = g < B;
  if (!mx) {
    int u = u0;
    constexpr int UNR = CPT ? FP4_UNROLL_RED : FP4_UNROLL_STD;   // units in flight per warp
#if FP4_PIPE_STD
    if (!CPT) u = run_q4_pipe<FP4_PIPE_STD, 32>(wstrip, xf, act, u, u1, acc);
#endif
    for (; u + UNR <= u1; u += UNR) {
      uint4 cw[UNR]; uint2 sw[UNR];
#pragma unroll
      for (int q = 0; q < UNR; q++) {
        cw[q] = ldg_nc(wstrip + (long)(u + q) * UB4 + lane * 16);
        sw[q] = ldg_nc2(wstrip + (long)(u + q) * UB4 + 512 + g * 8);
      }
#pragma unroll
      for (int q = 0; q < UNR; q++) {
        uint4 b0 = act ? ld4(xf + ((u + q) * LSZ + LSL) * 32) : make_uint4(0, 0, 0, 0);
        uint4 b1 = act ? ld4(xf + ((u + q) * LSZ + LSL) * 32 + 16) : make_uint4(0, 0, 0, 0);
        fp4_unit(cw[q], sw[q], b0, b1, acc);
      }
    }
    for (; u < u1; u++) {
      uint4 cw = ldg_nc(wstrip + (long)u * UB4 + lane * 16);
      uint2 sw = ldg_nc2(wstrip + (long)u * UB4 + 512 + g * 8);
      uint4 b0 = act ? ld4(xf + (u * LSZ + LSL) * 32) : make_uint4(0, 0, 0, 0);
      uint4 b1 = act ? ld4(xf + (u * LSZ + LSL) * 32 + 16) : make_uint4(0, 0, 0, 0);
      fp4_unit(cw, sw, b0, b1, acc);
    }
  } else {
    int u = u0;
#ifndef FP8_UNROLL
#define FP8_UNROLL 1
#endif
#if FP8_UNROLL > 1
    for (; u + FP8_UNROLL <= u1; u += FP8_UNROLL) {   // the loads of FP8_UNROLL units in flight together
      uint4 c0[FP8_UNROLL], c1[FP8_UNROLL]; uint32_t sw[FP8_UNROLL];
#pragma unroll
      for (int q = 0; q < FP8_UNROLL; q++) {
        c0[q] = ldg_nc(wstrip + (long)(u + q) * UB8 + lane * 16);
        c1[q] = ldg_nc(wstrip + (long)(u + q) * UB8 + 512 + lane * 16);
        sw[q] = ldg_nc1(wstrip + (long)(u + q) * UB8 + 1024 + g * 4);
      }
#pragma unroll
      for (int q = 0; q < FP8_UNROLL; q++) {
        uint4 b = act ? ld4(xf + ((u + q) * LSZ + LSL) * 16) : make_uint4(0, 0, 0, 0);
        fp8_unit(c0[q], c1[q], sw[q], b, xs, u + q, acc);
      }
    }
#endif
    // B>=2: the next unit's loads are issued before this unit is computed (2 KB in flight per warp instead of 1; the
    // MXFP8 stream is bound by loads in flight: B=8 -1.7 %; in the B=1 kernel it costs 0.4 %, e0059)
    if (!CPT && FP8_PIPE_STD == 2) {   // two units ahead
     if (u < u1) {
      uint4 c0n = ldg_nc(wstrip + (long)u * UB8 + lane * 16);
      uint4 c1n = ldg_nc(wstrip + (long)u * UB8 + 512 + lane * 16);
      uint32_t swn = ldg_nc1(wstrip + (long)u * UB8 + 1024 + g * 4);
      uint4 c0m = c0n, c1m = c1n; uint32_t swm = swn;
      if (u + 1 < u1) {
        c0m = ldg_nc(wstrip + (long)(u + 1) * UB8 + lane * 16);
        c1m = ldg_nc(wstrip + (long)(u + 1) * UB8 + 512 + lane * 16);
        swm = ldg_nc1(wstrip + (long)(u + 1) * UB8 + 1024 + g * 4);
      }
      for (; u < u1; u++) {
        const uint4 c0 = c0n, c1 = c1n; const uint32_t sw = swn;
        c0n = c0m; c1n = c1m; swn = swm;
        if (u + 2 < u1) {
          c0m = ldg_nc(wstrip + (long)(u + 2) * UB8 + lane * 16);
          c1m = ldg_nc(wstrip + (long)(u + 2) * UB8 + 512 + lane * 16);
          swm = ldg_nc1(wstrip + (long)(u + 2) * UB8 + 1024 + g * 4);
        }
        uint4 b = act ? ld4(xf + (u * LSZ + LSL) * 16) : make_uint4(0, 0, 0, 0);
        fp8_unit(c0, c1, sw, b, xs, u, acc);
      }
     }
    } else if (!CPT && FP8_PIPE_STD) {
     if (u < u1) {
      uint4 c0n = ldg_nc(wstrip + (long)u * UB8 + lane * 16);
      uint4 c1n = ldg_nc(wstrip + (long)u * UB8 + 512 + lane * 16);
      uint32_t swn = ldg_nc1(wstrip + (long)u * UB8 + 1024 + g * 4);
      for (; u < u1; u++) {
        const uint4 c0 = c0n, c1 = c1n; const uint32_t sw = swn;
        if (u + 1 < u1) {
          c0n = ldg_nc(wstrip + (long)(u + 1) * UB8 + lane * 16);
          c1n = ldg_nc(wstrip + (long)(u + 1) * UB8 + 512 + lane * 16);
          swn = ldg_nc1(wstrip + (long)(u + 1) * UB8 + 1024 + g * 4);
        }
        uint4 b = act ? ld4(xf + (u * LSZ + LSL) * 16) : make_uint4(0, 0, 0, 0);
        fp8_unit(c0, c1, sw, b, xs, u, acc);
      }
     }
    } else {
    for (; u < u1; u++) {
      uint4 c0 = ldg_nc(wstrip + (long)u * UB8 + lane * 16);
      uint4 c1 = ldg_nc(wstrip + (long)u * UB8 + 512 + lane * 16);
      uint32_t sw = ldg_nc1(wstrip + (long)u * UB8 + 1024 + g * 4);
      uint4 b = act ? ld4(xf + (u * LSZ + LSL) * 16) : make_uint4(0, 0, 0, 0);
      fp8_unit(c0, c1, sw, b, xs, u, acc);
    }
    }
  }
}

// ------------------------------------------------------------------------------------------------ ops
struct Smem {
  float red[NWARP * 40 + 64];
  float bestv[NWARP * MAXB];
  int besti[NWARP * MAXB];
  float att[6 * CHUNK];
  float qv[6 * HD];
  float relb[6 * CHUNK];
  float misc[128];
  float opart[8][(NWARP * 256 + 7) / 8 > 6 * HD ? (NWARP * 256 + 7) / 8 : 6 * HD];   // attention scratch; GEMV slots: NWARP * 2 * 32 float4
  unsigned gcnt[64];                    // gemv_ctg: pieces arrived per strip of the block (directly behind opart)
  int ids[MAXB * TOPK];
  float wts[MAXB * TOPK];
  int uni[MAXU];
  int nuni;
  float minv[10];
  float mixp[30];
  // B=1 (QCACHE): per finished block m its 1/rms and its dot with every later query (global query index, qbase())
#if QCACHE
  float cinv[9];
  float qd[9][128];
#else
  float cinv[1];
  float qd[1][1];
#endif
  // B >= 2, w2: routed (token, expert) pairs p = token * 8 + rank; pmap[union index][token] = p or -1
  float w2o[MAXB * TOPK];               // NVFP4: the pair's outer scale
  signed char pmap[MAXU * MAXB];
  unsigned char e2u[NE];                // expert id -> union index
  // per-token state of token blockIdx.x (< B) for the whole step: finished blocks 0..7, partial (8), attention out
  __align__(16) bf16 blk[9][H];
  __align__(16) bf16 ats[H];
  union {
    struct {  // compact (B == 1) fragments, used by the red mode
      __align__(16) bf16 fx[3][H];        // xq, xk, xv
      __align__(16) bf16 fx2[H];          // router input
      __align__(16) uint8_t f13[2 * H];   // w13 input (f16 nvfp4 values or e4m3)
      __align__(16) uint8_t f2[8 * ILOC * 2];  // w2 inputs of up to 8 experts
      __align__(16) bf16 fh[H];           // final hidden
      float sc13[144 * MAXB];             // w13 input scales (mxfp8) / outer at [0]
      float sc2[8 * 18 * MAXB];           // w2 input scales / outer at [ui][0][0]
    };
    __align__(16) uint8_t stage[73728];   // std mode: the current GEMV's 8-column B fragments
  };
};
// std mode: copy a GEMV's B fragments (global, L2-resident) into shared memory once per block
__device__ __forceinline__ void stage_frags(Smem& sm, const void* src, int bytes, const void* src2 = nullptr, int bytes2 = 0) {
  const uint4* s4 = reinterpret_cast<const uint4*>(src);
  uint4* d4 = reinterpret_cast<uint4*>(sm.stage);
#ifndef STAGE_UNROLL   // (unrolled: 24 more live registers, the B>=2 kernel's frame 288 -> 536 B and the step 7165 -> 7928 us, e0044)
  for (int k = threadIdx.x; k < bytes / 16; k += NTH) d4[k] = __ldcg(s4 + k);
#else
  {   // all of a thread's loads in flight before the first store (the loop waited for each load)
    constexpr int NI = (73728 / 16 + NTH - 1) / NTH;
    uint4 v[NI];
#pragma unroll
    for (int q = 0; q < NI; q++) { const int k = threadIdx.x + q * NTH; if (k < bytes / 16) v[q] = __ldcg(s4 + k); }
#pragma unroll
    for (int q = 0; q < NI; q++) { const int k = threadIdx.x + q * NTH; if (k < bytes / 16) d4[k] = v[q]; }
  }
#endif
  if (src2) {
    const uint4* t4 = reinterpret_cast<const uint4*>(src2);
    for (int k = threadIdx.x; k < bytes2 / 16; k += NTH) d4[bytes / 16 + k] = __ldcg(t4 + k);
  }
  __syncthreads();
}

template <bool CPT>
struct OpQKV {
  int layer; const bf16* xf0; const bf16* xs0; int tm = 0;   // xs0: staged copy of group 0 (std mode) or null   // three frags (xq, xk, xv), each 72 units
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    const LayerW& L = c.L[layer];
    int grp = 0;
    if (L.glob) grp = s < 205 ? 0 : (s < 222 ? 1 : 2);
    const uint32_t* xf = reinterpret_cast<const uint32_t*>((grp == 0 && xs0) ? xs0 : xf0 + grp * (72 * LSZ * 16));
#ifdef W12
    run_w12<CPT>(L.qkv12, s, xf, u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(L.wqkv + s * 72L * 2048, xf, u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
    int r0 = (int)s * 16 + g;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = r0 + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) c.qkvo[col * 3840 + row] = tobf(a[i]);
    }
  }
};

template <bool CPT>
struct OpOproj {
  int layer; const bf16* xf; int tm = 25;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<CPT>(c.L[layer].wo12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 24);
    return;
#endif
    run_bf16<CPT>(c.L[layer].wo + s * 24L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
#ifdef LL_SINGLE
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) for (int d = 0; d < NCARD; d++) ll_put(&c.comm[d]->lla[layer & 1][c.h.card][col][row], a[i], c.h.tag0 + layer + 1);
    }
#else
    // A cross-card store instruction costs the warp a fixed time whatever number of lanes take part (measured: the
    // consumers had their data 6.5 us after the GEMV, with 8 or 16 such instructions per strip). So: one 16-byte store
    // per destination card and column parity for the whole strip: even lanes send rows (g, g + 1), odd lanes rows
    // (g + 7, g + 8), each with the partner lane's value (lanes 4 apart).
    float ao[4];
#pragma unroll
    for (int i = 0; i < 4; i++) ao[i] = __shfl_xor_sync(0xffffffff, a[i], 4);
    const bool ev = (g & 1) == 0;
    const int row = (int)s * 16 + (ev ? g : g + 7);
#pragma unroll
    for (int cp = 0; cp < 2; cp++) {
      const int col = 2 * t + cp;
      const float v0 = ev ? a[cp] : ao[2 + cp], v1 = ev ? ao[cp] : a[2 + cp];
      if (col < c.h.B)
        for (int d = 0; d < NCARD; d++) ll_put2(&c.comm[d]->lla[layer & 1][c.h.card][col][row], v0, v1, c.h.tag0 + layer + 1);
    }
#endif
  }
};

template <bool CPT>
struct OpRouter {
  int layer; const bf16* xf; int tm = 0;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
#ifdef W12
    run_w12<CPT>(c.L[layer].wr12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 72);
#else
    run_bf16<CPT>(c.L[layer].wr + s * 72L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
#endif
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) ll_put(&c.rll[col * NE + row], a[i], c.h.tag0 + layer + 1);
    }
  }
};

__device__ __forceinline__ float act_fn(float g, float u) {
  float a = (4.0f * tanhf(g / 4.0f)) * sigm(g);
  return a * (25.0f * tanhf(u / 25.0f));
}

template <bool CPT>
struct OpW13 {
  int layer; int nu; const Smem* sm; const uint8_t* xf; const float* xs; const float* outer; int tm = 40;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    const LayerW& L = c.L[layer];
    int ui = (int)(s / 72), ls = (int)(s % 72);
    int e = sm->uni[ui];
    long ub = L.mx ? UB8 : UB4;
    const uint8_t* w = L.w13 + ((long)e * 72 + ls) * 72 * ub;
    run_q<CPT>(w, xf, xs, u0, u1, acc, c.h.B, L.mx);
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    const LayerW& L = c.L[layer];
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
    int ui = (int)(s / 72), ls = (int)(s % 72);
    int e = sm->uni[ui];
    // rows g (gate if g even... ) : local row r = ls*16 + g (+8). interleaved: even row gate, odd row up.
    // lane holds rows g and g+8 for cols 2t, 2t+1. Pair (gate,up) = rows (2p, 2p+1) -> lanes g=2p and g=2p+1.
    float v[4];
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int col = 2 * t + (i & 1);
      float sc = L.mx ? 1.0f : outer[col] * L.f13[e];
      v[i] = rbf(a[i] * sc);
    }
    // partner lane (g^1) holds the other member of the pair
    float o[4];
#pragma unroll
    for (int i = 0; i < 4; i++) o[i] = __shfl_xor_sync(0xffffffff, v[i], 4);
    float m0 = 0.f, m1 = 0.f;
    if ((g & 1) == 0) {
      // this lane: gate rows (g, g+8); partner: up rows (g+1, g+9). local intermediate j = (ls*16 + g)/2 (+4)
#pragma unroll
      for (int i = 0; i < 4; i++) {
        int col = 2 * t + (i & 1);
        if (col >= c.h.B) continue;
        int j = (ls * 16 + g + (i >> 1) * 8) >> 1;
        float wt = 0.f;
        for (int k = 0; k < TOPK; k++) if (sm->ids[col * TOPK + k] == e) wt = sm->wts[col * TOPK + k];
        float y = 0.f;
        if (wt != 0.f) y = rbf(act_fn(v[i], o[i]) * wt);
        c.act[(ui * MAXB + col) * ILOC + j] = tobf(y);
        if (i & 1) m1 = fmaxf(m1, fabsf(y)); else m0 = fmaxf(m0, fabsf(y));
      }
    }
    {
      // max over the warp per column, local atomic, and the last of the expert's 72 strips publishes to every card
      // (mxfp8 layers publish too: the tag tells quant2 that this card's act values of the expert are complete)
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) { m0 = fmaxf(m0, __shfl_xor_sync(0xffffffff, m0, o)); m1 = fmaxf(m1, __shfl_xor_sync(0xffffffff, m1, o)); }
      if (g == 0) {
        if (2 * t < c.h.B) atomicMax(&c.amax_loc[ui * MAXB + 2 * t], __float_as_uint(m0));
        if (2 * t + 1 < c.h.B) atomicMax(&c.amax_loc[ui * MAXB + 2 * t + 1], __float_as_uint(m1));
      }
      __syncwarp();
      unsigned old = 0;
      if (lane == 0) { __threadfence(); old = atomicAdd(&c.ucnt[ui], 1u); }
      old = __shfl_sync(0xffffffff, old, 0);
      if (old == 71u) {
        __threadfence();
        if (lane < c.h.B) {
          float v = __uint_as_float(atomicExch(&c.amax_loc[ui * MAXB + lane], 0u));
          for (int d = 0; d < NCARD; d++) ll_put(&c.comm[d]->llx[layer][c.h.card][ui][lane], v, c.h.tag0 + layer + 1);
        }
        if (lane == 0) c.ucnt[ui] = 0;
      }
    }
  }
};

template <bool CPT>
struct OpW2 {
  int layer; int nu; const Smem* sm; const uint8_t* xf0; const float* sc0; int tm = 28;   // frags [ui][9 units], scales [ui][18][MAXB]
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    // units: (ui, k-unit) with 9 units per expert
    const LayerW& L = c.L[layer];
    int lane = threadIdx.x & 31, t = lane & 3;
    long ub = L.mx ? UB8 : UB4;
    int u = u0;
    while (u < u1) {
      int ui = u / 9, k0 = u % 9, k1 = min(9, u1 - ui * 9);
      int e = sm->uni[ui];
      const uint8_t* w = L.w2 + ((long)e * 288 + s) * 9 * ub;
      float a[4] = {0.f, 0.f, 0.f, 0.f};
      const uint8_t* xf = xf0 + (long)ui * 9 * LSZ * (L.mx ? 16 : 32);
      const float* xs = sc0 + (long)ui * 18 * MAXB;
      run_q<CPT>(w, xf, xs, k0, k1, a, c.h.B, L.mx);
      if (L.mx) {
#pragma unroll
        for (int i = 0; i < 4; i++) acc[i] += a[i];
      } else {
        float f = L.f2[e];
        float s0 = sc0[ui * 18 * MAXB + 2 * t] * f, s1 = sc0[ui * 18 * MAXB + 2 * t + 1] * f;   // outer at [ui][0][col]
        // explicit FMAs: the compiler may contract the four columns' multiply-adds differently, which made a
        // sequence's result depend on its batch slot (1 ulp, s0004 http_tokens)
        acc[0] = __fmaf_rn(a[0], s0, acc[0]); acc[1] = __fmaf_rn(a[1], s1, acc[1]);
        acc[2] = __fmaf_rn(a[2], s0, acc[2]); acc[3] = __fmaf_rn(a[3], s1, acc[3]);
      }
      u = ui * 9 + k1;
    }
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
#ifdef LL_SINGLE
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) for (int d = 0; d < NCARD; d++) ll_put(&c.comm[d]->llm[layer & 1][c.h.card][col][row], a[i], c.h.tag0 + layer + 1);
    }
#else
    // A cross-card store instruction costs the warp a fixed time whatever number of lanes take part (measured: the
    // consumers had their data 6.5 us after the GEMV, with 8 or 16 such instructions per strip). So: one 16-byte store
    // per destination card and column parity for the whole strip: even lanes send rows (g, g + 1), odd lanes rows
    // (g + 7, g + 8), each with the partner lane's value (lanes 4 apart).
    float ao[4];
#pragma unroll
    for (int i = 0; i < 4; i++) ao[i] = __shfl_xor_sync(0xffffffff, a[i], 4);
    const bool ev = (g & 1) == 0;
    const int row = (int)s * 16 + (ev ? g : g + 7);
#pragma unroll
    for (int cp = 0; cp < 2; cp++) {
      const int col = 2 * t + cp;
      const float v0 = ev ? a[cp] : ao[2 + cp], v1 = ev ? ao[cp] : a[2 + cp];
      if (col < c.h.B)
        for (int d = 0; d < NCARD; d++) ll_put2(&c.comm[d]->llm[layer & 1][c.h.card][col][row], v0, v1, c.h.tag0 + layer + 1);
    }
#endif
  }
};

// B >= 2: w2 with compact one-column fragments per routed (token, expert) pair, staged in shared memory (the dense
// 8-column fragments were 1 KB per unit against 576 B of weights and came from L2: e0006, w2 at 3 TB/s).
__device__ __forceinline__ void run_q4p(const uint8_t* wstrip, const uint8_t* xf, bool act, int u0, int u1, float* acc) {
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  int u = u0;
#if FP4_PIPE_STD
  u = run_q4_pipe<FP4_PIPE_STD, 4>(wstrip, xf, act, u, u1, acc);
#endif
  for (; u + FP4_UNROLL_STD <= u1; u += FP4_UNROLL_STD) {
    uint4 cw[FP4_UNROLL_STD]; uint2 sw[FP4_UNROLL_STD];
#pragma unroll
    for (int q = 0; q < FP4_UNROLL_STD; q++) {
      cw[q] = ldg_nc(wstrip + (long)(u + q) * UB4 + lane * 16);
      sw[q] = ldg_nc2(wstrip + (long)(u + q) * UB4 + 512 + g * 8);
    }
#pragma unroll
    for (int q = 0; q < FP4_UNROLL_STD; q++) {
      uint4 b0 = act ? ld4(xf + ((u + q) * 4 + t) * 32) : make_uint4(0, 0, 0, 0);
      uint4 b1 = act ? ld4(xf + ((u + q) * 4 + t) * 32 + 16) : make_uint4(0, 0, 0, 0);
      fp4_unit(cw[q], sw[q], b0, b1, acc);
    }
  }
  for (; u < u1; u++) {
    uint4 cw = ldg_nc(wstrip + (long)u * UB4 + lane * 16);
    uint2 sw = ldg_nc2(wstrip + (long)u * UB4 + 512 + g * 8);
    uint4 b0 = act ? ld4(xf + (u * 4 + t) * 32) : make_uint4(0, 0, 0, 0);
    uint4 b1 = act ? ld4(xf + (u * 4 + t) * 32 + 16) : make_uint4(0, 0, 0, 0);
    fp4_unit(cw, sw, b0, b1, acc);
  }
}
// xs0 / xs1: the 18 block scales of the pairs of output columns 2t and 2t+1 (null: not routed, scale 0)
__device__ __forceinline__ void run_q8p(const uint8_t* wstrip, const uint8_t* xf, bool act, const float* xs0, const float* xs1,
                                        int u0, int u1, float* acc) {
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#if FP8_PIPE_STD
  if (u0 < u1) {
    uint4 c0n = ldg_nc(wstrip + (long)u0 * UB8 + lane * 16);
    uint4 c1n = ldg_nc(wstrip + (long)u0 * UB8 + 512 + lane * 16);
    uint32_t swn = ldg_nc1(wstrip + (long)u0 * UB8 + 1024 + g * 4);
    for (int u = u0; u < u1; u++) {
      const uint4 c0 = c0n, c1 = c1n; const uint32_t sw = swn;
      if (u + 1 < u1) {
        c0n = ldg_nc(wstrip + (long)(u + 1) * UB8 + lane * 16);
        c1n = ldg_nc(wstrip + (long)(u + 1) * UB8 + 512 + lane * 16);
        swn = ldg_nc1(wstrip + (long)(u + 1) * UB8 + 1024 + g * 4);
      }
      uint4 b = act ? ld4(xf + (u * 4 + t) * 16) : make_uint4(0, 0, 0, 0);
#pragma unroll
      for (int s = 0; s < 2; s++) {
        const uint4& cc = s ? c1 : c0;
        float d[4] = {0.f, 0.f, 0.f, 0.f};
        mma_e4m3(d, cc.x, cc.y, cc.z, cc.w, s ? b.z : b.x, s ? b.w : b.y);
        float fg = ue8m0((sw >> (16 * s)) & 0xff), fg8 = ue8m0((sw >> (16 * s + 8)) & 0xff);
        const float fx = xs0 ? xs0[u * 2 + s] : 0.f, fy = xs1 ? xs1[u * 2 + s] : 0.f;
        acc[0] = __fmaf_rn(d[0], __fmul_rn(fg, fx), acc[0]);
        acc[1] = __fmaf_rn(d[1], __fmul_rn(fg, fy), acc[1]);
        acc[2] = __fmaf_rn(d[2], __fmul_rn(fg8, fx), acc[2]);
        acc[3] = __fmaf_rn(d[3], __fmul_rn(fg8, fy), acc[3]);
      }
    }
  }
#else
  for (int u = u0; u < u1; u += FP8_UNROLL) {
    uint4 c0[FP8_UNROLL], c1[FP8_UNROLL]; uint32_t sw[FP8_UNROLL];
#pragma unroll
    for (int q = 0; q < FP8_UNROLL; q++) {
      if (u + q < u1) {
        c0[q] = ldg_nc(wstrip + (long)(u + q) * UB8 + lane * 16);
        c1[q] = ldg_nc(wstrip + (long)(u + q) * UB8 + 512 + lane * 16);
        sw[q] = ldg_nc1(wstrip + (long)(u + q) * UB8 + 1024 + g * 4);
      }
    }
#pragma unroll
    for (int q = 0; q < FP8_UNROLL; q++) {
      if (u + q >= u1) break;
      uint4 b = act ? ld4(xf + ((u + q) * 4 + t) * 16) : make_uint4(0, 0, 0, 0);
#pragma unroll
      for (int s = 0; s < 2; s++) {
        const uint4& cc = s ? c1[q] : c0[q];
        float d[4] = {0.f, 0.f, 0.f, 0.f};
        mma_e4m3(d, cc.x, cc.y, cc.z, cc.w, s ? b.z : b.x, s ? b.w : b.y);
        float fg = ue8m0((sw[q] >> (16 * s)) & 0xff), fg8 = ue8m0((sw[q] >> (16 * s + 8)) & 0xff);
        const float fx = xs0 ? xs0[(u + q) * 2 + s] : 0.f, fy = xs1 ? xs1[(u + q) * 2 + s] : 0.f;
        acc[0] = __fmaf_rn(d[0], __fmul_rn(fg, fx), acc[0]);
        acc[1] = __fmaf_rn(d[1], __fmul_rn(fg, fy), acc[1]);
        acc[2] = __fmaf_rn(d[2], __fmul_rn(fg8, fx), acc[2]);
        acc[3] = __fmaf_rn(d[3], __fmul_rn(fg8, fy), acc[3]);
      }
    }
  }
#endif
}
struct OpW2S {
  int layer; int nu; const Smem* sm; int tm = 28;
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    const LayerW& L = c.L[layer];
    const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
    const long ub = L.mx ? UB8 : UB4;
    const float* xsall = reinterpret_cast<const float*>(sm->stage + c.h.B * TOPK * 576);   // MXFP8: [pair][18]
    int u = u0;
    while (u < u1) {
      const int ui = u / 9, k0 = u % 9, k1 = min(9, u1 - ui * 9);
      const int e = sm->uni[ui];
      const uint8_t* w = L.w2 + ((long)e * 288 + s) * 9 * ub;
      const int pB = sm->pmap[ui * MAXB + g], p0 = sm->pmap[ui * MAXB + 2 * t], p1 = sm->pmap[ui * MAXB + 2 * t + 1];
      float a[4] = {0.f, 0.f, 0.f, 0.f};
      if (L.mx) {
        run_q8p(w, sm->stage + (long)max(pB, 0) * 576, pB >= 0, p0 >= 0 ? xsall + p0 * 18 : nullptr, p1 >= 0 ? xsall + p1 * 18 : nullptr, k0, k1, a);
#pragma unroll
        for (int i = 0; i < 4; i++) acc[i] += a[i];
      } else {
        run_q4p(w, sm->stage + (long)max(pB, 0) * 1152, pB >= 0, k0, k1, a);
        const float f = L.f2[e];
        const float s0 = (p0 >= 0 ? sm->w2o[p0] : 0.f) * f, s1 = (p1 >= 0 ? sm->w2o[p1] : 0.f) * f;
        acc[0] = __fmaf_rn(a[0], s0, acc[0]); acc[1] = __fmaf_rn(a[1], s1, acc[1]);
        acc[2] = __fmaf_rn(a[2], s0, acc[2]); acc[3] = __fmaf_rn(a[3], s1, acc[3]);
      }
      u = ui * 9 + k1;
    }
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
#pragma unroll
#ifdef LL_SINGLE
    for (int i = 0; i < 4; i++) {
      int row = (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B) for (int d = 0; d < NCARD; d++) ll_put(&c.comm[d]->llm[layer & 1][c.h.card][col][row], a[i], c.h.tag0 + layer + 1);
    }
#else
    // A cross-card store instruction costs the warp a fixed time whatever number of lanes take part (measured: the
    // consumers had their data 6.5 us after the GEMV, with 8 or 16 such instructions per strip). So: one 16-byte store
    // per destination card and column parity for the whole strip: even lanes send rows (g, g + 1), odd lanes rows
    // (g + 7, g + 8), each with the partner lane's value (lanes 4 apart).
    float ao[4];
#pragma unroll
    for (int i = 0; i < 4; i++) ao[i] = __shfl_xor_sync(0xffffffff, a[i], 4);
    const bool ev = (g & 1) == 0;
    const int row = (int)s * 16 + (ev ? g : g + 7);
#pragma unroll
    for (int cp = 0; cp < 2; cp++) {
      const int col = 2 * t + cp;
      const float v0 = ev ? a[cp] : ao[2 + cp], v1 = ev ? ao[cp] : a[2 + cp];
      if (col < c.h.B)
        for (int d = 0; d < NCARD; d++) ll_put2(&c.comm[d]->llm[layer & 1][c.h.card][col][row], v0, v1, c.h.tag0 + layer + 1);
    }
#endif
  }
};

template <bool CPT>
struct OpUnembed {
  float* bestv; int* besti; const bf16* xf; int tm = 0; int layer = 0;   // per-warp running best per col (smem)
  __device__ void run(const Ctx& c, long s, int u0, int u1, float* acc) {
    // both storages are compiled into every build and chosen at load (engine/TRACK): the code of the layer loop is
    // then the same binary for the BF16 and the 12-bit unembedding, and their difference is this op alone
    if (c.un12.data) run_w12<CPT>(c.un12, s, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B, 72);
    else run_bf16<CPT>(c.unembed + s * 72L * 2048, reinterpret_cast<const uint32_t*>(xf), u0, u1, acc, c.h.B);
  }
  __device__ void epi(const Ctx& c, long s, const float* a) {
    int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3, w = threadIdx.x >> 5;
    float bv[2] = {-INFINITY, -INFINITY};
    int bi[2] = {1 << 30, 1 << 30};
#pragma unroll
    for (int i = 0; i < 4; i++) {
      int row = c.un_row0 + (int)s * 16 + g + (i >> 1) * 8, col = 2 * t + (i & 1);
      if (col < c.h.B && row < VOCAB_REAL) {
        float z = 30.0f * tanhf(a[i] / 30.0f);
        if (c.h.want_logits) c.h.logits[(long)col * VOCAB_REAL + row] = z;
        int k = i & 1;
        if (z > bv[k] || (z == bv[k] && row < bi[k])) { bv[k] = z; bi[k] = row; }
      }
    }
#pragma unroll
    for (int k = 0; k < 2; k++) {
#pragma unroll
      for (int o = 4; o < 32; o <<= 1) {
        float ov = __shfl_xor_sync(0xffffffff, bv[k], o);
        int oi = __shfl_xor_sync(0xffffffff, bi[k], o);
        if (ov > bv[k] || (ov == bv[k] && oi < bi[k])) { bv[k] = ov; bi[k] = oi; }
      }
      int col = 2 * t + k;
      if (g == 0 && col < c.h.B) {
        float cv = bestv[w * MAXB + col];
        int ci = besti[w * MAXB + col];
        if (bv[k] > cv || (bv[k] == cv && bi[k] < ci)) { bestv[w * MAXB + col] = bv[k]; besti[w * MAXB + col] = bi[k]; }
      }
    }
  }
};

// ------------------------------------------------------------------------------------------------ phases


template <bool CPT> __device__ __forceinline__ void put16(bf16* f, int b, int k, float v) { f[fi16<CPT>(b, k)] = tobf(v); }

// ------------------------------------------------------------------------------------------------ per-token vector code
// thread t < 576 owns the 8 consecutive elements [8t, 8t+8) of a 4608-vector: one 16-byte load per bf16 vector.
#define NV8 (H / 8)
#define W8 (NV8 / 32)          // 18 active warps
#define ACT8 (threadIdx.x < NV8)
__device__ __forceinline__ void ld8(const bf16* p, float* v) {
  uint4 u = *reinterpret_cast<const uint4*>(p);
  const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
#pragma unroll
  for (int i = 0; i < 4; i++) { float2 f = __bfloat1622float2(h[i]); v[2 * i] = f.x; v[2 * i + 1] = f.y; }
}
__device__ __forceinline__ void ld8g(const bf16* p, float* v) {   // global, L2 (data written in this launch)
  uint4 u = __ldcg(reinterpret_cast<const uint4*>(p));
  const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
#pragma unroll
  for (int i = 0; i < 4; i++) { float2 f = __bfloat1622float2(h[i]); v[2 * i] = f.x; v[2 * i + 1] = f.y; }
}
__device__ __forceinline__ void st8(bf16* p, const float* v) {
  uint4 u;
  __nv_bfloat162* h = reinterpret_cast<__nv_bfloat162*>(&u);
#pragma unroll
  for (int i = 0; i < 4; i++) h[i] = __floats2bfloat162_rn(v[2 * i], v[2 * i + 1]);
  *reinterpret_cast<uint4*>(p) = u;
}
// block-wide sums of N values held by the 576 active threads; result broadcast through sm.red
template <int N>
__device__ __forceinline__ void bsum8(float* v, float* red) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  if (w < W8) {
#pragma unroll
    for (int i = 0; i < N; i++) {
#pragma unroll
      for (int o = 16; o; o >>= 1) v[i] += __shfl_xor_sync(0xffffffff, v[i], o);
      if (lane == 0) red[w * N + i] = v[i];
    }
  }
  __syncthreads();
#pragma unroll
  for (int i = 0; i < N; i++) {
    float t = 0.f;
#pragma unroll
    for (int j = 0; j < W8; j++) t += red[j * N + i];
    v[i] = t;
  }
  __syncthreads();
}
__device__ __forceinline__ float bmax8(float m, float* red) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5;
  if (w < W8) {
#pragma unroll
    for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
    if (lane == 0) red[w] = m;
  }
  __syncthreads();
  float r = red[0];
#pragma unroll
  for (int j = 1; j < W8; j++) r = fmaxf(r, red[j]);
  __syncthreads();
  return r;
}
// rms_norm (fp32 in) with a bf16 weight -> bf16-rounded values
// in place: u (fp32) -> rms_norm(u) * w rounded to bf16
__device__ __forceinline__ void rmsnorm8(float* u, const bf16* w, float* red) {
  float s[1] = {0.f};
  if (ACT8) {
#pragma unroll
    for (int i = 0; i < 8; i++) s[0] += u[i] * u[i];
  }
  bsum8<1>(s, red);
  if (!ACT8) return;
  const float r = rsqrtf(s[0] / (float)H + 1e-6f);
  const __nv_bfloat162* w2 = reinterpret_cast<const __nv_bfloat162*>(w + threadIdx.x * 8);
#pragma unroll
  for (int i = 0; i < 4; i++) {
    float2 f = __bfloat1622float2(w2[i]);
    u[2 * i] = rbf((u[2 * i] * r) * f.x);
    u[2 * i + 1] = rbf((u[2 * i + 1] * r) * f.y);
  }
}
// 8 bf16 values at k0..k0+7 of token b into a 16-bit fragment: pairs (k, k+1) are one 32-bit word
template <bool CPT>
__device__ __forceinline__ void put8(bf16* f, int b, int k0, const float* y) {
#pragma unroll
  for (int i = 0; i < 4; i++) {
    int k = k0 + 2 * i;
    *reinterpret_cast<__nv_bfloat162*>(f + fi16<CPT>(b, k)) = __floats2bfloat162_rn(y[2 * i], y[2 * i + 1]);
  }
}
// NVFP4 input quantization of one token (four over six); a block of 16 = threads (2m, 2m+1). Writes f16 frags.
__device__ __forceinline__ float e2m1_rne(float mag) {
  float q;
  if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
  else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
  return q;
}
// E2M1 round-to-nearest-even of two values, saturating at +-6, as f16x2 (v0 in the low half): the hardware conversion
// rounds exactly like the compare chain e2m1_rne above, signed zeros included (tools/ptx/t5.cu, 3096 values around every
// tie); only a NaN input differs (hardware 6, chain 0), which no finite activation produces.
__device__ __forceinline__ uint32_t e2m1x2_h(float v0, float v1) {
  uint32_t h;
  asm("{ .reg .b8 t; cvt.rn.satfinite.e2m1x2.f32 t, %2, %1; cvt.rn.f16x2.e2m1x2 %0, t; }" : "=r"(h) : "f"(v0), "f"(v1));
  return h;
}
__device__ __forceinline__ uint32_t h2x(float v) { __half2 h = __floats2half2_rn(v, v); return *reinterpret_cast<uint32_t*>(&h); }
__device__ __forceinline__ float2 h2f(uint32_t h) { return __half22float2(*reinterpret_cast<__half2*>(&h)); }
// NVFP4 quantization of one block of 16 values held by one thread (the w2 inputs): the two candidate block scales, the
// lower-error one kept; out: the 8 f16x2 words (code x block scale, elements 2i and 2i+1). The error sum is formed in
// the order of the former 16-lane shuffle tree (k with k^8, then ^4, ^2, ^1).
__device__ __forceinline__ void quant_nvfp4_16(const float* x, float amax, uint32_t* out) {
  const float FMAX = 3.4028234663852886e38f;
  if (amax == 0.f) {
#pragma unroll
    for (int i = 0; i < 8; i++) out[i] = 0u;
    return;
  }
  float bm = 0.f;
#pragma unroll
  for (int i = 0; i < 16; i++) bm = fmaxf(bm, fabsf(x[i]));
  const float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder, outer = amax * (1.0f / 1536.0f);
  uint32_t vh[2][8];
  float er[2];
#pragma unroll
  for (int cand = 0; cand < 2; cand++) {
    const float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
    const float scale = float(__nv_fp8_e4m3(fminf(bm * (encoder * inv_max), 448.0f)));
    const float inverse = fminf(1.0f / (scale * decoder), FMAX);
    const uint32_t s2 = h2x(scale);
    float e[16];
#pragma unroll
    for (int i = 0; i < 8; i++) {
      vh[cand][i] = hmul2(e2m1x2_h(x[2 * i] * inverse, x[2 * i + 1] * inverse), s2);
      const float2 f = h2f(vh[cand][i]);
      e[2 * i] = fabsf(__fmaf_rn(f.x, outer, -x[2 * i]));
      e[2 * i + 1] = fabsf(__fmaf_rn(f.y, outer, -x[2 * i + 1]));
    }
#pragma unroll
    for (int k = 0; k < 8; k++) e[k] = e[k] + e[k + 8];
#pragma unroll
    for (int k = 0; k < 4; k++) e[k] = e[k] + e[k + 4];
    er[cand] = (e[0] + e[2]) + (e[1] + e[3]);
  }
  const bool pick = er[1] < er[0];   // a strictly better /4 wins
#pragma unroll
  for (int i = 0; i < 8; i++) out[i] = pick ? vh[1][i] : vh[0][i];
}
// uint32 (f16x2) index of elements (2i, 2i+1) of 16-block kb in the compact one-column fragment (see fidx16c)
__device__ __forceinline__ int fidx16c_w(int kb, int i) { return (((kb >> 2) * 4 + (i & 3)) * 4 + (kb & 3)) * 2 + (i >> 2); }
__device__ __forceinline__ void ld16g(const bf16* p, float* v) {
  const uint4 u0 = __ldcg(reinterpret_cast<const uint4*>(p)), u1 = __ldcg(reinterpret_cast<const uint4*>(p) + 1);
  const __nv_bfloat162* h0 = reinterpret_cast<const __nv_bfloat162*>(&u0);
  const __nv_bfloat162* h1 = reinterpret_cast<const __nv_bfloat162*>(&u1);
#pragma unroll
  for (int i = 0; i < 4; i++) {
    float2 f = __bfloat1622float2(h0[i]); v[2 * i] = f.x; v[2 * i + 1] = f.y;
    f = __bfloat1622float2(h1[i]); v[8 + 2 * i] = f.x; v[8 + 2 * i + 1] = f.y;
  }
}
template <bool CPT>
__device__ float quant_nvfp4_8(const float* x, int b, __half* frag, float* red) {
  float m = 0.f;
  if (ACT8) {
#pragma unroll
    for (int i = 0; i < 8; i++) m = fmaxf(m, fabsf(x[i]));
  }
  const float amax = bmax8(m, red);
  const float FMAX = 3.4028234663852886e38f;
  const float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder, outer = amax * (1.0f / 1536.0f);
  if (ACT8) {
    float bm = m;
    bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, 1));
#ifdef QCHAIN
    float sc[2], iv[2], er[2];
#pragma unroll
    for (int cand = 0; cand < 2; cand++) {
      float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
      sc[cand] = float(__nv_fp8_e4m3(fminf(bm * (encoder * inv_max), 448.0f)));
      iv[cand] = fminf(1.0f / (sc[cand] * decoder), FMAX);
      float err = 0.f;
#pragma unroll
      for (int i = 0; i < 8; i++) {
        float val = x[i] * iv[cand];
        float q = (val != val) ? 0.f : e2m1_rne(fabsf(val));
        err += fabsf(((signbit(val) ? -q : q) * sc[cand]) * outer - x[i]);
      }
      er[cand] = err + __shfl_xor_sync(0xffffffff, err, 1);
    }
    const int pick = (er[1] < er[0]) ? 1 : 0;   // a strictly better /4 wins
    const float scale = sc[pick], inverse = iv[pick];
    const int k0 = threadIdx.x * 8;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      float v2[2];
#pragma unroll
      for (int h = 0; h < 2; h++) {
        float val = x[2 * i + h] * inverse;
        float q = (val != val) ? 0.f : e2m1_rne(fabsf(val));
        v2[h] = (signbit(val) ? -q : q) * scale;
      }
      *reinterpret_cast<__half2*>(frag + fi16<CPT>(b, k0 + 2 * i)) = __floats2half2_rn(v2[0], v2[1]);
    }
  }
#else
    float sc[2], iv[2], er[2];
    uint32_t vh[2][4];
#pragma unroll
    for (int cand = 0; cand < 2; cand++) {
      float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
      sc[cand] = float(__nv_fp8_e4m3(fminf(bm * (encoder * inv_max), 448.0f)));
      iv[cand] = fminf(1.0f / (sc[cand] * decoder), FMAX);
      const uint32_t s2 = h2x(sc[cand]);
      float err = 0.f;
#pragma unroll
      for (int i = 0; i < 4; i++) {
        vh[cand][i] = hmul2(e2m1x2_h(x[2 * i] * iv[cand], x[2 * i + 1] * iv[cand]), s2);
        const float2 f = h2f(vh[cand][i]);
        err += fabsf(__fmaf_rn(f.x, outer, -x[2 * i]));
        err += fabsf(__fmaf_rn(f.y, outer, -x[2 * i + 1]));
      }
      er[cand] = err + __shfl_xor_sync(0xffffffff, err, 1);
    }
    const int pick = (er[1] < er[0]) ? 1 : 0;   // a strictly better /4 wins
    const int k0 = threadIdx.x * 8;
#pragma unroll
    for (int i = 0; i < 4; i++)
      *reinterpret_cast<uint32_t*>(frag + fi16<CPT>(b, k0 + 2 * i)) = pick ? vh[1][i] : vh[0][i];
  }
#endif
  return outer;
}
// MXFP8 input quantization: a block of 32 = threads 4m..4m+3
template <bool CPT>
__device__ void quant_mxfp8_8(const float* x, int b, uint8_t* frag, float* scales) {
  if (!ACT8) return;
  float m = 0.f;
#pragma unroll
  for (int i = 0; i < 8; i++) m = fmaxf(m, fabsf(x[i]));
  m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, 1));
  m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, 2));
  float raw = m * (1.0f / 448.0f);
  unsigned bits = __float_as_uint(raw);
  int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
  if (raw <= 5.877471754111438e-39f) ex = 0;
  if (ex > 254) ex = 254;
  float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
  const int k0 = threadIdx.x * 8;
  uint32_t w[2] = {0, 0};
#pragma unroll
  for (int i = 0; i < 8; i++) {
    float v = fminf(fmaxf(x[i] * inverse, -448.f), 448.f);
    w[i >> 2] |= (uint32_t)__nv_fp8_e4m3(v).__x << (8 * (i & 3));
  }
  *reinterpret_cast<uint32_t*>(frag + fi8<CPT>(b, k0)) = w[0];
  *reinterpret_cast<uint32_t*>(frag + fi8<CPT>(b, k0 + 4)) = w[1];
  if ((threadIdx.x & 3) == 0) scales[(k0 >> 5) * MAXB + b] = ue8m0((unsigned)ex);
}
// all-reduce sum of the cards' partials (LL mailbox of one layer parity), bf16-rounded, then the short conv:
// hist [3][H] (oldest first), taps w4 [H][4]; writes the shifted history (writer only).
// The 16 mailbox words of a thread are polled 8 at a time (all loads in flight together; a stale tag is re-read),
// and the history loads are issued before the first poll: the serial version cost 16 dependent load latencies.
#ifndef SERIAL_POLL
// par: re-read all stale words per round (B>=2: 8 polling blocks, -3.6 %) or one after the other (B=1: all 152 blocks
// poll the same mailbox and the 8x polling traffic costs 2 %, e0030)
__device__ __forceinline__ void rawconv8(const uint2 (*mb)[MAXB][H], int b, unsigned tag, const bf16* __restrict__ hist,
                                         const bf16* w4, bf16* __restrict__ hw, bool writer, float* out, const bool par = false,
                                         long long* stp = nullptr, int kk = -1) {
#define RCS(k) do { if (stp && threadIdx.x == 0) stp[k] = (long long)gtime(); } while (0)
  const int k0 = kk >= 0 ? kk : threadIdx.x * 8;
  float raw[8];
  uint4 r[2][4];
  RCS(0);
#pragma unroll
  for (int h = 0; h < 2; h++)
#pragma unroll
    for (int d = 0; d < 4; d++) r[h][d] = ld_relaxed_sys_v4(&mb[d][b][k0 + 2 * h]);
  const uint4 hu0 = __ldcg(reinterpret_cast<const uint4*>(hist + k0)), hu1 = __ldcg(reinterpret_cast<const uint4*>(hist + H + k0)),
              hu2 = __ldcg(reinterpret_cast<const uint4*>(hist + 2 * H + k0));
#pragma unroll
  for (int half = 0; half < 2; half++) {
    if (half) {
#pragma unroll
      for (int h = 0; h < 2; h++)
#pragma unroll
        for (int d = 0; d < 4; d++) r[h][d] = ld_relaxed_sys_v4(&mb[d][b][k0 + 4 + 2 * h]);
    }
    if (par) for (;;) {   // every stale word is re-read in the same round (the loads are in flight together)
      unsigned stale = 0;
#pragma unroll
      for (int h = 0; h < 2; h++)
#pragma unroll
        for (int d = 0; d < 4; d++) stale |= (unsigned)(r[h][d].y != tag || r[h][d].w != tag) << (h * 4 + d);
      if (!stale) break;
      __nanosleep(LL_BACKOFF);
#pragma unroll
      for (int h = 0; h < 2; h++)
#pragma unroll
        for (int d = 0; d < 4; d++)
          if ((stale >> (h * 4 + d)) & 1u) r[h][d] = ld_relaxed_sys_v4(&mb[d][b][k0 + 4 * half + 2 * h]);
    }
#pragma unroll
    for (int h = 0; h < 2; h++) {
#pragma unroll
      for (int d = 0; d < 4; d++)
        while (r[h][d].y != tag || r[h][d].w != tag) { __nanosleep(LL_BACKOFF); r[h][d] = ld_relaxed_sys_v4(&mb[d][b][k0 + 4 * half + 2 * h]); }
      raw[4 * half + 2 * h] = rbf(((__uint_as_float(r[h][0].x) + __uint_as_float(r[h][1].x)) + __uint_as_float(r[h][2].x)) + __uint_as_float(r[h][3].x));
      raw[4 * half + 2 * h + 1] = rbf(((__uint_as_float(r[h][0].z) + __uint_as_float(r[h][1].z)) + __uint_as_float(r[h][2].z)) + __uint_as_float(r[h][3].z));
    }
    if (half == 0) RCS(5);
  }
  RCS(1);
  float h0[8], h1[8], h2[8];
  {
    const __nv_bfloat162* a0 = reinterpret_cast<const __nv_bfloat162*>(&hu0);
    const __nv_bfloat162* a1 = reinterpret_cast<const __nv_bfloat162*>(&hu1);
    const __nv_bfloat162* a2 = reinterpret_cast<const __nv_bfloat162*>(&hu2);
#pragma unroll
    for (int i = 0; i < 4; i++) {
      float2 f = __bfloat1622float2(a0[i]); h0[2 * i] = f.x; h0[2 * i + 1] = f.y;
      f = __bfloat1622float2(a1[i]); h1[2 * i] = f.x; h1[2 * i + 1] = f.y;
      f = __bfloat1622float2(a2[i]); h2[2 * i] = f.x; h2[2 * i + 1] = f.y;
    }
  }
  RCS(2);
#pragma unroll
  for (int q = 0; q < 4; q++) {
    float wt[8];
    ld8(w4 + (k0 * 4) + q * 8, wt);
    out[2 * q] = sconv4f(h0[2 * q], h1[2 * q], h2[2 * q], raw[2 * q], wt);
    out[2 * q + 1] = sconv4f(h0[2 * q + 1], h1[2 * q + 1], h2[2 * q + 1], raw[2 * q + 1], wt + 4);
  }
  RCS(3);
  if (writer) { st8(hw + k0, h1); st8(hw + H + k0, h2); st8(hw + 2 * H + k0, raw); }
  RCS(4);
}
#else
__device__ __forceinline__ void raw8(const uint2 (*mb)[MAXB][H], int b, unsigned tag, float* raw) {
  const int k0 = threadIdx.x * 8;
#pragma unroll
  for (int h = 0; h < 4; h++) {
    float2 v0 = ll_get2(&mb[0][b][k0 + 2 * h], tag), v1 = ll_get2(&mb[1][b][k0 + 2 * h], tag);
    float2 v2 = ll_get2(&mb[2][b][k0 + 2 * h], tag), v3 = ll_get2(&mb[3][b][k0 + 2 * h], tag);
    raw[2 * h] = rbf(((v0.x + v1.x) + v2.x) + v3.x);
    raw[2 * h + 1] = rbf(((v0.y + v1.y) + v2.y) + v3.y);
  }
}
__device__ __forceinline__ void rawconv8(const uint2 (*mb)[MAXB][H], int b, unsigned tag, const bf16* __restrict__ hist,
                                         const bf16* w4, bf16* __restrict__ hw, bool writer, float* out, const bool par = false) {
  const int k0 = threadIdx.x * 8;
  float raw[8];
  raw8(mb, b, tag, raw);
  float h0[8], h1[8], h2[8];
  ld8g(hist + k0, h0); ld8g(hist + H + k0, h1); ld8g(hist + 2 * H + k0, h2);
#pragma unroll
  for (int q = 0; q < 4; q++) {
    float wt[8];
    ld8(w4 + (k0 * 4) + q * 8, wt);
    out[2 * q] = sconv4f(h0[2 * q], h1[2 * q], h2[2 * q], raw[2 * q], wt);
    out[2 * q + 1] = sconv4f(h0[2 * q + 1], h1[2 * q + 1], h2[2 * q + 1], raw[2 * q + 1], wt + 4);
  }
  if (writer) { st8(hw + k0, h1); st8(hw + H + k0, h2); st8(hw + 2 * H + k0, raw); }
}
#endif
// B=1: all 152 blocks need the conv output of the all-reduce, but a sys-scope load is not served from L2: with every
// block polling the 147 KB mailbox the phase took 6.6 us after the data was there (e0033). Block 0 polls, convolves and
// publishes the BF16 result (9 KB) with a tag; the other blocks wait for the tag and read the result through L2.
#ifndef RDC
#define RDC 0   // (measured slower: 4560 -> 5003 us, e0034: block 0's own poll+conv is the slow part, not the polling traffic)
#endif
template <bool RED>
__device__ __forceinline__ void rdconv8(const Ctx& c, int kind, unsigned tag, const uint2 (*mb)[MAXB][H], int b,
                                        const bf16* __restrict__ hist, const bf16* w4, bf16* __restrict__ hw, bool writer, float* out,
                                        long long* stp = nullptr) {
  if ((RED ? CONVH_RED : CONVH_STD)) {   // the helpers' result: 4 tagged words per thread
    if (ACT8) {
      const uint2* src = c.lls + ((long)(kind * MAXB + b) * H) + threadIdx.x * 8;
      uint4 r[4];
#pragma unroll
      for (int h = 0; h < 4; h++) r[h] = ld_relaxed_sys_v4(src + 2 * h);
      if (!RED) {
        for (;;) {
          unsigned stale = 0;
#pragma unroll
          for (int h = 0; h < 4; h++) stale |= (unsigned)(r[h].y != tag || r[h].w != tag) << h;
          if (!stale) break;
          __nanosleep(LL_BACKOFF);
#pragma unroll
          for (int h = 0; h < 4; h++) if ((stale >> h) & 1u) r[h] = ld_relaxed_sys_v4(src + 2 * h);
        }
      }
#pragma unroll
      for (int h = 0; h < 4; h++) {
        while (r[h].y != tag || r[h].w != tag) { __nanosleep(LL_BACKOFF); r[h] = ld_relaxed_sys_v4(src + 2 * h); }
        out[2 * h] = __uint_as_float(r[h].x); out[2 * h + 1] = __uint_as_float(r[h].z);
      }
    }
  } else if (RED && RDC) {
    bf16* pub = c.rconv + (long)kind * H;
    const int k0 = threadIdx.x * 8;
    if (blockIdx.x == 0) {
      if (ACT8) { rawconv8(mb, b, tag, hist, w4, hw, true, out, false); st8(pub + k0, out); __threadfence(); }
      __syncthreads();
      if (threadIdx.x == 0) atomicExch(&c.rtag[kind], tag);
    } else {
      if (threadIdx.x == 0) { while (ld_acquire_gpu(&c.rtag[kind]) != tag) __nanosleep(LL_BACKOFF); }
      __syncthreads();
      if (ACT8) ld8g(pub + k0, out);
    }
  } else if (ACT8) {
    rawconv8(mb, b, tag, hist, w4, hw, writer, out, !RED && POLL_PAR_STD, stp);
  }
}
// ---- conv helpers. The all-reduce of the cards' partials and the short conv are element-wise (no reduction), ~230
// instructions per thread, and the token phases are bound by the instruction throughput of the token's SM. Threads that
// are idle in the token phase do this work and publish the conv output (exact BF16 values as float bits, with the tag):
// B=1: warps 18-20 of blocks 0..5 (96 threads x 8 elements each); B>=2: 144 threads of 4 otherwise idle blocks per token.
// The token blocks then read 4 tagged words per thread instead of polling 16 and computing. The helpers write the history.
#define CH_RED_BLOCKS 6
#define CH_RED_THREADS (NV8 / CH_RED_BLOCKS)     // 96
#define CH_STD_PER_TOKEN 4
#define CH_STD_THREADS (NV8 / CH_STD_PER_TOKEN)  // 144
// kind 0: attention output of layer l; kind 1: MLP output of layer l
__device__ __forceinline__ void conv_help_one(const Ctx& c, int kind, int l, int b, int k0, bool par) {
  const unsigned tag = c.h.tag0 + l + 1;
  float out[8];
  if (kind == 0)
    rawconv8(c.comm[c.h.card]->lla[l & 1], b, tag, c.hist_attn + ((((long)c.h.parity * NL + l) * MAXB + b) * 3) * H, c.L[l].attn_sc,
             c.hist_attn + ((((long)(c.h.parity ^ 1) * NL + l) * MAXB + b) * 3) * H, true, out, par, nullptr, k0);
  else
    rawconv8(c.comm[c.h.card]->llm[l & 1], b, tag, c.hist_mlp + ((((long)c.h.parity * NL + l) * MAXB + b) * 3) * H, c.L[l].mlp_sc,
             c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + l) * MAXB + b) * 3) * H, true, out, par, nullptr, k0);
  uint2* dst = c.lls + ((long)(kind * MAXB + b) * H) + k0;
#pragma unroll
  for (int h = 0; h < 4; h++) ll_put2(dst + 2 * h, out[2 * h], out[2 * h + 1], tag);
}
// called by every thread; only helper threads work
__device__ __noinline__ void conv_help_red(const Ctx& c, int kind, int l) {
  const int j = (int)threadIdx.x - NV8;
  if ((int)blockIdx.x < CH_RED_BLOCKS && j >= 0 && j < CH_RED_THREADS) conv_help_one(c, kind, l, 0, ((int)blockIdx.x * CH_RED_THREADS + j) * 8, false);
}
__device__ __noinline__ void conv_help_std(const Ctx& c, int kind, int l) {
  const int hb = (int)blockIdx.x - c.h.B;
  if (hb >= 0 && hb < c.h.B * CH_STD_PER_TOKEN && (int)threadIdx.x < CH_STD_THREADS)
    conv_help_one(c, kind, l, hb / CH_STD_PER_TOKEN, ((hb % CH_STD_PER_TOKEN) * CH_STD_THREADS + (int)threadIdx.x) * 8, true);
}
// residual mix: sources s < nb: finished blocks, s == nb: the partial (+ fp32 addend), s == nb+1: attention out
__device__ __forceinline__ const bf16* msrc(Smem& sm, int nb, int s) { return s < nb ? sm.blk[s] : (s == nb ? sm.blk[8] : sm.ats); }
template <int NQ>
__device__ __forceinline__ void mix_part8(Smem& sm, int nb, int s0, int s1, const float* addend, const float* q) {
  if (!ACT8) return;
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5, k0 = threadIdx.x * 8;
  const float qs = 0.014731391274719739f;  // 4608 ** -0.5 rounded to fp32
  constexpr int G = (NQ == 1) ? 4 : 2;     // sources per batch: G * (NQ + 1) = 8 independent shuffle chains
  float qv[NQ][8];
#pragma unroll
  for (int qi = 0; qi < NQ; qi++) {
    float4 a = *reinterpret_cast<const float4*>(q + qi * H + k0), b = *reinterpret_cast<const float4*>(q + qi * H + k0 + 4);
    qv[qi][0] = a.x * qs; qv[qi][1] = a.y * qs; qv[qi][2] = a.z * qs; qv[qi][3] = a.w * qs;
    qv[qi][4] = b.x * qs; qv[qi][5] = b.y * qs; qv[qi][6] = b.z * qs; qv[qi][7] = b.w * qs;
  }
  for (int sb = s0; sb < s1; sb += G) {
    float a[G][1 + NQ];
#pragma unroll
    for (int g = 0; g < G; g++) {
#pragma unroll
      for (int k = 0; k <= NQ; k++) a[g][k] = 0.f;
      const int s = sb + g;
      if (s < s1) {
        uint4 u = *reinterpret_cast<const uint4*>(msrc(sm, nb, s) + k0);
        const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
        const bool add = (s == nb) && addend;
#pragma unroll
        for (int i = 0; i < 4; i++) {
          float2 f = __bfloat1622float2(h[i]);
          if (add) { f.x += addend[2 * i]; f.y += addend[2 * i + 1]; }
          a[g][0] += f.x * f.x;
          a[g][0] += f.y * f.y;
#pragma unroll
          for (int qi = 0; qi < NQ; qi++) { a[g][1 + qi] += f.x * qv[qi][2 * i]; a[g][1 + qi] += f.y * qv[qi][2 * i + 1]; }
        }
      }
    }
#pragma unroll
    for (int o = 16; o; o >>= 1)
#pragma unroll
      for (int g = 0; g < G; g++)
#pragma unroll
        for (int k = 0; k <= NQ; k++) a[g][k] += __shfl_xor_sync(0xffffffff, a[g][k], o);
    if (lane == 0) {
#pragma unroll
      for (int g = 0; g < G; g++)
        if (sb + g < s1)
#pragma unroll
          for (int k = 0; k <= NQ; k++) sm.red[w * 40 + (sb + g) * 4 + k] = a[g][k];
    }
  }
}
template <int NQ>
__device__ __forceinline__ void mix_finish8(Smem& sm, int n, int ncached = 0, int jq = 0) {
  float* red = sm.red;
  __syncthreads();
  // warp 0, lane s < n: the source's sums over the 18 active warps, 1/rms, and the softmax over sources (shuffles).
  // Sources s < ncached are finished blocks whose sums were computed once (cache_block): 1/rms and the dots with the
  // queries jq.. come from the cache (the same sums in the same order: bit-identical).
  if (threadIdx.x < 32) {
    const int s = threadIdx.x;
    const bool on = s < n, cached = s < ncached;
    float f[1 + NQ];
#pragma unroll
    for (int k = 0; k <= NQ; k++) {
      float t = 0.f;
      if (on && !cached) {
#pragma unroll
        for (int j = 0; j < W8; j++) t += red[j * 40 + s * 4 + k];
      }
      if (cached && k > 0) t = sm.qd[s][jq + k - 1];
      f[k] = t;
    }
    const float iv = on ? (cached ? sm.cinv[s] : rsqrtf(f[0] / (float)H + 1e-6f)) : 0.f;
    if (on) sm.minv[s] = iv;
#pragma unroll
    for (int qi = 0; qi < NQ; qi++) {
      float lg = on ? f[1 + qi] * iv : -INFINITY;
      float m = lg;
#pragma unroll
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float p = on ? expf(lg - m) : 0.f;
      // the sum in source order (as the serial loop did): prefix through shuffles from lane 0 upwards
      float z = 0.f;
      for (int q = 0; q < n; q++) z += __shfl_sync(0xffffffff, p, q);
      if (on) sm.mixp[qi * 10 + s] = p / z;
    }
  }
  __syncthreads();
}
__device__ __forceinline__ void mix_out8(Smem& sm, int nb, int n, const float* addend, int qi, float* out) {
  if (!ACT8) return;
  const int k0 = threadIdx.x * 8;
#pragma unroll
  for (int i = 0; i < 8; i++) out[i] = 0.f;
  for (int s = 0; s < n; s++) {
    uint4 u = *reinterpret_cast<const uint4*>(msrc(sm, nb, s) + k0);
    const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
    const float p = sm.mixp[qi * 10 + s], iv = sm.minv[s];
    const bool add = (s == nb) && addend;
#pragma unroll
    for (int i = 0; i < 4; i++) {
      float2 f = __bfloat1622float2(h[i]);
      if (add) { f.x += addend[2 * i]; f.y += addend[2 * i + 1]; }
      out[2 * i] += p * (f.x * iv);
      out[2 * i + 1] += p * (f.y * iv);
    }
  }
}

// ---- B=1 query cache. Global query index: layer l's attention queries at qbase(l) (1, or 3 in a global layer), its
// MLP query behind them, the output query at 112.
#define NQTOT 113
__device__ __forceinline__ int qbase(int l) { return 2 * l + 2 * (l / 6); }
// The vector in sm.blk[8] has just become final (it is, or will be, finished block m; nb finished blocks precede it):
// this block computes its dot with query jmin + blockIdx.x (and everybody its 1/rms) with the code of the per-sublayer
// mix, and publishes the dot; all blocks pick the row up after the next grid barrier (step_body).
__device__ __forceinline__ void cache_block(const Ctx& c, Smem& sm, int m, int nb, int jmin) {
  const int j = jmin + blockIdx.x;
  const int jc = min(j, NQTOT - 1);
  const float* q = c.oq;
  for (int l = 0; l < NL; l++) {
    const int b0 = qbase(l), nq = (l % 6 == 5) ? 3 : 1;
    if (jc >= b0 && jc < b0 + nq && l > 0) q = c.L[l].aq + (long)(jc - b0) * H;
    if (jc == b0 + nq) q = c.L[l].mq;
  }
  mix_part8<1>(sm, nb, nb, nb + 1, nullptr, q);
  __syncthreads();
  if (threadIdx.x == 0) {
    float t0 = 0.f, t1 = 0.f;
#pragma unroll
    for (int w = 0; w < W8; w++) { t0 += sm.red[w * 40 + nb * 4]; t1 += sm.red[w * 40 + nb * 4 + 1]; }
    sm.cinv[m] = rsqrtf(t0 / (float)H + 1e-6f);
    if (j < NQTOT) c.qd[m * 128 + j] = t1;
  }
}
// phase: (mlp all-reduce of layer i-1, sconv, finalize) + attention input of layer i. One block per token.
template <bool RED>
__device__ PH_ATTR void phase_attn_in(const Ctx& c, int i, int b, Smem& sm, bool dowait, unsigned ev) {
  const LayerW& L = c.L[i];
  const bool writer = !RED || blockIdx.x == 0;
  bf16* xfd = RED ? &sm.fx[0][0] : c.xfrag;
  const int xstride = RED ? H : 72 * 32 * 16;
  float* red = sm.red;
  bf16* part = sm.blk[8];
  const int k0 = threadIdx.x * 8;
  if (i == 0) {
    float u[8];
    if (c.h.mode == 2) {   // track B: c.embed holds the normed embedding, and the token's row of the layer-0 table goes
      // to c.qkvo here (the loader set layer 0's qkv_strips to 0: its GEMV has nothing to do)
      if (ACT8) { ld8g(c.embed + (long)c.h.tokens[b] * H + k0, u); st8(part + k0, u); }
      if (writer && threadIdx.x < 480)
        reinterpret_cast<uint4*>(c.qkvo + b * 3840)[threadIdx.x] = __ldcg(reinterpret_cast<const uint4*>(c.l0tab + (long)c.h.tokens[b] * 3840) + threadIdx.x);
      return;
    }
    if (ACT8) ld8g(c.embed + (long)c.h.tokens[b] * H + k0, u);
    rmsnorm8(u, c.embed_norm, red);
    if (ACT8) { st8(part + k0, u); if (c.h.mode == 1) st8(c.partial + (long)b * H + k0, u); }
    rmsnorm8(u, L.norm[0], red);
    if (ACT8) put8<RED>(xfd, b, k0, u);
    if (RED && QCACHE) { __syncthreads(); cache_block(c, sm, 0, 0, qbase(0) + 1); }   // the embedding is block 0
    return;
  }
  const int lp = i - 1;
  // ---- before the cross-card wait: the finished blocks' statistics
  const int nb_before = (lp == 0) ? 0 : ((lp - 1) / 6 + 1);
  const bool boundary = (lp % 6) == 0;
  const int nb = nb_before + (boundary ? 1 : 0);
  if (boundary) {
    if (ACT8) *reinterpret_cast<uint4*>(sm.blk[nb_before] + k0) = *reinterpret_cast<const uint4*>(part + k0);
    __syncthreads();
  }
  const int ncq = (RED && QCACHE) ? nb : 0;   // finished blocks taken from the cache
  if (!ncq) {
    if (L.glob) mix_part8<3>(sm, nb, 0, nb, nullptr, L.aq);
    else mix_part8<1>(sm, nb, 0, nb, nullptr, L.aq);
  }
  (void)dowait; (void)ev;   // the mlp values are polled by tag in raw8
  TM(i, 1);
  float mlp[8];
  rdconv8<RED>(c, 1, c.h.tag0 + lp + 1, c.comm[c.h.card]->llm[lp & 1], b, c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H,
               c.L[lp].mlp_sc, c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, writer, mlp);
  if (ACT8) {
    float at[8], pv[8];
    ld8(sm.ats + k0, at);
    ld8(part + k0, pv);
    if (c.dbg && writer) st8(c.dbg + ((long)(lp * 2 + 1) * MAXB + b) * H + k0, mlp);
#pragma unroll
    for (int e = 0; e < 8; e++) pv[e] = boundary ? (at[e] + mlp[e]) : ((pv[e] + at[e]) + mlp[e]);
    st8(part + k0, pv);
  }
  TM(i, 16);
  __syncthreads();
  TM(i, 17);
  const int nq = L.glob ? 3 : 1;
  if (L.glob) { mix_part8<3>(sm, nb, nb, nb + 1, nullptr, L.aq); mix_finish8<3>(sm, nb + 1, ncq, qbase(i)); }
  else { mix_part8<1>(sm, nb, nb, nb + 1, nullptr, L.aq); mix_finish8<1>(sm, nb + 1, ncq, qbase(i)); }
  TM(i, 18);
  for (int k = 0; k < nq; k++) {
    float o[8];
    mix_out8(sm, nb, nb + 1, nullptr, k, o);
    rmsnorm8(o, L.norm[k], red);
    if (ACT8) put8<RED>(xfd + k * xstride, b, k0, o);
  }
  // the partial entering a boundary layer is final: it is the old partial of this layer's MLP mix and block i / 6 after
  if (RED && QCACHE && i % 6 == 0) { __syncthreads(); cache_block(c, sm, i / 6, nb, qbase(i) + (L.glob ? 3 : 1)); }
}

// attention: block per (token b, local kv head kh, chunk ch)
__device__ PH_ATTR void phase_attention(const Ctx& c, int i, int b, int kh, int ch, int nch, Smem& sm, bool combine) {
  // B=1 kernel (combine == false, the phase is its own function there): scores by the tensor cores and 8 dimensions per
  // thread in the value sum (-0.75 %). In the B>=2 kernel the same code costs 3 % (frame 240 -> 264 B): scalar there.
  const bool tc = ATT_TC && (!combine || ATT_TC_STD);
  const LayerW& L = c.L[i];
#define TMA(id) do { if (b == 0 && kh == 0 && ch == 0) TM(i, id); \
    if (c.tprof && i == 20 && threadIdx.x == 0 && (id) >= 32 && (id) <= 39 && blockIdx.x < 16) c.tprof[49 * 64 + 760 + blockIdx.x * 8 + (id) - 32] = gtime(); } while (0)
  TMA(32);
  const int t = c.h.pos;
  const int lo = L.glob ? 0 : max(0, t + 1 - WIN);
  const int p0 = lo + ch * CHUNK, p1 = min(t + 1, p0 + CHUNK);
  const bf16* qkv = c.qkvo + b * 3840;
  // row offsets in the local qkv matrix
  const int OQ = 0, OG = 1536, OR = 3072, OS = 3264, OK = 3280, ODK = 3536, OV = L.glob ? 3552 : 3536, ODV = 3808;
  float tau = 1.0f;
  if (L.glob) tau = 1.0f + 0.1f * logf(fmaxf((float)(t + 1) / 128000.0f, 1.0f));
  bf16* kcache = c.kc + (((long)(i * MAXB + b) * NKVL + kh) * c.maxctx) * HD;
  bf16* vcache = c.vc + (((long)(i * MAXB + b) * NKVL + kh) * c.maxctx) * HD;
  int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  float* red = sm.red;
  // q of the 6 heads (l2 clip with scale) -> sm.qv; rel bias -> sm.relb (for positions of this chunk)
  // each warp w<6 handles head j=w
  if (w < 6) {
    int hl = kh * 6 + w;
    float v[4], ss = 0.f;
    // all loads of the warp first: q and its scale, r and its scale
    float rv = 0.f;
    if (lane < 16) rv = bf(qkv[OR + hl * 16 + lane]) * bf(L.rscale[hl * 16 + lane]);
    for (int k = 0; k < 4; k++) {
      int d = lane + 32 * k;
      v[k] = bf(qkv[OQ + hl * HD + d]) * bf(L.qscale[hl * HD + d]);
      ss += v[k] * v[k];
    }
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
    float f = fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f);
    for (int k = 0; k < 4; k++) {
      float qq = rbf(v[k] * f);
      if (L.glob) qq = rbf(qq * tau);
      sm.qv[w * HD + lane + 32 * k] = qq;
    }
    // r: 16 values
    float rs = rv * rv;
    for (int o = 16; o; o >>= 1) rs += __shfl_xor_sync(0xffffffff, rs, o);
    float rf = fminf(8.0f / (sqrtf(rs) + 1e-6f), 1.0f);
    float rr = rbf(rv * rf);
    if (L.glob) rr = rbf(rr * tau);
    if (lane < 16) sm.misc[16 + w * 16 + lane] = rr;
  }
  // K and V rows of this chunk into shared memory (the B-fragment area is free during attention); row t later
#define KST (HD + 8)   // padded row stride (272 B): a warp reading 32 rows at one offset hits distinct banks
  bf16* ks = reinterpret_cast<bf16*>(sm.stage);
  bf16* vs = ks + CHUNK * KST;
  {
    const int np = p1 - p0;
    for (int k = tid; k < np * 16; k += NTH) {   // 16 x 16 B per row, asynchronous
      int r = k >> 4, q = k & 15;
      if (p0 + r == t) continue;
      unsigned dk = (unsigned)__cvta_generic_to_shared(ks + r * KST + q * 8), dv = (unsigned)__cvta_generic_to_shared(vs + r * KST + q * 8);
      asm volatile("cp.async.cg.shared.global [%0], [%1], 16;" :: "r"(dk), "l"(kcache + (long)(p0 + r) * HD + q * 8) : "memory");
      asm volatile("cp.async.cg.shared.global [%0], [%1], 16;" :: "r"(dv), "l"(vcache + (long)(p0 + r) * HD + q * 8) : "memory");
    }
    asm volatile("cp.async.commit_group;" ::: "memory");
  }
  // relative-bias projection values of this thread's (head, position) pair, loaded early
  const int sj = tid >> 7, sp = tid & 127;   // scores: thread -> (head sj < 6, position p0 + sp)
  const bool sact = sj < 6 && sp < p1 - p0;
  const int sdist = t - (p0 + sp);
  float pv[DREL];
#pragma unroll
  for (int d = 0; d < DREL; d++) pv[d] = (!tc && sact && sdist < RELEXT) ? bf(L.relp[d * RELEXT + sdist]) : 0.f;
  // (tensor-core scores) the relative-bias projection as the B operand of one MMA per group of 8 positions: lane
  // (n = lane >> 2, t = lane & 3) holds relp[2t, 2t+1, 2t+8, 2t+9][distance of position n]
  const int sgp = p0 + w * 8 + (lane >> 2);   // warp w < 16: positions p0 + 8w .. p0 + 8w + 7
  const int sgd = t - sgp;
  uint32_t rb0 = 0u, rb1 = 0u;
  if (tc && w < 16 && sgp < p1 && sgd < RELEXT) {
    const int tt = lane & 3;
    const bf16* rp = L.relp + sgd;
    rb0 = (uint32_t)reinterpret_cast<const uint16_t*>(rp)[(2 * tt) * RELEXT] | ((uint32_t)reinterpret_cast<const uint16_t*>(rp)[(2 * tt + 1) * RELEXT] << 16);
    rb1 = (uint32_t)reinterpret_cast<const uint16_t*>(rp)[(2 * tt + 8) * RELEXT] | ((uint32_t)reinterpret_cast<const uint16_t*>(rp)[(2 * tt + 9) * RELEXT] << 16);
  }
  // new k, v at position t (by the chunk that holds t): warps 6-9 k, warps 10-13 v, one channel per lane;
  // the per-head norm over 128 channels through shared memory and a named barrier of these 8 warps
  if (p1 == t + 1 && w >= 6 && w < 14) {
    const int kv = (w - 6) >> 2, q4 = (w - 6) & 3;
    const int d = q4 * 32 + lane, ch_ = kh * HD + d;
    const int base = (kv == 0) ? OK : OV;
    const bf16* sc = (kv == 0) ? L.ksc : L.vsc;
    bf16* hist = (kv == 0 ? c.hist_k : c.hist_v) + ((long)(i * MAXB + b) * 3) * 256;
    const float raw = bf(qkv[base + ch_]);
    const float h0 = bf(hist[ch_]), h1 = bf(hist[256 + ch_]), h2 = bf(hist[512 + ch_]);
    float y;
    if (!L.glob) {
      y = sconv4(h0, h1, h2, raw, sc + ch_ * 4);
    } else {
      const int dbase = (kv == 0) ? ODK : ODV;
      float acc = 0.f;
      const float xs[4] = {raw, h2, h1, h0};
#pragma unroll
      for (int lag = 0; lag < 4; lag++) {
        float tap = bf(sc[lag * 256 + ch_]) + bf(qkv[dbase + kh * 4 + lag]);
        acc = acc + xs[lag] * tap;
      }
      y = rbf((acc + raw) * 0.3333333333333333f);
    }
    hist[ch_] = tobf(h1); hist[256 + ch_] = tobf(h2); hist[512 + ch_] = tobf(raw);
    float ss = y * y;
#pragma unroll
    for (int o = 16; o; o >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, o);
    if (lane == 0) sm.misc[112 + kv * 4 + q4] = ss;
    asm volatile("bar.sync 1, 256;" ::: "memory");
    float tot = sm.misc[112 + kv * 4 + 0] + sm.misc[112 + kv * 4 + 1] + sm.misc[112 + kv * 4 + 2] + sm.misc[112 + kv * 4 + 3];
    float yo = (kv == 0) ? rbf(y * fminf(22.627416997969522f / (sqrtf(tot) + 1e-6f), 1.0f)) : rbf(y * rsqrtf(tot / 128.0f + 1e-6f));
    (kv == 0 ? kcache : vcache)[(long)t * HD + d] = tobf(yo);
    (kv == 0 ? ks : vs)[(t - p0) * KST + d] = tobf(yo);
  }
  TMA(43);
  asm volatile("cp.async.wait_all;" ::: "memory");
  TMA(44);
  __syncthreads();
  TMA(33);
  TMA(34);
  // scores: one thread per (head, position): full 128-wide dot from shared memory, + relative bias
  if (!tc && sact) {
    const float* qj = sm.qv + sj * HD;
    const bf16* kr = ks + sp * KST;
    float dot = 0.f;
#pragma unroll 4
    for (int d0 = 0; d0 < HD; d0 += 8) {
      uint4 u = *reinterpret_cast<const uint4*>(kr + d0);
      const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
      float4 qa = *reinterpret_cast<const float4*>(qj + d0), qb = *reinterpret_cast<const float4*>(qj + d0 + 4);
      float2 f0 = __bfloat1622float2(h[0]), f1 = __bfloat1622float2(h[1]), f2 = __bfloat1622float2(h[2]), f3 = __bfloat1622float2(h[3]);
      dot += qa.x * f0.x; dot += qa.y * f0.y; dot += qa.z * f1.x; dot += qa.w * f1.y;
      dot += qb.x * f2.x; dot += qb.y * f2.y; dot += qb.z * f3.x; dot += qb.w * f3.y;
    }
    float bias = 0.f;
    if (sdist < RELEXT) {
      float pr = 0.f;
#pragma unroll
      for (int d = 0; d < DREL; d++) pr += sm.misc[16 + sj * 16 + d] * pv[d];
      bias = rbf(pr);
    }
    sm.att[sj * CHUNK + sp] = dot * 0.08838834764831845f + bias;
  }
  // scores by the tensor cores (q and K are BF16, the accumulator FP32): A = q of the 6 heads (rows 0-5 of a 16-row
  // tile), B = 8 key rows per warp, 8 k-steps of 16 dimensions; then one MMA for the relative bias (r x projection,
  // rounded to BF16 as the engines' einsum). The scalar version was 128 FMAs per (head, position) thread on 24 warps.
  if (tc && w < 16 && p0 + w * 8 < p1) {
    const int g = lane >> 2, tt = lane & 3;
    const bool hrow = g < 6;
    const float* qj = sm.qv + (hrow ? g : 0) * HD;
    const uint32_t* kr = reinterpret_cast<const uint32_t*>(ks + (w * 8 + g) * KST);
    float dd[4] = {0.f, 0.f, 0.f, 0.f};
#pragma unroll
    for (int j = 0; j < 8; j++) {
      uint32_t a0 = 0u, a2 = 0u;
      if (hrow) {
        const float2 q0 = *reinterpret_cast<const float2*>(qj + 16 * j + 2 * tt), q1 = *reinterpret_cast<const float2*>(qj + 16 * j + 2 * tt + 8);
        __nv_bfloat162 h0 = __floats2bfloat162_rn(q0.x, q0.y), h1 = __floats2bfloat162_rn(q1.x, q1.y);
        a0 = *reinterpret_cast<uint32_t*>(&h0); a2 = *reinterpret_cast<uint32_t*>(&h1);
      }
      mma_bf16(dd, a0, 0u, a2, 0u, kr[8 * j + tt], kr[8 * j + tt + 4]);
    }
    float db[4] = {0.f, 0.f, 0.f, 0.f};
    {
      uint32_t a0 = 0u, a2 = 0u;
      if (hrow) {
        const float2 r0 = *reinterpret_cast<const float2*>(&sm.misc[16 + g * 16 + 2 * tt]), r1 = *reinterpret_cast<const float2*>(&sm.misc[16 + g * 16 + 2 * tt + 8]);
        __nv_bfloat162 h0 = __floats2bfloat162_rn(r0.x, r0.y), h1 = __floats2bfloat162_rn(r1.x, r1.y);
        a0 = *reinterpret_cast<uint32_t*>(&h0); a2 = *reinterpret_cast<uint32_t*>(&h1);
      }
      mma_bf16(db, a0, 0u, a2, 0u, rb0, rb1);
    }
    if (hrow) {   // d0, d1: head g, positions 8w + 2t and 8w + 2t + 1
      *reinterpret_cast<float2*>(&sm.att[g * CHUNK + w * 8 + 2 * tt]) =
          make_float2(dd[0] * 0.08838834764831845f + rbf(db[0]), dd[1] * 0.08838834764831845f + rbf(db[1]));
    }
  }
  __syncthreads();
  TMA(35);
  // per head max and exp
  int np = p1 - p0;
  if (w < 6) {
    float m = -INFINITY;
    for (int p = lane; p < np; p += 32) m = fmaxf(m, sm.att[w * CHUNK + p]);
    for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
    float l = 0.f;
    for (int p = lane; p < np; p += 32) { float e = expf(sm.att[w * CHUNK + p] - m); sm.att[w * CHUNK + p] = e; l += e; }
    for (int o = 16; o; o >>= 1) l += __shfl_xor_sync(0xffffffff, l, o);
    if (lane == 0) { sm.misc[w * 2] = m; sm.misc[w * 2 + 1] = l; }
  }
  __syncthreads();
  TMA(36);
  // V: one thread per (head, dimension pair), all positions of the chunk; writes the chunk partial directly
  float* chunkp = c.achunk + ((long)((b * NKVL + kh) * MAXCHUNK + ch) * 6) * (2 + HD);
  // (all threads: (head, dimension pair, half of the positions); the two halves summed through shared memory)
  if (!tc) {
    const int half = tid / (6 * (HD / 2)), r6 = tid % (6 * (HD / 2));
    const int j = r6 / (HD / 2), d = (r6 % (HD / 2)) * 2;
    const int pm = (np + 1) / 2, pa = half ? pm : 0, pb = half ? np : pm;
    float o0 = 0.f, o1 = 0.f;
    const float* aj = sm.att + j * CHUNK;
    if (half < 2) {
#pragma unroll 4
      for (int p = pa; p < pb; p++) {
        float2 v = __bfloat1622float2(*reinterpret_cast<const __nv_bfloat162*>(vs + p * KST + d));
        const float e = aj[p];
        o0 += e * v.x; o1 += e * v.y;
      }
      if (half == 1) *reinterpret_cast<float2*>(&sm.opart[0][0] + r6 * 2) = make_float2(o0, o1);
    }
    __syncthreads();
    if (half == 0) {
      float2 hv = *reinterpret_cast<const float2*>(&sm.opart[0][0] + r6 * 2);
      *reinterpret_cast<float2*>(chunkp + j * (2 + HD) + 2 + d) = make_float2(o0 + hv.x, o1 + hv.y);
    }
  }
  // (all threads: (head, 8 dimensions, an eighth of the positions): one 16-byte load and 8 FMAs per position; the eight
  // slices summed in order through shared memory. Before: 2 dimensions per thread and half of the positions.)
  if (tc) {
    const int slice = tid / 96, r96 = tid % 96;
    const int j = r96 >> 4, d = (r96 & 15) * 8;
    const int pa = np * slice / 8, pb = np * (slice + 1) / 8;
    float o[8] = {0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f};
    const float* aj = sm.att + j * CHUNK;
    if (slice < 8) {
#pragma unroll 2
      for (int p = pa; p < pb; p++) {
        const uint4 u = *reinterpret_cast<const uint4*>(vs + p * KST + d);
        const __nv_bfloat162* h = reinterpret_cast<const __nv_bfloat162*>(&u);
        const float e = aj[p];
#pragma unroll
        for (int q = 0; q < 4; q++) { const float2 v = __bfloat1622float2(h[q]); o[2 * q] += e * v.x; o[2 * q + 1] += e * v.y; }
      }
      if (slice > 0) {
        float4* dst = reinterpret_cast<float4*>(&sm.opart[0][0] + ((slice - 1) * 96 + r96) * 8);
        dst[0] = make_float4(o[0], o[1], o[2], o[3]); dst[1] = make_float4(o[4], o[5], o[6], o[7]);
      }
    }
    __syncthreads();
    if (slice == 0) {
#pragma unroll
      for (int sl = 1; sl < 8; sl++) {
        const float4* src = reinterpret_cast<const float4*>(&sm.opart[0][0] + ((sl - 1) * 96 + r96) * 8);
        const float4 x0 = src[0], x1 = src[1];
        o[0] += x0.x; o[1] += x0.y; o[2] += x0.z; o[3] += x0.w; o[4] += x1.x; o[5] += x1.y; o[6] += x1.z; o[7] += x1.w;
      }
      float2* dst = reinterpret_cast<float2*>(chunkp + j * (2 + HD) + 2 + d);
#pragma unroll
      for (int q = 0; q < 4; q++) dst[q] = make_float2(o[2 * q], o[2 * q + 1]);
    }
  }
  if (tid < 6) { chunkp[tid * (2 + HD)] = sm.misc[tid * 2]; chunkp[tid * (2 + HD) + 1] = sm.misc[tid * 2 + 1]; }
  __syncthreads();
  TMA(36);
  TMA(37);
  if (!combine) return;   // B=1: every block combines the chunks itself in front of o_proj (phase_ocombine_red)
  // last chunk block combines
  __shared__ unsigned last;
  if (tid == 0) {
    __threadfence();
    unsigned old = atomicAdd(&c.acnt[b * NKVL + kh], 1u);
    last = (old == (unsigned)(nch - 1));
    if (last) c.acnt[b * NKVL + kh] = 0;
  }
  __syncthreads();
  TMA(38);
  if (!last) return;
  __threadfence();
  const float* base = c.achunk + ((long)((b * NKVL + kh) * MAXCHUNK) * 6) * (2 + HD);
  // per head: chunk scale factors exp(m_q - M) into shared memory (sm.att is free now), then 1/L and lse
  if (w < 6) {
    const int j = w;
    float mq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD)) : -INFINITY;
    float lq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD) + 1) : 0.f;
    float M = mq;
    for (int o = 16; o; o >>= 1) M = fmaxf(M, __shfl_xor_sync(0xffffffff, M, o));
    float f = (lane < nch) ? expf(mq - M) : 0.f;
    // L = sum over chunks in chunk order (lane order)
    float Ls = 0.f;
    for (int q = 0; q < nch; q++) Ls += __shfl_sync(0xffffffff, lq * f, q);
    if (lane < nch) sm.att[j * CHUNK + lane] = f;
    if (lane == 0) { sm.misc[j * 2] = M + logf(Ls); sm.misc[j * 2 + 1] = Ls; }
  }
  __syncthreads();
  for (int idx = tid; idx < 6 * HD; idx += NTH) {
    int j = idx / HD, d = idx % HD;
    float O = 0.f;
    for (int q = 0; q < nch; q++) O += __ldcg(base + (q * 6 + j) * (2 + HD) + 2 + d) * sm.att[j * CHUNK + q];
    const float Ls = sm.misc[j * 2 + 1];
    float lse = sm.misc[j * 2];
    float out = O / Ls;
    int hl = kh * 6 + j;
    float gate = bf(qkv[OG + hl * HD + d]);
    float sink = bf(qkv[OS + hl]);
    out = out * sigm(gate);
    out = out * sigm(lse - sink);
    put16<false>(c.ofrag, b, hl * HD + d, out);
  }
  TMA(39);
#undef TMA
}

// phase: attention all-reduce + sconv + mlp input mix + norm + quantization. One block per token.
template <bool RED>
__device__ PH_ATTR void phase_post_attn(const Ctx& c, int i, int b, Smem& sm, bool dowait, unsigned ev) {
  const LayerW& L = c.L[i];
  const bool writer = !RED || blockIdx.x == 0;
  float* red = sm.red;
  const int k0 = threadIdx.x * 8;
  // ---- before the wait
  const int nb = (i == 0) ? 0 : ((i - 1) / 6 + 1);
  const bool boundary = (i % 6) == 0;
  const int ncq = (RED && QCACHE) ? (boundary ? nb + 1 : nb) : 0;
  const int jq = qbase(i) + (L.glob ? 3 : 1);
  if (!ncq) mix_part8<1>(sm, nb, 0, boundary ? nb + 1 : nb, nullptr, L.mq);   // finished blocks (and the old partial at a boundary)
  (void)dowait; (void)ev;
  TM(i, 6);
  float at[8];
  rdconv8<RED>(c, 0, c.h.tag0 + i + 1, c.comm[c.h.card]->lla[i & 1], b, c.hist_attn + ((((long)c.h.parity * NL + i) * MAXB + b) * 3) * H,
               L.attn_sc, c.hist_attn + ((((long)(c.h.parity ^ 1) * NL + i) * MAXB + b) * 3) * H, writer, at,
#ifdef PROBE
               (c.tprof && blockIdx.x == 0 && i == 20) ? (long long*)c.tprof + 49 * 64 + 1050 : nullptr
#else
               nullptr
#endif
               );
  if (ACT8) {
    st8(sm.ats + k0, at);
    if (c.dbg && writer) st8(c.dbg + ((long)(i * 2) * MAXB + b) * H + k0, at);
  }
  TM(i, 20);
  __syncthreads();
  float out[8];
  if (boundary) {
    mix_part8<1>(sm, nb, nb + 1, nb + 2, nullptr, L.mq);
    mix_finish8<1>(sm, nb + 2, ncq, jq);
    mix_out8(sm, nb, nb + 2, nullptr, 0, out);
  } else {
    mix_part8<1>(sm, nb, nb, nb + 1, at, L.mq);
    mix_finish8<1>(sm, nb + 1, ncq, jq);
    mix_out8(sm, nb, nb + 1, at, 0, out);
  }
  TM(i, 21);
  rmsnorm8(out, L.mlp_norm, red);
  float* x = out;
  TM(i, 22);
  if (ACT8) put8<RED>(RED ? sm.fx2 : c.x2frag, b, k0, x);
  uint8_t* f13 = RED ? sm.f13 : c.w13frag;
  float* sc13 = RED ? sm.sc13 : c.w13sc;
  if (!L.mx) {
    float outer = quant_nvfp4_8<RED>(x, b, reinterpret_cast<__half*>(f13), red);
    if (threadIdx.x == 0) sc13[b] = outer;
  } else {
    quant_mxfp8_8<RED>(x, b, f13, sc13);
  }
}

// routing, computed redundantly by every block: warp b < B does token b's top-8; thread 0 the sorted union.
__device__ PH_ATTR void phase_route(const Ctx& c, int i, Smem& sm) {
  const LayerW& L = c.L[i];
  const int lane = threadIdx.x & 31, b = threadIdx.x >> 5;
  const int B = c.h.B;
  float* sel = &sm.opart[0][0];   // [B][384] selection scores (attention scratch, free here)
  const unsigned tag = c.h.tag0 + i + 1;
  // B>=2: token block t computes token t's top-8 alone (one warp) and publishes ids and weights with tags; the other
  // blocks only read them. (Every block computing all B rows: 8 warps share the SM, 6 us per layer at B=8.)
  const bool dist = ROUTE_DIST && B > 1;
  if (!dist) { for (int k = threadIdx.x; k < B * NE; k += NTH) sel[k] = sigm(ll_get1(&c.rll[k], tag)) + L.rbias[k % NE]; }
  else if ((int)blockIdx.x < B) { for (int k = threadIdx.x; k < NE; k += NTH) sel[k] = sigm(ll_get1(&c.rll[blockIdx.x * NE + k], tag)) + L.rbias[k]; }
  __syncthreads();
  if (dist ? (b == 0 && (int)blockIdx.x < B) : (b < B)) {
    const int tok = dist ? (int)blockIdx.x : b;
    float* sb = sel + (dist ? 0 : b * NE);
    int cid = 0;
#ifdef TOPK_OLD
    for (int r = 0; r < TOPK; r++) {
      float bv = -INFINITY; int bi = 1 << 30;
#pragma unroll
      for (int k = 0; k < 12; k++) {
        int e = lane + 32 * k;
        float v = sb[e];
        if (v > bv) { bv = v; bi = e; }
      }
#pragma unroll
      for (int o = 16; o; o >>= 1) {
        float ov = __shfl_xor_sync(0xffffffff, bv, o); int oi = __shfl_xor_sync(0xffffffff, bi, o);
        if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
      }
      if (lane == r) cid = bi;
      if (lane == 0) sb[bi] = -INFINITY;
      __syncwarp();
    }
#else
    // One warp per token and a chain of dependent instructions (~16 cycles each): the lane's 12 scores stay in
    // registers, the lane-local best comes from a tree, the warp maximum from value-only shuffles, the winning lane from
    // a ballot. Ties: the lowest expert index wins, as before (exact ties between lanes take the index reduction).
    float v[12];
#pragma unroll
    for (int k = 0; k < 12; k++) v[k] = sb[lane + 32 * k];
    for (int r = 0; r < TOPK; r++) {
      float p[6]; int pk[6];
#pragma unroll
      for (int j = 0; j < 6; j++) { const bool hi = v[2 * j + 1] > v[2 * j]; p[j] = hi ? v[2 * j + 1] : v[2 * j]; pk[j] = hi ? 2 * j + 1 : 2 * j; }
#pragma unroll
      for (int j = 0; j < 3; j++) { const bool hi = p[2 * j + 1] > p[2 * j]; p[j] = hi ? p[2 * j + 1] : p[2 * j]; pk[j] = hi ? pk[2 * j + 1] : pk[2 * j]; }
      { const bool hi = p[1] > p[0]; p[0] = hi ? p[1] : p[0]; pk[0] = hi ? pk[1] : pk[0]; }
      { const bool hi = p[2] > p[0]; p[0] = hi ? p[2] : p[0]; pk[0] = hi ? pk[2] : pk[0]; }
      const float bv = p[0]; const int bk = pk[0];
      float M = bv;
#pragma unroll
      for (int o = 16; o; o >>= 1) M = fmaxf(M, __shfl_xor_sync(0xffffffff, M, o));
      const unsigned mask = __ballot_sync(0xffffffff, bv == M);
      int win = __ffs(mask) - 1;
      if (__popc(mask) != 1) {
        int idx = (bv == M) ? lane + 32 * bk : (1 << 30);
#pragma unroll
        for (int o = 16; o; o >>= 1) idx = min(idx, __shfl_xor_sync(0xffffffff, idx, o));
        win = idx & 31;
      }
      const int wk = __shfl_sync(0xffffffff, bk, win);
      if (lane == r) cid = win + 32 * wk;
#pragma unroll
      for (int k = 0; k < 12; k++) if (lane == win && k == bk) v[k] = -INFINITY;
    }
#endif
    // lanes 0..7 hold the chosen experts in rank order
    float sg = 0.f;
    if (lane < TOPK) sg = sigm(ll_get1(&c.rll[tok * NE + cid], tag));
    float z = sg;
#pragma unroll
    for (int o = 1; o < 8; o <<= 1) z += __shfl_xor_sync(0xffffffff, z, o);
    if (lane < TOPK) {
      const float wt = sg / z * 8.0f;
      if (dist) {
        ll_put(&c.rtk[(tok * TOPK + lane) * 2], __uint_as_float((unsigned)cid), tag);
        ll_put(&c.rtk[(tok * TOPK + lane) * 2 + 1], wt, tag);
        if (c.dbg_ids) c.dbg_ids[(i * MAXB + tok) * TOPK + lane] = cid;
      } else {
        sm.ids[tok * TOPK + lane] = cid;
        sm.wts[tok * TOPK + lane] = wt;
        if (c.dbg_ids && blockIdx.x == 0) c.dbg_ids[(i * MAXB + tok) * TOPK + lane] = cid;
      }
    }
  }
  if (dist && threadIdx.x < B * TOPK) {
    sm.ids[threadIdx.x] = (int)__float_as_uint(ll_get1(&c.rtk[threadIdx.x * 2], tag));
    sm.wts[threadIdx.x] = ll_get1(&c.rtk[threadIdx.x * 2 + 1], tag);
  }
  __syncthreads();
  TM(i, 24);
  // sorted union: a 384-bit mask in shared memory (sm.red is free here), then warp 0 compacts it
  unsigned* msk = reinterpret_cast<unsigned*>(sm.red);
  if (threadIdx.x < 12) msk[threadIdx.x] = 0;
  __syncthreads();
  if (threadIdx.x < c.h.B * TOPK) { int e = sm.ids[threadIdx.x]; atomicOr(&msk[e >> 5], 1u << (e & 31)); }
  __syncthreads();
  if (threadIdx.x < 32) {
    unsigned m = (lane < 12) ? msk[lane] : 0u;
    int cnt = __popc(m), pre = cnt;
    for (int o = 1; o < 32; o <<= 1) { int v = __shfl_up_sync(0xffffffff, pre, o); if (lane >= o) pre += v; }
    int n = pre - cnt;   // exclusive prefix
    while (m) { int bit = __ffs(m) - 1; m &= m - 1; sm.uni[n++] = lane * 32 + bit; }
    if (lane == 31) sm.nuni = pre;
  }
  __syncthreads();
#ifndef W2_DENSE
  if (c.h.B > 1) {   // the pair map of the compact w2 fragments
    for (int k = threadIdx.x; k < MAXU * MAXB; k += NTH) sm.pmap[k] = -1;
    if (threadIdx.x < sm.nuni) sm.e2u[sm.uni[threadIdx.x]] = (unsigned char)threadIdx.x;
    __syncthreads();
    if (threadIdx.x < c.h.B * TOPK) sm.pmap[sm.e2u[sm.ids[threadIdx.x]] * MAXB + threadIdx.x / TOPK] = (signed char)threadIdx.x;
    __syncthreads();
  }
#endif
}

// quantize act (per (ui, token)) for w2 with the global amax. Block per (ui, token) pair.
__device__ PH_ATTR void phase_quant2(const Ctx& c, int i, int ui, int b, int p, Smem& sm) {
  const LayerW& L = c.L[i];
  // 576 values: thread t < 576? NTH=512 -> 2 passes; use per-thread 2 elements: k = tid, tid+512 (<576)
  if (threadIdx.x == 0) {   // wait for every card's tag of (expert ui, token b): this card's act is complete then
    float am = 0.f;
    for (int d = 0; d < NCARD; d++) am = fmaxf(am, ll_get1(&c.comm[c.h.card]->llx[i][d][ui][b], c.h.tag0 + i + 1));
    sm.misc[0] = am;
    __threadfence();
  }
  __syncthreads();
#if !defined(W2_DENSE) && !defined(QCHAIN)
  if (!L.mx) {   // one thread per block of 16 values (36 threads): hardware E2M1 rounding, no shuffles
    if (threadIdx.x < ILOC / 16) {
      float x16[16];
      ld16g(c.act + (ui * MAXB + b) * ILOC + threadIdx.x * 16, x16);
      uint32_t o[8];
      quant_nvfp4_16(x16, sm.misc[0], o);
      uint32_t* f = reinterpret_cast<uint32_t*>(c.w2frag + (long)p * 9 * 4 * 32);
#pragma unroll
      for (int q = 0; q < 8; q++) f[fidx16c_w(threadIdx.x, q)] = o[q];
      if (threadIdx.x == 0) c.w2sc[(long)p * 18] = sm.misc[0] * (1.0f / 1536.0f);
    }
    return;
  }
#endif
  if (threadIdx.x >= ILOC) return;   // 18 whole warps
  float x[1];
  const int n = 1;
  x[0] = bf(__ldcg(&c.act[(ui * MAXB + b) * ILOC + threadIdx.x]));
#ifdef W2_DENSE
  uint8_t* frag = c.w2frag + (long)ui * 9 * 32 * (L.mx ? 16 : 32);
  float* const scp = c.w2sc + (long)ui * 18 * MAXB;
#define Q2I16(k) fidx16(b, k)
#define Q2I8(k) fidx8(b, k)
#define Q2SC(kb) scp[(kb) * MAXB + b]
#else   // compact one-column fragments per routed pair p (the layouts of the B=1 kernel), scales [p][18]
  uint8_t* frag = c.w2frag + (long)p * 9 * 4 * (L.mx ? 16 : 32);
  float* const scp = c.w2sc + (long)p * 18;
#define Q2I16(k) fidx16c(k)
#define Q2I8(k) fidx8c(k)
#define Q2SC(kb) scp[kb]
#endif
  if (!L.mx) {
    const float amax = sm.misc[0];
    // the block-of-16 shuffles need full warps: elements k >= 576 are padding in a separate warp range
    // k = tid + 512: tids 0..63 valid, rest padding -> whole warps 0,1 valid; padding warps compute garbage not stored
    __half* f = reinterpret_cast<__half*>(frag);
    // inline quantization (amax given); store only k < 576
    const float FMAX = 3.4028234663852886e38f;
    float outer = amax * (1.0f / 1536.0f);
    if (amax == 0.f) {
      for (int e = 0; e < n; e++) { int k = threadIdx.x + e * NTH; if (k < ILOC) f[Q2I16(k)] = __float2half_rn(0.f); }
    } else {
      float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder;
      for (int e = 0; e < n; e++) {
        int k = threadIdx.x + e * NTH;
        float xv = x[e];
        float bm = fabsf(xv);
        for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));
        float best_val = 0.f, best_err = 0.f;
        for (int cand = 0; cand < 2; cand++) {
          float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
          float sraw = fminf(bm * (encoder * inv_max), 448.0f);
          float scale = float(__nv_fp8_e4m3(sraw));
          float inverse = fminf(1.0f / (scale * decoder), FMAX);
          float val = xv * inverse, mag = fabsf(val), q;
          if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
          else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
          if (val != val) q = 0.f;
          float vals = (signbit(val) ? -q : q) * scale;
          float err = fabsf(vals * outer - xv);
          for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
          if (cand == 0) { best_val = vals; best_err = err; } else if (err < best_err) best_val = vals;
        }
        if (k < ILOC) f[Q2I16(k)] = __float2half_rn(best_val);
      }
    }
    if (threadIdx.x == 0) Q2SC(0) = outer;
  } else {
    for (int e = 0; e < n; e++) {
      int k = threadIdx.x + e * NTH;
      float xv = x[e];
      float m = fabsf(xv);
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float raw = m * (1.0f / 448.0f);
      unsigned bits = __float_as_uint(raw);
      int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
      if (raw <= 5.877471754111438e-39f) ex = 0;
      if (ex > 254) ex = 254;
      float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
      float v = fminf(fmaxf(xv * inverse, -448.f), 448.f);
      if (k < ILOC) {
        frag[Q2I8(k)] = __nv_fp8_e4m3(v).__x;
        if ((threadIdx.x & 31) == 0) Q2SC(k >> 5) = ue8m0((unsigned)ex);
      }
    }
  }
}

// B == 1: every block quantizes the w2 inputs of all union experts into its shared memory (compact frags).
// Flat index over nu * 576 values: blocks of 16 (nvfp4) / 32 (mxfp8) never straddle experts.
__device__ PH_ATTR void phase_quant2_red(const Ctx& c, int i, int nu, Smem& sm) {
  const LayerW& L = c.L[i];
  const int total = nu * ILOC;
  const float FMAX = 3.4028234663852886e38f;
  if (threadIdx.x < nu) {   // one poller per expert: every card's max for this expert (and this card's act is complete)
    const unsigned tag = c.h.tag0 + i + 1;
    uint2 r[NCARD];
#pragma unroll
    for (int d = 0; d < NCARD; d++) r[d] = ld_relaxed_sys_v2(&c.comm[c.h.card]->llx[i][d][threadIdx.x][0]);   // all four in flight
    float am = 0.f;
#pragma unroll
    for (int d = 0; d < NCARD; d++) {
      while (r[d].y != tag) { __nanosleep(LL_BACKOFF); r[d] = ld_relaxed_sys_v2(&c.comm[c.h.card]->llx[i][d][threadIdx.x][0]); }
      am = fmaxf(am, __uint_as_float(r[d].x));
    }
    sm.misc[threadIdx.x] = am;
    __threadfence();
  }
  __syncthreads();
#ifndef QCHAIN
  if (!L.mx) {   // one thread per block of 16 values (nu * 36 threads): hardware E2M1 rounding, no shuffles
    if (threadIdx.x < nu * (ILOC / 16)) {
      const int ui = threadIdx.x / (ILOC / 16), kb = threadIdx.x % (ILOC / 16);
      float x16[16];
      ld16g(c.act + (ui * MAXB) * ILOC + kb * 16, x16);
      uint32_t o[8];
      quant_nvfp4_16(x16, sm.misc[ui], o);
      uint32_t* f = reinterpret_cast<uint32_t*>(sm.f2 + ui * 9 * 4 * 32);
#pragma unroll
      for (int q = 0; q < 8; q++) f[fidx16c_w(kb, q)] = o[q];
      if (kb == 0) sm.sc2[ui * 18 * MAXB] = sm.misc[ui] * (1.0f / 1536.0f);
    }
    __syncthreads();
    return;
  }
#endif
  constexpr int NIT = (TOPK * ILOC + NTH - 1) / NTH;   // B == 1: the union is the token's 8 experts
  bf16 xr[NIT];
#pragma unroll
  for (int it = 0; it < NIT; it++) {   // every load of the thread issued before the first is used
    const int idx = it * NTH + threadIdx.x;
    xr[it] = (idx < total) ? __ldcg(&c.act[((idx / ILOC) * MAXB) * ILOC + idx % ILOC]) : tobf(0.f);
  }
#pragma unroll
  for (int it = 0; it < NIT; it++) {
    const int base = it * NTH;
    int idx = base + threadIdx.x;
    if (base + (threadIdx.x & ~31) >= total) break;   // whole warps beyond the end
    int ui = idx / ILOC, kk = idx % ILOC;
    const float amax = sm.misc[ui];
    float xv = bf(xr[it]);
    if (!L.mx) {
      float outer = amax * (1.0f / 1536.0f);
      float best_val = 0.f;
      float bm = fabsf(xv);
      for (int o = 8; o; o >>= 1) bm = fmaxf(bm, __shfl_xor_sync(0xffffffff, bm, o));
      if (amax != 0.f) {
        float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder;
        float best_err = 0.f;
        for (int cand = 0; cand < 2; cand++) {
          float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
          float sraw = fminf(bm * (encoder * inv_max), 448.0f);
          float scale = float(__nv_fp8_e4m3(sraw));
          float inverse = fminf(1.0f / (scale * decoder), FMAX);
          float val = xv * inverse, mag = fabsf(val), q;
          if (mag <= 0.25f) q = 0.f; else if (mag < 0.75f) q = 0.5f; else if (mag <= 1.25f) q = 1.0f; else if (mag < 1.75f) q = 1.5f;
          else if (mag <= 2.5f) q = 2.0f; else if (mag < 3.5f) q = 3.0f; else if (mag <= 5.0f) q = 4.0f; else q = 6.0f;
          if (val != val) q = 0.f;
          float vals = (signbit(val) ? -q : q) * scale;
          float err = fabsf(vals * outer - xv);
          for (int o = 8; o; o >>= 1) err += __shfl_xor_sync(0xffffffff, err, o);
          if (cand == 0) { best_val = vals; best_err = err; } else if (err < best_err) best_val = vals;
        }
      }
      __half* f = reinterpret_cast<__half*>(sm.f2 + ui * 9 * 4 * 32);
      f[fidx16c(kk)] = __float2half_rn(best_val);
      if (kk == 0) sm.sc2[ui * 18 * MAXB] = outer;
    } else {
      float m = fabsf(xv);
      for (int o = 16; o; o >>= 1) m = fmaxf(m, __shfl_xor_sync(0xffffffff, m, o));
      float raw = m * (1.0f / 448.0f);
      unsigned bits = __float_as_uint(raw);
      int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
      if (raw <= 5.877471754111438e-39f) ex = 0;
      if (ex > 254) ex = 254;
      float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
      float v = fminf(fmaxf(xv * inverse, -448.f), 448.f);
      (sm.f2 + ui * 9 * 4 * 16)[fidx8c(kk)] = __nv_fp8_e4m3(v).__x;
      if ((kk & 31) == 0) sm.sc2[ui * 18 * MAXB + (kk >> 5) * MAXB] = ue8m0((unsigned)ex);
    }
  }
  __syncthreads();
}

// final: mlp all-reduce of layer 47 + finalize + output mix + norm -> hfrag
template <bool RED>
__device__ PH_ATTR void phase_final(const Ctx& c, int b, Smem& sm) {
  const bool writer = !RED || blockIdx.x == 0;
  float* red = sm.red;
  bf16* part = sm.blk[8];
  const int lp = NL - 1, k0 = threadIdx.x * 8;
  float mlp[8];
  rdconv8<RED>(c, 1, c.h.tag0 + lp + 1, c.comm[c.h.card]->llm[lp & 1], b, c.hist_mlp + ((((long)c.h.parity * NL + lp) * MAXB + b) * 3) * H,
               c.L[lp].mlp_sc, c.hist_mlp + ((((long)(c.h.parity ^ 1) * NL + lp) * MAXB + b) * 3) * H, writer, mlp);
  if (ACT8) {
    float at[8], pv[8];
    ld8(sm.ats + k0, at);
    ld8(part + k0, pv);
    if (c.dbg && writer) st8(c.dbg + ((long)(lp * 2 + 1) * MAXB + b) * H + k0, mlp);
#pragma unroll
    for (int e = 0; e < 8; e++) pv[e] = (pv[e] + at[e]) + mlp[e];   // layer 47 is not a boundary
    st8(part + k0, pv);
  }
  __syncthreads();
  if (RED && QCACHE) { mix_part8<1>(sm, 8, 8, 9, nullptr, c.oq); mix_finish8<1>(sm, 9, 8, NQTOT - 1); }
  else { mix_part8<1>(sm, 8, 0, 9, nullptr, c.oq); mix_finish8<1>(sm, 9); }
  float out[8];
  mix_out8(sm, 8, 9, nullptr, 0, out);
  rmsnorm8(out, c.fnorm, red);
  if (ACT8) put8<RED>(RED ? sm.fh : c.hfrag, b, k0, out);
}

// L2 prefetch of this layer's K and V rows (this card's 2 heads, every token, the positions attention will read)
template <int MODE>   // 0: none; 1: one warp walks the (token, head) ranges serially; 2: one thread per range
__device__ __forceinline__ void prefetch_kv(const Ctx& c, int i, int part, int nparts, int warp = 0) {
  if (MODE == 0) return;
  const int t = c.h.pos;
  const int lo = c.L[i].glob ? 0 : max(0, t + 1 - WIN);
  const long rows = t - lo;   // position t is written this step
  if (rows <= 0) return;
  if (MODE == 1) {
    for (int bh = 0; bh < c.h.B * NKVL; bh++) {
      long off = (((long)(i * MAXB + bh / NKVL) * NKVL + bh % NKVL) * c.maxctx + lo) * HD;
      prefetch_l2(c.kc + off, rows * HD * 2, part, nparts, warp);
      prefetch_l2(c.vc + off, rows * HD * 2, part, nparts, warp);
    }
  } else if (threadIdx.x < c.h.B * NKVL * 2 && nparts > 0) {
    const int bh = threadIdx.x >> 1;
    const long off = (((long)(i * MAXB + bh / NKVL) * NKVL + bh % NKVL) * c.maxctx + lo) * HD;
    const char* p = (const char*)(((threadIdx.x & 1) ? c.vc : c.kc) + off);
    const long bytes = rows * HD * 2;
    long a = (bytes * part / nparts) & ~15L, b = (bytes * (part + 1) / nparts) & ~15L;
    if (part == nparts - 1) b = bytes & ~15L;
    for (long o = a; o < b; o += 32768) {
      unsigned n = (unsigned)min(32768L, b - o);
      asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(p + o), "r"(n) : "memory");
    }
  }
}
// B=1: combine the attention chunks of all 12 local heads (every block redundantly) into the compact o_proj
// fragment in shared memory (sm.fx[0]; the q/k/v fragments are dead after the qkv GEMV)
__device__ PH_ATTR void phase_ocombine_red(const Ctx& c, int i, int nch, Smem& sm) {
  const int tid = threadIdx.x, lane = tid & 31, w = tid >> 5;
  const bf16* qkv = c.qkvo;   // token 0
  const int OG = 1536, OS = 3264;
  // per head (warp w < 12): chunk factors exp(m_q - M), the sum L and lse
  if (w < NQL) {
    const int kh = w / 6, j = w % 6;
    const float* base = c.achunk + ((long)(kh * MAXCHUNK) * 6) * (2 + HD);
    float mq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD)) : -INFINITY;
    float lq = (lane < nch) ? __ldcg(base + (lane * 6 + j) * (2 + HD) + 1) : 0.f;
    float M = mq;
    for (int o = 16; o; o >>= 1) M = fmaxf(M, __shfl_xor_sync(0xffffffff, M, o));
    float f = (lane < nch) ? expf(mq - M) : 0.f;
    float Ls = 0.f;
    for (int q = 0; q < nch; q++) Ls += __shfl_sync(0xffffffff, lq * f, q);
    if (lane < nch) sm.att[w * 32 + lane] = f;      // 12 x 32 floats (sm.att holds 6 x 128)
    if (lane == 0) { sm.misc[w * 2] = M + logf(Ls); sm.misc[w * 2 + 1] = Ls; }
  }
  __syncthreads();
  for (int idx = tid; idx < NQL * HD; idx += NTH) {
    const int hl = idx / HD, d = idx % HD, kh = hl / 6, j = hl % 6;
    const float* base = c.achunk + ((long)(kh * MAXCHUNK) * 6) * (2 + HD);
    float O = 0.f;
    for (int q = 0; q < nch; q++) O += __ldcg(base + (q * 6 + j) * (2 + HD) + 2 + d) * sm.att[hl * 32 + q];
    float out = O / sm.misc[hl * 2 + 1];
    out = out * sigm(bf(qkv[OG + hl * HD + d]));
    out = out * sigm(sm.misc[hl * 2] - bf(qkv[OS + hl]));
    put16<true>(&sm.fx[0][0], 0, hl * HD + d, out);
  }
  __syncthreads();
}
// L2 prefetch of a layer's small weights (scales, taps, norms, queries, router bias), one region per block
__device__ __forceinline__ void prefetch_small(const Ctx& c, int i, int part, int warp = 0) {
  const LayerW& L = c.L[i];
  const void* p = nullptr; long n = 0;
  switch (part) {
    case 0: p = L.qscale; n = NQL * HD * 2; break;
    case 1: p = L.rscale; n = NQL * DREL * 2; break;
    case 2: p = L.relp; n = DREL * RELEXT * 2; break;
    case 3: p = L.ksc; n = 256 * 4 * 2; break;
    case 4: p = L.vsc; n = 256 * 4 * 2; break;
    case 5: p = L.attn_sc; n = H * 4 * 2; break;
    case 6: p = L.mlp_sc; n = H * 4 * 2; break;
    case 7: p = L.mq; n = H * 4; break;
    case 8: p = L.mlp_norm; n = H * 2; break;
    case 9: p = L.rbias; n = NE * 4; break;
    case 10: p = L.f13; n = NE * 4; break;
    case 11: p = L.f2; n = NE * 4; break;
    case 12: if (i + 1 < NL) { p = c.L[i + 1].aq; n = (c.L[i + 1].glob ? 3 : 1) * H * 4; } break;
    case 13: if (i + 1 < NL) { p = c.L[i + 1].norm[0]; n = H * 2; } break;
    case 14: if (i + 1 < NL && c.L[i + 1].glob) { p = c.L[i + 1].norm[1]; n = H * 2; } break;
    case 15: if (i + 1 < NL && c.L[i + 1].glob) { p = c.L[i + 1].norm[2]; n = H * 2; } break;
    default: break;
  }
  if (p && n >= 16) prefetch_l2(p, n, 0, 1, warp);
}
// ------------------------------------------------------------------------------------------------ phase calls
template <bool RED> __device__ __noinline__ void ni_attn_in(const Ctx& c, int i, int b, Smem& sm) { phase_attn_in<RED>(c, i, b, sm, i > 0, 0); }
template <bool RED> __device__ __noinline__ void ni_post_attn(const Ctx& c, int i, int b, Smem& sm) { phase_post_attn<RED>(c, i, b, sm, true, 0); }
template <bool RED> __device__ __noinline__ void ni_final(const Ctx& c, int b, Smem& sm) { phase_final<RED>(c, b, sm); }
template <bool RED> __device__ __noinline__ void ni_attention(const Ctx& c, int i, int b, int kh, int ch, int nch, Smem& sm) { phase_attention(c, i, b, kh, ch, nch, sm, !RED); }
template <bool RED> __device__ __noinline__ void ni_route(const Ctx& c, int i, Smem& sm) { phase_route(c, i, sm); }
__device__ __noinline__ void ni_quant2_red(const Ctx& c, int i, int nu, Smem& sm) { phase_quant2_red(c, i, nu, sm); }
__device__ __noinline__ void ni_quant2(const Ctx& c, int i, int ui, int b, int p, Smem& sm) { phase_quant2(c, i, ui, b, p, sm); }
__device__ __noinline__ void ni_ocombine_red(const Ctx& c, int i, int nch, Smem& sm) { phase_ocombine_red(c, i, nch, sm); }
// ------------------------------------------------------------------------------------------------ GEMV calls
template <bool RED> __device__ GV_ATTR void call_qkv(const Ctx& c, Smem& sm, int i) {
  OpQKV<RED> op{i, RED ? &sm.fx[0][0] : c.xfrag, RED ? nullptr : reinterpret_cast<const bf16*>(sm.stage)};
  gemv_sel(c, op, c.L[i].qkv_strips, 72, 1, &sm.opart[0][0]);
}
template <bool RED> __device__ GV_ATTR void call_oproj(const Ctx& c, Smem& sm, int i) {
  OpOproj<RED> op{i, RED ? &sm.fx[0][0] : c.ofrag}; gemv_sel(c, op, 288, 24, 2, &sm.opart[0][0]);
}
template <bool RED> __device__ GV_ATTR void call_router(const Ctx& c, Smem& sm, int i) {
  OpRouter<RED> op{i, RED ? sm.fx2 : reinterpret_cast<const bf16*>(sm.stage)}; gemv_sel(c, op, 24, 72, 4, &sm.opart[0][0]);
}
#ifdef NI_W13W2   // the expert GEMVs of the B>=2 kernel as own functions (their loops' registers apart from the step's)
#define XG_ATTR __noinline__
#else
#define XG_ATTR __forceinline__
#endif
template <bool RED> __device__ __forceinline__ void call_w13_body(const Ctx& c, Smem& sm, int i, int nu);
template <bool RED> __device__ __forceinline__ void call_w2_body(const Ctx& c, Smem& sm, int i, int nu);
__device__ XG_ATTR void call_w13_std(const Ctx& c, Smem& sm, int i, int nu) { call_w13_body<false>(c, sm, i, nu); }
__device__ XG_ATTR void call_w2_std(const Ctx& c, Smem& sm, int i, int nu) { call_w2_body<false>(c, sm, i, nu); }
template <bool RED> __device__ __forceinline__ void call_w13(const Ctx& c, Smem& sm, int i, int nu) {
  if (RED) call_w13_body<true>(c, sm, i, nu); else call_w13_std(c, sm, i, nu);
}
template <bool RED> __device__ __forceinline__ void call_w2(const Ctx& c, Smem& sm, int i, int nu) {
  if (RED) call_w2_body<true>(c, sm, i, nu); else call_w2_std(c, sm, i, nu);
}
template <bool RED> __device__ __forceinline__ void call_w13_body(const Ctx& c, Smem& sm, int i, int nu) {
  const LayerW& L = c.L[i];
  OpW13<RED> op{i, nu, &sm, RED ? sm.f13 : sm.stage,
                RED ? sm.sc13 : (L.mx ? reinterpret_cast<const float*>(sm.stage + 36864) : c.w13sc), RED ? sm.sc13 : c.w13sc};
  gemv_sel(c, op, (long)nu * 72, 72, 8, &sm.opart[0][0]);
}
template <bool RED> __device__ __forceinline__ void call_w2_body(const Ctx& c, Smem& sm, int i, int nu) {
#ifndef W2_DENSE
  if (!RED) {
    const int np = c.h.B * TOPK;
    if (c.L[i].mx) stage_frags(sm, c.w2frag, np * 576, c.w2sc, np * 18 * 4);
    else {
      if (threadIdx.x < np) sm.w2o[threadIdx.x] = __ldcg(&c.w2sc[threadIdx.x * 18]);
      stage_frags(sm, c.w2frag, np * 1152);
    }
    OpW2S op{i, nu, &sm}; gemv_sel(c, op, 288, nu * 9, 16, &sm.opart[0][0]);
    return;
  }
#endif
  OpW2<RED> op{i, nu, &sm, RED ? sm.f2 : c.w2frag, RED ? sm.sc2 : c.w2sc}; gemv_sel(c, op, 288, nu * 9, 16, &sm.opart[0][0]);
}
#ifdef UNEMB_NI
#define UN_ATTR __noinline__
#else
#define UN_ATTR __forceinline__
#endif
template <bool RED> __device__ UN_ATTR void call_unembed(const Ctx& c, Smem& sm) {
  OpUnembed<RED> op{sm.bestv, sm.besti, RED ? sm.fh : reinterpret_cast<const bf16*>(sm.stage)}; gemv_sel(c, op, c.un_strips, 72, 32, &sm.opart[0][0]);
}
// ------------------------------------------------------------------------------------------------ the step kernel
template <bool RED>
__device__ __forceinline__ void step_body(const Ctx& c, Smem& sm, int layer_lo, int layer_hi) {
  if (RED) {
    for (int k = threadIdx.x; k < 144 * MAXB; k += NTH) sm.sc13[k] = 0.f;
    for (int k = threadIdx.x; k < 8 * 18 * MAXB; k += NTH) sm.sc2[k] = 0.f;
    __syncthreads();
  }
  if (threadIdx.x < 64) sm.gcnt[threadIdx.x] = 0;
  __syncthreads();
  unsigned nbar = 0;
  const unsigned barbase = *((volatile unsigned*)&c.bar[1]);
  const int B = c.h.B;
  const int nblk = gridDim.x;
  unsigned ev = 0;  // comm events of this launch (per counter kind)
  unsigned ev_attn = 0, ev_mlp = 0, ev_amax = 0;
  for (int i = layer_lo; i < layer_hi; i++) {
    const LayerW& L = c.L[i];
    // A: attention input
    TM(i, 0);
    if (RED) {
      // a bulk prefetch instruction holds its warp ~0.4 us: issued by warps the token phase leaves idle (18..23)
      prefetch_l2(PF_QKV(L), blockIdx.x, nblk, PFW(23));
      prefetch_kv<KVPF>(c, i, blockIdx.x, nblk, PFW(22));
      if (blockIdx.x >= nblk - 16) prefetch_small(c, i, nblk - 1 - blockIdx.x, PFW(21));
      if ((RED ? CONVH_RED : CONVH_STD) && i > 0 && (int)blockIdx.x < CH_RED_BLOCKS && threadIdx.x >= NV8) conv_help_red(c, 1, i - 1);
      if (NI_ON(true)) ni_attn_in<true>(c, i, 0, sm); else phase_attn_in<true>(c, i, 0, sm, i > 0, ev_mlp);
      __syncthreads();   // the fragments of every warp are read by the next GEMV
    } else {
      if (blockIdx.x < B) { if (NI_ON(false)) ni_attn_in<false>(c, i, blockIdx.x, sm); else phase_attn_in<false>(c, i, blockIdx.x, sm, i > 0, ev_mlp); }
      else {
        if ((RED ? CONVH_RED : CONVH_STD)) {   // prefetches by an idle warp (a bulk prefetch holds its warp); helper threads are in warps 0..4
          prefetch_l2(PF_QKV(L), blockIdx.x - B, nblk - B, 23); prefetch_kv<KVPF_STD>(c, i, blockIdx.x - B, nblk - B, 22);
          if (blockIdx.x >= nblk - 16) prefetch_small(c, i, nblk - 1 - blockIdx.x, 21);
          if (i > 0 && (int)blockIdx.x < B + B * CH_STD_PER_TOKEN) conv_help_std(c, 1, i - 1);
        } else {
          prefetch_l2(PF_QKV(L), blockIdx.x - B, nblk - B); prefetch_kv<KVPF_STD>(c, i, blockIdx.x - B, nblk - B);
          if (blockIdx.x >= nblk - 16) prefetch_small(c, i, nblk - 1 - blockIdx.x);
        }
      }
      grid_bar(c, nbar, barbase);
    }
    TM(i, 2);
    // B: qkv
    if (!RED) stage_frags(sm, c.xfrag, 73728);
    call_qkv<RED>(c, sm, i);
    __syncthreads();
    if (c.tprof && threadIdx.x == 0 && i == 20) {
      unsigned smid; asm volatile("mov.u32 %0, %%smid;" : "=r"(smid));
      c.tprof[49 * 64 + 0 * 152 + blockIdx.x] = gtime();
      c.tprof[49 * 64 + 3 * 152 + blockIdx.x] = smid;
    }
    grid_bar(c, nbar, barbase);
    if (RED && QCACHE && i % 6 == 0) {   // the row of the block finalized in this layer's attention-input phase
      if (threadIdx.x < 128) sm.qd[i / 6][threadIdx.x] = __ldcg(&c.qd[(i / 6) * 128 + threadIdx.x]);
      __syncthreads();
    }
    TM(i, 3);
    // C: attention
    {
      int t = c.h.pos;
      int lo = L.glob ? 0 : max(0, t + 1 - WIN);
      int nch = (t + 1 - lo + CHUNK - 1) / CHUNK;
      int nitems = B * NKVL * nch;
      if (blockIdx.x >= nitems && nitems < nblk) prefetch_l2(PF_WO(L), blockIdx.x - nitems, nblk - nitems);
      for (int it = blockIdx.x; it < nitems; it += nblk) {
        int b = it / (NKVL * nch), r = it % (NKVL * nch);
        if (NI_ON(RED) || ATT_TC_STD) ni_attention<RED>(c, i, b, r / nch, r % nch, nch, sm); else phase_attention(c, i, b, r / nch, r % nch, nch, sm, !RED);
        __syncthreads();
      }
      if (c.tprof && threadIdx.x == 0 && i == 20) c.tprof[49 * 64 + 4 * 152 + blockIdx.x] = gtime();
    }
    grid_bar(c, nbar, barbase);
    TM(i, 4);
    // D: o_proj -> all cards
    if (RED) {
      const int t = c.h.pos, lo = L.glob ? 0 : max(0, t + 1 - WIN);
      if (NI_ON(true)) ni_ocombine_red(c, i, (t + 1 - lo + CHUNK - 1) / CHUNK, sm); else phase_ocombine_red(c, i, (t + 1 - lo + CHUNK - 1) / CHUNK, sm);
    }
    call_oproj<RED>(c, sm, i);
#ifdef PROBE
    if (c.tprof && threadIdx.x == 0 && i == 20) c.tprof[49 * 64 + 888 + blockIdx.x] = gtime();
#endif
    ev_attn++;
    TM(i, 5);
    // E: post-attention (token blocks)
    if (RED) {
      prefetch_l2(PF_WR(L), blockIdx.x, nblk, PFW(23));
      if ((RED ? CONVH_RED : CONVH_STD) && (int)blockIdx.x < CH_RED_BLOCKS && threadIdx.x >= NV8) conv_help_red(c, 0, i);
      if (NI_ON(true)) ni_post_attn<true>(c, i, 0, sm); else phase_post_attn<true>(c, i, 0, sm, true, ev_attn);
      __syncthreads();
    } else {
      if (blockIdx.x < B) { if (NI_ON(false)) ni_post_attn<false>(c, i, blockIdx.x, sm); else phase_post_attn<false>(c, i, blockIdx.x, sm, true, ev_attn); }
      else {
        prefetch_l2(PF_WR(L), blockIdx.x - B, nblk - B, (RED ? CONVH_RED : CONVH_STD) ? 23 : 0);
        if ((RED ? CONVH_RED : CONVH_STD) && (int)blockIdx.x < B + B * CH_STD_PER_TOKEN) conv_help_std(c, 0, i);
      }
      grid_bar(c, nbar, barbase);
    }
    TM(i, 7);
    // F: router
    if (!RED) stage_frags(sm, c.x2frag, 73728);
    call_router<RED>(c, sm, i);
    TM(i, 8);
    // G: routing (every block)
#ifdef ICTEST
    phase_route(c, i, sm);   // a second, i-cache-warm run is timed 31 -> 9
    TM(i, 31);
#endif
    if (NI_ON(RED)) ni_route<RED>(c, i, sm); else phase_route(c, i, sm);
    TM(i, 9);
    int nu = sm.nuni;
    // H: w13 (+ act, amax to all cards)
    if (!RED) {
      if (L.mx) stage_frags(sm, c.w13frag, 36864, c.w13sc, 144 * MAXB * 4);
      else stage_frags(sm, c.w13frag, 73728);
    }
    call_w13<RED>(c, sm, i, nu);
    __syncthreads();
    if (c.tprof && threadIdx.x == 0 && i == 20) c.tprof[49 * 64 + 1 * 152 + blockIdx.x] = gtime();
    {
      long ub = L.mx ? UB8 : UB4, per = 288L * 9 * ub;
      // every block: its share of the union experts' w2 slabs
      if ((RED ? W2PF_RED : W2PF_STD) == 1) {
        // serial: warp 0 walks the union (one bulk prefetch per expert, ~0.4 us each). At B=1 the 8 prefetches hide in
        // the wait for the other cards' w13 and w2 then streams from L2; at B=8 the ~51 cost 20 us per layer (e0006).
        for (int u = 0; u < nu; u++) prefetch_l2(L.w2 + (long)sm.uni[u] * per, per, blockIdx.x, nblk);
      } else if ((RED ? W2PF_RED : W2PF_STD) == 2) {
        if (threadIdx.x < nu) {   // thread u takes expert u: all prefetches of the block issued at once
          const long a = (per * blockIdx.x / nblk) & ~15L, b = (per * (blockIdx.x + 1) / nblk) & ~15L;
          const char* p = (const char*)(L.w2 + (long)sm.uni[threadIdx.x] * per);
          for (long o = a; o < b; o += 32768) {
            unsigned n = (unsigned)min(32768L, b - o);
            asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(p + o), "r"(n) : "memory");
          }
        }
      }
    }
    ev_amax++;
    TM(i, 10);
    TM(i, 11);
    // I: quantize act for w2
    if (RED) {
      if (NI_ON(true)) ni_quant2_red(c, i, nu, sm); else phase_quant2_red(c, i, nu, sm);
    } else {
#ifdef W2_DENSE
      for (int it = blockIdx.x; it < nu * B; it += nblk) {
        int ui = it / B, b = it % B;
        bool routed = false;
        for (int r = 0; r < TOPK; r++) routed |= (sm.ids[b * TOPK + r] == sm.uni[ui]);
        if (routed) { if (NI_ON(false)) ni_quant2(c, i, ui, b, 0, sm); else phase_quant2(c, i, ui, b, 0, sm); __syncthreads(); }
        else {  // not routed: zero scale and zero fragment column (a stale fragment of the other format could be Inf)
          if (threadIdx.x < 18) c.w2sc[(ui * 18 + threadIdx.x) * MAXB + b] = 0.f;
          if (threadIdx.x < ILOC) {
            uint8_t* frag = c.w2frag + (long)ui * 9 * 32 * (L.mx ? 16 : 32);
            if (L.mx) frag[fidx8(b, threadIdx.x)] = 0;
            else reinterpret_cast<__half*>(frag)[fidx16(b, threadIdx.x)] = __float2half_rn(0.f);
          }
        }
      }
#else
      if (blockIdx.x < B * TOPK) {   // one block per routed (token, expert) pair
        const int p = blockIdx.x, ui = sm.e2u[sm.ids[p]], b = p / TOPK;
        if (NI_ON(false)) ni_quant2(c, i, ui, b, p, sm); else phase_quant2(c, i, ui, b, p, sm);
      }
#endif
      grid_bar(c, nbar, barbase);
    }
    TM(i, 12);
    // J: w2 -> all cards
    call_w2<RED>(c, sm, i, nu);
    __syncthreads();
    if (c.tprof && threadIdx.x == 0 && i == 20) c.tprof[49 * 64 + 2 * 152 + blockIdx.x] = gtime();
    ev_mlp++;
    TM(i, 13);
  }
  if (layer_hi == NL) {
    TM(NL, 0);
    if (RED) {
      if ((RED ? CONVH_RED : CONVH_STD) && (int)blockIdx.x < CH_RED_BLOCKS && threadIdx.x >= NV8) conv_help_red(c, 1, NL - 1);
      TM(NL, 1); if (NI_ON(true)) ni_final<true>(c, 0, sm); else phase_final<true>(c, 0, sm);
      __syncthreads();
    } else {
      if (blockIdx.x < B) { TM(NL, 1); if (NI_ON(false)) ni_final<false>(c, blockIdx.x, sm); else phase_final<false>(c, blockIdx.x, sm); }
      else if ((RED ? CONVH_RED : CONVH_STD) && (int)blockIdx.x < B + B * CH_STD_PER_TOKEN) conv_help_std(c, 1, NL - 1);
      grid_bar(c, nbar, barbase);
    }
    TM(NL, 2);
    for (int k = threadIdx.x; k < NWARP * MAXB; k += NTH) { sm.bestv[k] = -INFINITY; sm.besti[k] = 1 << 30; }
    __syncthreads();
    if (!RED) stage_frags(sm, c.hfrag, 73728);
    call_unembed<RED>(c, sm);
    __syncthreads();
    // block best per col -> candidates on every card
    if (threadIdx.x < B) {
      int col = threadIdx.x;
      float bv = -INFINITY; int bi = 1 << 30;
      for (int w = 0; w < NWARP; w++) {
        float v = sm.bestv[w * MAXB + col]; int ii = sm.besti[w * MAXB + col];
        if (v > bv || (v == bv && ii < bi)) { bv = v; bi = ii; }
      }
      for (int d = 0; d < NCARD; d++) { c.comm[d]->cand_v[c.h.card][col][blockIdx.x] = bv; c.comm[d]->cand_i[c.h.card][col][blockIdx.x] = bi; }
    }
    xsignal(c, 3, nbar, barbase);
    TM(NL, 3);
    if (blockIdx.x == 0) {
      xwait(c, 3, 1);
      TM(NL, 4);
      if (threadIdx.x < B) {
        int col = threadIdx.x;
        float bv = -INFINITY; int bi = 1 << 30;
        for (int d = 0; d < NCARD; d++)
          for (int k = 0; k < nblk; k++) {
            float v = c.comm[c.h.card]->cand_v[d][col][k]; int ii = c.comm[c.h.card]->cand_i[d][col][k];
            if (v > bv || (v == bv && ii < bi)) { bv = v; bi = ii; }
          }
        c.next_tok[col] = bi;
        if (c.h.gen_out) {
          if (c.h.gen_n) c.h.gen_out[c.h.gen_idx * MAXB + col] = bi + 1;          // host-mapped stream: 0 = not yet
          else c.h.gen_out[c.h.gen_idx * MAXB + col] = bi;
        }
      }
    }
  }
  grid_bar(c, nbar, barbase);
  if (blockIdx.x == 0 && threadIdx.x == 0) c.bar[1] = barbase + nbar * gridDim.x;
}

// the kernel parameters (Ctx, ~14 KB) are copied into shared memory once: every later access is a shared load,
// immune to the L1 invalidations of the barriers' acquire fences
#define CTXB ((sizeof(Ctx) + 127) / 128 * 128)
#define SMEM_TOTAL (CTXB + sizeof(Smem))
__device__ __forceinline__ const Ctx& load_ctx(const Ctx* cp, const Hdr& hdr, unsigned char* smraw) {
  static_assert(sizeof(Ctx) % 8 == 0 && sizeof(Hdr) % 8 == 0, "Ctx size");
  const uint2* src = reinterpret_cast<const uint2*>(cp);
  uint2* dst = reinterpret_cast<uint2*>(smraw);
  const int nh = sizeof(Hdr) / 8;
  for (int k = threadIdx.x; k < (int)(sizeof(Ctx) / 8); k += NTH)
    dst[k] = (k < nh) ? reinterpret_cast<const uint2*>(&hdr)[k] : src[k];   // the per-step header comes by value
  __syncthreads();
  return *reinterpret_cast<const Ctx*>(smraw);
}
extern "C" __global__ void __launch_bounds__(NTH, 1) ink_step_std(const Ctx* __restrict__ cp, const Hdr hdr, int lo, int hi) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Ctx& c = load_ctx(cp, hdr, smraw);
  step_body<false>(c, *reinterpret_cast<Smem*>(smraw + CTXB), lo, hi);
}
extern "C" __global__ void __launch_bounds__(NTH, 1) ink_step_red(const Ctx* __restrict__ cp, const Hdr hdr, int lo, int hi) {
  extern __shared__ __align__(16) unsigned char smraw[];
  const Ctx& c = load_ctx(cp, hdr, smraw);
  step_body<true>(c, *reinterpret_cast<Smem*>(smraw + CTXB), lo, hi);
}

// ------------------------------------------------------------------------------------------------ host API
extern "C" int ink_smem_bytes() { return (int)sizeof(Smem); }
extern "C" int ink_ctx_bytes() { return (int)sizeof(Ctx); }
extern "C" int ink_comm_bytes() { return (int)sizeof(Comm); }
extern "C" int ink_layer_bytes() { return (int)sizeof(LayerW); }

extern "C" int ink_setup(int dev) {
  cudaSetDevice(dev);
  cudaError_t e = cudaFuncSetAttribute(ink_step_std, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)SMEM_TOTAL);
  if (e) return (int)e;
  e = cudaFuncSetAttribute(ink_step_red, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)SMEM_TOTAL);
  return (int)e;
}

extern "C" int ink_enable_peer(int n) {
  for (int a = 0; a < n; a++) {
    cudaSetDevice(a);
    for (int b = 0; b < n; b++) if (a != b) {
      cudaError_t e = cudaDeviceEnablePeerAccess(b, 0);
      if (e != cudaSuccess && e != cudaErrorPeerAccessAlreadyEnabled) return (int)e;
      cudaGetLastError();
    }
  }
  return 0;
}
extern "C" void* ink_host_alloc(size_t n) {
  void* p = nullptr;
  if (cudaHostAlloc(&p, n, cudaHostAllocMapped | cudaHostAllocPortable) != cudaSuccess) return nullptr;
  memset(p, 0, n);
  return p;
}
extern "C" int ink_h2d(void* dst, const void* src, size_t n, void* stream) {
  return (int)cudaMemcpyAsync(dst, src, n, cudaMemcpyHostToDevice, (cudaStream_t)stream);
}
extern "C" int ink_launch(int dev, const void* ctx, const void* hdr, int nblk, void* stream, int lo, int hi, int red) {
  cudaSetDevice(dev);
  const Hdr h = *reinterpret_cast<const Hdr*>(hdr);
  if (red) ink_step_red<<<nblk, NTH, SMEM_TOTAL, (cudaStream_t)stream>>>((const Ctx*)ctx, h, lo, hi);
  else ink_step_std<<<nblk, NTH, SMEM_TOTAL, (cudaStream_t)stream>>>((const Ctx*)ctx, h, lo, hi);
  return (int)cudaGetLastError();
}
