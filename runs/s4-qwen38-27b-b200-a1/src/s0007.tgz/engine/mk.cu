// Megakernel for Qwen3.8-27B text decode on one B200.
//
// One kernel launch = one pass of the whole model (one decode step, or P positions per sequence at once).
// The grid is one 1024-thread block per SM; the model is a "program" of ops; all blocks walk the program
// together and meet at a spin barrier after every op.
//
// Every big matrix is stored in tensor-core fragment order (m16n8k16, weights = A operand): a warp reads 512
// contiguous bytes per 16 rows x 16 columns and feeds them to MMA without any shuffling. The up to 8 MMA columns
// are the sequences of the batch (or positions of one sequence). Each warp gets an equal contiguous share of a
// matrix (split along K too); a 16-row tile cut by warp boundaries is put together in a fixed order, so results
// do not depend on timing, on the batch size or on the column a sequence is in.
//
// What the card taught (notes/findings.md): (1) L1 is not coherent between SMs inside one grid: data another
// block wrote in this launch is read with ld.global.cg, or from a buffer nobody read before in this launch;
// (2) a spin-wait must use a volatile load; (3) a thread's stack is real memory: nothing big is passed by
// reference to a function, and a function with spills is entered only by warps that have work;
// (4) 64 registers per thread: the hot loop is not unrolled.
#include <cuda_runtime.h>
#include <stdint.h>
#include <stdio.h>

typedef unsigned long long u64;
typedef uint16_t u16;
typedef uint32_t u32;

#define HID 5120
#define VOCAB 248320
#define NCM 32            // max columns (buffer strides)
#define MROW 16480        // row stride of the mixer input buffer
#define RING 64           // conv history ring (positions per pass + 3 must fit)
#define PMAX 32           // max positions per pass

enum { OP_EMBED = 1, OP_GEMM = 2, OP_LMIX = 3, OP_ATT_PREP = 4, OP_ATT_SCORE = 5, OP_ATT_SOFTMAX = 6, OP_ATT_VSUM = 7,
       OP_ATT_OUT = 8, OP_ARGMAX = 9, OP_FINISH = 10, OP_MTP_IN = 11, OP_ACCEPT = 12, OP_CHAIN_FIN = 13 };
enum { EP_STORE = 1, EP_RESID = 2, EP_GATEUP = 3, EP_LOGITS = 4, EP_SET = 5 };
enum { F_SPEC = 1, F_LOGITS = 2, F_FEEDBACK = 4, F_CHAIN = 1024 };
#define NGRAM 6           // a draft may be copied from the context after a match of this many tokens

struct Op {   // 20 words
  long long type, ep, NT, KQ, use_r, M, i6, i7;
  void *W, *xf, *out, *gnext, *p4, *p5, *p6, *p7, *p8, *p9, *p10, *p11;
};

struct Ctx {
  int B, P, NC, NG;            // sequences, positions per pass, columns (B*P), column groups of 8
  int nwarps, nblocks, max_ctx, flags;
  int pos_ub, NGq, tok_stride, na_max;
  int pos_off, src_P, src_NG, src_sel;   // attention position offset; where MTP_IN finds the hidden state
  int next_P, pad0, pad1, pad2;          // positions per sequence of the next verify pass (layout of tokbuf)
  u64 bar_base;
  u64* bar;
  int* pos;                    // [B] tokens already consumed per sequence
  int* nacc;                   // [B] pending state updates to commit (speculative mode)
  const long long* tok_in;     // input token of column c at tok_in[c * tok_stride]
  u16* h;                      // [NCM][HID] residual stream, bf16
  u16* mbuf;                   // [NCM][MROW] mixer inputs, bf16
  float* ssq;                  // [320][NCM] partial sums of squares of h
  float4* part;                // partial accumulators of tiles cut by a block boundary
  int* cnt;                    // per-tile counters for those
  u16* logits;                 // [NC][VOCAB] bf16, when F_LOGITS
  float* amax_val;             // [15520][NCM]
  int* amax_idx;
  int* tok_res;                // [NCM] argmax per column
  long long* tok_out;          // [NC] int64, may be null
  long long* tokbuf;           // [NCM] device-side next input tokens
  u16* qf;                     // attention: query fragments
  float* sc;                   // attention: scores
  u16* pf;                     // attention: probability fragments
  float4* vpart;               // attention: partial V sums
  const float* rope_cos;       // [max_ctx][32]
  const float* rope_sin;
  int* limit;                  // [B] a sequence stops advancing at this position (speculative mode)
  int* mtp_res;                // [NCM] argmax of the draft head per column
  int* cnt_out;                // [B] tokens accepted in this pass, may be null
  const long long* tok_next;   // prefill: the token after each column's token
  int* hist;                   // [B][max_ctx] the tokens of each sequence by position (speculative mode)
  int* lkf;                    // [B] 1 when the drafts of the next pass were copied from the context
  const long long* pft;        // [nops][nblocks][2]: (address, bytes) of this block's share of the next weight matrix
  unsigned long long* ts;      // debug: block 0 records the global timer after every barrier (null: off)
};

// Shared memory: [0, 512) bytes the launch context and the current op, [512, 768) r per column, then the work
// area (recurrent-state slots, or the partial sums of cut tiles). Its size is chosen per launch: what is not
// shared memory is L1 cache, and the stream is 6-12 % faster with 80 KB of shared memory than with 200 KB.
#define CTX_WORDS ((sizeof(Ctx) + 7) / 8)
#define SMR_OFF 128       // floats
#define WORK_OFF 192      // floats
__device__ __forceinline__ const Ctx& CX() { extern __shared__ float sm[]; return *(const Ctx*)sm; }
__device__ __forceinline__ const Op& OP() { extern __shared__ float sm[]; return *(const Op*)((const long long*)sm + CTX_WORDS); }

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ float bf2f(u16 b) { return __uint_as_float(((u32)b) << 16); }
__device__ __forceinline__ u16 f2bf(float f) {
  u32 u = __float_as_uint(f);
  u += 0x7FFFu + ((u >> 16) & 1u);
  return (u16)(u >> 16);
}
__device__ __forceinline__ float rbf(float f) { return bf2f(f2bf(f)); }
__device__ __forceinline__ float sigmoidf_(float x) { return 1.0f / (1.0f + __expf(-x)); }
__device__ __forceinline__ float siluf_(float x) { return x * sigmoidf_(x); }

// Loads of anything another block may have written during this launch (bench/coh.cu: a default load can return
// the value this SM read before another SM overwrote it; ld.global.cg returns the new one).
__device__ __forceinline__ u16 ldv(const u16* p) { u32 v; asm volatile("ld.global.cg.u16 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return (u16)v; }
__device__ __forceinline__ int ldv(const int* p) { int v; asm volatile("ld.global.cg.s32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ float ldv(const float* p) { float v; asm volatile("ld.global.cg.f32 %0, [%1];" : "=f"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ uint2 ldv(const uint2* p) { uint2 v; asm volatile("ld.global.cg.v2.u32 {%0,%1}, [%2];" : "=r"(v.x), "=r"(v.y) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ uint4 ldv(const uint4* p) { uint4 v; asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(v.x), "=r"(v.y), "=r"(v.z), "=r"(v.w) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ float4 ldv(const float4* p) { float4 v; asm volatile("ld.global.cg.v4.f32 {%0,%1,%2,%3}, [%4];" : "=f"(v.x), "=f"(v.y), "=f"(v.z), "=f"(v.w) : "l"(p) : "memory"); return v; }
// weights: read once, kept out of L1 so that the activations stay there
__device__ __forceinline__ uint4 ldw(const uint4* p) { uint4 v; asm volatile("ld.global.cg.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(v.x), "=r"(v.y), "=r"(v.z), "=r"(v.w) : "l"(p)); return v; }

// W12 (track B): 12 bits per weight, [sign][exponent - lo + 1][7 mantissa bits]; lo is the tensor's exponent
// window (15 consecutive exponents). Two codes in the low 24 bits of x -> two bf16 in one register:
// bf16 = code + C + sign * 0x7800 with C = (lo - 1) << 7 (the add moves the sign from bit 11 to bit 15).
// Weights outside the window (and exact zeros) carry code 0 and are patched from a list (see gemm_stream).
__device__ __forceinline__ u32 dec2(u32 x, u32 C2) {
  const u32 t = (x & 0x00FFF000u) * 16u + (x & 0x00000FFFu);   // two codes in the two halves
  return (t & 0x08000800u) * 15u + t + C2;                     // sign bit 11 -> bit 15, exponent base added
}
// 96 bits = the 8 weights of one thread and k-step -> the four MMA operand registers
__device__ __forceinline__ uint4 dec8(u32 u0, u32 u1, u32 u2, u32 C2) {
  return make_uint4(dec2(u0, C2), dec2((u0 >> 24) | (u1 << 8), C2), dec2((u1 >> 16) | (u2 << 16), C2), dec2(u2 >> 8, C2));
}
__device__ __forceinline__ void w12_patch(uint4& r, u32 reg, u32 mk, u32 vv) {
  if (reg < 2) { if (reg == 0) r.x = (r.x & mk) | vv; else r.y = (r.y & mk) | vv; }
  else { if (reg == 2) r.z = (r.z & mk) | vv; else r.w = (r.w & mk) | vv; }
}
__device__ __forceinline__ void mma(float* c, const uint4& a, const uint2& b) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n"
               : "+f"(c[0]), "+f"(c[1]), "+f"(c[2]), "+f"(c[3])
               : "r"(a.x), "r"(a.y), "r"(a.z), "r"(a.w), "r"(b.x), "r"(b.y));
}
// index (in u16 units) of element (column c, input k) in an x-fragment buffer (B operand of m16n8k16)
__device__ __forceinline__ size_t xf_idx(int c, int k, int NG) {
  int s = k >> 4, r = k & 15;
  int t = (r & 7) >> 1, half = r & 1, reg = r >> 3;
  int lane = (c & 7) * 4 + t;
  return ((size_t)(s * NG + (c >> 3)) * 32 + lane) * 4 + reg * 2 + half;
}
// index (u16 units) of element (row r of 16, col kk of 16) inside one 512-byte A-operand tile
__device__ __forceinline__ int af_idx(int r, int kk) {
  int lane = (r & 7) * 4 + ((kk & 7) >> 1);
  return lane * 8 + ((r >> 3) + 2 * (kk >> 3)) * 2 + (kk & 1);
}
__device__ __forceinline__ float warp_sum(float v) {
  v += __shfl_xor_sync(0xffffffffu, v, 16);
  v += __shfl_xor_sync(0xffffffffu, v, 8);
  v += __shfl_xor_sync(0xffffffffu, v, 4);
  v += __shfl_xor_sync(0xffffffffu, v, 2);
  v += __shfl_xor_sync(0xffffffffu, v, 1);
  return v;
}
// Grid-wide barrier; it also brings the next op into shared memory. The wait reads the counter with a volatile
// load: a spin on ld.global(.cg/.cv) never sees it change (bench/bar.cu). 0.8 us with 152 blocks.
// Release/acquire at GPU scope (PTX memory model): the arrival is a release add (cumulative over the block's stores,
// which __syncthreads orders before it), the wait an acquire load, so stores before the barrier are visible after it.
__device__ __forceinline__ void red_release(u64* p, u64 v) { asm volatile("red.release.gpu.global.add.u64 [%0], %1;" :: "l"(p), "l"(v) : "memory"); }
__device__ __forceinline__ u64 ld_acquire(const u64* p) { u64 v; asm volatile("ld.acquire.gpu.global.u64 %0, [%1];" : "=l"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ int atom_add_acqrel(int* p, int v) { int r; asm volatile("atom.acq_rel.gpu.global.add.s32 %0, [%1], %2;" : "=r"(r) : "l"(p), "r"(v) : "memory"); return r; }
__device__ __forceinline__ void barrier(const long long* prog, int o, int nops) {
  extern __shared__ float sm[];
  __syncthreads();
  if (threadIdx.x == 32) {
    // While this block waits for the others (and while the small ops that follow run), DRAM would idle: ask L2 to
    // fetch the start of this block's share of the next weight matrix (the host chose the size per op).
    const Ctx& cx = CX();
    if (cx.pft) {
      const long long* e = cx.pft + ((size_t)o * cx.nblocks + blockIdx.x) * 2;
      const unsigned long long addr = (unsigned long long)e[0];
      long long left = e[1];
      for (unsigned long long a = addr; left > 0; a += 65536, left -= 65536) {
        const unsigned n = left < 65536 ? (unsigned)left : 65536u;
        asm volatile("cp.async.bulk.prefetch.L2.global [%0], %1;" :: "l"(a), "r"(n) : "memory");
      }
    }
  }
  if (threadIdx.x == 0) {
    const Ctx& cx = CX();
    u64* bar = cx.bar;
    const u64 target = cx.bar_base + (u64)(o + 1) * (u64)cx.nblocks;
#ifdef NO_FENCE
    atomicAdd(bar, 1ull);
    while (*(volatile u64*)bar < target) {}
#else
    red_release(bar, 1ull);
    while (ld_acquire(bar) < target) {
#ifdef BAR_SLEEP_NS
      { unsigned ns = BAR_SLEEP_NS; asm volatile("nanosleep.u32 %0;" :: "r"(ns)); }
#endif
    }
    if (cx.ts && blockIdx.x == 0) { unsigned long long t; asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(t)); cx.ts[o] = t; }
#endif
  } else if (threadIdx.x <= 20 && o + 1 < nops) {
    ((long long*)sm + CTX_WORDS)[threadIdx.x - 1] = prog[(size_t)(o + 1) * 20 + threadIdx.x - 1];
  }
  __syncthreads();
}

// ------------------------------------------------------------------------------------------------ GEMM
// Tile sums live in shared memory (tried in a per-block global scratch area to leave L1 larger: no gain in the
// stream, slower epilogues; see journal).
// What happens to the 16 x 8 results of a tile (per column group), read from shared-memory slot `sidx`.
template <int NGT>
__device__ __noinline__ void epilogue(int T, int sidx) {
  extern __shared__ float sm[];
  const Ctx& cx = CX(); const Op& op = OP();
  const float* smr = sm + SMR_OFF;
  const float4* ps = (const float4*)(sm + WORK_OFF);
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const int NC = cx.NC, ep = (int)op.ep;
  const bool use_r = op.use_r != 0;
  #pragma unroll
  for (int cg = 0; cg < NGT; ++cg) {
    const int cb = cg * 8 + 2 * t;
    float r0 = 1.0f, r1 = 1.0f;
    if (use_r) { r0 = smr[cb]; r1 = smr[cb + 1]; }
    const float4 cc = ps[sidx + cg * 32];
    const float v00 = cc.x * r0, v01 = cc.y * r1, v10 = cc.z * r0, v11 = cc.w * r1;
    if (ep == EP_STORE) {
      u16* out = (u16*)op.out;
      const int row0 = T * 16 + g, row1 = row0 + 8;
      if (cb < NC) { out[(size_t)cb * MROW + row0] = f2bf(v00); out[(size_t)cb * MROW + row1] = f2bf(v10); }
      if (cb + 1 < NC) { out[(size_t)(cb + 1) * MROW + row0] = f2bf(v01); out[(size_t)(cb + 1) * MROW + row1] = f2bf(v11); }
    } else if (ep == EP_RESID || ep == EP_SET) {
      const int row0 = T * 16 + g, row1 = row0 + 8;
      const float* gn = (const float*)op.gnext;
      u16* xn = (u16*)op.out;   // the next matrix's x fragments: bf16(h (1+w)), r is applied after that GEMM
      const float g0 = gn[row0], g1 = gn[row1];
      u16* hp0 = cx.h + (size_t)cb * HID;
      u16* hp1 = hp0 + HID;
      u16 o00 = 0, o10 = 0, o01 = 0, o11 = 0;
      if (ep == EP_RESID) {
        if (cb < NC) { o00 = ldv(hp0 + row0); o10 = ldv(hp0 + row1); }
        if (cb + 1 < NC) { o01 = ldv(hp1 + row0); o11 = ldv(hp1 + row1); }
      }
      float s0 = 0.f, s1 = 0.f;
      if (cb < NC) {
        const float a = rbf(bf2f(o00) + rbf(v00)), b = rbf(bf2f(o10) + rbf(v10));
        hp0[row0] = f2bf(a); hp0[row1] = f2bf(b);
        xn[xf_idx(cb, row0, NGT)] = f2bf(a * g0);
        xn[xf_idx(cb, row1, NGT)] = f2bf(b * g1);
        s0 = a * a + b * b;
      }
      if (cb + 1 < NC) {
        const float a = rbf(bf2f(o01) + rbf(v01)), b = rbf(bf2f(o11) + rbf(v11));
        hp1[row0] = f2bf(a); hp1[row1] = f2bf(b);
        xn[xf_idx(cb + 1, row0, NGT)] = f2bf(a * g0);
        xn[xf_idx(cb + 1, row1, NGT)] = f2bf(b * g1);
        s1 = a * a + b * b;
      }
      s0 += __shfl_xor_sync(0xffffffffu, s0, 4);  s1 += __shfl_xor_sync(0xffffffffu, s1, 4);
      s0 += __shfl_xor_sync(0xffffffffu, s0, 8);  s1 += __shfl_xor_sync(0xffffffffu, s1, 8);
      s0 += __shfl_xor_sync(0xffffffffu, s0, 16); s1 += __shfl_xor_sync(0xffffffffu, s1, 16);
      if (g == 0) {
        if (cb < NC) cx.ssq[(size_t)T * NCM + cb] = s0;
        if (cb + 1 < NC) cx.ssq[(size_t)T * NCM + cb + 1] = s1;
      }
    } else if (ep == EP_GATEUP) {
      u16* out = (u16*)op.out;
      const int n = T * 8 + g;
      if (cb < NC) out[xf_idx(cb, n, NGT)] = f2bf(rbf(siluf_(rbf(v00))) * rbf(v10));
      if (cb + 1 < NC) out[xf_idx(cb + 1, n, NGT)] = f2bf(rbf(siluf_(rbf(v01))) * rbf(v11));
    } else {  // EP_LOGITS
      const int row0 = T * 16 + g, row1 = row0 + 8;
      const u16 b00 = f2bf(v00), b01 = f2bf(v01), b10 = f2bf(v10), b11 = f2bf(v11);
      if ((cx.flags & F_LOGITS) && op.i6) {
        if (cb < NC) { cx.logits[(size_t)cb * VOCAB + row0] = b00; cx.logits[(size_t)cb * VOCAB + row1] = b10; }
        if (cb + 1 < NC) { cx.logits[(size_t)(cb + 1) * VOCAB + row0] = b01; cx.logits[(size_t)(cb + 1) * VOCAB + row1] = b11; }
      }
      float m0 = bf2f(b00), m1 = bf2f(b01); int i0 = row0, i1 = row0;
      { float x = bf2f(b10); if (x > m0) { m0 = x; i0 = row1; } }
      { float x = bf2f(b11); if (x > m1) { m1 = x; i1 = row1; } }
      #pragma unroll
      for (int sh = 4; sh <= 16; sh <<= 1) {
        float om0 = __shfl_xor_sync(0xffffffffu, m0, sh), om1 = __shfl_xor_sync(0xffffffffu, m1, sh);
        int oi0 = __shfl_xor_sync(0xffffffffu, i0, sh), oi1 = __shfl_xor_sync(0xffffffffu, i1, sh);
        if (om0 > m0 || (om0 == m0 && oi0 < i0)) { m0 = om0; i0 = oi0; }
        if (om1 > m1 || (om1 == m1 && oi1 < i1)) { m1 = om1; i1 = oi1; }
      }
      if (g == 0) {
        if (cb < NC) { cx.amax_val[(size_t)T * NCM + cb] = m0; cx.amax_idx[(size_t)T * NCM + cb] = i0; }
        if (cb + 1 < NC) { cx.amax_val[(size_t)T * NCM + cb + 1] = m1; cx.amax_idx[(size_t)T * NCM + cb + 1] = i1; }
      }
    }
  }
}

// A tile cut by warp boundaries, put together by the warp of this block that holds its last piece: the pieces
// inside the block through shared memory in warp order; if the tile is also cut by a block boundary, one partial
// per block through global memory, summed in block order by the block that arrives last (a counter per tile).
template <int NGT>
__device__ __noinline__ void finalize(int T, int myslot) {
  extern __shared__ float sm[];
  const Ctx& cx = CX(); const Op& op = OP();
  const int lane = threadIdx.x & 31, wib = threadIdx.x >> 5, bl = blockIdx.x;
  const int* tab = (const int*)op.p4 + bl * 32;
  const int KQ = (int)op.KQ;
  float4* ps = (float4*)(sm + WORK_OFF);
  const int own = (wib * 2) * NGT * 32 + lane;
  int x = wib;
  while (x > 0 && tab[x] > T * KQ) --x;   // the first warp of this block with a piece of T
  #pragma unroll
  for (int cg = 0; cg < NGT; ++cg) {
    float s0 = 0.f, s1 = 0.f, s2 = 0.f, s3 = 0.f;
    for (int i = x; i < wib; ++i) {
      const float4 v = ps[((i * 2 + 1) * NGT + cg) * 32 + lane];
      s0 += v.x; s1 += v.y; s2 += v.z; s3 += v.w;
    }
    const float4 v = ps[own + (myslot * NGT + cg) * 32];
    ps[own + (myslot * NGT + cg) * 32] = make_float4(s0 + v.x, s1 + v.y, s2 + v.z, s3 + v.w);
  }
  if (T * KQ >= tab[0] && (T + 1) * KQ <= tab[32]) { epilogue<NGT>(T, own + myslot * NGT * 32); return; }
  #pragma unroll
  for (int cg = 0; cg < NGT; ++cg) cx.part[((size_t)(T + bl) * NGT + cg) * 32 + lane] = ps[own + (myslot * NGT + cg) * 32];
  const int tb = ((const int*)op.p5)[T];
  const int bf = tb & 0xffff, bla = tb >> 16;
  __syncwarp();   // the warp's partial stores are ordered before lane 0's release
  int old = 0;
  if (lane == 0) old = atom_add_acqrel(cx.cnt + T, 1);
  old = __shfl_sync(0xffffffffu, old, 0);
  __syncwarp();   // ... and lane 0's acquire before the warp's loads of the other blocks' partials
  if (old + 1 != bla - bf + 1) return;
  #pragma unroll
  for (int cg = 0; cg < NGT; ++cg) {
    float s0 = 0.f, s1 = 0.f, s2 = 0.f, s3 = 0.f;
    for (int b = bf; b <= bla; b += 4) {   // 4 loads in flight, summed in block order
      float4 v[4];
      #pragma unroll
      for (int u = 0; u < 4; ++u)
        if (b + u <= bla) v[u] = ldv(cx.part + ((size_t)(T + b + u) * NGT + cg) * 32 + lane);
      #pragma unroll
      for (int u = 0; u < 4; ++u)
        if (b + u <= bla) { s0 += v[u].x; s1 += v[u].y; s2 += v[u].z; s3 += v[u].w; }
    }
    ps[own + (myslot * NGT + cg) * 32] = make_float4(s0, s1, s2, s3);
  }
  if (lane == 0) cx.cnt[T] = 0;
  epilogue<NGT>(T, own + myslot * NGT * 32);
}

// One GEMM for one warp: its share [q0, q1) of the matrix (quads of 4 k-steps, tile-major) in one loop, 4 weight
// loads of 16 bytes per thread in flight, one MMA per k-step and column group. The loop is not unrolled (64
// registers). At a tile boundary the sums go to a shared-memory slot and the loop goes on.
template <int NGT, bool W12>
__device__ __noinline__ void gemm_stream() {
  extern __shared__ float sm[];
  const Ctx& cx = CX(); const Op& op = OP();
  const int lane = threadIdx.x & 31, wib = threadIdx.x >> 5;
  const int w = blockIdx.x * 32 + wib;
  const int* tab = (const int*)op.p4;
  const int KQ = (int)op.KQ;
  const int q0 = tab[w], q1 = tab[w + 1];
  const int flags = cx.flags;
  float4* ps = (float4*)(sm + WORK_OFF);
  const int own = (wib * 2) * NGT * 32 + lane;   // slot 0: first cut piece; slot 1: scratch for whole tiles, then the last cut piece
  if (!(flags & 8)) {
    int T = q0 / KQ;
    int left = KQ - (q0 - T * KQ);
    bool whole = (left == KQ);
    const uint4* wp = (const uint4*)op.W + (size_t)q0 * (W12 ? 96 : 128) + lane;
    const uint2* xb = (const uint2*)op.xf + lane;
    const uint2* xp = xb + (KQ - left) * 4 * NGT * 32;
    // W12: the next out-of-window weight of this warp's share, [quad in share][lane][k-step][slot] and its bf16 bits
    const u32 C2 = (u32)op.i7;
    // The warp's list is loaded once, one entry per lane (all lists end with an all-ones sentinel), and walked
    // with shuffles: a dependent global load per patch cost ~3 us under full load (bench/lat.cu).
    const uint2* ep = W12 ? (const uint2*)op.p7 + ((const int*)op.p6)[w] : (const uint2*)0;
    uint2 eL = make_uint2(0xFFFFFFFFu, 0);
    int ek = 0;
    u32 epos = 0xFFFFFFFFu, eval_ = 0;
    if (W12 && !(flags & 2048)) {   // debug 2048: no patches
      eL = ep[lane];
      epos = __shfl_sync(0xffffffffu, eL.x, 0); eval_ = __shfl_sync(0xffffffffu, eL.y, 0);
    }
    float a_[NGT][4];
    #pragma unroll
    for (int cg = 0; cg < NGT; ++cg) { a_[cg][0] = 0.f; a_[cg][1] = 0.f; a_[cg][2] = 0.f; a_[cg][3] = 0.f; }
    #pragma unroll 1
    for (int q = q0; q < q1; ++q) {
      if (!W12) {
        const uint4 a0 = ldw(wp), a1 = ldw(wp + 32), a2 = ldw(wp + 64), a3 = ldw(wp + 96);
        if (NGT <= 2) {
          #pragma unroll
          for (int cg = 0; cg < NGT; ++cg) {
            const uint2 b0 = xp[(0 * NGT + cg) * 32], b1 = xp[(1 * NGT + cg) * 32], b2 = xp[(2 * NGT + cg) * 32], b3 = xp[(3 * NGT + cg) * 32];
            mma(a_[cg], a0, b0); mma(a_[cg], a1, b1); mma(a_[cg], a2, b2); mma(a_[cg], a3, b3);
          }
        } else {   // 32 columns: k-step by k-step, so that at most one k-step of activations is live (fewer spills)
          #pragma unroll
          for (int ks = 0; ks < 4; ++ks) {
            const uint4 a = ks == 0 ? a0 : ks == 1 ? a1 : ks == 2 ? a2 : a3;
            uint2 b[NGT];
            #pragma unroll
            for (int cg = 0; cg < NGT; ++cg) b[cg] = xp[(ks * NGT + cg) * 32];
            #pragma unroll
            for (int cg = 0; cg < NGT; ++cg) mma(a_[cg], a, b[cg]);
          }
        }
        wp += 128;
      } else {
        const uint4 p0 = ldw(wp), p1 = ldw(wp + 32), p2 = ldw(wp + 64);   // 48 bytes: 32 weights of this thread
        uint2 xb_[NGT <= 2 ? 4 * NGT : 1];
        if (NGT <= 2) {
          #pragma unroll
          for (int i = 0; i < 4 * NGT; ++i) xb_[i] = xp[i * 32];
        }
        uint4 r0 = dec8(p0.x, p0.y, p0.z, C2), r1 = dec8(p0.w, p1.x, p1.y, C2);
        uint4 r2 = dec8(p1.z, p1.w, p2.x, C2), r3 = dec8(p2.y, p2.z, p2.w, C2);
        if ((epos >> 10) == (u32)(q - q0)) {            // rare: this quad has out-of-window weights (same test in every lane)
          do {
            if (((epos >> 5) & 31u) == (u32)lane) {
              const u32 sh = (epos & 1u) << 4;
              const u32 mk = ~(0xFFFFu << sh), vv = eval_ << sh, reg = (epos >> 1) & 3u, ks = (epos >> 3) & 3u;
              if (ks < 2) { if (ks == 0) w12_patch(r0, reg, mk, vv); else w12_patch(r1, reg, mk, vv); }
              else { if (ks == 2) w12_patch(r2, reg, mk, vv); else w12_patch(r3, reg, mk, vv); }
            }
            if (++ek == 32) { ep += 32; ek = 0; eL = ep[lane]; }   // a list longer than 32 (rare): the next 32
            epos = __shfl_sync(0xffffffffu, eL.x, ek); eval_ = __shfl_sync(0xffffffffu, eL.y, ek);
          } while ((epos >> 10) == (u32)(q - q0));
        }
        #pragma unroll
        for (int cg = 0; cg < NGT; ++cg) {
          if (NGT <= 2) {
            mma(a_[cg], r0, xb_[0 * NGT + cg]); mma(a_[cg], r1, xb_[1 * NGT + cg]);
            mma(a_[cg], r2, xb_[2 * NGT + cg]); mma(a_[cg], r3, xb_[3 * NGT + cg]);
          } else {
            mma(a_[cg], r0, xp[(0 * NGT + cg) * 32]); mma(a_[cg], r1, xp[(1 * NGT + cg) * 32]);
            mma(a_[cg], r2, xp[(2 * NGT + cg) * 32]); mma(a_[cg], r3, xp[(3 * NGT + cg) * 32]);
          }
        }
        wp += 96;
      }
      xp += 4 * NGT * 32;
      if (--left == 0) {   // end of a tile
        const int sl = whole ? 1 : 0;
        #pragma unroll
        for (int cg = 0; cg < NGT; ++cg) {
          ps[own + (sl * NGT + cg) * 32] = make_float4(a_[cg][0], a_[cg][1], a_[cg][2], a_[cg][3]);
          a_[cg][0] = 0.f; a_[cg][1] = 0.f; a_[cg][2] = 0.f; a_[cg][3] = 0.f;
        }
        if (whole && !(flags & 16)) epilogue<NGT>(T, own + 1 * NGT * 32);
        ++T; left = KQ; whole = true; xp = xb;
      }
    }
    if (left != KQ) {     // the share ends inside a tile
      #pragma unroll
      for (int cg = 0; cg < NGT; ++cg) ps[own + (1 * NGT + cg) * 32] = make_float4(a_[cg][0], a_[cg][1], a_[cg][2], a_[cg][3]);
    }
  }
  __syncthreads();
  if (flags & 24) return;   // debug: 8 = prologue and barrier only, 16 = stream only
  const int Ta = q0 / KQ;
  if (q0 > Ta * KQ && (Ta + 1) * KQ <= q1) finalize<NGT>(Ta, 0);
  const int Tb = (q1 - 1) / KQ;
  if (wib == 31 && q1 < (Tb + 1) * KQ) finalize<NGT>(Tb, 1);
}

__device__ __forceinline__ void gemm_phase() {
  extern __shared__ float sm[];
  const Ctx& cx = CX(); const Op& op = OP();
  if (op.use_r) {
    // r[c] = rsqrt(mean(h^2) + eps) from the per-tile partial sums of squares, the same in every block and for every
    // batch size: warp w sums tiles w, w + 32, ... (in that order) for all columns at once (lane = column, coalesced),
    // then warp c adds the 32 warp sums of column c with the butterfly of warp_sum.
    const int wi = threadIdx.x >> 5, ln = threadIdx.x & 31, NC = cx.NC;
    if (NC <= 4) {   // few columns: one warp per column, lane j sums tiles j, j + 32, ... (the same sums, the same order)
      if (wi < NC) {
        float v[10];
        #pragma unroll
        for (int i = 0; i < 10; ++i) v[i] = ldv(cx.ssq + (size_t)(ln + 32 * i) * NCM + wi);
        float s = 0.f;
        #pragma unroll
        for (int i = 0; i < 10; ++i) s += v[i];
        s = warp_sum(s);
        if (ln == 0) sm[SMR_OFF + wi] = rsqrtf(s * (1.0f / HID) + 1e-6f);
      }
      __syncthreads();
    } else {
    float* part = sm + WORK_OFF;   // [32 warps][32 columns]
    float v[10];
    #pragma unroll
    for (int i = 0; i < 10; ++i) v[i] = ln < NC ? ldv(cx.ssq + (size_t)(wi + 32 * i) * NCM + ln) : 0.f;
    float s = 0.f;
    #pragma unroll
    for (int i = 0; i < 10; ++i) s += v[i];
    part[wi * 32 + ln] = s;
    __syncthreads();
    if (wi < NC) {
      const float t = warp_sum(part[ln * 32 + wi]);
      if (ln == 0) sm[SMR_OFF + wi] = rsqrtf(t * (1.0f / HID) + 1e-6f);
    }
    __syncthreads();
    }
  }
  const int NG = cx.NG;
  if (op.i7 >> 32) {   // the matrix is stored in 12 bits per weight
    if (NG == 1) gemm_stream<1, true>();
    else if (NG == 2) gemm_stream<2, true>();
    else gemm_stream<4, true>();
  } else {
    if (NG == 1) gemm_stream<1, false>();
    else if (NG == 2) gemm_stream<2, false>();
    else gemm_stream<4, false>();
  }
}

// ------------------------------------------------------------------------------------------------ embedding
__device__ __noinline__ void embed_work() {
  const Ctx& cx = CX(); const Op& op = OP();
  const int lane = threadIdx.x & 31;
  const int w = blockIdx.x * 32 + (threadIdx.x >> 5);
  const u16* emb = (const u16*)op.W;
  const float* gn = (const float*)op.gnext;
  u16* xn = (u16*)op.out;
  const int nunits = cx.NC * 320;
  for (int u = w; u < nunits; u += cx.nwarps) {
    const int c = u / 320, tile = u % 320;
    float sq = 0.f;
    if (lane < 16) {
      const long long tok = cx.tok_in[(size_t)c * cx.tok_stride];
      const int row = tile * 16 + lane;
      const u16 e = emb[(size_t)tok * HID + row];
      const float f = bf2f(e);
      cx.h[(size_t)c * HID + row] = e;
      xn[xf_idx(c, row, cx.NG)] = f2bf(f * gn[row]);
      sq = f * f;
    }
    sq = warp_sum(sq);
    if (lane == 0) cx.ssq[(size_t)tile * NCM + c] = sq;
  }
}

// ------------------------------------------------------------------------------------------------ linear attention
__device__ __forceinline__ float lm_upd(float s, float d, float k, float dl) { return __fmaf_rn(s, d, __fmul_rn(k, dl)); }

// Gated delta rule, one (sequence, value head) per block. Thread (v, g) = (tid >> 3, tid & 7) keeps rows 16g..16g+15
// of column v of the 128 x 128 float32 state in registers; a warp holds 4 columns, so both reductions over k of a
// position (S^T k and S^T q) are 3 shuffles and the loop over the positions of a pass has no block barrier. The state
// is stored in this thread order ([warp][row i][lane]: coalesced). The update is rank 1 (S = d S + k (x) delta): a
// speculative pass leaves the stored state alone and saves (d, k, delta) per position; the next pass replays the
// accepted ones with the same lm_upd in the same order, so the committed state is bit-identical to stepping.
#define LKS 16                                   // a 16-row group of k or q; its 4 float4 chunks are XOR-swizzled by group
__device__ __forceinline__ int lsw(int g, int i) { return g * 16 + (((i >> 2) ^ ((g >> 1) & 3)) << 2) + (i & 3); }   // conflict-free LDS.128
// Shared-memory layout (floats from WORK_OFF) for at most PM positions; PM is a template parameter (8 or PMAX) so
// that the offsets are compile-time constants and a single step does not pay for the space of 32 positions
// (run-time offsets measured +0.13 ms per step; 84 KB of shared memory +0.15 ms).
#define LQ 0                                     // q [PM][8 * 16]
#define LK (LQ + PM * 8 * LKS)                   // k [PM][8 * 16]
#define LV (LK + PM * 8 * LKS)                   // v [PM][128]
#define LZ (LV + PM * 128)                       // z [PM][128]
#define LO (LZ + PM * 128)                       // core output [PM][128]
#define LS (LO + PM * 128)                       // (beta, decay) [PM][2]
#define LR (LS + 2 * PM)                         // reductions [PM][8] (at least 32)
#define LM_FLOATS(PM) (5 * (PM) * 128 + 10 * (PM) + 32)
__device__ __forceinline__ float grp8_sum(float x) {   // butterfly over the 8 lanes of a column: the same value in all 8
  x += __shfl_xor_sync(0xffffffffu, x, 1);
  x += __shfl_xor_sync(0xffffffffu, x, 2);
  x += __shfl_xor_sync(0xffffffffu, x, 4);
  return x;
}
template <int PM>
__device__ __noinline__ void lmix_work() {
  extern __shared__ float sm[];
  const Ctx& cx = CX(); const Op& op = OP();
  float* L = sm + WORK_OFF;
  const int tid = threadIdx.x, lane = tid & 31, wid = tid >> 5;
  const int g = tid & 7, v = tid >> 3;
  const int P = cx.P, NG = cx.NG;
  const bool spec = (cx.flags & F_SPEC) != 0;
  const float* negA = (const float*)op.p7; const float* dtb = (const float*)op.p8; const float* nwt = (const float*)op.p9;
  u16* xn = (u16*)op.xf;
  const int dbg = cx.flags;
  const int nunits = cx.B * 48;
  for (int u = blockIdx.x; u < nunits; u += cx.nblocks) {
    const int b = u / 48, hv = u % 48, hk = hv / 3;
    const int pos0 = ldv(cx.pos + b);
    const int na = spec ? ldv(cx.nacc + b) : 0;
    float* Sg = (float*)op.p4 + ((size_t)(b * 48 + hv) << 14) + (size_t)wid * 512 + lane;
    float* pk = (float*)op.p10 + (size_t)(b * 48 + hv) * PMAX * 128;
    float* pd = (float*)op.p11 + (size_t)(b * 48 + hv) * PMAX * 128;
    float* pdec = (float*)op.W + (size_t)(b * 48 + hv) * PMAX;
    // 1. the accepted updates of the previous pass (staged in the q and v areas) and the state
    for (int idx = tid; idx < na * 128; idx += 1024) {
      const int j = idx >> 7, k = idx & 127;
      L[LQ + j * 8 * LKS + lsw(k >> 4, k & 15)] = ldv(pk + idx);
      L[LV + idx] = ldv(pd + idx);
    }
    if (tid < na) L[LR + tid] = ldv(pdec + tid);
    float s[16];
    #pragma unroll
    for (int i = 0; i < 16; ++i) s[i] = (pos0 > 0 && !(dbg & 32)) ? ldv(Sg + i * 32) : 0.f;
    __syncthreads();
    for (int j = 0; j < na; ++j) {
      const float dj = L[LR + j], dv = L[LV + j * 128 + v];
      const float4* kk4 = (const float4*)(L + LQ + j * 8 * LKS);
      #pragma unroll
      for (int c = 0; c < 4; ++c) {
        const float4 k4 = kk4[g * 4 + (c ^ ((g >> 1) & 3))];
        s[4 * c] = lm_upd(s[4 * c], dj, k4.x, dv); s[4 * c + 1] = lm_upd(s[4 * c + 1], dj, k4.y, dv);
        s[4 * c + 2] = lm_upd(s[4 * c + 2], dj, k4.z, dv); s[4 * c + 3] = lm_upd(s[4 * c + 3], dj, k4.w, dv);
      }
    }
    if (na > 0) {
      #pragma unroll
      for (int i = 0; i < 16; ++i) Sg[i * 32] = s[i];
    }
    __syncthreads();
    // 2. conv + SiLU of q, k, v for every position, z, decay and beta; threads 0-511 even positions, 512-1023 odd
    {
      const int half = tid >> 9, role = (tid >> 7) & 3, j = tid & 127;
      const int ch = role == 0 ? hk * 128 + j : (role == 1 ? 2048 + hk * 128 + j : 4096 + hv * 128 + j);
      const bool wr = role == 2 || hv % 3 == 0;
      const float4 cw = role < 3 ? *((const float4*)op.p6 + ch) : make_float4(0.f, 0.f, 0.f, 0.f);
      u16* ring = (u16*)op.p5 + (size_t)b * RING * 10240 + ch;
      const u16* mb = cx.mbuf + (size_t)(b * P) * MROW;
      const int jx = lsw(j >> 4, j & 15);
      for (int p = half; p < P; p += 2) {
        const u16* m = mb + (size_t)p * MROW;
        float val = 0.f;
        if (role < 3) {
          u16 x[4];
          x[3] = ldv(m + ch);
          #pragma unroll
          for (int i = 1; i <= 3; ++i) {
            const int pp = p - i;
            u16 xv = 0;
            if (pp >= 0) xv = ldv(m - (size_t)i * MROW + ch);
            else if (pos0 + pp >= 0) xv = ldv(ring + (size_t)((pos0 + pp) & (RING - 1)) * 10240);
            x[3 - i] = xv;
          }
          if (wr) ring[(size_t)((pos0 + p) & (RING - 1)) * 10240] = x[3];
          float y = cw.w * bf2f(x[3]);
          y += cw.z * bf2f(x[2]);
          y += cw.y * bf2f(x[1]);
          y += cw.x * bf2f(x[0]);
          val = rbf(siluf_(rbf(y)));
          if (role == 0) L[LQ + p * 8 * LKS + jx] = val;
          else if (role == 1) L[LK + p * 8 * LKS + jx] = val;
          else L[LV + p * 128 + j] = val;
        } else {
          L[LZ + p * 128 + j] = bf2f(ldv(m + 10240 + hv * 128 + j));
          if (j == 0) {
            const u16 bb = ldv(m + 16384 + hv), ab = ldv(m + 16432 + hv);
            const float aa = bf2f(ab) + dtb[hv];
            const float sp = aa > 20.f ? aa : log1pf(__expf(aa));
            L[LS + p * 2] = rbf(sigmoidf_(bf2f(bb)));
            L[LS + p * 2 + 1] = __expf(negA[hv] * sp);
          }
        }
        const float ssum = warp_sum(val * val);
        if (lane == 0 && role < 2) L[LR + p * 8 + role * 4 + ((tid >> 5) & 3)] = ssum;
      }
      __syncthreads();
      if (role < 2) {   // L2-normalise q and k
        for (int p = half; p < P; p += 2) {
          const float* r2 = L + LR + p * 8 + role * 4;
          const float inv = rsqrtf((r2[0] + r2[1]) + (r2[2] + r2[3]) + 1e-6f);
          float* x = L + (role == 0 ? LQ : LK) + p * 8 * LKS + jx;
          const float nv = role == 0 ? *x * inv * 0.08838834764831845f : *x * inv;
          *x = nv;
          if (spec && role == 1) pk[p * 128 + j] = nv;
        }
      }
      __syncthreads();
    }
    if (dbg & 512) continue;   // debug: inputs only
    // 3. the recurrence over the positions of the pass: no block barrier
    const int sw = (g >> 1) & 3;
    for (int p = 0; p < P; ++p) {
      const float4* kp = (const float4*)(L + LK + p * 8 * LKS) + g * 4;
      const float4* qp = (const float4*)(L + LQ + p * 8 * LKS) + g * 4;
      const float beta = L[LS + p * 2], dec = L[LS + p * 2 + 1];
      float kr[16];
      #pragma unroll
      for (int c = 0; c < 4; ++c) { const float4 t = kp[c ^ sw]; kr[4 * c] = t.x; kr[4 * c + 1] = t.y; kr[4 * c + 2] = t.z; kr[4 * c + 3] = t.w; }
      float acc = 0.f;
      #pragma unroll
      for (int i = 0; i < 16; ++i) acc = __fmaf_rn(s[i], kr[i], acc);
      acc = grp8_sum(acc);
      const float d = (L[LV + p * 128 + v] - dec * acc) * beta;
      if (spec && g == 0) { pd[p * 128 + v] = d; if (v == 0) pdec[p] = dec; }
      float acc2 = 0.f;
      #pragma unroll
      for (int c = 0; c < 4; ++c) {
        const float4 q4 = qp[c ^ sw];
        s[4 * c] = lm_upd(s[4 * c], dec, kr[4 * c], d);         acc2 = __fmaf_rn(s[4 * c], q4.x, acc2);
        s[4 * c + 1] = lm_upd(s[4 * c + 1], dec, kr[4 * c + 1], d); acc2 = __fmaf_rn(s[4 * c + 1], q4.y, acc2);
        s[4 * c + 2] = lm_upd(s[4 * c + 2], dec, kr[4 * c + 2], d); acc2 = __fmaf_rn(s[4 * c + 2], q4.z, acc2);
        s[4 * c + 3] = lm_upd(s[4 * c + 3], dec, kr[4 * c + 3], d); acc2 = __fmaf_rn(s[4 * c + 3], q4.w, acc2);
      }
      acc2 = grp8_sum(acc2);
      if (g == 0) L[LO + p * 128 + v] = rbf(acc2);
    }
    if (!spec && !(dbg & 32)) {
      #pragma unroll
      for (int i = 0; i < 16; ++i) Sg[i * 32] = s[i];
    }
    __syncthreads();
    // 4. gated RMSNorm per position (8 positions per round) and the out_proj input
    for (int p0 = 0; p0 < P; p0 += 8) {
      const int p = p0 + (tid >> 7), vv = tid & 127;
      const float ob = p < P ? L[LO + p * 128 + vv] : 0.f;
      const float so = warp_sum(ob * ob);
      if (lane == 0) L[LR + wid] = so;
      __syncthreads();
      if (p < P) {
        const float* r2 = L + LR + (tid >> 7) * 4;
        const float rs = rsqrtf(((r2[0] + r2[1]) + (r2[2] + r2[3])) * (1.0f / 128.0f) + 1e-6f);
        const float n = rbf(ob * rs);
        const float mm = rbf(nwt[vv] * n);
        xn[xf_idx(b * P + p, hv * 128 + vv, NG)] = f2bf(mm * siluf_(L[LZ + p * 128 + vv]));
      }
      __syncthreads();
    }
  }
}

// ------------------------------------------------------------------------------------------------ full attention
// K cache: per (b, kv head): [key tile][16 ksteps][512 B] in A-operand order (rows = keys, cols = dims)
// V cache: per (b, kv head): [dim tile (16)][key group][512 B] in A-operand order (rows = dims, cols = keys)
__device__ __noinline__ void att_prep_work() {
  const Ctx& cx = CX(); const Op& op = OP();
  const int lane = threadIdx.x & 31;
  const int w = blockIdx.x * 32 + (threadIdx.x >> 5);
  const int nunits = cx.NC * 32, P = cx.P, NGq = cx.NGq, mc = cx.max_ctx;
  const float* gq = (const float*)op.p6; const float* gk = (const float*)op.p7;
  for (int u = w; u < nunits; u += cx.nwarps) {
    const int c = u >> 5, j = u & 31;
    const int b = c / P, p = c % P;
    const int Tpos = ldv(cx.pos + b) + cx.pos_off + p;
    const u16* m = cx.mbuf + (size_t)c * MROW;
    const int kind = j < 24 ? 0 : (j < 28 ? 1 : 2);
    const int hd = j < 24 ? j : (j - 24) & 3;
    const u16* src = m + (kind == 0 ? hd * 512 : (kind == 1 ? 12288 + hd * 256 : 13312 + hd * 256));
    u16 raw[8];
    #pragma unroll
    for (int e = 0; e < 8; ++e) raw[e] = ldv(src + lane + 32 * e);
    float x[8];
    float ss = 0.f;
    #pragma unroll
    for (int e = 0; e < 8; ++e) { x[e] = bf2f(raw[e]); ss += x[e] * x[e]; }
    ss = warp_sum(ss);
    if (kind < 2) {
      const float rs = rsqrtf(ss * (1.0f / 256.0f) + 1e-6f);
      const float* gg = kind == 0 ? gq : gk;
      #pragma unroll
      for (int e = 0; e < 8; ++e) x[e] = rbf(x[e] * rs * gg[lane + 32 * e]);
      const float cs = cx.rope_cos[(size_t)Tpos * 32 + lane], sn = cx.rope_sin[(size_t)Tpos * 32 + lane];
      const float x0 = rbf(rbf(x[0] * cs) + rbf(-x[1] * sn));
      const float x1 = rbf(rbf(x[1] * cs) + rbf(x[0] * sn));
      x[0] = x0; x[1] = x1;
    }
    if (kind == 0) {
      const int kh = hd / 6, qq = p * 6 + hd % 6;
      u16* qf = cx.qf + (size_t)(b * 4 + kh) * (16 * NGq * 128);
      #pragma unroll
      for (int e = 0; e < 8; ++e) qf[xf_idx(qq, lane + 32 * e, NGq)] = f2bf(x[e]);
    } else if (kind == 1) {
      u16* Kc = (u16*)op.p4 + (size_t)(b * 4 + hd) * mc * 256;
      const int kt = Tpos >> 4, r = Tpos & 15;
      #pragma unroll
      for (int e = 0; e < 8; ++e) { const int i = lane + 32 * e; Kc[((size_t)kt * 16 + (i >> 4)) * 256 + af_idx(r, i & 15)] = f2bf(x[e]); }
    } else {
      u16* Vc = (u16*)op.p5 + (size_t)(b * 4 + hd) * mc * 256;
      const int kg = Tpos >> 4, kk = Tpos & 15;
      #pragma unroll
      for (int e = 0; e < 8; ++e) { const int i = lane + 32 * e; Vc[((size_t)(i >> 4) * (mc >> 4) + kg) * 256 + af_idx(i & 15, kk)] = f2bf(x[e]); }
    }
  }
}

__device__ __noinline__ void att_score_work() {
  const Ctx& cx = CX(); const Op& op = OP();
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const int w = blockIdx.x * 32 + (threadIdx.x >> 5);
  const int P = cx.P, NGq = cx.NGq, mc = cx.max_ctx;
  const int nkt = (cx.pos_ub + P + 15) >> 4;
  const int nunits = cx.B * 4 * nkt;
  for (int u = w; u < nunits; u += cx.nwarps) {
    const int bk = u / nkt, kt = u % nkt, b = bk >> 2, kh = bk & 3;
    const int pos0 = ldv(cx.pos + b) + cx.pos_off;
    if (kt * 16 > pos0 + P - 1) continue;
    const uint4* Kc = (const uint4*)op.p4 + ((size_t)bk * mc * 256 + (size_t)kt * 16 * 256) / 8 + lane;
    const uint2* qf = (const uint2*)cx.qf + (size_t)bk * (16 * NGq * 32) + lane;
    for (int cg = 0; cg < NGq; ++cg) {
      float c[4] = {0.f, 0.f, 0.f, 0.f};
      #pragma unroll
      for (int s0 = 0; s0 < 16; s0 += 4) {
        uint4 a[4]; uint2 bb[4];
        #pragma unroll
        for (int s = 0; s < 4; ++s) { a[s] = ldv(Kc + (s0 + s) * 32); bb[s] = ldv(qf + ((s0 + s) * NGq + cg) * 32); }
        #pragma unroll
        for (int s = 0; s < 4; ++s) mma(c, a[s], bb[s]);
      }
      #pragma unroll
      for (int i = 0; i < 2; ++i) {
        const int qq = cg * 8 + 2 * t + i;
        if (qq < 6 * P) {
          const int p = qq / 6, hh = qq % 6;
          float* sc = cx.sc + ((size_t)(b * 24 + kh * 6 + hh) * P + p) * mc + kt * 16 + g;
          sc[0] = c[i] * 0.0625f;
          sc[8] = c[2 + i] * 0.0625f;
        }
      }
    }
  }
}

__device__ __noinline__ void att_softmax_work() {
  const Ctx& cx = CX();
  const int lane = threadIdx.x & 31;
  const int w = blockIdx.x * 32 + (threadIdx.x >> 5);
  const int P = cx.P, NGq = cx.NGq, mc = cx.max_ctx;
  const int nunits = cx.B * 24 * P;
  for (int u = w; u < nunits; u += cx.nwarps) {
    const int p = u % P, bh = u / P, b = bh / 24, h = bh % 24, kh = h / 6, hh = h % 6;
    const int pos0 = ldv(cx.pos + b) + cx.pos_off;
    const int n = pos0 + p + 1, nend = ((pos0 + P + 15) >> 4) << 4;
    const float* sc = cx.sc + (size_t)u * mc;
    u16* pf = cx.pf + (size_t)(b * 4 + kh) * ((mc >> 4) * NGq * 128);
    const int qq = p * 6 + hh;
    // pass 1: max, 8 loads in flight
    float mx = -3.0e38f;
    for (int j = lane; j < n; j += 256) {
      float v[8];
      #pragma unroll
      for (int e = 0; e < 8; ++e) v[e] = (j + 32 * e < n) ? ldv(sc + j + 32 * e) : -3.0e38f;
      #pragma unroll
      for (int e = 0; e < 8; ++e) mx = fmaxf(mx, v[e]);
    }
    #pragma unroll
    for (int sh = 16; sh >= 1; sh >>= 1) mx = fmaxf(mx, __shfl_xor_sync(0xffffffffu, mx, sh));
    // pass 2: sum of exp (per lane in key order, then the fixed lane tree)
    float sum = 0.f;
    for (int j = lane; j < n; j += 256) {
      float v[8];
      #pragma unroll
      for (int e = 0; e < 8; ++e) v[e] = (j + 32 * e < n) ? ldv(sc + j + 32 * e) : -3.0e38f;
      #pragma unroll
      for (int e = 0; e < 8; ++e) if (j + 32 * e < n) sum += __expf(v[e] - mx);
    }
    sum = warp_sum(sum);
    const float inv = 1.0f / sum;
    // pass 3: probabilities in bf16, zeros for the keys this position must not see
    for (int j = lane; j < nend; j += 256) {
      float v[8];
      #pragma unroll
      for (int e = 0; e < 8; ++e) v[e] = (j + 32 * e < n) ? ldv(sc + j + 32 * e) : -3.0e38f;
      #pragma unroll
      for (int e = 0; e < 8; ++e)
        if (j + 32 * e < nend) pf[xf_idx(qq, j + 32 * e, NGq)] = (j + 32 * e < n) ? f2bf(__expf(v[e] - mx) * inv) : (u16)0;
    }
  }
}

__device__ __noinline__ void att_vsum_work() {
  const Ctx& cx = CX(); const Op& op = OP();
  const int lane = threadIdx.x & 31;
  const int w = blockIdx.x * 32 + (threadIdx.x >> 5);
  const int P = cx.P, NGq = cx.NGq, mc = cx.max_ctx;
  const int nch = (cx.pos_ub + P + 255) >> 8;
  const int nunits = cx.B * 4 * 16 * nch;
  for (int u = w; u < nunits; u += cx.nwarps) {
    const int ch = u % nch, r = u / nch, dt = r & 15, bk = r >> 4, b = bk >> 2;
    const int pos0 = ldv(cx.pos + b) + cx.pos_off;
    if (ch * 256 > pos0 + P - 1) continue;
    const int nkg = (pos0 + P + 15) >> 4;
    const uint4* Vc = (const uint4*)op.p5 + ((size_t)bk * mc * 256 + ((size_t)dt * (mc >> 4) + ch * 16) * 256) / 8 + lane;
    const uint2* pf = (const uint2*)cx.pf + (size_t)bk * ((mc >> 4) * NGq * 32) + (size_t)ch * 16 * NGq * 32 + lane;
    for (int cg = 0; cg < NGq; ++cg) {
      float c[4] = {0.f, 0.f, 0.f, 0.f};
      for (int s0 = 0; s0 < 16 && ch * 16 + s0 < nkg; s0 += 4) {
        uint4 a[4]; uint2 bb[4];
        #pragma unroll
        for (int s = 0; s < 4; ++s) {
          const bool on = ch * 16 + s0 + s < nkg;
          a[s] = on ? ldv(Vc + (s0 + s) * 32) : make_uint4(0, 0, 0, 0);
          bb[s] = on ? ldv(pf + ((s0 + s) * NGq + cg) * 32) : make_uint2(0, 0);
        }
        #pragma unroll
        for (int s = 0; s < 4; ++s) mma(c, a[s], bb[s]);
      }
      cx.vpart[(((size_t)r * (mc >> 8) + ch) * NGq + cg) * 32 + lane] = make_float4(c[0], c[1], c[2], c[3]);
    }
  }
}

__device__ __noinline__ void att_out_work() {
  const Ctx& cx = CX(); const Op& op = OP();
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const int w = blockIdx.x * 32 + (threadIdx.x >> 5);
  const int P = cx.P, NGq = cx.NGq, mc = cx.max_ctx;
  const int nunits = cx.B * 4 * 16;
  u16* xn = (u16*)op.xf;
  for (int u = w; u < nunits; u += cx.nwarps) {
    const int dt = u & 15, bk = u >> 4, b = bk >> 2, kh = bk & 3;
    const int pos0 = ldv(cx.pos + b) + cx.pos_off;
    const int nchb = (pos0 + P + 255) >> 8;
    for (int cg = 0; cg < NGq; ++cg) {
      float c[4] = {0.f, 0.f, 0.f, 0.f};
      for (int ch = 0; ch < nchb; ch += 4) {
        float4 v[4];
        #pragma unroll
        for (int e = 0; e < 4; ++e)
          if (ch + e < nchb) v[e] = ldv(cx.vpart + (((size_t)u * (mc >> 8) + ch + e) * NGq + cg) * 32 + lane);
        #pragma unroll
        for (int e = 0; e < 4; ++e)
          if (ch + e < nchb) { c[0] += v[e].x; c[1] += v[e].y; c[2] += v[e].z; c[3] += v[e].w; }
      }
      #pragma unroll
      for (int i = 0; i < 2; ++i) {
        const int qq = cg * 8 + 2 * t + i;
        if (qq < 6 * P) {
          const int p = qq / 6, h = kh * 6 + qq % 6, col = b * P + p;
          const u16* m = cx.mbuf + (size_t)col * MROW + h * 512 + 256;
          const int d0 = dt * 16 + g, d1 = d0 + 8;
          const u16 g0 = ldv(m + d0), g1 = ldv(m + d1);
          xn[xf_idx(col, h * 256 + d0, cx.NG)] = f2bf(rbf(c[i]) * rbf(sigmoidf_(bf2f(g0))));
          xn[xf_idx(col, h * 256 + d1, cx.NG)] = f2bf(rbf(c[2 + i]) * rbf(sigmoidf_(bf2f(g1))));
        }
      }
    }
  }
}

// ------------------------------------------------------------------------------------------------ argmax, finish
__device__ __noinline__ void argmax_work() {
  extern __shared__ float sm[];
  const Ctx& cx = CX(); const Op& op = OP();
  const int col = blockIdx.x, tid = threadIdx.x, lane = tid & 31, wib = tid >> 5;
  const int NT = (int)op.NT;
  int* dst = (int*)op.out;
  float* smv = sm + WORK_OFF;
  int* smi = (int*)(sm + WORK_OFF + 64);
  float m = -3.0e38f; int idx = 0x7fffffff;
  #pragma unroll
  for (int e0 = 0; e0 < 16; e0 += 8) {
    float v[8]; int ix[8];
    #pragma unroll
    for (int e = 0; e < 8; ++e) {
      const int T = tid + 1024 * (e0 + e);
      v[e] = -3.0e38f; ix[e] = 0x7fffffff;
      if (T < NT) { v[e] = ldv(cx.amax_val + (size_t)T * NCM + col); ix[e] = ldv(cx.amax_idx + (size_t)T * NCM + col); }
    }
    #pragma unroll
    for (int e = 0; e < 8; ++e) if (v[e] > m || (v[e] == m && ix[e] < idx)) { m = v[e]; idx = ix[e]; }
  }
  #pragma unroll
  for (int sh = 16; sh >= 1; sh >>= 1) {
    const float om = __shfl_xor_sync(0xffffffffu, m, sh); const int oi = __shfl_xor_sync(0xffffffffu, idx, sh);
    if (om > m || (om == m && oi < idx)) { m = om; idx = oi; }
  }
  if (lane == 0) { smv[wib] = m; smi[wib] = idx; }
  __syncthreads();
  if (wib == 0) {
    m = smv[lane]; idx = smi[lane];
    #pragma unroll
    for (int sh = 16; sh >= 1; sh >>= 1) {
      const float om = __shfl_xor_sync(0xffffffffu, m, sh); const int oi = __shfl_xor_sync(0xffffffffu, idx, sh);
      if (om > m || (om == m && oi < idx)) { m = om; idx = oi; }
    }
    if (lane == 0) dst[col] = idx;
  }
  __syncthreads();
}

__device__ __noinline__ void finish_work() {
  const Ctx& cx = CX(); const Op& op = OP();
  const int b = blockIdx.x, P = cx.P;
  if (op.i6) {  // the head ran: publish the chosen tokens
    for (int p = 0; p < P; ++p) {
      const long long tk = ldv(cx.tok_res + b * P + p);
      if (cx.tok_out) cx.tok_out[b * P + p] = tk;
      if ((cx.flags & F_FEEDBACK) && p == P - 1) cx.tokbuf[b] = tk;
    }
  }
  cx.pos[b] = ldv(cx.pos + b) + P;
}

// ------------------------------------------------------------------------------------------------ MTP drafter
// Input of mtp.fc for column c: cat[rms(embed(token), pre_fc_norm_embedding), rms(hidden, pre_fc_norm_hidden)],
// hidden = the post-norm output of the pass that ran before: r * bf16(h (1+w)), from that pass's last x buffer
// (op.p5) and the partial sums of squares.
__device__ __noinline__ void mtp_in_work() {
  extern __shared__ float sm[];
  const Ctx& cx = CX(); const Op& op = OP();
  const int c = blockIdx.x, tid = threadIdx.x, lane = tid & 31, wib = tid >> 5;
  const int P = cx.P, b = c / P, p = c % P;
  float* w0 = sm + WORK_OFF;
  int na = ldv(cx.nacc + b); if (na < 1) na = 1;
  const int cs = cx.src_sel ? b * cx.src_P + (na - 1) : b * cx.src_P + p;
  long long tok;
  if (op.i6 == 0) tok = ldv(cx.tok_res + c);
  else if (op.i6 == 1) tok = cx.tokbuf[b * (int)op.M + op.i7];
  else tok = cx.tok_next[(size_t)c * cx.tok_stride];
  const u16* emb = (const u16*)op.W + (size_t)tok * HID;
  const float* ge = (const float*)op.gnext; const float* gh = (const float*)op.p4;
  const u16* src = (const u16*)op.p5;
  u16* out = (u16*)op.out;
  // r of the source column, summed exactly as the GEMM prologue does
  if (wib == 0) {
    float v[10];
    #pragma unroll
    for (int i = 0; i < 10; ++i) v[i] = ldv(cx.ssq + (size_t)(lane + 32 * i) * NCM + cs);
    float s = 0.f;
    #pragma unroll
    for (int i = 0; i < 10; ++i) s += v[i];
    s = warp_sum(s);
    if (lane == 0) w0[0] = rsqrtf(s * (1.0f / HID) + 1e-6f);
  }
  u16 xr[5]; float e[5], hn[5];
  #pragma unroll
  for (int i = 0; i < 5; ++i) xr[i] = ldv(src + xf_idx(cs, tid + 1024 * i, cx.src_NG));
  __syncthreads();
  const float r = w0[0];
  float se = 0.f, sh = 0.f;
  #pragma unroll
  for (int i = 0; i < 5; ++i) {
    e[i] = bf2f(emb[tid + 1024 * i]); hn[i] = rbf(r * bf2f(xr[i]));
    se += e[i] * e[i]; sh += hn[i] * hn[i];
  }
  se = warp_sum(se); sh = warp_sum(sh);
  if (lane == 0) { w0[64 + wib] = se; w0[128 + wib] = sh; }
  __syncthreads();
  if (wib == 0) {
    const float a = warp_sum(w0[64 + lane]), bq = warp_sum(w0[128 + lane]);
    if (lane == 0) { w0[1] = rsqrtf(a * (1.0f / HID) + 1e-6f); w0[2] = rsqrtf(bq * (1.0f / HID) + 1e-6f); }
  }
  __syncthreads();
  const float re = w0[1], rh = w0[2];
  #pragma unroll
  for (int i = 0; i < 5; ++i) {
    const int j = tid + 1024 * i;
    out[xf_idx(c, j, cx.NG)] = f2bf(e[i] * re * ge[j]);
    out[xf_idx(c, HID + j, cx.NG)] = f2bf(hn[i] * rh * gh[j]);
  }
  __syncthreads();
}

// End of a verify pass (one warp per sequence): how many of the drafted tokens the model confirmed, what comes
// out, what goes in next. Column 0 held the true token x, columns 1..P-1 the drafts; y[p] is the model's choice
// after column p. Drafts for the next pass: if the last NGRAM tokens occurred before in the sequence and what
// followed them agrees with the MTP head's first draft, the continuation is copied from the context (and the
// chained MTP launches skip themselves); otherwise draft 1 is the MTP head's and the chain makes the rest.
__device__ __noinline__ void accept_work() {
  const Ctx& cx = CX();
  const int b = blockIdx.x, P = cx.P, NP = cx.next_P, lane = threadIdx.x & 31;
  int* hist = cx.hist + (size_t)b * cx.max_ctx;
  int pos = 0, a = 0, d1 = 0;
  int y[PMAX];
  #pragma unroll
  for (int p = 0; p < PMAX; ++p) y[p] = 0;
  if (lane == 0) {
    pos = ldv(cx.pos + b);
    const int lim = ldv(cx.limit + b);
    for (int p = 0; p < P; ++p) y[p] = ldv(cx.tok_res + b * P + p);
    a = 1;
    while (a < P && cx.tokbuf[b * P + a] == (long long)y[a - 1]) ++a;
    if (a > lim - pos) a = lim - pos;
    if (a < 0) a = 0;
    if (cx.tok_out) for (int p = 0; p < P; ++p) cx.tok_out[b * P + p] = y[p];
    if (cx.cnt_out) cx.cnt_out[b] = a;
    cx.nacc[b] = a;
    cx.pos[b] = pos + a;
    for (int p = 0; p < a; ++p) hist[pos + 1 + p] = y[p];
    if (a > 0) {
      d1 = ldv(cx.mtp_res + b * P + a - 1);
      cx.tokbuf[b * NP] = y[a - 1];
      if (NP > 1) cx.tokbuf[b * NP + 1] = d1;
    }
  }
  pos = __shfl_sync(0xffffffffu, pos, 0); a = __shfl_sync(0xffffffffu, a, 0); d1 = __shfl_sync(0xffffffffu, d1, 0);
  #pragma unroll
  for (int p = 0; p < PMAX; ++p) y[p] = __shfl_sync(0xffffffffu, y[p], 0);
  int found = -1;
  const int cur = pos + a;                      // position of the new current token
  if (a > 0 && NP > 2 && cur >= NGRAM) {
    // tokens at positions <= pos come from the history buffer (older launches), newer ones from y
    #define TOKAT(i) ((i) <= pos ? ldv(hist + (i)) : y[(i) - pos - 1])
    int key[NGRAM];
    #pragma unroll
    for (int t = 0; t < NGRAM; ++t) key[t] = TOKAT(cur - t);
    for (int j0 = cur - 1; j0 >= NGRAM - 1 && found < 0; j0 -= 32) {   // 32 candidate end positions per round, newest first
      const int j = j0 - lane;
      int m = -1;
      if (j >= NGRAM - 1 && TOKAT(j) == key[0]) {
        bool ok = true;
        #pragma unroll
        for (int t = 1; t < NGRAM; ++t) ok = ok && (TOKAT(j - t) == key[t]);
        if (ok && TOKAT(j + 1) == d1) m = j;
      }
      #pragma unroll
      for (int sh = 16; sh >= 1; sh >>= 1) m = max(m, __shfl_xor_sync(0xffffffffu, m, sh));
      found = m;
    }
    if (lane == 0 && found >= 0) {
      int d[PMAX];
      for (int i = 1; i < NP; ++i) {
        const int src = found + i;
        d[i] = src <= cur ? TOKAT(src) : d[src - cur];
        cx.tokbuf[b * NP + i] = d[i];
      }
    }
    #undef TOKAT
  }
  if (lane == 0) cx.lkf[b] = found >= 0 ? 1 : 0;
}

// ------------------------------------------------------------------------------------------------ the kernel
// Only warps (or blocks) that have work enter a phase function: a function's spills are executed by every thread
// that enters it (measured: 3 us per op for an empty pass through a function with a large frame).
__global__ void __launch_bounds__(1024, 1) mk_kernel(const long long* prog, int nops, Ctx cxp) {
  extern __shared__ float sm[];
  if (cxp.flags & F_CHAIN) {   // a draft-chain launch has nothing to do when every sequence copied its drafts
    bool all = true;
    for (int b = 0; b < cxp.B; ++b) all = all && (cxp.lkf[b] != 0);
    if (all) {   // the host has already counted this launch's barriers
      if (threadIdx.x == 0) atomicAdd(cxp.bar, (u64)nops);
      return;
    }
  }
  if (threadIdx.x == 0) *(Ctx*)sm = cxp;
  else if (threadIdx.x <= 20) ((long long*)sm + CTX_WORDS)[threadIdx.x - 1] = prog[threadIdx.x - 1];
  __syncthreads();
  const int w = blockIdx.x * 32 + (threadIdx.x >> 5);
  for (int o = 0; o < nops; ++o) {
    const Ctx& cx = CX(); const Op& op = OP();
    const int B = cx.B, P = cx.P, NC = cx.NC;
    switch (op.type) {
      case OP_EMBED: if (w < NC * 320) embed_work(); break;
      case OP_GEMM: gemm_phase(); break;
      case OP_LMIX: if ((int)blockIdx.x < B * 48) { if (P <= 8) lmix_work<8>(); else lmix_work<PMAX>(); } break;
      case OP_ATT_PREP: if (w < NC * 32) att_prep_work(); break;
      case OP_ATT_SCORE: if (w < B * 4 * ((cx.pos_ub + P + 15) >> 4)) att_score_work(); break;
      case OP_ATT_SOFTMAX: if (w < B * 24 * P) att_softmax_work(); break;
      case OP_ATT_VSUM: if (w < B * 64 * ((cx.pos_ub + P + 255) >> 8)) att_vsum_work(); break;
      case OP_ATT_OUT: if (w < B * 64) att_out_work(); break;
      case OP_ARGMAX: if ((int)blockIdx.x < NC) argmax_work(); break;
      case OP_FINISH: if ((int)blockIdx.x < B && threadIdx.x == 0) finish_work(); break;
      case OP_MTP_IN: if ((int)blockIdx.x < NC) mtp_in_work(); break;
      case OP_ACCEPT: if ((int)blockIdx.x < B && threadIdx.x < 32) accept_work(); break;
      case OP_CHAIN_FIN: if ((int)blockIdx.x < B && threadIdx.x == 0 && !ldv(cx.lkf + blockIdx.x)) cx.tokbuf[blockIdx.x * (int)op.M + op.i6] = ldv(cx.mtp_res + blockIdx.x); break;
    }
    barrier(prog, o, nops);
  }
}

// ------------------------------------------------------------------------------------------------ host side
extern "C" {
int mk_init(int* sm_count, int* max_smem) {
  int dev = 0;
  cudaGetDevice(&dev);
  cudaDeviceGetAttribute(sm_count, cudaDevAttrMultiProcessorCount, dev);
  cudaDeviceGetAttribute(max_smem, cudaDevAttrMaxSharedMemoryPerBlockOptin, dev);
  cudaError_t e = cudaFuncSetAttribute(mk_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, *max_smem);
  if (e != cudaSuccess) { fprintf(stderr, "mk_init: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}
int mk_launch(const long long* prog, int nops, const Ctx* cx, int smem_bytes) {
  mk_kernel<<<cx->nblocks, 1024, smem_bytes, 0>>>(prog, nops, *cx);
  cudaError_t e = cudaGetLastError();
  if (e != cudaSuccess) { fprintf(stderr, "mk_launch: %s\n", cudaGetErrorString(e)); return 1; }
  return 0;
}
int mk_sizes(int* op_bytes, int* ctx_bytes) { *op_bytes = sizeof(Op); *ctx_bytes = sizeof(Ctx); return 0; }
}
