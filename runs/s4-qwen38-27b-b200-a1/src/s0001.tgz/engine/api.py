"""Decode engine for Qwen3.8-27B on one B200: a persistent megakernel (engine/mk.cu), one launch per model pass.

Contract (eval/_engine_runner.py): Engine(model_dir, max_batch, max_context), reset(), step(tokens), generate(),
submit()/poll(), stats(), close(). Python only loads the weights, lays them out and launches the kernel; nothing of
the model runs in PyTorch.

MK_TRACK=A (default B): submit()/poll() decode one token per pass, the same data flow as step().
MK_TRACK=B: submit()/poll() draft with the checkpoint's own MTP head and verify P positions per pass (exactly the
greedy tokens of step(): a verify pass computes every position with the arithmetic of a single step).
"""

from __future__ import annotations

import ctypes
import glob
import json
import os
import struct
import subprocess
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
HID, VOCAB, FF, NL = 5120, 248320, 17408, 64
NCM, MROW, RING, PMAX = 32, 16480, 16, 8
(OP_EMBED, OP_GEMM, OP_LMIX, OP_ATT_PREP, OP_ATT_SCORE, OP_ATT_SOFTMAX, OP_ATT_VSUM, OP_ATT_OUT, OP_ARGMAX, OP_FINISH, OP_MTP_IN,
 OP_ACCEPT, OP_CHAIN_FIN) = range(1, 14)
EP_STORE, EP_RESID, EP_GATEUP, EP_LOGITS, EP_SET = 1, 2, 3, 4, 5
F_SPEC, F_LOGITS, F_FEEDBACK = 1, 2, 4
OPW = 20  # int64 words per op
DRAFT_ROWS = 32768  # the draft head scores token ids below this (first rows of lm_head, same buffer)
TRACK = os.environ.get("MK_TRACK", "A").upper()


class Ctx(ctypes.Structure):
    _fields_ = ([(n, ctypes.c_int) for n in ("B", "P", "NC", "NG", "nwarps", "nblocks", "max_ctx", "flags", "pos_ub", "NGq",
                                             "tok_stride", "na_max", "pos_off", "src_P", "src_NG", "src_sel")]
                + [("bar_base", ctypes.c_uint64)]
                + [(n, ctypes.c_void_p) for n in ("bar", "pos", "nacc", "tok_in", "h", "xf_h", "xf_mix", "xf_act", "mbuf", "ssq",
                                                  "part", "cnt", "logits", "amax_val", "amax_idx", "tok_res", "tok_out", "tokbuf",
                                                  "qf", "sc", "pf", "vpart", "rope_cos", "rope_sin", "limit", "mtp_res",
                                                  "cnt_out", "xf_fc", "tok_next")])


def _lib():
    so = HERE / "build" / "libmk.so"
    if not so.exists():
        subprocess.run(["bash", str(HERE / "build.sh")], check=True)
    lib = ctypes.CDLL(str(so))
    lib.mk_launch.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(Ctx)]
    lib.mk_launch.restype = ctypes.c_int
    return lib


def to_frag(W: torch.Tensor) -> torch.Tensor:
    """[M, K] bf16 -> int16 buffer in m16n8k16 A-operand order: [tile][kstep][lane][reg][half]."""
    M, K = W.shape
    x = W.view(torch.int16).view(M // 16, 2, 8, K // 16, 2, 4, 2).permute(0, 3, 2, 5, 4, 1, 6).contiguous()
    return x.view(-1)


def ngroups(nc: int) -> int:
    return 1 if nc <= 8 else 2 if nc <= 16 else 4


class Weights:
    """Reads the checkpoint's BF16 tensors straight onto the card."""

    def __init__(self, model_dir: str):
        self.where = {}
        for f in sorted(glob.glob(os.path.join(model_dir, "model-*.safetensors"))):
            with open(f, "rb") as fh:
                n = struct.unpack("<Q", fh.read(8))[0]
                head = json.loads(fh.read(n))
            for k, v in head.items():
                if k != "__metadata__":
                    self.where[k] = (f, 8 + n + v["data_offsets"][0], v["data_offsets"][1] - v["data_offsets"][0], v["shape"])
        self.maps = {}

    def get(self, name: str) -> torch.Tensor:
        f, off, size, shape = self.where[name]
        if f not in self.maps:
            self.maps[f] = np.memmap(f, dtype=np.uint8, mode="r")
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            raw = torch.from_numpy(self.maps[f][off:off + size])  # read-only memmap: only copied to the card
        return raw.cuda().view(torch.bfloat16).view(shape)


class Engine:
    def __init__(self, model_dir: str, max_batch: int, max_context: int):
        t0 = time.time()
        torch.cuda.init()
        self.lib = _lib()
        sm_count, max_smem = ctypes.c_int(), ctypes.c_int()
        if self.lib.mk_init(ctypes.byref(sm_count), ctypes.byref(max_smem)):
            raise RuntimeError("mk_init failed")
        self.nblocks = sm_count.value
        self.nwarps = self.nblocks * 32
        self.Bmax = max(1, int(max_batch))
        self.mc = ((int(max_context) + 2 * PMAX + 255) // 256) * 256
        self.keep = []           # every device buffer the kernel uses
        self.launches = 0
        self.dev = torch.device("cuda")
        self.spec = TRACK == "B"
        self._buffers()
        self._load(model_dir)
        self.pos_ub = 0
        self.bar_base = 0
        self._hold = None
        self.counters = {"passes": 0, "tokens": 0, "chain_launches": 0}
        self.load_seconds = time.time() - t0
        self.waiting, self.cohort, self.first_wait = [], None, None

    # ------------------------------------------------------------------ buffers
    def _z(self, *shape, dtype=torch.float32):
        t = torch.zeros(*shape, dtype=dtype, device=self.dev)
        self.keep.append(t)
        return t

    def _buffers(self):
        B, mc, nw = self.Bmax, self.mc, self.nwarps
        i16, i32, i64 = torch.int16, torch.int32, torch.int64
        b = {}
        b["bar"] = self._z(2, dtype=i64)
        b["pos"] = self._z(max(B, 8), dtype=i32)
        b["nacc"] = self._z(max(B, 8), dtype=i32)
        b["limit"] = self._z(max(B, 8), dtype=i32)
        b["h"] = self._z(NCM * HID, dtype=i16)
        b["xf_h"] = self._z(320 * 4 * 128, dtype=i16)
        b["xf_mix"] = self._z(384 * 4 * 128, dtype=i16)
        b["xf_act"] = self._z(1088 * 4 * 128, dtype=i16)
        b["xf_fc"] = self._z(640 * 4 * 128, dtype=i16)
        b["mbuf"] = self._z(NCM * MROW, dtype=i16)
        b["ssq"] = self._z(320 * NCM)
        b["part"] = self._z((VOCAB // 16 + self.nblocks + 1) * 4 * 32 * 4)
        b["cnt"] = self._z(VOCAB // 16, dtype=i32)
        b["amax_val"] = self._z(VOCAB // 16 * NCM)
        b["amax_idx"] = self._z(VOCAB // 16 * NCM, dtype=i32)
        b["tok_res"] = self._z(NCM, dtype=i32)
        b["mtp_res"] = self._z(NCM, dtype=i32)
        b["tokbuf"] = self._z(NCM, dtype=i64)
        b["qf"] = self._z(B * 4 * 16 * 6 * 128, dtype=i16)
        b["sc"] = self._z(B * 24 * PMAX * mc)
        b["pf"] = self._z(B * 4 * (mc // 16) * 6 * 128, dtype=i16)
        b["vpart"] = self._z(B * 4 * 16 * (mc // 256) * 6 * 32 * 4)
        pos = torch.arange(mc, dtype=torch.float32, device=self.dev)
        inv_freq = 1.0 / (10000000.0 ** (torch.arange(0, 64, 2, dtype=torch.float) / 64)).to(self.dev)
        freqs = pos[:, None] * inv_freq[None, :]
        b["rope_cos"] = freqs.cos().to(torch.bfloat16).float().contiguous()
        b["rope_sin"] = freqs.sin().to(torch.bfloat16).float().contiguous()
        self.keep += [b["rope_cos"], b["rope_sin"]]
        self.buf = b

    # ------------------------------------------------------------------ weights and programs
    def _load(self, model_dir: str):
        cfg = json.loads((Path(model_dir) / "config.json").read_text())["text_config"]
        types = cfg["layer_types"]
        assert cfg["hidden_size"] == HID and cfg["vocab_size"] == VOCAB and len(types) == NL
        wts = Weights(model_dir)
        B, mc = self.Bmax, self.mc
        pre = "model.language_model."
        f32 = lambda t: t.float().contiguous()
        keep = self.keep
        bf = self.buf
        self.weight_bytes = 0

        def K(t):
            keep.append(t)
            return t.data_ptr()

        def gain(name):  # RMSNorm weights are stored centred
            return K(f32(1.0 + wts.get(name).float()))

        def frag(W):
            t = to_frag(W)
            self.weight_bytes += t.numel() * 2
            return K(t)

        def row(type_, ep=0, NT=0, KQ=0, use_r=0, M=0, i6=0, i7=0, W=0, xf=0, out=0, gnext=0, p=()):
            return [type_, ep, NT, KQ, use_r, M, i6, i7, W, xf, out, gnext] + list(p) + [0] * (8 - len(p))

        def attention(prefix, ops):
            Win = torch.cat([wts.get(prefix + "q_proj.weight"), wts.get(prefix + "k_proj.weight"), wts.get(prefix + "v_proj.weight")], 0)
            ops.append(row(OP_GEMM, EP_STORE, NT=Win.shape[0] // 16, KQ=80, use_r=1, M=Win.shape[0], W=frag(Win),
                           xf=bf["xf_h"].data_ptr(), out=bf["mbuf"].data_ptr()))
            del Win
            Kc = self._z(B * 4 * mc * 256, dtype=torch.int16)
            Vc = self._z(B * 4 * mc * 256, dtype=torch.int16)
            p = (Kc.data_ptr(), Vc.data_ptr(), gain(prefix + "q_norm.weight"), gain(prefix + "k_norm.weight"))
            for t in (OP_ATT_PREP, OP_ATT_SCORE, OP_ATT_SOFTMAX, OP_ATT_VSUM, OP_ATT_OUT):
                ops.append(row(t, p=p))
            return wts.get(prefix + "o_proj.weight")

        def mlp(lp, Wout, g_next, ops):
            ops.append(row(OP_GEMM, EP_RESID, NT=320, KQ=96, W=frag(Wout), xf=bf["xf_mix"].data_ptr(),
                           gnext=gain(lp + "post_attention_layernorm.weight")))
            gate, up = wts.get(lp + "mlp.gate_proj.weight"), wts.get(lp + "mlp.up_proj.weight")
            Wgu = torch.stack([gate.view(FF // 8, 8, HID), up.view(FF // 8, 8, HID)], 1).reshape(2 * FF, HID)
            del gate, up
            ops.append(row(OP_GEMM, EP_GATEUP, NT=2 * FF // 16, KQ=80, use_r=1, W=frag(Wgu), xf=bf["xf_h"].data_ptr(),
                           out=bf["xf_act"].data_ptr()))
            del Wgu
            ops.append(row(OP_GEMM, EP_RESID, NT=320, KQ=FF // 64, W=frag(wts.get(lp + "mlp.down_proj.weight")),
                           xf=bf["xf_act"].data_ptr(), gnext=g_next))

        g_in = [gain(f"{pre}layers.{i}.input_layernorm.weight") for i in range(NL)] + [gain(f"{pre}norm.weight")]
        self.emb = wts.get(f"{pre}embed_tokens.weight").view(torch.int16).contiguous()
        keep.append(self.emb)
        body = [row(OP_EMBED, W=self.emb.data_ptr(), gnext=g_in[0])]
        self.layer_end = []
        for i in range(NL):
            lp = f"{pre}layers.{i}."
            if types[i] == "linear_attention":
                la = lp + "linear_attn."
                Win = torch.cat([wts.get(la + "in_proj_qkv.weight"), wts.get(la + "in_proj_z.weight"),
                                 wts.get(la + "in_proj_b.weight"), wts.get(la + "in_proj_a.weight")], 0)
                body.append(row(OP_GEMM, EP_STORE, NT=Win.shape[0] // 16, KQ=80, use_r=1, M=Win.shape[0], W=frag(Win),
                                xf=bf["xf_h"].data_ptr(), out=bf["mbuf"].data_ptr()))
                del Win
                S = self._z(B * 48 * 16384)
                ring = self._z(B * RING * 10240, dtype=torch.int16)
                convw = K(f32(wts.get(la + "conv1d.weight").view(10240, 4)))
                negA = K(f32(-(wts.get(la + "A_log").float().exp())))
                dtb = K(f32(wts.get(la + "dt_bias")))
                nwt = K(f32(wts.get(la + "norm.weight")))
                pk = self._z(B * 48 * PMAX * 128)
                pd = self._z(B * 48 * PMAX * 128)
                pdec = self._z(B * 48 * PMAX)
                body.append(row(OP_LMIX, W=pdec.data_ptr(),
                                p=(S.data_ptr(), ring.data_ptr(), convw, negA, dtb, nwt, pk.data_ptr(), pd.data_ptr())))
                Wout = wts.get(la + "out_proj.weight")
            else:
                Wout = attention(lp + "self_attn.", body)
            mlp(lp, Wout, g_in[i + 1], body)
            del Wout
            self.layer_end.append(len(body))
        self.model_bytes = self.weight_bytes
        self.head_ptr = frag(wts.get("lm_head.weight"))
        head = [row(OP_GEMM, EP_LOGITS, NT=VOCAB // 16, KQ=80, use_r=1, i6=1, W=self.head_ptr, xf=bf["xf_h"].data_ptr()),
                row(OP_ARGMAX, NT=VOCAB // 16, out=bf["tok_res"].data_ptr())]
        self.model_bytes = self.weight_bytes
        progs = {"full": body + head + [row(OP_FINISH, i6=1)], "nohead": body + [row(OP_FINISH)]}

        if self.spec:
            # the checkpoint's multi-token-prediction head: mtp.fc, one full-attention layer, mtp.norm, shared lm_head
            mp = "mtp.layers.0."
            fc = frag(wts.get("mtp.fc.weight"))
            g_emb, g_hid = gain("mtp.pre_fc_norm_embedding.weight"), gain("mtp.pre_fc_norm_hidden.weight")
            fc_row = row(OP_GEMM, EP_SET, NT=320, KQ=160, W=fc, xf=bf["xf_fc"].data_ptr(), gnext=gain(mp + "input_layernorm.weight"))
            layer = []
            Wout = attention(mp + "self_attn.", layer)
            mlp(mp, Wout, gain("mtp.norm.weight"), layer)
            del Wout
            dhead = [row(OP_GEMM, EP_LOGITS, NT=DRAFT_ROWS // 16, KQ=80, use_r=1, W=self.head_ptr, xf=bf["xf_h"].data_ptr()),
                     row(OP_ARGMAX, NT=DRAFT_ROWS // 16, out=bf["mtp_res"].data_ptr())]

            def mtp_in(src, idx=0, stride=0):
                return row(OP_MTP_IN, i6=src, i7=idx, M=stride, W=self.emb.data_ptr(), gnext=g_emb, out=bf["xf_fc"].data_ptr(), p=(g_hid,))

            progs["verify"] = body + head + [mtp_in(0), fc_row] + layer + dhead + [row(OP_ACCEPT)]
            progs["prefill"] = body + [mtp_in(2), fc_row] + layer[:2] + [row(OP_FINISH)]
            for Pv in range(3, PMAX + 1):
                for i in range(2, Pv):
                    progs[f"chain{Pv}_{i}"] = [mtp_in(1, i - 1, Pv), fc_row] + layer + dhead + [row(OP_CHAIN_FIN, i6=i, M=Pv)]
        self.prog = {}
        for name, rows in progs.items():
            a = np.array(rows, dtype=np.int64)
            assert a.shape[1] == OPW
            self.prog[name] = torch.from_numpy(a).to(self.dev)
        self.keep += list(self.prog.values())
        self.prog_full, self.prog_nohead = self.prog["full"], self.prog["nohead"]
        torch.cuda.synchronize()
        wts.maps.clear()

    # ------------------------------------------------------------------ launching
    def _launch(self, B, P, tok_ptr, tok_stride, flags, logits_ptr=0, tok_out_ptr=0, prog=None, nops=None, advance=None, **kw):
        prog = self.prog_full if prog is None else prog
        nops = prog.shape[0] if nops is None else nops
        NC = B * P
        cx = Ctx()
        cx.B, cx.P, cx.NC, cx.NG = B, P, NC, ngroups(NC)
        cx.nwarps, cx.nblocks, cx.max_ctx, cx.flags = self.nwarps, self.nblocks, self.mc, flags
        cx.pos_ub, cx.NGq, cx.tok_stride = self.pos_ub, (6 * P + 7) // 8, tok_stride
        cx.bar_base = self.bar_base
        for name, t in self.buf.items():
            setattr(cx, name, t.data_ptr())
        cx.tok_in, cx.logits, cx.tok_out = tok_ptr, logits_ptr, tok_out_ptr
        cx.src_P, cx.src_NG = P, cx.NG
        for k, v in kw.items():
            setattr(cx, k, v)
        if cx.pos_ub + P > self.mc:
            raise RuntimeError("context longer than max_context")
        if self.lib.mk_launch(prog.data_ptr(), nops, ctypes.byref(cx)):
            raise RuntimeError("mk_launch failed")
        self.bar_base += nops * self.nblocks
        self.pos_ub += P if advance is None else advance
        self.launches += 1

    # ------------------------------------------------------------------ the offline contract
    def reset(self) -> None:
        self.buf["pos"].zero_()
        self.buf["nacc"].zero_()
        self.pos_ub = 0

    def step(self, tokens: torch.Tensor) -> torch.Tensor:
        B = tokens.shape[0]
        logits = torch.empty(B, VOCAB, dtype=torch.bfloat16, device=self.dev)
        self._launch(B, 1, tokens.data_ptr(), tokens.stride(0), F_LOGITS, logits_ptr=logits.data_ptr())
        self._hold = (tokens, logits)
        return logits

    def generate(self, tokens: torch.Tensor, n_steps: int) -> torch.Tensor:
        B = tokens.shape[0]
        tb = self.buf["tokbuf"]
        tb[:B] = tokens
        out = torch.empty(n_steps, B, dtype=torch.int64, device=self.dev)
        for i in range(n_steps):
            self._launch(B, 1, tb.data_ptr(), 1, F_FEEDBACK, tok_out_ptr=out[i].data_ptr())
        self._hold = (tokens, out)
        return out.t()

    def close(self) -> None:
        torch.cuda.synchronize()
        self.keep = []
        self.buf = {}

    def stats(self) -> dict:
        s = {"implementation": "megakernel, one launch per model pass, weights in MMA fragment order", "track": TRACK,
             "launches": self.launches, "weight_bytes": self.weight_bytes, "sm_count": self.nblocks,
             "load_seconds": round(self.load_seconds, 1)}
        s.update(self.counters)
        if self.counters["passes"]:
            s["tokens_per_verify_pass"] = round(self.counters["tokens"] / self.counters["passes"], 3)
        return s

    # ------------------------------------------------------------------ the online contract (HTTP server)
    def submit(self, rid, prompt, n) -> None:
        self.waiting.append((int(rid), list(prompt), int(n)))
        if self.first_wait is None:
            self.first_wait = time.perf_counter()

    def _take_cohort(self):
        length = len(self.waiting[0][1])
        cohort = [r for r in self.waiting if len(r[1]) == length][:self.Bmax]
        self.waiting = [r for r in self.waiting if all(r is not c for c in cohort)]
        self.first_wait = time.perf_counter() if self.waiting else None
        return cohort, length

    def _start_cohort(self):
        cohort, L = self._take_cohort()
        B = len(cohort)
        nmax = max(r[2] for r in cohort)
        ids = torch.tensor([r[1] for r in cohort], dtype=torch.int64, device=self.dev).t().contiguous()  # [L, B]
        tb = self.buf["tokbuf"]
        self.reset()
        Pv = int(os.environ.get("MK_PV", "0")) or (PMAX if B == 1 else 4 if B <= 8 else 2)
        Pv = max(1, min(Pv, PMAX, NCM // B))
        spec = self.spec and Pv >= 2 and L >= 2 and L + nmax + 2 * Pv < self.mc
        co = {"reqs": cohort, "B": B, "n": nmax, "ids": ids, "queued": 0, "done": 0, "events": [], "spec": spec,
              "sent": [0] * B}
        if not spec:
            for t in range(L - 1):
                self._launch(B, 1, ids[t].data_ptr(), 1, 0, prog=self.prog_nohead)
            tb[:B] = ids[L - 1]
            co["out"] = torch.empty(nmax, B, dtype=torch.int64, device=self.dev)
            co["host"] = torch.empty(nmax, B, dtype=torch.int64).pin_memory()
        else:
            # prompt: one position per pass, the drafter's K/V history is built on the way
            for t in range(L - 1):
                self._launch(B, 1, ids[t].data_ptr(), 1, 0, prog=self.prog["prefill"], tok_next=ids[t + 1].data_ptr())
            tb.view(-1)[:B * Pv] = ids[L - 1].repeat_interleave(Pv)   # column 0: the last prompt token; no drafts yet
            lim = torch.tensor([L - 1 + r[2] for r in cohort], dtype=torch.int32, device=self.dev)
            self.buf["limit"][:B] = lim
            co.update(Pv=Pv, cap=nmax + 8, known_pos=L - 1, limit=L - 1 + nmax,
                      out=torch.empty(nmax + 8, B * Pv, dtype=torch.int64, device=self.dev),
                      cnt=torch.empty(nmax + 8, B, dtype=torch.int32, device=self.dev),
                      host=torch.empty(nmax + 8, B * Pv, dtype=torch.int64).pin_memory(),
                      hcnt=torch.empty(nmax + 8, B, dtype=torch.int32).pin_memory(), prev_P=0)
        self.cohort = co

    def _queue_plain(self, co):
        tb = self.buf["tokbuf"]
        while co["queued"] < co["n"] and co["queued"] - co["done"] < 4:
            i = co["queued"]
            self._launch(co["B"], 1, tb.data_ptr(), 1, F_FEEDBACK, tok_out_ptr=co["out"][i].data_ptr())
            co["host"][i].copy_(co["out"][i], non_blocking=True)
            ev = torch.cuda.Event()
            ev.record()
            co["events"].append(ev)
            co["queued"] += 1

    def _queue_spec(self, co):
        tb, B, Pv = self.buf["tokbuf"], co["B"], co["Pv"]
        NGv, NG1 = ngroups(B * Pv), ngroups(B)
        while co["queued"] < co["cap"] and co["queued"] - co["done"] < 2 and min(co["sent"]) < co["n"]:
            i = co["queued"]
            inflight = co["queued"] - co["done"]
            self.pos_ub = min(co["known_pos"] + inflight * Pv, co["limit"])
            self._launch(B, Pv, tb.data_ptr(), 1, F_SPEC, prog=self.prog["verify"], tok_out_ptr=co["out"][i].data_ptr(),
                         cnt_out=co["cnt"][i].data_ptr(), na_max=co["prev_P"], advance=0)
            co["prev_P"] = Pv
            ub = min(co["known_pos"] + (inflight + 1) * Pv, co["limit"])
            for k in range(2, Pv):   # drafts 2 .. Pv-1, one launch each (draft 1 came out of the verify pass)
                self.pos_ub = ub + k - 2
                self._launch(B, 1, 0, 1, 0, prog=self.prog[f"chain{Pv}_{k}"], pos_off=k - 2, advance=0,
                             src_P=(Pv if k == 2 else 1), src_NG=(NGv if k == 2 else NG1), src_sel=(1 if k == 2 else 0))
                self.counters["chain_launches"] += 1
            co["host"][i].copy_(co["out"][i], non_blocking=True)
            co["hcnt"][i].copy_(co["cnt"][i], non_blocking=True)
            ev = torch.cuda.Event()
            ev.record()
            co["events"].append(ev)
            co["queued"] += 1

    def poll(self):
        if self.cohort is None:
            if not self.waiting:
                return []
            if len(self.waiting) < self.Bmax and time.perf_counter() - self.first_wait < 0.05:
                return []
            self._start_cohort()
        co = self.cohort
        events = []
        if not co["spec"]:
            self._queue_plain(co)
            while co["done"] < co["queued"] and co["events"][co["done"]].query():
                i = co["done"]
                tokens = co["host"][i].tolist()
                for j, (rid, _, n) in enumerate(co["reqs"]):
                    if i < n:
                        events.append((rid, [tokens[j]], i == n - 1))
                co["done"] += 1
            if co["done"] == co["n"]:
                self.cohort = None
            return events
        self._queue_spec(co)
        Pv = co["Pv"]
        while co["done"] < co["queued"] and co["events"][co["done"]].query():
            i = co["done"]
            cnt, tokens = co["hcnt"][i].tolist(), co["host"][i].tolist()
            for j, (rid, _, n) in enumerate(co["reqs"]):
                a = min(cnt[j], n - co["sent"][j])
                if a > 0:
                    co["sent"][j] += a
                    events.append((rid, tokens[j * Pv:j * Pv + a], co["sent"][j] == n))
                    self.counters["tokens"] += a
            co["known_pos"] += max(cnt) if cnt else 0
            self.counters["passes"] += 1
            co["done"] += 1
        if all(s >= r[2] for s, r in zip(co["sent"], co["reqs"])) and co["done"] == co["queued"]:
            self.cohort = None
        elif co["done"] == co["queued"] and co["queued"] >= co["cap"]:
            self.cohort = None  # cannot happen: every pass emits at least one token per unfinished sequence
        return events
