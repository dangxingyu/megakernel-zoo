#!/usr/bin/env bash
# Build step run by the evaluator before anything else (cwd: the workspace). Must be repeatable.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
stamp=$(cat mk.cu build.sh | sha256sum | cut -d' ' -f1)
if [ ! -f build/libmk.so ] || [ "$(cat build/stamp 2>/dev/null)" != "$stamp" ]; then
  nvcc -O3 -std=c++17 -arch=sm_100 -shared -Xcompiler -fPIC -Xptxas -v -o build/libmk.so.tmp mk.cu 2> build/ptxas.log || { cat build/ptxas.log; exit 1; }
  mv build/libmk.so.tmp build/libmk.so
  echo "$stamp" > build/stamp
  echo "built libmk.so"
fi
