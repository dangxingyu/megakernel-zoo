// Inkling-2-Small pass engine for one GB200 node (4 x B200).
//
// A pass carries T rows (a row = one position of one sequence: prompt chunks and decoding sequences together)
// through the 48 layers. Per card: attention is split by heads (12 q heads / 2 KV heads per card), every expert
// lives whole on one card (96 per card), router / o_proj / attention residuals / short convolutions / norms are
// replicated and bitwise identical on the four cards. Two exchanges per layer (attention outputs, expert outputs)
// are read through peer pointers after a flag written by the producing card; nothing waits for the host inside a
// pass. Every row's arithmetic is independent of the other rows of the pass and of how a sequence is cut into
// passes: GEMM columns are independent, attention folds page-aligned segments in order, expert outputs are summed
// in expert order.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_fp8.h>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <chrono>
#include <algorithm>

typedef __nv_bfloat16 bf16;

#define H 4608
#define NL 48
#define NE 384
#define NEC 96            // experts per card
#define TOPK 8
#define HD 128
#define NQL 12
#define NKVL 2
#define DREL 16
#define RELEXT 1024
#define WIN 1024
#define NCARD 4
#define PAGE 512
#define MAXPG 68          // pages per sequence (34816 positions)
#define VOCAB_REAL 200058
#define HS 9728           // short-convolution state per (layer, lag): k 256, v 256, attn 4608, mlp 4608
#define NTB 256           // threads of the per-row kernels
#define EPT (H / NTB)     // 18 elements per thread
#define COLT 128          // GEMM column tile
#define QG 1536
#define QR 3072
#define QS 3264
#define QK 3280
#define UB4 576
#define UB8 1056
#define APW 130           // attention segment record per row: max, sum, 128 values
#define NSIG (NL * 3 + 16)       // exchange flags: 2 per layer, the unembedding join at NL*2, the owner-sum spread at NL*2+8+layer
#define SIG_SCHED (NSIG - 1)      // card 0: tag of the pass it has composed
#define SIG_TAKEN (NSIG - 2)      // every card: tag of the pass whose tables it has taken

struct PLayer {
  // weights in the tensor core's operand layout: units of 128 rows x one K step (bf16: 16 k, 4096 B; nvfp4: 64 k,
  // 4096 B of codes + 512 B scale atom; mxfp8: 32 k, 4096 B + 512 B atom), [row group][K step][unit]
  const uint8_t* wqkv;      // [30 or 32 row groups][288]: q|gate|r|sink (26), k (+taps) (2 or 3), v (+taps) (2 or 3)
  const uint8_t* wo;        // [36][384] (full o_proj, replicated)
  const uint8_t* wr;        // router [3][288]
  const float* rbias;       // [384]
  const uint8_t* w13;       // [96][36][72 or 144]
  const uint8_t* w2;        // [96][36][36 or 72]
  const float* f13;         // [384] weight outer factor amax / denominator (nvfp4), by expert
  const float* f2;
  const bf16* norm[3];
  const bf16* mlp_norm;
  const bf16* ksc;          // local: [256][4] (channel, tap); global: [4][256] (lag, channel)
  const bf16* vsc;
  const bf16* attn_sc;      // [4608][4]
  const bf16* mlp_sc;
  const bf16* qscale;       // [12][128]
  const bf16* rscale;       // [12][16]
  const uint8_t* relp;      // relative-bias projection [1024][16] as tensor-core units [8 row groups][1 K step][4096 B]
  const float* aq;          // [nq][4608], pre-scaled by H^-0.5 (layer 0: null)
  const float* mq;          // [4608], pre-scaled
  uint8_t* kpg;             // K pages of this layer [npages][2 kv][32 chunks][4096 B]
  uint8_t* vpg;
  int glob, mx, qkv_strips, pad;
};

#include "sched.h"      // PHdr (what a pass is) and the scheduler that composes passes on the device

struct PCtx {
  PHdr h;
  PLayer L[NL];
  int card, npages, tmax, pmax;
  float eps; int umax; int pad0, pad1;
  const bf16* embed; const bf16* embed_norm; const float* oq; const bf16* fnorm;
  const uint8_t* unembed; int un_strips; int un_row0;
  int* tab;                 // per-pass tables (offsets in the header)
  bf16* blocks;             // [9][tmax][H]: finished blocks and the partial block (index = blocks finished)
  bf16* xin;                // [3][tmax][H] attention inputs, tile layout (64 rows per tile, see xta)
  bf16* qkvo;               // [tmax][3824]
  bf16* qn;                 // [tmax][12][128]
  bf16* relb;               // [tmax][12][1024]
  uint8_t* rt;              // [tmax*12/128 tiles][4096 B]: clipped r of (row, head), tile layout (input of the bias GEMM)
  float* apart;             // [umax][16][APW]
  bf16* attn_out;           // [tmax][1536]
  bf16* xo;                 // [tmax][6144] tile layout
  bf16* attn_raw;           // [tmax][H]
  bf16* attn_s;             // [tmax][H]
  bf16* mlp_in;             // [tmax][H]
  bf16* mlp_inx;            // [tmax][H] tile layout (router input)
  float* rlog;              // [tmax][384]
  int* ids; float* wts;     // [tmax][8]
  int* pidx;                // [tmax][8] pair index on the expert's card
  int* cnt;                 // [NL][384]
  int* emap;                // [NL][384]: where an expert's weights are: card | index on that card << 8 (the host moves
                            // experts between cards to even out the cards' load; the same table on every card)
  uint8_t* xq;              // [tmax][H]: e2m1 codes (2304 B, low nibble first) or e4m3 codes (4608 B) of the MoE input
  float* xouter;            // [tmax] (nvfp4)
  uint8_t* xs8;             // [tmax][288] block scales: e4m3 per 16 (nvfp4) or ue8m0 exponent per 32 (mxfp8)
  int* ptok; int* pslot;    // [4][pmax]
  int* items;               // [4][pmax][4]: expert, first pair, pairs
  int* ginfo;               // [4][4]: items, pairs
  bf16* h13;                // [pmax][H]
  uint8_t* xt13;            // [items][72 or 144 K steps][2560]: w13 inputs of an item's pairs, operand layout + scale atom
  float* aouter;            // [pmax]
  uint8_t* xt2;             // [items][36 or 72][2560]: w2 inputs
  int* pitem;               // [pmax] item of a pair (this card)
  bf16* pairout;            // [pmax][H]
  bf16* mlp_raw;            // [tmax][H]
  bf16* hist;               // [nslot][NL][3][HS]
  bf16* snap;               // [npages][NL][3][HS]
  bf16* hfin;               // [tmax][H] tile layout
  unsigned long long* cand; // [tmax]
  unsigned* sig;            // [NSIG]
  unsigned* err;            // [4]
  const bf16* attn_out_p[NCARD];
  const bf16* pairout_p[NCARD];
  unsigned* sig_p[NCARD];
  const bf16* mlp_raw_p[NCARD];
  // device-side serving loop (card 0 composes the passes; the others copy its tables)
  Sched* sched; SShared* shr; const int* arena;
  const unsigned long long* cand_p[NCARD];
  PCtx* ctx_p[NCARD];
  const int* tab_p[NCARD];
};

// ------------------------------------------------------------------------------------------------ helpers
__device__ __forceinline__ float bf(bf16 x) { return __bfloat162float(x); }
__device__ __forceinline__ bf16 tobf(float x) { return __float2bfloat16_rn(x); }
__device__ __forceinline__ float sigm(float x) { return 1.0f / (1.0f + expf(-x)); }
__device__ __forceinline__ uint4 ldg_nc(const void* p) {
  uint4 r;
  asm volatile("ld.global.nc.L1::no_allocate.v4.u32 {%0,%1,%2,%3}, [%4];" : "=r"(r.x), "=r"(r.y), "=r"(r.z), "=r"(r.w) : "l"(p));
  return r;
}
__device__ __forceinline__ uint2 ldg_nc2(const void* p) {
  uint2 r;
  asm volatile("ld.global.nc.L1::no_allocate.v2.u32 {%0,%1}, [%2];" : "=r"(r.x), "=r"(r.y) : "l"(p));
  return r;
}
__device__ __forceinline__ uint32_t ldg_nc1(const void* p) {
  uint32_t r;
  asm volatile("ld.global.nc.L1::no_allocate.u32 %0, [%1];" : "=r"(r) : "l"(p));
  return r;
}
__device__ __forceinline__ uint4 ld4(const void* p) { return *reinterpret_cast<const uint4*>(p); }
__device__ __forceinline__ uint32_t hmul2(uint32_t a, uint32_t b) { uint32_t r; asm("mul.rn.f16x2 %0,%1,%2;" : "=r"(r) : "r"(a), "r"(b)); return r; }
__device__ __forceinline__ void mma_f16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_bf16(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ void mma_e4m3(float* d, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t b0, uint32_t b1) {
  asm volatile("mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
               : "+f"(d[0]), "+f"(d[1]), "+f"(d[2]), "+f"(d[3]) : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(b0), "r"(b1));
}
__device__ __forceinline__ float ue8m0(uint32_t e) { return e == 0 ? __int_as_float(0x00400000) : __int_as_float(e << 23); }
__device__ __forceinline__ void cvt4(uint32_t w, uint32_t* o) {
  asm("{ .reg .b8 b0,b1,b2,b3; mov.b32 {b0,b1,b2,b3}, %4;\n"
      " cvt.rn.f16x2.e2m1x2 %0, b0; cvt.rn.f16x2.e2m1x2 %1, b1; cvt.rn.f16x2.e2m1x2 %2, b2; cvt.rn.f16x2.e2m1x2 %3, b3; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(w));
}
__device__ __forceinline__ void scl4(uint32_t w, uint32_t* o) {  // bytes (g,g8) j0, (g,g8) j1 -> {g,g},{g8,g8},{g,g},{g8,g8}
  uint32_t lo, hi;
  asm("{ .reg .b16 l,h; mov.b32 {l,h}, %2; cvt.rn.f16x2.e4m3x2 %0, l; cvt.rn.f16x2.e4m3x2 %1, h; }" : "=r"(lo), "=r"(hi) : "r"(w));
  asm("{ .reg .b16 a,b; mov.b32 {a,b}, %4; mov.b32 %0, {a,a}; mov.b32 %1, {b,b}; mov.b32 {a,b}, %5; mov.b32 %2, {a,a}; mov.b32 %3, {b,b}; }"
      : "=r"(o[0]), "=r"(o[1]), "=r"(o[2]), "=r"(o[3]) : "r"(lo), "r"(hi));
}
__device__ __forceinline__ unsigned ld_acquire_sys(const unsigned* p) { unsigned v; asm volatile("ld.acquire.sys.global.u32 %0, [%1];" : "=r"(v) : "l"(p) : "memory"); return v; }
__device__ __forceinline__ void st_release_sys(unsigned* p, unsigned v) { asm volatile("st.release.sys.global.u32 [%0], %1;" :: "l"(p), "r"(v) : "memory"); }

// Tile layout of the dense GEMM inputs (the tensor core's B operand): 128 rows per tile, per K step of 16 a unit of
// 4096 B: row n, element k at (n/8)*256 + ((k/8)&1)*128 + (n%8)*16 + (k%8)*2. Byte offset of element k of `row`:
__device__ __forceinline__ long xta(int row, int k, int KS) {
  const int n = row & 127;
  return ((long)(row >> 7) * KS + (k >> 4)) * 4096 + (n >> 3) * 256 + ((k >> 3) & 1) * 128 + (n & 7) * 16 + (k & 7) * 2;
}
// (unused) B-fragment order of a row of K values: element k at ((t * (K/16) + s) * 4 + e), t = (k%8)/2, s = k/16,
// e = (k%2) + 2*((k%16)/8): lane (col, t) of an m16n8k16 reads its 8 bytes of step s at one address.
__device__ __forceinline__ int xfi(int k, int K) { return (((k & 7) >> 1) * (K >> 4) + (k >> 4)) * 4 + (k & 1) + 2 * ((k >> 3) & 1); }

// block-wide sums of n per-thread values (every thread gets the totals); red: shared [nwarp][n]
__device__ __forceinline__ void block_sum_n(float* v, int n, float* red) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5, nw = blockDim.x >> 5;
  for (int i = 0; i < n; i++) {
    float x = v[i];
#pragma unroll
    for (int off = 16; off; off >>= 1) x += __shfl_xor_sync(0xffffffff, x, off);
    if (lane == 0) red[w * n + i] = x;
  }
  __syncthreads();
  for (int i = 0; i < n; i++) {
    float s = 0.f;
    for (int k = 0; k < nw; k++) s += red[k * n + i];
    v[i] = s;
  }
  __syncthreads();
}
__device__ __forceinline__ float block_max1(float x, float* red) {
  const int lane = threadIdx.x & 31, w = threadIdx.x >> 5, nw = blockDim.x >> 5;
#pragma unroll
  for (int off = 16; off; off >>= 1) x = fmaxf(x, __shfl_xor_sync(0xffffffff, x, off));
  if (lane == 0) red[w] = x;
  __syncthreads();
  float s = 0.f;
  for (int k = 0; k < nw; k++) s = fmaxf(s, red[k]);
  __syncthreads();
  return s;
}

// the producers of exchange `idx` on this card have finished (this kernel runs after them on the card's stream):
// say so, then wait until the other three cards have said the same for this pass.
__device__ __forceinline__ void xwait(const PCtx* c, int idx) {
  if (threadIdx.x == 0) {
    const unsigned tag = (unsigned)c->h.tag;
    const int me = c->card;
    st_release_sys(&c->sig_p[me][idx], tag);
    for (int p = 0; p < NCARD; p++) {
      if (p == me) continue;
      unsigned long long spins = 0;
      while (ld_acquire_sys(&c->sig_p[p][idx]) != tag) {
        if (++spins > (1ull << 31)) { c->err[0] = 1 + idx; break; }
      }
    }
  }
  __syncthreads();
}

#define TAB(o) (c->tab + c->h.o)

// ------------------------------------------------------------------------------------------------ embedding
// Per-row vector kernels: one block per row, 288 threads, 16 consecutive elements per thread (two 16-byte loads
// or stores per bf16 vector). Sums over the 4608 elements: per thread in element order, then the warp's shuffle
// tree, then the nine warps in order: the same for every pass size.
#define RT 288
#define RE 16
__device__ __forceinline__ void ld16(const bf16* p, float* v) {
  const uint4 a = *reinterpret_cast<const uint4*>(p), b = *reinterpret_cast<const uint4*>(p + 8);
  const bf16* x = reinterpret_cast<const bf16*>(&a);
  const bf16* y = reinterpret_cast<const bf16*>(&b);
#pragma unroll
  for (int e = 0; e < 8; e++) { v[e] = bf(x[e]); v[8 + e] = bf(y[e]); }
}
__device__ __forceinline__ uint4 pk8(const float* v) {
  uint4 o;
  bf16* b = reinterpret_cast<bf16*>(&o);
#pragma unroll
  for (int e = 0; e < 8; e++) b[e] = tobf(v[e]);
  return o;
}
__device__ __forceinline__ void st16(bf16* p, const float* v) {
  *reinterpret_cast<uint4*>(p) = pk8(v);
  *reinterpret_cast<uint4*>(p + 8) = pk8(v + 8);
}
// the same 16 values into the tile layout of a dense GEMM input (two 16-byte pieces)
__device__ __forceinline__ void st16t(uint8_t* base, int row, int k0, int KS, const float* v) {
  *reinterpret_cast<uint4*>(base + xta(row, k0, KS)) = pk8(v);
  *reinterpret_cast<uint4*>(base + xta(row, k0 + 8, KS)) = pk8(v + 8);
}
__global__ void __launch_bounds__(RT) k_embed(const PCtx* c) {
  if (blockIdx.x >= c->h.T) return;       // fixed-grid launches: no such row in this pass
  __shared__ float red[9 * 4];
  const int r = blockIdx.x, tid = threadIdx.x, k0 = tid * RE;
  if (r == 0) for (int i = tid; i < NL * NE; i += RT) c->cnt[i] = 0;
  const int tok = c->h.tok_dev ? c->h.tokens[r] : TAB(o_tok)[r];
  float u[RE], g[RE], ss = 0.f;
  ld16(c->embed + (long)tok * H + k0, u);
  ld16(c->embed_norm + k0, g);
#pragma unroll
  for (int e = 0; e < RE; e++) ss += u[e] * u[e];
  block_sum_n(&ss, 1, red);
  const float inv = rsqrtf(ss / (float)H + c->eps);
#pragma unroll
  for (int e = 0; e < RE; e++) u[e] = u[e] * inv * g[e];
  st16(c->blocks + (long)r * H + k0, u);
}

// ------------------------------------------------------------------------------------------------ attention residual mix
// sources: n rows of bf16 [H] (+ an addend on the last one, summed in fp32); NQ queries (pre-scaled); out [NQ][RE]
template <int NQ>
__device__ __forceinline__ void mix_row(const bf16* const* src, int n, const bf16* add, const float* qv, float (*out)[RE], float* red) {
  const int k0 = threadIdx.x * RE;
  float acc[10 * (1 + NQ)];
  float qq[NQ][RE];
#pragma unroll
  for (int q = 0; q < NQ; q++)
#pragma unroll
    for (int e = 0; e < RE; e += 4) {
      const float4 t = *reinterpret_cast<const float4*>(qv + (long)q * H + k0 + e);
      qq[q][e] = t.x; qq[q][e + 1] = t.y; qq[q][e + 2] = t.z; qq[q][e + 3] = t.w;
    }
  for (int s = 0; s < n; s++) {
    float v[RE], ss = 0.f, d[NQ];
    ld16(src[s] + k0, v);
    if (add && s == n - 1) {
      float a[RE];
      ld16(add + k0, a);
#pragma unroll
      for (int e = 0; e < RE; e++) v[e] += a[e];
    }
#pragma unroll
    for (int q = 0; q < NQ; q++) d[q] = 0.f;
#pragma unroll
    for (int e = 0; e < RE; e++) {
      ss += v[e] * v[e];
#pragma unroll
      for (int q = 0; q < NQ; q++) d[q] += v[e] * qq[q][e];
    }
    acc[s * (1 + NQ)] = ss;
#pragma unroll
    for (int q = 0; q < NQ; q++) acc[s * (1 + NQ) + 1 + q] = d[q];
  }
  block_sum_n(acc, n * (1 + NQ), red);
  float inv[10], p[NQ][10];
  for (int s = 0; s < n; s++) inv[s] = rsqrtf(acc[s * (1 + NQ)] / (float)H + 1e-6f);
#pragma unroll
  for (int q = 0; q < NQ; q++) {
    float m = -3.0e38f, sum = 0.f;
    for (int s = 0; s < n; s++) { p[q][s] = acc[s * (1 + NQ) + 1 + q] * inv[s]; m = fmaxf(m, p[q][s]); }
    for (int s = 0; s < n; s++) { p[q][s] = expf(p[q][s] - m); sum += p[q][s]; }
    for (int s = 0; s < n; s++) p[q][s] /= sum;
#pragma unroll
    for (int e = 0; e < RE; e++) out[q][e] = 0.f;
  }
  // second read of the sources (kept in registers they spill: measured 62 -> 97 us per layer at 2048 rows)
  for (int s = 0; s < n; s++) {
    float v[RE];
    ld16(src[s] + k0, v);
    if (add && s == n - 1) {
      float a[RE];
      ld16(add + k0, a);
#pragma unroll
      for (int e = 0; e < RE; e++) v[e] += a[e];
    }
#pragma unroll
    for (int e = 0; e < RE; e++) {
      const float x = v[e] * inv[s];
#pragma unroll
      for (int q = 0; q < NQ; q++) out[q][e] += p[q][s] * x;
    }
  }
}
// RMS norm with gain of NQ per-thread vectors (in place)
template <int NQ>
__device__ __forceinline__ void rms_rows(float (*u)[RE], const bf16* const* w, float eps, float* red) {
  const int k0 = threadIdx.x * RE;
  float ss[NQ];
#pragma unroll
  for (int q = 0; q < NQ; q++) {
    ss[q] = 0.f;
#pragma unroll
    for (int e = 0; e < RE; e++) ss[q] += u[q][e] * u[q][e];
  }
  block_sum_n(ss, NQ, red);
#pragma unroll
  for (int q = 0; q < NQ; q++) {
    const float inv = rsqrtf(ss[q] / (float)H + eps);
    float g[RE];
    ld16(w[q] + k0, g);
#pragma unroll
    for (int e = 0; e < RE; e++) u[q][e] = u[q][e] * inv * g[e];
  }
}

// attention input of layer i: mix of the finished blocks and the partial block, RMS norm -> xin (tile layout)
template <int NQ>
__global__ void __launch_bounds__(RT) k_mix_attn(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T) return;       // fixed-grid launches: no such row in this pass
  __shared__ float red[9 * 40];
  const int r = blockIdx.x, k0 = threadIdx.x * RE;
  const PLayer& L = c->L[i];
  const int nb = (i + 5) / 6;             // finished blocks; the partial block is blocks[nb]
  const long tm = c->tmax;
  float u[NQ][RE];
  if (i == 0) ld16(c->blocks + (long)r * H + k0, u[0]);
  else {
    const bf16* src[10];
    for (int s = 0; s <= nb; s++) src[s] = c->blocks + ((long)s * tm + r) * H;
    mix_row<NQ>(src, nb + 1, nullptr, L.aq, u, red);
  }
  const bf16* w[3] = {L.norm[0], L.norm[1], L.norm[2]};
  rms_rows<NQ>(u, w, c->eps, red);
#pragma unroll
  for (int q = 0; q < NQ; q++) st16t(reinterpret_cast<uint8_t*>(c->xin + (long)q * tm * H), r, k0, H / 16, u[q]);
}

// ------------------------------------------------------------------------------------------------ tensor-core GEMM
// Every GEMM of the model through tcgen05: D[128 rows x N columns] += A[128 x K step] B[K step x N] with the operands
// in shared memory, where the copy engine puts them (cp.async.bulk + mbarriers), and the accumulators in tensor memory.
//   bf16  (kind::f16):                    K step 16; attention projections, o_proj, router, unembedding
//   nvfp4 (kind::mxf4nvf4, block scales): K step 64; the checkpoint's E2M1 codes and E4M3 scales as stored, times the
//                                         model-defined quantized activations (codes + block scales)
//   mxfp8 (kind::mxf8f6f4, block scales): K step 32; E4M3 codes with UE8M0 scales
// A block takes (a tile of up to 128 columns, RG <= 3 row groups) and runs the K steps through a ring of stages in
// shared memory; a stage is G consecutive K steps: the B units and, per row group, G A units, each one bulk copy.
// Thread (warp 4) issues the copies of a stage as soon as its slot is free, thread (warp 5) the scale copies and
// MMAs, warps 0-3 read D from tensor memory and write the results. The ring is what is in flight from memory: the
// chain runs at the rate the SM can pull bytes (measured ~50 GB/s per SM), so the shapes maximise work per byte.
#define TC_RING 122880
#define TC_MAXS 8
#define TC_UB 4608
#define TC_BUB 4608
#define TC_SMEM (TC_RING + 1024)
__device__ __forceinline__ uint32_t sh(const void* p) { return (uint32_t)__cvta_generic_to_shared(p); }
__device__ __forceinline__ void mbar_init(uint32_t a, uint32_t cnt) { asm volatile("mbarrier.init.shared::cta.b64 [%0], %1;" :: "r"(a), "r"(cnt) : "memory"); }
__device__ __forceinline__ bool mbar_try(uint32_t a, uint32_t par) {
  uint32_t ok; asm volatile("{ .reg .pred p; mbarrier.try_wait.parity.shared::cta.b64 p, [%1], %2; selp.u32 %0, 1, 0, p; }" : "=r"(ok) : "r"(a), "r"(par) : "memory"); return ok; }
__device__ __forceinline__ void mbar_wait(uint32_t a, uint32_t par) { while (!mbar_try(a, par)) {} }
__device__ __forceinline__ void mbar_expect(uint32_t a, uint32_t bytes) { asm volatile("mbarrier.arrive.expect_tx.shared::cta.b64 _, [%0], %1;" :: "r"(a), "r"(bytes) : "memory"); }
__device__ __forceinline__ void mbar_arrive(uint32_t a) { asm volatile("mbarrier.arrive.shared::cta.b64 _, [%0];" :: "r"(a) : "memory"); }
__device__ __forceinline__ void tc_bulk(uint32_t dst, const void* src, uint32_t n, uint32_t bar) {
  asm volatile("cp.async.bulk.shared::cta.global.mbarrier::complete_tx::bytes [%0], [%1], %2, [%3];" :: "r"(dst), "l"(src), "r"(n), "r"(bar) : "memory"); }
__device__ __forceinline__ void tc_alloc(uint32_t smem_addr, uint32_t ncols) {
  asm volatile("tcgen05.alloc.cta_group::1.sync.aligned.shared::cta.b32 [%0], %1;" :: "r"(smem_addr), "r"(ncols) : "memory");
  asm volatile("tcgen05.relinquish_alloc_permit.cta_group::1.sync.aligned;" ::: "memory"); }
__device__ __forceinline__ void tc_dealloc(uint32_t taddr, uint32_t ncols) { asm volatile("tcgen05.dealloc.cta_group::1.sync.aligned.b32 %0, %1;" :: "r"(taddr), "r"(ncols) : "memory"); }
__device__ __forceinline__ void tc_cp(uint32_t taddr, uint64_t desc) { asm volatile("tcgen05.cp.cta_group::1.32x128b.warpx4 [%0], %1;" :: "r"(taddr), "l"(desc) : "memory"); }
__device__ __forceinline__ void tc_mma_fp4(uint32_t td, uint64_t da, uint64_t db, uint32_t idesc, uint32_t acc, uint32_t tsfa, uint32_t tsfb) {
  asm volatile("{ .reg .pred p; setp.ne.b32 p, %4, 0; tcgen05.mma.cta_group::1.kind::mxf4nvf4.block_scale.scale_vec::4X [%0], %1, %2, %3, [%5], [%6], p; }"
               :: "r"(td), "l"(da), "l"(db), "r"(idesc), "r"(acc), "r"(tsfa), "r"(tsfb) : "memory"); }
__device__ __forceinline__ void tc_mma_fp8(uint32_t td, uint64_t da, uint64_t db, uint32_t idesc, uint32_t acc, uint32_t tsfa, uint32_t tsfb) {
  asm volatile("{ .reg .pred p; setp.ne.b32 p, %4, 0; tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X [%0], %1, %2, %3, [%5], [%6], p; }"
               :: "r"(td), "l"(da), "l"(db), "r"(idesc), "r"(acc), "r"(tsfa), "r"(tsfb) : "memory"); }
__device__ __forceinline__ void tc_mma_bf16(uint32_t td, uint64_t da, uint64_t db, uint32_t idesc, uint32_t acc) {
  asm volatile("{ .reg .pred p; setp.ne.b32 p, %4, 0; tcgen05.mma.cta_group::1.kind::f16 [%0], %1, %2, %3, p; }"
               :: "r"(td), "l"(da), "l"(db), "r"(idesc), "r"(acc) : "memory"); }
__device__ __forceinline__ void tc_commit(uint32_t bar) { asm volatile("tcgen05.commit.cta_group::1.mbarrier::arrive::one.shared::cluster.b64 [%0];" :: "r"(bar) : "memory"); }
__device__ __forceinline__ void tc_fence_after() { asm volatile("tcgen05.fence::after_thread_sync;" ::: "memory"); }
__device__ __forceinline__ void tc_fence_before() { asm volatile("tcgen05.fence::before_thread_sync;" ::: "memory"); }
__device__ __forceinline__ void fence_async() { asm volatile("fence.proxy.async.shared::cta;" ::: "memory"); }
__device__ __forceinline__ void tc_ld8(uint32_t taddr, float* d) {
  uint32_t r[8];
  asm volatile("tcgen05.ld.sync.aligned.32x32b.x8.b32 {%0,%1,%2,%3,%4,%5,%6,%7}, [%8];"
               : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]), "=r"(r[4]), "=r"(r[5]), "=r"(r[6]), "=r"(r[7]) : "r"(taddr) : "memory");
  asm volatile("tcgen05.wait::ld.sync.aligned;" ::: "memory");
#pragma unroll
  for (int j = 0; j < 8; j++) d[j] = __uint_as_float(r[j]);
}
__device__ __forceinline__ uint64_t tc_sdesc(uint32_t addr, uint32_t lbo, uint32_t sbo) {   // shared memory descriptor: K-major, no swizzle
  return (uint64_t)((addr & 0x3FFFF) >> 4) | ((uint64_t)(lbo >> 4) << 16) | ((uint64_t)(sbo >> 4) << 32) | (1ull << 46);
}
enum { TK_FP4 = 0, TK_FP8 = 1, TK_BF16 = 2 };
enum { G_QKV = 0, G_OPROJ = 1, G_ROUTER = 2, G_UNEMBED = 3, G_W13 = 4, G_W2 = 5, G_RELB = 6 };
#define QKV_RGA 26
// chunks of RG row groups; a chunk of the q/k/v matrix never mixes rows that take different inputs
__host__ __device__ inline int tc_nchunks(int which, int glob, int nrg, int RG) {
  if (which == G_QKV) { const int nb = glob ? 3 : 2; return (QKV_RGA + RG - 1) / RG + 2 * ((nb + RG - 1) / RG); }
  return (nrg + RG - 1) / RG;
}
__device__ __forceinline__ void tc_ld16(uint32_t taddr, float* d) {
  uint32_t r[16];
  asm volatile("tcgen05.ld.sync.aligned.32x32b.x16.b32 {%0,%1,%2,%3,%4,%5,%6,%7,%8,%9,%10,%11,%12,%13,%14,%15}, [%16];"
               : "=r"(r[0]), "=r"(r[1]), "=r"(r[2]), "=r"(r[3]), "=r"(r[4]), "=r"(r[5]), "=r"(r[6]), "=r"(r[7]),
                 "=r"(r[8]), "=r"(r[9]), "=r"(r[10]), "=r"(r[11]), "=r"(r[12]), "=r"(r[13]), "=r"(r[14]), "=r"(r[15]) : "r"(taddr) : "memory");
  asm volatile("tcgen05.wait::ld.sync.aligned;" ::: "memory");
#pragma unroll
  for (int j = 0; j < 16; j++) d[j] = __uint_as_float(r[j]);
}
// row groups per block of a GEMM: experts `rg` (their scale columns leave room for three in tensor memory), dense
// ones `rgd` (four fill the 512 columns: a 2048-row pass then has 144 block-units for q/k/v and for o_proj, one
// round on 148 SMs); the router's three row groups go to three blocks
__host__ __device__ inline int tc_rg(int which, int rg, int rgd) { return which == G_ROUTER ? 1 : ((which == G_W13 || which == G_W2) ? rg : rgd); }
// small passes (one row group per block): the dense GEMMs run 64-row MMAs, two blocks per row group, so that twice
// as many SMs pull the weights (a 128-row unit is two 64-row units one after the other)
__host__ __device__ inline int tc_half(int which, int rg) { return rg == 1 && which <= G_UNEMBED; }
__host__ __device__ inline int tc_units(int which, int glob, int nrg, int rg, int rgd) {
  return tc_nchunks(which, glob, nrg, tc_rg(which, rg, rgd)) * (tc_half(which, rg) ? 2 : 1);
}
template <int KIND, int WHICH>
__global__ void __launch_bounds__(288) k_tc(const PCtx* c, int i) {
  extern __shared__ __align__(1024) uint8_t sm[];
  const int tid = threadIdx.x, w = tid >> 5, lane = tid & 31;
  uint64_t* bars = reinterpret_cast<uint64_t*>(sm + TC_RING);
  const uint32_t b_full = sh(bars), b_empty = sh(bars + TC_MAXS), b_done = sh(bars + 2 * TC_MAXS);
  uint32_t* tptr = reinterpret_cast<uint32_t*>(bars + 2 * TC_MAXS + 1);
  float* colf = reinterpret_cast<float*>(bars + 2 * TC_MAXS + 2);
  const PLayer& L = c->L[WHICH == G_UNEMBED ? 0 : i];
  const bool expert = WHICH == G_W13 || WHICH == G_W2;
  const int me = c->card, RG = tc_rg(WHICH, c->h.rg, c->h.rgd);
  const bool HM = KIND == TK_BF16 && tc_half(WHICH, c->h.rg);
  const long tm = c->tmax, pm = c->pmax;
  const int UB = KIND == TK_BF16 ? 4096 : 4608, BUB = KIND == TK_BF16 ? 4096 : 4608;
  int NRG, KS, T = c->h.T;
  const uint8_t* W; const uint8_t* Xt;
  if (WHICH == G_QKV) { NRG = L.glob ? 32 : 30; KS = 288; W = L.wqkv; Xt = reinterpret_cast<const uint8_t*>(c->xin); }
  else if (WHICH == G_OPROJ) { NRG = 36; KS = 384; W = L.wo; Xt = reinterpret_cast<const uint8_t*>(c->xo); }
  else if (WHICH == G_ROUTER) { NRG = 3; KS = 288; W = L.wr; Xt = reinterpret_cast<const uint8_t*>(c->mlp_inx); }
  else if (WHICH == G_UNEMBED) { NRG = c->un_strips; KS = 288; W = c->unembed; Xt = reinterpret_cast<const uint8_t*>(c->hfin); T = c->h.nlog; }
  else if (WHICH == G_RELB) { NRG = 8; KS = 1; W = L.relp; Xt = c->rt; T = c->h.T * NQL; }
  else if (WHICH == G_W13) { NRG = 36; KS = KIND == TK_FP4 ? 72 : 144; W = L.w13; Xt = c->xt13; }
  else { NRG = 36; KS = KIND == TK_FP4 ? 36 : 72; W = L.w2; Xt = c->xt2; }
  // stage geometry: G K steps; B slots at 0 (bsl bytes each), then the A slots (asl bytes each): row group r, step g
  // at aoff + (r * G + g) * asl. Small passes (at most 16 columns per tile, one row group per block) use short
  // slots, so that the ring holds 8 stages: the chain is then bound by what is in flight, not by slot count.
  const bool small = c->h.rg == 1 && WHICH != G_RELB;
  const int G = KS == 1 ? 1 : (RG == 1 ? (KIND == TK_BF16 ? 4 : 2) : (KIND == TK_BF16 ? 2 : 1));
  const uint32_t bsl = small ? (KIND == TK_BF16 ? 512 : 1024) : BUB, sfo = small ? 512 : 4096;   // B slot, offset of its scale atom
  const uint32_t asl = HM ? 2048 : UB;
  const uint32_t aoff = G * bsl, stg = G * (bsl + RG * asl);
  const uint32_t S = min((uint32_t)TC_MAXS, (uint32_t)TC_RING / stg);
  const int nstage = KS / G;
  const int ntiles = expert ? c->ginfo[me * 4] : (T + COLT - 1) / COLT;
  const int nch = tc_nchunks(WHICH, WHICH == G_QKV ? L.glob : 0, NRG, RG) * (HM ? 2 : 1);
  const long total = (long)ntiles * nch;
  if (blockIdx.x >= total || (WHICH == G_UNEMBED && !c->h.mode)) return;       // nothing for this block (fixed-grid launches)
  // one consumer thread per row group (warps 5 .. 5 + RG - 1): the scale copies and the MMA of a row group are a
  // serial path of ~0.1 us per operation, so the row groups of a stage are issued side by side. A stage's slot is
  // free, and the block-unit done, when every consumer has said so: those barriers count RG arrivals.
  const int RGc = RG;
  if (tid < TC_MAXS) mbar_init(sh(bars + tid), 1);
  else if (tid < 2 * TC_MAXS + 1) mbar_init(sh(bars + tid), RGc);
  __syncthreads();
  if (w == 0) tc_alloc(sh(tptr), 512);
  __syncthreads();
  fence_async();
  const uint32_t t = *tptr;
  uint32_t slot = 0, par = (w == 4) ? 1 : 0, dpar = 0;      // ring position of the producer / consumer; parity of `done`
  for (long bu = blockIdx.x; bu < total; bu += gridDim.x) {
    const int tile = (int)(bu / nch), half = HM ? (int)(bu % nch) & 1 : 0, ch = (int)(bu % nch) >> (HM ? 1 : 0);
    int rg0, nrg, sel = 0;
    if (WHICH == G_QKV) {
      const int nA = (QKV_RGA + RG - 1) / RG, nb = L.glob ? 3 : 2, nB = (nb + RG - 1) / RG;
      if (ch < nA) { rg0 = ch * RG; nrg = min(RG, QKV_RGA - rg0); }
      else if (ch < nA + nB) { const int o = (ch - nA) * RG; rg0 = QKV_RGA + o; nrg = min(RG, nb - o); sel = L.glob ? 1 : 0; }
      else { const int o = (ch - nA - nB) * RG; rg0 = QKV_RGA + nb + o; nrg = min(RG, nb - o); sel = L.glob ? 2 : 0; }
    } else { rg0 = ch * RG; nrg = min(RG, NRG - rg0); }
    int ncols, e = 0, p0 = 0;
    if (expert) {
      const int* it = c->items + ((long)me * pm + tile) * 4;
      e = it[0]; p0 = it[1]; ncols = it[2];
      const int eg = it[3];
      if (KIND == TK_FP4)
        for (int k = tid; k < COLT; k += blockDim.x) {
          const int pair = p0 + min(k, ncols - 1);
          colf[k] = (WHICH == G_W2 ? c->aouter[pair] : c->xouter[c->ptok[me * pm + pair]]) * (WHICH == G_W2 ? L.f2 : L.f13)[eg];
        }
    } else ncols = min(COLT, T - tile * COLT);
    const int ncg = (ncols + 7) >> 3;
    const uint8_t* Wb = W + ((long)(expert ? e * NRG : 0) + rg0) * KS * UB;
    const uint8_t* Xb = Xt + (WHICH == G_QKV ? (long)sel * tm * H * 2 : 0) + (long)tile * KS * BUB;
    __syncthreads();
    if (w == 4 && lane == 0) {            // producer: the next stage's operands, as soon as its slot is free
      const uint32_t bcp = ncg * 256;       // bytes of a B unit that hold columns
      const bool whole = ncg == 16 && !small;
      const uint32_t bbytes = whole ? G * BUB : G * (bcp + (KIND == TK_BF16 ? 0 : 512));
      for (int st = 0; st < nstage; st++) {
        mbar_wait(b_empty + 8 * slot, par);
        const uint32_t dst = sh(sm) + slot * stg, bf_ = b_full + 8 * slot;
        mbar_expect(bf_, bbytes + (HM ? G * 2048 : nrg * G * UB));
        const uint8_t* xs = Xb + (long)st * G * BUB;
        if (whole) tc_bulk(dst, xs, G * BUB, bf_);
        else
          for (int g = 0; g < G; g++) {
            tc_bulk(dst + g * bsl, xs + g * BUB, bcp, bf_);
            if (KIND != TK_BF16) tc_bulk(dst + g * bsl + sfo, xs + g * BUB + 4096, 512, bf_);
          }
        if (HM) for (int g = 0; g < G; g++) tc_bulk(dst + aoff + g * asl, Wb + ((long)st * G + g) * UB + half * 2048, 2048, bf_);
        else for (int r = 0; r < nrg; r++) tc_bulk(dst + aoff + r * G * asl, Wb + ((long)r * KS + (long)st * G) * UB, G * UB, bf_);
        if (++slot == S) { slot = 0; par ^= 1; }
      }
    } else if (w >= 5 && w < 5 + RG && lane == 0) {     // consumer of row group w - 5: scale copies and MMAs
      const int r = w - 5;
      const uint32_t t_sfa = t + 384 + 4 * r, t_sfb = t + 396 + 4 * r;
      tc_fence_after();
      const uint32_t idesc = KIND == TK_FP4 ? ((1u << 7) | (1u << 10) | ((uint32_t)ncg << 17) | (8u << 24))
                           : KIND == TK_FP8 ? ((1u << 23) | ((uint32_t)ncg << 17) | (8u << 24))
                           : ((1u << 4) | (1u << 7) | (1u << 10) | ((uint32_t)ncg << 17) | ((HM ? 4u : 8u) << 24));
      const uint64_t hi = tc_sdesc(0, 128, 256), his = tc_sdesc(0, 0, 128);
      uint32_t accf = 0;
      for (int st = 0; st < nstage; st++) {
        mbar_wait(b_full + 8 * slot, par);
        if (r < nrg) {
          const uint32_t base = sh(sm) + slot * stg;
          for (int g = 0; g < G; g++) {
            const uint32_t bb = (base + g * bsl) >> 4;
            const uint64_t db = hi | bb;
            const uint32_t a = (base + aoff + (r * G + g) * asl) >> 4;
            if (KIND == TK_FP4) { tc_cp(t_sfb, his | (bb + (sfo >> 4))); tc_cp(t_sfa, his | (a + 256)); tc_mma_fp4(t + r * COLT, hi | a, db, idesc, accf, t_sfa, t_sfb); }
            else if (KIND == TK_FP8) { tc_cp(t_sfb, his | (bb + (sfo >> 4))); tc_cp(t_sfa, his | (a + 256)); tc_mma_fp8(t + r * COLT, hi | a, db, idesc, accf, t_sfa, t_sfb); }
            else tc_mma_bf16(t + r * COLT, hi | a, db, idesc, accf);
            accf = 1;
          }
          tc_commit(b_empty + 8 * slot);
        } else mbar_arrive(b_empty + 8 * slot);
        if (++slot == S) { slot = 0; par ^= 1; }
      }
      if (r < nrg) tc_commit(b_done); else mbar_arrive(b_done);
    }
    if (w < 4) {                          // readers: D of this block-unit
      mbar_wait(b_done, dpar);
      tc_fence_after();
      // a 64-row MMA keeps its rows in lanes 0-15 of the four warps
      const int rin = HM ? w * 16 + lane + half * 64 : w * 32 + lane;
      for (int r = 0; r < nrg; r++) {
        const int rg = rg0 + r;
        for (int cq = 0; cq * 2 < ncg; cq++) {
          float d[16];
          tc_ld16(t + r * COLT + cq * 16 + ((uint32_t)(w * 32) << 16), d);
#pragma unroll
          for (int j = 0; j < 16; j++) {
            const int col = cq * 16 + j;
            const bool dead = HM && lane >= 16;       // a 64-row MMA has no row in this lane
            if (col >= ncols || (dead && WHICH != G_UNEMBED)) continue;
            float v = d[j];
            if (WHICH == G_W13 || WHICH == G_W2) {
              if (KIND == TK_FP4) v *= colf[col];
              (WHICH == G_W2 ? c->pairout : c->h13)[(long)(p0 + col) * H + rg * 128 + rin] = tobf(v);
            } else {
              const int tok = tile * COLT + col;
              if (WHICH == G_QKV) {
                const int nb = L.glob ? 3 : 2;
                int n, lim;
                if (rg < QKV_RGA) { n = rg * 128 + rin; lim = QK; }
                else if (rg < QKV_RGA + nb) { n = (rg - QKV_RGA) * 128 + rin; lim = L.glob ? 272 : 256; n += QK; lim += QK; }
                else { n = (rg - QKV_RGA - nb) * 128 + rin; lim = L.glob ? 272 : 256; n += QK + lim; lim = QK + 2 * lim; }
                if (n < lim) c->qkvo[(long)tok * 3824 + n] = tobf(v);
              } else if (WHICH == G_OPROJ) c->attn_raw[(long)tok * H + rg * 128 + rin] = tobf(v);
              else if (WHICH == G_RELB) c->relb[(long)tok * RELEXT + rg * 128 + rin] = tobf(v);
              else if (WHICH == G_ROUTER) c->rlog[(long)tok * NE + rg * 128 + rin] = v;
              else {
                const int vid = c->un_row0 + rg * 128 + rin;
                const bool real = !dead && vid < VOCAB_REAL && rg * 128 + rin < 201024 / NCARD;
                const float z = 30.0f * tanhf(v / 30.0f);
                if (c->h.mode == 1) { if (real) c->h.logits[(long)tok * VOCAB_REAL + vid] = z; }
                else {
                  // candidate of this column: the warp's best (soft-capped logit, then the lower token id), one atomic
                  unsigned bits = __float_as_uint(z);
                  bits = (bits & 0x80000000u) ? ~bits : (bits | 0x80000000u);
                  unsigned long long key = real ? (((unsigned long long)bits << 32) | (0xFFFFFFFFu - (unsigned)vid)) : 0ull;
#pragma unroll
                  for (int off = 16; off; off >>= 1) { const unsigned long long o2 = __shfl_xor_sync(0xffffffff, key, off); key = o2 > key ? o2 : key; }
                  if (lane == 0) atomicMax(&c->cand[tok], key);
                }
              }
            }
          }
        }
      }
      tc_fence_before();
      dpar ^= 1;
    }
    __syncthreads();
  }
  if (w == 0) tc_dealloc(t, 512);
}

// ------------------------------------------------------------------------------------------------ K/V, q, relative bias
__device__ __forceinline__ long kaddr(int pos, int kv, int f) {   // byte offset of K[pos][kv][f] inside its page
  const int chunk = (pos & (PAGE - 1)) >> 4, kk = pos & 15;
  const int ng = kk >> 3, g = kk & 7, j = f >> 4, t = (f & 7) >> 1, e = (f & 1) + 2 * ((f >> 3) & 1);
  return ((long)(kv * 32 + chunk)) * 4096 + ((((ng * 8 + g) * 4 + t) * 8 + j) * 4 + e) * 2;
}
__device__ __forceinline__ long vaddr(int pos, int kv, int f) {
  const int chunk = (pos & (PAGE - 1)) >> 4, kk = pos & 15;
  const int t = (kk & 7) >> 1, e = (kk & 1) + 2 * (kk >> 3), fg = f >> 3, g = f & 7;
  return ((long)(kv * 32 + chunk)) * 4096 + (((g * 4 + t) * 16 + fg) * 4 + e) * 2;
}
// raw short-convolution input of row r at lag j (0 = the row itself): the pass's own rows, then the slot's state
__device__ __forceinline__ float raw_at(const bf16* rows, long stride, int r, int j, int back, const bf16* hist, int ch, int hch) {
  if (j <= back) return bf(rows[(long)(r - j) * stride + ch]);
  return bf(hist[(long)(3 - (j - back)) * HS + hch]);
}

__global__ void __launch_bounds__(NTB) k_prep(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T) return;       // fixed-grid launches: no such row in this pass
  __shared__ float red[8 * 8];
  const int r = blockIdx.x, tid = threadIdx.x, w = tid >> 5;
  const PLayer& L = c->L[i];
  const int slot = TAB(o_slot)[r], pos = TAB(o_pos)[r], back = TAB(o_back)[r];
  const bf16* q = c->qkvo + (long)r * 3824;
  const bf16* hist = c->hist + ((long)slot * NL + i) * 3 * HS;
  const int V0 = QK + (L.glob ? 272 : 256);
  const int page = TAB(o_pt)[slot * MAXPG + (pos >> 9)];
  float tau = 1.0f;
  if (L.glob) tau = 1.0f + 0.1f * logf(fmaxf(((float)pos + 1.0f) / 128000.0f, 1.0f));
  // K and V: thread = channel (2 heads x 128)
  float y[2], ssk[2];
#pragma unroll
  for (int kvsel = 0; kvsel < 2; kvsel++) {
    const int base = kvsel ? V0 : QK, hoff = kvsel ? 256 : 0, head = tid >> 7;
    const bf16* sc = kvsel ? L.vsc : L.ksc;
    float x[4];
#pragma unroll
    for (int j = 0; j < 4; j++) x[j] = raw_at(c->qkvo + base, 3824, r, j, back, hist, tid, hoff + tid);
    float v;
    if (L.glob) {
      float acc = 0.f;
#pragma unroll
      for (int j = 0; j < 4; j++) acc = acc + x[j] * (bf(sc[j * 256 + tid]) + bf(q[base + 256 + head * 4 + j]));
      v = (acc + x[0]) * 0.3333333333333333f;
    } else {
      float acc = 0.f;
#pragma unroll
      for (int tap = 0; tap < 4; tap++) acc = acc + x[3 - tap] * bf(sc[tid * 4 + tap]);
      v = (acc + x[0]) * 0.4472135954999579f;
    }
    y[kvsel] = bf(tobf(v));
    float ss = y[kvsel] * y[kvsel];
#pragma unroll
    for (int off = 16; off; off >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, off);
    ssk[kvsel] = ss;
  }
  if ((tid & 31) == 0) { red[w] = ssk[0]; red[8 + w] = ssk[1]; }
  // q: thread = (head pair hp, feature) for six head pairs
  float qv[NQL / 2], qs[NQL / 2];
#pragma unroll
  for (int hp = 0; hp < NQL / 2; hp++) {
    const int head = hp * 2 + (tid >> 7), f = tid & 127;
    qv[hp] = bf(q[head * HD + f]) * bf(L.qscale[head * HD + f]);
    float ss = qv[hp] * qv[hp];
#pragma unroll
    for (int off = 16; off; off >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, off);
    qs[hp] = ss;
  }
  if ((tid & 31) == 0) {
#pragma unroll
    for (int hp = 0; hp < NQL / 2; hp++) red[16 + hp * 8 + w] = qs[hp];
  }
  __syncthreads();
  {
    const int hh = tid >> 7, head = hh, f = tid & 127;
    const float sk = (red[hh * 4] + red[hh * 4 + 1]) + (red[hh * 4 + 2] + red[hh * 4 + 3]);
    const float sv = (red[8 + hh * 4] + red[8 + hh * 4 + 1]) + (red[8 + hh * 4 + 2] + red[8 + hh * 4 + 3]);
    const float fac = fminf(22.627416997969522f / (sqrtf(sk) + 1e-6f), 1.0f);
    *reinterpret_cast<bf16*>(L.kpg + (long)page * 262144 + kaddr(pos, head, f)) = tobf(y[0] * fac);
    *reinterpret_cast<bf16*>(L.vpg + (long)page * 262144 + vaddr(pos, head, f)) = tobf(y[1] * rsqrtf(sv / 128.0f + c->eps));
#pragma unroll
    for (int hp = 0; hp < NQL / 2; hp++) {
      const float* rq = red + 16 + hp * 8 + hh * 4;
      const float ss = (rq[0] + rq[1]) + (rq[2] + rq[3]);
      bf16 o = tobf(qv[hp] * fminf(22.627416997969522f / (sqrtf(ss) + 1e-6f), 1.0f));
      if (L.glob) o = tobf(bf(o) * tau);
      c->qn[((long)r * NQL + hp * 2 + hh) * HD + f] = o;
    }
  }
  // r: 12 heads x 16, clipped, as column (row * 12 + head) of the bias GEMM's input
  if (tid < NQL * DREL) {
    const int head = tid >> 4, k = tid & 15, col = r * NQL + head, n = col & 127;
    const float v = bf(q[QR + tid]) * bf(L.rscale[tid]);
    float ss = v * v;
#pragma unroll
    for (int off = 8; off; off >>= 1) ss += __shfl_xor_sync(0xffffffff, ss, off);
    bf16 o = tobf(v * fminf(8.0f / (sqrtf(ss) + 1e-6f), 1.0f));
    if (L.glob) o = tobf(bf(o) * tau);
    *reinterpret_cast<bf16*>(c->rt + (long)(col >> 7) * 4096 + (n >> 3) * 256 + (k >> 3) * 128 + (n & 7) * 16 + (k & 7) * 2) = o;
  }
}

// ------------------------------------------------------------------------------------------------ attention
// A unit = (group of up to 16 consecutive rows of one sequence, q head, one page of keys); one warp per unit.
// group record: row0, n, slot, pos0, pgL0, npgL, ubaseL, ubaseG  (global: pages 0 .. npgG-1 with npgG = (pos0+n-1)/512+1)
#define GRPW 8
__global__ void __launch_bounds__(192) k_attn_seg(const PCtx* c, int i) {
  const int lane = threadIdx.x & 31, g = lane >> 2, t = lane & 3;
  const PLayer& L = c->L[i];
  const int nwarp = gridDim.x * (blockDim.x >> 5);
  const int total = L.glob ? c->h.unitsG : c->h.unitsL;
  const int* grp = TAB(o_grp);
  const int ngrp = c->h.ngrp;
  for (int u = blockIdx.x * (blockDim.x >> 5) + (threadIdx.x >> 5); u < total; u += nwarp) {
    // group of this unit: the last group whose base is <= u
    int lo = 0, hi = ngrp - 1;
    while (lo < hi) {
      const int mid = (lo + hi + 1) >> 1;
      if (grp[mid * GRPW + (L.glob ? 7 : 6)] <= u) lo = mid; else hi = mid - 1;
    }
    const int* G = grp + lo * GRPW;
    // a group is up to 16 consecutive rows of a sequence (one unit per head and page: the MMA's rows are the rows),
    // or one row "packed" (bit 8 of n: one unit per KV head and page: the MMA's rows are that row's six heads)
    const int row0 = G[0], packed = G[1] >> 8, n = G[1] & 255, slot = G[2], pos0 = G[3];
    const int pg0 = L.glob ? 0 : G[4], npg = L.glob ? ((pos0 + n - 1) >> 9) + 1 : G[5];
    // units of a group are page-major: the six heads of a KV head on one page are neighbours, so a block of six
    // warps reads each K/V chunk from memory once (the other five warps find it in the L1)
    const int upp = packed ? 2 : NQL, rel = u - G[L.glob ? 7 : 6];
    if (rel >= upp * npg) continue;       // padding between groups
    const int hk = rel % upp, pi = pg0 + rel / upp;
    const int kv = packed ? hk : hk / 6;
    const int page = TAB(o_pt)[slot * MAXPG + pi];
    const uint8_t* kp = L.kpg + (long)page * 262144 + (long)kv * 131072;
    const uint8_t* vp = L.vpg + (long)page * 262144 + (long)kv * 131072;
    // the lane's two MMA rows (g, g+8): (row of the pass, head)
    const int r0 = packed ? row0 : row0 + g, r1 = packed ? row0 : row0 + g + 8;
    const int h0 = packed ? kv * 6 + g : hk, h1 = packed ? kv * 6 : hk;
    const bool rv0 = packed ? g < 6 : g < n, rv1 = packed ? false : g + 8 < n;
    const int p0r = packed ? pos0 : pos0 + g, p1r = packed ? pos0 : pos0 + g + 8;   // positions of the two rows
    uint32_t qa[8][4];
    {
      const bf16* q0 = c->qn + ((long)r0 * NQL + h0) * HD;
      const bf16* q1 = c->qn + ((long)r1 * NQL + h1) * HD;
#pragma unroll
      for (int j = 0; j < 8; j++) {
        qa[j][0] = rv0 ? *reinterpret_cast<const uint32_t*>(q0 + 16 * j + 2 * t) : 0u;
        qa[j][1] = rv1 ? *reinterpret_cast<const uint32_t*>(q1 + 16 * j + 2 * t) : 0u;
        qa[j][2] = rv0 ? *reinterpret_cast<const uint32_t*>(q0 + 16 * j + 2 * t + 8) : 0u;
        qa[j][3] = rv1 ? *reinterpret_cast<const uint32_t*>(q1 + 16 * j + 2 * t + 8) : 0u;
      }
    }
    const bf16* rb0 = c->relb + ((long)r0 * NQL + h0) * RELEXT;
    const bf16* rb1 = c->relb + ((long)r1 * NQL + h1) * RELEXT;
    float m0 = -1.0e30f, m1 = -1.0e30f, l0 = 0.f, l1 = 0.f;
    float acc[16][4];
#pragma unroll
    for (int fg = 0; fg < 16; fg++) { acc[fg][0] = acc[fg][1] = acc[fg][2] = acc[fg][3] = 0.f; }
    const int plast = pos0 + n - 1;
    for (int ch = 0; ch < 32; ch++) {
      const int j0 = pi * PAGE + ch * 16;
      if (j0 > plast) break;
      if (!L.glob && j0 + 15 < pos0 - (WIN - 1)) continue;
      // scores of 16 keys
      float s[2][4];
#pragma unroll
      for (int ng = 0; ng < 2; ng++) {
        s[ng][0] = s[ng][1] = s[ng][2] = s[ng][3] = 0.f;
        const uint8_t* kb = kp + (long)ch * 4096 + ((ng * 8 + g) * 4 + t) * 64;
#pragma unroll
        for (int jj = 0; jj < 4; jj++) {
          const uint4 b = ld4(kb + jj * 16);
          mma_bf16(s[ng], qa[2 * jj][0], qa[2 * jj][1], qa[2 * jj][2], qa[2 * jj][3], b.x, b.y);
          mma_bf16(s[ng], qa[2 * jj + 1][0], qa[2 * jj + 1][1], qa[2 * jj + 1][2], qa[2 * jj + 1][3], b.z, b.w);
        }
      }
      bool ok[2][4];
      float cm0 = -1.0e30f, cm1 = -1.0e30f;
#pragma unroll
      for (int ng = 0; ng < 2; ng++) {
#pragma unroll
        for (int e = 0; e < 4; e++) {
          const int key = j0 + ng * 8 + 2 * t + (e & 1);
          const int pr = (e >> 1) ? p1r : p0r;
          const int dist = pr - key;
          const bool valid = ((e >> 1) ? rv1 : rv0) && dist >= 0 && (L.glob || dist < WIN);
          float sc = s[ng][e] * 0.08838834764831845f;
          if (valid && dist < RELEXT) sc += bf(((e >> 1) ? rb1 : rb0)[dist]);
          ok[ng][e] = valid;
          s[ng][e] = valid ? sc : -1.0e30f;
          if (e >> 1) cm1 = fmaxf(cm1, s[ng][e]); else cm0 = fmaxf(cm0, s[ng][e]);
        }
      }
      cm0 = fmaxf(cm0, __shfl_xor_sync(0xffffffff, cm0, 1)); cm0 = fmaxf(cm0, __shfl_xor_sync(0xffffffff, cm0, 2));
      cm1 = fmaxf(cm1, __shfl_xor_sync(0xffffffff, cm1, 1)); cm1 = fmaxf(cm1, __shfl_xor_sync(0xffffffff, cm1, 2));
      const float n0 = fmaxf(m0, cm0), n1 = fmaxf(m1, cm1);
      if (__any_sync(0xffffffff, n0 > m0 || n1 > m1)) {
        const float f0 = expf(m0 - n0), f1 = expf(m1 - n1);
        l0 *= f0; l1 *= f1;
#pragma unroll
        for (int fg = 0; fg < 16; fg++) { acc[fg][0] *= f0; acc[fg][1] *= f0; acc[fg][2] *= f1; acc[fg][3] *= f1; }
        m0 = n0; m1 = n1;
      }
      // probabilities relative to the running maximum, rounded to bf16 (the P fragments of the V product)
      uint32_t pa[4];
      float ps0 = 0.f, ps1 = 0.f;
#pragma unroll
      for (int ng = 0; ng < 2; ng++) {
        float p[4];
#pragma unroll
        for (int e = 0; e < 4; e++) p[e] = ok[ng][e] ? bf(tobf(expf(s[ng][e] - ((e >> 1) ? m1 : m0)))) : 0.f;
        ps0 += p[0] + p[1]; ps1 += p[2] + p[3];
        const __nv_bfloat162 x0 = __floats2bfloat162_rn(p[0], p[1]), x1 = __floats2bfloat162_rn(p[2], p[3]);
        pa[ng * 2] = *reinterpret_cast<const uint32_t*>(&x0);
        pa[ng * 2 + 1] = *reinterpret_cast<const uint32_t*>(&x1);
      }
      ps0 += __shfl_xor_sync(0xffffffff, ps0, 1); ps0 += __shfl_xor_sync(0xffffffff, ps0, 2);
      ps1 += __shfl_xor_sync(0xffffffff, ps1, 1); ps1 += __shfl_xor_sync(0xffffffff, ps1, 2);
      l0 += ps0; l1 += ps1;
      const uint8_t* vb = vp + (long)ch * 4096 + (g * 4 + t) * 128;
#pragma unroll
      for (int k8 = 0; k8 < 8; k8++) {
        const uint4 b = ld4(vb + k8 * 16);
        mma_bf16(acc[2 * k8], pa[0], pa[1], pa[2], pa[3], b.x, b.y);
        mma_bf16(acc[2 * k8 + 1], pa[0], pa[1], pa[2], pa[3], b.z, b.w);
      }
    }
    // record: rows (g, g+8), features 8 fg + 2t, +1
    float* rec0 = c->apart + ((long)u * 16 + g) * APW;
    float* rec1 = rec0 + 8 * APW;
    if (t == 0) { rec0[0] = m0; rec0[1] = l0; rec1[0] = m1; rec1[1] = l1; }
#pragma unroll
    for (int fg = 0; fg < 16; fg++) {
      *reinterpret_cast<float2*>(rec0 + 2 + fg * 8 + 2 * t) = make_float2(acc[fg][0], acc[fg][1]);
      *reinterpret_cast<float2*>(rec1 + 2 + fg * 8 + 2 * t) = make_float2(acc[fg][2], acc[fg][3]);
    }
  }
}

// fold a row's segments in page order, apply the sink and the output gate
__global__ void __launch_bounds__(128) k_attn_fold(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T) return;       // fixed-grid launches: no such row in this pass
  __shared__ float fac[NQL][MAXPG], sm_l[NQL], sm_m[NQL];
  const int r = blockIdx.x, tid = threadIdx.x;
  const PLayer& L = c->L[i];
  const int* grp = TAB(o_grp);
  int lo = 0, hi = c->h.ngrp - 1;
  while (lo < hi) {
    const int mid = (lo + hi + 1) >> 1;
    if (grp[mid * GRPW] <= r) lo = mid; else hi = mid - 1;
  }
  const int* G = grp + lo * GRPW;
  const int packed = G[1] >> 8, gn = G[1] & 255;
  const int rr = r - G[0], npg = L.glob ? ((G[3] + gn - 1) >> 9) + 1 : G[5], ubase = G[L.glob ? 7 : 6];
  const int upp = packed ? 2 : NQL;     // units per page
  const long sstep = (long)upp * 16 * APW;
  const bf16* q = c->qkvo + (long)r * 3824;
  if (tid < NQL) {                      // thread = head: its maximum over the pages, the pages' factors, the sum
    const float* rec = packed ? c->apart + ((long)(ubase + tid / 6) * 16 + tid % 6) * APW
                              : c->apart + ((long)(ubase + tid) * 16 + rr) * APW;
    float m = -1.0e30f;
    for (int s = 0; s < npg; s++) m = fmaxf(m, rec[s * sstep]);
    float l = 0.f;
    for (int s = 0; s < npg; s++) { const float f = expf(rec[s * sstep] - m); fac[tid][s] = f; l += rec[s * sstep + 1] * f; }
    sm_l[tid] = l; sm_m[tid] = m;
  }
  __syncthreads();
  for (int head = 0; head < NQL; head++) {
    const float* rec = packed ? c->apart + ((long)(ubase + head / 6) * 16 + head % 6) * APW
                              : c->apart + ((long)(ubase + head) * 16 + rr) * APW;
    float a = 0.f;
    for (int s = 0; s < npg; s++) a += rec[s * sstep + 2 + tid] * fac[head][s];
    const float l = sm_l[head], lse = sm_m[head] + logf(l);
    float o = a / l;
    o = o * sigm(bf(q[QG + head * HD + tid]));
    o = o * sigm(lse - bf(q[QS + head]));
    c->attn_out[(long)r * (NQL * HD) + head * HD + tid] = tobf(o);
  }
}

// attention outputs of the four cards -> o_proj input
__global__ void __launch_bounds__(768) k_gather_o(const PCtx* c, int i, int cls) {
  // cls: -1 any pass; 0 / 1: this launch serves passes of up to 64 rows / of more (fixed-grid launches issue both)
  if (blockIdx.x >= c->h.T || (cls >= 0 && (c->h.T <= 64) != (cls == 0))) return;
  xwait(c, i * 2);
  const int r = blockIdx.x, tid = threadIdx.x;
  uint8_t* dst = reinterpret_cast<uint8_t*>(c->xo);
  for (int q = tid; q < 768; q += blockDim.x)
    *reinterpret_cast<uint4*>(dst + xta(r, q * 8, 6144 / 16)) = reinterpret_cast<const uint4*>(c->attn_out_p[q / 192] + (long)r * 1536)[q % 192];
}

// ------------------------------------------------------------------------------------------------ after attention
// 16 raw short-convolution inputs of row r at lag j (0 = the row itself): the pass's own rows, then the slot's state
__device__ __forceinline__ void raw16(const bf16* rows, long stride, int r, int j, int back, const bf16* hist, int ch, int hch, float* v) {
  ld16(j <= back ? rows + (long)(r - j) * stride + ch : hist + (long)(3 - (j - back)) * HS + hch, v);
}
// static short convolution of 16 channels from k0: taps [channel][4] (tap 3 = the current row), identity residual
__device__ __forceinline__ void sconv16(const bf16* rows, int r, int back, const bf16* hist, int hoff, const bf16* taps, int k0, float* y) {
  float x[4][RE], w[4][RE];
#pragma unroll
  for (int j = 0; j < 4; j++) raw16(rows, H, r, j, back, hist, k0, hoff + k0, x[j]);
#pragma unroll
  for (int q = 0; q < 4; q++) ld16(taps + (long)k0 * 4 + q * 16, w[q]);     // w[q][4*m + tap] = channel k0 + 4q + m
#pragma unroll
  for (int e = 0; e < RE; e++) {
    float acc = 0.f;
#pragma unroll
    for (int tap = 0; tap < 4; tap++) acc = acc + x[3 - tap][e] * w[e >> 2][(e & 3) * 4 + tap];
    y[e] = bf(tobf((acc + x[0][e]) * 0.4472135954999579f));
  }
}
__global__ void __launch_bounds__(RT) k_post_attn(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T) return;       // fixed-grid launches: no such row in this pass
  __shared__ float red[9 * 20];
  const int r = blockIdx.x, k0 = threadIdx.x * RE;
  const PLayer& L = c->L[i];
  const long tm = c->tmax;
  const int slot = TAB(o_slot)[r], back = TAB(o_back)[r];
  const bf16* hist = c->hist + ((long)slot * NL + i) * 3 * HS;
  bf16* as = c->attn_s + (long)r * H;
  {
    float y[RE];
    sconv16(c->attn_raw, r, back, hist, 512, L.attn_sc, k0, y);
    st16(as + k0, y);
  }
  const int nb = (i + 5) / 6;
  const bool boundary = (i % 6) == 0;
  const bf16* src[10];
  int n = 0;
  for (int s = 0; s < nb; s++) src[n++] = c->blocks + ((long)s * tm + r) * H;
  float u[1][RE];
  if (boundary) {
    src[n++] = c->blocks + ((long)nb * tm + r) * H;
    src[n++] = as;
    mix_row<1>(src, n, nullptr, L.mq, u, red);
  } else {
    src[n++] = c->blocks + ((long)nb * tm + r) * H;
    mix_row<1>(src, n, as, L.mq, u, red);
  }
  const bf16* w[1] = {L.mlp_norm};
  rms_rows<1>(u, w, c->eps, red);
  st16(c->mlp_in + (long)r * H + k0, u[0]);
  st16t(reinterpret_cast<uint8_t*>(c->mlp_inx), r, k0, H / 16, u[0]);
}

// ------------------------------------------------------------------------------------------------ quantizers
// E2M1 code (index 0..7 of 0, .5, 1, 1.5, 2, 3, 4, 6) of a magnitude, round to nearest, ties to the even code
__device__ __forceinline__ int e2m1_idx(float mag) {
  int q;
  if (mag <= 0.25f) q = 0; else if (mag < 0.75f) q = 1; else if (mag <= 1.25f) q = 2; else if (mag < 1.75f) q = 3;
  else if (mag <= 2.5f) q = 4; else if (mag < 3.5f) q = 5; else if (mag <= 5.0f) q = 6; else q = 7;
  return q;
}
__device__ __forceinline__ float e2m1_val(int q) { return q < 4 ? 0.5f * q : (q == 4 ? 2.0f : (q == 5 ? 3.0f : (q == 6 ? 4.0f : 6.0f))); }
// NVFP4 ("four over six"): this thread's block of 16 (x), the row's amax -> 8 bytes of codes (low nibble = even
// element) and the block's E4M3 scale byte
__device__ __forceinline__ void quant_nvfp4_blk(const float* x, float amax, uint2& codes, uint8_t& sbyte) {
  const float FMAX = 3.4028234663852886e38f;
  const float encoder = fminf(1536.0f / amax, FMAX), decoder = 1.0f / encoder, outer = amax * (1.0f / 1536.0f);
  float bm = 0.f;
#pragma unroll
  for (int e = 0; e < 16; e++) bm = fmaxf(bm, fabsf(x[e]));
  float sc[2], iv[2], er[2]; uint8_t sb[2];
#pragma unroll
  for (int cand = 0; cand < 2; cand++) {
    const float inv_max = cand == 0 ? (1.0f / 6.0f) : 0.25f;
    const __nv_fp8_e4m3 s8 = __nv_fp8_e4m3(fminf(bm * (encoder * inv_max), 448.0f));
    sb[cand] = s8.__x;
    sc[cand] = float(s8);
    iv[cand] = fminf(1.0f / (sc[cand] * decoder), FMAX);
    float err = 0.f;
#pragma unroll
    for (int e = 0; e < 16; e++) {
      const float val = x[e] * iv[cand];
      const float q = (val != val) ? 0.f : e2m1_val(e2m1_idx(fabsf(val)));
      err += fabsf(((signbit(val) ? -q : q) * sc[cand]) * outer - x[e]);
    }
    er[cand] = err;
  }
  const int pick = (er[1] < er[0]) ? 1 : 0;
  const float inverse = iv[pick];
  uint32_t wlo = 0, whi = 0;
#pragma unroll
  for (int e = 0; e < 16; e++) {
    const float val = x[e] * inverse;
    const uint32_t nib = (val != val) ? 0u : ((uint32_t)e2m1_idx(fabsf(val)) | (signbit(val) ? 8u : 0u));
    if (e < 8) wlo |= nib << (4 * e); else whi |= nib << (4 * (e - 8));
  }
  codes = make_uint2(wlo, whi);
  sbyte = sb[pick];
}
// MXFP8: this thread's block of 32 -> 32 E4M3 codes and the block's UE8M0 exponent
__device__ __forceinline__ void quant_mxfp8_blk(const float* x, uint4& lo, uint4& hi, uint8_t& sbyte) {
  float m = 0.f;
#pragma unroll
  for (int e = 0; e < 32; e++) m = fmaxf(m, fabsf(x[e]));
  const float raw = m * (1.0f / 448.0f);
  const unsigned bits = __float_as_uint(raw);
  int ex = (int)(((bits + 0x007FFFFFu) & 0x7F800000u) >> 23);
  if (raw <= 5.877471754111438e-39f) ex = 0;
  if (ex > 254) ex = 254;
  const float inverse = (ex == 0) ? 1.7014118346046923e38f : 1.0f / ue8m0((unsigned)ex);
  uint32_t wd[8];
#pragma unroll
  for (int q = 0; q < 8; q++) {
    uint32_t w0 = 0;
#pragma unroll
    for (int b = 0; b < 4; b++) w0 |= (uint32_t)__nv_fp8_e4m3(fminf(fmaxf(x[4 * q + b] * inverse, -448.f), 448.f)).__x << (8 * b);
    wd[q] = w0;
  }
  lo = make_uint4(wd[0], wd[1], wd[2], wd[3]); hi = make_uint4(wd[4], wd[5], wd[6], wd[7]);
  sbyte = (uint8_t)ex;
}

// ------------------------------------------------------------------------------------------------ routing + input quantization
__global__ void __launch_bounds__(384) k_route(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T) return;       // fixed-grid launches: no such row in this pass
  __shared__ float cs[TOPK], red[12];
  __shared__ int flag[NE];
  __shared__ unsigned long long wmax[12];
  const int r = blockIdx.x, tid = threadIdx.x;
  const PLayer& L = c->L[i];
  const float logit = c->rlog[(long)r * NE + tid];
  const float sg = sigm(logit);
  // key: the selection score in an order-preserving code, then the lower expert index wins a tie
  unsigned bits = __float_as_uint(sg + L.rbias[tid]);
  bits = (bits & 0x80000000u) ? ~bits : (bits | 0x80000000u);
  unsigned long long key = ((unsigned long long)bits << 32) | (unsigned)(NE - tid);
  bool chosen = false;
  for (int round = 0; round < TOPK; round++) {
    unsigned long long m = key;
#pragma unroll
    for (int off = 16; off; off >>= 1) { const unsigned long long o = __shfl_xor_sync(0xffffffff, m, off); m = o > m ? o : m; }
    if ((tid & 31) == 0) wmax[tid >> 5] = m;
    __syncthreads();
    m = wmax[0];
#pragma unroll
    for (int k = 1; k < 12; k++) m = wmax[k] > m ? wmax[k] : m;
    __syncthreads();
    if (key == m) { chosen = true; key = 0ull; }
  }
  flag[tid] = chosen;
  __syncthreads();
  if (flag[tid]) {
    int slot = 0;
    for (int e = 0; e < tid; e++) slot += flag[e];
    c->ids[r * TOPK + slot] = tid;
    cs[slot] = sg;
    atomicAdd(&c->cnt[i * NE + tid], 1);
  }
  __syncthreads();
  if (tid < TOPK) {
    float sum = 0.f;
#pragma unroll
    for (int k = 0; k < TOPK; k++) sum += cs[k];
    c->wts[r * TOPK + tid] = cs[tid] / sum * 8.0f;
  }
  // quantization of the MoE input (codes in natural order; k_packx lays them out per item)
  const bf16* x = c->mlp_in + (long)r * H;
  if (!L.mx) {
    float v[16], m = 0.f;
    if (tid < 288) {
#pragma unroll
      for (int e = 0; e < 16; e++) { v[e] = bf(x[tid * 16 + e]); m = fmaxf(m, fabsf(v[e])); }
    }
    const float amax = block_max1(m, red);
    if (tid < 288) {
      uint2 cd; uint8_t sb;
      quant_nvfp4_blk(v, amax, cd, sb);
      *reinterpret_cast<uint2*>(c->xq + (long)r * H + tid * 8) = cd;
      c->xs8[(long)r * 288 + tid] = sb;
    }
    if (tid == 0) c->xouter[r] = amax * (1.0f / 1536.0f);
  } else if (tid < 144) {
    float v[32];
#pragma unroll
    for (int e = 0; e < 32; e++) v[e] = bf(x[tid * 32 + e]);
    uint4 lo, hi; uint8_t sb;
    quant_mxfp8_blk(v, lo, hi, sb);
    *reinterpret_cast<uint4*>(c->xq + (long)r * H + tid * 32) = lo;
    *reinterpret_cast<uint4*>(c->xq + (long)r * H + tid * 32 + 16) = hi;
    c->xs8[(long)r * 288 + tid] = sb;
  }
}

// pair lists per card (expert-major, rows ascending) and the GEMM items; block = expert
__global__ void __launch_bounds__(NTB) k_assign(const PCtx* c, int i) {
  if (!c->h.T) return;
  __shared__ int cj[NTB];
  __shared__ int sm_poff, sm_ioff;
  const int e = blockIdx.x, tid = threadIdx.x;
  const int* em = c->emap + i * NE;
  const int cc = em[e] & 255;           // the card that holds this expert
  const int T = c->h.T;
  const int* cnt = c->cnt + i * NE;
  {   // a card's pairs and items: its experts in ascending order; pairs, items and "a later expert exists" before e
    int v[3] = {0, 0, 0};
    for (int o = tid; o < NE; o += NTB)
      if ((em[o] & 255) == cc) {
        if (o < e) { v[0] += cnt[o]; v[1] += (cnt[o] + COLT - 1) / COLT; }
        else if (o > e) v[2] = 1;
      }
#pragma unroll
    for (int k = 0; k < 3; k++) {
#pragma unroll
      for (int off = 16; off; off >>= 1) v[k] += __shfl_xor_sync(0xffffffff, v[k], off);
      if ((tid & 31) == 0) cj[(tid >> 5) * 3 + k] = v[k];
    }
  }
  __syncthreads();
  if (tid == 0) {
    int poff = 0, ioff = 0, later = 0;
#pragma unroll
    for (int w8 = 0; w8 < NTB / 32; w8++) { poff += cj[w8 * 3]; ioff += cj[w8 * 3 + 1]; later += cj[w8 * 3 + 2]; }
    sm_poff = poff; sm_ioff = ioff;
    const int n = cnt[e];
    for (int ti = 0; ti * COLT < n; ti++) {
      int* it = c->items + ((long)cc * c->pmax + ioff + ti) * 4;
      it[0] = em[e] >> 8; it[1] = poff + ti * COLT; it[2] = min(COLT, n - ti * COLT); it[3] = e;
    }
    if (!later) { c->ginfo[cc * 4] = ioff + (n + COLT - 1) / COLT; c->ginfo[cc * 4 + 1] = poff + n; }
  }
  __syncthreads();
  const int per = (T + NTB - 1) / NTB, r0 = tid * per, r1 = min(T, r0 + per);
  int mine = 0;
  for (int r = r0; r < r1; r++)
#pragma unroll
    for (int k = 0; k < TOPK; k++) mine += c->ids[r * TOPK + k] == e;
  cj[tid] = mine;
  __syncthreads();
  if (!mine) return;
  int pos = sm_poff;
  for (int j = 0; j < tid; j++) pos += cj[j];
  for (int r = r0; r < r1; r++)
#pragma unroll
    for (int k = 0; k < TOPK; k++)
      if (c->ids[r * TOPK + k] == e) {
        c->ptok[(long)cc * c->pmax + pos] = r; c->pslot[(long)cc * c->pmax + pos] = k; c->pidx[r * TOPK + k] = pos;
        if (cc == c->card) c->pitem[pos] = sm_ioff + (pos - sm_poff) / COLT;
        pos++;
      }
}

// ------------------------------------------------------------------------------------------------ expert inputs
// the quantized MoE input of a pair's row, laid out as column (pair - first pair of its item) of the item's B units:
// per K step two 16-byte pieces at (n/8)*256 + h*128 + (n%8)*16 and the scales at 4096 + (n%32)*16 + (n/32)*4
template <bool MX>
__global__ void __launch_bounds__(160) k_packx(const PCtx* c, int i) {
  const int tid = threadIdx.x, me = c->card;
  const int np = c->ginfo[me * 4 + 1];
  const long pm = c->pmax;
  const int KS = MX ? 144 : 72;
  for (int pair = blockIdx.x; pair < np; pair += gridDim.x) {
    const int row = c->ptok[me * pm + pair], item = c->pitem[pair];
    const int n = pair - c->items[((long)me * pm + item) * 4 + 1];
    const uint8_t* src = c->xq + (long)row * H;
    const uint8_t* ssrc = c->xs8 + (long)row * 288;
    uint8_t* dst = c->xt13 + (long)item * KS * TC_BUB + (n >> 3) * 256 + (n & 7) * 16;
    uint8_t* sdst = c->xt13 + (long)item * KS * TC_BUB + 4096 + (n & 31) * 16 + (n >> 5) * 4;
    for (int ks = tid; ks < KS; ks += blockDim.x) {
      *reinterpret_cast<uint4*>(dst + (long)ks * TC_BUB) = *reinterpret_cast<const uint4*>(src + ks * 32);
      *reinterpret_cast<uint4*>(dst + (long)ks * TC_BUB + 128) = *reinterpret_cast<const uint4*>(src + ks * 32 + 16);
      *reinterpret_cast<uint32_t*>(sdst + (long)ks * TC_BUB) = MX ? (uint32_t)ssrc[ks] : *reinterpret_cast<const uint32_t*>(ssrc + ks * 4);
    }
  }
}

// activation of a pair, times its routing weight, rounded to bf16, quantized for w2 into the item's B units
template <bool MX>
__global__ void __launch_bounds__(160) k_act(const PCtx* c, int i) {
  __shared__ float red[8];
  const int tid = threadIdx.x, me = c->card;
  const int np = c->ginfo[me * 4 + 1];
  const long pm = c->pmax;
  const int KS = MX ? 72 : 36;
  for (int pair = blockIdx.x; pair < np; pair += gridDim.x) {
    const int row = c->ptok[me * pm + pair], k = c->pslot[me * pm + pair], item = c->pitem[pair];
    const int n = pair - c->items[((long)me * pm + item) * 4 + 1];
    const float wt = c->wts[row * TOPK + k];
    const bf16* h = c->h13 + (long)pair * H;
    uint8_t* dst = c->xt2 + (long)item * KS * TC_BUB + (n >> 3) * 256 + (n & 7) * 16;
    uint8_t* sdst = c->xt2 + (long)item * KS * TC_BUB + 4096 + (n & 31) * 16 + (n >> 5) * 4;
    if (!MX) {
      float v[16], m = 0.f;
      if (tid < 144) {
#pragma unroll
        for (int e = 0; e < 16; e++) {
          const uint32_t gu = *reinterpret_cast<const uint32_t*>(h + (tid * 16 + e) * 2);
          const float gg = bf(*reinterpret_cast<const bf16*>(&gu)), uu = bf(reinterpret_cast<const bf16*>(&gu)[1]);
          const float a = (4.0f * tanhf(gg / 4.0f)) * sigm(gg);
          v[e] = bf(tobf((a * (25.0f * tanhf(uu / 25.0f))) * wt));
          m = fmaxf(m, fabsf(v[e]));
        }
      }
      const float amax = block_max1(m, red);
      if (tid < 144) {       // block tid = k16 block (tid & 3) of K step (tid >> 2)
        uint2 cd; uint8_t sb;
        quant_nvfp4_blk(v, amax, cd, sb);
        const int ks = tid >> 2, j = tid & 3;
        *reinterpret_cast<uint2*>(dst + (long)ks * TC_BUB + (j >> 1) * 128 + (j & 1) * 8) = cd;
        sdst[(long)ks * TC_BUB + j] = sb;
      }
      if (tid == 0) c->aouter[pair] = amax * (1.0f / 1536.0f);
    } else if (tid < 72) {
      float v[32];
#pragma unroll
      for (int e = 0; e < 32; e++) {
        const uint32_t gu = *reinterpret_cast<const uint32_t*>(h + (tid * 32 + e) * 2);
        const float gg = bf(*reinterpret_cast<const bf16*>(&gu)), uu = bf(reinterpret_cast<const bf16*>(&gu)[1]);
        const float a = (4.0f * tanhf(gg / 4.0f)) * sigm(gg);
        v[e] = bf(tobf((a * (25.0f * tanhf(uu / 25.0f))) * wt));
      }
      uint4 lo, hi; uint8_t sb;
      quant_mxfp8_blk(v, lo, hi, sb);
      *reinterpret_cast<uint4*>(dst + (long)tid * TC_BUB) = lo;
      *reinterpret_cast<uint4*>(dst + (long)tid * TC_BUB + 128) = hi;
      *reinterpret_cast<uint32_t*>(sdst + (long)tid * TC_BUB) = (uint32_t)sb;
    }
    __syncthreads();
  }
}

// ------------------------------------------------------------------------------------------------ after the experts
// sum of a row's eight expert outputs in expert order (pair outputs live on the experts' cards)
__global__ void __launch_bounds__(576) k_combine(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T || c->h.T > 64) return;
  xwait(c, i * 2 + 1);
  const int r = blockIdx.x, tid = threadIdx.x;
  const uint4* po[TOPK];
#pragma unroll
  for (int k = 0; k < TOPK; k++) po[k] = reinterpret_cast<const uint4*>(c->pairout_p[c->emap[i * NE + c->ids[r * TOPK + k]] & 255] + (long)c->pidx[r * TOPK + k] * H);
  uint4* mr = reinterpret_cast<uint4*>(c->mlp_raw + (long)r * H);
  for (int q = tid; q < H / 8; q += blockDim.x) {
    float s[8];
#pragma unroll
    for (int e = 0; e < 8; e++) s[e] = 0.f;
#pragma unroll
    for (int j = 0; j < TOPK; j++) {
      const uint4 v = po[j][q];
      const bf16* b = reinterpret_cast<const bf16*>(&v);
#pragma unroll
      for (int e = 0; e < 8; e++) s[e] += bf(b[e]);
    }
    uint4 o;
    bf16* ob = reinterpret_cast<bf16*>(&o);
#pragma unroll
    for (int e = 0; e < 8; e++) ob[e] = tobf(s[e]);
    mr[q] = o;
  }
}
// Larger passes: the sum of a row's eight expert outputs is made once, on the card that holds most of the row's
// experts (k_osum), and the other cards fetch the result (k_spread): a third of the bytes over the links that
// every card summing every row for itself (k_combine) needs. The sum itself is the same.
__device__ __forceinline__ int row_owner(const PCtx* c, int i, int r) {
  int n[NCARD] = {0, 0, 0, 0};
#pragma unroll
  for (int k = 0; k < TOPK; k++) n[c->emap[i * NE + c->ids[r * TOPK + k]] & 255]++;
  int o = 0;
#pragma unroll
  for (int q = 1; q < NCARD; q++) if (n[q] > n[o]) o = q;
  return o;
}
__global__ void __launch_bounds__(NTB) k_osum(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T || c->h.T <= 64) return;
  xwait(c, i * 2 + 1);
  const int r = blockIdx.x, tid = threadIdx.x;
  if (row_owner(c, i, r) != c->card) return;
  const uint4* po[TOPK];
#pragma unroll
  for (int k = 0; k < TOPK; k++) po[k] = reinterpret_cast<const uint4*>(c->pairout_p[c->emap[i * NE + c->ids[r * TOPK + k]] & 255] + (long)c->pidx[r * TOPK + k] * H);
  uint4* mr = reinterpret_cast<uint4*>(c->mlp_raw + (long)r * H);
  for (int q = tid; q < H / 8; q += blockDim.x) {
    float s[8];
#pragma unroll
    for (int e = 0; e < 8; e++) s[e] = 0.f;
#pragma unroll
    for (int j = 0; j < TOPK; j++) {
      const uint4 v = po[j][q];
      const bf16* b = reinterpret_cast<const bf16*>(&v);
#pragma unroll
      for (int e = 0; e < 8; e++) s[e] += bf(b[e]);
    }
    mr[q] = pk8(s);
  }
}
__global__ void __launch_bounds__(NTB) k_spread(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T || c->h.T <= 64) return;
  xwait(c, NL * 2 + 8 + i);
  const int r = blockIdx.x, tid = threadIdx.x;
  const int o = row_owner(c, i, r);
  if (o == c->card) return;
  const uint4* src = reinterpret_cast<const uint4*>(c->mlp_raw_p[o] + (long)r * H);
  uint4* mr = reinterpret_cast<uint4*>(c->mlp_raw + (long)r * H);
  for (int q = tid; q < H / 8; q += blockDim.x) mr[q] = src[q];
}
__global__ void __launch_bounds__(RT) k_post_mlp(const PCtx* c, int i) {
  if (blockIdx.x >= c->h.T) return;       // fixed-grid launches: no such row in this pass
  const int r = blockIdx.x, k0 = threadIdx.x * RE;
  const PLayer& L = c->L[i];
  const long tm = c->tmax;
  const int slot = TAB(o_slot)[r], back = TAB(o_back)[r];
  const bf16* hist = c->hist + ((long)slot * NL + i) * 3 * HS;
  const int nb = (i + 5) / 6;
  const bool boundary = (i % 6) == 0;
  float mlp[RE], a[RE], pt[RE], o[RE];
  sconv16(c->mlp_raw, r, back, hist, 5120, L.mlp_sc, k0, mlp);
  ld16(c->attn_s + (long)r * H + k0, a);
  if (!boundary) ld16(c->blocks + ((long)nb * tm + r) * H + k0, pt);
#pragma unroll
  for (int e = 0; e < RE; e++) o[e] = boundary ? a[e] + mlp[e] : pt[e] + a[e] + mlp[e];
  st16(c->blocks + ((long)(boundary ? nb + 1 : nb) * tm + r) * H + k0, o);
}


// short-convolution state: a job = (dst kind: 0 slot state, 1 page snapshot; dst index; slot; row0; n)
__global__ void __launch_bounds__(NTB) k_hist(const PCtx* c, int i, int snaps) {
  if (blockIdx.x >= (snaps ? c->h.nsnap : c->h.nseq)) return;
  const int tid = threadIdx.x;
  const PLayer& L = c->L[i];
  const int* job = (snaps ? TAB(o_snap) : TAB(o_seq)) + blockIdx.x * 4;
  const int dsti = job[0], slot = job[1], row0 = job[2], n = job[3];
  const int V0 = QK + (L.glob ? 272 : 256);
  bf16* dst = (snaps ? c->snap + ((long)dsti * NL + i) * 3 * HS : c->hist + ((long)dsti * NL + i) * 3 * HS);
  const bf16* old = c->hist + ((long)slot * NL + i) * 3 * HS;
  for (int q = tid; q < HS / 8; q += NTB) {
    const int ch = q * 8;
    const bf16* rows; long stride; int off;
    if (ch < 256) { rows = c->qkvo; stride = 3824; off = QK + ch; }
    else if (ch < 512) { rows = c->qkvo; stride = 3824; off = V0 + ch - 256; }
    else if (ch < 5120) { rows = c->attn_raw; stride = H; off = ch - 512; }
    else { rows = c->mlp_raw; stride = H; off = ch - 5120; }
#pragma unroll
    for (int idx = 0; idx < 3; idx++) {
      const int o = n - 3 + idx;
      const uint4 v = *reinterpret_cast<const uint4*>(o >= 0 ? rows + (long)(row0 + o) * stride + off : old + (long)(idx + n) * HS + ch);
      *reinterpret_cast<uint4*>(dst + (long)idx * HS + ch) = v;
    }
  }
}

// state of sequences that start in this pass: zero, or the snapshot of the last shared page. job = (slot, page or -1)
__global__ void __launch_bounds__(NTB) k_prologue(const PCtx* c) {
  if (blockIdx.x >= c->h.nprol * NL) return;
  const int* job = TAB(o_prol) + (blockIdx.x / NL) * 2;
  const int layer = blockIdx.x % NL, slot = job[0], page = job[1];
  bf16* dst = c->hist + ((long)slot * NL + layer) * 3 * HS;
  const bf16* src = c->snap + ((long)max(page, 0) * NL + layer) * 3 * HS;
  for (int k = threadIdx.x; k < 3 * HS; k += NTB) dst[k] = page >= 0 ? src[k] : tobf(0.f);
}

// final mix + norm of the rows that need logits -> hfin (B-fragment order)
__global__ void __launch_bounds__(RT) k_final(const PCtx* c) {
  if (blockIdx.x >= c->h.nlog || !c->h.mode) return;
  __shared__ float red[9 * 20];
  const int li = blockIdx.x, r = TAB(o_log)[li], k0 = threadIdx.x * RE;
  const long tm = c->tmax;
  if (c->h.mode == 2 && threadIdx.x == 0) c->cand[li] = 0ull;
  const bf16* src[10];
  for (int s = 0; s < 9; s++) src[s] = c->blocks + ((long)s * tm + r) * H;
  float u[1][RE];
  mix_row<1>(src, 9, nullptr, c->oq, u, red);
  const bf16* w[1] = {c->fnorm};
  rms_rows<1>(u, w, c->eps, red);
  st16t(reinterpret_cast<uint8_t*>(c->hfin), li, k0, H / 16, u[0]);
}
__global__ void k_join(const PCtx* c) { if (!c->h.nlog || !c->h.mode) return; xwait(c, NL * 2); }

// ------------------------------------------------------------------------------------------------ serving loop on the device
// k_sched (card 0) is the scheduler: it reads the tokens of the pass that just ran, takes arrivals from the request
// ring, keeps the slot table, the page free list and the prefix cache, and writes the next pass (header and tables).
// k_wait (cards 1-3) takes that pass over. The host only enqueues the fixed pass program again and again, copies
// prompts into the arena and reads the token ring: no decision, and nothing here waits for it.
__device__ __forceinline__ double dev_now() {
  unsigned long long t;
  asm volatile("mov.u64 %0, %globaltimer;" : "=l"(t));
  return (double)t * 1e-9;
}
__global__ void k_sched_init(PCtx* c, int npages, int tmax, int umax, int ncache, int* freep, int* page_ref, SNode* cache, const double* cfg) {
  if (threadIdx.x || blockIdx.x) return;
  s_init(c->sched, npages, tmax, umax, ncache, freep, page_ref, cache);
  Sched* S = c->sched;
  S->base = cfg[0]; S->dec = cfg[1]; S->row = cfg[2]; S->ctx = cfg[3]; S->target_decode_ms = cfg[4]; S->target_idle_ms = cfg[5];
  S->ttft_slo = cfg[6]; S->gap_limit = cfg[7]; S->min_pass_ms = cfg[8]; S->host_ms = cfg[9];
  for (int i = 0; i < S_NSLOT * S_MAXPG; i++) c->tab[(4 + S_GRPW) * tmax + 4 * S_MAXE + 4 * (S_MAXE + 64) + S_MAXE + 2 * S_MAXE + i] = 0;
}
__global__ void __launch_bounds__(256) k_sched(PCtx* c) {
  __shared__ unsigned long long best[S_MAXE];
  const int tid = threadIdx.x;
  Sched* S = c->sched;
  SShared* sh = c->shr;
  // the other cards have taken the pass composed last (so its tables may be overwritten)
  if (tid == 0) {
    const unsigned tag = (unsigned)S->pass_no;
    for (int p = 1; p < NCARD; p++) {
      unsigned long long spins = 0;
      while (ld_acquire_sys(&c->sig_p[p][SIG_TAKEN]) != tag) { if (++spins > (1ull << 31)) { c->err[1] = 100 + p; break; } }
    }
  }
  // candidates of the pass that just ran: the best of the four cards per row that wanted a token
  const int nlog = S->ne ? c->h.nlog : 0;
  for (int li = tid; li < nlog; li += blockDim.x) {
    unsigned long long b = 0;
#pragma unroll
    for (int d = 0; d < NCARD; d++) { const unsigned long long v = c->cand_p[d][li]; b = v > b ? v : b; }
    best[li] = b;
  }
  __syncthreads();
  if (tid) return;
  // an idle engine: wait a little for a request before composing an empty pass
  bool work = false;
  for (int i = 0; i < S_NSLOT; i++) work |= S->slot[i].state != 0;
  if (!work && S->ne == 0) {
    for (int spin = 0; spin < 200000; spin++)
      if (sh->ring_head != sh->ring_tail || sh->cmd_drop != sh->ack_drop || sh->stop) break;
  }
  const unsigned long long* cp[4] = {best, best, best, best};
  s_step(S, sh, c->arena, cp, c->tab, &c->h, dev_now());
  st_release_sys(&c->sig_p[0][SIG_SCHED], (unsigned)c->h.tag);
  st_release_sys(&c->sig_p[0][SIG_TAKEN], (unsigned)c->h.tag);
}
__global__ void __launch_bounds__(1024) k_wait(PCtx* c) {
  __shared__ PHdr hs;
  const int tid = threadIdx.x, me = c->card;
  if (tid == 0) {
    const unsigned last = ld_acquire_sys(&c->sig_p[me][SIG_TAKEN]);
    unsigned long long spins = 0;
    while (ld_acquire_sys(&c->sig_p[0][SIG_SCHED]) == last) { if (++spins > (1ull << 33)) { c->err[1] = 200 + me; break; } }
    hs = c->ctx_p[0]->h;
  }
  __syncthreads();
  // the tables of the pass: rows, groups, jobs, page table (16 bytes per load)
  const int* src = c->tab_p[0];
  const int tmax = hs.pad2;
  const int secs[10][2] = {{hs.o_slot, hs.T}, {hs.o_pos, hs.T}, {hs.o_tok, hs.T}, {hs.o_back, hs.T}, {hs.o_grp, hs.ngrp * S_GRPW}, {hs.o_seq, hs.nseq * 4},
                           {hs.o_snap, hs.nsnap * 4}, {hs.o_log, hs.nlog}, {hs.o_prol, hs.nprol * 2}, {hs.o_pt, S_NSLOT * S_MAXPG}};
  (void)tmax;
#pragma unroll 1
  for (int k = 0; k < 10; k++) {
    const int o = secs[k][0] & ~3, n4 = (secs[k][1] + (secs[k][0] & 3) + 3) >> 2;
    for (int q = tid; q < n4; q += blockDim.x)
      *reinterpret_cast<uint4*>(c->tab + o + q * 4) = *reinterpret_cast<const uint4*>(src + o + q * 4);
  }
  __syncthreads();
  if (tid == 0) {
    c->h = hs;
    st_release_sys(&c->sig_p[me][SIG_TAKEN], (unsigned)hs.tag);
  }
}

// ------------------------------------------------------------------------------------------------ host API
extern "C" int pe_ctx_bytes() { return (int)sizeof(PCtx); }
extern "C" int pe_layer_bytes() { return (int)sizeof(PLayer); }
extern "C" int pe_hdr_bytes() { return (int)sizeof(PHdr); }

extern "C" int pe_enable_peer(int n) {
  for (int a = 0; a < n; a++) {
    cudaSetDevice(a);
    for (int b = 0; b < n; b++) if (a != b) {
      cudaError_t e = cudaDeviceEnablePeerAccess(b, 0);
      if (e != cudaSuccess && e != cudaErrorPeerAccessAlreadyEnabled) return (int)e;
      cudaGetLastError();
    }
  }
  return 0;
}
extern "C" int pe_setup(int dev) {
  cudaSetDevice(dev);
  int e = 0;
#define SA(K) e |= (int)cudaFuncSetAttribute(K, cudaFuncAttributeMaxDynamicSharedMemorySize, TC_SMEM)
  SA((k_tc<TK_BF16, G_QKV>)); SA((k_tc<TK_BF16, G_OPROJ>)); SA((k_tc<TK_BF16, G_ROUTER>)); SA((k_tc<TK_BF16, G_UNEMBED>)); SA((k_tc<TK_BF16, G_RELB>));
  SA((k_tc<TK_FP4, G_W13>)); SA((k_tc<TK_FP4, G_W2>)); SA((k_tc<TK_FP8, G_W13>)); SA((k_tc<TK_FP8, G_W2>));
#undef SA
  return e;
}
extern "C" void* pe_host_alloc(size_t n) {
  void* p = nullptr;
  if (cudaHostAlloc(&p, n, cudaHostAllocPortable | cudaHostAllocMapped) != cudaSuccess) return nullptr;
  memset(p, 0, n);
  return p;
}

struct PassArgs { int dev; void* ctx; const void* hdr; const void* tab; long tab_bytes; void* tab_dev; void* stream; int nsm; int flags; };   // flags: 1 fixed grids, 2 tables are written on the device

static int launch_pass(const PassArgs& a) {
  cudaSetDevice(a.dev);
  cudaStream_t s = (cudaStream_t)a.stream;
  const PCtx* c = (const PCtx*)a.ctx;
  // The pass as a fixed program (flags & 1): grids for the largest pass, every kernel leaves when the pass has no
  // work for a block. Then nothing here depends on what the pass contains: it can be enqueued before the device
  // has decided it.
  const bool fixed = a.flags & 1;
  PHdr h = *(const PHdr*)a.hdr;
  if (!(a.flags & 2)) {
    cudaMemcpyAsync(a.tab_dev, a.tab, a.tab_bytes, cudaMemcpyHostToDevice, s);
    cudaMemcpyAsync(a.ctx, a.hdr, sizeof(PHdr), cudaMemcpyHostToDevice, s);
  }
  const int nsm = a.nsm;
  if (fixed) { h.T = h.pad2; h.nprol = 64; h.nseq = 128; h.nsnap = 128; h.nlog = 64; h.lo = 0; h.hi = NL; h.mode = 2; h.unitsL = h.unitsG = 1 << 30; h.rg = 3; h.rgd = 3; }
  const int T = h.T, RG = h.rg, RGD = h.rgd;
  const int ntt = (T + COLT - 1) / COLT;
  auto gd = [&](long items, int mx) { long g = items; if (g > mx) g = mx; if (g < 1) g = 1; return (int)g; };
  // dense GEMM grids: units of the pass, at most one block per SM
  auto gt = [&](int which, int glob, int nrg) { return fixed ? nsm : gd((long)ntt * tc_units(which, glob, nrg, RG, RGD), nsm); };
  const bool smc = T <= 64;
  if (a.flags & 2) { if (a.dev == 0) k_sched<<<1, 256, 0, s>>>((PCtx*)a.ctx); else k_wait<<<1, 1024, 0, s>>>((PCtx*)a.ctx); }
  if (h.nprol) k_prologue<<<h.nprol * NL, NTB, 0, s>>>(c);
  if (h.lo == 0) k_embed<<<T, RT, 0, s>>>(c);
  for (int i = h.lo; i < h.hi; i++) {
    const bool glob = (i % 6) == 5, mx = i >= 40;
    if (glob) k_mix_attn<3><<<T, RT, 0, s>>>(c, i); else k_mix_attn<1><<<T, RT, 0, s>>>(c, i);
    k_tc<TK_BF16, G_QKV><<<gt(G_QKV, glob, 0), 288, TC_SMEM, s>>>(c, i);
    k_prep<<<T, NTB, 0, s>>>(c, i);
    k_tc<TK_BF16, G_RELB><<<fixed ? nsm : gd((long)((T * NQL + COLT - 1) / COLT) * tc_nchunks(G_RELB, 0, 8, RGD), nsm), 288, TC_SMEM, s>>>(c, i);
    k_attn_seg<<<fixed ? 3 * nsm : gd(((glob ? h.unitsG : h.unitsL) + 5) / 6, 3 * nsm), 192, 0, s>>>(c, i);
    k_attn_fold<<<T, 128, 0, s>>>(c, i);
    if (fixed) { k_gather_o<<<64, 768, 0, s>>>(c, i, 0); k_gather_o<<<T, NTB, 0, s>>>(c, i, 1); }
    else k_gather_o<<<T, smc ? 768 : NTB, 0, s>>>(c, i, -1);
    k_tc<TK_BF16, G_OPROJ><<<gt(G_OPROJ, 0, 36), 288, TC_SMEM, s>>>(c, i);
    k_post_attn<<<T, RT, 0, s>>>(c, i);
    k_tc<TK_BF16, G_ROUTER><<<gt(G_ROUTER, 0, 3), 288, TC_SMEM, s>>>(c, i);
    k_route<<<T, 384, 0, s>>>(c, i);
    k_assign<<<NE, NTB, 0, s>>>(c, i);
    const int ge = fixed ? nsm : gd((long)(T * 8 / COLT + NEC + 1) * tc_nchunks(G_W13, 0, 36, RG), nsm);
    const int ga = fixed ? 8 * nsm : gd((long)T * 8, 8 * nsm);
    if (mx) {
      k_packx<true><<<ga, 160, 0, s>>>(c, i);
      k_tc<TK_FP8, G_W13><<<ge, 288, TC_SMEM, s>>>(c, i);
      k_act<true><<<ga, 160, 0, s>>>(c, i);
      k_tc<TK_FP8, G_W2><<<ge, 288, TC_SMEM, s>>>(c, i);
    } else {
      k_packx<false><<<ga, 160, 0, s>>>(c, i);
      k_tc<TK_FP4, G_W13><<<ge, 288, TC_SMEM, s>>>(c, i);
      k_act<false><<<ga, 160, 0, s>>>(c, i);
      k_tc<TK_FP4, G_W2><<<ge, 288, TC_SMEM, s>>>(c, i);
    }
    if (fixed || T <= 64) k_combine<<<fixed ? 64 : T, 576, 0, s>>>(c, i);
    if (fixed || T > 64) { k_osum<<<T, NTB, 0, s>>>(c, i); k_spread<<<T, NTB, 0, s>>>(c, i); }
    k_post_mlp<<<T, RT, 0, s>>>(c, i);
    if (h.nsnap) k_hist<<<h.nsnap, NTB, 0, s>>>(c, i, 1);
    k_hist<<<h.nseq, NTB, 0, s>>>(c, i, 0);
  }
  if (h.hi == NL && h.nlog && h.mode) {
    k_final<<<h.nlog, RT, 0, s>>>(c);
    k_tc<TK_BF16, G_UNEMBED><<<fixed ? nsm : gd((long)((h.nlog + COLT - 1) / COLT) * tc_units(G_UNEMBED, 0, 393, RG, RGD), nsm), 288, TC_SMEM, s>>>(c, 0);
    k_join<<<1, 32, 0, s>>>(c);
  }
  return (int)cudaGetLastError();
}

// four launcher threads, one per card
struct Launcher {
  std::thread th[NCARD];
  std::mutex mu;
  std::condition_variable cv, done_cv;
  PassArgs args[NCARD];
  int gen[NCARD] = {0, 0, 0, 0}, want = 0, pending = 0, rc[NCARD] = {0, 0, 0, 0};
  bool started = false;
  void run(int c) {
    int seen = 0;
    for (;;) {
      PassArgs a;
      {
        std::unique_lock<std::mutex> lk(mu);
        cv.wait(lk, [&] { return gen[c] != seen; });
        seen = gen[c];
        a = args[c];
      }
      int r = launch_pass(a);
      {
        std::lock_guard<std::mutex> lk(mu);
        rc[c] = r;
        pending--;
      }
      done_cv.notify_all();
    }
  }
};
static Launcher& g_l = *new Launcher;   // never destroyed: its threads outlive main

extern "C" int pe_pass(const PassArgs* a, int n, int threads) {
  if (!threads) {
    int r = 0;
    for (int k = 0; k < n; k++) r |= launch_pass(a[k]);
    return r;
  }
  if (!g_l.started) {
    g_l.started = true;
    for (int c = 0; c < NCARD; c++) { g_l.th[c] = std::thread([c] { g_l.run(c); }); g_l.th[c].detach(); }
  }
  {
    std::lock_guard<std::mutex> lk(g_l.mu);
    for (int k = 0; k < n; k++) { g_l.args[k] = a[k]; g_l.gen[k]++; }
    g_l.pending = n;
  }
  g_l.cv.notify_all();
  std::unique_lock<std::mutex> lk(g_l.mu);
  g_l.done_cv.wait(lk, [&] { return g_l.pending == 0; });
  int r = 0;
  for (int k = 0; k < n; k++) r |= g_l.rc[k];
  return r;
}
// ---- device-side loop: set-up and the pump (a thread per card that keeps two pass programs enqueued)
extern "C" int pe_sched_bytes() { return (int)sizeof(Sched); }
extern "C" int pe_shared_bytes() { return (int)sizeof(SShared); }
extern "C" int pe_node_bytes() { return (int)sizeof(SNode); }
extern "C" int pe_tab_ints(int tmax) { return s_tab_ints(tmax); }
extern "C" int pe_sched_init(void* ctx, int npages, int tmax, int umax, int ncache, void* freep, void* page_ref, void* cache, const double* cfg, void* cfg_dev) {
  cudaSetDevice(0);
  cudaMemcpy(cfg_dev, cfg, 10 * sizeof(double), cudaMemcpyHostToDevice);
  k_sched_init<<<1, 32>>>((PCtx*)ctx, npages, tmax, umax, ncache, (int*)freep, (int*)page_ref, (SNode*)cache, (const double*)cfg_dev);
  cudaDeviceSynchronize();
  return (int)cudaGetLastError();
}
struct Pump {
  std::thread th[NCARD];
  PassArgs args[NCARD];
  std::atomic<int> running{0};
  std::atomic<long> launched[NCARD], final{-1};
  int rc[NCARD] = {0, 0, 0, 0};
};
static Pump& g_p = *new Pump;
extern "C" void* pe_stream_create(int dev) {
  cudaSetDevice(dev);
  cudaStream_t s;
  if (cudaStreamCreateWithFlags(&s, cudaStreamNonBlocking) != cudaSuccess) return nullptr;
  return (void*)s;
}
extern "C" int pe_copy_in(int dev, void* stream, void* dst, const void* src, size_t n) {      // a prompt into the arena
  cudaSetDevice(dev);
  cudaError_t e = cudaMemcpyAsync(dst, src, n, cudaMemcpyHostToDevice, (cudaStream_t)stream);
  if (e) return (int)e;
  return (int)cudaStreamSynchronize((cudaStream_t)stream);
}
extern "C" int pe_pump_start(const PassArgs* a, volatile unsigned* stop_word) {
  if (g_p.running.load()) return 0;
  g_p.final = -1; g_p.running = NCARD;
  for (int c = 0; c < NCARD; c++) {
    g_p.args[c] = a[c]; g_p.launched[c] = 0;
    g_p.th[c] = std::thread([c, stop_word] {
      cudaSetDevice(g_p.args[c].dev);
      cudaStream_t s = (cudaStream_t)g_p.args[c].stream;
      cudaEvent_t ev[2];
      cudaEventCreateWithFlags(&ev[0], cudaEventDisableTiming); cudaEventCreateWithFlags(&ev[1], cudaEventDisableTiming);
      long n = 0;
      for (;;) {
        if (*stop_word && g_p.final.load() < 0) {      // every card ends after the same number of programs
          long mx = 0;
          for (int k = 0; k < NCARD; k++) mx = std::max(mx, g_p.launched[k].load());
          long expect = -1;
          g_p.final.compare_exchange_strong(expect, mx + 1);
        }
        const long fin = g_p.final.load();
        if (fin >= 0 && n >= fin) break;
        if (n >= 2) cudaEventSynchronize(ev[n & 1]);       // the pass before the last has ended: at most two enqueued
        g_p.rc[c] |= launch_pass(g_p.args[c]);
        cudaEventRecord(ev[n & 1], s);
        n++; g_p.launched[c] = n;
      }
      cudaStreamSynchronize(s);
      g_p.running--;
    });
    g_p.th[c].detach();
  }
  return 0;
}
extern "C" int pe_pump_stop() {
  for (int k = 0; k < 30000 && g_p.running.load(); k++) std::this_thread::sleep_for(std::chrono::milliseconds(1));
  int r = 0;
  for (int c = 0; c < NCARD; c++) r |= g_p.rc[c];
  return g_p.running.load() ? -1 : r;
}
extern "C" long pe_pump_launched(int c) { return g_p.launched[c].load(); }
extern "C" int pe_sync(int dev, void* stream) {
  cudaSetDevice(dev);
  return (int)cudaStreamSynchronize((cudaStream_t)stream);
}
