// The serving loop's scheduler: admission, the page store with its prefix cache, and the composition of a pass.
// Plain C++ without allocation or library calls: the same code runs in a kernel on card 0 (engine/pe.cu, k_sched:
// the slot table, the page free list, the cache and the request ring live in device memory and nothing waits for the
// host) and on the host for tests (tools/sched_sim.cpp replays the trace on a virtual clock).
#pragma once
#ifdef __CUDACC__
#define SFN __host__ __device__ inline
#else
#define SFN inline
#endif

#define S_NSLOT 64
#define S_MAXPG 68
#define S_PAGE 512
#define S_RING 1024
#define S_OUT (1 << 17)
#define S_MAXE 192            // sequences with rows in one pass
#define S_GRPW 8
#define S_AQ 21            // rows of an attention group: 21 x 6 q heads are the 128 rows of a tensor-core tile
#define S_SWMAX 12            // expert swaps per rebalance
#define S_NL 48
#define S_NE 384

struct PHdr {               // what a pass is: written before every pass (by the host, or by the scheduler kernel)
  int T, tag, ngrp, nseq, nsnap, nlog, mode, nprol;     // mode: 0 none, 1 logits to `logits`, 2 argmax candidates
  int unitsL, unitsG, o_slot, o_pos, o_tok, o_back, o_grp, o_seq, o_snap, o_log, o_prol, o_pt, lo, hi, tok_dev, rg;
  int rgd, pad2;            // rg: row groups per block of the expert GEMMs (1 or 3); rgd: of the dense ones (1 or 2)
  int nswap, o_swap;        // expert swaps between cards before this pass: (layer, a, b, card a, index a, card b, index b)
  float* logits;            // [nlog][VOCAB_REAL] on card 0 (mode 1)
  const int* tokens;        // when tok_dev: [T] int32 on card 0 (rows' input tokens)
};

struct SReq { int rid, plen, n_out, off; };     // off: the prompt's first token in the arena
struct SShared {                                // host-mapped memory: the only thing host and device share
  volatile unsigned ring_head;                  // host: requests written
  volatile unsigned ring_tail;                  // device: requests admitted
  volatile unsigned out_head;                   // device: token records written
  volatile unsigned cmd_drop, ack_drop;         // host asks for drop_cache; device has done it
  volatile unsigned stop;                       // host: leave the loop
  volatile unsigned pass_no;                    // device: passes composed
  volatile unsigned active, free_pages, total_pages, cached_pages, pad;
  volatile unsigned long long stats[32];
  SReq ring[S_RING];
  int out[S_OUT][2];                            // rid, token | last << 31
};

struct SSlot {
  int state;                  // 0 free, 1 prompt, 2 decoding
  int rid, plen, n_out, pos, nout, last_tok, off;
  int fresh, prol_page, npages, reserve, nkeys, cb_end;   // cb_end: prompt blocks [pos / 512, cb_end) are being computed by this slot
  double t_submit, t_first;
  int pages[S_MAXPG];
  unsigned long long keys[64];
};
struct SNode { unsigned long long key; int page, parent, children, users; unsigned lru; int pad; };   // key 0: empty, 1: deleted
struct SEntry { int slot, n, kind, li, p0, pad; unsigned long long snapmask; };   // kind 0 decode row, 1 prompt chunk

enum { SC_PASSES, SC_ROWS, SC_PREFILL, SC_DECODE, SC_HIT, SC_MISS, SC_LATEHIT, SC_EVICT, SC_REQ, SC_MAXACT, SC_INSERT, SC_DEDUP,
       SC_FIRST, SC_FIRST_OK, SC_RECOMP, SC_EMPTY, SC_SWAPS, SC_REBAL, SC_N };

struct Sched {
  // configuration
  int npages, tmax, umax, ncache;               // ncache: cache table entries, a power of two
  double base, dec, row, ctx, target_decode_ms, target_idle_ms, ttft_slo, gap_limit, min_pass_ms, host_ms;
  // arrays owned by whoever holds the scheduler (device memory on card 0, or the host's heap in tests)
  int* freep; int* page_ref; SNode* cache;
  float* eload;               // [48][384] recent pairs per expert and layer
  int* emap;                  // [48][384] where each expert's weights are: card | index on the card << 8
  int reb_seen, reb_every;
  // state
  SSlot slot[S_NSLOT];
  int nfree, cache_evictable, cache_nodes, reserved, lru_tick, pass_no, ne, rows_last, pad;
  double cost_scale, t_last, est_last;
  SEntry ent[S_MAXE];
  unsigned long long counters[32];
  // requests whose prompts are in the arena (the scheduler kernel copies them from the host's page-locked memory):
  // admission stops at head_limit when has_limit is set
  unsigned head_limit, copied; int has_limit, pad3;
};

// ---------------------------------------------------------------------------------------------- hash chain of the prompt
SFN unsigned long long s_mix(unsigned long long h) {
  h ^= h >> 33; h *= 0xff51afd7ed558ccdull; h ^= h >> 33; h *= 0xc4ceb9fe1a85ec53ull; h ^= h >> 33;
  return h;
}
SFN unsigned long long s_block_key(unsigned long long prev, const int* tok) {
  unsigned long long h = prev ^ 0x9e3779b97f4a7c15ull;
  for (int i = 0; i < S_PAGE; i++) h = (h ^ (unsigned)tok[i]) * 0x100000001b3ull + (h >> 29);
  h = s_mix(h);
  return h < 2 ? h + 2 : h;       // 0 and 1 mark empty and deleted table entries
}

// ---------------------------------------------------------------------------------------------- prefix cache (open addressing)
SFN int s_find(const Sched* S, unsigned long long key) {
  const unsigned mask = S->ncache - 1;
  for (unsigned i = (unsigned)s_mix(key) & mask, n = 0; n < (unsigned)S->ncache; i = (i + 1) & mask, n++) {
    const unsigned long long k = S->cache[i].key;
    if (k == key) return (int)i;
    if (k == 0) return -1;
  }
  return -1;
}
SFN int s_insert_node(Sched* S, unsigned long long key, int page, int parent) {
  const unsigned mask = S->ncache - 1;
  for (unsigned i = (unsigned)s_mix(key) & mask, n = 0; n < (unsigned)S->ncache; i = (i + 1) & mask, n++) {
    if (S->cache[i].key < 2) {
      SNode& nd = S->cache[i];
      nd.key = key; nd.page = page; nd.parent = parent; nd.children = 0; nd.users = 1; nd.lru = ++S->lru_tick;
      S->cache_nodes++;
      return (int)i;
    }
  }
  return -1;
}
SFN void s_unref(Sched* S, int page) {
  if (--S->page_ref[page] == 0) S->freep[S->nfree++] = page;
}
SFN void s_remove_node(Sched* S, int i) {       // a node nobody uses
  SNode& nd = S->cache[i];
  if (nd.parent >= 0 && S->cache[nd.parent].key >= 2) S->cache[nd.parent].children--;
  s_unref(S, nd.page);
  nd.key = 1;
  S->cache_nodes--;
  S->cache_evictable--;
}
SFN bool s_evict_one(Sched* S) {                // the least recently used leaf that nobody uses
  int best = -1;
  for (int i = 0; i < S->ncache; i++) {
    const SNode& nd = S->cache[i];
    if (nd.key >= 2 && nd.users == 0 && nd.children == 0 && (best < 0 || nd.lru < S->cache[best].lru)) best = i;
  }
  if (best < 0) return false;
  s_remove_node(S, best);
  S->counters[SC_EVICT]++;
  return true;
}
SFN int s_alloc_page(Sched* S) {
  if (S->nfree == 0) s_evict_one(S);
  if (S->nfree == 0) return 0;                  // cannot happen: admission reserved the page
  const int p = S->freep[--S->nfree];
  S->page_ref[p] = 1;
  return p;
}
SFN void s_drop_cache(Sched* S) {
  // nodes without users form subtrees closed downwards: removing them leaves the parents' counts right
  for (int i = 0; i < S->ncache; i++)
    if (S->cache[i].key >= 2 && S->cache[i].users == 0) s_remove_node(S, i);
  // an emptied table: forget the deletion marks, so that probes stay short
  if (S->cache_nodes == 0) for (int i = 0; i < S->ncache; i++) S->cache[i].key = 0;
}
SFN void s_use_node(Sched* S, int i) {          // one more running request shares this page
  SNode& nd = S->cache[i];
  if (nd.users == 0) S->cache_evictable--;
  nd.users++;
  nd.lru = ++S->lru_tick;
  S->page_ref[nd.page]++;
}

// ---------------------------------------------------------------------------------------------- sequences
SFN void s_release(Sched* S, int si) {
  SSlot& s = S->slot[si];
  for (int j = 0; j < s.npages; j++) {
    const int page = s.pages[j];
    if (j < s.nkeys) {
      const int nd = s_find(S, s.keys[j]);
      if (nd >= 0 && S->cache[nd].page == page) {
        if (--S->cache[nd].users == 0) S->cache_evictable++;
      }
    }
    s_unref(S, page);
  }
  S->reserved -= s.reserve;
  s.reserve = 0; s.npages = 0; s.state = 0; s.cb_end = 0;
}
SFN void s_ensure_pages(Sched* S, SSlot& s, int upto) {      // pages for positions < upto
  while (s.npages * S_PAGE < upto) {
    s.reserve--; S->reserved--;
    s.pages[s.npages++] = s_alloc_page(S);
  }
}
SFN void s_cache_insert(Sched* S, SSlot& s, int j) {         // block j of s (a full prompt page whose snapshot was written)
  const unsigned long long key = s.keys[j];
  if (s_find(S, key) >= 0) return;
  int parent = -1;
  if (j) {
    parent = s_find(S, s.keys[j - 1]);
    if (parent < 0) return;                     // the chain below is not cached: this page could not be found again
  }
  if (s_insert_node(S, key, s.pages[j], parent) < 0) return;
  if (parent >= 0) S->cache[parent].children++;
  S->page_ref[s.pages[j]]++;
  S->counters[SC_INSERT]++;
}
SFN void s_late_hits(Sched* S, SSlot& s) {      // at a page boundary: take over blocks cached since admission
  if (s.pos % S_PAGE || s.npages * S_PAGE != s.pos) return;
  const int usable = s.nkeys < (s.plen - 1) / S_PAGE ? s.nkeys : (s.plen - 1) / S_PAGE;
  int j = s.pos / S_PAGE, got = 0;
  while (j < usable) {
    const int nd = s_find(S, s.keys[j]);
    if (nd < 0) break;
    s_use_node(S, nd);
    s.pages[s.npages++] = S->cache[nd].page;
    j++; got++;
  }
  if (got) {
    s.pos = j * S_PAGE;
    s.fresh = 1; s.prol_page = s.pages[s.npages - 1];
    s.reserve -= got; S->reserved -= got;
    S->counters[SC_LATEHIT] += got;
  }
}
SFN bool s_admit(Sched* S, const SReq& rq, const int* arena, double now) {
  int si = -1;
  for (int i = 0; i < S_NSLOT; i++) if (S->slot[i].state == 0) { si = i; break; }
  if (si < 0) return false;
  SSlot& s = S->slot[si];
  const int nkeys = rq.plen / S_PAGE;
  unsigned long long k = 0;
  for (int j = 0; j < nkeys; j++) { k = s_block_key(k, arena + rq.off + j * S_PAGE); s.keys[j] = k; }
  const int usable = nkeys < (rq.plen - 1) / S_PAGE ? nkeys : (rq.plen - 1) / S_PAGE;    // the last position is always computed
  int hit = 0, pinned = 0, nodes[64];
  while (hit < usable) {
    const int nd = s_find(S, s.keys[hit]);
    if (nd < 0) break;
    if (S->cache[nd].users == 0) pinned++;
    nodes[hit++] = nd;
  }
  const int total_pages = (rq.plen + rq.n_out + S_PAGE - 1) / S_PAGE;
  const int need = total_pages - hit;
  if (S->nfree + S->cache_evictable - S->reserved - pinned < need) return false;
  s.state = 1; s.rid = rq.rid; s.plen = rq.plen; s.n_out = rq.n_out; s.off = rq.off;
  s.nkeys = nkeys; s.npages = 0; s.nout = 0; s.last_tok = -1; s.cb_end = 0;
  for (int j = 0; j < hit; j++) { s_use_node(S, nodes[j]); s.pages[s.npages++] = S->cache[nodes[j]].page; }
  s.pos = hit * S_PAGE;
  s.fresh = 1; s.prol_page = hit ? s.pages[hit - 1] : -1;
  s.reserve = need; S->reserved += need;
  s.t_submit = now; s.t_first = 0.0;
  S->counters[SC_HIT] += hit; S->counters[SC_MISS] += nkeys - hit; S->counters[SC_REQ]++;
  return true;
}
SFN int s_units(int pos, int n) {               // attention units of the global layers (bound): 2 per group of S_AQ rows and page
  return 2 * ((n + S_AQ - 1) / S_AQ) * (((pos + n - 1) >> 9) + 1);
}

// ---------------------------------------------------------------------------------------------- expert placement
// The cards' expert load follows the traffic: from the pairs per expert of the pass that just ran (cnt [48][384]),
// every few prompt passes swap experts between the most and the least loaded card of a layer. Returns the number of
// swaps written to sw (7 ints each: layer, a, b, card a, index a, card b, index b); the cards exchange the weights
// before the next pass (k_swap1 / k_swap2). No result depends on where an expert's weights are.
SFN int s_observe(Sched* S, const int* cnt, int* sw) {
  for (int i = 0; i < S_NL * S_NE; i++) S->eload[i] = 0.75f * S->eload[i] + 0.25f * (float)cnt[i];
  if (++S->reb_seen % S->reb_every) return 0;
  int ns = 0;
  for (int i = 0; i < S_NL && ns < S_SWMAX; i++) {
    const float* el = S->eload + i * S_NE;
    int* em = S->emap + i * S_NE;
    float load[4] = {0.f, 0.f, 0.f, 0.f};
    for (int e = 0; e < S_NE; e++) load[em[e] & 255] += (el[e] > 0.05f ? 1.0f : 0.0f) + el[e] / 128.0f;
    int used[8], nu = 0;       // experts already swapped in this round: the cards move a round's swaps side by side
    for (int it = 0; it < 3 && ns < S_SWMAX; it++) {
      int M = 0, m = 0;
      for (int q = 1; q < 4; q++) { if (load[q] > load[M]) M = q; if (load[q] < load[m]) m = q; }
      const float gap = load[M] - load[m], mean = (load[0] + load[1] + load[2] + load[3]) * 0.25f;
      if (gap < 0.15f * mean + 1.0f) break;
      int b = -1; float wb = 0.f;
      for (int e = 0; e < S_NE; e++)
        if ((em[e] & 255) == m) {
          bool u = false;
          for (int k = 0; k < nu; k++) u |= used[k] == e;
          const float w = (el[e] > 0.05f ? 1.0f : 0.0f) + el[e] / 128.0f;
          if (!u && (b < 0 || w < wb)) { b = e; wb = w; }
        }
      int a = -1; float best = 0.f, da = 0.f;
      for (int e = 0; e < S_NE; e++)
        if ((em[e] & 255) == M) {
          bool u = false;
          for (int k = 0; k < nu; k++) u |= used[k] == e;
          const float d = (el[e] > 0.05f ? 1.0f : 0.0f) + el[e] / 128.0f - wb;
          if (!u && d > 0.f && d < gap) { const float x = d > gap * 0.5f ? d - gap * 0.5f : gap * 0.5f - d; if (a < 0 || x < best) { a = e; best = x; da = d; } }
        }
      if (a < 0 || b < 0) break;
      int* o = sw + 7 * ns++;
      o[0] = i; o[1] = a; o[2] = b; o[3] = em[a] & 255; o[4] = em[a] >> 8; o[5] = em[b] & 255; o[6] = em[b] >> 8;
      const int t = em[a]; em[a] = em[b]; em[b] = t;
      used[nu++] = a; used[nu++] = b;
      load[M] -= da; load[m] += da;
    }
  }
  if (ns) { S->counters[SC_SWAPS] += ns; S->counters[SC_REBAL]++; }
  return ns;
}

// ---------------------------------------------------------------------------------------------- one step of the loop
// cand[c][li]: the cards' candidates of the pass that just ran (argmax key: logit bits << 32 | ~token).
// Writes the tables of the next pass into `tab` and its header into *hdr. Returns the number of rows.
SFN int s_step(Sched* S, SShared* sh, const int* arena, const unsigned long long* const* cand, const int* cnt, int* tab, PHdr* hdr, double now) {
  // ---- (1) the pass that just ran: tokens out, prompt progress, cache inserts, finished requests leave
  if (S->ne && S->rows_last >= 128 && S->est_last > 0) {     // the cost model follows the measured time of prompt passes
    const double ms = (now - S->t_last) * 1e3;
    double sc = S->cost_scale * (1.0 + 0.2 * (ms / (S->est_last * S->cost_scale) - 1.0));
    S->cost_scale = sc < 0.25 ? 0.25 : (sc > 4.0 ? 4.0 : sc);
  }
  unsigned oh = sh->out_head;
  for (int e = 0; e < S->ne; e++) {
    const SEntry& en = S->ent[e];
    SSlot& s = S->slot[en.slot];
    int tok = -1;
    if (en.li >= 0) {
      unsigned long long best = 0;
      for (int cc = 0; cc < 4; cc++) { const unsigned long long v = cand[cc][en.li]; best = v > best ? v : best; }
      tok = (int)(0xFFFFFFFFu - (unsigned)(best & 0xFFFFFFFFull));
    }
    if (en.kind == 0) s.pos++;
    else {
      const int p0 = s.pos;
      s.pos += en.n;
      for (int j = p0 / S_PAGE; j < s.pos / S_PAGE; j++)
        if (j < s.nkeys && ((en.snapmask >> (j - p0 / S_PAGE)) & 1)) s_cache_insert(S, s, j);
      if (en.li >= 0) {
        s.state = 2; s.t_first = now;
        S->counters[SC_FIRST]++;
        if (now - s.t_submit <= S->ttft_slo) S->counters[SC_FIRST_OK]++;
      }
    }
    if (tok >= 0) {
      s.last_tok = tok; s.nout++;
      const bool last = s.nout >= s.n_out;
      sh->out[oh & (S_OUT - 1)][0] = s.rid;
      sh->out[oh & (S_OUT - 1)][1] = tok | (last ? (int)0x80000000 : 0);
      oh++;
      if (last) s_release(S, en.slot);
    }
  }
  sh->out_head = oh;
  S->ne = 0;
  // ---- (2) drop_cache on request
  if (sh->cmd_drop != sh->ack_drop) { s_drop_cache(S); sh->ack_drop = sh->cmd_drop; }
  // ---- (3) admission: in arrival order, while slots and pages last
  {
    unsigned tail = sh->ring_tail;
    const unsigned head = S->has_limit ? S->head_limit : sh->ring_head;
    while (tail != head) {
      if (!s_admit(S, sh->ring[tail & (S_RING - 1)], arena, now)) break;
      tail++;
    }
    sh->ring_tail = tail;
  }
  // ---- (4) the next pass: every decoding sequence, then prompt rows while the pass stays within its time
  int T = 0, ng = 0, nseq = 0, nsnap = 0, nlog = 0, nprol = 0, uL = 0, uG = 0, nd = 0, nactive = 0;
  int* t_slot = tab; int* t_pos = tab + S->tmax; int* t_tok = tab + 2 * S->tmax; int* t_back = tab + 3 * S->tmax;
  int* t_grp = tab + 4 * S->tmax;                               // groups: at most tmax (single rows)
  int* t_seq = t_grp + S_GRPW * S->tmax; int* t_snap = t_seq + 4 * S_MAXE; int* t_log = t_snap + 4 * (S_MAXE + 64);
  int* t_prol = t_log + S_MAXE; int* t_pt = t_prol + 2 * S_MAXE; int* t_swap = t_pt + S_NSLOT * S_MAXPG;
  const int nswap = (cnt && S->eload && S->rows_last >= 256) ? s_observe(S, cnt, t_swap) : 0;
  int ubudget = S->umax;
  double est = S->base;
  // rows of one sequence into the tables
#define S_ROWS(si_, p0_, n_, kind_, want_)                                                                        \
  do {                                                                                                            \
    SSlot& q_ = S->slot[si_];                                                                                     \
    const int r0_ = T;                                                                                            \
    for (int x_ = 0; x_ < (n_); x_++) {                                                                           \
      t_slot[T] = (si_); t_pos[T] = (p0_) + x_; t_back[T] = x_ < 3 ? x_ : 3;                                      \
      t_tok[T] = (kind_) ? arena[q_.off + (p0_) + x_] : q_.last_tok;                                              \
      T++;                                                                                                        \
    }                                                                                                             \
    for (int g0_ = 0; g0_ < (n_); g0_ += S_AQ) {       /* attention groups: up to S_AQ consecutive rows */          \
      const int gn_ = (n_) - g0_ < S_AQ ? (n_) - g0_ : S_AQ, gp_ = (p0_) + g0_;                                   \
      const int pgl0_ = (gp_ - 1023 > 0 ? gp_ - 1023 : 0) >> 9;                                                   \
      const int npgl_ = ((gp_ + gn_ - 1) >> 9) - pgl0_ + 1, npgg_ = ((gp_ + gn_ - 1) >> 9) + 1;                   \
      int* G_ = t_grp + S_GRPW * ng++;                                                                            \
      G_[0] = r0_ + g0_; G_[1] = gn_; G_[2] = (si_); G_[3] = gp_;                                                 \
      G_[4] = pgl0_; G_[5] = npgl_; G_[6] = uL; G_[7] = uG;                                                       \
      uL += 2 * npgl_; uG += 2 * npgg_;                                                                           \
    }                                                                                                             \
    t_seq[4 * nseq] = (si_); t_seq[4 * nseq + 1] = (si_); t_seq[4 * nseq + 2] = r0_; t_seq[4 * nseq + 3] = (n_);  \
    nseq++;                                                                                                       \
    if (q_.fresh) { t_prol[2 * nprol] = (si_); t_prol[2 * nprol + 1] = q_.prol_page; nprol++; q_.fresh = 0; }     \
    SEntry& en_ = S->ent[S->ne++];                                                                                \
    en_.slot = (si_); en_.n = (n_); en_.kind = (kind_); en_.p0 = (p0_); en_.snapmask = 0; en_.li = -1;            \
    if (want_) { en_.li = nlog; t_log[nlog++] = r0_ + (n_) - 1; }                                                 \
  } while (0)

  double allow = S->target_idle_ms;
  for (int i = 0; i < S_NSLOT; i++) {
    SSlot& s = S->slot[i];
    if (s.state) nactive++;
    if (s.state != 2) continue;
    s_ensure_pages(S, s, s.pos + 1);
    S_ROWS(i, s.pos, 1, 0, 1);
    nd++;
    ubudget -= 2 * ((s.pos >> 9) + 1);
    const int gaps = s.n_out - 1;
    if (gaps > 0) {       // a request needs a mean gap under the limit: the pass may be as long as its credit allows
      const int left = s.n_out - s.nout - 1;
      const double a = 1e3 * (S->gap_limit * gaps - (now - s.t_first)) - left * S->target_decode_ms;
      allow = a < allow ? a : allow;
    }
  }
  est += S->dec * nd;
  double target = S->target_idle_ms;
  if (nd) { target = allow - S->host_ms; if (target < S->min_pass_ms) target = S->min_pass_ms; }
  target /= S->cost_scale;
  int rows_left = S->tmax - nd, npre = 0;
  const double per_s = 1000.0 / (S->row * S->cost_scale);
  // prompts: those that can still answer in time first, shortest remaining first; blocks cached meanwhile are taken over
  unsigned long long done_mask = 0;      // slots already looked at in this pass
  for (int i = 0; i < S_NSLOT; i++) if (S->slot[i].state == 1) s_late_hits(S, S->slot[i]);
  for (int round = 0; round < S_NSLOT + 1; round++) {
    int bi = -1; int blate = 0, brem = 0; double bt = 0;
    const bool fallback = round == S_NSLOT;           // nothing fitted the time: the most urgent prompt gets a minimal chunk
    if (fallback) { if (T > 0) break; done_mask = 0; }
    else if (rows_left <= 0 || est + S->row * 16 > target) continue;
    for (int i = 0; i < S_NSLOT; i++) {
      const SSlot& s = S->slot[i];
      if (s.state != 1 || ((done_mask >> i) & 1)) continue;
      const int rem = s.plen - s.pos;
      const int late = (s.t_submit + S->ttft_slo - now) < rem / per_s + 0.03;
      if (bi < 0 || late < blate || (late == blate && (rem < brem || (rem == brem && s.t_submit < bt)))) { bi = i; blate = late; brem = rem; bt = s.t_submit; }
    }
    if (bi < 0) break;
    done_mask |= 1ull << bi;
    int si = bi, limit = 1 << 30;
    if (fallback) { target = 1e9; limit = 256; }
    {   // a prompt whose next block another request is computing waits for it; that request is served now
      const SSlot& s = S->slot[bi];
      const int j = s.pos / S_PAGE;
      if (s.pos % S_PAGE == 0 && j < s.nkeys) {
        int owner = -1;
        for (int o = 0; o < S_NSLOT && owner < 0; o++) {
          const SSlot& a = S->slot[o];
          if (o != bi && a.state == 1 && a.pos / S_PAGE <= j && j < a.cb_end && j < a.nkeys && a.keys[j] == s.keys[j]) owner = o;
        }
        if (owner >= 0) {
          S->counters[SC_DEDUP]++;
          bool sched = false;
          for (int e = 0; e < S->ne; e++) if (S->ent[e].slot == owner) sched = true;
          if (sched) continue;
          si = owner; limit = (S->slot[owner].pos / S_PAGE + 1) * S_PAGE - S->slot[owner].pos;
          done_mask |= 1ull << owner;
        }
      }
    }
    SSlot& s = S->slot[si];
    const double cr = S->row + S->ctx * s.pos;
    int n = s.plen - s.pos;
    if (n > rows_left) n = rows_left;
    if (n > limit) n = limit;
    const int fit = (int)((target - est) / cr);
    if (n > fit) n = fit;
    while (n > 16 && s_units(s.pos, n) > ubudget) n = n / 2 > 16 ? n / 2 : 16;
    if (n <= 0 || s_units(s.pos, n) > ubudget) continue;
    s_ensure_pages(S, s, s.pos + n);
    const bool wants = s.pos + n == s.plen;
    const int p0 = s.pos;
    S_ROWS(si, p0, n, 1, wants);
    SEntry& en = S->ent[S->ne - 1];
    for (int j = p0 / S_PAGE; j < (p0 + n) / S_PAGE; j++)
      if (j < s.nkeys && s_find(S, s.keys[j]) < 0) {
        en.snapmask |= 1ull << (j - p0 / S_PAGE);
        t_snap[4 * nsnap] = s.pages[j]; t_snap[4 * nsnap + 1] = si; t_snap[4 * nsnap + 2] = T - n; t_snap[4 * nsnap + 3] = (j + 1) * S_PAGE - p0;
        nsnap++;
      }
    {
      int ce = (p0 + n - 1) / S_PAGE + 1;
      if (ce > s.nkeys) ce = s.nkeys;
      if (ce > s.cb_end) s.cb_end = ce;
    }
    est += cr * n;
    rows_left -= n; npre += n;
    ubudget -= s_units(p0, n);
  }
#undef S_ROWS
  // ---- (5) the page table and the header
  for (int i = 0; i < S_NSLOT; i++) {
    const SSlot& s = S->slot[i];
    if (s.state) for (int j = 0; j < s.npages; j++) t_pt[i * S_MAXPG + j] = s.pages[j];
  }
  hdr->T = T; hdr->tag = ++S->pass_no; hdr->ngrp = ng; hdr->nseq = nseq; hdr->nsnap = nsnap; hdr->nlog = nlog; hdr->mode = 2;
  hdr->nprol = nprol; hdr->unitsL = uL; hdr->unitsG = uG;
  hdr->o_slot = 0; hdr->o_pos = (int)(t_pos - tab); hdr->o_tok = (int)(t_tok - tab); hdr->o_back = (int)(t_back - tab);
  hdr->o_grp = (int)(t_grp - tab); hdr->o_seq = (int)(t_seq - tab); hdr->o_snap = (int)(t_snap - tab); hdr->o_log = (int)(t_log - tab);
  hdr->o_prol = (int)(t_prol - tab); hdr->o_pt = (int)(t_pt - tab);
  hdr->lo = 0; hdr->hi = 48; hdr->tok_dev = 0;
  hdr->rg = T <= 16 ? 1 : 3; hdr->rgd = T <= 1024 ? 1 : 2; hdr->pad2 = S->tmax;
  hdr->logits = 0; hdr->tokens = 0;
  hdr->nswap = nswap; hdr->o_swap = (int)(t_swap - tab);
  S->t_last = now; S->est_last = npre ? est : 0.0; S->rows_last = npre;
  S->counters[SC_PASSES]++; S->counters[SC_ROWS] += T; S->counters[SC_PREFILL] += npre; S->counters[SC_DECODE] += nd;
  if (T == 0) S->counters[SC_EMPTY]++;
  if ((unsigned long long)nactive > S->counters[SC_MAXACT]) S->counters[SC_MAXACT] = nactive;
  // what the host may read (idle, kv_pages, stats)
  sh->active = nactive; sh->free_pages = S->nfree; sh->total_pages = S->npages; sh->cached_pages = S->cache_nodes;
  for (int k = 0; k < SC_N; k++) sh->stats[k] = S->counters[k];
  sh->pass_no = S->pass_no;
  return T;
}

// table sizes (ints) for a given tmax, and the scheduler's defaults
SFN int s_tab_ints(int tmax) { return (4 + S_GRPW) * tmax + 4 * S_MAXE + 4 * (S_MAXE + 64) + S_MAXE + 2 * S_MAXE + S_NSLOT * S_MAXPG + 7 * S_SWMAX; }
SFN void s_init(Sched* S, int npages, int tmax, int umax, int ncache, int* freep, int* page_ref, SNode* cache) {
  S->npages = npages; S->tmax = tmax; S->umax = umax; S->ncache = ncache;
  S->base = 13.0; S->dec = 0.09; S->row = 0.0228; S->ctx = 0.30e-6;
  S->target_decode_ms = 80.0; S->target_idle_ms = 140.0; S->ttft_slo = 5.0; S->gap_limit = 0.090; S->min_pass_ms = 45.0; S->host_ms = 3.0;
  S->freep = freep; S->page_ref = page_ref; S->cache = cache;
  S->eload = 0; S->emap = 0; S->reb_seen = 0; S->reb_every = 6;
  for (int i = 0; i < S_NSLOT; i++) { S->slot[i].state = 0; S->slot[i].npages = 0; S->slot[i].reserve = 0; S->slot[i].cb_end = 0; }
  S->nfree = npages;
  for (int i = 0; i < npages; i++) { freep[i] = npages - 1 - i; page_ref[i] = 0; }
  for (int i = 0; i < ncache; i++) cache[i].key = 0;
  S->cache_evictable = 0; S->cache_nodes = 0; S->reserved = 0; S->lru_tick = 0; S->pass_no = 1 << 20; S->ne = 0; S->rows_last = 0;
  S->cost_scale = 1.0; S->t_last = 0.0; S->est_last = 0.0;
  for (int k = 0; k < 32; k++) S->counters[k] = 0;
  S->head_limit = 0; S->copied = 0; S->has_limit = 0;
}
